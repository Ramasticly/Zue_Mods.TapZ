package com.zue.attackeditor;

/**
 * Presets de aceleracao da SPEEDLINE (Java puro). Cada preset e um perfil de velocidade nas fronteiras dos frames da cadeia;
 * para cada eixo o app calcula a speed inicial e a aceleracao de cada frame de modo que o DESLOCAMENTO TOTAL fique igual ao de antes
 * (vezes a escala em %), entao da para diminuir/aumentar o movimento mantendo o padrao. Frames depois do primeiro mantem a velocidade
 * (bit 64) e so recebem a aceleracao.
 */
final class AccelPresets {
    private AccelPresets() { }

    static final String[] NAMES = {
        "Comecar devagar e acelerar rapidamente", "Acelerar ate o fim", "Desacelerar rapidamente",
        "Desacelerar ate parar", "Acelerar e desacelerar", "Velocidade constante"};
    static final int SLOW_START = 0, ACCEL = 1, DECEL_FAST = 2, DECEL_STOP = 3, EASE = 4, CONSTANT = 5;

    /** Perfil de velocidade (0..1) nas n+1 fronteiras de n frames. */
    static double[] profile(int preset, int n) {
        double[] u = new double[n + 1];
        for (int i = 0; i <= n; i++) {
            double r = n == 0 ? 0 : i / (double) n;
            switch (preset) {
                case SLOW_START: u[i] = 0.1 + 0.9 * r * r * r; break;
                case ACCEL: u[i] = 0.2 + 0.8 * r; break;
                case DECEL_FAST: u[i] = 0.15 + 0.85 * (1 - r) * (1 - r) * (1 - r); break;
                case DECEL_STOP: u[i] = 1 - r; break;
                case EASE: u[i] = 0.15 + 0.85 * Math.sin(Math.PI * r); break;
                default: u[i] = 1; break;
            }
        }
        return u;
    }

    /** Deslocamento de um frame de t ticks com velocidade inicial v e aceleracao a, na conta do jogo. */
    static double frameShift(int t, double v, double a) { return t * v + a * t * (t - 1) / 2.0; }

    /**
     * Aplica o preset a cadeia: por eixo, mantem o deslocamento total (x escala%) e distribui speed/aceleracao pelos frames.
     * Eixo sem deslocamento fica como esta. Nunca mexe no TIME.
     */
    static Ano.Mpt[] apply(Ano.Mpt[] m, SpeedLine.Chain c, int preset, double scalePct) {
        int n = c.frames();
        SpeedLine.Pt end = c.vertex(n), start = c.vertex(0);
        double[] total = {(end.x - start.x) * scalePct / 100.0, (end.y - start.y) * scalePct / 100.0};
        double[] u = profile(preset, n);
        Ano.Mpt[] out = m.clone();
        for (int f = c.head; f <= c.last; f++) out[f] = out[f].copy();
        for (int axis = 0; axis < 2; axis++) {
            if (total[axis] == 0) continue;
            double s = 0;
            for (int i = 0; i < n; i++) {
                int t = FrameTools.ticks(m[c.head + i]);
                if (t <= 0) continue;
                s += t * u[i] + (u[i + 1] - u[i]) * (t - 1) / 2.0;
            }
            if (s == 0) continue;
            double v = total[axis] / s;
            for (int i = 0; i < n; i++) {
                int f = c.head + i;
                int t = FrameTools.ticks(m[f]);
                double a = t > 0 ? v * (u[i + 1] - u[i]) / t : 0;
                Ano.Mpt p = out[f];
                if (i == 0) p = FrameTools.setSpeed(p, axis, v * u[0], true);
                else p = FrameTools.setSpeed(p, axis, 0, false);
                p = FrameTools.setAccel(p, axis, a);
                out[f] = p;
            }
        }
        for (int f = c.head + 1; f <= c.last; f++) {            // quem nao e o primeiro mantem a velocidade do anterior
            Ano.Mpt p = out[f].copy();
            p.flags |= 2;
            p.wActFlag |= 64;
            p.normalize();
            out[f] = p;
        }
        return out;
    }

    /** Multiplica speeds e aceleracoes proprias dos frames da cadeia por {@code pct}/100: o movimento fica mais lento/rapido com o mesmo padrao. */
    static Ano.Mpt[] scale(Ano.Mpt[] m, SpeedLine.Chain c, double pct) {
        Ano.Mpt[] out = m.clone();
        double k = pct / 100.0;
        for (int f = c.head; f <= c.last; f++) {
            Ano.Mpt p = m[f].copy();
            if ((p.flags & 4) != 0) {
                if ((p.moveMask & 1) != 0) p.speedX = (int) Math.round(p.speedX * k);
                if ((p.moveMask & 2) != 0) p.speedY = (int) Math.round(p.speedY * k);
                if ((p.moveMask & 4) != 0) p.accelX = (int) Math.round(p.accelX * k);
                if ((p.moveMask & 8) != 0) p.accelY = (int) Math.round(p.accelY * k);
            }
            out[f] = p;
        }
        return out;
    }
}
