package com.zue.attackeditor;

import android.app.Activity;
import android.content.DialogInterface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Modo DEFINIR de "Adicionar Sprites": posicao (MID), RAZ (zoom, rotacao, alpha), Hitbox e Hurtbox. O que for definido aqui vale para todos os Frames adicionados
 * (e so para eles). Edita o {@link AddSprites.Define} recebido no proprio objeto. So tela; as contas ficam em {@link AddSprites}.
 */
final class AddDefineDialog {
    private AddDefineDialog() { }

    private static final int TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A;

    static void show(final Activity a, final AddSprites.Define d, final Runnable done) {
        final ScrollView sv = new ScrollView(a);
        final LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = SpriteListScreen.dp(a, 14);
        box.setPadding(p, p / 2, p, p / 2);
        sv.addView(box);
        final Runnable[] build = {null};
        build[0] = new Runnable() {
            @Override public void run() {
                box.removeAllViews();
                box.addView(SpriteListScreen.text(a, "Vale para todos os Frames adicionados agora, e só para eles. O time é o do rodapé da lista.", 11, DIM, false));
                head(a, box, "POSIÇÃO (MID)");
                box.addView(toggle(a, "Centralizada (automática, por sprite)", d.posCentered, new Runnable() { @Override public void run() { d.posCentered = !d.posCentered; build[0].run(); } }));
                if (!d.posCentered) {
                    row(a, box, "X", -4000, 4000, d.midX, new Stepper.OnValue() { @Override public void on(double v) { d.midX = (int) v; } });
                    row(a, box, "Y", -4000, 4000, d.midY, new Stepper.OnValue() { @Override public void on(double v) { d.midY = (int) v; } });
                }
                head(a, box, "RAZ");
                row(a, box, "Zoom X (%)", 0, 5000, d.zx, new Stepper.OnValue() { @Override public void on(double v) { d.zx = (int) v; } });
                row(a, box, "Zoom Y (%)", 0, 5000, d.zy, new Stepper.OnValue() { @Override public void on(double v) { d.zy = (int) v; } });
                row(a, box, "Rotação", -3600, 3600, d.rot, new Stepper.OnValue() { @Override public void on(double v) { d.rot = (int) v; } });
                row(a, box, "Alpha (%)", 0, 100, d.alphaPct, new Stepper.OnValue() { @Override public void on(double v) { d.alphaPct = (int) v; } });
                boxes(a, box, "HITBOX", d.hit, build[0]);
                boxes(a, box, "HURTBOX", d.hurt, build[0]);
            }
        };
        build[0].run();
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Definir").setView(sv)
                .setNegativeButton("RESTAURAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) {
                        AddSprites.Define n = new AddSprites.Define();
                        d.posCentered = n.posCentered; d.midX = n.midX; d.midY = n.midY; d.zx = n.zx; d.zy = n.zy; d.rot = n.rot; d.alphaPct = n.alphaPct;
                        d.hit.on = false; d.hurt.on = false;
                        if (done != null) done.run();
                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) { if (done != null) done.run(); }
                }).show();
    }

    private static void boxes(Activity a, LinearLayout box, String name, final AddSprites.Box b, final Runnable rebuild) {
        head(a, box, name);
        box.addView(toggle(a, b.on ? "Ligada" : "Desligada (toque para ligar)", b.on, new Runnable() { @Override public void run() { b.on = !b.on; rebuild.run(); } }));
        if (!b.on) return;
        row(a, box, "X", -4000, 4000, b.x, new Stepper.OnValue() { @Override public void on(double v) { b.x = (int) v; } });
        row(a, box, "Y", -4000, 4000, b.y, new Stepper.OnValue() { @Override public void on(double v) { b.y = (int) v; } });
        row(a, box, "Largura", 1, 4000, b.w, new Stepper.OnValue() { @Override public void on(double v) { b.w = (int) v; } });
        row(a, box, "Altura", 1, 4000, b.h, new Stepper.OnValue() { @Override public void on(double v) { b.h = (int) v; } });
    }

    private static void head(Activity a, LinearLayout box, String s) {
        TextView t = SpriteListScreen.text(a, s, 12, ACCENT, true);
        t.setPadding(0, SpriteListScreen.dp(a, 12), 0, SpriteListScreen.dp(a, 2));
        box.addView(t);
    }

    private static View toggle(Activity a, String label, boolean on, final Runnable flip) {
        TextView t = SpriteListScreen.button(a, (on ? "☑ " : "☐ ") + label, new View.OnClickListener() { @Override public void onClick(View v) { flip.run(); } });
        t.setTextColor(on ? OK : TEXT);
        return t;
    }

    private static void row(Activity a, LinearLayout box, String label, double lo, double hi, double v, Stepper.OnValue l) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        r.setPadding(0, SpriteListScreen.dp(a, 3), 0, SpriteListScreen.dp(a, 3));
        r.addView(SpriteListScreen.text(a, label, 13, TEXT, false), new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 96), -2));
        r.addView(new Stepper(a).step(1).range(lo, hi).keyboard(l).live(true).value(v).view());
        box.addView(r);
    }
}
