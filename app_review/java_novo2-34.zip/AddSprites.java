package com.zue.attackeditor;

/**
 * "Adicionar Sprite" da timeline com varias sprites do personagem: um Frame por sprite, em sequencia depois do frame {@code after}, todos com o mesmo time. Como cada
 * Frame nasce depende do modo: CENTRAR (MID centrado, zoom do padrao), REESCALAR (zoom pela altura do Parado + MID centrado), PADRAO (o padrao do Editar Frame) ou
 * DEFINIR (valores escolhidos pelo usuario, so para os Frames adicionados). Java puro.
 */
final class AddSprites {
    private AddSprites() { }

    static final int MIN_TIME = 1, MAX_TIME = 255;

    static int clampTime(int t) { return Math.max(MIN_TIME, Math.min(MAX_TIME, t)); }

    enum Mode { CENTER, RESCALE, DEFAULT, DEFINE }

    static final Mode[] MODES = Mode.values();
    static final String[] MODE_NAMES = {"CENTRAR", "REESCALAR", "PADRÃO", "DEFINIR"};

    /** Caixa (hitbox ou hurtbox) a por em cada Frame novo. */
    static final class Box {
        boolean on;
        int x = -16, y = -16, w = 32, h = 32;
        Box copy() { Box b = new Box(); b.on = on; b.x = x; b.y = y; b.w = w; b.h = h; return b; }
    }

    /** Valores do modo DEFINIR. Padrao: posicao centrada por sprite, zoom 100/100, rotacao 0, alpha 100%, sem caixas. */
    static final class Define {
        boolean posCentered = true;
        int midX, midY;
        int zx = 100, zy = 100, rot, alphaPct = 100;
        final Box hit = new Box(), hurt = new Box();

        /** Alpha no formato do Frame: 0 = opaco; senao 255 - (alpha de 0 a 255). */
        int alphaRaw() {
            int p = Math.max(0, Math.min(100, alphaPct));
            return p >= 100 ? 0 : 255 - (int) Math.round(p * 255 / 100.0);
        }

        Define copy() {
            Define d = new Define();
            d.posCentered = posCentered; d.midX = midX; d.midY = midY; d.zx = zx; d.zy = zy; d.rot = rot; d.alphaPct = alphaPct;
            d.hit.on = hit.on; d.hit.x = hit.x; d.hit.y = hit.y; d.hit.w = hit.w; d.hit.h = hit.h;
            d.hurt.on = hurt.on; d.hurt.x = hurt.x; d.hurt.y = hurt.y; d.hurt.w = hurt.w; d.hurt.h = hurt.h;
            return d;
        }
    }

    /** Modo + time + valores do DEFINIR. */
    static final class Spec {
        final Mode mode;
        final int time;
        final Define define;
        Spec(Mode mode, int time, Define define) { this.mode = mode; this.time = time; this.define = define == null ? new Define() : define; }
    }

    /** Padrao de uma sprite {@code image} no modo escolhido (sem as caixas). */
    static SpriteDefaults.Def defFor(Spec spec, int image, SpriteDefaults.Store st, Centralize.Sizes sizes, double refH) {
        SpriteDefaults.Def base = st == null ? new SpriteDefaults.Def() : st.get(image);
        int[] s = sizes == null ? null : sizes.logical(image);
        boolean sized = s != null && s[0] > 0 && s[1] > 0;
        switch (spec.mode) {
            case DEFAULT:
                return base;
            case RESCALE:
                if (sized && refH > 0) return Centralize.toDef(base, Centralize.plan(refH, s[0], s[1]));
                // sem referencia (sem Parado) ou sem tamanho: centra sem mudar o tamanho
                // fall through
            case CENTER: {
                if (sized) { base.midX = -(int) Math.round(s[0] * base.zx / 200.0); base.midY = -(int) Math.round(s[1] * base.zy / 100.0); }
                return base;
            }
            default: {
                Define d = spec.define;
                SpriteDefaults.Def r = new SpriteDefaults.Def();
                r.zx = d.zx; r.zy = d.zy; r.rot = d.rot; r.alpha = d.alphaRaw();
                if (d.posCentered) { if (sized) { r.midX = -(int) Math.round(s[0] * d.zx / 200.0); r.midY = -(int) Math.round(s[1] * d.zy / 100.0); } }
                else { r.midX = d.midX; r.midY = d.midY; }
                return r;
            }
        }
    }

    private static Ano.Hit box(int flag, Box b) {
        Ano.Hit h = new Ano.Hit();
        h.flag = flag; h.x = b.x; h.y = b.y; h.width = Math.max(1, b.w); h.height = Math.max(1, b.h);
        return h;
    }

    /**
     * Lista nova com {@code images.length} Frames depois de {@code after}, NA ORDEM de {@code images} (ordem da selecao), cada um com {@code spec.time} ticks; o Frame base
     * fornece o resto (hitboxes, som, velocidade nao entram, como em {@link FrameOps#insertSprites}). Devolve a lista original se nao deu para inserir.
     */
    static Ano.Mpt[] insert(Ano.Mpt[] mp, int after, int[] images, Spec spec, SpriteDefaults.Store st, Centralize.Sizes sizes, double refH) {
        if (mp == null || images == null || images.length == 0 || spec == null || !FrameOps.ok(mp, after)) return mp;
        int t = clampTime(spec.time);
        int[] ticks = new int[images.length];
        java.util.Arrays.fill(ticks, t);
        Ano.Mpt[] out = FrameOps.insertSprites(mp, after, images, ticks);
        if (out == mp || out.length != mp.length + images.length) return mp;
        for (int k = 0; k < images.length; k++) {
            if (images[k] < 0) continue;
            Ano.Mpt m = SpriteDefaults.write(out[after + 1 + k], defFor(spec, images[k], st, sizes, refH));
            if (spec.mode == Mode.DEFINE && (spec.define.hit.on || spec.define.hurt.on)) {
                java.util.ArrayList<Ano.Hit> hs = new java.util.ArrayList<Ano.Hit>();
                if (spec.define.hurt.on) hs.add(box(1, spec.define.hurt));
                if (spec.define.hit.on) hs.add(box(2, spec.define.hit));
                m.hits = hs.toArray(new Ano.Hit[0]);
                m.flags |= 0x10;
                m.normalize();
            }
            out[after + 1 + k] = m;
        }
        return out;
    }

    /** Compatibilidade: modo PADRAO. */
    static Ano.Mpt[] insert(Ano.Mpt[] mp, int after, int[] images, int time, SpriteDefaults.Store st) {
        return insert(mp, after, images, new Spec(Mode.DEFAULT, time, null), st, null, -1);
    }
}
