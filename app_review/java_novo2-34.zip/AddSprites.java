package com.zue.attackeditor;

/** "Adicionar Sprite" da timeline com varias sprites do personagem: um Frame por sprite, em sequencia depois do frame {@code after}, todos com o mesmo time, cada um nascendo no padrao da sprite. Java puro. */
final class AddSprites {
    private AddSprites() { }

    static final int MIN_TIME = 1, MAX_TIME = 255;

    static int clampTime(int t) { return Math.max(MIN_TIME, Math.min(MAX_TIME, t)); }

    /**
     * Lista nova com {@code images.length} Frames depois de {@code after} (cada um com {@code time} ticks); o Frame base fornece o resto (hitboxes, som, velocidade nao entram,
     * como em {@link FrameOps#insertSprites}). Cada Frame novo recebe o padrao visual da sprite ({@code st}: zoom, rotacao, alpha, MID e flips - ABSOLUTO, nao relativo).
     * Devolve a lista original se nao deu para inserir.
     */
    static Ano.Mpt[] insert(Ano.Mpt[] mp, int after, int[] images, int time, SpriteDefaults.Store st) {
        if (mp == null || images == null || images.length == 0 || !FrameOps.ok(mp, after)) return mp;
        int t = clampTime(time);
        int[] ticks = new int[images.length];
        java.util.Arrays.fill(ticks, t);
        Ano.Mpt[] out = FrameOps.insertSprites(mp, after, images, ticks);
        if (out == mp || out.length != mp.length + images.length) return mp;
        if (st != null) for (int k = 0; k < images.length; k++) if (images[k] >= 0) out[after + 1 + k] = SpriteDefaults.write(out[after + 1 + k], st.get(images[k]));
        return out;
    }
}
