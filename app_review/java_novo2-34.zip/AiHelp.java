package com.zue.attackeditor;

import java.util.List;
import java.util.Locale;

/**
 * Monta o TBRHelp.md ("Ajuda de IA"): um Markdown em ingles, escrito para uma IA, que o usuario envia a ela para depois perguntar como criar ou
 * editar ataques. O texto fixo esta em {@link AiHelpDoc}; aqui entram os trechos gerados pelo proprio app (exemplos de DAC / HDAT / reacao / CNV
 * lidos e escritos pelos mesmos conversores, tabela do HDAT 4, grupos de reacao, limites do jogo) e o anexo com a ajuda do app (HelpText).
 * Java puro, determinístico.
 */
final class AiHelp {
    private AiHelp() { }

    /** Nome do arquivo gravado em Download/. */
    static final String FILE_NAME = "TBRHelp.md";

    // ---- exemplos (entrada -> leitor -> escritor do app) ----

    private static final String SAMPLE_ANO =
            "$ANO_5: {\n   $PRIO: 3,\n   $LNKS:{\n      $LINK_0: {$BX: 0, $BY: -20, $SYNC{SPAWN_POS: YES, XY: YES, MPT: NOT}, $ANO: 230},\n   },\n   $MPTS:{\n"
            + "      $MPT_0:{ $TIME: 4, $IMG: 12, $MID:[8, 40],\n         $HITS:{ $HT_0:{$FLAG: 1, $COORDS: [-10,-60,20,60]}, },\n      },\n"
            + "      $MPT_1:{ $TIME: 6, $IMG: 13, $WACTFLAG: 64, $SE: 81,\n         $MOVE:{$XSPEED: 2.5, $XACCEL: 0.25, },\n"
            + "         $HITS:{ $HT_0:{$FLAG: 1, $COORDS: [-10,-60,20,60]}, $HT_1:{$FLAG: 2, $COORDS: [10,-50,40,20]}, $HT_2:{$FLAG: 0, $COORDS: [30,-40,0,0]}, },\n"
            + "         $OPT:{$FLAG: 0, $DATA: B[12,52,0,0]},\n      },\n"
            + "      $MPT_2:{ $TIME: 5, $IMG: 14,\n         $RAZ:{$ROT: 15, $ALPHA: 0, $XZOOM: 100, $YZOOM: 100},\n      },\n   },\n},";

    private static final String SAMPLE_CNV = "$SPR_0:{$src:0, $x:0, $y:0, $w:128, $h:192}, $SPR_1:{$src:0, $x:128, $y:0, $w:96, $h:160},";

    /** Texto do ANO de exemplo ja relido e reescrito pelo conversor do app (cai no texto cru se algo falhar). */
    static String sampleAno() {
        String body;
        try { body = DacText.ano(DacText.parseAno(SAMPLE_ANO, 5, null), -1); } catch (Exception e) { body = SAMPLE_ANO; }
        return "DAC_ACT_ {\n" + Saver.indent(body) + "\n   // ... the other ANOs ...\n}";
    }

    static String sampleGolpe() {
        CharData.Move m = new CharData.Move();
        m.animInicial = 5;
        m.projNormal = 21;
        m.animSeqChao = 6;
        m.animEndChao = 7;
        m.animSeqAr = 8;
        m.animEndAr = 7;
        return DacText.move(m, 2);
    }

    static String sampleReaction() {
        byte[] rows = new byte[2 * ReactionTable.STRIDE];
        int[][] r = {{6, 9, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}, {4, 5, 4, -1, 0, 2, 0, -1, 0, 2, 0, 0, 0, 9}};
        for (int i = 0; i < r.length; i++) for (int c = 0; c < ReactionTable.STRIDE; c++) rows[i * ReactionTable.STRIDE + c] = (byte) r[i][c];
        return "// slot 3 of the character = HDAT 17\n" + Saver.reactionText(new ReactionTable(rows, 0), 3).replaceAll("\\s+$", "");
    }

    static String sampleCnv() {
        try {
            Cnv c = Cnv.fromTxt(SAMPLE_CNV, true);
            if (c != null) return c.toTxt().replaceAll("\\s+$", "");
        } catch (Exception e) { /* texto cru abaixo */ }
        return "CNV_TXT_ {\n   " + SAMPLE_CNV + "\n}";
    }

    // ---- tabelas geradas ----

    /** Descricao de cada campo do HDAT 4, na ordem de {@link DacText#MOVE_KEYS}. */
    static final String[] MOVE_DOC = {
        "Option bits (table below). Sum the bits you want.",
        "The ANO that starts the move.",
        "Projectile ANO when the opponent is at about the same height as the attacker (0 = none). With TRIPLE (4) the ANOs +1 and +2 are thrown too.",
        "Projectile ANO when the **attacker** is far below the opponent (Y difference ≥ 51 px; the attacker is lower).",
        "Projectile ANO when the **attacker** is far above the opponent (Y difference ≥ 37 px; the attacker is higher).",
        "Projectile \"global hit\" ANO (projectile-related animation played on a hit; exact trigger not verified — copy from an existing move).",
        "Projectile ANO played after the projectile hits (its hit/explosion animation).",
        "Projectile ANO played when the projectile touches the floor.",
        "Projectile chases the opponent (0 = off).",
        "Turn speed of the chase.",
        "Projectile repeat count (> 0 repeats; uses the frame window 512, so the move cannot also grab).",
        "Sub-projectile ANO (spawned by a flag-0 hit inside a projectile ANO).",
        "Sub-projectile ANO after it hits.",
        "Sub-projectile ANO when it touches the floor.",
        "SEQ_PROJETIL: ANO the attacker switches to when the first hit of a projectile connects (applies to the whole move).",
        "SEQ on the ground: ANO to go to when a hit connects while the attacker is on the ground.",
        "END on the ground: ANO to go to on a new hit while in the SEQ ANO (the END ANO has no further transition).",
        "SEQ in the air: like SEQ on the ground but while airborne.",
        "END in the air.",
        "Landing after a MISSED aerial move: ANO to switch to when touching the floor.",
        "Landing after a CONNECTED aerial move.",
        "Defender's ANO while being grabbed (grab moves).",
        "Unknown (offset 44): keep the value of an existing move.",
        "Unknown (offset 46): keep the value of an existing move.",
    };

    /** Byte dentro do registro de 48 bytes do HDAT 4, na ordem de {@link DacText#MOVE_KEYS} (igual ao leitor de CharData). */
    static final int[] MOVE_BYTE = {0, 2, 4, 34, 36, 38, 6, 40, 26, 28, 30, 18, 20, 42, 32, 10, 12, 14, 16, 8, 22, 24, 44, 46};

    static String hdat4Table() {
        StringBuilder sb = new StringBuilder("| # | byte offset | `$KEY` | Meaning |\n|---|---|---|---|\n");
        for (int i = 0; i < DacText.MOVE_KEYS.length; i++)
            sb.append("| ").append(i).append(" | ").append(MOVE_BYTE[i]).append(" | `").append(DacText.MOVE_KEYS[i]).append("` | ").append(i < MOVE_DOC.length ? MOVE_DOC[i] : "").append(" |\n");
        sb.append("\nAll values are 16-bit integers (0..32767); the \"byte offset\" column is where the field sits inside the 48-byte HDAT 4 record (the game stores them in its own order, which differs from this text-key order). A value of 0 means \"none\" for ANO fields.");
        return sb.toString();
    }

    private static final String[] GROUP_NAMES = {"normal", "alternate sound", "strong", "light", "no effect"};

    static String opt1Groups() {
        StringBuilder sb = new StringBuilder("| Group | Name | `OPT1` range | Hit effect (effect-pack ANO) | Hit sound | Pushes the defender | Hitstop |\n|---|---|---|---|---|---|---|\n");
        for (int g = 0; g < GROUP_NAMES.length; g++) {
            Opt1 o = new Opt1(g * 50);
            sb.append("| ").append(g).append(" | ").append(GROUP_NAMES[g]).append(" | ").append(g * 50).append("–").append(g * 50 + 49).append(" | ")
              .append(o.effectAno < 0 ? "none" : String.valueOf(o.effectAno)).append(" | ")
              .append(o.sound < 0 ? "none" : "se_" + (o.sound < 10 ? "0" : "") + o.sound).append(" | ")
              .append(o.pushes ? "yes" : "no").append(" | ")
              .append(o.hitstopMode == 2 ? "none" : o.hitstopMode == 1 ? "half (melee)" : "normal").append(" |\n");
        }
        return sb.toString().replaceAll("\\s+$", "");
    }

    static String limits() {
        return "| Limit | Value | If exceeded |\n|---|---|---|\n"
                + "| Boxes (`$HITS`) per frame | " + GameRules.MAX_HITS + " | **fatal** — the game array `hit[50]` (5 numbers per box) overflows and the game closes |\n"
                + "| Links per ANO | " + GameRules.MAX_LINKS + " | **fatal** — `lnk[13]`; one level only, a link's own links/boxes are ignored |\n"
                + "| Frames (`$MPT`) per ANO | " + GameRules.MAX_MPTS + " | **fatal** — the DAC stores the count in 1 byte |\n"
                + "| `$TIME` per frame | " + GameRules.MAX_TIME + " | **fatal** — 1-byte field |\n"
                + "| `OPT1` (reaction code) with a hitbox | " + GameRules.MAX_OPT1 + " (group 0–4) | **fatal** — the group does not exist |\n"
                + "| Live projectiles | 8 | the 9th is silently not created |\n"
                + "| Interpolation (`$OPT` d2) with a next frame that has other box counts | — | **fatal/garbage** — wrong rotation/alpha/zoom or reads garbage |\n"
                + "| Image index not in the CNV | — | the frame has no drawing (warning) |";
    }

    // ---- montagem ----

    /** Anexo: o texto da ajuda do app (portugues), fiel, capitulo a capitulo. */
    static String appendix() {
        StringBuilder sb = new StringBuilder("## Appendix A — The app's own in-app help (verbatim, Portuguese)\n\n"
                + "Source text of the AJUDA screen; the UI labels you will see on the user's phone are exactly these. Use it to confirm button names and behaviours.\n\n");
        for (HelpText.Chapter ch : HelpText.chapters()) {
            sb.append("### ").append(ch.title).append("\n\n_").append(ch.summary).append("_\n\n");
            for (HelpText.Section s : ch.sections) sb.append("#### ").append(s.title).append("\n\n").append(s.body).append("\n\n");
        }
        return sb.toString();
    }

    private static String toc(String doc) {
        StringBuilder sb = new StringBuilder();
        for (String line : doc.split("\n")) if (line.startsWith("## ")) sb.append("- ").append(line.substring(3)).append('\n');
        return sb.toString().replaceAll("\\s+$", "");
    }

    /** O documento completo. {@code buildLabel}: versao do app (so informativo). */
    static String build(String buildLabel) {
        StringBuilder sb = new StringBuilder();
        for (String p : AiHelpDoc.PARTS) sb.append(p);
        String doc = sb.toString();
        doc = doc.replace("{{BUILD}}", buildLabel == null ? "unknown" : buildLabel)
                .replace("{{SAMPLE_ANO}}", sampleAno())
                .replace("{{SAMPLE_GOLPE}}", sampleGolpe())
                .replace("{{SAMPLE_REACTION}}", sampleReaction())
                .replace("{{SAMPLE_CNV}}", sampleCnv())
                .replace("{{OPT1_GROUPS}}", opt1Groups())
                .replace("{{HDAT4_TABLE}}", hdat4Table())
                .replace("{{LIMITS}}", limits());
        doc = doc.replace("{{TOC}}", toc(doc + "## Appendix A — The app's own in-app help (verbatim, Portuguese)\n"));
        return doc.replaceAll("\\s+$", "") + "\n\n" + appendix().replaceAll("\\s+$", "") + "\n";
    }

    /** Linhas do documento que começam com "## " (secoes), para conferir. */
    static List<String> sectionTitles(String doc) {
        List<String> out = new java.util.ArrayList<String>();
        for (String line : doc.split("\n")) if (line.startsWith("## ")) out.add(line.substring(3).trim());
        return out;
    }

    static String sizeLabel(String doc) { return String.format(Locale.US, "%.1f KB", doc.getBytes(java.nio.charset.Charset.forName("UTF-8")).length / 1024.0); }
}
