package com.zue.attackeditor;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 * Botao "Ajuda de IA": gera o TBRHelp.md ({@link AiHelp}), grava em Download/ e abre o compartilhamento do Android para o usuario mandar o arquivo a uma IA.
 * O app ja tem acesso a todos os arquivos; o content:// vem do indexador de midia (nao precisa de FileProvider nem de manifest).
 */
final class AiHelpShare {
    private AiHelpShare() { }

    /** Versao do app, so informativa dentro do arquivo. */
    static final String BUILD = "java_novo2-34";

    static File target() {
        return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), AiHelp.FILE_NAME);
    }

    static void run(final Activity a) {
        final BusyDialog bd = BusyDialog.show(a, "Criando " + AiHelp.FILE_NAME);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    bd.set("Montando o documento…", 0, 3);
                    String doc = AiHelp.build(BUILD);
                    bd.set("Gravando em Download/…", 1, 3);
                    final File f = target();
                    File dir = f.getParentFile();
                    if (dir != null && !dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("não foi possível criar " + dir.getPath());
                    Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
                    try { w.write(doc); } finally { w.close(); }
                    bd.set("Preparando o compartilhamento…", 2, 3);
                    MediaScannerConnection.scanFile(a, new String[]{f.getPath()}, new String[]{"text/markdown"}, new MediaScannerConnection.OnScanCompletedListener() {
                        @Override public void onScanCompleted(final String path, final Uri uri) {
                            a.runOnUiThread(new Runnable() { @Override public void run() { bd.dismiss(); share(a, f, uri); } });
                        }
                    });
                } catch (final Exception e) {
                    a.runOnUiThread(new Runnable() { @Override public void run() {
                        bd.dismiss();
                        new android.app.AlertDialog.Builder(a).setTitle("Ajuda de IA")
                                .setMessage("Não foi possível criar o " + AiHelp.FILE_NAME + " em Download/: " + e.getMessage()
                                        + "\n\nConfira se o app tem \"Acesso a todos os arquivos\" (Configurações do Android > Apps > Attack Editor > Permissões).")
                                .setPositiveButton("OK", null).show();
                    } });
                }
            }
        }, "ai-help").start();
    }

    private static void share(Activity a, File f, Uri uri) {
        if (uri == null) {
            Toast.makeText(a, AiHelp.FILE_NAME + " criado em Download/, mas o Android não liberou o compartilhamento. Envie o arquivo pelo gerenciador de arquivos.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, AiHelp.FILE_NAME);
        send.putExtra(Intent.EXTRA_TEXT, "Leia este arquivo (" + AiHelp.FILE_NAME + "): ele descreve o app Attack Editor. Depois responda às minhas perguntas sobre como criar e editar ataques.");
        send.setClipData(ClipData.newRawUri(AiHelp.FILE_NAME, uri));
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            a.startActivity(Intent.createChooser(send, "Enviar " + AiHelp.FILE_NAME + " para uma IA"));
            Toast.makeText(a, AiHelp.FILE_NAME + " salvo em Download/ (" + f.length() / 1024 + " KB)", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(a, AiHelp.FILE_NAME + " criado em Download/. Não achei app para compartilhar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
