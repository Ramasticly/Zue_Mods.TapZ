package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

/** Previa animada (em laco) de uma ANO de qualquer pacote: efeitos, projeteis... */
final class AnimPreview extends View {
    private final AttackRenderer renderer = new AttackRenderer();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Dac dac;
    private SpriteCache sprites;
    private int ano = -1;
    private AttackSim sim;
    private long last;
    private double acc;
    private int age, idle;
    private float zoom = 1.4f;
    private boolean facingLeft;
    private final RectF box = new RectF();
    private boolean hasBox;
    /** >= 0: toca a ANO ate este frame e trava nele (para ver o momento de uma transicao). -2 = toca tudo e trava no fim. -1 = em laco. */
    private int stopPat = -1;
    private boolean frozen;
    private boolean autoReplay, staticMode;
    private long frozenAt;
    private static final long HOLD_MS = 1000;
    private boolean showHits, showOpp;
    /** >= 0: ANO de pouso. Quando o personagem estava no ar e chega ao chao, a previa troca para ela (13 = pouso padrao do jogo). */
    private int landAno = -1;
    private boolean wasAir, landed;
    private Dac oppDac;
    private SpriteCache oppSprites;
    private AttackSim oppSim;
    private static final int OPP_DIST_PX = 100;
    private final AttackRenderer.Options opts = new AttackRenderer.Options();

    AnimPreview(Context c) {
        super(c);
        p.setTextSize(10f * c.getResources().getDisplayMetrics().density);
        p.setTextAlign(Paint.Align.CENTER);
    }

    void setZoom(float z) { zoom = z; }

    private boolean loading;
    private final RectF arc = new RectF();

    /** Enquanto os dados carregam: um semicirculo girando no lugar de "sem animacao". */
    void setLoading(boolean on) { loading = on; invalidate(); }

    /** Angulo (graus) do semicirculo de carga para o instante {@code ms}: uma volta a cada 900 ms. */
    static float loadingAngle(long ms) { return (ms % 900L) * 360f / 900f; }

    private int holdPat = -1, onlyFlag = -1, onlyOcc;

    /** Mostra parado o frame {@code pat} (sem reproduzir): avanca a simulacao ate ele de uma vez e congela. */
    void setStaticFrame(int pat) { holdPat = pat; stopPat = -1; restart(); }

    /** So a n-esima box {@code occ} da flag (1 hurtbox, 2 hitbox); as outras boxes nao sao desenhadas. flag < 0: todas. */
    void setOnlyHit(int flag, int occ) { onlyFlag = flag; onlyOcc = occ; invalidate(); }

    /**
     * Avanca a simulacao ate o objeto raiz chegar ao frame {@code pat} (a 1a vez); para antes se a ANO acaba.
     * Devolve true se chegou ao frame.
     */
    static boolean advanceToPat(AttackSim s, int pat) {
        for (int i = 0; i < 4000; i++) {
            AttackSim.Obj r = s.root();
            if (r == null) return false;
            if (r.pat >= pat) return r.pat == pat;
            if (r.isDone()) return false;
            s.step();
            ground(s);
        }
        return false;
    }

    /** Toca ate o frame {@code pat} (indice, 0 = primeiro) e para nele; pat < 0: toca tudo e para no fim. */
    void setPlayUntil(int pat) { stopPat = pat < 0 ? -2 : pat; restart(); }

    /** Depois de travar, espera 1 s e recomeca sozinha (miniaturas do fluxo). */
    void setAutoReplay(boolean on) { autoReplay = on; }

    /** Simula o pouso: ao tocar o chao depois de estar no ar, toca a ANO {@code ano} (pouso do golpe ou o padrao). -1 desliga. */
    void setLanding(int ano) { landAno = ano; wasAir = false; }

    /** So o primeiro frame, parado (listas grandes de ANOs: barato, sem simular a animacao inteira). */
    void setFirstFrameOnly(boolean on) { staticMode = on; restart(); }

    private boolean hasMark;
    private int markX, markY;

    /** Cruz amarela no ponto (x, y) relativo ao objeto raiz (como as coordenadas de hit; espelha com o objeto). */
    void setMarker(boolean on, int x, int y) { hasMark = on; markX = x; markY = y; invalidate(); }

    /** Mostra as hitboxes na previa. */
    void setShowHits(boolean on) { showHits = on; invalidate(); }

    /** Oponente parado (ANO 0 do pacote dele) a frente do atacante; precisa de dac/sprites dele. */
    void setOpponent(Dac d, SpriteCache s) { oppDac = d; oppSprites = s; }

    boolean hasOpponent() { return oppDac != null && oppSprites != null; }

    void setShowOpponent(boolean on) { showOpp = on && hasOpponent(); restart(); }

    /** Chao: y = 0 e a linha dos pes; nada fica abaixo dela. */
    private static void ground(AttackSim s) { groundSim(s); }

    /** Limita a raiz ao chao e leva os links junto (senao eles ficam no y antigo, flutuando ou afundando). */
    static void groundSim(AttackSim s) {
        AttackSim.Obj r = s.root();
        if (r != null && r.y > 0) { r.y = 0; r.speedY = 0; s.settle(); }
    }

    private AttackSim makeOpp() {
        if (!showOpp || !hasOpponent()) return null;
        Ano a = oppDac.getAno(0);
        if (a == null || !a.present) return null;
        int x = (facingLeft ? -OPP_DIST_PX : OPP_DIST_PX) * 65536;
        return new AttackSim(oppDac, 0, !facingLeft, x, 0);
    }

    private void accumOpp(RectF out, boolean[] any) {
        AttackSim o = makeOpp();
        if (o != null) renderer.accumBounds(o, oppSprites, out, any);
    }

    /** Barra com os interruptores HITBOXES e OPONENTE (so aparece o do oponente se houver dados dele). */
    static android.widget.LinearLayout switchBar(Context c, final AnimPreview pv) {
        final float d = c.getResources().getDisplayMetrics().density;
        android.widget.LinearLayout row = new android.widget.LinearLayout(c);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER);
        final android.widget.Switch sh = new android.widget.Switch(c);
        sh.setText("Hitboxes");
        sh.setTextColor(LayoutManager.TEXT);
        sh.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { pv.setShowHits(on); } });
        row.addView(sh);
        if (pv.hasOpponent()) {
            android.widget.Switch so = new android.widget.Switch(c);
            so.setText("Oponente");
            so.setTextColor(LayoutManager.TEXT);
            so.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { pv.setShowOpponent(on); } });
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = Math.round(18 * d);
            row.addView(so, lp);
        }
        return row;
    }

    /** Recomeca (depois de travar). */
    void replay() { restart(); }

    void set(Dac d, SpriteCache s, int anoIndex, boolean flip) {
        facingLeft = flip;
        set(d, s, anoIndex);
    }

    void set(Dac d, SpriteCache s, int anoIndex) {
        loading = false;
        dac = d;
        sprites = s;
        ano = anoIndex;
        restart();
    }

    private void restart() {
        sim = null;
        landed = false;
        wasAir = false;
        age = 0;
        idle = 0;
        frozen = false;
        frozenAt = 0;
        Ano a = dac == null ? null : dac.getAno(ano);
        if (a != null && a.present) sim = new AttackSim(dac, ano, facingLeft, 0, 0);
        oppSim = makeOpp();
        if (holdPat >= 0 && sim != null) {            // frame parado: nada de reproducao
            advanceToPat(sim, holdPat);
            computeBox();
            frozen = true;
            last = 0;
            acc = 0;
            invalidate();
            return;
        }
        if (staticMode) {
            hasBox = false;
            if (sim != null && sprites != null) {
                boolean[] any = new boolean[1];
                renderer.accumBounds(sim, sprites, box, any);
                accumOpp(box, any);
                if (any[0] && box.bottom < 0) box.bottom = 0;
                hasBox = any[0] && box.width() > 0 && box.height() > 0;
            }
            frozen = true;
        } else computeBox();
        last = 0;
        acc = 0;
        if (sim != null && stopPat >= 0 && sim.root() != null && sim.root().pat >= stopPat) frozen = true;
        invalidate();
    }

    /** Percorre a animacao uma vez para achar o retangulo total ocupado e poder encaixa-la no quadrado. */
    private void computeBox() {
        hasBox = false;
        if (dac == null || sprites == null || ano < 0) return;
        Ano a = dac.getAno(ano);
        if (a == null || !a.present) return;
        AttackSim s = new AttackSim(dac, ano, facingLeft, 0, 0);
        boolean[] any = new boolean[1];
        int idleN = 0;
        for (int t = 0; t < 400; t++) {
            renderer.accumBounds(s, sprites, box, any);
            s.step();
            ground(s);
            if (s.isSettled() || s.hasWrapped()) idleN++;
            if (idleN > 18) break;
        }
        accumOpp(box, any);
        if (any[0] && box.bottom < 0) box.bottom = 0;
        hasBox = any[0] && box.width() > 0 && box.height() > 0;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D0F13);
        if (loading && (sim == null || sprites == null)) {
            float d = getResources().getDisplayMetrics().density, r = Math.min(14f * d, Math.min(getWidth(), getHeight()) * 0.25f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(LayoutManager.ACCENT);
            arc.set(getWidth() / 2f - r, getHeight() / 2f - r, getWidth() / 2f + r, getHeight() / 2f + r);
            c.drawArc(arc, loadingAngle(SystemClock.uptimeMillis()), 180f, false, p);
            p.setStyle(Paint.Style.FILL);
            p.setStrokeWidth(0f);
            postInvalidateOnAnimation();
            return;
        }
        if (sim == null || sprites == null) {
            p.setColor(0xFF4A505E);
            I18nUi.drawText(c, "sem animacao", getWidth() / 2f, getHeight() / 2f, p);
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (last == 0) last = now;
        acc += (now - last) / (1000.0 / AttackSim.TICKS_PER_SECOND);
        last = now;
        int steps = 0;
        while (!frozen && acc >= 1 && steps < 6) {
            acc -= 1;
            steps++;
            sim.step();
            AttackSim.Obj rr = sim.root();
            if (landAno >= 0 && rr != null) {
                if (rr.y < 0) wasAir = true;
                else if (wasAir && rr.y >= 0 && rr.speedY >= 0) {                 // pousou: troca a ANO raiz pela de pouso, na mesma posicao
                    wasAir = false;
                    Ano la = dac.getAno(landAno);
                    if (la != null && la.present) { sim = new AttackSim(dac, landAno, facingLeft, rr.x, 0); landed = true; }
                }
            }
            ground(sim);
            if (oppSim != null) oppSim.step();
            age++;
            if (stopPat != -1) {                                  // modo "ate o frame": trava em vez de recomecar
                AttackSim.Obj r = sim.root();
                if (stopPat >= 0 && r != null && r.pat >= stopPat) { frozen = true; break; }
                if (sim.isSettled() || sim.hasWrapped() || (r != null && r.isDone())) { frozen = true; break; }
                if (++idle > 100000 || age > 1200) { frozen = true; break; }
                continue;
            }
            if (sim.isSettled() || sim.hasWrapped()) idle++;
            if (idle > 18 || age > 400) { restart(); break; }
        }
        c.save();
        float curScale;
        if (hasBox) {
            float pad = 0.9f;
            float s = Math.min(getWidth() * pad / box.width(), getHeight() * pad / box.height());
            curScale = s;
            c.translate(getWidth() / 2f - box.centerX() * s, getHeight() / 2f - box.centerY() * s);
            c.scale(s, s);
        } else {
            float s = zoom * Math.min(getWidth(), getHeight()) / 100f;
            curScale = s;
            c.translate(getWidth() / 2f, getHeight() * 0.62f);
            c.scale(s, s);
        }
        p.setColor(0xFF3A4254);
        p.setStrokeWidth(2f / Math.max(0.01f, curScale));
        c.drawLine(-20000, 0, 20000, 0, p);
        if (oppSim != null) renderer.drawSim(c, oppSim, oppSprites);
        renderer.drawSim(c, sim, sprites);
        if (showHits) {
            opts.showHits = true;
            opts.onlyHitFlag = onlyFlag;
            opts.onlyHitOcc = onlyOcc;
            opts.pixelScale = curScale;
            renderer.drawOverlay(c, sim, opts);
            if (oppSim != null) renderer.drawOverlay(c, oppSim, opts);
        }
        if (hasMark && sim.root() != null) {
            AttackSim.Obj r = sim.root();
            float mx = r.x / 65536f + ((r.objFlags & 16) != 0 ? -markX : markX), my = r.y / 65536f + markY;
            float u = 1f / Math.max(0.01f, curScale);
            p.setColor(0xFFFFD84D);
            p.setStrokeWidth(2f * u);
            c.drawLine(mx - 7 * u, my, mx + 7 * u, my, p);
            c.drawLine(mx, my - 7 * u, mx, my + 7 * u, p);
            p.setStyle(Paint.Style.STROKE);
            c.drawCircle(mx, my, 4 * u, p);
            p.setStyle(Paint.Style.FILL);
        }
        c.restore();
        if (!frozen) postInvalidateOnAnimation();
        else if (autoReplay && !staticMode) {
            if (frozenAt == 0) frozenAt = now;
            long left = HOLD_MS - (now - frozenAt);
            if (left <= 0) { restart(); postInvalidateOnAnimation(); }
            else postInvalidateDelayed(Math.min(left, 100));
        }
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        last = 0;
    }
}
