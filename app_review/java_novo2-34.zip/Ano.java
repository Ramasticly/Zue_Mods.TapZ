package com.zue.attackeditor;

/** Uma ANO e sua arvore de Links/MPTs (dados ja lidos do DAC, sem estado de execucao). */
public final class Ano {
    public static final Hit[] NO_HITS = new Hit[0];

    public final int index;
    public final boolean present;
    public final int flags;
    /** iActPrio do jogo (byte com sinal). Maior = desenhado mais atras. */
    public final int priority;
    public final Link[] links;
    public final Mpt[] mpts;

    public Ano(int index, boolean present, int flags, int priority,
               Link[] links, Mpt[] mpts) {
        this.index = index;
        this.present = present;
        this.flags = flags;
        this.priority = priority;
        this.links = links == null ? new Link[0] : links;
        this.mpts = mpts == null ? new Mpt[0] : mpts;
    }

    /** Link instanciado pela propria ANO (o jogo so tem 1 nivel de links). */
    public static final class Link {
        public final int baseX;
        public final int baseY;
        public final int flags;

        public Link(int baseX, int baseY, int flags) {
            this.baseX = baseX;
            this.baseY = baseY;
            this.flags = flags;
        }

        public int getAno() { return flags & 0x0FFF; }
        /** Bit 0x1000 LIGADO = o link NAO copia x/y do pai ao nascer (_SetAct: so copia com o bit desligado); fica em 0,0 ate o _SetXY do dono. */
        public boolean spawnPos() { return (flags & 0x1000) != 0; }
        public boolean syncXY() { return (flags & 0x4000) != 0; }
        public boolean syncMpt() { return (flags & 0x8000) != 0; }
    }

    /** Um frame (MPT) como esta no DAC. */
    public static final class Mpt {
        /** Byte de flags do frame (quais campos existem). */
        public int flags;

        public boolean hasTime;
        public boolean hasMid;
        public boolean hasMove;
        public boolean hasOpt;
        public boolean hasRaz;

        /** Duracao em ticks. Sem a flag 0x20 vale 0 = frame que nao avanca. */
        public int time;
        public int midX;
        public int midY;
        /** wActFlag do frame (campo 0x02), 16 bits sem sinal. */
        public int wActFlag;
        public int se = -1;
        public int image = -1;

        /** Bits 1/2/4/8 = quais de speedX/speedY/accelX/accelY foram lidos. */
        public int moveMask;
        public int speedX;
        public int speedY;
        public int accelX;
        public int accelY;

        public Hit[] hits = NO_HITS;

        public int optFlag;
        public final int[] optData = new int[4];

        public int rot;
        /** Valor bruto do alpha (short). */
        public int alphaRaw;
        /** Alpha final 0..255 (255 quando alphaRaw == 0). */
        public int alpha = 255;
        public int xZoom = 100;
        public int yZoom = 100;
        /** 2048 | (512 aditivo ou 1024 outro modo), como o jogo faz ao ler o campo 0x80. */
        public int razFlags;

        /** Copia profunda (edicao em runtime). */
        public Mpt copy() {
            Mpt m = new Mpt();
            m.flags = flags; m.hasTime = hasTime; m.hasMid = hasMid; m.hasMove = hasMove; m.hasOpt = hasOpt; m.hasRaz = hasRaz;
            m.time = time; m.midX = midX; m.midY = midY; m.wActFlag = wActFlag; m.se = se; m.image = image;
            m.moveMask = moveMask; m.speedX = speedX; m.speedY = speedY; m.accelX = accelX; m.accelY = accelY;
            m.hits = new Hit[hits.length];
            for (int i = 0; i < hits.length; i++) {
                Hit h = new Hit();
                h.flag = hits[i].flag; h.x = hits[i].x; h.y = hits[i].y; h.width = hits[i].width; h.height = hits[i].height; h.cut = hits[i].cut;
                m.hits[i] = h;
            }
            m.optFlag = optFlag;
            for (int i = 0; i < 4; i++) m.optData[i] = optData[i];
            m.rot = rot; m.alphaRaw = alphaRaw; m.alpha = alpha; m.xZoom = xZoom; m.yZoom = yZoom; m.razFlags = razFlags;
            return m;
        }

        /** Sincroniza os has* e razFlags com o byte de flags (depois de editar). */
        public void normalize() {
            hasTime = (flags & 0x20) != 0;
            hasMid = (flags & 0x01) != 0;
            hasMove = (flags & 0x04) != 0;
            hasOpt = (flags & 0x40) != 0;
            hasRaz = (flags & 0x80) != 0;
            if (!hasTime) time = 0;
            if (hasRaz) Dac.finishRaz(this);
        }
    }

    public static final class Hit {
        public int flag;
        public int x;
        public int y;
        public int width;
        public int height;
        /** So na sessao de edicao (nao vai para o arquivo): este frame inicia um objeto separado do anterior. */
        public boolean cut;
    }
}
