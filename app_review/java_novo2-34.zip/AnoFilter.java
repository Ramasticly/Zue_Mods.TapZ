package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Filtros da grade de ANOs: reordenam sem esconder nada. As ANOs que casam com o filtro vem primeiro (com moldura) e o resto vai embaixo, sem moldura.
 * Dentro de cada grupo a ordem e a do filtro (Tempo / Frames: maiores primeiro) ou a numerica. Java puro.
 */
final class AnoFilter {
    private AnoFilter() { }

    static final int DEFAULT = 0, IMPORTANCE = 1, MOVES = 2, ATTACK = 3, TIME = 4, FRAMES = 5, EFFECTS = 6;
    static final String[] NAMES = {"Padrão", "Importância", "Golpes", "Ataque", "Tempo", "Frames", "Efeitos"};

    static final class Result {
        /** ANOs na ordem em que a grade mostra. */
        final List<Integer> order = new ArrayList<Integer>();
        /** Quantas das primeiras casam com o filtro (as outras vem depois, sem moldura). */
        int matches;
        final boolean[] matched;
        Result(int n) { matched = new boolean[n]; }
    }

    private static boolean present(Dac dac, int i) {
        Ano a = dac.getAno(i);
        return a != null && a.present && a.mpts.length > 0;
    }

    static boolean hasAttackBox(Ano a) {
        for (Ano.Mpt m : a.mpts) {
            if ((m.flags & 0x10) == 0) continue;
            for (Ano.Hit h : m.hits) if (h.flag == 2 || h.flag == 0) return true;
        }
        return false;
    }

    /** A ANO e animacao de uma flag de efeito (hits 10 a 125 de alguma ANO apontam para ela)? */
    static boolean[] effectAnos(Dac dac) {
        boolean[] r = new boolean[Math.max(dac.size(), 4096)];
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (Ano.Mpt m : a.mpts) {
                if ((m.flags & 0x10) == 0) continue;
                for (Ano.Hit h : m.hits) {
                    int fl = h.flag;
                    if (ObjModel.kindOf(fl) != ObjModel.EFFECT || ObjModel.fxPack(fl) != 2) continue;      // so os efeitos do proprio personagem (pack char)
                    int ano = ObjModel.fxAno(fl);
                    if (ano >= 0 && ano < r.length) r[ano] = true;
                }
            }
        }
        return r;
    }

    private static int ticks(Ano a) { return FrameOps.total(a.mpts); }

    static Result apply(int mode, Dac dac, CharData cd) {
        int n = dac.size();
        Result res = new Result(n);
        boolean[] fx = mode == EFFECTS ? effectAnos(dac) : null;
        for (int i = 0; i < n; i++) {
            Ano a = dac.getAno(i);
            boolean ok = present(dac, i);
            switch (mode) {
                case IMPORTANCE: res.matched[i] = ok && (AttackInfo.anoInfo(cd, i) != null); break;
                case MOVES: res.matched[i] = ok && cd != null && cd.ownerOf(i) != null && !cd.ownerOf(i).generic; break;
                case ATTACK: res.matched[i] = ok && hasAttackBox(a); break;
                case EFFECTS: res.matched[i] = ok && (fx[i] || (i >= 201 && i <= 255)); break;
                case TIME: case FRAMES: res.matched[i] = ok; break;
                default: res.matched[i] = false;
            }
        }
        final int[] key = new int[n];
        for (int i = 0; i < n; i++) {
            Ano a = dac.getAno(i);
            key[i] = !present(dac, i) ? 0 : mode == TIME ? ticks(a) : mode == FRAMES ? a.mpts.length : 0;
        }
        List<Integer> top = new ArrayList<Integer>(), rest = new ArrayList<Integer>();
        for (int i = 0; i < n; i++) (mode != DEFAULT && res.matched[i] ? top : rest).add(Integer.valueOf(i));
        if (mode == TIME || mode == FRAMES) {
            java.util.Collections.sort(top, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer x, Integer y) { return key[x] != key[y] ? (key[x] > key[y] ? -1 : 1) : x - y; }
            });
        }
        res.order.addAll(top);
        res.order.addAll(rest);
        res.matches = mode == DEFAULT ? 0 : top.size();
        return res;
    }
}
