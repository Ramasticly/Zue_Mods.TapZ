package com.zue.attackeditor;

import android.app.Activity;
import android.content.DialogInterface;

/** Menu do ANO (toque no nome do ANO no cabecalho da timeline): loop, copiar ANO (a mesma da lista de ANOs) e Ver Frames. */
final class AnoMenu {
    private AnoMenu() { }

    static void show(final Activity a, final AttackView view, final CharAssets ca, final TimelineOps ops) {
        final Ano an = view.currentAno();
        if (an == null) return;
        final boolean loop = ObjModel.loops(an.mpts);
        String[] items = {loop ? "Loop: ligado (toque para desligar)" : "Loop: desligado (toque para ligar)", "Copiar ANO", "Ver Frames"};
        new I18nBuilder(a).setTitle("ANO " + an.index).setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dlg, int which) {
                if (which == 0) ops.onLoop(!loop);
                else if (which == 1) copy(a, view);
                else FramesScreen.show(a, view, ca, new FramesScreen.Applier() {
                    @Override public void apply(Ano.Mpt[] mp, int focus) { ops.applyFrames(mp, focus); }
                });
            }
        }).setNegativeButton("FECHAR", null).show();
    }

    /** Copia a ANO atual (como esta na edicao, com links e prioridade) para o COLAR da lista de ANOs. */
    static void copy(Activity a, AttackView view) {
        Ano an = view.currentAno();
        if (an == null || an.mpts == null || an.mpts.length == 0) { I18nUi.toast(a, "A ANO " + (an == null ? 0 : an.index) + " está vazia", android.widget.Toast.LENGTH_SHORT).show(); return; }
        AnoOps.Clip c = new AnoOps.Clip();
        c.fromIndex = an.index; c.flags = an.flags; c.priority = an.priority;
        c.links = an.links == null ? new Ano.Link[0] : an.links.clone();
        c.mpts = new Ano.Mpt[an.mpts.length];
        for (int i = 0; i < c.mpts.length; i++) c.mpts[i] = an.mpts[i].copy();
        AttackGrid.clip = c;
        I18nUi.toast(a, "ANO " + an.index + " copiada (" + c.mpts.length + " frame(s))", android.widget.Toast.LENGTH_SHORT).show();
    }
}
