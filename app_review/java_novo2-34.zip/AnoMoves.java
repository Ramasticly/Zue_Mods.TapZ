package com.zue.attackeditor;

import java.util.List;

/** Que golpe renderizar para ver um ANO inteiro em acao no editor de cutscenes (a parte pura escolhe o golpe; {@link #dataFor} monta o AttackData). */
final class AnoMoves {
    private AnoMoves() { }

    /**
     * Indice do golpe do HDAT 4 que alcanca o ANO {@code ano}: primeiro o que o tem como ANIM_INICIAL, depois o dono ({@link CharData#ownerOf}), depois qualquer
     * golpe cujos ANOs alcancados ({@link Saver#anosOfMove}) o incluam. -1 se nenhum golpe o usa (entao o ANO toca sozinho, como no modo ANOS).
     */
    static int moveFor(CharData cd, Dac dac, int ano) {
        if (cd == null) return -1;
        for (int i = 0; i < cd.moves.length; i++) if (cd.moves[i].animInicial == ano && !cd.moves[i].generic) return i;
        CharData.Move o = cd.ownerOf(ano);
        if (o != null) for (int i = 0; i < cd.moves.length; i++) if (cd.moves[i] == o) return i;
        if (dac != null) for (int i = 0; i < cd.moves.length; i++) {
            if (cd.moves[i].animInicial <= 0) continue;
            if (Saver.anosOfMove(dac, cd.moves[i], cd).contains(Integer.valueOf(ano))) return i;
        }
        return -1;
    }

    /** ANOs que usam o evento {@code ev} (hit flag 20), na ordem do DAC. */
    static List<Integer> usersOf(CharAssets ch, int ev) { return CutsceneEdit.users(CutsceneEdit.all(ch.dac), ev); }

    /** Dados para renderizar o ANO inteiro (o golpe dono dele, ou o ANO sozinho). {@code base} = dados do que esta aberto na principal. */
    static AttackData dataFor(AttackData base, int ano) {
        CharAssets ca = base.attacker;
        int mi = moveFor(ca.data, ca.dac, ano);
        AttackData d;
        if (mi >= 0) {
            d = new AttackData(ca, base.opponent, base.effects, base.gameData, mi, ca.data.moves[mi]);
        } else {
            CharData.Move m = CharData.genericFrom(ano, ca.data.ownerOf(ano));
            m.projectile = ano >= 0 && ano < ca.anoKinds().length && ca.anoKinds()[ano] == CharAssets.KIND_PROJECTILE;
            m.rootKind = ca.data.rootKindOf(ano);
            d = new AttackData(ca, base.opponent, base.effects, base.gameData, ano, m);
        }
        d.charf = base.charf;
        d.bobj = base.bobj;
        return d;
    }
}
