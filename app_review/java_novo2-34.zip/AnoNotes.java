package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Notas MANUAIS das ANOs para o (i) da grade: edite o {@code switch} em {@link #fill}. Um {@code case} por ANO; cada chamada abaixo vira uma linha:
 * <pre>
 *   case 0:  blue("Idle Chão"); break;                       // azul = fixo no codigo-fonte do jogo
 *   case 57: green("Especial, botão Z no ar"); break;         // verde = vem do Bin
 *   case 9:  blue("Dash Trás Pulo/Ar ←←"); plain("texto sem cor"); break;
 * </pre>
 * Varias linhas no mesmo {@code case} aparecem na ordem. ANO sem {@code case} aqui cai nos nomes antigos de {@link FixedAnos#name}.
 * Java puro (sem Android).
 */
final class AnoNotes {
    private AnoNotes() { }

    /** Linhas da ANO (vazia se nao ha nota). */
    static List<AttackInfo.Line> lines(int ano) {
        List<AttackInfo.Line> out = new ArrayList<AttackInfo.Line>();
        fill(ano, out);
        return out;
    }

    static boolean has(int ano) { return !lines(ano).isEmpty(); }

    private static void blue(List<AttackInfo.Line> o, String t) { o.add(new AttackInfo.Line(t, AttackInfo.CODE)); }
    private static void green(List<AttackInfo.Line> o, String t) { o.add(new AttackInfo.Line(t, AttackInfo.BIN)); }
    private static void plain(List<AttackInfo.Line> o, String t) { o.add(new AttackInfo.Line(t, AttackInfo.PLAIN)); }

    // ===================================================================================================================
    //  EDITE AQUI  (testado no jogo: char13.txt)
    // ===================================================================================================================
    private static void fill(int ano, List<AttackInfo.Line> o) {
        switch (ano) {
            case 0:  blue(o, "Idle Chão"); break;
            case 1:  blue(o, "Idle Voando"); break;
            case 2:  blue(o, "Super Dash Frente →→→"); break;
            case 3:  blue(o, "Super Dash Trás ←←←"); break;
            case 4:  blue(o, "Defesa"); break;
            case 5:  blue(o, "Voo Frente →"); break;
            case 19: blue(o, "Voo Trás ←"); break;
            case 6:  blue(o, "Dash Frente →→"); break;
            case 7:  blue(o, "Dash Trás ←←"); break;
            case 11: blue(o, "Pulo Frente"); break;
            case 12: blue(o, "Pulo Trás"); break;
            case 10: blue(o, "Pulo cima"); break;
            case 13: blue(o, "Pouso Padrão"); break;
            case 8:  blue(o, "Dash Pulo/Voo →→"); break;
            case 9:  blue(o, "Dash Trás Pulo/Ar ←←"); break;
            case 89: blue(o, "Pouso do alto"); break;
            case 84: blue(o, "Início Carga de Energia"); break;
            case 85: blue(o, "Loop Carga de Energia"); break;
            case 15: blue(o, "Pose de Vitória"); break;
            case 72: blue(o, "Reação de Dano 2"); break;
            case 20: blue(o, "Reação de Dano 1"); break;
            case 68: blue(o, "Reação de dano 3"); break;
            case 67: blue(o, "Reação de Dano: Caindo no chão"); break;
            case 69: blue(o, "Reação de Dano: Caindo no chão 2"); break;
            case 25: blue(o, "Levantando do chão"); break;
            case 24: blue(o, "Caído no chão."); break;
            case 73: blue(o, "Reação de dano 4"); break;
            case 23: blue(o, "Caindo no chão com tremor"); break;
            default: break;
        }
    }
}
