package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Operacoes de ANO da grade de escolha: excluir (a ANO fica vazia mas continua existindo), copiar, colar e mover, mais o aviso de risco.
 * Java puro. Links de outras ANOs e golpes do HDAT 4 que apontam para uma ANO nao sao atualizados (so os Frames mudam de lugar).
 */
final class AnoOps {
    private AnoOps() { }

    /** O que a ANO tem de perigoso para apagar ou sobrescrever. */
    static final class Risk {
        boolean hitbox, projectile, attack;
        boolean any() { return hitbox || projectile || attack; }

        String text() {
            StringBuilder b = new StringBuilder();
            if (hitbox) b.append("• tem hitbox (flag 2)\n");
            if (projectile) b.append("• tem lançamento de projétil (flag 0)\n");
            if (attack) b.append("• é usada por um ataque do BIN (HDAT 4)\n");
            return b.toString();
        }
    }

    static Risk risk(Dac dac, CharData cd, int ano) {
        Risk r = new Risk();
        Ano a = dac.getAno(ano);
        if (a != null && a.present) {
            for (Ano.Mpt m : a.mpts) {
                if ((m.flags & 0x10) == 0) continue;
                for (Ano.Hit h : m.hits) { if (h.flag == 2) r.hitbox = true; if (h.flag == 0) r.projectile = true; }
            }
        }
        if (cd != null) {
            CharData.Move own = cd.ownerOf(ano);
            if (own != null && !own.generic) r.attack = true;
        }
        return r;
    }

    /** Frames copiados de uma ANO, prontos para colar em outra. */
    static final class Clip {
        int fromIndex, flags, priority;
        Ano.Link[] links;
        Ano.Mpt[] mpts;
    }

    static boolean isEmpty(Dac dac, int ano) {
        Ano a = dac.getAno(ano);
        return a == null || !a.present || a.mpts.length == 0;
    }

    /** null se a ANO esta vazia. */
    static Clip copy(Dac dac, int ano) {
        Ano a = dac.getAno(ano);
        if (a == null || !a.present || a.mpts.length == 0) return null;
        Clip c = new Clip();
        c.fromIndex = ano; c.flags = a.flags; c.priority = a.priority;
        c.links = a.links == null ? new Ano.Link[0] : a.links.clone();
        c.mpts = new Ano.Mpt[a.mpts.length];
        for (int i = 0; i < c.mpts.length; i++) c.mpts[i] = a.mpts[i].copy();
        return c;
    }

    /** Esvazia a ANO: sem Frames, mas o numero continua existindo no DAC. */
    static void clear(Dac dac, int ano) {
        if (ano < 0 || ano >= dac.size()) return;
        dac.setAno(ano, new Ano(ano, false, 0, 0, new Ano.Link[0], new Ano.Mpt[0]));
    }

    /** Cola os Frames (copias novas) no lugar do que a ANO tinha. */
    static void paste(Dac dac, int ano, Clip c) {
        if (c == null || ano < 0 || ano >= dac.size()) return;
        Ano.Mpt[] mp = new Ano.Mpt[c.mpts.length];
        for (int i = 0; i < mp.length; i++) mp[i] = c.mpts[i].copy();
        dac.setAno(ano, new Ano(ano, true, c.flags, c.priority, c.links.clone(), mp));
    }

    /** A ANO {@code from} vai para o lugar de {@code to} (que e sobrescrita) e fica vazia. */
    static boolean move(Dac dac, int from, int to) {
        if (from == to || to < 0 || to >= dac.size()) return false;
        Clip c = copy(dac, from);
        if (c == null) return false;
        clear(dac, from);
        paste(dac, to, c);
        return true;
    }

    /** Texto do aviso para uma lista de ANOs (um bloco por ANO com risco); vazio se nenhuma tem. */
    static String warning(Dac dac, CharData cd, List<Integer> anos) {
        StringBuilder b = new StringBuilder();
        for (Integer a : anos) {
            Risk r = risk(dac, cd, a.intValue());
            if (r.any()) b.append("ANO ").append(a).append(":\n").append(r.text());
        }
        return b.toString();
    }

    /** Quantas ANOs da lista tem Frames. */
    static List<Integer> nonEmpty(Dac dac, List<Integer> anos) {
        List<Integer> r = new ArrayList<Integer>();
        for (Integer a : anos) if (!isEmpty(dac, a.intValue())) r.add(a);
        return r;
    }
}
