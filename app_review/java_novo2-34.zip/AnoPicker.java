package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Lista independente de ANOs (todas as do DAC, no minimo 0 a 255): cada uma com a previa do primeiro frame; tocar numa a expande e toca a ANO inteira,
 * com o botao para usa-la. Serve para qualquer tela que precise escolher uma ANO.
 */
final class AnoPicker {
    interface Listener { void onPick(int ano); }

    private final Activity a;
    private final Dac dac;
    private final SpriteCache sprites;
    private final boolean flip;
    private final int selected;
    private final Listener listener;
    private final float d;
    private Dialog dlg;
    private Dac oppDac;
    private SpriteCache oppSprites;

    /** Com oponente: habilita o interruptor Oponente na previa ampliada. */
    static void show(Activity a, Dac dac, SpriteCache sprites, boolean flip, int selected, String title, boolean allowClear, Dac od, SpriteCache os, Listener l) {
        AnoPicker p = new AnoPicker(a, dac, sprites, flip, selected, l);
        p.oppDac = od; p.oppSprites = os;
        p.open(title, allowClear);
    }

    private AnoPicker(Activity a, Dac dac, SpriteCache sprites, boolean flip, int selected, Listener l) {
        this.a = a; this.dac = dac; this.sprites = sprites; this.flip = flip; this.selected = selected; this.listener = l;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    /** {@code allowClear}: mostra "SEM ANO" (devolve 0). */
    static void show(Activity a, Dac dac, SpriteCache sprites, boolean flip, int selected, String title, boolean allowClear, Listener l) {
        new AnoPicker(a, dac, sprites, flip, selected, l).open(title, allowClear);
    }

    private boolean all;

    /** Lista completa do DAC (todas as ANOs, nao so 0..255) e ANO vazia tambem pode ser escolhida (para ir editar/criar frames nela). */
    static void showAll(Activity a, Dac dac, SpriteCache sprites, int selected, String title, Listener l) {
        AnoPicker p = new AnoPicker(a, dac, sprites, false, selected, l);
        p.all = true;
        p.open(title, false);
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private boolean present(int i) {
        Ano an = dac == null ? null : dac.getAno(i);
        return an != null && an.present;
    }

    private void open(String title, boolean allowClear) {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);

        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv(title, 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        TextView hint = tv(all ? "Todas as ANOs do DAC (" + dac.size() + "). ANO vazia também pode ser aberta, para criar frames nela. Toque numa para ver a animação completa." : "Todas as ANOs do DAC (" + Math.max(256, dac.size()) + "; a prévia é do primeiro frame). Toque numa para ver a animação completa.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(8));
        root.addView(hint);
        if (allowClear) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, dp(8));
            root.addView(button("SEM ANO (limpar)", LayoutManager.WARN, new View.OnClickListener() { public void onClick(View v) {
                dlg.dismiss();
                listener.onPick(0);
            } }), lp);
        }
        final GridView gv = new GridView(a);
        gv.setNumColumns(4);
        gv.setVerticalSpacing(dp(6));
        gv.setHorizontalSpacing(dp(6));
        gv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return all ? Math.max(1, dac.size()) : Math.max(256, dac.size()); }
            @Override public Object getItem(int i) { return Integer.valueOf(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(final int i, View cv, ViewGroup parent) {
                LinearLayout cell = new LinearLayout(a);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                GradientDrawable g = new GradientDrawable();
                g.setColor(LayoutManager.PANEL);
                g.setCornerRadius(dp(8));
                if (i == selected) g.setStroke(dp(2), LayoutManager.ACCENT);
                cell.setBackground(g);
                cell.setPadding(dp(3), dp(3), dp(3), dp(3));
                int side = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(18)) / 4 - dp(6);
                boolean ok = present(i);
                if (ok) {
                    AnimPreview pv = new AnimPreview(a);
                    pv.setFirstFrameOnly(true);
                    pv.set(dac, sprites, i, flip);
                    cell.addView(pv, new LinearLayout.LayoutParams(side, side));
                } else {
                    TextView e = tv("vazio", 10, 0xFF4A505E, false);
                    e.setGravity(Gravity.CENTER);
                    e.setBackgroundColor(0xFF0D0F13);
                    cell.addView(e, new LinearLayout.LayoutParams(side, side));
                }
                TextView n = tv(String.valueOf(i), 12, ok ? LayoutManager.TEXT : LayoutManager.DIM, true);
                n.setGravity(Gravity.CENTER);
                cell.addView(n);
                cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                    if (present(i)) expand(i);
                    else if (all) { dlg.dismiss(); listener.onPick(i); }
                    else I18nUi.toast(a, "ANO " + i + " está vazia.", android.widget.Toast.LENGTH_SHORT).show();
                } });
                return cell;
            }
        });
        root.addView(gv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(button("VOLTAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }));
        dlg.show();
        if (selected >= 0 && selected < (all ? dac.size() : Math.max(256, dac.size()))) gv.setSelection(Math.max(0, selected - 4));
    }

    /** A ANO inteira, em laco, maior; com o botao para usar. */
    private void expand(final int ano) {
        final Dialog big = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        big.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("ANO " + ano, 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { big.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        box.addView(h);
        AnimPreview pv = new AnimPreview(a);
        pv.set(dac, sprites, ano, flip);
        if (oppDac != null && oppSprites != null) pv.setOpponent(oppDac, oppSprites);
        int side = Math.min(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.8f), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.40f));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(side, side);
        pl.gravity = Gravity.CENTER_HORIZONTAL;
        pl.setMargins(0, dp(8), 0, dp(8));
        box.addView(pv, pl);
        box.addView(AnimPreview.switchBar(a, pv));
        box.addView(button((all ? "IR PARA ANO " : "USAR ANO ") + ano, LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            big.dismiss();
            dlg.dismiss();
            listener.onPick(ano);
        } }));
        big.setContentView(box);
        big.show();
        if (big.getWindow() != null) {
            big.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            big.getWindow().setLayout(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.94f), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }
}
