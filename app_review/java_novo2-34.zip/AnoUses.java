package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Onde um ANO do personagem e usado (EDITAR NOS USOS): links de outros ANOs, animacoes de hitbox flag 71-125, cutscenes da flag 20 com o pack do
 * personagem (ALVO 1), projeteis e campos dos golpes do HDAT 4. Java puro (testado sem Android). Cada uso diz o ANO "host" (o que toca na previa do
 * contexto) e, quando e um campo de golpe, o golpe.
 */
final class AnoUses {
    private AnoUses() { }

    static final int LINK = 0, FLAG = 1, CUTSCENE = 2, PROJ = 3, MOVE = 4, GRAB = 5;

    static final class Use {
        final int kind;
        /** ANO que usa o alvo (no golpe: o ANIM_INICIAL dele). */
        final int host;
        /** Golpe do HDAT 4 (-1 = o ANO host sozinho ou o golpe dono dele). */
        final int move;
        /** Frame do host onde o uso aparece (-1 = desde o inicio). */
        final int pat;
        /** Evento da cutscene, flag da animacao ou -1. */
        final int ev, flag;
        /** Cutscene: o alvo e so a ANIM_FLIP (o atacante tem de estar virado para a esquerda). */
        final boolean flipped;
        /** Campo do golpe ("ANIM_SEQ_CHAO"...) ou null. */
        final String field;

        Use(int kind, int host, int move, int pat, int ev, int flag, boolean flipped, String field) {
            this.kind = kind; this.host = host; this.move = move; this.pat = pat; this.ev = ev; this.flag = flag; this.flipped = flipped; this.field = field;
        }

        /** Rotulo curto em PT (partes fixas; a tela traduz pelos pedacos de {@link #parts}). */
        String label() {
            StringBuilder b = new StringBuilder();
            for (String[] p : parts()) b.append(p[0]);
            return b.toString();
        }

        /** Pedacos do rotulo: {texto, "t"} = traduzir; {texto, ""} = nao traduzir (numeros, nomes de campo). */
        List<String[]> parts() {
            List<String[]> o = new ArrayList<String[]>();
            switch (kind) {
                case LINK: o.add(new String[] {"Link do ANO", "t"}); o.add(new String[] {" " + host, ""}); break;
                case FLAG: o.add(new String[] {"Animação da flag", "t"}); o.add(new String[] {" " + flag + " · ANO " + host + " · frame " + (pat + 1), ""}); break;
                case CUTSCENE:
                    o.add(new String[] {"Cutscene do evento", "t"});
                    o.add(new String[] {" " + ev + " · ANO " + host + " · frame " + (pat + 1), ""});
                    if (flipped) { o.add(new String[] {" · ", ""}); o.add(new String[] {"virado", "t"}); }
                    break;
                case PROJ: o.add(new String[] {"Projétil do", "t"}); o.add(new String[] {String.format(java.util.Locale.US, " GOLPE_%02d (%s)", move, field), ""}); break;
                case GRAB: o.add(new String[] {"Agarrado no", "t"}); o.add(new String[] {String.format(java.util.Locale.US, " GOLPE_%02d (%s)", move, field), ""}); break;
                default: o.add(new String[] {"Campo do", "t"}); o.add(new String[] {String.format(java.util.Locale.US, " GOLPE_%02d (%s)", move, field), ""}); break;
            }
            return o;
        }
    }

    /** Todos os usos do ANO {@code t} (pack do personagem). {@code ch} pode ser null (so links e flags). */
    static List<Use> find(CharData ch, Dac dac, int t) {
        List<Use> out = new ArrayList<Use>();
        if (dac == null || t < 0) return out;
        HashSet<String> seen = new HashSet<String>();
        for (int h = 0; h < dac.size(); h++) {
            Ano a = dac.getAno(h);
            if (a == null || !a.present) continue;
            for (Ano.Link l : a.links) {
                if (l.getAno() == t && seen.add("L" + h)) out.add(new Use(LINK, h, -1, -1, -1, -1, false, null));
            }
            for (int p = 0; p < a.mpts.length; p++) {
                for (Ano.Hit hit : a.mpts[p].hits) {
                    int f = hit.flag;
                    if (f >= 71 && f <= 125 && 201 + f - 71 == t && seen.add("F" + h + ":" + f)) out.add(new Use(FLAG, h, -1, p, -1, f, false, null));
                    if (f == 20 && ch != null && ch.hasEvent(hit.width) && ch.eventField(hit.width, CharData.EV_ALVO) == 1) {
                        int ev = hit.width, an = ch.eventField(ev, CharData.EV_ANIM), fl = ch.eventField(ev, CharData.EV_ANIM_FLIP);
                        if (an == 0) continue;                                       // sem ANIM_ID o jogo nao cria nada
                        if ((an == t || fl == t) && seen.add("C" + h + ":" + ev)) out.add(new Use(CUTSCENE, h, -1, p, ev, 20, an != t, null));
                    }
                }
            }
        }
        if (ch == null) return out;
        for (int i = 0; i < ch.moves.length; i++) {
            CharData.Move m = ch.moves[i];
            if (m == null || m.generic || m.animInicial <= 0) continue;
            int h = m.animInicial;
            String[] pn = {"PROJETIL_ANIM_NORMAL", "PROJETIL_ANIM_ABAIXO", "PROJETIL_ANIM_ACIMA", "PROJETIL_ANIM_ACERTAR_GLOBAL", "PROJETIL_ANIM_AO_ACERTAR",
                    "PROJETIL_COLISAO_CHAO", "SUBPROJETIL_ANIM_ID", "SUBPROJETIL_ANIM_AO_ACERTAR", "SUBPROJETIL_COLISAO_CHAO"};
            int[] pv = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao, m.subId, m.subAoAcertar, m.subChao};
            for (int k = 0; k < pn.length; k++) if (pv[k] > 0 && pv[k] == t) out.add(new Use(PROJ, h, i, -1, -1, -1, false, pn[k]));
            if ((m.flags & 4) != 0 && m.projNormal > 0) {
                if (m.projNormal + 1 == t) out.add(new Use(PROJ, h, i, -1, -1, -1, false, "PROJETIL_ANIM_NORMAL + 1"));
                if (m.projNormal + 2 == t) out.add(new Use(PROJ, h, i, -1, -1, -1, false, "PROJETIL_ANIM_NORMAL + 2"));
            }
            String[] mn = {"ANIM_INICIAL", "ANIM_AO_ACERTAR", "ANIM_SEQ_CHAO", "ANIM_END_CHAO", "ANIM_SEQ_AR", "ANIM_END_AR", "POUSO_AO_ERRAR", "POUSO_AO_ACERTAR"};
            int[] mv = {m.animInicial, m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr, m.animEndAr, m.pousoErrar, m.pousoAcertar};
            for (int k = 0; k < mn.length; k++) if (mv[k] > 0 && mv[k] == t) out.add(new Use(MOVE, h, i, -1, -1, -1, false, mn[k]));
            if ((m.flags & (8 | 128)) != 0 && m.animInicial + 1 == t) out.add(new Use(MOVE, h, i, -1, -1, -1, false, "ANIM_INICIAL + 1"));
            if (m.oponenteAgarrado > 0 && m.oponenteAgarrado == t) out.add(new Use(GRAB, h, i, -1, -1, -1, false, "OPONENTE_ANIM_SENDO_AGARRADO"));
        }
        return out;
    }

    /** Posicao do primeiro uso cujo host e a origem da navegacao (o ANO de onde se veio), ou -1. */
    static int originIndex(List<Use> uses, int origin) {
        if (origin < 0) return -1;
        for (int i = 0; i < uses.size(); i++) if (uses.get(i).host == origin) return i;
        return -1;
    }
}
