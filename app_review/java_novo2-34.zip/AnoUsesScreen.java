package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/**
 * EDITAR NOS USOS: grade (3 colunas) com a miniatura do ANO que usa o ANO aberto e o tipo do uso ({@link AnoUses}). O uso que veio da navegacao
 * (o ANO de origem) fica destacado. Tocar num card abre o ANO no contexto daquele uso.
 */
final class AnoUsesScreen {
    interface Pick { void on(AnoUses.Use u); }

    private AnoUsesScreen() { }

    static void show(final Activity a, AttackView view, int target, int origin, final Pick pick) {
        AttackData d = view.attackData();
        if (d == null) return;
        view.pause();
        final float den = a.getResources().getDisplayMetrics().density;
        final Dac dac = d.attacker.dac;
        SpriteCache spr = d.attacker.sprites;
        List<AnoUses.Use> uses = AnoUses.find(d.attacker.data, dac, target);
        int oi = AnoUses.originIndex(uses, origin);
        final Dialog dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(den, 10), dp(den, 12), dp(den, 10), dp(den, 10));
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(raw(a, I18n.tr("USOS DO ANO") + " " + target, 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = raw(a, "✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(den, 44), dp(den, 40)));
        root.addView(h);
        root.addView(tv(a, "Toque num uso para editar este ANO no contexto dele: a prévia toca o ANO/golpe que o usa (só para ver) e a timeline edita este ANO, começando no tick em que ele aparece.", 11, LayoutManager.DIM));
        ScrollView sv = new SafeScrollView(a);
        LinearLayout grid = new LinearLayout(a);
        grid.setOrientation(LinearLayout.VERTICAL);
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        if (uses.isEmpty()) {
            grid.addView(tv(a, "Nenhum uso: nenhum link, flag de animação, cutscene, projétil ou campo de golpe usa este ANO.", 12, LayoutManager.DIM));
        }
        int side = (a.getResources().getDisplayMetrics().widthPixels - dp(den, 20) - dp(den, 6) * 3) / 3;
        LinearLayout row = null;
        View originCard = null;
        for (int i = 0; i < uses.size(); i++) {
            if (i % 3 == 0) { row = new LinearLayout(a); grid.addView(row); }
            final AnoUses.Use u = uses.get(i);
            boolean isOrigin = i == oi;
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            card.setPadding(dp(den, 3), dp(den, 3), dp(den, 3), dp(den, 4));
            GradientDrawable g = new GradientDrawable();
            g.setColor(isOrigin ? 0x334C8DFF : LayoutManager.PANEL);
            g.setStroke(dp(den, isOrigin ? 3 : 1), isOrigin ? LayoutManager.ACCENT : 0xFF2C313C);
            g.setCornerRadius(dp(den, 8));
            card.setBackground(g);
            FrameLayout fl = new FrameLayout(a);
            Ano ha = dac.getAno(u.host);
            if (ha != null && ha.present && ha.mpts.length > 0) {
                AnimPreview pv = new AnimPreview(a);
                pv.setFirstFrameOnly(true);
                pv.set(dac, spr, u.host);
                fl.addView(pv, new FrameLayout.LayoutParams(side - dp(den, 6), side - dp(den, 6)));
            } else {
                TextView e = tv(a, "ANO vazia", 11, LayoutManager.DIM);
                e.setGravity(Gravity.CENTER);
                fl.addView(e, new FrameLayout.LayoutParams(side - dp(den, 6), side - dp(den, 6)));
            }
            TextView badge = raw(a, "ANO " + u.host, 10, 0xFFFFFFFF, true);
            badge.setBackgroundColor(0xAA000000);
            badge.setPadding(dp(den, 4), 0, dp(den, 4), 0);
            fl.addView(badge, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
            if (isOrigin) {
                TextView ob = tv(a, "ORIGEM", 10, 0xFFFFFFFF);
                ob.setTypeface(Typeface.DEFAULT_BOLD);
                ob.setBackgroundColor(LayoutManager.ACCENT);
                ob.setPadding(dp(den, 4), 0, dp(den, 4), 0);
                fl.addView(ob, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));
            }
            card.addView(fl);
            TextView lab = raw(a, labelOf(u), 10, isOrigin ? 0xFFFFFFFF : LayoutManager.TEXT, isOrigin);
            lab.setGravity(Gravity.CENTER);
            card.addView(lab);
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); pick.on(u); } });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            cp.setMargins(dp(den, 3), dp(den, 3), dp(den, 3), dp(den, 3));
            row.addView(card, cp);
            if (isOrigin) originCard = row;
        }
        if (row != null) for (int k = uses.size() % 3; k > 0 && k < 3; k++) row.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        dlg.setContentView(root);
        dlg.show();
        if (originCard != null) {
            final View oc = originCard;
            final ScrollView fsv = sv;
            sv.post(new Runnable() { public void run() { fsv.smoothScrollTo(0, Math.max(0, oc.getTop() - dp(den, 8))); } });
        }
    }

    /** Rotulo do uso com as partes fixas traduzidas. */
    static String labelOf(AnoUses.Use u) {
        StringBuilder b = new StringBuilder();
        for (String[] p : u.parts()) b.append("t".equals(p[1]) ? I18n.tr(p[0]) : p[0]);
        return b.toString();
    }

    private static int dp(float den, int v) { return Math.round(v * den); }

    private static TextView tv(Activity a, String s, int sp, int color) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private static TextView raw(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a).noTranslate();
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
