package com.zue.attackeditor;

/**
 * Zoom (RAZ) e posicao (MID) dos frames de um ANO, para o EDITAR da tela ANIM das cutscenes (Java puro, testado sem Android).
 * Mudar um valor soma a mesma diferenca em todos os frames (ou so num), sem mexer nos links nem nos outros campos.
 */
final class AnoXform {
    private AnoXform() { }

    static final int ZOOM_MIN = 1, ZOOM_MAX = 9999;

    /** {zoom X, zoom Y, X, Y} do frame {@code pat}: sem RAZ o zoom e 100 x 100; sem MID a posicao e 0, 0. Null se o frame nao existe. */
    static int[] valuesAt(Ano a, int pat) {
        if (a == null || pat < 0 || pat >= a.mpts.length) return null;
        Ano.Mpt m = a.mpts[pat];
        boolean raz = (m.flags & 0x80) != 0, mid = (m.flags & 1) != 0;
        return new int[] {raz ? m.xZoom : 100, raz ? m.yZoom : 100, mid ? m.midX : 0, mid ? m.midY : 0};
    }

    /** "Unir zoom" comeca marcado quando o zoom X e igual ao Y no frame. */
    static boolean uniteOf(Ano a, int pat) {
        int[] v = valuesAt(a, pat);
        return v == null || v[0] == v[1];
    }

    private static int clampZoom(int z) { return Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, z)); }

    /**
     * Copia do ANO com as diferencas somadas no frame {@code pat} (ou em todos, com {@code pat < 0}). Cria o MID (0, 0) e o RAZ (100 %, sem rotacao
     * nem alpha) quando o frame nao tem; tira o RAZ que ficar neutro; zoom limitado a {@link #ZOOM_MIN}..{@link #ZOOM_MAX}. Os links nao mudam.
     */
    static Ano addDelta(Ano a, int pat, int dzx, int dzy, int dx, int dy) {
        if (a == null) return null;
        Ano.Mpt[] ms = new Ano.Mpt[a.mpts.length];
        for (int i = 0; i < ms.length; i++) {
            Ano.Mpt c = a.mpts[i].copy();
            if (pat < 0 || i == pat) apply(c, dzx, dzy, dx, dy);
            ms[i] = c;
        }
        return new Ano(a.index, a.present, a.flags, a.priority, a.links, ms);
    }

    private static void apply(Ano.Mpt c, int dzx, int dzy, int dx, int dy) {
        if (dx != 0 || dy != 0) {
            if ((c.flags & 1) == 0) { c.flags |= 1; c.midX = 0; c.midY = 0; }
            c.midX += dx;
            c.midY += dy;
        }
        if (dzx != 0 || dzy != 0) {
            if ((c.flags & 0x80) == 0) { c.flags |= 0x80; c.rot = 0; c.alphaRaw = 0; c.xZoom = 100; c.yZoom = 100; }
            c.xZoom = clampZoom(c.xZoom + dzx);
            c.yZoom = clampZoom(c.yZoom + dzy);
            if (c.rot == 0 && c.alphaRaw == 0 && c.xZoom == 100 && c.yZoom == 100) { c.flags &= ~0x80; c.alpha = 255; c.razFlags = 0; }
        }
        c.normalize();
    }

    /** O ANO mudou de zoom ou posicao em algum frame (comparado com o original)? */
    static boolean differs(Ano orig, Ano cur) {
        if (orig == null || cur == null) return orig != cur;
        if (orig.mpts.length != cur.mpts.length) return true;
        for (int i = 0; i < orig.mpts.length; i++) {
            int[] a = valuesAt(orig, i), b = valuesAt(cur, i);
            for (int k = 0; k < 4; k++) if (a[k] != b[k]) return true;
        }
        return false;
    }

    /** O que mudou (para a confirmacao do SALVAR): frames mudados de {@code total} e a diferenca {dzx, dzy, dx, dy} quando e a mesma em todos eles. */
    static final class Change {
        int changed, total;
        /** Null quando os frames mudaram de jeitos diferentes. */
        int[] delta;
    }

    /** Null se nada mudou. */
    static Change change(Ano orig, Ano cur) {
        if (!differs(orig, cur)) return null;
        Change c = new Change();
        c.total = orig.mpts.length;
        boolean same = true;
        for (int i = 0; i < c.total; i++) {
            int[] a = valuesAt(orig, i), b = valuesAt(cur, i);
            int[] d = {b[0] - a[0], b[1] - a[1], b[2] - a[2], b[3] - a[3]};
            if (d[0] == 0 && d[1] == 0 && d[2] == 0 && d[3] == 0) continue;
            c.changed++;
            if (c.delta == null) c.delta = d;
            else if (c.delta[0] != d[0] || c.delta[1] != d[1] || c.delta[2] != d[2] || c.delta[3] != d[3]) same = false;
        }
        if (!same) c.delta = null;
        return c;
    }

    static String sign(int v) { return v > 0 ? "+" + v : v < 0 ? "−" + (-v) : "0"; }
}
