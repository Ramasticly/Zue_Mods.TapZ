package com.zue.attackeditor;

/** Tudo que a view precisa para montar uma batalha: atacante + golpe, oponente, effect e gamedata. */
public final class AttackData {
    public final CharAssets attacker;
    public final CharAssets opponent;
    public final CharAssets effects;   // pode ser null
    public final GameData gameData;    // pode ser null
    public final int moveIndex;
    public final CharData.Move move;
    /** charf do atacante (hitbox flags 41-70); pode ser null. */
    public CharAssets charf;
    /** bobjNN do cenario (cutscenes da flag 20 com ALVO >= 2); pode ser null. */
    public CharAssets bobj;

    public AttackData(CharAssets attacker, CharAssets opponent, CharAssets effects, GameData gameData,
                      int moveIndex) {
        this(attacker, opponent, effects, gameData, moveIndex, attacker.data.moves[moveIndex]);
    }

    /** move = golpe do HDAT 4 (ou CharData.blank(ano) quando o ANO nao e ANIM_INICIAL de nenhum golpe). */
    public AttackData(CharAssets attacker, CharAssets opponent, CharAssets effects, GameData gameData,
                      int moveIndex, CharData.Move move) {
        this.attacker = attacker;
        this.opponent = opponent;
        this.effects = effects;
        this.gameData = gameData;
        this.moveIndex = moveIndex;
        this.move = move;
    }

    /** Mesmos dados com outra game data (releitura ao voltar para o app). */
    public AttackData withGameData(GameData g) {
        AttackData d = new AttackData(attacker, opponent, effects, g, moveIndex, move);
        d.charf = charf;
        d.bobj = bobj;
        return d;
    }

    public AttackData withOpponent(CharAssets o) {
        AttackData d = new AttackData(attacker, o, effects, gameData, moveIndex, move);
        d.charf = charf;
        d.bobj = bobj;
        return d;
    }
}
