package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Escolha de ANO ou golpe: so grade (sem Spinner). Cada cartao mostra o primeiro Frame; tocar numa seleciona e toca a animacao inteira no painel
 * (sem abrir); o botao grande abre para editar. Em ANOS: EXCLUIR (esvazia), COPIAR, MOVER e COLAR, o botao (i) dos ataques e o modo selecao
 * (segurar um cartao) para excluir varias de uma vez. Em golpes: so o botao de abrir.
 */
final class AttackGrid {
    interface Host {
        boolean anoMode();
        CharAssets attacker();
        int selected();
        /** Abre o item (ANO ou golpe) para editar. */
        void open(int index);
        /** Os Frames de alguma ANO mudaram: refazer lista e o editor aberto. */
        void changed();
        /** CRIAR ANO (modo ANOS); devolve o indice criado ou -1. */
        int create();
    }

    private static final int RED = 0xFFFF6B6B, YELLOW = 0xFFFFD84C, DIMC = 0xFF6F7585;

    /** ANO copiada (fica na memoria entre aberturas da grade). */
    private static AnoOps.Clip clip;

    private final Activity a;
    private final Host host;
    private final float d;
    private Dialog dlg;
    private int sel;
    private boolean selecting;
    private final Set<Integer> picked = new HashSet<Integer>();
    private BaseAdapter adapter;
    private LinearLayout previewBox, actions;
    private TextView openBtn;
    private GridView gv;
    private PopupWindow pop;

    static void show(Activity a, Host host) { new AttackGrid(a, host).open(); }

    private AttackGrid(Activity a, Host host) {
        this.a = a; this.host = host;
        this.d = a.getResources().getDisplayMetrics().density;
        this.sel = Math.max(0, host.selected());
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, int bg, View.OnClickListener l) {
        TextView t = tv(s, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(11), dp(8), dp(11));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private int count() {
        CharAssets ca = host.attacker();
        return host.anoMode() ? ca.dac.size() : ca.data.moves.length;
    }

    /** ANO que o item mostra: ela mesma (modo ANOS) ou o ANO inicial do golpe. */
    private int anoOf(int i) { return host.anoMode() ? i : host.attacker().data.moves[i].animInicial; }

    private boolean present(int ano) {
        Ano an = host.attacker().dac.getAno(ano);
        return an != null && an.present && an.mpts.length > 0;
    }

    private void open() {
        final boolean anos = host.anoMode();
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) { if (pop != null) pop.dismiss(); }
        });

        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        final TextView title = tv(anos ? "Escolher ANO" : "Escolher golpe", 17, LayoutManager.TEXT, true);
        h.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        if (anos) {
            TextView mk = button("＋ CRIAR ANO", 0xFF3DDC84, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
                int n = host.create();
                if (n >= 0) { sel = n; adapter.notifyDataSetChanged(); gv.setSelection(Math.max(0, n - 4)); refreshPanel(); }
            } });
            h.addView(mk);
        }
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        TextView hint = tv(anos ? "Toque numa ANO para ver a animação aqui; segure para marcar várias e excluir." : "Toque num golpe para ver a animação aqui.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(6));
        root.addView(hint);

        gv = new GridView(a);
        gv.setNumColumns(4);
        gv.setVerticalSpacing(dp(6));
        gv.setHorizontalSpacing(dp(6));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return count(); }
            @Override public Object getItem(int i) { return Integer.valueOf(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(final int i, View cv, ViewGroup parent) { return card(i); }
        };
        gv.setAdapter(adapter);
        root.addView(gv, new LinearLayout.LayoutParams(-1, 0, 1f));

        previewBox = new LinearLayout(a);
        previewBox.setOrientation(LinearLayout.HORIZONTAL);
        previewBox.setGravity(Gravity.CENTER);
        root.addView(previewBox, new LinearLayout.LayoutParams(-1, -2));

        openBtn = button("", LayoutManager.TEXT, LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            int i = sel;
            dlg.dismiss();
            host.open(i);
        } });
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-1, -2);
        ol.setMargins(0, dp(6), 0, dp(4));
        root.addView(openBtn, ol);

        actions = new LinearLayout(a);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        dlg.show();
        gv.setSelection(Math.max(0, sel - 4));
        refreshPanel();
    }

    // ---------------------------------------------------------------- cartao

    private View card(final int i) {
        final CharAssets ca = host.attacker();
        final boolean anos = host.anoMode();
        final int ano = anoOf(i);
        boolean ok = present(ano);
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(selecting && picked.contains(Integer.valueOf(i)) ? 0xFF3A2430 : LayoutManager.PANEL);
        g.setCornerRadius(dp(8));
        if (selecting ? picked.contains(Integer.valueOf(i)) : i == sel) g.setStroke(dp(2), selecting ? RED : LayoutManager.ACCENT);
        cell.setBackground(g);
        cell.setPadding(dp(3), dp(3), dp(3), dp(3));
        int side = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(18)) / 4 - dp(6);
        FrameLayout fl = new FrameLayout(a);
        if (ok) {
            AnimPreview pv = new AnimPreview(a);
            pv.setFirstFrameOnly(true);
            pv.set(ca.dac, ca.sprites, ano, false);
            pv.setClickable(false);
            fl.addView(pv, new FrameLayout.LayoutParams(side, side));
        } else {
            TextView e = tv("vazio", 10, 0xFF4A505E, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            fl.addView(e, new FrameLayout.LayoutParams(side, side));
        }
        if (anos && AttackInfo.describe(ca.data, ano) != null) {
            final TextView info = tv("ⓘ", 16, LayoutManager.ACCENT, true);
            info.setGravity(Gravity.CENTER);
            info.setBackgroundColor(0x99000000);
            info.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showInfo(v, ano); } });
            fl.addView(info, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP | Gravity.END));
        }
        cell.addView(fl);
        int kind = anos ? ca.anoKinds()[Math.min(i, ca.anoKinds().length - 1)] : CharAssets.KIND_ATTACK;
        String label = anos ? String.valueOf(i) : String.format(java.util.Locale.US, "GOLPE_%02d", i);
        TextView n = tv(label, anos ? 12 : 11, !ok ? DIMC : kind == CharAssets.KIND_ATTACK && anos ? RED : kind == CharAssets.KIND_PROJECTILE ? YELLOW : LayoutManager.TEXT, true);
        n.setGravity(Gravity.CENTER);
        cell.addView(n);
        if (!anos) {
            TextView s = tv("ANO " + ano, 10, LayoutManager.DIM, false);
            s.setGravity(Gravity.CENTER);
            cell.addView(s);
        }
        cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            if (selecting) { toggle(i); return; }
            sel = i;
            adapter.notifyDataSetChanged();
            refreshPanel();
        } });
        if (anos) cell.setOnLongClickListener(new View.OnLongClickListener() { public boolean onLongClick(View v) {
            if (!selecting) { selecting = true; picked.clear(); }
            toggle(i);
            return true;
        } });
        return cell;
    }

    private void toggle(int i) {
        Integer k = Integer.valueOf(i);
        if (!picked.remove(k)) picked.add(k);
        if (picked.isEmpty()) selecting = false;
        adapter.notifyDataSetChanged();
        refreshPanel();
    }

    // ---------------------------------------------------------------- painel de baixo

    private void refreshPanel() {
        final boolean anos = host.anoMode();
        previewBox.removeAllViews();
        actions.removeAllViews();
        if (selecting) {
            openBtn.setVisibility(View.GONE);
            TextView t = tv(picked.size() + " ANO(s) marcada(s)", 13, LayoutManager.TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(6), 0, dp(6));
            previewBox.addView(t, new LinearLayout.LayoutParams(-1, -2));
            actions.addView(button("EXCLUIR (" + picked.size() + ")", RED, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
                List<Integer> l = new ArrayList<Integer>(picked);
                Collections.sort(l);
                confirmClear(l, new Runnable() { public void run() { selecting = false; picked.clear(); refreshAll(); } });
            } }), cell());
            actions.addView(button("CANCELAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
                selecting = false; picked.clear(); adapter.notifyDataSetChanged(); refreshPanel();
            } }), cell());
            return;
        }
        openBtn.setVisibility(View.VISIBLE);
        int ano = anoOf(sel);
        openBtn.setText("➜  " + (anos ? "ABRIR ANO " + sel : String.format(java.util.Locale.US, "ABRIR GOLPE_%02d", sel)));
        // animacao completa do selecionado, tocando aqui mesmo (sem abrir)
        CharAssets ca = host.attacker();
        if (present(ano)) {
            AnimPreview pv = new AnimPreview(a);
            pv.set(ca.dac, ca.sprites, ano, false);
            int side = Math.min(dp(190), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.26f));
            previewBox.addView(pv, new LinearLayout.LayoutParams(side, side));
        } else {
            TextView e = tv("ANO vazia", 12, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            previewBox.addView(e, new LinearLayout.LayoutParams(-1, dp(60)));
        }
        if (!anos) return;
        actions.addView(button("EXCLUIR", RED, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            List<Integer> l = new ArrayList<Integer>();
            l.add(Integer.valueOf(sel));
            confirmClear(l, new Runnable() { public void run() { refreshAll(); } });
        } }), cell());
        actions.addView(button("COPIAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            AnoOps.Clip c = AnoOps.copy(host.attacker().dac, sel);
            if (c == null) { I18nUi.toast(a, "A ANO " + sel + " está vazia", android.widget.Toast.LENGTH_SHORT).show(); return; }
            clip = c;
            I18nUi.toast(a, "ANO " + sel + " copiada (" + c.mpts.length + " frame(s))", android.widget.Toast.LENGTH_SHORT).show();
            refreshPanel();
        } }), cell());
        actions.addView(button("MOVER", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { chooseMoveTarget(); } }), cell());
        TextView paste = button("COLAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { confirmPaste(); } });
        paste.setEnabled(clip != null);
        paste.setAlpha(clip != null ? 1f : 0.4f);
        actions.addView(paste, cell());
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private void refreshAll() {
        adapter.notifyDataSetChanged();
        refreshPanel();
    }

    // ---------------------------------------------------------------- acoes

    private void confirmClear(final List<Integer> anos, final Runnable done) {
        final CharAssets ca = host.attacker();
        final List<Integer> filled = AnoOps.nonEmpty(ca.dac, anos);
        if (filled.isEmpty()) { I18nUi.toast(a, "Nada a excluir: " + (anos.size() == 1 ? "a ANO já está vazia" : "as ANOs já estão vazias"), android.widget.Toast.LENGTH_SHORT).show(); return; }
        String warn = AnoOps.warning(ca.dac, ca.data, filled);
        String msg = "Os Frames " + (filled.size() == 1 ? "da ANO " + filled.get(0) : "de " + filled.size() + " ANOs") + " são apagados. A ANO continua existindo, só fica vazia."
                + (warn.isEmpty() ? "" : "\n\nAtenção:\n" + warn);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(warn.isEmpty() ? "Excluir?" : "Excluir mesmo assim?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("EXCLUIR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    for (Integer an : filled) AnoOps.clear(ca.dac, an.intValue());
                    ca.invalidateKinds();
                    host.changed();
                    done.run();
                } }).show();
    }

    private void confirmPaste() {
        if (clip == null) return;
        final CharAssets ca = host.attacker();
        final int to = sel;
        List<Integer> one = new ArrayList<Integer>();
        one.add(Integer.valueOf(to));
        String warn = AnoOps.warning(ca.dac, ca.data, AnoOps.nonEmpty(ca.dac, one));
        String msg = "Os Frames copiados da ANO " + clip.fromIndex + " (" + clip.mpts.length + " frame(s)) vão para a ANO " + to + ", no lugar do que ela tem."
                + (warn.isEmpty() ? "" : "\n\nAtenção, a ANO " + to + " vai ser sobrescrita:\n" + warn);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(warn.isEmpty() ? "Colar?" : "Colar mesmo assim?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("COLAR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    AnoOps.paste(ca.dac, to, clip);
                    ca.invalidateKinds();
                    host.changed();
                    refreshAll();
                } }).show();
    }

    private void chooseMoveTarget() {
        final CharAssets ca = host.attacker();
        if (AnoOps.isEmpty(ca.dac, sel)) { I18nUi.toast(a, "A ANO " + sel + " está vazia", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final List<Integer> targets = new ArrayList<Integer>();
        List<String> labels = new ArrayList<String>();
        for (int i = 0; i < ca.dac.size(); i++) {
            if (i == sel) continue;
            targets.add(Integer.valueOf(i));
            labels.add("ANO " + i + (AnoOps.isEmpty(ca.dac, i) ? "  (vazia)" : "  (" + ca.dac.getAno(i).mpts.length + " frame(s))"));
        }
        if (targets.isEmpty()) return;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Mover a ANO " + sel + " para…")
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int which) {
                    confirmMove(targets.get(which).intValue());
                } }).setNegativeButton("CANCELAR", null).show();
    }

    private void confirmMove(final int to) {
        final CharAssets ca = host.attacker();
        final int from = sel;
        List<Integer> both = new ArrayList<Integer>();
        both.add(Integer.valueOf(from));
        List<Integer> dst = new ArrayList<Integer>();
        dst.add(Integer.valueOf(to));
        String warn = AnoOps.warning(ca.dac, ca.data, both) + AnoOps.warning(ca.dac, ca.data, AnoOps.nonEmpty(ca.dac, dst));
        String msg = "Os Frames da ANO " + from + " vão para a ANO " + to + " (o que ela tinha é apagado) e a ANO " + from + " fica vazia. Links de outras ANOs e golpes que apontam para a ANO " + from + " não são atualizados."
                + (warn.isEmpty() ? "" : "\n\nAtenção:\n" + warn);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(warn.isEmpty() ? "Mover?" : "Mover mesmo assim?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("MOVER", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    if (AnoOps.move(ca.dac, from, to)) {
                        ca.invalidateKinds();
                        sel = to;
                        host.changed();
                        refreshAll();
                        gv.setSelection(Math.max(0, to - 4));
                    }
                } }).show();
    }

    // ---------------------------------------------------------------- (i)

    private void showInfo(View anchor, int ano) {
        String text = AttackInfo.describe(host.attacker().data, ano);
        if (text == null) return;
        if (pop != null) pop.dismiss();
        TextView t = tv(text, 12, LayoutManager.TEXT, false);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2C313C);
        g.setStroke(dp(1), LayoutManager.ACCENT);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        int maxW = Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.72f);
        t.setMaxWidth(maxW);
        pop = new PopupWindow(t, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        pop.setOutsideTouchable(true);
        pop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        t.measure(View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST), View.MeasureSpec.UNSPECIFIED);
        boolean right = loc[0] + anchor.getWidth() + t.getMeasuredWidth() < sw;       // ao lado do botao: a direita se couber, senao a esquerda
        int x = right ? loc[0] + anchor.getWidth() : Math.max(0, loc[0] - t.getMeasuredWidth());
        int y = Math.max(dp(8), Math.min(loc[1], a.getResources().getDisplayMetrics().heightPixels - t.getMeasuredHeight() - dp(16)));
        pop.showAtLocation(gv, Gravity.NO_GRAVITY, x, y);
    }
}
