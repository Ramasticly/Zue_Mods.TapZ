package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Escolha de ANO ou golpe: so grade (sem Spinner). Switch GOLPES | ANOS no topo. Cada cartao mostra o primeiro Frame; tocar numa seleciona e toca a animacao
 * inteira no painel (com pouso, loop ou trava de 1 s e a box de hit/projetil), sem abrir; o botao grande abre para editar. Em ANOS: CRIAR ANO, EXCLUIR (esvazia),
 * COPIAR, MOVER e COLAR, o filtro (reordena sem esconder), o botao (i) e o modo selecao (segurar um cartao) para excluir varias.
 */
final class AttackGrid {
    interface Host {
        boolean anoMode();
        CharAssets attacker();
        int selected();
        /** Abre o item (ANO ou golpe) para editar. */
        void open(int index);
        /** Os Frames de alguma ANO mudaram: refazer lista e o editor aberto. */
        void changed();
        /** CRIAR ANO (modo ANOS); devolve o indice criado ou -1. */
        int create();
        /** Ver Fluxo (modo GOLPES): carrega o golpe e abre o fluxo dele so para visualizar. */
        void showFlow(int move);
        /** Troca GOLPES / ANOS (o mesmo que o chip ANOS da tela principal). */
        void setAnoMode(boolean ano);
        /** effect.pac (icones dos botoes), ou null. */
        CharAssets effectAssets();
    }

    private static final int RED = 0xFFFF6B6B, YELLOW = 0xFFFFD84C, DIMC = 0xFF6F7585, GREEN = 0xFF3DDC84, CODE_BLUE = 0xFF6CB4FF;

    /** ANO copiada (fica na memoria entre aberturas da grade). */
    private static AnoOps.Clip clip;

    /** Golpe copiado: a linha do HDAT 4 (copia) e o personagem de origem; so cola no MESMO personagem carregado (para outro, SALVAR > outro personagem). */
    private static final class MoveClip {
        final CharAssets owner;
        final CharData.Move move;
        final int index;
        MoveClip(CharAssets owner, CharData.Move move, int index) { this.owner = owner; this.move = move; this.index = index; }
    }
    private static MoveClip moveClip;
    /** Filtro escolhido (fica entre aberturas da grade). */
    private static int filterMode = AnoFilter.DEFAULT;

    private final Activity a;
    private final Host host;
    private final float d;
    private Dialog dlg;
    private int sel;
    private boolean selecting;
    private final Set<Integer> picked = new HashSet<Integer>();
    private BaseAdapter adapter;
    private LinearLayout previewBox, actions, filterRow;
    private TextView openBtn, filterBtn, swGolpes, swAnos, title;
    private GridView gv;
    private FrameLayout frame;
    private View scrim, bubble;
    private List<Integer> order = new ArrayList<Integer>();
    private AnoFilter.Result fres;

    static void show(Activity a, Host host) { new AttackGrid(a, host).open(); }

    private AttackGrid(Activity a, Host host) {
        this.a = a; this.host = host;
        this.d = a.getResources().getDisplayMetrics().density;
        this.sel = Math.max(0, host.selected());
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, int bg, View.OnClickListener l) {
        TextView t = tv(s, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(11), dp(6), dp(11));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private void paint(TextView t, int bg, int fg) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setTextColor(fg);
    }

    private boolean anos() { return host.anoMode(); }

    private int count() {
        CharAssets ca = host.attacker();
        return anos() ? ca.dac.size() : ca.data.moves.length;
    }

    /** ANO que o item mostra: ela mesma (modo ANOS) ou o ANO inicial do golpe. */
    private int anoOf(int i) { return anos() ? i : host.attacker().data.moves[i].animInicial; }

    private boolean present(int ano) {
        Ano an = host.attacker().dac.getAno(ano);
        return an != null && an.present && an.mpts.length > 0;
    }

    /** Refaz a ordem dos cartoes (filtro no modo ANOS; numerica em golpes). */
    private void reorder() {
        order = new ArrayList<Integer>();
        fres = null;
        CharAssets ca = host.attacker();
        if (anos()) {
            fres = AnoFilter.apply(filterMode, ca.dac, ca.data);
            order.addAll(fres.order);
        } else {
            for (int i = 0; i < count(); i++) order.add(Integer.valueOf(i));
        }
    }

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        frame = new FrameLayout(a);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        dlg.setContentView(frame);

        // topo: switch GOLPES | ANOS e fechar
        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        swGolpes = button("GOLPES", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { switchMode(false); } });
        swAnos = button("ANOS", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { switchMode(true); } });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -2, 1f);
        sl.setMargins(0, 0, dp(4), 0);
        h.addView(swGolpes, sl);
        h.addView(swAnos, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);

        filterRow = new LinearLayout(a);
        filterRow.setOrientation(LinearLayout.HORIZONTAL);
        filterRow.setGravity(Gravity.CENTER_VERTICAL);
        filterBtn = button("", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            filterMode = (filterMode + 1) % AnoFilter.NAMES.length;
            updateFilterLabel();
            reorder();
            adapter.notifyDataSetChanged();
            gv.setSelection(Math.max(0, order.indexOf(Integer.valueOf(sel)) - 4));
            refreshPanel();
        } });
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-2, -2);
        fl.setMargins(0, dp(6), dp(8), dp(2));
        filterRow.addView(filterBtn, fl);
        title = tv("", 11, LayoutManager.DIM, false);
        filterRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(filterRow);

        gv = new GridView(a);
        gv.setNumColumns(4);
        gv.setVerticalSpacing(dp(6));
        gv.setHorizontalSpacing(dp(6));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return order.size(); }
            @Override public Object getItem(int p) { return order.get(p); }
            @Override public long getItemId(int p) { return order.get(p).intValue(); }
            @Override public View getView(int p, View cv, ViewGroup parent) { return card(order.get(p).intValue()); }
        };
        gv.setAdapter(adapter);
        root.addView(gv, new LinearLayout.LayoutParams(-1, 0, 1f));

        previewBox = new LinearLayout(a);
        previewBox.setOrientation(LinearLayout.HORIZONTAL);
        previewBox.setGravity(Gravity.CENTER);
        root.addView(previewBox, new LinearLayout.LayoutParams(-1, -2));

        openBtn = button("", LayoutManager.TEXT, LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            int i = sel;
            dlg.dismiss();
            host.open(i);
        } });
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-1, -2);
        ol.setMargins(0, dp(6), 0, dp(4));
        root.addView(openBtn, ol);

        actions = new LinearLayout(a);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        dlg.show();
        rebuild();
    }

    /** Troca GOLPES / ANOS e refaz a grade. */
    private void switchMode(boolean ano) {
        if (anos() == ano) return;
        dismissInfo();
        selecting = false;
        picked.clear();
        host.setAnoMode(ano);
        sel = Math.max(0, host.selected());
        rebuild();
    }

    private void rebuild() {
        dismissInfo();
        boolean an = anos();
        paint(swGolpes, an ? LayoutManager.PANEL_HI : LayoutManager.ACCENT, LayoutManager.TEXT);
        paint(swAnos, an ? LayoutManager.ACCENT : LayoutManager.PANEL_HI, LayoutManager.TEXT);
        sel = Math.min(Math.max(0, sel), Math.max(0, count() - 1));
        reorder();
        updateFilterLabel();
        filterBtn.setVisibility(an ? View.VISIBLE : View.GONE);
        title.setText(an ? "Toque numa ANO para ver a animação; segure para marcar várias e excluir." : "Toque num golpe para ver a animação.");
        adapter.notifyDataSetChanged();
        gv.setSelection(Math.max(0, order.indexOf(Integer.valueOf(sel)) - 4));
        refreshPanel();
    }

    private void updateFilterLabel() { filterBtn.setText("FILTRAR: " + AnoFilter.NAMES[filterMode]); }

    // ---------------------------------------------------------------- cartao

    private View card(final int i) {
        final CharAssets ca = host.attacker();
        final boolean anos = anos();
        final int ano = anoOf(i);
        boolean ok = present(ano);
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable g = new GradientDrawable();
        boolean pickedNow = selecting && picked.contains(Integer.valueOf(i));
        g.setColor(pickedNow ? 0xFF3A2430 : LayoutManager.PANEL);
        g.setCornerRadius(dp(8));
        boolean framed = anos && fres != null && filterMode != AnoFilter.DEFAULT && i < fres.matched.length && fres.matched[i];
        if (selecting ? pickedNow : i == sel) g.setStroke(dp(2), selecting ? RED : LayoutManager.ACCENT);
        else if (framed) g.setStroke(dp(2), GREEN);
        cell.setBackground(g);
        cell.setPadding(dp(3), dp(3), dp(3), dp(3));
        int side = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(18)) / 4 - dp(6);
        FrameLayout fl = new FrameLayout(a);
        if (ok) {
            AnimPreview pv = new AnimPreview(a);
            pv.setFirstFrameOnly(true);
            pv.set(ca.dac, ca.sprites, ano, false);
            pv.setClickable(false);
            fl.addView(pv, new FrameLayout.LayoutParams(side, side));
        } else {
            TextView e = tv("vazio", 10, 0xFF4A505E, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            fl.addView(e, new FrameLayout.LayoutParams(side, side));
        }
        final boolean hasInfo = anos ? AttackInfo.anoInfo(ca.data, ano) != null : AttackInfo.moveInfo(ca.data, i) != null;
        if (hasInfo) {
            final TextView info = tv("ⓘ", 16, LayoutManager.ACCENT, true);
            info.setGravity(Gravity.CENTER);
            info.setBackgroundColor(0x99000000);
            info.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showInfo(v, i); } });
            fl.addView(info, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP | Gravity.END));
        }
        cell.addView(fl);
        int kind = anos ? ca.anoKinds()[Math.min(i, ca.anoKinds().length - 1)] : CharAssets.KIND_ATTACK;
        String label = anos ? String.valueOf(i) : String.format(java.util.Locale.US, "GOLPE_%02d", i);
        TextView n = tv(label, anos ? 12 : 11, !ok ? DIMC : kind == CharAssets.KIND_ATTACK && anos ? RED : kind == CharAssets.KIND_PROJECTILE ? YELLOW : LayoutManager.TEXT, true);
        n.setGravity(Gravity.CENTER);
        cell.addView(n);
        if (!anos) {
            TextView s = tv("ANO " + ano, 10, LayoutManager.DIM, false);
            s.setGravity(Gravity.CENTER);
            cell.addView(s);
        }
        cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            if (scrim != null) { dismissInfo(); return; }
            if (selecting) { toggle(i); return; }
            sel = i;
            adapter.notifyDataSetChanged();
            refreshPanel();
        } });
        if (anos) cell.setOnLongClickListener(new View.OnLongClickListener() { public boolean onLongClick(View v) {
            if (scrim != null) return true;
            if (!selecting) { selecting = true; picked.clear(); }
            toggle(i);
            return true;
        } });
        return cell;
    }

    private void toggle(int i) {
        Integer k = Integer.valueOf(i);
        if (!picked.remove(k)) picked.add(k);
        if (picked.isEmpty()) selecting = false;
        adapter.notifyDataSetChanged();
        refreshPanel();
    }

    // ---------------------------------------------------------------- painel de baixo

    private void refreshPanel() {
        final boolean anos = anos();
        previewBox.removeAllViews();
        actions.removeAllViews();
        if (selecting) {
            openBtn.setVisibility(View.GONE);
            TextView t = tv(picked.size() + " ANO(s) marcada(s)", 13, LayoutManager.TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(6), 0, dp(6));
            previewBox.addView(t, new LinearLayout.LayoutParams(-1, -2));
            actions.addView(button("EXCLUIR (" + picked.size() + ")", RED, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
                List<Integer> l = new ArrayList<Integer>(picked);
                Collections.sort(l);
                confirmClear(l, new Runnable() { public void run() { selecting = false; picked.clear(); refreshAll(); } });
            } }), cell());
            actions.addView(button("CANCELAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
                selecting = false; picked.clear(); adapter.notifyDataSetChanged(); refreshPanel();
            } }), cell());
            return;
        }
        openBtn.setVisibility(View.VISIBLE);
        int ano = anoOf(sel);
        openBtn.setText("➜  " + (anos ? "ABRIR ANO " + sel : String.format(java.util.Locale.US, "ABRIR GOLPE_%02d", sel)));
        CharAssets ca = host.attacker();
        if (present(ano)) {
            AnimPreview pv = new AnimPreview(a);
            Ano an = ca.dac.getAno(ano);
            pv.set(ca.dac, ca.sprites, ano, false);
            // loop nas ANOs com wActFlag 1; as outras tocam uma vez, travam no ultimo Frame por 1 s e recomecam
            if (!ObjModel.loops(an.mpts)) { pv.setPlayUntil(-1); pv.setAutoReplay(true); }
            if (AnoFilter.hasAttackBox(an)) pv.setShowHits(true);
            CharData.Move own = ca.data.ownerOf(ano);
            if (anos ? own != null && !own.generic && own.animInicial == ano : !ca.data.moves[sel].generic) {
                CharData.Move mv = anos ? own : ca.data.moves[sel];
                if (hasYMove(an)) pv.setLanding(ca.dac.getAno(mv.pousoErrar) != null && ca.dac.getAno(mv.pousoErrar).present && mv.pousoErrar != 0 ? mv.pousoErrar : FixedAnos.STANDARD_LANDING);
            }
            int side = Math.min(dp(190), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.26f));
            previewBox.addView(pv, new LinearLayout.LayoutParams(side, side));
        } else {
            TextView e = tv("ANO vazia", 12, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            previewBox.addView(e, new LinearLayout.LayoutParams(-1, dp(60)));
        }
        if (!anos) { moveActions(); return; }
        actions.addView(button("＋ CRIAR", GREEN, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            int n = host.create();
            if (n >= 0) { sel = n; reorder(); adapter.notifyDataSetChanged(); gv.setSelection(Math.max(0, order.indexOf(Integer.valueOf(n)) - 4)); refreshPanel(); }
        } }), cell());
        actions.addView(button("EXCLUIR", RED, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            List<Integer> l = new ArrayList<Integer>();
            l.add(Integer.valueOf(sel));
            confirmClear(l, new Runnable() { public void run() { refreshAll(); } });
        } }), cell());
        actions.addView(button("COPIAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            AnoOps.Clip c = AnoOps.copy(host.attacker().dac, sel);
            if (c == null) { I18nUi.toast(a, "A ANO " + sel + " está vazia", android.widget.Toast.LENGTH_SHORT).show(); return; }
            clip = c;
            I18nUi.toast(a, "ANO " + sel + " copiada (" + c.mpts.length + " frame(s))", android.widget.Toast.LENGTH_SHORT).show();
            refreshPanel();
        } }), cell());
        actions.addView(button("MOVER", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { chooseMoveTarget(); } }), cell());
        TextView paste = button("COLAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { confirmPaste(); } });
        paste.setEnabled(clip != null);
        paste.setAlpha(clip != null ? 1f : 0.4f);
        actions.addView(paste, cell());
    }

    // ---------------------------------------------------------------- golpes: Ver Fluxo | Copiar | Colar | Trocar

    private void moveActions() {
        final CharAssets ca = host.attacker();
        final boolean empty = ca.data.moves[sel].generic || ca.data.moves[sel].animInicial <= 0;
        TextView flowBtn = button("VER FLUXO", CODE_BLUE, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            dlg.dismiss();
            host.showFlow(sel);
        } });
        flowBtn.setEnabled(!empty);
        flowBtn.setAlpha(empty ? 0.4f : 1f);
        actions.addView(flowBtn, cell());
        TextView copyBtn = button("COPIAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) {
            CharData.Move m = ca.data.moves[sel];
            if (m.animInicial <= 0) { I18nUi.toast(a, "O golpe " + String.format(java.util.Locale.US, "%02d", sel) + " está vazio", android.widget.Toast.LENGTH_SHORT).show(); return; }
            moveClip = new MoveClip(ca, m.copy(), sel);
            I18nUi.toast(a, String.format(java.util.Locale.US, "GOLPE_%02d copiado (%d ANO(s))", sel, MoveTransplant.anosToCopy(ca.dac, m).size()), android.widget.Toast.LENGTH_SHORT).show();
            refreshPanel();
        } });
        copyBtn.setEnabled(!empty);
        copyBtn.setAlpha(empty ? 0.4f : 1f);
        actions.addView(copyBtn, cell());
        final boolean canPaste = moveClip != null && moveClip.owner == ca;
        TextView pasteBtn = button("COLAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { confirmPasteMove(); } });
        pasteBtn.setEnabled(canPaste);
        pasteBtn.setAlpha(canPaste ? 1f : 0.4f);
        actions.addView(pasteBtn, cell());
        actions.addView(button("TROCAR", LayoutManager.TEXT, LayoutManager.PANEL_HI, new View.OnClickListener() { public void onClick(View v) { chooseSwapTarget(); } }), cell());
    }

    private static String moveName(int i) { return String.format(java.util.Locale.US, "GOLPE_%02d", i); }

    private void confirmPasteMove() {
        final MoveClip mc = moveClip;
        final CharAssets ca = host.attacker();
        if (mc == null || mc.owner != ca) return;
        final int to = sel;
        if (!MoveTransplant.canReplace(mc.index, to)) {
            I18nUi.toast(a, moveName(mc.index) + " não pode ser colado sobre " + moveName(to) + ": os golpes 0, 3 e 6 só substituem o próprio número.", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        int n = MoveTransplant.anosToCopy(ca.dac, mc.move).size();
        String msg = "O " + moveName(mc.index) + " copiado vai para o lugar do " + moveName(to) + " (a linha dele no Bin é trocada; o que ele tinha deixa de ser usado por ele).\n\n"
                + "• " + n + " ANO(s) entram como ANOs novas no fim do DAC (a partir do ANO " + ca.dac.size() + "), com os números do Bin e os links ajustados.\n"
                + "• Reações do personagem: igual a uma que já existe, usa ela; senão vão para um slot vazio; sem slot vazio você escolhe qual substituir.\n"
                + "• Os sprites são os mesmos (mesmo personagem). Sons do personagem e hitbox flags 20 e 41-125 continuam os do personagem.\n\n"
                + "Isto altera só o que está na memória; SALVAR grava (os ANOs novos entram no 000.dac.txt).";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Colar o golpe?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("COLAR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) { pasteMove(mc, ca, to); } }).show();
    }

    private void pasteMove(final MoveClip mc, final CharAssets ca, final int to) {
        java.util.Set<Integer> writable = null;
        java.io.File binTxt = new java.io.File(ca.dir, "000.bin.txt");
        if (binTxt.isFile()) { try { writable = Saver.writableReactionSlots(Saver.readText(binTxt)); } catch (Exception ignored) { } }
        final java.util.Set<Integer> wr = writable;
        final ArrayList<Integer> ask = new ArrayList<Integer>(MoveTransplant.needsChoice(ca.dac, ca.data, mc.move, ca.dac, ca.data, wr));
        nextPasteReaction(mc, ca, to, wr, ask, 0, new java.util.HashMap<Integer, MoveTransplant.Choice>());
    }

    private void nextPasteReaction(final MoveClip mc, final CharAssets ca, final int to, final java.util.Set<Integer> wr, final ArrayList<Integer> ask, final int at,
                                   final java.util.HashMap<Integer, MoveTransplant.Choice> choices) {
        if (at >= ask.size()) { finishPasteMove(mc, ca, to, wr, choices); return; }
        final Integer type = ask.get(at);
        ReactionReplaceScreen.show(a, ca, type.intValue(), ca, new ReactionReplaceScreen.Listener() {
            @Override public void onChoice(MoveTransplant.Choice choice) {
                choices.put(type, choice);
                nextPasteReaction(mc, ca, to, wr, ask, at + 1, choices);
            }
            @Override public void onCancel() { }
        });
    }

    private void finishPasteMove(MoveClip mc, CharAssets ca, int to, java.util.Set<Integer> wr, java.util.Map<Integer, MoveTransplant.Choice> choices) {
        try {
            MoveTransplant.Plan p = MoveTransplant.build(ca.dac, ca.data, mc.move, ca.dac, ca.data, MoveTransplant.KEEP_IMAGES, wr, choices);
            MoveTransplant.applyInMemory(p, ca.dac, ca.data, to);
            ca.invalidateKinds();
            host.changed();
            refreshAll();
            String first = p.anos.isEmpty() ? "" : " (ANOs " + p.anos.get(0).index + " a " + p.anos.get(p.anos.size() - 1).index + ")";
            StringBuilder w = new StringBuilder();
            for (String s : p.warnings) w.append("• ").append(s).append('\n');
            if (w.length() > 0) {
                new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Golpe colado com avisos").setMessage(moveName(to) + " colado" + first + ".\n\n" + w).setPositiveButton("OK", null).show();
            } else {
                I18nUi.toast(a, moveName(to) + " colado" + first + ". Salve para gravar.", android.widget.Toast.LENGTH_LONG).show();
            }
        } catch (java.io.IOException e) {
            I18nUi.toast(a, "Não deu para colar: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void chooseSwapTarget() {
        final CharAssets ca = host.attacker();
        final List<Integer> targets = new ArrayList<Integer>();
        List<String> labels = new ArrayList<String>();
        for (int i = 0; i < ca.data.moves.length; i++) {
            if (!MoveSwap.canSwap(ca.data, sel, i)) continue;
            targets.add(Integer.valueOf(i));
            labels.add(moveName(i) + (ca.data.moves[i].animInicial <= 0 ? "  (vazio)" : "  (ANO " + ca.data.moves[i].animInicial + ")"));
        }
        if (targets.isEmpty()) {
            I18nUi.toast(a, moveName(sel) + " não tem com quem trocar (os golpes 0, 3 e 6 só trocam de lugar com eles mesmos).", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Trocar o " + moveName(sel) + " com…")
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int which) {
                    confirmSwap(targets.get(which).intValue());
                } }).setNegativeButton("CANCELAR", null).show();
    }

    private void confirmSwap(final int other) {
        final CharAssets ca = host.attacker();
        final int me = sel;
        String msg = "Troca as linhas do " + moveName(me) + " e do " + moveName(other) + " no Bin (HDAT 4). Os ANOs e as reações não mudam: só o número do golpe muda, e com ele o comando que o dispara "
                + "(Y 0/3/6, X 1/4/7, B 2/5/8, Z 9/10, IRA 11/12, Rage 14/15; os golpes 9 a 12 têm a trava cinemática).\n\n"
                + "Salve os dois golpes (SALVAR › todos os golpes) para gravar o Bin.";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Trocar?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("TROCAR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    if (MoveSwap.swap(ca.data, me, other)) {
                        ca.invalidateKinds();
                        host.changed();
                        refreshAll();
                        I18nUi.toast(a, moveName(me) + " e " + moveName(other) + " trocados. Salve para gravar.", android.widget.Toast.LENGTH_LONG).show();
                    }
                } }).show();
    }

    /** A ANO muda velocidade ou aceleracao vertical (pode sair do chao e pousar)? */
    private static boolean hasYMove(Ano an) {
        for (Ano.Mpt m : an.mpts) {
            if ((m.moveMask & 2) != 0 && m.speedY != 0) return true;
            if ((m.moveMask & 8) != 0 && m.accelY != 0) return true;
        }
        return false;
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private void refreshAll() {
        reorder();
        adapter.notifyDataSetChanged();
        refreshPanel();
    }

    // ---------------------------------------------------------------- acoes

    private void confirmClear(final List<Integer> anos, final Runnable done) {
        final CharAssets ca = host.attacker();
        final List<Integer> filled = AnoOps.nonEmpty(ca.dac, anos);
        if (filled.isEmpty()) { I18nUi.toast(a, "Nada a excluir: " + (anos.size() == 1 ? "a ANO já está vazia" : "as ANOs já estão vazias"), android.widget.Toast.LENGTH_SHORT).show(); return; }
        String warn = AnoOps.warning(ca.dac, ca.data, filled);
        String msg = "Os Frames " + (filled.size() == 1 ? "da ANO " + filled.get(0) : "de " + filled.size() + " ANOs") + " são apagados. A ANO continua existindo, só fica vazia."
                + (warn.isEmpty() ? "" : "\n\nAtenção:\n" + warn);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(warn.isEmpty() ? "Excluir?" : "Excluir mesmo assim?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("EXCLUIR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    for (Integer an : filled) AnoOps.clear(ca.dac, an.intValue());
                    ca.invalidateKinds();
                    host.changed();
                    done.run();
                } }).show();
    }

    private void confirmPaste() {
        if (clip == null) return;
        final CharAssets ca = host.attacker();
        final int to = sel;
        List<Integer> one = new ArrayList<Integer>();
        one.add(Integer.valueOf(to));
        String warn = AnoOps.warning(ca.dac, ca.data, AnoOps.nonEmpty(ca.dac, one));
        String msg = "Os Frames copiados da ANO " + clip.fromIndex + " (" + clip.mpts.length + " frame(s)) vão para a ANO " + to + ", no lugar do que ela tem."
                + (warn.isEmpty() ? "" : "\n\nAtenção, a ANO " + to + " vai ser sobrescrita:\n" + warn);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(warn.isEmpty() ? "Colar?" : "Colar mesmo assim?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("COLAR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    AnoOps.paste(ca.dac, to, clip);
                    ca.invalidateKinds();
                    host.changed();
                    refreshAll();
                } }).show();
    }

    private void chooseMoveTarget() {
        final CharAssets ca = host.attacker();
        if (AnoOps.isEmpty(ca.dac, sel)) { I18nUi.toast(a, "A ANO " + sel + " está vazia", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final List<Integer> targets = new ArrayList<Integer>();
        List<String> labels = new ArrayList<String>();
        for (int i = 0; i < ca.dac.size(); i++) {
            if (i == sel) continue;
            targets.add(Integer.valueOf(i));
            labels.add("ANO " + i + (AnoOps.isEmpty(ca.dac, i) ? "  (vazia)" : "  (" + ca.dac.getAno(i).mpts.length + " frame(s))"));
        }
        if (targets.isEmpty()) return;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Mover a ANO " + sel + " para…")
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int which) {
                    confirmMove(targets.get(which).intValue());
                } }).setNegativeButton("CANCELAR", null).show();
    }

    private void confirmMove(final int to) {
        final CharAssets ca = host.attacker();
        final int from = sel;
        List<Integer> both = new ArrayList<Integer>();
        both.add(Integer.valueOf(from));
        List<Integer> dst = new ArrayList<Integer>();
        dst.add(Integer.valueOf(to));
        String warn = AnoOps.warning(ca.dac, ca.data, both) + AnoOps.warning(ca.dac, ca.data, AnoOps.nonEmpty(ca.dac, dst));
        String msg = "Os Frames da ANO " + from + " vão para a ANO " + to + " (o que ela tinha é apagado) e a ANO " + from + " fica vazia. Links de outras ANOs e golpes que apontam para a ANO " + from + " não são atualizados."
                + (warn.isEmpty() ? "" : "\n\nAtenção:\n" + warn);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(warn.isEmpty() ? "Mover?" : "Mover mesmo assim?").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("MOVER", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                    if (AnoOps.move(ca.dac, from, to)) {
                        ca.invalidateKinds();
                        sel = to;
                        host.changed();
                        refreshAll();
                        gv.setSelection(Math.max(0, order.indexOf(Integer.valueOf(to)) - 4));
                    }
                } }).show();
    }

    // ---------------------------------------------------------------- (i)

    private void dismissInfo() {
        if (frame == null) return;
        if (scrim != null) { frame.removeView(scrim); scrim = null; }
        if (bubble != null) { frame.removeView(bubble); bubble = null; }
    }

    /**
     * Texto flutuante ao lado do botao. Uma camada transparente cobre a grade: o toque que fecha o texto e consumido ali e nao chega ao cartao de baixo.
     * No modo GOLPES o texto vem com o icone do botao (renderizado do effect.pac).
     */
    private void showInfo(View anchor, int item) {
        dismissInfo();
        CharAssets ca = host.attacker();
        final boolean anos = anos();
        List<AttackInfo.Line> lines = anos ? AttackInfo.anoLines(ca.data, anoOf(item)) : AttackInfo.moveLines(ca.data, item);
        if (lines.isEmpty()) return;
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(10), dp(8), dp(12), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2C313C);
        g.setStroke(dp(1), LayoutManager.ACCENT);
        g.setCornerRadius(dp(10));
        box.setBackground(g);
        AttackInfo.Button bt = anos ? null : AttackInfo.button(item);
        CharAssets eff = host.effectAssets();
        if (bt != null && bt.hudAno >= 0 && eff != null && eff.dac != null && eff.dac.getAno(bt.hudAno) != null && eff.dac.getAno(bt.hudAno).present) {
            AnimPreview ic = new AnimPreview(a);
            ic.setFirstFrameOnly(true);
            ic.set(eff.dac, eff.sprites, bt.hudAno, false);
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(dp(54), dp(54));
            il.setMargins(0, 0, dp(10), 0);
            box.addView(ic, il);
        }
        // cores: azul = fixo no codigo-fonte do jogo, verde = vem do BIN ou de outra fonte. O texto e traduzido linha a linha (texto com cor nao passa pelo TextView traduzido).
        android.text.SpannableStringBuilder sp = new android.text.SpannableStringBuilder();
        for (int k = 0; k < lines.size(); k++) {
            AttackInfo.Line ln = lines.get(k);
            String tx = I18n.lang() == I18n.PT ? ln.text : I18n.tr(ln.text);
            int st = sp.length();
            sp.append(tx);
            int col = ln.src == AttackInfo.CODE ? CODE_BLUE : ln.src == AttackInfo.BIN ? GREEN : LayoutManager.TEXT;
            sp.setSpan(new android.text.style.ForegroundColorSpan(col), st, sp.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (k + 1 < lines.size()) sp.append('\n');
        }
        TextView t = tv("", 12, LayoutManager.TEXT, false);
        t.setText(sp);
        box.addView(t);
        final int maxW = Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.78f);
        t.setMaxWidth(maxW - dp(90));
        scrim = new View(a);
        scrim.setBackgroundColor(0x33000000);
        scrim.setClickable(true);
        scrim.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dismissInfo(); } });
        frame.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        bubble = box;
        box.measure(View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST), View.MeasureSpec.UNSPECIFIED);
        int[] fl = new int[2], al = new int[2];
        frame.getLocationOnScreen(fl);
        anchor.getLocationOnScreen(al);
        int ax = al[0] - fl[0], ay = al[1] - fl[1];
        boolean right = ax + anchor.getWidth() + box.getMeasuredWidth() < frame.getWidth();     // ao lado do botao: a direita se couber, senao a esquerda
        int x = right ? ax + anchor.getWidth() : Math.max(0, ax - box.getMeasuredWidth());
        int y = Math.max(dp(8), Math.min(ay, frame.getHeight() - box.getMeasuredHeight() - dp(16)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.leftMargin = x;
        lp.topMargin = y;
        frame.addView(box, lp);
    }
}
