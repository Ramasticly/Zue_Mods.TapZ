package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Texto do botao (i) de uma ANO de ataque: qual comando do jogo dispara o golpe e quais ANOs vem em seguida sozinhas.
 * O numero do golpe (GOLPE_n do HDAT 4) e o SpecialType do jogo; o codigo de comando vem de CmdCheck (ver a secao 15.1 da ajuda para IA).
 * Os botoes da tela sao identificados pelas ANOs do HUD: Especial 1 = 339/341, Especial 2 = 27/28/41/45; A/Y/X/B (209, 330, 333, 336) disparam
 * os golpes normais, que usam ANOs fixos 29 a 39 do jogo e nao passam pelo HDAT 4. Java puro.
 */
final class AttackInfo {
    private AttackInfo() { }

    /** Nome do comando que dispara o golpe {@code n} (linha do HDAT 4), ou null se nenhum comando o dispara. */
    static String command(int n) {
        switch (n) {
            case 0: return "Especial 1 (botão Especial 1, ANO 339/341 do HUD) — no chão";
            case 3: return "Especial 1 (botão Especial 1, ANO 339/341 do HUD) — pulando ou caindo";
            case 6: return "Especial 1 (botão Especial 1, ANO 339/341 do HUD) — voando";
            case 1: return "Especial 2 (botão Especial 2, ANOs 27/28/41/45 do HUD) — no chão";
            case 4: return "Especial 2 (botão Especial 2, ANOs 27/28/41/45 do HUD) — pulando ou caindo";
            case 7: return "Especial 2 (botão Especial 2, ANOs 27/28/41/45 do HUD) — voando";
            case 2: return "Especial 3 (atalho de Especial 3) — no chão";
            case 5: return "Especial 3 (atalho de Especial 3) — pulando ou caindo";
            case 8: return "Especial 3 (atalho de Especial 3) — voando";
            case 9: return "Ultimate (comando 8, atalho de Ultimate) — no chão ou voando";
            case 10: return "Ultimate (comando 8, atalho de Ultimate) — pulando";
            case 11: return "Super Ultimate (comando 9, atalho de Super Ultimate) — no chão ou voando";
            case 12: return "Super Ultimate (comando 9, atalho de Super Ultimate) — pulando";
            case 14: return "Rage (comando 4) — no chão";
            case 15: return "Rage (comando 4) — voando";
            case 16: return "Rage alternativo (comando 23) — no chão";
            case 17: return "Rage alternativo (comando 23) — no ar";
            default: return null;
        }
    }

    private static final String[] FIELD_NAMES = {"ao acertar", "sequência no chão (SEQ)", "fim no chão (END)", "sequência no ar (SEQ)", "fim no ar (END)",
            "pouso ao errar", "pouso ao acertar", "oponente agarrado"};

    private static int[] fields(CharData.Move m) {
        return new int[]{m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr, m.animEndAr, m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado};
    }

    /** Linhas de "sequências automáticas" do golpe (vazio se nao tem). */
    static List<String> sequences(CharData.Move m) {
        List<String> out = new ArrayList<String>();
        int[] f = fields(m);
        for (int i = 0; i < f.length; i++) if (f[i] != 0) out.add(FIELD_NAMES[i] + " → ANO " + f[i]);
        int[] pj = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao};
        StringBuilder b = new StringBuilder();
        java.util.TreeSet<Integer> seen = new java.util.TreeSet<Integer>();
        for (int p : pj) if (p != 0 && seen.add(Integer.valueOf(p))) b.append(b.length() == 0 ? "" : ", ").append(p);
        if (b.length() > 0) out.add("projétil → ANO " + b);
        return out;
    }

    /** Papel da ANO {@code ano} no golpe {@code m} (alem de ser o ANO inicial), ou null. */
    static String role(CharData.Move m, int ano) {
        if (m.animInicial == ano) return "ANO inicial";
        int[] f = fields(m);
        for (int i = 0; i < f.length; i++) if (f[i] == ano && ano != 0) return FIELD_NAMES[i];
        int[] pj = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao, m.subId, m.subAoAcertar, m.subChao};
        for (int p : pj) if (p == ano && ano != 0) return "projétil";
        return null;
    }

    /** O texto do (i); null se nenhum golpe do HDAT 4 usa a ANO. */
    static String describe(CharData cd, int ano) {
        if (cd == null) return null;
        StringBuilder b = new StringBuilder();
        int shown = 0;
        for (int pass = 0; pass < 2; pass++) {
            for (int n = 0; n < cd.moves.length; n++) {
                CharData.Move m = cd.moves[n];
                if (m.generic) continue;
                boolean initial = m.animInicial == ano;
                if (pass == 0 ? !initial : (initial || role(m, ano) == null)) continue;
                if (shown++ > 0) b.append("\n\n");
                String name = String.format(java.util.Locale.US, "GOLPE_%02d", n);
                if (initial) {
                    String cmd = command(n);
                    b.append(name).append('\n');
                    b.append(cmd != null ? "Ativado por: " + cmd : "Nenhum comando do jogo dispara este golpe (linha " + n + " do HDAT 4).");
                } else {
                    b.append(name).append(" — esta ANO é ").append(role(m, ano)).append('\n');
                    String cmd = command(n);
                    b.append(cmd != null ? "O golpe é ativado por: " + cmd : "Nenhum comando do jogo dispara este golpe (linha " + n + " do HDAT 4).");
                }
                List<String> seq = sequences(m);
                if (!seq.isEmpty()) {
                    b.append("\nSequências automáticas:");
                    for (String s : seq) b.append("\n• ").append(s);
                } else b.append("\nSem sequências automáticas.");
            }
        }
        return shown == 0 ? null : b.toString();
    }
}
