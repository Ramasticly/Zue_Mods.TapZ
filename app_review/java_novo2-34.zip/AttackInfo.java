package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Textos do botao (i) da grade. O numero do golpe (GOLPE_n do HDAT 4) e o SpecialType do jogo; os comandos vem do CmdCheck e os botoes do
 * CreateGamepad (pad do tipo 4: a tecla e a mascara do 6o argumento de AddPad). Botoes: A (HUD 209, 16640) golpes normais; Y (330, 1048576) comando 1;
 * X (333, 2097152) comando 2; B (336, 4194304) comando 3; Z (339, 8388608) comando 8 (100 de Synchro); IRA (45, canto, 553648128) comando 9 com AngryOn
 * (200 de Synchro) ou Rage (comando 4) sem AngryOn. Java puro.
 */
final class AttackInfo {
    private AttackInfo() { }

    /** Botao da tela: nome, ANO do icone no effect.pac (-1 = sem icone) e o gesto de joystick equivalente em setas. */
    static final class Button {
        final String name;
        final int hudAno;
        final String stick;
        Button(String name, int hudAno, String stick) { this.name = name; this.hudAno = hudAno; this.stick = stick; }
    }

    static final int HUD_A = 209, HUD_Y = 330, HUD_X = 333, HUD_B = 336, HUD_Z = 339, HUD_IRA = 45;

    /** Botao que dispara o golpe {@code n}, ou null se nenhum comando o dispara. */
    static Button button(int n) {
        switch (n) {
            case 0: case 3: case 6: return new Button("Y", HUD_Y, "↓ →");
            case 1: case 4: case 7: return new Button("X", HUD_X, "→ ↓");
            case 2: case 5: case 8: return new Button("B", HUD_B, "↓ ←");
            case 9: case 10: return new Button("Z", HUD_Z, "↓ → →");
            case 11: case 12: return new Button("IRA", HUD_IRA, "↓ ← ↓ ←");
            case 14: case 15: return new Button("IRA", HUD_IRA, null);
            default: return null;
        }
    }

    /** Em que estado do personagem o golpe {@code n} sai. */
    static String where(int n) {
        switch (n) {
            case 0: case 1: case 2: case 14: return "no chão";
            case 3: case 4: case 5: case 10: case 12: return "pulando ou caindo";
            case 6: case 7: case 8: case 15: return "voando";
            case 9: case 11: return "no chão ou voando";
            default: return "";
        }
    }

    /** Condicao extra do botao (Synchro / AngryOn), ou "". */
    static String cost(int n) {
        switch (n) {
            case 9: case 10: return "100 de Synchro (1 barra de ki)";
            case 11: case 12: return "AngryOn ligado e 200 de Synchro";
            case 14: case 15: return "Angry em 100 ou mais e AngryOn desligado";
            default: return "";
        }
    }

    private static final String[] FIELD_NAMES = {"ao acertar", "SEQ", "END", "SEQ (ar)", "END (ar)", "pouso ao errar", "pouso ao acertar", "oponente agarrado"};

    private static int[] fields(CharData.Move m) {
        return new int[]{m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr, m.animEndAr, m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado};
    }

    /** Linhas das sequencias automaticas do golpe (vazio se nao tem). */
    static List<String> sequences(CharData.Move m) {
        List<String> out = new ArrayList<String>();
        int[] f = fields(m);
        for (int i = 0; i < f.length; i++) if (f[i] != 0) out.add(FIELD_NAMES[i] + " → ANO " + f[i]);
        int[] pj = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao};
        java.util.TreeSet<Integer> seen = new java.util.TreeSet<Integer>();
        StringBuilder b = new StringBuilder();
        for (int p : pj) if (p != 0 && seen.add(Integer.valueOf(p))) b.append(b.length() == 0 ? "" : ", ").append(p);
        if (b.length() > 0) out.add("projétil → ANO " + b);
        return out;
    }

    /** Texto do golpe {@code n} (modo GOLPES): nome, botao e sequencias. O icone do botao e desenhado pela tela. */
    static String moveInfo(CharData cd, int n) {
        if (cd == null || n < 0 || n >= cd.moves.length) return null;
        CharData.Move m = cd.moves[n];
        StringBuilder b = new StringBuilder(String.format(java.util.Locale.US, "GOLPE_%02d", n));
        Button bt = button(n);
        if (bt != null) {
            b.append("\nBotão ").append(bt.name);
            String w = where(n);
            if (!w.isEmpty()) b.append(" — ").append(w);
            if (bt.stick != null) b.append("\nou joystick: ").append(bt.stick);
            String c = cost(n);
            if (!c.isEmpty()) b.append("\nUsa: ").append(c);
        } else b.append("\nNenhum botão dispara este golpe (linha ").append(n).append(" do HDAT 4).");
        List<String> seq = sequences(m);
        if (!seq.isEmpty()) {
            b.append("\nSequências automáticas:");
            for (String s : seq) b.append("\n• ").append(s);
        }
        return b.toString();
    }

    /** Papel curto da ANO {@code ano} no golpe {@code n}, ou null. */
    static String role(CharData.Move m, int n, int ano) {
        if (ano == 0) return null;
        String no = String.valueOf(n);
        if (m.animInicial == ano) return "ANIM_INICIAL do Golpe " + no;
        if (m.animSeqChao == ano) return "SEQ do golpe " + no;
        if (m.animSeqAr == ano) return "SEQ (ar) do golpe " + no;
        if (m.animEndChao == ano) return "END do golpe " + no;
        if (m.animEndAr == ano) return "END (ar) do golpe " + no;
        if (m.animAoAcertar == ano) return "Ao acertar do golpe " + no;
        if (m.pousoErrar == ano) return "Animação de pouso do golpe " + no;
        if (m.pousoAcertar == ano) return "Animação de pouso (ao acertar) do golpe " + no;
        if (m.oponenteAgarrado == ano) return "Oponente agarrado do golpe " + no;
        int[] pj = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao, m.subId, m.subAoAcertar, m.subChao};
        for (int p : pj) if (p == ano) return "Projétil do golpe " + no;
        return null;
    }

    /** O texto simples do (i) de uma ANO (modo ANOS); null se nao ha nada a dizer. Sem botoes: eles so aparecem na info do golpe. */
    static String anoInfo(CharData cd, int ano) {
        List<String> lines = new ArrayList<String>();
        if (cd != null) {
            for (int n = 0; n < cd.moves.length; n++) {
                CharData.Move m = cd.moves[n];
                if (m.generic) continue;
                String r = role(m, n, ano);
                if (r != null && !lines.contains(r)) lines.add(r);
            }
        }
        String fixed = FixedAnos.name(ano);
        if (fixed != null) {
            lines.add(fixed);
            if (FixedAnos.hasComboWindow(ano)) lines.add("Janela de combo (OPT 512): o próximo A continua a sequência");
        }
        if (lines.isEmpty()) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) b.append(i == 0 ? "" : "\n").append(lines.get(i));
        return b.toString();
    }
}
