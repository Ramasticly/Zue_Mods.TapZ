package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Textos do botao (i) da grade. O numero do golpe (GOLPE_n do HDAT 4) e o SpecialType do jogo; os comandos vem do CmdCheck e os botoes do
 * CreateGamepad (pad do tipo 4: a tecla e a mascara do 6o argumento de AddPad). Botoes: A (HUD 209, 16640) golpes normais; Y (330, 1048576) comando 1;
 * X (333, 2097152) comando 2; B (336, 4194304) comando 3; Z (339, 8388608) comando 8 (100 de Synchro); IRA (45, canto, 553648128) comando 9 com AngryOn
 * (200 de Synchro) ou Rage (comando 4) sem AngryOn. Java puro.
 */
final class AttackInfo {
    private AttackInfo() { }

    /** Botao da tela: nome, ANO do icone no effect.pac (-1 = sem icone) e o gesto de joystick equivalente em setas. */
    static final class Button {
        final String name;
        final int hudAno;
        final String stick;
        Button(String name, int hudAno, String stick) { this.name = name; this.hudAno = hudAno; this.stick = stick; }
    }

    static final int HUD_A = 209, HUD_Y = 330, HUD_X = 333, HUD_B = 336, HUD_Z = 339, HUD_IRA = 45;

    /** Botao que dispara o golpe {@code n}, ou null se nenhum comando o dispara. */
    static Button button(int n) {
        switch (n) {
            case 0: case 3: case 6: return new Button("Y", HUD_Y, "↓ → + A");
            case 1: case 4: case 7: return new Button("X", HUD_X, "→ ↓ + A");
            case 2: case 5: case 8: return new Button("B", HUD_B, "↓ ← + A");
            case 9: case 10: return new Button("Z", HUD_Z, "↓ ← → + A");
            case 11: case 12: return new Button("IRA", HUD_IRA, "↓ ← ↓ ← + A");
            case 14: case 15: return new Button("IRA", HUD_IRA, null);
            default: return null;
        }
    }

    /** Em que estado do personagem o golpe {@code n} sai. */
    static String where(int n) {
        switch (n) {
            case 0: case 1: case 2: case 14: return "no chão";
            case 3: case 4: case 5: case 10: case 12: return "pulando ou caindo";
            case 6: case 7: case 8: case 15: return "voando";
            case 9: case 11: return "no chão ou voando";
            default: return "";
        }
    }

    /** Condicao extra do botao (Synchro / AngryOn), ou "". */
    static String cost(int n) {
        switch (n) {
            case 9: case 10: return "100 de Synchro (1 barra de ki)";
            case 11: case 12: return "AngryOn ligado e 200 de Synchro";
            case 14: case 15: return "Angry em 100 ou mais e AngryOn desligado";
            default: return "";
        }
    }

    /** De onde vem a informacao de uma linha: texto simples, fixo no codigo-fonte do jogo (azul) ou do BIN / outra fonte (verde). */
    static final int PLAIN = 0, CODE = 1, BIN = 2, RED = 3, DIM = 4;

    static final class Line {
        final String text;
        final int src;
        Line(String text, int src) { this.text = text; this.src = src; }
    }

    private static String join(List<Line> l) {
        if (l.isEmpty()) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.size(); i++) b.append(i == 0 ? "" : "\n").append(l.get(i).text);
        return b.toString();
    }

    /** Sequencias do BIN do golpe (verde): SEQ e END no chao e no ar, SEQ PROJ (ANIM_AO_ACERTAR) e agarrao. Pouso nao entra. */
    static List<String> binSequences(CharData.Move m) {
        List<String> out = new ArrayList<String>();
        if (m.animSeqChao != 0) out.add("SEQ (chão) → ANO " + m.animSeqChao);
        if (m.animEndChao != 0) out.add("END (chão) → ANO " + m.animEndChao);
        if (m.animSeqAr != 0) out.add("SEQ (ar) → ANO " + m.animSeqAr);
        if (m.animEndAr != 0) out.add("END (ar) → ANO " + m.animEndAr);
        if (m.animAoAcertar != 0) out.add("SEQ PROJ → ANO " + m.animAoAcertar);
        if (m.oponenteAgarrado != 0) out.add("agarrão (oponente agarrado) → ANO " + m.oponenteAgarrado);
        return out;
    }

    /** Sequencias fixas no codigo do jogo para o golpe {@code n} (azul, com "(automática)"). */
    static List<String> codeSequences(CharData.Move m, int n) {
        List<String> out = new ArrayList<String>();
        if (m.repeats(n)) out.add("repetição → ANO 42, alterna 40/41 (automática)");
        if (m.grabWorks()) out.add("agarrão → ANO " + (m.animInicial + 1) + " (automática)");
        return out;
    }

    /** Linhas do golpe {@code n} (modo GOLPES). O icone do botao e desenhado pela tela. */
    static List<Line> moveLines(CharData cd, int n) {
        List<Line> out = new ArrayList<Line>();
        if (cd == null || n < 0 || n >= cd.moves.length) return out;
        CharData.Move m = cd.moves[n];
        out.add(new Line(String.format(java.util.Locale.US, "GOLPE_%02d", n), PLAIN));
        Button bt = button(n);
        if (bt != null) {
            String w = where(n);
            out.add(new Line("Botão " + bt.name + (w.isEmpty() ? "" : " — " + w), CODE));
            if (bt.stick != null) out.add(new Line("ou joystick: " + bt.stick, CODE));
            String c = cost(n);
            if (!c.isEmpty()) out.add(new Line("Usa: " + c, CODE));
        } else out.add(new Line("Nenhum botão dispara este golpe (linha " + n + " do HDAT 4).", CODE));
        List<String> bin = binSequences(m), code = codeSequences(m, n);
        if (!bin.isEmpty() || !code.isEmpty()) {
            out.add(new Line("Sequências:", PLAIN));
            for (String s : bin) out.add(new Line("• " + s, BIN));
            for (String s : code) out.add(new Line("• " + s, CODE));
        }
        return out;
    }

    /** Texto do golpe (sem cores). */
    static String moveInfo(CharData cd, int n) { return join(moveLines(cd, n)); }

    /** Papel curto da ANO {@code ano} no golpe {@code n}, ou null. */
    static String role(CharData.Move m, int n, int ano) {
        if (ano == 0) return null;
        String no = String.valueOf(n);
        if (m.animInicial == ano) return "ANIM_INICIAL do Golpe " + no;
        if (m.animSeqChao == ano) return "SEQ do golpe " + no;
        if (m.animSeqAr == ano) return "SEQ (ar) do golpe " + no;
        if (m.animEndChao == ano) return "END do golpe " + no;
        if (m.animEndAr == ano) return "END (ar) do golpe " + no;
        if (m.animAoAcertar == ano) return "SEQ PROJ do golpe " + no;
        if (m.pousoErrar == ano) return "Animação de pouso do golpe " + no;
        if (m.pousoAcertar == ano) return "Animação de pouso (ao acertar) do golpe " + no;
        if (m.oponenteAgarrado == ano) return "Oponente agarrado do golpe " + no;
        int[] pj = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao, m.subId, m.subAoAcertar, m.subChao};
        for (int p : pj) if (p == ano) return "Projétil do golpe " + no;
        return null;
    }

    /** Linhas da ANO (modo ANOS): papel no BIN (verde) e o que o codigo do jogo faz com ela (azul). Sem botoes. */
    static List<Line> anoLines(CharData cd, int ano) {
        List<Line> out = new ArrayList<Line>();
        if (cd != null) {
            for (int n = 0; n < cd.moves.length; n++) {
                CharData.Move m = cd.moves[n];
                if (m.generic) continue;
                String r = role(m, n, ano);
                if (r != null) {
                    boolean dup = false;
                    for (Line l : out) if (l.text.equals(r)) dup = true;
                    if (!dup) out.add(new Line(r, BIN));
                }
            }
        }
        List<Line> notes = AnoNotes.lines(ano);                       // notas manuais (AnoNotes); sem nota, o nome antigo de FixedAnos
        if (!notes.isEmpty()) out.addAll(notes);
        else {
            String fixed = FixedAnos.name(ano);
            if (fixed != null) out.add(new Line(fixed, CODE));
        }
        if (FixedAnos.isNormalAttack(ano)) {
            int from = FixedAnos.comesFrom(ano);
            if (from != 0) out.add(new Line("Vem da ANO " + from + " (janela de combo)", CODE));
            String[][] cont = FixedAnos.continuations(ano);
            if (cont.length == 0) out.add(new Line("Sem continuação", CODE));
            else {
                out.add(new Line("Sequência (automática, janela OPT 512 — depende do comando):", CODE));
                for (String[] c : cont) out.add(new Line("• " + c[0] + " → ANO " + c[1], CODE));
            }
        }
        return out;
    }

    /** Texto da ANO (sem cores); null se nao ha nada a dizer. */
    static String anoInfo(CharData cd, int ano) { return join(anoLines(cd, ano)); }
}
