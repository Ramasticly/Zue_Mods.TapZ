package com.zue.attackeditor;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;

/**
 * Desenha um {@link AttackSim} seguindo o DrawExec/DrawImage do jogo.
 * O Canvas deve chegar com (0,0) = origem do mundo e 1 unidade = 1 pixel logico.
 */
public final class AttackRenderer {
    public static final class Options {
        public boolean showHits;
        /** >= 0: desenha so a ocorrencia {@code onlyHitOcc} (n-esima com essa flag) das boxes do objeto raiz; as demais somem. */
        public int onlyHitFlag = -1, onlyHitOcc;
        public boolean showLinks;
        /** Ancoras (CHAR OBJ): sprite (amarelo), hurtbox (azul), hitbox (vermelho), efeitos/animacoes (cinza). */
        public boolean anchorSpr, anchorHurt, anchorHit, anchorFx, anchorGlobal, anchorProj;
        /** Modo "Ancora e Box": contorno da box + linha da ponta da ancora ate a borda (so quando a ancora esta fora da box). */
        public boolean anchorBox;
        /** Pixels de tela por pixel logico (para manter tracos finos independentes do zoom). */
        public float pixelScale = 1f;
    }

    private static final int COLOR_HURT = 0xFF4CA6FF;
    private static final int COLOR_HIT = 0xFFFF4C4C;
    private static final int COLOR_OTHER = 0xFFFFC94C;
    private static final int COLOR_LINK = 0xFF7CFFB2;

    private final Paint sprite = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint fill = new Paint();
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Xfermode additive = new PorterDuffXfermode(PorterDuff.Mode.ADD);
    private final RectF dst = new RectF();
    private final AttackSim.Obj[] order = new AttackSim.Obj[AttackSim.MAX_LINKS + 1];

    public AttackRenderer() {
        sprite.setAntiAlias(false);
        stroke.setStyle(Paint.Style.STROKE);
        fill.setStyle(Paint.Style.FILL);
    }

    public void draw(Canvas c, AttackSim sim, SpriteCache sprites, Options o) {
        drawSim(c, sim, sprites);
        drawOverlay(c, sim, o);
    }

    /** Sprites de uma simulacao (cada camada usa o cache do seu dono). */
    public void drawSim(Canvas c, AttackSim sim, SpriteCache sprites) {
        if (sim == null || sim.root() == null || sprites == null) return;
        int n = sim.fillDrawOrder(order);
        for (int i = 0; i < n; i++) drawObj(c, order[i], sprites);
    }

    /** Uma camada de BattleSim.layers(): so o objeto indicado, ou a simulacao inteira. */
    public void drawLayer(Canvas c, BattleSim.Layer l, SpriteCache sprites) {
        if (l.only == null) { drawSim(c, l.sim, sprites); return; }
        if (sprites == null || l.sim == null || l.sim.root() == null) return;
        drawObj(c, l.only, sprites);
    }

    /** Acumula em {@code out} (coords do mundo) o retangulo ocupado pelos sprites desta simulacao no frame atual. */
    public void accumBounds(AttackSim sim, SpriteCache sprites, RectF out, boolean[] any) {
        if (sim == null || sim.root() == null || sprites == null) return;
        int n = sim.fillDrawOrder(order);
        for (int i = 0; i < n; i++) {
            AttackSim.Obj o = order[i];
            if (o.img < 0) continue;
            if ((o.objFlags & 1) != 0 || (o.parent != null && (o.parent.objFlags & 1) != 0)) continue;
            SpriteCache.Sprite s = sprites.get(o.img);
            if (s == null) continue;
            int flip = o.actFlags & 48;
            if (o.parent != null) {
                if ((o.parent.objFlags & 16) != 0) flip ^= 16;
                if ((o.parent.objFlags & 32) != 0) flip ^= 32;
            } else flip ^= (o.objFlags & 16) ^ (o.objFlags & 32);
            boolean fh = (flip & 16) != 0, fv = (flip & 32) != 0;
            int zo = (o.parent != null) ? o.parent.zoomObj : o.zoomObj;
            int zx = o.xZoom * zo / 100, zy = o.yZoom * zo / 100;
            if (zx == 0 || zy == 0) continue;
            int a = o.alpha;
            if (a == 0 && (o.actFlags & 2048) == 0) { /* desenha opaco */ }
            else if (a <= 0) continue;
            float wf = s.drawWidth * zx / 100f, hf = s.drawHeight * zy / 100f;
            int offX = zo * o.ox / 100, offY = zo * o.oy / 100, bx = o.bx, by = o.by;
            if (fh) { offX = -offX; bx = -bx; }
            if (fv) { offY = -offY; by = -by; }
            float l = (fh ? -s.logicalWidth * zx / 100 : 0) + bx + offX;
            float t = (fv ? -s.logicalHeight * zy / 100 : 0) + by + offY;
            float px = o.x / 65536f, py = o.y / 65536f;
            float x0 = l, y0 = t, x1 = l + wf, y1 = t + hf;
            if (o.rot != 0) {                       // gira em torno da ancora: usa o raio maximo
                float m = (float) Math.sqrt(Math.max(Math.max(x0 * x0, x1 * x1) + Math.max(y0 * y0, y1 * y1), 0));
                x0 = -m; y0 = -m; x1 = m; y1 = m;
            }
            x0 += px; x1 += px; y0 += py; y1 += py;
            if (!any[0]) { out.set(x0, y0, x1, y1); any[0] = true; }
            else out.union(x0, y0, x1, y1);
        }
    }

    /** Hitboxes e links de uma simulacao. */
    public void drawOverlay(Canvas c, AttackSim sim, Options o) { drawOverlay(c, sim, o, 0); }

    /** kind: 0 corpo/projetil, 1 animacao do personagem, 2 efeito global (ver BattleSim.Layer.kind). */
    public void drawOverlay(Canvas c, AttackSim sim, Options o, int kind) {
        if (sim == null || sim.root() == null) return;
        int n = sim.fillDrawOrder(order);
        if (o.showHits) for (int i = 0; i < n; i++) drawHits(c, order[i], o.pixelScale, o.onlyHitFlag, o.onlyHitOcc);
        if (o.showLinks) drawLinks(c, order, n, o.pixelScale);
        if (o.anchorSpr || o.anchorHurt || o.anchorHit || o.anchorFx)
            drawAnchors(c, order, n, o, (kind == 0 || kind == 3) ? o.anchorSpr : kind == 1 && o.anchorFx, kind == 1 ? 0xFFA0A4AC : 0xFFFFE04C);
    }

    private final android.graphics.Path leafPath = new android.graphics.Path();

    /** Ponto em forma de folha: circulo com uma pontinha apontando para (dx, dy), a direcao do objeto ancorado aqui. */
    private void leaf(Canvas c, float x, float y, float dx, float dy, int color, float ps) { leaf(c, x, y, dx, dy, color, ps, true); }

    private void leaf(Canvas c, float x, float y, float dx, float dy, int color, float ps, boolean withTip) {
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.001f) { dx = 1; dy = 1; len = 1.4142f; }
        float ux = dx / len, uy = dy / len;
        for (int pass = 0; pass < 2; pass++) {
            // tamanho em unidades do mundo: cresce junto com o zoom da preview (minimo de ~2 px de tela para nao sumir de longe)
            float k0 = Math.max(1.5f, 2.5f / Math.max(0.01f, ps));
            float r = (pass == 0 ? 1.4f : 1f) * k0, tip = (pass == 0 ? 3.7f : 3.2f) * k0;
            float px = -uy, py = ux;                       // perpendicular
            float k = r * 0.8f;                            // onde a pontinha sai do circulo
            fill.setColor(pass == 0 ? 0xFF000000 : color);
            if (withTip) {
                leafPath.reset();
                leafPath.moveTo(x + ux * tip, y + uy * tip);
                leafPath.lineTo(x + ux * k * 0.6f + px * r * 0.8f, y + uy * k * 0.6f + py * r * 0.8f);
                leafPath.lineTo(x + ux * k * 0.6f - px * r * 0.8f, y + uy * k * 0.6f - py * r * 0.8f);
                leafPath.close();
                c.drawPath(leafPath, fill);
            }
            c.drawCircle(x, y, r, fill);
        }
    }

    /** Sprites usados para achar o retangulo (box) dos sprites no modo Ancora e Box; o AttackView troca por camada. */
    public SpriteCache anchorSprites;

    /**
     * Ancora em (px, py) com box (l,t,r,b) no mesmo referencial. Modo "Apenas Ancora" (ou sem box): folha apontando para (defDx, defDy).
     * Modo "Ancora e Box": contorno da box; ancora fora dela = folha apontando para o centro + linha da ponta ate a borda mais proxima
     * na direcao do centro (nunca ate o centro); ancora dentro = ponto redondo, sem linha.
     */
    private void anchorMark(Canvas c, float px, float py, boolean hasBox, float l, float t, float r, float b, int color, float defDx, float defDy, Options o) {
        float ps = o.pixelScale;
        if (!o.anchorBox || !hasBox || r <= l || b <= t) { leaf(c, px, py, defDx, defDy, color, ps); return; }
        stroke.setColor(color);
        stroke.setStrokeWidth(1f / ps);
        c.drawRect(l, t, r, b, stroke);
        if (px >= l && px <= r && py >= t && py <= b) { leaf(c, px, py, 0, 0, color, ps, false); return; }
        float dx = (l + r) / 2f - px, dy = (t + b) / 2f - py;
        float inf = Float.MAX_VALUE;
        float tx1 = dx == 0 ? -inf : (l - px) / dx, tx2 = dx == 0 ? inf : (r - px) / dx;
        float ty1 = dy == 0 ? -inf : (t - py) / dy, ty2 = dy == 0 ? inf : (b - py) / dy;
        float enter = Math.max(Math.min(tx1, tx2), Math.min(ty1, ty2));
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        float k0 = Math.max(1.5f, 2.5f / Math.max(0.01f, ps));
        float tipLen = 3.2f * k0;
        float dist = enter * len;                      // distancia da ancora ate a borda
        if (dist > tipLen) c.drawLine(px + dx / len * tipLen, py + dy / len * tipLen, px + dx / len * dist, py + dy / len * dist, stroke);
        leaf(c, px, py, dx, dy, color, ps);
    }

    /** {ancoraX, ancoraY, l, t, r, b, rotGraus} do sprite do objeto no referencial local dele (origem = x,y do objeto), ou null. */
    private float[] spriteLocal(AttackSim.Obj ob) {
        if (anchorSprites == null || ob.img < 0) return null;
        SpriteCache.Sprite sp = anchorSprites.get(ob.img);
        if (sp == null) return null;
        int sf = ob.actFlags & 48;
        if (ob.parent != null) {
            if ((ob.parent.objFlags & 16) != 0) sf ^= 16;
            if ((ob.parent.objFlags & 32) != 0) sf ^= 32;
        } else sf ^= (ob.objFlags & 16) ^ (ob.objFlags & 32);
        boolean fh = (sf & 16) != 0, fv = (sf & 32) != 0;
        int zo = (ob.parent != null) ? ob.parent.zoomObj : ob.zoomObj;
        int zx = ob.xZoom * zo / 100, zy = ob.yZoom * zo / 100;
        if (zx == 0 || zy == 0) return null;
        int offX = zo * ob.ox / 100, offY = zo * ob.oy / 100, bX = ob.bx, bY = ob.by;
        if (fh) { offX = -offX; bX = -bX; }
        if (fv) { offY = -offY; bY = -bY; }
        float wf = sp.drawWidth * zx / 100f, hf = sp.drawHeight * zy / 100f;
        float left = (fh ? -(sp.logicalWidth * zx / 100) : 0) + bX + offX;
        float top = (fv ? -(sp.logicalHeight * zy / 100) : 0) + bY + offY;
        float rot = 0;
        if (ob.rot != 0) { int rr = ob.rot % 360; rot = fh ? 360 - rr : rr; }
        return new float[]{bX + offX, bY + offY, left, top, left + wf, top + hf, rot};
    }

    private void objAnchorWithBox(Canvas c, AttackSim.Obj ob, boolean atSpriteOrigin, int color, float dx, float dy, Options o) {
        float[] g = spriteLocal(ob);
        c.save();
        c.translate(ob.x >> 16, ob.y >> 16);
        if (g != null) {
            if (g[6] != 0) c.rotate(g[6]);
            if (atSpriteOrigin) anchorMark(c, g[0], g[1], true, g[2], g[3], g[4], g[5], color, dx, dy, o);
            else anchorMark(c, 0, 0, true, g[2], g[3], g[4], g[5], color, dx, dy, o);
        } else if (atSpriteOrigin) {
            int sf = ob.actFlags & 48;
            if (ob.parent != null) {
                if ((ob.parent.objFlags & 16) != 0) sf ^= 16;
                if ((ob.parent.objFlags & 32) != 0) sf ^= 32;
            } else sf ^= (ob.objFlags & 16) ^ (ob.objFlags & 32);
            int zo = (ob.parent != null) ? ob.parent.zoomObj : ob.zoomObj;
            int offX = zo * ob.ox / 100, offY = zo * ob.oy / 100, bX = ob.bx, bY = ob.by;
            if ((sf & 16) != 0) { offX = -offX; bX = -bX; }
            if ((sf & 32) != 0) { offY = -offY; bY = -bY; }
            anchorMark(c, bX + offX, bY + offY, false, 0, 0, 0, 0, color, dx, dy, o);
        } else anchorMark(c, 0, 0, false, 0, 0, 0, 0, color, dx, dy, o);
        c.restore();
    }

    /** Efeito global (pack effect: faiscas de hit, poeira, efeitos de flag, cutscenes): ponto roxo na posicao em que o efeito foi colocado. */
    public void drawGlobalAnchor(Canvas c, AttackSim sim, Options o) {
        if (!o.anchorGlobal || sim == null || sim.root() == null) return;
        AttackSim.Obj r = sim.root();
        int sf = r.actFlags & 48;
        sf ^= (r.objFlags & 16) ^ (r.objFlags & 32);
        objAnchorWithBox(c, r, false, 0xFFB05CFF, (sf & 16) != 0 ? -1 : 1, (sf & 32) != 0 ? -1 : 1, o);
    }

    /** Projetil: ponto laranja (cor do toggle Projetil) na origem do objeto dele, apontando para onde ele vai (velocidade; sem velocidade, o lado em que olha). */
    public void drawProjectileAnchor(Canvas c, AttackSim sim, Options o) {
        if (!o.anchorProj || sim == null || sim.root() == null) return;
        AttackSim.Obj r = sim.root();
        boolean left = (r.objFlags & 16) != 0;
        float dx = left ? -r.speedX : r.speedX, dy = r.speedY;
        if (dx == 0 && dy == 0) { dx = left ? -1 : 1; dy = 0; }
        objAnchorWithBox(c, r, false, 0xFFFF9A3C, dx, dy, o);
    }

    private void drawAnchors(Canvas c, AttackSim.Obj[] list, int n, Options o, boolean spr, int sprColor) {
        float ps = o.pixelScale;
        for (int i = 0; i < n; i++) {
            AttackSim.Obj ob = list[i];
            float ax = ob.x >> 16, ay = ob.y >> 16;
            if (spr && (ob.parent == null || o.showLinks) && ob.img >= 0 && (ob.objFlags & 1) == 0 && (ob.parent == null || (ob.parent.objFlags & 1) == 0)) {
                // ancora = ponto 0,0 do proprio sprite (canto de origem da imagem), ja com a base do recorte e o centro proprio (MID) do frame
                int sf = ob.actFlags & 48;
                if (ob.parent != null) {
                    if ((ob.parent.objFlags & 16) != 0) sf ^= 16;
                    if ((ob.parent.objFlags & 32) != 0) sf ^= 32;
                } else sf ^= (ob.objFlags & 16) ^ (ob.objFlags & 32);
                objAnchorWithBox(c, ob, true, sprColor, (sf & 16) != 0 ? -1 : 1, (sf & 32) != 0 ? -1 : 1, o);
            }
            int fl = (ob.actFlags & 48) ^ (ob.objFlags & 48);
            for (int k = 0; k < ob.hits.length; k++) {
                Ano.Hit h = ob.hits[k];
                boolean hurt = h.flag == 1, hit = h.flag == 2;
                if (hurt ? !o.anchorHurt : hit ? !o.anchorHit : !o.anchorFx) continue;
                float px = ax, py = ay;       // ancora = ponto 0,0 das coordenadas da hit (origem do objeto): nao se mexe quando a box muda de x/y
                float tw = h.width > 0 ? h.width : 1, th = h.height > 0 ? h.height : 1;       // a pontinha aponta para o centro da box
                float hl, hr, ht, hb;
                if ((fl & 16) != 0) { hr = ax - h.x; hl = hr - h.width; } else { hl = ax + h.x; hr = hl + h.width; }
                if ((fl & 32) != 0) { hb = ay - h.y; ht = hb - h.height; } else { ht = ay + h.y; hb = ht + h.height; }
                anchorMark(c, px, py, true, hl, ht, hr, hb, hurt ? 0xFF3C8CFF : hit ? 0xFFFF3C3C : 0xFFA0A4AC, (fl & 16) != 0 ? -tw : tw, (fl & 32) != 0 ? -th : th, o);
            }
        }
    }

    /** Box amarela nas bordas de cada sprite (ajuste fino de posicao); ligado pelo AttackView a cada desenho. */
    public boolean spriteBoxes;
    public float boxScale = 1f;

    private void drawObj(Canvas c, AttackSim.Obj o, SpriteCache sprites) {
        if (o.img < 0) return;
        if ((o.objFlags & 1) != 0 || (o.parent != null && (o.parent.objFlags & 1) != 0)) return;
        if ((o.objFlags & 2) != 0) return; // caminho "sprite" do jogo, nao usado em ataques

        SpriteCache.Sprite s = sprites.get(o.img);
        if (s == null) return;

        // flip: flags do frame XOR flip do objeto (do pai quando existe)
        int flip = o.actFlags & 48;
        if (o.parent != null) {
            if ((o.parent.objFlags & 16) != 0) flip ^= 16;
            if ((o.parent.objFlags & 32) != 0) flip ^= 32;
        } else {
            flip ^= (o.objFlags & 16) ^ (o.objFlags & 32);
        }
        boolean flipH = (flip & 16) != 0;
        boolean flipV = (flip & 32) != 0;

        int zo = (o.parent != null) ? o.parent.zoomObj : o.zoomObj;
        int zx = o.xZoom * zo / 100;
        int zy = o.yZoom * zo / 100;
        if (zx == 0 || zy == 0) return;

        int wInt = s.logicalWidth * zx / 100;
        int hInt = s.logicalHeight * zy / 100;
        float wf = s.drawWidth * zx / 100f;
        float hf = s.drawHeight * zy / 100f;

        int offX = zo * o.ox / 100;
        int offY = zo * o.oy / 100;
        int baseX = o.bx;
        int baseY = o.by;
        if (flipH) { offX = -offX; baseX = -baseX; }
        if (flipV) { offY = -offY; baseY = -baseY; }

        // posicao local (relativa a ancora): drawX = ancora - largura quando espelhado
        float left = (flipH ? -wInt : 0) + baseX + offX;
        float top = (flipV ? -hInt : 0) + baseY + offY;

        // alpha / blend
        int a = o.alpha;
        if (a < 0) a = 0; else if (a > 255) a = 255;
        int act = o.actFlags;
        boolean add = false;
        int paintAlpha;
        if (a == 0 && (act & 2048) == 0) {
            paintAlpha = 255;
        } else if ((act & 512) == 0 && (o.objFlags & 512) == 0) {
            paintAlpha = ((act & 1024) == 0 && (o.objFlags & 1024) == 0) ? a : 255;
        } else {
            add = true;
            paintAlpha = a;
        }
        if (paintAlpha == 0) return;
        sprite.setAlpha(paintAlpha);
        sprite.setXfermode(add ? additive : null);

        c.save();
        c.translate(o.x >> 16, o.y >> 16);
        if (o.rot != 0) {
            // graus inteiros, pivo na ancora do objeto; espelhado inverte o sentido
            int r = o.rot % 360;
            c.rotate(flipH ? 360 - r : r);
        }
        dst.set(left, top, left + wf, top + hf);
        if (flipH || flipV) c.scale(flipH ? -1f : 1f, flipV ? -1f : 1f, dst.centerX(), dst.centerY());
        c.drawBitmap(s.bitmap, s.src, dst, sprite);
        if (spriteBoxes) {
            stroke.setColor(0xFFFFE04C);
            stroke.setStrokeWidth(1f / Math.max(0.01f, boxScale));
            c.drawRect(dst, stroke);
        }
        c.restore();
        sprite.setXfermode(null);
        sprite.setAlpha(255);
    }

    /** Mesma geometria do CheckObjHit. */
    private void drawHits(Canvas c, AttackSim.Obj o, float ps, int onlyFlag, int onlyOcc) {
        if (o.hits.length == 0) return;
        if (onlyFlag >= 0 && o.parent != null) return;       // filtro: so as boxes do objeto raiz
        int seen = 0;
        int ax = o.x >> 16;
        int ay = o.y >> 16;
        int fl = (o.actFlags & 48) ^ (o.objFlags & 48);
        stroke.setStrokeWidth(1.5f / ps);
        text.setTextSize(11f / ps);
        for (int i = 0; i < o.hits.length; i++) {
            Ano.Hit h = o.hits[i];
            if (onlyFlag >= 0) {
                if (h.flag != onlyFlag) continue;
                if (seen++ != onlyOcc) continue;
            }
            if (h.flag == 20 || h.flag == 40) {
                // CheckOptFlag usa so x/y (espelhados por wObjFlag & 16, sem o flip do ANO): e um ponto, nao uma caixa; em 20 a largura e o id do evento
                float px = (o.objFlags & 16) != 0 ? ax - h.x : ax + h.x, py = ay + h.y;
                stroke.setColor(COLOR_OTHER);
                text.setColor(COLOR_OTHER);
                float k = 5f / ps;
                c.drawLine(px - k, py, px + k, py, stroke);
                c.drawLine(px, py - k, px, py + k, stroke);
                c.drawCircle(px, py, k * 0.6f, stroke);
                I18nUi.drawText(c, h.flag == 20 ? "20 \u00b7 evento " + h.width : "40", px + k + 2f / ps, py - 2f / ps, text);
                continue;
            }
            float l, r, t, b;
            if ((fl & 16) != 0) { r = ax - h.x; l = r - h.width; } else { l = ax + h.x; r = l + h.width; }
            if ((fl & 32) != 0) { b = ay - h.y; t = b - h.height; } else { t = ay + h.y; b = t + h.height; }
            int color = h.flag == 1 ? COLOR_HURT : (h.flag == 2 ? COLOR_HIT : COLOR_OTHER);
            fill.setColor((color & 0x00FFFFFF) | 0x38000000);
            c.drawRect(l, t, r, b, fill);
            stroke.setColor(color);
            c.drawRect(l, t, r, b, stroke);
            text.setColor(color);
            I18nUi.drawText(c, String.valueOf(h.flag), l + 2f / ps, t + 11f / ps, text);
        }
    }

    private void drawLinks(Canvas c, AttackSim.Obj[] list, int n, float ps) {
        stroke.setColor(COLOR_LINK);
        stroke.setStrokeWidth(1f / ps);
        fill.setColor(COLOR_LINK);
        float rad = 3f / ps;
        for (int i = 0; i < n; i++) {
            AttackSim.Obj o = list[i];
            float x = o.x >> 16;
            float y = o.y >> 16;
            if (o.parent != null) {
                c.drawLine(o.parent.x >> 16, o.parent.y >> 16, x, y, stroke);
            }
            c.drawCircle(x, y, rad, fill);
        }
    }
}
