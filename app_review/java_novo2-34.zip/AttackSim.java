package com.zue.attackeditor;

import java.util.Random;

/**
 * Simulacao de um golpe, tick a tick, espelhando o jogo:
 * _SetAct (cria raiz + links de 1 nivel), _ActReqMain (tempo, loop, sync, movimento) e _Hokan (interpolacao).
 * Nao depende de Android: so de Dac/Ano.
 */
public final class AttackSim {
    public static final int TICKS_PER_SECOND = 60;
    public static final int MAX_LINKS = 13;

    /** Se true, links nascem com 0..19 px de deslocamento aleatorio em x, como no jogo. */
    public static boolean randomLinkX = false;

    private static final int MAX_MEASURE_TICKS = 1200;
    private static final int TAIL_TICKS = 12;

    /** Objeto simulado (equivale ao ObjReq do jogo). */
    public static final class Obj {
        public final Ano ano;
        public final Ano.Mpt[] mpts;
        public final Obj parent;
        /** Indice do link no pai (-1 na raiz). */
        public final int slot;

        /** Posicao 16.16 como no jogo. */
        public int x, y;
        public int pat, time;
        public int actFlags, objFlags;

        public int img = -1;
        public int ox, oy;
        /** Offset base vindo do link. */
        public int bx, by;

        public int speedX, speedY, accelX, accelY;
        public int rot, alpha = 255, xZoom = 100, yZoom = 100;
        public int zoomObj = 100;

        public Ano.Hit[] hits = Ano.NO_HITS;
        public int optFlag;
        public final int[] optData = new int[4];

        public int actPrio, taskPrio;

        /** Incrementa a cada frame (MPT) carregado: serve para armar 1 hit por frame. */
        public int serial;
        /** SE do frame recem carregado (-1 = nada); quem toca deve consumir. */
        public int pendingSe = -1;

        // interpolacao (_Hokan)
        int rotAdd, alphaAdd, xZoomAdd, yZoomAdd, oxAdd, oyAdd;
        int oxBase, oyBase, zoomxBase, zoomyBase;

        Obj(Ano ano, Obj parent, int slot) {
            this.ano = ano;
            this.mpts = ano.mpts;
            this.parent = parent;
            this.slot = slot;
        }

        /** Projetil voando: ao acabar a animacao trava no ultimo frame e segue com a velocidade (como no jogo). */
        boolean holdLast;
        private boolean holding;
        public boolean frozenOnLast() { return holding; }

        public boolean isSynced() { return (actFlags & 0x8000) != 0; }

        /** Terminou: passou do ultimo MPT ou levantou a flag de fim. */
        public boolean isDone() { return pat >= mpts.length || (actFlags & 2) != 0; }

        /** Frame sem tempo: o jogo reprocessa o mesmo frame para sempre. */
        public boolean isHolding() { return !isDone() && time <= 0 && !isSynced(); }

        /**
         * _ActReqMain, "sincronizacao com o pai": roda ANTES da checagem de pausa (flag 4), entao um link sincronizado (0x8000 frame / 0x2000 x,y)
         * continua acompanhando o pai mesmo com o hitstop.
         */
        void syncWithParent() {
            if (parent != null && (actFlags & 0xA000) != 0) {
                if ((actFlags & 0x8000) != 0) {
                    if (pat != parent.pat) {
                        pat = parent.pat;
                        time = 0;
                        actFlags &= ~2;
                    } else {
                        time = -1;
                    }
                }
                x = parent.x;
                y = parent.y;
            }
        }

        /** So a parte de movimento de um tick (sem passar o tempo nem trocar de frame): o atacante da previa de reacao termina o frame onde ele acabaria. */
        void moveOnly() {
            if ((actFlags & 0xA000) != 0) return;
            x += ((objFlags & 16) != 0) ? -speedX : speedX;
            y += ((objFlags & 32) != 0) ? -speedY : speedY;
            speedX += accelX;
            speedY += accelY;
        }

        /** Um tick de _ActReqMain. */
        void actReq() {
            syncWithParent();

            if (holdLast && (holding || pat >= mpts.length || (actFlags & 2) != 0) && mpts.length > 0) {
                if (!holding) {                       // chegou ao fim: congela no ultimo frame e continua andando
                    holding = true;
                    if (pat >= mpts.length || pat < 0) pat = mpts.length - 1;
                    actFlags &= ~2;
                }
                if ((actFlags & 0xA000) == 0) {
                    x += ((objFlags & 16) != 0) ? -speedX : speedX;
                    y += ((objFlags & 32) != 0) ? -speedY : speedY;
                    speedX += accelX;
                    speedY += accelY;
                }
                return;
            }
            if (pat >= mpts.length) { actFlags |= 2; return; }
            if (pat < 0 || (actFlags & 2) != 0) return;

            // pausa (flag 4) vem do pai quando existe
            if (parent != null) {
                if ((parent.actFlags & 4) != 0) return;
            } else if ((actFlags & 4) != 0) {
                return;
            }

            if (time > 0) {
                if (optData[2] != 0) {
                    rot += rotAdd;
                    alpha += alphaAdd;
                    zoomxBase += xZoomAdd;
                    zoomyBase += yZoomAdd;
                    xZoom = zoomxBase / 128;
                    yZoom = zoomyBase / 128;
                    oxBase += oxAdd;
                    oyBase += oyAdd;
                    ox = oxBase / 128;
                    oy = oyBase / 128;
                }
                if ((actFlags & 0xA000) == 0) {
                    x += ((objFlags & 16) != 0) ? -speedX : speedX;
                    y += ((objFlags & 32) != 0) ? -speedY : speedY;
                    speedX += accelX;
                    speedY += accelY;
                }
                time--;
                if (time > 0) return;
                if ((actFlags & 1) != 0) {
                    pat = 0;
                } else {
                    pat++;
                    if (pat >= mpts.length) {
                        if (holdLast) { pat = mpts.length - 1; holding = true; return; }
                        actFlags |= 2;
                        return;
                    }
                }
            }
            loadFrame(mpts[pat]);
        }

        private void loadFrame(Ano.Mpt m) {
            serial++;
            if (m.se >= 0) pendingSe = m.se;
            time = m.hasTime ? m.time : 0;
            img = m.image;
            if (m.hasMid) { ox = m.midX; oy = m.midY; } else { ox = 0; oy = 0; }

            actFlags = (actFlags & 0xA000) | (m.wActFlag & 0xFFFF);

            if ((actFlags & 64) == 0) { speedX = 0; speedY = 0; }
            accelX = 0;
            accelY = 0;
            if (m.hasMove) {
                if ((m.moveMask & 1) != 0) speedX = m.speedX;
                if ((m.moveMask & 2) != 0) speedY = m.speedY;
                if ((m.moveMask & 4) != 0) accelX = m.accelX;
                if ((m.moveMask & 8) != 0) accelY = m.accelY;
            }

            hits = m.hits;

            if (m.hasOpt) {
                optFlag = m.optFlag;
                for (int i = 0; i < 4; i++) optData[i] = m.optData[i];
            } else {
                optFlag = 0;
                for (int i = 0; i < 4; i++) optData[i] = 0;
            }

            if (m.hasRaz) {
                rot = m.rot;
                xZoom = m.xZoom;
                yZoom = m.yZoom;
                alpha = m.alpha;
                actFlags |= m.razFlags;
            } else {
                rot = 0;
                alpha = 255;
                xZoom = 100;
                yZoom = 100;
            }
            hokan();
        }

        /**
         * _Hokan: calcula os passos para interpolar ox/oy, rotacao, alpha e zoom ate o proximo frame.
         * (O jogo pula os hits do proximo frame usando o iHitNum do frame atual; aqui usamos os dados
         * corretos do proximo frame.)
         */
        private void hokan() {
            rotAdd = 0; alphaAdd = 0; xZoomAdd = 0; yZoomAdd = 0; oxAdd = 0; oyAdd = 0;
            if (optData[2] == 0 || time <= 0) return;

            int np = pat + 1;
            if (np >= mpts.length) np = 0;
            Ano.Mpt n = mpts[np];

            int tx = n.hasMid ? n.midX : 0;
            int ty = n.hasMid ? n.midY : 0;
            oxBase = ox * 128;
            oyBase = oy * 128;
            oxAdd = (tx * 128 - oxBase) / time;
            oyAdd = (ty * 128 - oyBase) / time;
            zoomxBase = xZoom * 128;
            zoomyBase = yZoom * 128;

            if (n.hasRaz) {
                rotAdd = (n.rot - rot) / time;
                xZoomAdd = (n.xZoom * 128 - xZoom * 128) / time;
                yZoomAdd = (n.yZoom * 128 - yZoom * 128) / time;
                alphaAdd = (255 - (n.alphaRaw & 255) - alpha) / time;
            } else {
                rotAdd = (0 - rot) / time;
                xZoomAdd = (12800 - xZoom * 128) / time;
                yZoomAdd = (12800 - yZoom * 128) / time;
                alphaAdd = (255 - alpha) / time;
            }
        }
    }

    private final Dac dac;
    private final int rootAnoIndex;
    private final boolean facingLeft;
    private final int startX;
    private final int startY;

    private Obj root;
    private Obj[] children = new Obj[0];
    private int frame;
    private int prevRootPat;
    private boolean rootWrapped;

    public AttackSim(Dac dac, int rootAnoIndex, boolean facingLeft) {
        this(dac, rootAnoIndex, facingLeft, 0, 0);
    }

    /** startX/startY em 16.16 (como o jogo). */
    public AttackSim(Dac dac, int rootAnoIndex, boolean facingLeft, int startX, int startY) {
        this.dac = dac;
        this.rootAnoIndex = rootAnoIndex;
        this.facingLeft = facingLeft;
        this.startX = startX;
        this.startY = startY;
        reset();
    }

    public Obj root() { return root; }
    public Obj[] children() { return children; }
    /** Indice do frame mostrado (0 = primeiro tick). */
    public int frame() { return frame; }

    /** Recria raiz e links (_SetAct) e roda o primeiro tick. */
    public final void reset() {
        root = null;
        children = new Obj[0];
        rootWrapped = false;
        frame = 0;

        Ano ra = dac.getAno(rootAnoIndex);
        if (ra == null || !ra.present) return;

        Obj r = new Obj(ra, null, -1);
        r.objFlags = facingLeft ? 16 : 0;
        r.x = startX;
        r.y = startY;
        r.actPrio = ra.priority;
        r.taskPrio = MAX_LINKS - 1;

        int n = Math.min(ra.links.length, MAX_LINKS);
        Obj[] list = new Obj[n];
        Random rnd = randomLinkX ? new Random(1234L) : null;
        for (int i = 0; i < n; i++) {
            Ano.Link l = ra.links[i];
            Ano ca = dac.getAno(l.getAno());
            if (ca == null || !ca.present) continue;

            Obj c = new Obj(ca, r, i);
            c.bx = l.baseX;
            c.by = l.baseY;
            c.actPrio = ca.priority;
            c.taskPrio = MAX_LINKS - 2 - i;
            c.objFlags |= r.objFlags;
            if (l.syncMpt()) {
                c.actFlags |= 0x8000;
                c.pat = -1;
            } else {
                c.pat = 0;
                c.time = 0;
                // spawnPos (0x1000) no jogo deixa x/y como vierem do spawner; aqui nao ha spawner,
                // entao o filho nasce na posicao do pai de qualquer jeito.
                c.x = r.x;
                c.y = r.y;
            }
            if (l.syncXY()) c.actFlags |= 0x2000;
            if (rnd != null) c.x += rnd.nextInt(20) << 16;
            list[i] = c;
        }
        root = r;
        children = list;

        frame = -1;
        step();
        prevRootPat = root.pat;
        rootWrapped = false;
    }

    /** Um tick: raiz primeiro, depois os links na ordem. */
    public void step() { step(false); }

    /**
     * true = objeto de lutador/agarrado/cutscene (tasks que chamam _SetXY ANTES do _ActReq): a cada tick todos os links voltam
     * para a posicao da raiz e so andam o passo de velocidade proprio daquele tick (sem acumular). Projeteis, auras e efeitos
     * (que escrevem so o x da raiz) deixam isto desligado.
     */
    public boolean rebaseLinks;

    /**
     * true = lutador, projetil, aura ou agarrao: o PlayerTail / md 971 / md 977 / md 941 recalculam o bit 4 do wActFlag (pausa) a cada tick
     * (so o hitstop ou o md 925 o ligam), entao um bit 4 vindo do dado do MPT nao prende o objeto. Efeitos de hit e cutscenes nao fazem isso.
     */
    public boolean clearPause;

    /** _SetXY do jogo: raiz e todos os links vao para (x, y) (16.16). */
    public void pinTo(int x, int y) {
        if (root == null) return;
        root.x = x;
        root.y = y;
        for (int i = 0; i < children.length; i++) {
            if (children[i] != null) { children[i].x = x; children[i].y = y; }
        }
        settledX = x;
        settledY = y;
    }

    private int settledX, settledY;

    /**
     * Quem mexeu na raiz depois do passo (camera, paredes, teleporte...) leva os links junto: no jogo isso so aparece no
     * _SetXY do tick seguinte, mas a previa desenha logo, entao os filhos andam o mesmo deslocamento.
     */
    public void settle() {
        if (root == null) return;
        int dx = root.x - settledX, dy = root.y - settledY;
        if ((dx | dy) != 0) {
            for (int i = 0; i < children.length; i++) {
                if (children[i] != null) { children[i].x += dx; children[i].y += dy; }
            }
        }
        settledX = root.x;
        settledY = root.y;
    }

    /** Move raiz e links pelo mesmo deslocamento (camera/limites que mexem na raiz depois do passo). */
    public void translate(int dx, int dy) {
        if (root == null) return;
        root.x += dx;
        root.y += dy;
        for (int i = 0; i < children.length; i++) {
            if (children[i] != null) { children[i].x += dx; children[i].y += dy; }
        }
        settledX += dx;
        settledY += dy;
    }

    /** frozen = hitstop: o jogo liga a flag 4 (pausa) e o _ActReq nao avanca nada. */
    public void step(boolean frozen) {
        if (root == null) return;
        if (rebaseLinks) {
            for (int i = 0; i < children.length; i++) {
                if (children[i] != null) { children[i].x = root.x; children[i].y = root.y; }
            }
        }
        if (!frozen) {
            if (clearPause) root.actFlags &= ~4;
            root.actReq();
            for (int i = 0; i < children.length; i++) {
                if (children[i] != null) children[i].actReq();
            }
        } else {
            for (int i = 0; i < children.length; i++) {          // pausado: o _ActReq ainda sincroniza o link com o pai antes de parar
                if (children[i] != null) children[i].syncWithParent();
            }
        }
        frame++;
        if (root.pat < prevRootPat) rootWrapped = true;
        prevRootPat = root.pat;
        settledX = root.x;
        settledY = root.y;
    }

    /** Raiz + links ordenados como o DrawExec: chave (prio - actPrio) crescente, empate por taskPrio. */
    public int fillDrawOrder(Obj[] out) {
        if (root == null) return 0;
        int n = 0;
        out[n++] = root;
        for (int i = 0; i < children.length && n < out.length; i++) {
            if (children[i] != null) out[n++] = children[i];
        }
        for (int i = 1; i < n; i++) {
            Obj cur = out[i];
            int j = i - 1;
            while (j >= 0 && drawsAfter(out[j], cur)) {
                out[j + 1] = out[j];
                j--;
            }
            out[j + 1] = cur;
        }
        return n;
    }

    private static boolean drawsAfter(Obj a, Obj b) {
        int ka = -a.actPrio;
        int kb = -b.actPrio;
        if (ka != kb) return ka > kb;
        return a.taskPrio > b.taskPrio;
    }

    /** Duracao sugerida em ticks (ate estabilizar) mais uma pequena cauda. */
    public int measureLength() {
        AttackSim s = new AttackSim(dac, rootAnoIndex, facingLeft);
        if (s.root == null) return 1;
        for (int t = 0; t < MAX_MEASURE_TICKS; t++) {
            if (s.settled()) return t + 1 + TAIL_TICKS;
            s.step();
        }
        return MAX_MEASURE_TICKS;
    }

    public boolean isSettled() { return settled(); }

    /** A raiz voltou ao frame 0 por causa da flag de loop (wActFlag 1) desde o ultimo reset. */
    public boolean hasWrapped() { return rootWrapped; }

    private boolean settled() {
        if (root == null) return true;
        if (!(root.isDone() || root.isHolding() || rootWrapped)) return false;
        for (int i = 0; i < children.length; i++) {
            Obj c = children[i];
            if (c == null) continue;
            if (!(c.isDone() || c.isHolding() || c.isSynced() || (c.actFlags & 1) != 0)) return false;
        }
        return true;
    }

    public String describe() { return describeMain() + "  " + describeExtra(); }

    /** Linha 1: onde o ANO esta (pat, img, posicao). */
    public String describeMain() {
        if (root == null) return "sem ANO";
        return "pat " + root.pat + "/" + root.mpts.length + " \u00b7 img " + root.img
                + " \u00b7 pos " + (root.x >> 16) + "," + (root.y >> 16) + " \u00b7 tempo " + Math.max(0, root.time);
    }

    /** Linha 2: hitboxes, links e estado do ANO. */
    public String describeExtra() {
        if (root == null) return "";
        int live = 0;
        for (int i = 0; i < children.length; i++) if (children[i] != null) live++;
        StringBuilder sb = new StringBuilder();
        sb.append("hits ").append(root.hits.length).append(" \u00b7 links ").append(live);
        if (root.isDone()) sb.append(" \u00b7 [fim]");
        else if (root.isHolding()) sb.append(" \u00b7 [fixo]");
        return sb.toString();
    }
}
