package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Area de preview: reproduz a simulacao a 60 ticks/s, permite arrastar, dar zoom e navegar frame a frame. */
public final class AttackView extends View {
    public interface Listener {
        void onFrame(int frame, int length, boolean playing);
    }

    private static final float TICK_MS = 1000f / AttackSim.TICKS_PER_SECOND;
    private static final int MAX_STEPS_PER_DRAW = 8;
    private static final float MIN_SCALE = PreviewCam.MIN_SCALE;
    private static final float MAX_SCALE = PreviewCam.MAX_SCALE;

    private final AttackRenderer renderer = new AttackRenderer();
    private final AttackRenderer.Options opts = new AttackRenderer.Options();
    private final Paint gridPaint = new Paint();
    private final Paint axisPaint = new Paint();
    private final Paint groundFill = new Paint();
    private final Paint groundLine = new Paint();
    private final Paint edgePaint = new Paint();
    private final Paint barPaint = new Paint();
    private final Paint barText = new Paint();
    private final ScaleGestureDetector scaler;
    private final float density;

    private AttackData data;
    private BattleSim sim;
    private SoundPlayer sound;
    private boolean soundOn = true;
    /** Distancia de inicio de batalha do jogo: P1 em 120 px e P2 em 360 px (md 720: iBackXPos + 7864320 / + 23592960). */
    public static final int SPAWN_DISTANCE = 240;
    private int distance = SPAWN_DISTANCE;
    private int height = 0;
    private boolean facingLeft;
    private boolean playing = true;
    private boolean showGrid = true;
    private int frame;
    private int length = 1;
    private boolean loops;
    private long lastMs;
    private float acc;
    private float speed = 1f;

    private float originX, originY, scale;
    private boolean originSet;
    private float lastX, lastY;
    private boolean dragging;

    private Listener listener;
    private boolean uiPosted;
    private final Runnable notifier = new Runnable() {
        @Override public void run() {
            uiPosted = false;
            if (listener != null) listener.onFrame(frame, length, playing);
        }
    };

    public AttackView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        scale = Math.max(1f, density);
        gridPaint.setColor(0x14FFFFFF);
        gridPaint.setStrokeWidth(1f);
        axisPaint.setColor(0x55FFFFFF);
        axisPaint.setStrokeWidth(Math.max(1f, density));

        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float ns = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale * d.getScaleFactor()));
                float k = ns / scale;
                originX = d.getFocusX() - (d.getFocusX() - originX) * k;
                originY = d.getFocusY() - (d.getFocusY() - originY) * k;
                scale = ns;
                invalidate();
                return true;
            }
        });
    }

    // ---- dados ----

    /** Troca o golpe mostrado (mantem o estado de "virar"). */
    public void setData(AttackData d) {
        this.data = d;
        ctxAno = -1;                                       // dados novos: sai do modo contexto (EDITAR NOS USOS liga de novo depois)
        ctx = null;
        rebuild(0);
    }

    // ---- modo contexto (EDITAR NOS USOS): a previa toca o golpe/ANO que usa o ANO alvo; a timeline edita o ANO alvo ----
    private int ctxAno = -1;
    private BattleSim.Trace ctx;
    private String ctxKey = "";

    public boolean inContext() { return ctxAno >= 0; }
    public int contextAno() { return ctxAno; }

    /** Liga o contexto (os dados do host ja carregados com setData): para no 1o tick em que o ANO {@code ano} aparece. */
    public void setContext(int ano) {
        ctxAno = ano;
        ctx = null;
        ctxKey = "";
        if (data != null) rebuild(0);
        pause();
        int f = contextFirstTick();
        if (f > 0) seekTo(f);
    }

    /** Rastreio do ANO alvo na simulacao atual (refeito quando algo muda). */
    private BattleSim.Trace ctxTrace() {
        if (ctxAno < 0 || sim == null) return null;
        String key = editVersion + ":" + System.identityHashCode(data) + ":" + facingLeft + ":" + distance + ":" + height + ":" + BattleSim.oppHeightPx
                + ":" + BattleSim.lockFromTick + ":" + BattleSim.landingOn + ":" + BattleSim.extendTime + ":" + BattleSim.flyMode;
        if (ctx == null || !key.equals(ctxKey)) {
            ctx = sim.traceAno(ctxAno, Math.min(3600, Math.max(length, 600) + 600));
            ctxKey = key;
        }
        return ctx;
    }

    /** Primeiro tick em que o ANO do contexto aparece; -1 se ele nao aparece nesta simulacao. */
    public int contextFirstTick() { BattleSim.Trace t = ctxTrace(); return t == null ? -1 : t.first; }

    /** Frame e ticks decorridos do ANO do contexto no tick {@code f}: antes de aparecer = 0, 0; depois de sumir = o ultimo visto. */
    private int[] ctxAt(int f) {
        BattleSim.Trace t = ctxTrace();
        Ano a = data == null ? null : data.attacker.dac.getAno(ctxAno);
        if (t == null || a == null || a.mpts.length == 0 || t.first < 0 || f < t.first) return new int[] {0, 0};
        int i = Math.min(f, t.pat.length - 1);
        while (i > t.first && t.pat[i] < 0) i--;
        if (t.pat[i] < 0) return new int[] {0, 0};
        return new int[] {Math.min(t.pat[i], a.mpts.length - 1), Math.max(0, t.elapsed[i])};
    }

    /** O contexto estende o fim da barra ate o ANO alvo sumir. */
    private void ctxExtend() {
        if (ctxAno < 0) return;
        ctx = null;
        BattleSim.Trace t = ctxTrace();
        if (t != null && t.last >= length) length = t.last + 1;
    }

    /** Troca os dados mantendo o frame e o estado de play (ex.: a game data foi relida ao voltar para o app). */
    public void setDataKeep(AttackData d) {
        this.data = d;
        rebuild(frame);
    }

    public AttackData currentData() { return data; }

    public void setSoundPlayer(SoundPlayer p) { sound = p; }
    public SoundPlayer soundPlayer() { return sound; }
    public void setSoundOn(boolean on) { soundOn = on; }
    public void setDistance(int d) { distance = Math.max(0, Math.min(480, d)); if (data != null) rebuild(frame); }
    public void setHeight(int h) { height = Math.max(0, Math.min(200, h)); if (data != null) rebuild(frame); }
    public int getDistance() { return distance; }
    /** Distancia e altura de uma vez (uma unica reconstrucao). */
    public void setPosition(int d, int h) {
        distance = Math.max(0, Math.min(480, d));
        height = Math.max(0, Math.min(200, h));
        if (data != null) rebuild(frame);
    }
    public int getOppAltitude() { return BattleSim.oppHeightPx; }
    public void setOppHeight(int h) { BattleSim.oppHeightPx = Math.max(0, Math.min(200, h)); if (data != null) rebuild(frame); }
    /** Distancia, altura do atacante e altura do oponente de uma vez. */
    public void setPositions(int d, int ha, int ho) {
        distance = Math.max(0, Math.min(480, d));
        height = Math.max(0, Math.min(200, ha));
        BattleSim.oppHeightPx = Math.max(0, Math.min(200, ho));
        if (data != null) rebuild(frame);
    }
    /** POS ESQ / MEIO / DIR: 0 padrao, 1 encosta o par na borda esquerda do mapa, 2 centraliza, 3 borda direita (so o x muda). */
    public int getMapPos() { return BattleSim.mapPos; }
    public void setMapPos(int m) { BattleSim.mapPos = Math.max(0, Math.min(3, m)); if (data != null) rebuild(frame); }
    public void setFly(boolean on) { BattleSim.flyMode = on; if (data != null) rebuild(frame); }
    public boolean isFly() { return BattleSim.flyMode; }
    /** 0 livre, 1 camera no centro do mapa (tela centrada na origem). */
    /** true = o atacante trava no ultimo frame e a simulacao segue ate projeteis e reacao acabarem. */
    public void setExtendTime(boolean on) { BattleSim.extendTime = on; if (data != null) rebuild(frame); }
    /** Modo de tempo: 0 NORMAL, 1 ESTENDIDO, 2 ATAQUE (estendido; a reproducao para no pouso, a barra continua livre). */
    public void setTimeMode(int mode) {
        BattleSim.extendTime = mode != 0;
        BattleSim.attackStop = mode == 2;
        if (data != null) rebuild(frame);
    }
    public int getTimeMode() { return BattleSim.attackStop ? 2 : BattleSim.extendTime ? 1 : 0; }
    public void setLockTransitions(boolean on) { BattleSim.lockFromTick = on ? frame : -1; lockDismissed = false; if (data != null) rebuild(frame); }
    public void setLanding(boolean on) { BattleSim.landingOn = on; if (data != null) rebuild(frame); }
    public boolean isLanding() { return BattleSim.landingOn; }
    /** DEF: o oponente defende os golpes (para testar o comportamento do golpe ao ser defendido). */
    public void setDefend(boolean on) { BattleSim.defend = on; if (data != null) rebuild(frame); }
    public boolean isDefend() { return BattleSim.defend; }
    private boolean lockDismissed;

    /** O golpe tem SEQ (chao ou ar) ou AO ACERTAR? So ai a trava de transicao tem o que travar. */
    public boolean hasSequence() {
        if (data == null || data.move == null) return false;
        CharData.Move m = data.move;
        return m.animSeqChao > 0 || m.animSeqAr > 0 || m.animAoAcertar > 0;
    }
    private Runnable lockOffRequest;
    /** Quem desliga a trava na interface (botao DESATIVAR do aviso). */
    public void setLockOffRequest(Runnable r) { lockOffRequest = r; }

    private void showLockNotice() {
        if (BattleSim.lockFromTick < 0 || lockDismissed || !hasSequence()) return;
        QuickNotice n = new QuickNotice("A transição está travada, o golpe não pode entrar na Sequência, para ver a sequência, desative a trava.")
                .left("OCULTAR", new Runnable() { public void run() { lockDismissed = true; } })
                .right("DESATIVAR", new Runnable() { public void run() { if (lockOffRequest != null) lockOffRequest.run(); } });
        showNotice(n);
    }
    public void setCinematic(boolean on) { BattleSim.cinematic = on; if (data != null) rebuild(frame); }
    public boolean hasCinematic() { return sim != null && sim.hasCinematic(); }
    public void setCutscenes(boolean on) { BattleSim.cutscenes = on; if (data != null) rebuild(frame); }
    public int getAltitude() { return height; }

    public void setFacingLeft(boolean left) {
        if (left == facingLeft) return;
        facingLeft = left;
        if (data != null) rebuild(frame);
    }

    private void rebuild(int keepFrame) {
        if (data == null) {
            sim = null;
            length = 1;
            frame = 0;
        } else {
            ghostKey = "";
            ghostSim = null;
            ObjModel.setWindowContext(data.move, data.moveIndex);
            ObjModel.setGameContext(data.gameData);
            sim = new BattleSim(data.attacker.dac, data.attacker.data, data.move, facingLeft,
                    data.opponent.dac, data.effects == null ? null : data.effects.dac, data.gameData,
                    distance, height, data.attacker.wavCount);
            sim.setOpponentChar(data.opponent.data);
            sim.setSpecialType(data.moveIndex);
            if (data.charf != null) sim.setCharfDac(data.charf.dac);
            if (data.bobj != null) sim.setBobjDac(data.bobj.dac);
            length = Math.max(1, sim.measureLength());
            ctxExtend();
            landStop = sim.measuredLandTick();
            checkLandWarning();
            if (!measuredEarly) checkRules();
            anoEnd = Math.min(length, Math.max(1, sim.measureAnoLength()));
            loops = sim.loops();
            seekInternal(Math.min(keepFrame, length - 1));
        }
        acc = 0;
        lastMs = 0;
        notifyUi();
        invalidate();
    }

    private volatile boolean building;

    /**
     * Como rebuild(), mas a simulacao nova (e as medicoes completas do golpe) sao feitas fora da UI thread; a tela nao desenha ate terminar.
     * {@code done} roda na UI thread no fim. Para edicoes grandes (muitos frames de uma vez).
     */
    public void rebuildAsync(final int keepFrame, final Runnable done) {
        if (data == null || building) { rebuild(keepFrame); if (done != null) done.run(); return; }
        building = true;
        final AttackData d = data;
        final boolean fl = facingLeft;
        final int dist = distance, hgt = height;
        new Thread(new Runnable() {
            @Override public void run() {
                BattleSim ns = null;
                int len = 1, land = -1, aEnd = 1, target = 0;
                boolean lp = false;
                Throwable err = null;
                try {
                    ns = new BattleSim(d.attacker.dac, d.attacker.data, d.move, fl, d.opponent.dac, d.effects == null ? null : d.effects.dac,
                            d.gameData, dist, hgt, d.attacker.wavCount);
                    ns.setOpponentChar(d.opponent.data);
                    ns.setSpecialType(d.moveIndex);
                    if (d.charf != null) ns.setCharfDac(d.charf.dac);
                    if (d.bobj != null) ns.setBobjDac(d.bobj.dac);
                    len = Math.max(1, ns.measureLength());
                    land = ns.measuredLandTick();
                    aEnd = Math.min(len, Math.max(1, ns.measureAnoLength()));
                    target = Math.min(keepFrame, len - 1);
                    ns.reset();
                    for (int i = 0; i < target; i++) ns.step();
                    if (target > 0) ns.drainSounds();
                } catch (Throwable t) { err = t; }
                final BattleSim fs = ns;
                final int flen = len, fland = land, fend = aEnd, ft = target;
                final Throwable ferr = err;
                post(new Runnable() {
                    @Override public void run() {
                        building = false;
                        if (ferr != null || fs == null) { rebuild(keepFrame); if (done != null) done.run(); return; }
                        ghostKey = "";
                        ghostSim = null;
                        sim = fs;
                        length = flen;
                        ctxExtend();
                        landStop = fland;
                        checkLandWarning();
                        if (!measuredEarly) checkRules();
                        anoEnd = fend;
                        loops = sim.loops();
                        stopSounds();
                        frame = ft;
                        landSeen = sim.landedEarly();
                        acc = 0;
                        lastMs = 0;
                        notifyUi();
                        invalidate();
                        if (done != null) done.run();
                    }
                });
            }
        }).start();
    }

    /** Troca a ANO atual inteira reconstruindo em segundo plano (veja rebuildAsync). */
    public void replaceAnoAsync(Ano na, Runnable done) {
        final Ano old = currentAno();
        if (old == null || data == null) { if (done != null) done.run(); return; }
        na = withLoopKept(old, na);
        final Dac dac = data.attacker.dac;
        final int idx = old.index;
        dac.setAno(idx, na);
        pushUndo(null, UndoEdits.swapAno(dac, idx, old));
        editVersion++;
        rebuildAsync(frame, done);
    }

    /** Troca varias ANOs do DAC do atacante de uma vez (um unico desfazer), reconstruindo em segundo plano. */
    public void replaceAnosAsync(final java.util.List<Ano> list, Runnable done) {
        if (data == null || list.isEmpty()) { if (done != null) done.run(); return; }
        final Dac dac = data.attacker.dac;
        final java.util.ArrayList<Ano> olds = new java.util.ArrayList<Ano>();
        for (Ano na : list) { olds.add(dac.getAno(na.index)); dac.setAno(na.index, na); }
        pushUndo(null, UndoEdits.swapAnos(dac, olds));
        editVersion++;
        rebuildAsync(frame, done);
    }

    // ---- avisos rapidos sobre a preview (QuickNotice) ----

    private QuickNotice notice;
    private long noticeUntil;                 // 0 = sem aviso; Long.MAX_VALUE = fica ate fechar
    private final Paint warnBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint warnText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final java.util.ArrayList<android.graphics.RectF> noticeRects = new java.util.ArrayList<android.graphics.RectF>();
    private final java.util.ArrayList<QuickNotice.Action> noticeActs = new java.util.ArrayList<QuickNotice.Action>();
    private Runnable posRequest;
    private boolean noticeExpanded;                       // toque no aviso: ocupa a preview inteira (ainda flutuante)
    private final android.graphics.RectF noticeBox = new android.graphics.RectF();
    private final android.graphics.RectF noticeClose = new android.graphics.RectF();

    /** Quem abre o menu de posicao dos personagens (botao POS dos avisos). */
    public void setPosRequest(Runnable r) { posRequest = r; }

    private Runnable posClosed;

    /** Abre o MESMO dialogo POS da tela principal (arrastar atacante e oponente, alturas, FLY); {@code onClosed} roda quando ele fecha. false = indisponivel. */
    public boolean openPosDialog(Runnable onClosed) {
        if (posRequest == null) return false;
        posClosed = onClosed;
        posRequest.run();
        return true;
    }

    /** O dialogo POS fechou (chamado por quem o mostra). */
    public void posDialogClosed() { Runnable r = posClosed; posClosed = null; if (r != null) r.run(); }

    public void showNotice(QuickNotice n) {
        notice = n;
        noticeExpanded = false;
        if (n.durationMs > 0) {
            noticeUntil = SystemClock.uptimeMillis() + n.durationMs;
            postInvalidateDelayed(n.durationMs + 30);
        } else noticeUntil = Long.MAX_VALUE;
        invalidate();
    }

    public void hideNotice() { notice = null; noticeExpanded = false; noticeUntil = 0; noticeRects.clear(); noticeActs.clear(); noticeBox.setEmpty(); noticeClose.setEmpty(); invalidate(); }

    private boolean noticeVisible() { return notice != null && SystemClock.uptimeMillis() < noticeUntil; }

    // limites do jogo (GameRules): o simulador aceita, o jogo fecha ou ignora

    private String rulesDismissed = "";

    private void checkRules() {
        if (data == null || data.attacker == null) return;
        java.util.TreeSet<Integer> anos = Saver.anosOfMove(data.attacker.dac, data.move, data.attacker.data);
        java.util.List<GameRules.Issue> iss = GameRules.check(data.attacker.dac, anos, data.attacker.cnv == null ? 0 : data.attacker.cnv.size());
        boolean fatal = false;
        for (GameRules.Issue i : iss) fatal |= i.fatal;
        // prioridade: o que fecha o jogo > projetil que nao nasceu > avisos do jogo
        String spawn = sim == null ? "" : sim.spawnProblem();
        boolean showSpawn = !fatal && spawn.length() > 0;
        final String msg = showSpawn ? spawn : GameRules.summary(iss);
        if (msg.isEmpty() || msg.equals(rulesDismissed)) return;
        StringBuilder all = new StringBuilder();
        if (spawn.length() > 0) all.append(spawn);
        String det = GameRules.details(iss);
        if (det.length() > 0) all.append(all.length() > 0 ? "\n" : "").append(det);
        QuickNotice n = new QuickNotice(msg).full(all.toString()).duration(showSpawn ? 9000 : 7000).left("OCULTAR", new Runnable() { public void run() { rulesDismissed = msg; } });
        if (showSpawn && sim.spawnProblemByHeight()) n.right("POS", new Runnable() { public void run() { if (posRequest != null) posRequest.run(); } });
        if (!fatal) n.colors(QuickNotice.AMBER, QuickNotice.AMBER_BTN);
        showNotice(n);
    }

    // aviso de pouso

    private static final String LAND_MSG = "Animação/golpe acabou antes por causa do pouso. Experimente mudar a posição do personagem para ver o movimento completo.";
    private boolean landSeen;                 // o pouso antecipado ja aconteceu na simulacao atual
    private boolean measuredEarly;            // a medicao completa do golpe pousou antes do fim
    private String warnKey = "", dismissedKey = "";

    /**
     * Aviso de pouso: aparece 2 s ao escolher/alterar o golpe e de novo toda vez que, tocando, o personagem pousa antes da hora;
     * dar play o esconde. OCULTAR (esquerda) o desliga para esta combinacao golpe/altura/distancia/lado; POS (direita) abre as posicoes.
     */
    private void checkLandWarning() {
        measuredEarly = sim != null && data != null && sim.measuredLandedEarly();
        warnKey = data == null ? "" : data.moveIndex + ":" + height + ":" + distance + ":" + facingLeft;
        hideNotice();
        if (measuredEarly) showLandWarning();
    }

    private void showLandWarning() {
        if (!measuredEarly || warnKey.equals(dismissedKey)) return;
        final String key = warnKey;
        QuickNotice n = new QuickNotice(LAND_MSG)
                .left("OCULTAR", new Runnable() { public void run() { dismissedKey = key; } })
                .right("POS", new Runnable() { public void run() { if (posRequest != null) posRequest.run(); } });
        showNotice(n);
    }

    /** Chamado depois de cada tick: o pouso antecipado acabou de acontecer? */
    private void watchLanding() {
        boolean now = sim != null && sim.landedEarly();
        if (now && !landSeen && measuredEarly) showLandWarning();
        landSeen = now;
    }

    private void drawNotice(Canvas c) {
        noticeRects.clear();
        noticeActs.clear();
        noticeBox.setEmpty();
        noticeClose.setEmpty();
        if (!noticeVisible()) return;
        QuickNotice n = notice;
        float w = getWidth(), h = getHeight(), pad = 10f * density, margin = 8f * density;
        float xs = 26f * density;                                  // lado do botao X
        warnText.setColor(0xFFFFFFFF);
        warnText.setTextSize((noticeExpanded ? 15f : 12f) * density);
        warnText.setTextAlign(Paint.Align.LEFT);
        float maxW = (noticeExpanded ? w - 2 * margin : w * 0.8f) - 2 * pad - xs;
        java.util.ArrayList<String> lines = new java.util.ArrayList<String>();
        float widest = 0;
        for (String para : n.shown(noticeExpanded).split("\n")) {
            String rest = para.trim();
            if (rest.isEmpty()) continue;
            while (rest.length() > 0) {
                int k = warnText.breakText(rest, true, maxW, null);
                if (k < rest.length()) {
                    int sp = rest.lastIndexOf(' ', k);
                    if (sp > 0) k = sp;
                }
                String ln = rest.substring(0, k).trim();
                lines.add(ln);
                widest = Math.max(widest, warnText.measureText(ln));
                rest = rest.substring(k).trim();
            }
        }
        float lh = warnText.getFontSpacing();
        float btnH = lh + pad, gap = 6f * density;
        float leftW = rowWidth(n.left, pad, gap), rightW = rowWidth(n.right, pad, gap);
        widest = Math.max(widest, leftW + rightW + (leftW > 0 && rightW > 0 ? 2 * pad : 0));
        boolean hasBtn = !n.left.isEmpty() || !n.right.isEmpty();
        float bw = widest + 2 * pad + xs, bh = Math.max(lines.size() * lh, xs) + 2 * pad + (hasBtn ? pad + btnH : 0);
        float x, y;
        if (noticeExpanded) {
            x = margin; y = margin; bw = w - 2 * margin; bh = h - 2 * margin;
        } else {
            x = (w - bw) / 2f; y = 40f * density;
        }
        noticeBox.set(x, y, x + bw, y + bh);
        warnBg.setColor(noticeExpanded ? (n.color & 0x00FFFFFF) | 0xE6000000 : n.color);
        c.drawRoundRect(noticeBox, 8f * density, 8f * density, warnBg);
        float base = y + pad - warnText.ascent();
        for (int i = 0; i < lines.size(); i++) I18nUi.drawText(c, lines.get(i), x + pad, base + i * lh, warnText);
        // X: fecha sem ocultar
        noticeClose.set(x + bw - pad / 2f - xs, y + pad / 2f, x + bw - pad / 2f, y + pad / 2f + xs);
        warnBg.setColor(n.buttonColor);
        c.drawRoundRect(noticeClose, 6f * density, 6f * density, warnBg);
        Paint.Align al = warnText.getTextAlign();
        warnText.setTextAlign(Paint.Align.CENTER);
        I18nUi.drawText(c, "\u2715", noticeClose.centerX(), noticeClose.centerY() - (warnText.ascent() + warnText.descent()) / 2f, warnText);
        warnText.setTextAlign(al);
        float by = y + bh - pad - btnH;
        drawRow(c, n.left, x + pad, by, btnH, pad, gap, n.buttonColor);
        drawRow(c, n.right, x + bw - pad - rightW, by, btnH, pad, gap, n.buttonColor);
    }

    private float rowWidth(java.util.List<QuickNotice.Action> row, float pad, float gap) {
        float t = 0;
        for (int i = 0; i < row.size(); i++) t += warnText.measureText(row.get(i).label) + 2 * pad + (i > 0 ? gap : 0);
        return t;
    }

    private void drawRow(Canvas c, java.util.List<QuickNotice.Action> row, float x, float y, float h, float pad, float gap, int color) {
        float lh = warnText.getFontSpacing();
        for (int i = 0; i < row.size(); i++) {
            QuickNotice.Action a = row.get(i);
            float bw = warnText.measureText(a.label) + 2 * pad;
            android.graphics.RectF r = new android.graphics.RectF(x, y, x + bw, y + h);
            warnBg.setColor(color);
            c.drawRoundRect(r, 6f * density, 6f * density, warnBg);
            I18nUi.drawText(c, a.label, x + pad, y + (h - lh) / 2f - warnText.ascent(), warnText);
            noticeRects.add(r);
            noticeActs.add(a);
            x += bw + gap;
        }
    }

    /** Toque num botao do aviso aberto; true se consumiu. */
    private boolean noticeTouch(float tx, float ty) {
        if (!noticeVisible()) return false;
        if (noticeClose.contains(tx, ty)) { hideNotice(); return true; }
        for (int i = 0; i < noticeRects.size(); i++) {
            if (noticeRects.get(i).contains(tx, ty)) {
                QuickNotice.Action a = noticeActs.get(i);
                if (a.closes) hideNotice();
                if (a.run != null) a.run.run();
                return true;
            }
        }
        if (noticeBox.contains(tx, ty)) {                           // area do aviso: expande / recolhe
            noticeExpanded = !noticeExpanded;
            if (noticeExpanded) noticeUntil = Long.MAX_VALUE;
            else if (notice.durationMs > 0) {
                noticeUntil = SystemClock.uptimeMillis() + notice.durationMs;
                postInvalidateDelayed(notice.durationMs + 30);
            }
            invalidate();
            return true;
        }
        return false;
    }

    // ---- reproducao ----

    private int landStop = -1;           // tick do pouso (modo ATAQUE), -1 = nao pousa

    private boolean atLandStop() { return BattleSim.attackStop && landStop >= 0 && frame >= landStop; }

    public void play() {
        if (playing) return;
        if (atLandStop()) seekTo(0);       // parado no pouso: recomeca
        clearHitstopNotice();
        playing = true;
        if (sound != null) sound.resumeAll();
        hideNotice();
        showLockNotice();
        lastMs = 0;
        acc = 0;
        notifyUi();
        invalidate();
    }

    public void pause() {
        if (sound != null) sound.pauseAll();
        if (!playing) return;
        playing = false;
        notifyUi();
        invalidate();
    }

    private void liveStep() { sim.step(); }

    public void togglePlay() { if (playing) pause(); else play(); }

    public boolean isPlaying() { return playing; }

    public void restart() { seekTo(0); }

    // ---- hitstop ao avancar tick pelo botao: o numero do tick trava e um aviso amarelo diz por quantos ticks ----
    private final HitstopNotice hsNotice = new HitstopNotice();
    private QuickNotice hsNoticeObj;

    /** Tick a mostrar no contador: travado enquanto o botao de tick passa pelo hitstop. */
    public int displayTick(int realTick) { return tickDisplay.shown(realTick); }

    private final CineNotice cineNotice = new CineNotice();
    private final TickDisplay tickDisplay = new TickDisplay();

    private void updateHitstopNotice() {
        if (cineNotice.active()) {                  // a trava cinematica tem prioridade: tudo esta congelado
            hsNoticeObj = new QuickNotice(cineNotice.text()).colors(QuickNotice.AMBER, QuickNotice.AMBER_BTN).duration(0)
                    .right("PULAR", new Runnable() { public void run() { skipCinematic(); } });
            showNotice(hsNoticeObj);
        } else if (hsNotice.active()) {
            hsNoticeObj = new QuickNotice(hsNotice.text()).colors(QuickNotice.AMBER, QuickNotice.AMBER_BTN).duration(0);
            showNotice(hsNoticeObj);
        } else dropNotices();
    }

    /** Timeline, barra, reproducao e voltar tick: sem aviso e o contador volta a mostrar o tick da simulacao. */
    private void clearHitstopNotice() {
        dropNotices();
        tickDisplay.reset();
    }

    /** Tira os avisos (o contador de ticks continua: ele so zera em {@link #clearHitstopNotice}). */
    private void dropNotices() {
        hsNotice.clear();
        cineNotice.clear();
        if (hsNoticeObj != null) {
            if (notice == hsNoticeObj) hideNotice();
            hsNoticeObj = null;
        }
    }

    public void stepForward() {
        pause();
        if (sim == null) return;
        if (frame + 1 >= length) return;          // avancar Frame nao da a volta: so a reproducao repete
        stopSounds();
        liveStep();
        frame++;
        hsNotice.afterStep(frame, sim.hitstopAttacker());
        cineNotice.afterStep(frame, sim.cinematicLeft());
        tickDisplay.afterStep(frame, hsNotice.active() || cineNotice.active());
        updateHitstopNotice();
        watchLanding();
        playSounds();
        notifyUi();
        invalidate();
    }

    /** PULAR do aviso da trava cinematica: passa por todos os ticks que faltam e libera o tick (sem tocar os sons dos ticks pulados). */
    public void skipCinematic() {
        if (sim == null) return;
        pause();
        int guard = 0;
        while (sim.cinematicActive() && frame + 1 < length && guard++ < 400) {
            liveStep();
            frame++;
            sim.drainSounds();
        }
        hsNotice.afterStep(frame, sim.hitstopAttacker());
        cineNotice.afterStep(frame, sim.cinematicLeft());
        tickDisplay.afterStep(frame, hsNotice.active() || cineNotice.active());      // liberou: o numero segue o travado + 1
        updateHitstopNotice();
        watchLanding();
        notifyUi();
        invalidate();
    }

    public void stepBack() {
        pause();
        if (frame <= 0) return;                   // voltar Frame nao pula para o fim
        seekTo(frame - 1);
    }

    public void seekTo(int target) {
        if (sim == null) return;
        int tg = Math.max(0, Math.min(length - 1, target));
        seekInternal(tg);
        acc = 0;
        lastMs = 0;
        notifyUi();
        invalidate();
    }

    private void seekInternal(int target) {
        clearHitstopNotice();                      // timeline, barra de progresso e voltar tick ignoram o aviso
        stopSounds();
        sim.reset();
        seekSnd.clear();
        seekTick.clear();
        for (int i = 0; i < target; i++) {
            sim.step();
            if (!sim.hasSounds()) continue;
            java.util.List<BattleSim.Snd> l = sim.drainSounds();      // sons dos frames pulados: nao tocam, mas os ainda audiveis voltam em finishSeek
            for (int k = 0; k < l.size(); k++) { seekSnd.add(l.get(k)); seekTick.add(Integer.valueOf(i + 1)); }
        }
        frame = target;
        landSeen = sim.landedEarly();
    }

    private final java.util.List<BattleSim.Snd> seekSnd = new java.util.ArrayList<BattleSim.Snd>();
    private final java.util.List<Integer> seekTick = new java.util.ArrayList<Integer>();

    /** Moveu a linha do tempo: os sons que ja tinham comecado e ainda estariam tocando entram a partir do ponto certo. */
    /** Soltou a barra da timeline: so agora entram os sons que ja estariam tocando nesse ponto (durante o arrasto nada toca, para nao pesar). */
    public void finishSeek() { startSeekSounds(frame, 0); }

    private void startSeekSounds(int target, int limitMs) {
        if (sound == null || !soundOn || data == null) return;
        for (int i = 0; i < seekSnd.size(); i++) {
            BattleSim.Snd s = seekSnd.get(i);
            int elapsed = (int) ((target - seekTick.get(i).intValue()) * 1000L / AttackSim.TICKS_PER_SECOND);
            if (elapsed < 0) continue;
            if (s.common) sound.playCommonFrom(s.id, elapsed, limitMs);
            else sound.playCharFrom(s.owner == 0 ? data.attacker.dir : data.opponent.dir, s.id, elapsed, limitMs);
        }
    }

    private void playSounds() {
        playSounds(sim.drainSounds());
    }

    /** Toca sons ja tirados de uma simulacao (a previa da reacao usa o mesmo mapeamento: comum / do personagem do dono). */
    public void playSounds(java.util.List<BattleSim.Snd> l) {
        if (sound == null || !soundOn || data == null) return;
        for (int i = 0; i < l.size(); i++) {
            BattleSim.Snd s = l.get(i);
            if (s.common) sound.playCommon(s.id);
            else sound.playChar(s.owner == 0 ? data.attacker.dir : data.opponent.dir, s.id);
        }
    }

    public void setSpeed(float s) { speed = s; acc = 0; lastMs = 0; }

    public int getFrame() { return frame; }
    public int getLength() { return length; }

    /** ANOs editados fora do ANO aberto (tela ANIM das cutscenes, Editar nos usos): o SALVAR do app grava tambem esses. */
    private final java.util.TreeSet<Integer> pendingAnos = new java.util.TreeSet<Integer>();
    public void markPendingAnos(java.util.Collection<Integer> idx) { pendingAnos.addAll(idx); }
    public java.util.Set<Integer> pendingAnos() { return java.util.Collections.unmodifiableSet(pendingAnos); }
    public void clearPendingAnos() { pendingAnos.clear(); }

    private String cutKey = "";
    private boolean[] cutTicks = new boolean[0];

    /** Ticks em que a cutscene do evento {@code ev} (do atacante) esta viva nesta simulacao; guardado ate a proxima edicao. */
    public boolean[] cutsceneTicks(int ev) {
        if (sim == null) return new boolean[0];
        String key = ev + ":" + editVersion + ":" + length + ":" + System.identityHashCode(data) + ":" + facingLeft + ":" + distance + ":" + height
                + ":" + BattleSim.cutscenes + ":" + BattleSim.edgeMode;
        if (!key.equals(cutKey)) { cutTicks = sim.cutsceneTicks(ev, length); cutKey = key; }
        return cutTicks;
    }

    /** Primeiro tick com a cutscene {@code ev} viva, ou -1 se ela nao aparece. */
    public int firstCutsceneTick(int ev) {
        boolean[] t = cutsceneTicks(ev);
        for (int i = 0; i < t.length; i++) if (t[i]) return i;
        return -1;
    }

    /** Dados carregados (atacante, golpe, indice); null sem dados. */
    public AttackData attackData() { return data; }

    /** Ticks do ANO (sem a fisica que o tempo estendido acrescenta depois); <= getLength(). */
    public int getAnoEnd() {
        if (ctxAno >= 0) { BattleSim.Trace t = ctxTrace(); if (t != null && t.last >= 0) return Math.min(length, t.last + 1); }
        return anoEnd;
    }
    private int anoEnd = 1;

    public void setListener(Listener l) { listener = l; notifyUi(); }

    // ---- opcoes visuais ----

    private boolean hideEff;
    /** HIDE-EFF: so desenha atacante e oponente (sem efeitos, auras, bobj nem projeteis). */
    public void setHideEff(boolean v) { hideEff = v; invalidate(); }
    public void setShowHits(boolean v) { opts.showHits = v; invalidate(); }
    public void setShowLinks(boolean v) { opts.showLinks = v; invalidate(); }

    private boolean spriteBoxes;
    public void setSpriteBoxes(boolean v) { spriteBoxes = v; invalidate(); }

    private boolean bodyOn;
    private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** CHAR OBJ: box do objeto de cada jogador (tamanho do HDAT 3) e ancoras: atacante BRANCA, oponente CIANO. */
    public void setCharObj(boolean on) { bodyOn = on; invalidate(); }
    public boolean isCharObj() { return bodyOn; }
    /** Modo das ancoras: false = Apenas Ancora, true = Ancora e Box. */
    public void setAnchorBox(boolean v) { opts.anchorBox = v; invalidate(); }
    public void setAnchors(boolean spr, boolean hurt, boolean hit, boolean fx, boolean global, boolean proj) {
        opts.anchorSpr = spr; opts.anchorHurt = hurt; opts.anchorHit = hit; opts.anchorFx = fx; opts.anchorGlobal = global; opts.anchorProj = proj; invalidate();
    }

    static final int BODY_ATTACKER = 0xFFFFFFFF, BODY_OPPONENT = 0xFF00E5FF;

    private void drawBodyBox(Canvas c, int x, int y, CharData cd, boolean main) {
        if (cd == null) return;
        float w = cd.bodyWidth(), h = cd.bodyHeight();
        float u = 1f / Math.max(0.01f, scale);
        int col = main ? BODY_ATTACKER : BODY_OPPONENT;
        bodyPaint.setStyle(Paint.Style.FILL);
        bodyPaint.setColor((col & 0x00FFFFFF) | (main ? 0x22000000 : 0x1E000000));
        c.drawRect(x - w / 2f, y - h, x + w / 2f, y, bodyPaint);
        bodyPaint.setStyle(Paint.Style.STROKE);
        bodyPaint.setStrokeWidth(1.5f * u);
        bodyPaint.setColor(col);
        c.drawRect(x - w / 2f, y - h, x + w / 2f, y, bodyPaint);
        c.drawLine(x - 6 * u, y, x + 6 * u, y, bodyPaint);
        c.drawLine(x, y - 6 * u, x, y + 6 * u, bodyPaint);
        bodyPaint.setStyle(Paint.Style.FILL);
    }
    public void setShowGrid(boolean v) { showGrid = v; invalidate(); }

    /** Camera da preview: 0 NORMAL (manual), 1 TELA (centraliza o retangulo azul da camera; com zoom ativo, segue o retangulo amarelo do zoom), 2 CHAR (centraliza os personagens, margem ~50 px). */
    private int centerMode;

    public void setCenterMode(int m) {
        centerMode = m;
        invalidate();
    }

    public int getCenterMode() { return centerMode; }

    /** CENTRO: TELA desenha como o jogo: a tela deste aparelho e o zoom/esticamento da camera por camada ({@link GameScreen}). */
    private boolean gameMode() { return centerMode == 1 && sim != null; }

    /** Ponto da view -> mundo {x, y, escala extra}: no modo TELA desfaz tambem a matriz da camera dos lutadores. */
    private float[] viewToWorld(float sx, float sy) {
        float gx = (sx - originX) / scale, gy = (sy - originY) / scale;
        if (!gameMode()) return new float[] {gx, gy, 1f};
        float[] m = sim.gameXform(GameScreenDraw.forContext(getContext()), GameScreenDraw.FIGHTER_KEY);
        return new float[] {(gx - m[2]) / m[0], (gy - m[3]) / m[1], m[0]};
    }

    /** save() + (no modo TELA) a matriz da camera do jogo para um objeto de chave {@code key} da simulacao {@code s}. */
    private void beginKey(Canvas c, BattleSim s, int key) {
        c.save();
        if (s == null) return;
        if (gameMode()) { GameScreenDraw.apply(c, s, GameScreenDraw.forContext(getContext()), key); return; }
        float[] w = s.worldViewXform(key);              // NORMAL/CHAR com zoom: o que fica fora da faixa da camera (Frente, efeito 328...) vai para o retangulo amarelo
        if (w != null) { c.translate(w[2], w[3]); c.scale(w[0], w[1]); }
    }

    /** Modos automaticos: ajusta zoom e posicao a cada desenho. */
    private void applyCamera() {
        if (centerMode == 0 || sim == null || getWidth() == 0 || getHeight() == 0) return;
        if (gameMode()) {                                   // TELA: a area de desenho do jogo neste aparelho, cada camada com a matriz da camera do jogo
            float[] f = GameScreenDraw.fit(GameScreenDraw.forContext(getContext()), getWidth(), getHeight());
            scale = f[0]; originX = f[1]; originY = f[2];
            originSet = true;
            return;
        }
        float[] bd = CameraModes.bounds(centerMode, sim);
        float x0 = bd[0], y0 = bd[1], x1 = bd[2], y1 = bd[3];
        float s = Math.min(getWidth() / (x1 - x0), getHeight() / (y1 - y0));
        scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, s));
        originX = getWidth() * 0.5f - (x0 + x1) * 0.5f * scale;
        originY = getHeight() * 0.5f - (y0 + y1) * 0.5f * scale;
        originSet = true;
    }

    public void recenter() {
        originX = getWidth() * 0.5f;
        originY = getHeight() * 0.55f;
        scale = Math.max(1f, density);
        // padrao: enquadra o mapa inteiro (bordas vermelhas visiveis); depois pan/zoom seguem livres
        if (sim != null && getWidth() > 0) {
            float ml = sim.mapLeft() / 65536f, mr = sim.mapRight() / 65536f;
            if (mr - ml > 50f) {
                float w = mr - ml + 40f;
                scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, getWidth() / w));
                originX = getWidth() * 0.5f - (ml + mr) * 0.5f * scale;
            }
        }
        originSet = true;
        invalidate();
    }

    /** Texto de depuracao do estado atual (frame raiz + erros de sprite). */
    /** true = lista de ANOs (move generico); false = lista de golpes. */
    public boolean isAnoMode() { return data != null && data.move.generic; }

    /** Texto de uma aba: "move", "ano", "frame" ou "links" (formato texto do DAC / HDAT 4). */
    public String info(String tab) {
        if (sim == null || data == null) return "";
        AttackSim.Obj r = sim.attacker().root();
        if ("move".equals(tab)) return InfoText.move(data);
        if ("frame".equals(tab)) return InfoText.frame(r);
        if ("links".equals(tab)) return InfoText.links(r);
        return InfoText.ano(r);
    }

    /** Muda quando o texto da aba muda (evita remontar o texto a cada tick). */
    public String infoKey(String tab) {
        if (sim == null || data == null) return "";
        AttackSim.Obj r = sim.attacker().root();
        int ano = r == null ? -1 : r.ano.index;
        int pat = r == null ? -1 : r.pat;
        boolean perFrame = "frame".equals(tab) || "ano".equals(tab);
        return tab + ":" + ano + ":" + editVersion + ":" + (perFrame ? pat : 0) + ":" + System.identityHashCode(data);
    }

    /** Indice do ANO mostrado (alvo da edicao) ou -1. */
    public int currentAnoIndex() {
        if (ctxAno >= 0) return ctxAno;
        AttackSim.Obj r = sim == null ? null : sim.timelineAtk().root();
        return r == null ? -1 : r.ano.index;
    }

    /** Linha de estado em tempo de execucao (2 linhas). */
    public String status() {
        if (sim == null) return "";
        String ev = sim.describeEvent().trim();
        return String.format(java.util.Locale.US, "t=%.2fs \u00b7 %s \u00b7 %s\nOPONENTE %s%s",
                frame / (double) AttackSim.TICKS_PER_SECOND, sim.attacker().describeMain(), sim.attacker().describeExtra(),
                sim.describeDefender(), ev.length() > 0 ? " \u00b7 " + ev : "");
    }

    // ---- API da timeline ----

    public Ano currentAno() {
        if (ctxAno >= 0) {
            ObjModel.setCurAno(ctxAno);
            return data == null || sim == null ? null : data.attacker.dac.getAno(ctxAno);
        }
        AttackSim.Obj r = sim == null ? null : sim.timelineAtk().root();
        ObjModel.setCurAno(r == null ? -1 : r.ano.index);
        return r == null ? null : r.ano;
    }

    /** Com a transicao travada: ticks desde que a ANO atual acabou (a timeline segue andando por todos os frames). */
    public int overTicks() {
        return BattleSim.lockFromTick >= 0 && sim != null ? sim.ticksSinceAnoEnd() : 0;
    }

    public int currentPat() {
        if (ctxAno >= 0) return sim == null ? -1 : ctxAt(frame)[0];
        AttackSim.Obj r = sim == null ? null : sim.timelineAtk().root();
        return r == null ? -1 : Math.min(r.pat, r.mpts.length - 1);   // depois do fim do ANO fica no ultimo frame
    }

    /** Ticks ja decorridos dentro do frame atual. */
    public int currentElapsed() {
        if (ctxAno >= 0) return sim == null ? 0 : ctxAt(frame)[1];
        AttackSim.Obj r = sim == null ? null : sim.timelineAtk().root();
        if (r == null || r.pat < 0 || r.mpts.length == 0) return 0;
        if (r.pat >= r.mpts.length) {                  // ANO acabou (so fisica depois): trava no fim do ultimo frame
            Ano.Mpt lm = r.mpts[r.mpts.length - 1];
            return lm.hasTime ? lm.time : 0;
        }
        int dur = r.mpts[r.pat].hasTime ? r.mpts[r.pat].time : 0;
        return Math.max(0, Math.min(dur, dur - r.time));
    }


    /** Como seekToPat, mas se o ponteiro ja esta dentro do frame ele fica onde esta. */
    public boolean seekToPatKeep(int pat) {
        if (currentPat() == pat) return true;
        return seekToPat(pat);
    }

    /** Vai para o primeiro tick em que o frame {@code pat} da ANO atual aparece (pausa). */
    public boolean seekToPat(int pat) {
        if (sim == null) return false;
        if (ctxAno >= 0) return ctxSeek(pat, -1);
        int t = sim.firstTickOf(currentAnoIndex(), pat, Math.max(length, 600));
        if (t < 0) t = currentAno() == null ? -1 : transitionTick(currentAno()) - 1;
        if (t < 0) return false;
        pause();
        seekTo(t);
        return true;
    }

    private int[] tickTable;
    private String tickTableKey = "";

    // ---- F-GHOST: previa semitransparente do frame seguinte / anterior ----
    private int ghostMode;                 // 0 desligado, 1 NEXT, 2 PREV
    private int ghostAlpha = 110;          // 0..255
    private BattleSim ghostSim;
    private String ghostKey = "";

    // ---- POSE: o ANO 0 (parado) por baixo do golpe, na mesma ancora, para comparar altura e tamanho ----
    private boolean poseOn;
    private AttackSim poseSim;
    private String poseKey = "";

    public void setPose(boolean on) { poseOn = on; poseSim = null; poseKey = ""; invalidate(); }
    public boolean isPose() { return poseOn; }

    /** Camada da pose parada (ANO 0 do atacante) no lugar do atacante; null se nao ha o que desenhar. */
    private BattleSim.Layer poseLayer() {
        if (sim == null || data == null || ctxAno >= 0) return null;
        AttackSim.Obj ar = sim.timelineAtk().root();
        if (ar == null) return null;
        boolean left = (ar.objFlags & 16) != 0;
        String key = editVersion + ":" + System.identityHashCode(data) + ":" + ar.x + ":" + ar.y + ":" + left;
        if (poseSim == null || !key.equals(poseKey)) {
            poseSim = new AttackSim(data.attacker.dac, 0, left, ar.x, ar.y);
            poseKey = key;
        }
        if (poseSim.root() == null) return null;
        BattleSim.Layer l = new BattleSim.Layer();
        l.sim = poseSim;
        l.owner = BattleSim.OWNER_ATTACKER;
        l.kind = 0;
        l.key = l.rootKey = GameScreenDraw.FIGHTER_KEY;
        return l;
    }

    public void setGhostMode(int m) { ghostMode = m; ghostKey = ""; ghostSim = null; invalidate(); }
    public int getGhostMode() { return ghostMode; }
    public void setGhostAlpha(int a) { ghostAlpha = Math.max(0, Math.min(255, a)); invalidate(); }
    public int getGhostAlpha() { return ghostAlpha; }
    private boolean ghostProj = true, ghostFx;
    public void setGhostProj(boolean v) { ghostProj = v; invalidate(); }
    public void setGhostFx(boolean v) { ghostFx = v; invalidate(); }
    public boolean isGhostProj() { return ghostProj; }
    public boolean isGhostFx() { return ghostFx; }
    private boolean ghostCurrent;
    public void setGhostCurrent(boolean v) { ghostCurrent = v; invalidate(); }
    public boolean isGhostCurrent() { return ghostCurrent; }

    private int[] tickTableFor(Ano a) {
        String key = a.index + ":" + a.mpts.length + ":" + editVersion + ":" + length + ":" + System.identityHashCode(data)
                + ":" + BattleSim.lockFromTick + ":" + BattleSim.landingOn + ":" + distance + ":" + height + ":" + BattleSim.oppHeightPx + ":" + BattleSim.extendTime;
        if (tickTable == null || !key.equals(tickTableKey)) {
            tickTable = sim.firstTicks(a.index, a.mpts.length, Math.max(length, 600));
            tickTableKey = key;
        }
        return tickTable;
    }

    private int[][] tickElapsed;
    private String tickElapsedKey = "";

    /** Tabela (frame, tick dentro do frame) -> tick da simulacao: a timeline conta so ticks de frame, entao o hitstop nao ocupa lugar nela. */
    private int[][] tickElapsedFor(Ano a) {
        tickTableFor(a);                              // atualiza tickTableKey
        if (tickElapsed == null || !tickTableKey.equals(tickElapsedKey)) {
            int[] dur = new int[a.mpts.length];
            for (int i = 0; i < dur.length; i++) dur[i] = a.mpts[i].hasTime ? a.mpts[i].time : 0;
            tickElapsed = sim.firstTicksElapsed(a.index, dur, Math.max(length, 600));
            tickElapsedKey = tickTableKey;
        }
        return tickElapsed;
    }

    /** Combate parado no primeiro tick do frame vizinho do atual, ou null. */
    private BattleSim ghost() {
        if (ctxAno >= 0) return null;                       // contexto: o ANO alvo nao e o lutador
        Ano a = currentAno();
        if (sim == null || a == null) return null;
        int target = currentPat() + (ghostMode == 1 ? 1 : -1);
        if (target < 0 || target >= a.mpts.length) return null;
        int base = tickTableFor(a)[target];
        if (base < 0) return null;
        String key = tickTableKey + ":" + target;
        if (!key.equals(ghostKey)) {
            ghostSim = sim.copyAt(base);
            ghostKey = key;
        }
        return ghostSim;
    }

    // ---- SPEEDLINE: pontos e linhas verdes da trajetoria do movimento (arrastar muda so a speed; tocar abre o menu do ponto) ----
    private boolean speedLineOn;
    private String slKey = "";
    private double[][] slAnchor = new double[0][];           // por cadeia: {x, y, lado x, lado y} do personagem no inicio da cadeia
    private Ano.Mpt[] slWork;                                // durante o arrasto: os frames ja editados (so na tela; grava ao soltar)
    private int slDragHead = -1, slDragK = -1, slDragMode;
    private float slDownX, slDownY;
    private boolean slMoved;

    public void setSpeedLine(boolean on) { speedLineOn = on; slKey = ""; slWork = null; slDragHead = -1; invalidate(); }
    public boolean isSpeedLine() { return speedLineOn; }

    /** Ancoras (posicao do personagem no inicio de cada cadeia de movimento) da ANO atual; refeitas quando a edicao muda. */
    private void slPrepare(Ano a) {
        int[] tt = tickTableFor(a);
        String key = tickTableKey + ":" + System.identityHashCode(a.mpts);
        if (key.equals(slKey) && slWork == null) return;
        if (slWork != null && slAnchor.length > 0) return;       // arrastando: mantem as ancoras
        java.util.List<SpeedLine.Chain> chains = SpeedLine.chains(a.mpts);
        double[][] an = new double[chains.size()][];
        for (int i = 0; i < an.length; i++) {
            int t = chains.get(i).head < tt.length ? tt[chains.get(i).head] : -1;
            if (t < 0) continue;
            BattleSim s = sim.copyAt(t);
            AttackSim.Obj r = s.timelineAtk().root();
            if (r == null) continue;
            an[i] = new double[] {r.x / 65536.0, r.y / 65536.0, (r.objFlags & 16) != 0 ? -1 : 1, (r.objFlags & 32) != 0 ? -1 : 1};
        }
        slAnchor = an;
        slKey = key;
    }

    /** Cadeia (e seu indice nas ancoras) que contem o frame atual; null se ele nao se move. */
    private SpeedLine.Chain slCurrentChain(Ano.Mpt[] m, int[] ciOut) {
        java.util.List<SpeedLine.Chain> chains = SpeedLine.chains(m);
        int cur = currentPat();
        for (int ci = 0; ci < chains.size() && ci < slAnchor.length; ci++) {
            SpeedLine.Chain ch = chains.get(ci);
            if (cur >= ch.head && cur <= ch.last && slAnchor[ci] != null) { ciOut[0] = ci; return ch; }
        }
        return null;
    }

    private double[] slWorld(double[] an, double[] p) { return new double[] {an[0] + an[2] * p[0], an[1] + an[3] * p[1]}; }

    /** SPEEDLINE: so o movimento do Frame atual. Um ponto onde o Frame comeca e uma seta ate onde ele termina; se o movimento para, a seta acaba num ponto. */
    private void drawSpeedLine(Canvas c) {
        if (ctxAno >= 0) return;
        Ano a = currentAno();
        if (!speedLineOn || a == null || sim == null) return;
        slPrepare(a);
        Ano.Mpt[] m = slWork != null ? slWork : a.mpts;
        int[] ci = new int[1];
        SpeedLine.Chain ch = slCurrentChain(m, ci);
        if (ch == null) return;
        double[] an = slAnchor[ci[0]];
        int cur = currentPat();
        SpeedLine.Arrow ar = SpeedLine.frameArrow(m, ch, cur);
        if (ar == null) return;
        float sw = Math.max(0.5f, 2.2f * density / scale), dot = 4.5f * density / scale;
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(sw);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(0xE63DDC84);
        android.graphics.Path path = new android.graphics.Path();
        double[] s0 = slWorld(an, ar.path[0]);
        path.moveTo((float) s0[0], (float) s0[1]);
        for (int i = 1; i < ar.path.length; i++) {
            double[] w = slWorld(an, ar.path[i]);
            path.lineTo((float) w[0], (float) w[1]);
        }
        c.drawPath(path, line);
        double[] e = slWorld(an, ar.to());
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFF3DDC84);
        double dxe = 0, dye = 0;
        for (int i = ar.path.length - 1; i > 0 && dxe == 0 && dye == 0; i--) {         // direcao da ultima parte que anda
            double[] w1 = slWorld(an, ar.path[i]), w0 = slWorld(an, ar.path[i - 1]);
            dxe = w1[0] - w0[0];
            dye = w1[1] - w0[1];
        }
        double len = Math.hypot(dxe, dye);
        if (ar.stops || len < 1e-6) {
            c.drawCircle((float) e[0], (float) e[1], dot * 1.2f, fill);              // o movimento para aqui: ponto no fim
        } else {
            float ux = (float) (dxe / len), uy = (float) (dye / len), h = dot * 2.6f;
            android.graphics.Path head = new android.graphics.Path();                 // ponta da seta
            head.moveTo((float) e[0] + ux * h * 0.4f, (float) e[1] + uy * h * 0.4f);
            head.lineTo((float) e[0] - ux * h * 0.6f - uy * h * 0.5f, (float) e[1] - uy * h * 0.6f + ux * h * 0.5f);
            head.lineTo((float) e[0] - ux * h * 0.6f + uy * h * 0.5f, (float) e[1] - uy * h * 0.6f - ux * h * 0.5f);
            head.close();
            c.drawPath(head, fill);
        }
        fill.setColor(0xFFB6FFD6);                                                    // ponto onde o Frame comeca (toque = menu)
        c.drawCircle((float) s0[0], (float) s0[1], dot * 1.8f, fill);
        fill.setStyle(Paint.Style.STROKE);
        fill.setStrokeWidth(sw);
        fill.setColor(0xFFFFFFFF);
        c.drawCircle((float) s0[0], (float) s0[1], dot * 1.8f, fill);
        Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG), outline = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        outline.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        outline.setStyle(Paint.Style.STROKE);
        outline.setColor(0xE60D0F13);
        float size = 13f * density / scale;
        txt.setTextSize(size);
        outline.setTextSize(size);
        outline.setStrokeWidth(3f * density / scale);
        txt.setColor(0xFFFFFFFF);
        String label = String.valueOf(cur + 1);
        float tx = (float) s0[0] + dot * 2.2f, ty = (float) s0[1] - dot * 1.6f;
        c.drawText(label, tx, ty, outline);
        c.drawText(label, tx, ty, txt);
        double[] pos = ch.posAt(m, cur, currentElapsed());                           // o personagem andando dentro do Frame
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFFFE066);
        c.drawCircle((float) (an[0] + an[2] * pos[0]), (float) (an[1] + an[3] * pos[1]), dot * 0.9f, fill);
    }

    /** Alvo sob o dedo: o ponto onde o Frame atual comeca (modo 0: toque abre o menu) ou a ponta da seta (modo 1: arrastar muda a speed; toque abre o menu). {cabeca da cadeia, indice, modo}. */
    private int[] slHit(float sx, float sy) {
        Ano a = currentAno();
        if (!speedLineOn || a == null || sim == null || ctxAno >= 0) return null;
        slPrepare(a);
        int[] ci = new int[1];
        SpeedLine.Chain ch = slCurrentChain(a.mpts, ci);
        if (ch == null) return null;
        SpeedLine.Arrow ar = SpeedLine.frameArrow(a.mpts, ch, currentPat());
        if (ar == null) return null;
        double[] an = slAnchor[ci[0]];
        float[] w = viewToWorld(sx, sy);
        float wx = w[0], wy = w[1];
        double rad = 28f * density / (scale * w[2]), best = rad * rad;
        double[] st = slWorld(an, ar.from()), en = slWorld(an, ar.to());
        double ds = (st[0] - wx) * (st[0] - wx) + (st[1] - wy) * (st[1] - wy);
        double de = (en[0] - wx) * (en[0] - wx) + (en[1] - wy) * (en[1] - wy);
        int k = currentPat() - ch.head;
        if (de <= best && de <= ds) return new int[] {ch.head, k + 1, 1};          // empate: a ponta (e a que da para arrastar quando o Frame esta parado)
        if (ds <= best) return new int[] {ch.head, k, 0};
        return null;
    }

    /** Alvo do arrasto no sistema da cadeia (relativo ao inicio dela, como se olhasse para a direita). */
    private void slDragTo(float sx, float sy) {
        Ano a = currentAno();
        if (a == null) return;
        Ano.Mpt[] base = a.mpts;
        java.util.List<SpeedLine.Chain> chains = SpeedLine.chains(base);
        for (int ci = 0; ci < chains.size() && ci < slAnchor.length; ci++) {
            SpeedLine.Chain ch = chains.get(ci);
            if (ch.head != slDragHead || slAnchor[ci] == null) continue;
            double[] an = slAnchor[ci];
            float[] w = viewToWorld(sx, sy);
            double rx = (w[0] - an[0]) / an[2], ry = (w[1] - an[1]) / an[3];
            slWork = SpeedLine.dragTo(base, ch, slDragK, rx, ry);
            invalidate();
            return;
        }
    }

    /** Chamado pela UI do menu do ponto: cadeia que comeca em {@code head} na ANO atual (ou null). */
    SpeedLine.Chain speedLineChain(int head) {
        Ano a = currentAno();
        if (a == null) return null;
        for (SpeedLine.Chain c : SpeedLine.chains(a.mpts)) if (c.head == head) return c;
        return null;
    }

    /** Arrastar a timeline: vai para {@code elapsed} ticks dentro do frame {@code pat} da ANO atual (pausa). */
    public void seekToPatTick(int pat, int elapsed) {
        if (ctxAno >= 0) { if (!ctxSeek(pat, elapsed)) ctxSeek(pat, -1); return; }
        Ano a = currentAno();
        if (sim == null || a == null || pat < 0 || pat >= a.mpts.length) return;
        int base = tickTableFor(a)[pat];
        int tt = transitionTick(a);
        int limit = tt < 0 ? Integer.MAX_VALUE : tt - 1;     // arrastar nunca faz a troca: trava no ultimo tick antes dela
        int[][] te = tickElapsedFor(a);
        int exact = elapsed >= 0 && pat < te.length && elapsed < te[pat].length ? te[pat][elapsed] : -1;     // ticks so da simulacao (hitstop) nao contam
        int target = exact >= 0 ? Math.min(exact, limit) : (base < 0 ? limit : Math.min(base + elapsed, limit));
        if (target == Integer.MAX_VALUE || target < 0) return;
        pause();
        seekTo(target);
    }

    /** Contexto: vai ao primeiro tick em que o ANO alvo esta no frame {@code pat} (e com {@code elapsed} ticks decorridos, se >= 0). */
    private boolean ctxSeek(int pat, int elapsed) {
        BattleSim.Trace t = ctxTrace();
        if (t == null) return false;
        for (int i = Math.max(0, t.first); i < t.pat.length && i < length; i++) {
            if (t.pat[i] == pat && (elapsed < 0 || t.elapsed[i] == elapsed)) { pause(); seekTo(i); return true; }
        }
        return false;
    }

    /** Tick em que a primeira troca real de ANO sai desta ANO, ou -1. */
    private int transitionTick(Ano a) {
        if (sim == null) return -1;
        int best = -1;
        for (BattleSim.Trans t : sim.transitions()) if (t.kind <= SeqMark.HIT && t.fromAno == a.index && (best < 0 || t.tick < best)) best = t.tick;
        return best;
    }

    /** Troca um MPT da ANO atual (coalescendo edicoes seguidas do mesmo frame). */
    /** Depois de algo mexer no DAC/sprites por fora do editor de frames (lista de sprites): refaz a simulacao. */
    public void refreshAfterExternalEdit() {
        editVersion++;
        if (data != null) rebuild(frame);
        invalidate();
    }

    public void changeMpt(final int pat, Ano.Mpt m) {
        final Ano a = currentAno();
        if (a == null || pat < 0 || pat >= a.mpts.length) return;
        m.normalize();
        final Ano.Mpt prev = a.mpts[pat];
        a.mpts[pat] = m;
        pushUndo("m:" + a.index + ":" + pat, UndoEdits.swapMpts(a, new int[] {pat}, new Ano.Mpt[] {prev}));
        editVersion++;
        rebuild(frame);
    }

    /** Troca varios MPTs de uma vez (um unico desfazer e uma unica reconstrucao). */
    public void changeMpts(final int[] pats, Ano.Mpt[] ms) {
        final Ano a = currentAno();
        if (a == null || pats.length == 0) return;
        final Ano.Mpt[] prev = new Ano.Mpt[pats.length];
        for (int i = 0; i < pats.length; i++) {
            if (pats[i] < 0 || pats[i] >= a.mpts.length) return;
            prev[i] = a.mpts[pats[i]];
        }
        for (int i = 0; i < pats.length; i++) { ms[i].normalize(); a.mpts[pats[i]] = ms[i]; }
        pushUndo("r:" + a.index + ":" + pats[0] + ":" + pats.length, UndoEdits.swapMpts(a, pats, prev));
        editVersion++;
        rebuild(frame);
    }

    /** true enquanto o usuario liga/desliga o loop: ai a normalizacao do loop nao pode desfazer o gesto. */
    private boolean rawLoopEdit;

    /** O loop e do ANO: se estava no ultimo frame, acompanha o novo ultimo frame depois de qualquer edicao. */
    private Ano withLoopKept(Ano old, Ano na) {
        if (rawLoopEdit || old == null || na == null) return na;
        Ano.Mpt[] fixed = FrameOps.normalizeLoop(old.mpts, na.mpts);
        return fixed == na.mpts ? na : new Ano(na.index, na.present, na.flags, na.priority, na.links, fixed);
    }

    /** Liga/desliga o loop da ANO atual (unico caminho que pode desligar o loop). */
    public void setLoop(boolean on) {
        Ano old = currentAno();
        if (old == null) return;
        rawLoopEdit = true;
        try { replaceMpts(ObjModel.setLoop(old.mpts, on)); } finally { rawLoopEdit = false; }
    }

    /** Troca a lista de MPTs da ANO atual (dividir, apagar, duplicar...). */
    public void replaceMpts(Ano.Mpt[] mp) {
        Ano old = currentAno();
        if (old == null) return;
        replaceAno(new Ano(old.index, true, old.flags, old.priority, old.links, mp));
    }

    /** Troca a ANO atual inteira (adicionar/remover frames, links). */
    public void replaceMpts(Ano.Mpt[] mp, String undoKey) {
        Ano old = currentAno();
        if (old == null) return;
        replaceAno(new Ano(old.index, true, old.flags, old.priority, old.links, mp), undoKey);
    }

    public void replaceAno(Ano na) { replaceAno(na, null); }

    /** undoKey != null: edicoes seguidas com a mesma chave (4 s) viram um unico desfazer. */
    public void replaceAno(Ano na, String undoKey) {
        final Ano old = currentAno();
        if (old == null || data == null) return;
        na = withLoopKept(old, na);
        final Dac dac = data.attacker.dac;
        final int idx = old.index;
        dac.setAno(idx, na);
        pushUndo(undoKey, UndoEdits.swapAno(dac, idx, old));
        editVersion++;
        rebuild(frame);
    }

    // ---- acesso para a timeline por sprite ----

    /** Move (HDAT 4) em edicao; null sem dados. */
    public CharData.Move moveData() { return data == null ? null : data.move; }

    /** Miniaturas e previas: SpriteCache do atacante. */
    public SpriteCache attackerSprites() { return data == null ? null : data.attacker.sprites; }

    /** Pacote de animacoes: 0 = effect.pac, 1 = charf, 2 = personagem. */
    public Dac packDac(int pack) {
        if (data == null) return null;
        if (pack == 0) return data.effects == null ? null : data.effects.dac;
        if (pack == 1) return data.charf == null ? null : data.charf.dac;
        if (pack == 3) return data.bobj == null ? null : data.bobj.dac;           // bobj do cenario (poeira dos tipos 1-5)
        return data.attacker.dac;
    }

    public SpriteCache packSprites(int pack) {
        if (data == null) return null;
        if (pack == 0) return data.effects == null ? null : data.effects.sprites;
        if (pack == 1) return data.charf == null ? null : data.charf.sprites;
        if (pack == 3) return data.bobj == null ? null : data.bobj.sprites;
        return data.attacker.sprites;
    }

    /** Qualquer ANO do DAC do atacante (ex.: a do projetil). */
    public Ano anoAt(int index) { return data == null ? null : data.attacker.dac.getAno(index); }

    /** Troca uma ANO qualquer do DAC do atacante (com desfazer); reconstroi a simulacao. */
    public void replaceAnoAt(Ano na) {
        if (data == null) return;
        final Dac dac = data.attacker.dac;
        final int idx = na.index;
        final Ano old = dac.getAno(idx);
        dac.setAno(idx, na);
        pushUndo(null, UndoEdits.swapAno(dac, idx, old));
        editVersion++;
        rebuild(frame);
    }

    // ---- reacoes (previa e edicao) ----

    public Dac opponentDac() { return data == null ? null : data.opponent.dac; }
    public GameData gameDataObj() { return data == null ? null : data.gameData; }
    public CharData attackerCharData() { return data == null ? null : data.attacker.data; }
    public SpriteCache opponentSprites() { return data == null ? null : data.opponent.sprites; }

    /** Tabela de reacao do char do atacante (tipo 0..19 = indice 30..49 do OPT 1). */
    public ReactionTable charReaction(int type) { return data == null ? null : data.attacker.data.reaction(type); }

    public ReactionTable gameReaction(int type) { return data == null || data.gameData == null ? null : data.gameData.reaction(type); }

    /** Existe tabela para o indice 0..49 do OPT 1 (0-29 gamedata, 30-49 char do atacante)? */
    public boolean hasReaction(int index) {
        if (data == null) return false;
        ReactionTable t = index >= 30 ? data.attacker.data.reaction(index - 30)
                : (data.gameData == null ? null : data.gameData.reaction(index));
        return t != null && t.rows > 0;
    }

    /** Nova simulacao so para previa de reacao: o defensor recebe o OPT 1 (use BattleSim.forceHit). */
    /** Simulacao para o editor de reacoes. {@code hit}: o golpe real acertou a reacao editada; {@code sim} esta logo ANTES do tick do hit (hit) ou no tick 0 (sem hit). */
    public static final class ReactionRun {
        public BattleSim sim;
        public boolean hit;
        /** Ticks que a previa deve andar: a reacao toda (hit; o trace decide) ou ate nada mais animar (sem hit). */
        public int quietTicks;
    }

    private String hitKey = "";
    private int hitTicks = -1, hitQuiet;

    /** O BattleSim do golpe atual igual ao do rebuild() (posicoes, alturas, FLY, virar, POS ESQ/MEIO/DIR da principal), no modo reacao: atacante para no fim do frame da hitbox. */
    private BattleSim newMainSim(int ano, int pat) {
        BattleSim s = new BattleSim(data.attacker.dac, data.attacker.data, data.move, facingLeft, data.opponent.dac, data.effects == null ? null : data.effects.dac,
                data.gameData, distance, height, data.attacker.wavCount);
        s.setOpponentChar(data.opponent.data);
        s.setSpecialType(data.moveIndex);
        if (data.charf != null) s.setCharfDac(data.charf.dac);
        if (data.bobj != null) s.setBobjDac(data.bobj.dac);
        s.setReactionMode(true, ano, pat);
        return s;
    }

    /** O lado para onde o atacante olha (VIRAR). */
    public boolean isFacingLeft() { return facingLeft; }

    /**
     * Sim do golpe com a distancia {@code dist} e a altura do oponente {@code oppH} dadas (sem mudar as da tela), andado ate o atacante parar no fim do frame da hitbox
     * ({@code ano}, {@code pat}); null se ele nunca chega la. Usado pelo REPOSICIONAR do editor de reacoes.
     */
    public BattleSim newHeldSim(int ano, int pat, int dist, int oppH) {
        if (data == null || data.move == null) return null;
        int oldD = distance, oldH = BattleSim.oppHeightPx;
        try {
            distance = Math.max(0, Math.min(480, dist));
            BattleSim.oppHeightPx = Math.max(0, Math.min(200, oppH));
            BattleSim s = newMainSim(ano, pat);
            for (int i = 0; i < ReactionHit.MAX_TICKS; i++) {
                if (s.attackerHeld()) return s;
                s.step();
            }
            return s.attackerHeld() ? s : null;
        } finally { distance = oldD; BattleSim.oppHeightPx = oldH; }
    }

    /**
     * Previa do editor de reacoes: o GOLPE REAL (mesmas posicoes da edicao principal) ate o hit que usa a reacao {@code type}/{@code charSrc}; o atacante termina o
     * frame da hitbox ({@code ano}, {@code pat}) e para. Se o golpe NAO acerta nessa posicao nao ha hit forcado: o atacante para igual e o oponente fica no idle.
     */
    public ReactionRun newReactionRun(int ano, int pat, int type, boolean charSrc) {
        ReactionRun run = new ReactionRun();
        if (data == null || data.move == null) return run;
        String key = editVersion + ":" + System.identityHashCode(data) + ":" + distance + ":" + height + ":" + facingLeft + ":" + BattleSim.oppHeightPx + ":" + BattleSim.flyMode
                + ":" + BattleSim.defend + ":" + BattleSim.mapPos + ":" + ano + ":" + pat + ":" + type + ":" + charSrc;
        if (!key.equals(hitKey)) {
            hitKey = key;
            BattleSim probe = newMainSim(ano, pat);
            hitTicks = ReactionHit.ticksBeforeHit(probe, type, charSrc, ReactionHit.MAX_TICKS);
            if (hitTicks < 0) hitQuiet = ReactionHit.ticksUntilQuiet(newMainSim(ano, pat), ReactionHit.MAX_TICKS);
        }
        BattleSim s = newMainSim(ano, pat);
        run.hit = hitTicks >= 0;
        run.quietTicks = run.hit ? 0 : hitQuiet;
        for (int i = 0; i < Math.max(0, hitTicks); i++) s.step();
        s.drainSounds();
        run.sim = s;
        return run;
    }

    /** Simulacao simples (so o oponente) para as previas pequenas das grades: o OPT 1 e forcado. */
    public BattleSim newReactionSim() {
        if (data == null) return null;
        BattleSim s = new BattleSim(data.attacker.dac, data.attacker.data, CharData.blank(0), false,
                data.opponent.dac, data.effects == null ? null : data.effects.dac, data.gameData,
                100, 0, data.attacker.wavCount);
        s.setOpponentChar(data.opponent.data);
        return s;
    }

    /** Edita uma tabela de reacao do char em runtime (com desfazer); reconstroi a simulacao. */
    public void editReaction(int type, Runnable change) {
        final ReactionTable t = charReaction(type);
        if (t == null) return;
        final ReactionTable before = t.copy();
        change.run();
        pushUndo(null, UndoEdits.swapReaction(t, before));
        editVersion++;
        rebuild(frame);
    }

    private final Runnable reactionRebuild = new Runnable() { public void run() { reactionRebuildPending = false; if (data != null) rebuild(frame); } };
    private boolean reactionRebuildPending;

    /**
     * Edicao rapida de uma tabela de reacao (campo digitado ou - / + segurado): grava na hora, junta as edicoes seguidas de {@code key}
     * numa unica entrada de desfazer e refaz a simulacao principal uma vez, 250 ms depois da ultima edicao (ou em {@link #flushReactionEdit}).
     */
    public void editReaction(int type, String key, Runnable change) {
        final ReactionTable t = charReaction(type);
        if (t == null) return;
        final ReactionTable before = t.copy();
        change.run();
        pushUndo(key, UndoEdits.swapReaction(t, before));
        editVersion++;
        removeCallbacks(reactionRebuild);
        reactionRebuildPending = true;
        postDelayed(reactionRebuild, 250);
    }

    /** Se uma edicao rapida de reacao ainda espera a simulacao, refaz agora (ao fechar o editor, por exemplo). */
    public void flushReactionEdit() {
        if (!reactionRebuildPending) return;
        removeCallbacks(reactionRebuild);
        reactionRebuildPending = false;
        if (data != null) rebuild(frame);
    }

    /** Edita o golpe (HDAT 4) em runtime: executa a mudanca, empilha o desfazer e reconstroi a simulacao. */
    public void editMove(Runnable change) {
        if (data == null) return;
        final CharData.Move mv = data.move;
        final CharData.Move before = mv.copy();
        change.run();
        pushUndo(null, UndoEdits.swapMove(mv, before, null));
        editVersion++;
        rebuild(frame);
    }

    /** Ouve o SE do jeito que o jogo toca (ids < 80 sao comuns). */
    /** WAVs do personagem mudaram (adicionado/trocado/mutado): recontagem e nova simulacao. */
    public void soundsChanged(java.io.File wav) {
        if (data == null) return;
        if (sound != null && wav != null) sound.invalidate(wav);
        data.attacker.refreshWavCount();
        if (data.opponent != data.attacker) data.opponent.refreshWavCount();
        rebuild(frame);
    }

    /**
     * Tira de todas as ANOs do DAC do atacante os frames que tocam algum dos sons {@code ses} (flag de som desligada, se = -1).
     * Uma unica entrada de desfazer. Devolve quantos frames mudaram.
     */
    public int clearSoundUses(java.util.Set<Integer> ses) {
        if (data == null || ses.isEmpty()) return 0;
        final Dac dac = data.attacker.dac;
        final java.util.ArrayList<Ano> olds = new java.util.ArrayList<Ano>();
        int frames = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            Ano.Mpt[] ms = a.mpts;
            Ano.Mpt[] nm = null;
            for (int k = 0; k < ms.length; k++) {
                Ano.Mpt m = ms[k];
                if ((m.flags & 8) == 0 || !ses.contains(Integer.valueOf(m.se))) continue;
                if (nm == null) nm = ms.clone();
                Ano.Mpt c = m.copy();
                c.flags &= ~8;
                c.se = -1;
                nm[k] = c;
                frames++;
            }
            if (nm != null) {
                olds.add(a);
                dac.setAno(i, new Ano(a.index, a.present, a.flags, a.priority, a.links, nm));
            }
        }
        if (frames == 0) return 0;
        pushUndo(null, UndoEdits.swapAnos(dac, olds));
        editVersion++;
        rebuild(frame);
        return frames;
    }

    /** Para qualquer som de previa que esteja tocando (menu fechado, outro som escolhido). */
    public void stopSounds() { if (sound != null) sound.stopAll(); }

    public void previewSe(int se) {
        if (sound == null || data == null || se < 0) return;
        sound.stopAll();
        if (SoundIds.isCharId(se)) { sound.playChar(data.attacker.dir, se - SoundIds.CHAR_FIRST); return; }
        int n = SoundIds.commonOf(se);
        if (n >= 0) sound.playCommon(n);
    }

    private final UndoHistory history = new UndoHistory();

    private void pushUndo(String key, UndoHistory.Edit e) { history.push(key, SystemClock.uptimeMillis(), e); }

    // ---- edicao em runtime ----

    private int editVersion;

    /** Passos para desfazer no escopo ativo (o menu aberto, ou as acoes ja aplicadas). */
    public int undoCount() { return history.count(); }
    public boolean canUndo() { return history.canUndo(); }
    public boolean canRedo() { return history.canRedo(); }
    public boolean inUndoSession() { return history.inSession(); }

    /** Proxima edicao nunca se funde com a anterior. */
    public void breakUndo() { history.breakMerge(); }

    /** Abre a sessao de desfazer de um menu: desfazer/refazer valem so dentro dele ate APLICAR (vira uma entrada so) ou fechar (descarta). */
    public void beginUndoSession() { history.begin(); }
    public void commitUndoSession() { history.commit(); }

    /** Fechar sem aplicar: desfaz o que restou do menu. Devolve quantos passos desfez. */
    public int discardUndoSession() {
        int n = history.discard();
        if (n > 0) { editVersion++; if (data != null) rebuild(frame); }
        return n;
    }

    public boolean undoEdit() {
        if (!history.undo()) return false;
        editVersion++;
        if (data != null) rebuild(frame);
        return true;
    }

    public boolean redoEdit() {
        if (!history.redo()) return false;
        editVersion++;
        if (data != null) rebuild(frame);
        return true;
    }

    // ---- sequencia: marcadores calculados pela simulacao + edicao dos campos do golpe ----

    private java.util.List<SeqMark> seqMarks = new java.util.ArrayList<SeqMark>();
    private String seqKey = "";

    /** Hits que conectariam (e trocariam de ANO) se o golpe comecasse na ANO dada; vazio sem simulacao. Pesado: chamar fora da UI thread. */
    public java.util.List<BattleSim.HitEvent> probeHits(int ano) {
        BattleSim s = sim;
        return s == null ? new java.util.ArrayList<BattleSim.HitEvent>() : s.probeHits(ano);
    }

    /** Hits que conectam no ANO atual e disparariam ANIM_SEQ / ANIM_END (cache; recalcula so quando algo muda). */
    public java.util.List<SeqMark> sequenceMarks() {
        Ano a = sim == null ? null : currentAno();
        if (a == null || data == null || data.move == null || data.move.generic || ctxAno >= 0) {
            if (!seqMarks.isEmpty()) seqMarks = new java.util.ArrayList<SeqMark>();
            return seqMarks;
        }
        CharData.Move mv = data.move;
        String key = a.index + ":" + editVersion + ":" + System.identityHashCode(data) + ":" + distance + ":" + height + ":" + BattleSim.oppHeightPx
                + ":" + mv.animSeqChao + ":" + mv.animSeqAr + ":" + mv.animEndChao + ":" + mv.animEndAr
                + ":" + mv.animAoAcertar + ":" + BattleSim.lockFromTick + ":" + BattleSim.landingOn + ":" + sim.transitions().size() + ":" + BattleSim.extendTime
                + ":" + mv.flags + ":" + data.attacker.data.pullDistance() + ":" + mv.animInicial;
        if (key.equals(seqKey)) return seqMarks;
        seqKey = key;
        java.util.List<SeqMark> out = new java.util.ArrayList<SeqMark>();
        java.util.HashSet<Integer> seen = new java.util.HashSet<Integer>();
        for (BattleSim.HitEvent e : sim.probeHits(a.index)) {
            if (e.kind > SeqMark.HIT || e.ano != a.index || !seen.add(e.pat * 8 + e.kind)) continue;
            SeqMark m = new SeqMark();
            m.kind = e.kind; m.pat = e.pat; m.target = e.target; m.target2 = e.target2; m.air = e.air; m.blocked = e.blocked; m.projectile = e.projectile;
            out.add(m);
        }
        for (BattleSim.Trans t : sim.transitions()) {
            if (t.kind < 0 || t.kind > SeqMark.HIT) continue;      // pouso e queda sao fisica, nao algo editavel
            if (t.fromAno == a.index) {
                SeqMark hit = null;
                for (SeqMark q : out) if (q.kind == t.kind && q.pat == t.fromPat && !q.incoming) hit = q;
                if (hit == null) {
                    hit = new SeqMark();
                    hit.kind = t.kind; hit.pat = t.fromPat; hit.target = t.toAno;
                    out.add(hit);
                }
                hit.real = true; hit.tick = t.tick;
            }
            if (t.toAno == a.index && t.fromAno != a.index) {
                SeqMark in = new SeqMark();
                in.kind = t.kind; in.pat = 0; in.incoming = true; in.real = true;
                in.fromAno = t.fromAno; in.fromPat = t.fromPat; in.tick = t.tick; in.target = t.toAno;
                out.add(in);
            }
        }
        // simplifica: por tipo, so a troca que de fato vale (a real, ou a primeira que conecta); bloqueadas antes dela continuam para poder desbloquear
        java.util.Collections.sort(out, new java.util.Comparator<SeqMark>() {
            @Override public int compare(SeqMark x, SeqMark y) { return x.pat != y.pat ? x.pat - y.pat : x.kind - y.kind; }
        });
        java.util.List<SeqMark> kept = new java.util.ArrayList<SeqMark>();
        for (SeqMark q : out) if (q.incoming) kept.add(q);
        for (int k = 0; k <= SeqMark.HIT; k++) {
            boolean realExists = false;
            for (SeqMark q : out) if (q.kind == k && q.real && !q.incoming) realExists = true;
            for (SeqMark q : out) {
                if (q.kind != k || q.incoming) continue;
                if (q.real) { kept.add(q); break; }
                if (q.blocked) { kept.add(q); continue; }
                if (realExists) continue;
                kept.add(q);
                break;
            }
        }
        // agarrao (md 882): no fim do ANO inicial, ou no 1o frame com a janela 512; e quase uma transicao (vai para ANIM_INICIAL + 1)
        if (mv.grabWorks() && a.index == mv.animInicial) {
            int gp = a.mpts.length - 1;
            for (int i = 0; i < a.mpts.length; i++) if (ObjModel.optFlagBit(a.mpts[i], ObjModel.VF_WINDOW)) { gp = i; break; }
            SeqMark g = new SeqMark();
            g.kind = SeqMark.GRAB; g.pat = gp; g.target = a.index + 1;
            kept.add(g);
        }
        out = kept;
        java.util.Collections.sort(out, new java.util.Comparator<SeqMark>() {
            @Override public int compare(SeqMark x, SeqMark y) { return x.pat != y.pat ? x.pat - y.pat : x.kind - y.kind; }
        });
        seqMarks = out;
        return out;
    }

    /** Distancia do agarrao (HDAT 3 byte 5), com desfazer. */
    public void setPullDistance(final int px) {
        if (data == null) return;
        final CharData cd = data.attacker.data;
        final int before = cd.pullDistance();
        cd.setPullDistance(px);
        pushUndo(null, UndoEdits.swapPull(cd, before));
        editVersion++;
        rebuild(frame);
    }

    public interface MoveEdit { void apply(CharData.Move m); }

    /** Edita campos do golpe (HDAT 4) em runtime, com desfazer; campos de 16 bits (maximo 32767). */
    public void editMove(MoveEdit e) {
        if (data == null || data.move == null) return;
        final CharData.Move mv = data.move;
        final CharData.Move before = mv.copy();
        e.apply(mv);
        mv.clamp();
        pushUndo(null, UndoEdits.swapMove(mv, before, null));
        editVersion++;
        rebuild(frame);
    }

    /**
     * Golpe real do HDAT 4 que "dono" do ANO aberto no modo ANO (o golpe da tela e so uma copia generica); null no modo golpe
     * (ai o golpe da tela e o proprio) ou se nenhum golpe usa o ANO.
     */
    public CharData.Move moveOwner() {
        if (data == null || data.move == null || !data.move.generic) return null;
        return data.attacker.data.ownerOf(data.moveIndex);
    }

    /**
     * Edita {@code target} (um golpe real do HDAT 4, ou o golpe da tela). No modo ANO o golpe da tela e uma copia generica com os campos
     * de projetil do dono: a copia acompanha a edicao para a simulacao refletir e o desfazer volta os dois.
     */
    public void editMoveOf(final CharData.Move target, Runnable change) {
        if (data == null || target == null) return;
        final CharData.Move shown = data.move;
        final CharData.Move before = target.copy();
        change.run();
        target.clamp();
        if (shown != target && shown.generic) syncGeneric(shown, target);
        pushUndo(null, UndoEdits.swapMove(target, before, new Runnable() { public void run() { if (shown != target && shown.generic) syncGeneric(shown, target); } }));
        editVersion++;
        rebuild(frame);
    }

    /** Campos que o golpe generico (modo ANO) herda do dono: os mesmos de {@link CharData#genericFrom}. */
    private static void syncGeneric(CharData.Move g, CharData.Move src) {
        g.flags = src.flags;
        g.projNormal = src.projNormal; g.projAbaixo = src.projAbaixo; g.projAcima = src.projAcima;
        g.projGlobal = src.projGlobal; g.projAoAcertar = src.projAoAcertar; g.projChao = src.projChao;
        g.homing = src.homing; g.homingSpeed = src.homingSpeed; g.maxRep = src.maxRep;
        g.subId = src.subId; g.subAoAcertar = src.subAoAcertar; g.subChao = src.subChao;
    }

    /** Titulo do que a aba edita, ou null se nao ha o que editar. */
    public String editTitle(String tab) {
        if (sim == null || data == null) return null;
        AttackSim.Obj r = sim.attacker().root();
        if ("move".equals(tab)) return "GOLPE " + data.moveIndex;
        if (r == null) return null;
        if ("frame".equals(tab)) return r.pat >= 0 && r.pat < r.mpts.length ? "ANO " + r.ano.index + " \u00b7 FRAME " + r.pat : null;
        if ("links".equals(tab)) return "ANO " + r.ano.index + " \u00b7 LINKS";
        return "ANO " + r.ano.index;
    }

    /** Texto inicial do editor (sem a marca de frame). */
    public String editText(String tab) {
        AttackSim.Obj r = sim == null ? null : sim.attacker().root();
        if (r == null || data == null) return "";
        if ("move".equals(tab)) return DacText.move(data.move, data.moveIndex);
        if ("frame".equals(tab)) return DacText.mpt(r.mpts[r.pat], r.pat, "");
        if ("links".equals(tab)) return DacText.links(r.ano.links, "");
        return DacText.ano(r.ano, -1);
    }

    /** Aplica o texto editado e recria a simulacao. Devolve null se deu certo ou a mensagem de erro. */
    public String applyEdit(String tab, String text) {
        if (sim == null || data == null) return "nada carregado";
        AttackSim.Obj r = sim.attacker().root();
        try {
            if ("move".equals(tab)) {
                final CharData.Move mv = data.move;
                final CharData.Move before = mv.copy();
                DacText.parseMove(text, mv);
                pushUndo(null, UndoEdits.swapMove(mv, before, null));
            } else {
                if (r == null) return "sem ANO";
                final Dac dac = data.attacker.dac;
                final int idx = r.ano.index;
                final Ano old = r.ano;
                if ("frame".equals(tab)) {
                    final int pat = r.pat;
                    if (pat < 0 || pat >= old.mpts.length) return "frame fora da ANO";
                    final Ano.Mpt m = DacText.parseMpt(text);
                    final Ano.Mpt prev = old.mpts[pat];
                    old.mpts[pat] = m;
                    pushUndo(null, UndoEdits.swapMpts(old, new int[] {pat}, new Ano.Mpt[] {prev}));
                } else if ("links".equals(tab)) {
                    Ano.Link[] ls = DacText.parseLinks(text, old.links);
                    int fl = ls.length > 0 ? (old.flags | 2) : (old.flags & ~2);
                    dac.setAno(idx, new Ano(idx, true, fl, old.priority, ls, old.mpts));
                    pushUndo(null, UndoEdits.swapAno(dac, idx, old));
                } else {
                    Ano na = DacText.parseAno(text, idx, old);
                    dac.setAno(idx, na);
                    pushUndo(null, UndoEdits.swapAno(dac, idx, old));
                }
            }
        } catch (DacText.ParseError e) {
            return e.getMessage();
        }
        editVersion++;
        rebuild(frame);
        return null;
    }

    /** Todas as falhas de recorte/folha das pastas em uso (atacante, oponente, efeitos, charf, bobj), "pasta  SPR_n: motivo". */
    public java.util.List<String> spriteProblems() {
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        if (data == null) return out;
        CharAssets[] all = {data.attacker, data.opponent, data.effects, data.charf, data.bobj};
        for (CharAssets c : all) if (c != null && c.sprites != null) out.addAll(c.sprites.errors());
        return out;
    }

    public String spriteProblem() {
        if (data == null) return "";
        int n = data.attacker.sprites.errorCount() + data.opponent.sprites.errorCount()
                + (data.effects == null ? 0 : data.effects.sprites.errorCount())
                + (data.charf == null ? 0 : data.charf.sprites.errorCount());
        if (n == 0) return "";
        String last = data.attacker.sprites.errorCount() > 0 ? data.attacker.sprites.lastError()
                : data.opponent.sprites.errorCount() > 0 ? data.opponent.sprites.lastError()
                : data.effects != null && data.effects.sprites.errorCount() > 0 ? data.effects.sprites.lastError()
                : data.charf.sprites.lastError();
        return n + " erro(s) de sprite: " + last;
    }

    // ---- desenho ----

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        if (!originSet) recenter();
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D0F13);
        if (building) return;                        // a simulacao esta sendo refeita em segundo plano
        if (playing && sim != null && data != null) advance();
        applyCamera();
        drawGrid(c);
        if (sim != null && data != null) {
            c.save();
            c.translate(originX, originY);
            c.scale(scale, scale);
            opts.pixelScale = scale;
            renderer.spriteBoxes = spriteBoxes;
            renderer.boxScale = scale;
            java.util.List<BattleSim.Layer> ls = sim.layers();
            if (poseOn) {
                BattleSim.Layer pl = poseLayer();
                if (pl != null) {
                    c.saveLayerAlpha(null, Math.max(90, ghostAlpha), Canvas.ALL_SAVE_FLAG);
                    beginKey(c, sim, pl.key);
                    renderer.drawLayer(c, pl, spritesFor(pl.owner));
                    c.restore();
                    c.restore();
                }
            }
            for (int i = 0; i < ls.size(); i++) {
                BattleSim.Layer l = ls.get(i);
                if (hideEff && l.owner != BattleSim.OWNER_ATTACKER && l.owner != BattleSim.OWNER_DEFENDER && l.owner != BattleSim.OWNER_SHADOW) continue;
                if (ghostMode != 0 && ghostCurrent) {          // F-GHOST SET: o mesmo filtro tambem no Frame atual
                    if (l.owner == BattleSim.OWNER_PROJECTILE && !ghostProj) continue;
                    if (l.owner == BattleSim.OWNER_EFFECT && !ghostFx) continue;
                }
                beginKey(c, sim, l.key);
                renderer.drawLayer(c, l, spritesFor(l.owner));
                c.restore();
            }
            if (ghostMode != 0) {
                BattleSim g = ghost();
                if (g != null && ghostAlpha > 0) {
                    java.util.List<BattleSim.Layer> gl = g.layers();
                    c.saveLayerAlpha(null, ghostAlpha, Canvas.ALL_SAVE_FLAG);
                    for (int i = 0; i < gl.size(); i++) {
                        BattleSim.Layer l = gl.get(i);
                        boolean ch = l.owner == BattleSim.OWNER_ATTACKER;
                        boolean ok = ch || (!hideEff && (l.owner == BattleSim.OWNER_PROJECTILE ? ghostProj
                                : l.owner == BattleSim.OWNER_EFFECT && ghostFx));
                        if (ok) { beginKey(c, g, l.key); renderer.drawLayer(c, l, spritesFor(l.owner)); c.restore(); }
                    }
                    c.restore();
                }
            }
            for (int i = 0; i < ls.size(); i++) if (ls.get(i).firstOfSim) {
                renderer.anchorSprites = spritesFor(ls.get(i).owner);
                beginKey(c, sim, ls.get(i).rootKey);
                renderer.drawOverlay(c, ls.get(i).sim, opts, ls.get(i).kind);
                c.restore();
            }
            if (!hideEff) for (int i = 0; i < ls.size(); i++)
                if (ls.get(i).kind == 2 && ls.get(i).firstOfSim) { renderer.anchorSprites = spritesFor(ls.get(i).owner); beginKey(c, sim, ls.get(i).rootKey); renderer.drawGlobalAnchor(c, ls.get(i).sim, opts); c.restore(); }
            for (int i = 0; i < ls.size(); i++)
                if (ls.get(i).kind == 3 && ls.get(i).firstOfSim) { renderer.anchorSprites = spritesFor(ls.get(i).owner); beginKey(c, sim, ls.get(i).rootKey); renderer.drawProjectileAnchor(c, ls.get(i).sim, opts); c.restore(); }
            beginKey(c, sim, GameScreenDraw.FIGHTER_KEY);          // SPEEDLINE, caixas do corpo e bordas seguem a camera dos lutadores
            drawSpeedLine(c);
            if (bodyOn) {
                drawBodyBox(c, sim.attackerX(), sim.attackerY(), data.attacker.data, true);
                drawBodyBox(c, sim.opponentX(), sim.opponentY(), data.opponent.data, false);
            }
            if (!gameMode()) drawEdges(c);
            c.restore();
            if (gameMode()) GameScreenDraw.frames(c, GameScreenDraw.forContext(getContext()), 1f / Math.max(0.01f, scale), sim.fullScreenActive());
            c.restore();
            drawLifeBars(c);
            drawNotice(c);
        }
        if (playing) {
            if (Build.VERSION.SDK_INT >= 16) postInvalidateOnAnimation(); else postInvalidateDelayed(16);
        }
    }

    /** Mini barras de vida (Life[] do jogo): atacante a esquerda, oponente a direita, combo no centro. */
    private void drawLifeBars(Canvas c) {
        float w = getWidth(), pad = 8f * density, bh = 10f * density, y = pad;
        float bw = Math.max(40f * density, (w - 3 * pad - 64f * density) / 2f);
        barText.setAntiAlias(true);
        barText.setTextSize(11f * density);
        drawBar(c, pad, y, bw, bh, sim.lifeAttacker(), sim.maxLifeAttacker(), 0xFF3DDC84, false);
        drawBar(c, w - pad - bw, y, bw, bh, sim.lifeOpponent(), sim.maxLifeOpponent(), 0xFFE5484D, true);
        barText.setColor(0xFFFFFFFF);
        barText.setTextAlign(Paint.Align.CENTER);
        String mid = sim.opponentDead() ? "KO" : (sim.comboCount() > 0 ? sim.comboCount() + " HITS" : "");
        if (mid.length() > 0) I18nUi.drawText(c, mid, w / 2f, y + bh, barText);
        if (sim.totalDamage() > 0) {
            barText.setTextSize(10f * density);
            barText.setColor(0xFFB8C0CC);
            I18nUi.drawText(c, "-" + sim.totalDamage(), w / 2f, y + bh + 13f * density, barText);
        }
    }

    private void drawBar(Canvas c, float x, float y, float w, float h, int life, int max, int color, boolean rightAligned) {
        barPaint.setStyle(Paint.Style.FILL);
        barPaint.setColor(0xFF2A2F3A);
        c.drawRect(x, y, x + w, y + h, barPaint);
        float f = max <= 0 ? 0f : Math.max(0f, Math.min(1f, life / (float) max));
        barPaint.setColor(color);
        if (rightAligned) c.drawRect(x + w * (1f - f), y, x + w, y + h, barPaint);
        else c.drawRect(x, y, x + w * f, y + h, barPaint);
        barPaint.setStyle(Paint.Style.STROKE);
        barPaint.setStrokeWidth(Math.max(1f, density));
        barPaint.setColor(0xFFB8C0CC);
        c.drawRect(x, y, x + w, y + h, barPaint);
        barText.setColor(0xFFFFFFFF);
        barText.setTextSize(9f * density);
        barText.setTextAlign(rightAligned ? Paint.Align.RIGHT : Paint.Align.LEFT);
        I18nUi.drawText(c, life + "/" + max, rightAligned ? x + w : x, y + h + 11f * density, barText);
    }

    /** Bordas da tela (azul) e do mapa (vermelho), em coordenadas do mundo (ja dentro do translate/scale). */
    private void drawEdges(Canvas c) {
        StageEdges.draw(c, sim, edgePaint, scale, -getHeight() / scale - originY / scale, (getHeight() - originY) / scale);
    }

    public SpriteCache spritesForOwner(int owner) { return spritesFor(owner); }

    private SpriteCache spritesFor(int owner) {
        if (owner == BattleSim.OWNER_DEFENDER || owner == BattleSim.OWNER_AURA_OPPCHAR) return data.opponent.sprites;
        if (owner == BattleSim.OWNER_AURA_EFFECT) return data.effects == null ? null : data.effects.sprites;
        if (owner == BattleSim.OWNER_AURA_CHARF) return data.charf == null ? null : data.charf.sprites;
        if (owner == BattleSim.OWNER_SHADOW) return data.effects == null ? null : data.effects.sprites;
        if (owner == BattleSim.OWNER_EFFECT) return data.effects == null ? null : data.effects.sprites;
        if (owner == BattleSim.OWNER_BOBJ) return data.bobj == null ? null : data.bobj.sprites;
        return data.attacker.sprites;
    }

    private void advance() {
        long now = SystemClock.uptimeMillis();
        if (lastMs == 0) lastMs = now;
        acc += (now - lastMs) * speed;
        lastMs = now;
        int steps = 0;
        while (acc >= TICK_MS && steps < MAX_STEPS_PER_DRAW) {
            if (atLandStop()) { playing = false; acc = 0; lastMs = 0; notifyUi(); return; }
            if (frame + 1 >= length) {
                seekInternal(0);
                // ANO sem wActFlag 1: volta ao frame 0 e espera o play
                if (!loops || (!BattleSim.flyMode && landStop >= 0)) { playing = false; acc = 0; lastMs = 0; notifyUi(); return; }
            } else { liveStep(); frame++; watchLanding(); }
            playSounds();
            acc -= TICK_MS;
            steps++;
        }
        if (steps == MAX_STEPS_PER_DRAW) acc = 0;
        if (steps > 0) notifyUi();
    }

    private void drawGrid(Canvas c) {
        PreviewGrid.draw(c, getWidth(), getHeight(), originX, originY, scale, density, showGrid);      // o mesmo fundo da previa do Editar Frame
    }

    private void notifyUi() {
        if (uiPosted) return;
        uiPosted = true;
        post(notifier);
    }

    // ---- toque: arrastar move a origem, pinca da zoom ----

    /** SPEEDLINE: dedo num ponto = arrastar (muda a speed) ou tocar (menu); devolve true se o gesto e do ponto. */
    private boolean slTouch(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int[] h = slHit(e.getX(), e.getY());
                if (h == null) return false;
                slDragHead = h[0];
                slDragK = h[1];
                slDragMode = h[2];
                slDownX = e.getX();
                slDownY = e.getY();
                slMoved = false;
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (slDragHead < 0) return false;
                if (e.getPointerCount() > 1) { slWork = null; slDragHead = -1; return false; }
                if (!slMoved && Math.hypot(e.getX() - slDownX, e.getY() - slDownY) < 10f * density) return true;
                slMoved = true;
                if (slDragMode == 1) slDragTo(e.getX(), e.getY());          // so a ponta da seta arrasta (muda a speed do Frame atual)
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (slDragHead < 0) return false;
                int head = slDragHead, k = slDragK;
                slDragHead = -1;
                Ano.Mpt[] work = slWork;
                slWork = null;
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    if (slMoved && work != null) { replaceMpts(work, "speedline"); }
                    else if (!slMoved && getContext() instanceof android.app.Activity) {
                        int[] loc = new int[2];
                        getLocationOnScreen(loc);
                        SpeedLineMenu.show((android.app.Activity) getContext(), this, head, slDragMode == 1 ? k - 1 : k, loc[0] + (int) e.getX(), loc[1] + (int) e.getY());
                    }
                }
                invalidate();
                return true;
            }
            default:
                return false;
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN && noticeTouch(e.getX(), e.getY())) return true;
        if (speedLineOn && slTouch(e)) return true;
        if (centerMode != 0) return true;       // camera automatica: sem arrastar nem zoom
        scaler.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX();
                lastY = e.getY();
                dragging = true;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                dragging = false;
                break;
            case MotionEvent.ACTION_POINTER_UP: {
                int keep = e.getActionIndex() == 0 ? 1 : 0;
                lastX = e.getX(keep);
                lastY = e.getY(keep);
                dragging = e.getPointerCount() == 2;
                break;
            }
            case MotionEvent.ACTION_MOVE:
                if (dragging && !scaler.isInProgress() && e.getPointerCount() == 1) {
                    originX += e.getX() - lastX;
                    originY += e.getY() - lastY;
                    lastX = e.getX();
                    lastY = e.getY();
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                break;
            default:
                break;
        }
        return true;
    }
}
