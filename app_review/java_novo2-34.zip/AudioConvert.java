package com.zue.attackeditor;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Converte qualquer audio para o formato que o SoundEffect do jogo toca (AudioTrack 22050 Hz, mono, PCM 16 bits):
 * WAV canonico com cabecalho de 44 bytes, pois o jogo escreve os dados a partir do byte 44.
 */
public final class AudioConvert {
    private AudioConvert() { }

    public static final int RATE = 22050;
    /** Limite de duracao do audio decodificado (segundos de origem). */
    private static final int MAX_SECONDS = 60;

    /** Audio decodificado: amostras de 16 bits intercaladas por canal. */
    static final class Pcm {
        short[] data;
        int channels, rate;
    }

    /** Arquivo qualquer -> bytes do WAV do jogo. */
    public static byte[] toGameWav(File src) throws IOException {
        byte[] raw = GameData.readAll(src);
        Pcm p = null;
        if (isWav(raw)) p = parseWav(raw);
        if (p == null) p = decodeWithCodec(src);
        if (p == null || p.data.length == 0) throw new IOException("audio vazio ou formato nao suportado");
        return encode(toGame(p));
    }

    /** Silencio curto no formato do jogo (som "excluido": o arquivo continua la para nao mudar a ordem dos outros). */
    public static byte[] silentWav() { return encode(new short[441]); }

    /** Duracao em segundos de um WAV do jogo (44 bytes de cabecalho, 22050 Hz, 16 bits mono). */
    public static double seconds(long fileLength) { return Math.max(0, fileLength - 44) / (RATE * 2.0); }

    /** Silencio gerado por silentWav(). */
    public static boolean isSilent(long fileLength) { return fileLength <= 44 + 441 * 2; }

    /** Amostras (16 bits) de um WAV do jogo (depois dos 44 bytes de cabecalho). */
    public static short[] pcmOf(byte[] wav) {
        int n = Math.max(0, (wav.length - 44) / 2);
        short[] out = new short[n];
        ByteBuffer b = ByteBuffer.wrap(wav).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < n; i++) out[i] = b.getShort(44 + i * 2);
        return out;
    }

    /** Trecho [from, to) em amostras de um WAV do jogo, como novo WAV. */
    public static byte[] slice(byte[] wav, int from, int to) {
        short[] p = pcmOf(wav);
        from = Math.max(0, Math.min(from, p.length));
        to = Math.max(from, Math.min(to, p.length));
        short[] o = new short[to - from];
        System.arraycopy(p, from, o, 0, o.length);
        return encode(o);
    }

    // ------------------------------------------------------------------ conversao

    /** Mistura os canais em mono e reamostra para 22050 Hz. */
    static short[] toGame(Pcm p) {
        int ch = Math.max(1, p.channels);
        int frames = p.data.length / ch;
        float[] mono = new float[frames];
        for (int i = 0; i < frames; i++) {
            float s = 0;
            for (int c = 0; c < ch; c++) s += p.data[i * ch + c];
            mono[i] = s / ch;
        }
        return resample(mono, p.rate, RATE);
    }

    static short[] resample(float[] x, int srcRate, int dstRate) {
        if (srcRate <= 0) srcRate = dstRate;
        int n = (int) Math.floor(x.length * (double) dstRate / srcRate);
        short[] out = new short[Math.max(n, 0)];
        double r = (double) srcRate / dstRate;
        for (int i = 0; i < out.length; i++) {
            double v;
            if (r > 1.0) {                                   // reduz: media da janela (evita serrilhado)
                double a = i * r, b = Math.min(x.length, (i + 1) * r);
                int ia = (int) a, ib = (int) Math.ceil(b);
                double sum = 0, w = 0;
                for (int k = ia; k < ib && k < x.length; k++) {
                    double lo = Math.max(a, k), hi = Math.min(b, k + 1);
                    double wk = hi - lo;
                    if (wk <= 0) continue;
                    sum += x[k] * wk;
                    w += wk;
                }
                v = w > 0 ? sum / w : 0;
            } else if (r == 1.0) {
                v = x[i];
            } else {                                         // amplia: interpolacao linear
                double pos = i * r;
                int k = (int) pos;
                double f = pos - k;
                double s0 = x[Math.min(k, x.length - 1)], s1 = x[Math.min(k + 1, x.length - 1)];
                v = s0 + (s1 - s0) * f;
            }
            long q = Math.round(v);
            out[i] = (short) Math.max(-32768, Math.min(32767, q));
        }
        return out;
    }

    /** WAV PCM 16 bits mono 22050 Hz com cabecalho de 44 bytes. */
    static byte[] encode(short[] pcm) {
        int dataLen = pcm.length * 2;
        ByteBuffer b = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R', 'I', 'F', 'F'}).putInt(36 + dataLen).put(new byte[]{'W', 'A', 'V', 'E'});
        b.put(new byte[]{'f', 'm', 't', ' '}).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(RATE).putInt(RATE * 2).putShort((short) 2).putShort((short) 16);
        b.put(new byte[]{'d', 'a', 't', 'a'}).putInt(dataLen);
        for (int i = 0; i < pcm.length; i++) b.putShort(pcm[i]);
        return b.array();
    }

    // ------------------------------------------------------------------ WAV de entrada

    static boolean isWav(byte[] d) {
        return d.length > 12 && d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F'
                && d[8] == 'W' && d[9] == 'A' && d[10] == 'V' && d[11] == 'E';
    }

    /** WAV PCM (8/16/24/32 bits) ou float 32; null se for outro codec (o MediaCodec tenta). */
    static Pcm parseWav(byte[] d) {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int pos = 12, fmt = -1, ch = 0, rate = 0, bits = 0, dataPos = -1, dataLen = 0;
        while (pos + 8 <= d.length) {
            int id = b.getInt(pos), len = b.getInt(pos + 4);
            int body = pos + 8;
            if (len < 0) len = d.length - body;
            if (id == 0x20746d66 && body + 16 <= d.length) {                       // "fmt "
                fmt = b.getShort(body) & 0xFFFF;
                ch = b.getShort(body + 2) & 0xFFFF;
                rate = b.getInt(body + 4);
                bits = b.getShort(body + 14) & 0xFFFF;
                if (fmt == 0xFFFE && len >= 26 && body + 26 <= d.length) fmt = b.getShort(body + 24) & 0xFFFF;
            } else if (id == 0x61746164) {                                          // "data"
                dataPos = body;
                dataLen = Math.min(len, d.length - body);
                break;
            }
            pos = body + len + (len & 1);
        }
        if (dataPos < 0 || ch <= 0 || rate <= 0) return null;
        boolean isFloat = fmt == 3;
        if (!(fmt == 1 || isFloat)) return null;
        int bytes = bits / 8;
        if (bytes < 1 || bytes > 4 || (isFloat && bytes != 4)) return null;
        int n = dataLen / bytes;
        n -= n % ch;
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            int o = dataPos + i * bytes;
            int v;
            if (isFloat) v = (int) Math.round(Math.max(-1f, Math.min(1f, b.getFloat(o))) * 32767);
            else if (bytes == 1) v = ((d[o] & 0xFF) - 128) << 8;
            else if (bytes == 2) v = b.getShort(o);
            else if (bytes == 3) v = ((d[o + 2] << 16) | ((d[o + 1] & 0xFF) << 8) | (d[o] & 0xFF)) >> 8;
            else v = b.getInt(o) >> 16;
            out[i] = (short) v;
        }
        Pcm p = new Pcm();
        p.data = out;
        p.channels = ch;
        p.rate = rate;
        return p;
    }

    // ------------------------------------------------------------------ outros formatos (MP3, OGG, M4A, FLAC...)

    static Pcm decodeWithCodec(File f) throws IOException {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(f.getAbsolutePath());
            int track = -1;
            String mime = null;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat tf = ex.getTrackFormat(i);
                String m = tf.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { track = i; mime = m; fmt = tf; break; }
            }
            if (track < 0) throw new IOException("o arquivo nao tem faixa de audio");
            ex.selectTrack(track);
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(fmt, null, null, 0);
            codec.start();
            ByteBuffer[] in = codec.getInputBuffers();
            ByteBuffer[] outBufs = codec.getOutputBuffers();
            int rate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : RATE;
            int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
            short[] buf = new short[1 << 16];
            int n = 0;
            boolean inDone = false, outDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int guard = 0;
            while (!outDone && guard++ < 2000000) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        int sz = ex.readSampleData(in[ii], 0);
                        if (sz < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi >= 0) {
                    ByteBuffer ob = outBufs[oi];
                    ob.position(info.offset);
                    ob.limit(info.offset + info.size);
                    int cnt = info.size / 2;
                    ByteBuffer le = ob.slice().order(ByteOrder.LITTLE_ENDIAN);
                    if (n + cnt > buf.length) {
                        short[] nb = new short[Math.max(buf.length * 2, n + cnt)];
                        System.arraycopy(buf, 0, nb, 0, n);
                        buf = nb;
                    }
                    for (int i = 0; i < cnt; i++) buf[n++] = le.getShort();
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    if (n >= (long) rate * Math.max(1, ch) * MAX_SECONDS) outDone = true;
                } else if (oi == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                    outBufs = codec.getOutputBuffers();
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                }
            }
            Pcm p = new Pcm();
            p.data = new short[n - n % Math.max(1, ch)];
            System.arraycopy(buf, 0, p.data, 0, p.data.length);
            p.channels = Math.max(1, ch);
            p.rate = rate;
            return p;
        } catch (RuntimeException e) {
            throw new IOException("nao consegui decodificar o audio: " + e.getMessage());
        } finally {
            if (codec != null) { try { codec.stop(); } catch (Exception ignored) { } try { codec.release(); } catch (Exception ignored) { } }
            ex.release();
        }
    }
}
