package com.zue.attackeditor;

/** Volume, tom e velocidade de um som do jogo (PCM 16 bits mono 22050 Hz), mais igualar o volume pela media dos outros sons. */
public final class AudioEffects {
    private AudioEffects() { }

    public static final class Params {
        public float volume = 1f;          // multiplicador (0..3)
        public float semitones = 0f;       // tom, sem mudar a duracao (se !linked)
        public float speed = 1f;           // velocidade (0.5..2)
        public boolean linked;             // tom e velocidade juntos: so reamostra (tom sobe com a velocidade)
        public boolean equalize;           // iguala o volume a targetRms
        public double targetRms;           // volume medio dos outros sons (0 = sem referencia)
    }

    /** Resultado: som processado e informacoes para mostrar ao usuario. */
    public static final class Result {
        public short[] pcm;
        public double gain;                // ganho total aplicado
        public boolean limited;            // o ganho de igualar foi limitado para nao estourar
    }

    /** RMS dos trechos com som (ignora o silencio entre as partes). 0 se so tem silencio. */
    public static double activeRms(short[] p) {
        double sum = 0;
        long n = 0;
        int thr = Math.max(30, peak(p) / 20);          // abaixo de 5% do pico do proprio som: silencio (assim nao depende do volume)
        for (int i = 0; i < p.length; i++) {
            int v = p[i];
            if (Math.abs(v) < thr) continue;
            sum += (double) v * v;
            n++;
        }
        return n == 0 ? 0 : Math.sqrt(sum / n);
    }

    public static int peak(short[] p) {
        int m = 0;
        for (int i = 0; i < p.length; i++) m = Math.max(m, Math.abs((int) p[i]));
        return m;
    }

    public static Result process(short[] in, Params q) {
        float[] x = new float[in.length];
        for (int i = 0; i < x.length; i++) x[i] = in[i];
        double speed = Math.max(0.25, Math.min(4.0, q.speed));
        double pr = Math.pow(2.0, q.semitones / 12.0);
        if (q.linked) {
            x = resample(x, speed);                        // tom e velocidade andam juntos
        } else {
            if (Math.abs(pr - 1.0) > 1e-4) x = resample(x, pr);       // tom: reamostra (muda a duracao)...
            double k = speed / pr;                                    // ...e a duracao e acertada sem mexer no tom
            if (Math.abs(k - 1.0) > 1e-4) x = stretch(x, k);
        }
        Result r = new Result();
        short[] tmp = toShort(x, 1.0);
        double gain = Math.max(0, q.volume);
        if (q.equalize && q.targetRms > 0) {
            double own = activeRms(tmp);
            if (own > 0) {
                double g = q.targetRms / own;
                double pk = peak(tmp);
                double maxG = pk > 0 ? 32000.0 / (pk * gain) : g;   // com o volume escolhido por cima, sem estourar
                if (g > maxG) { g = maxG; r.limited = true; }
                gain *= g;
            }
        }
        r.gain = gain;
        r.pcm = toShort(x, gain);
        return r;
    }

    private static short[] toShort(float[] x, double gain) {
        short[] o = new short[x.length];
        for (int i = 0; i < o.length; i++) {
            long v = Math.round(x[i] * gain);
            o[i] = (short) Math.max(-32768, Math.min(32767, v));
        }
        return o;
    }

    /** Reamostra: fator f > 1 encurta (mais agudo e rapido), f < 1 alonga. */
    static float[] resample(float[] x, double f) {
        int n = (int) Math.floor(x.length / f);
        float[] o = new float[Math.max(n, 0)];
        for (int i = 0; i < o.length; i++) {
            double pos = i * f;
            int k = (int) pos;
            double fr = pos - k;
            double s0 = x[Math.min(k, x.length - 1)], s1 = x[Math.min(k + 1, x.length - 1)];
            if (f > 1.0) {                                  // reduz: media simples na janela evita serrilhado
                int span = Math.max(1, (int) Math.round(f));
                double sum = 0;
                int c = 0;
                for (int j = 0; j < span; j++) { int idx = k + j - span / 2; if (idx >= 0 && idx < x.length) { sum += x[idx]; c++; } }
                o[i] = c == 0 ? 0 : (float) (sum / c);
            } else o[i] = (float) (s0 + (s1 - s0) * fr);
        }
        return o;
    }

    /** Muda a duracao sem mexer no tom (WSOLA): k > 1 acelera (mais curto), k < 1 desacelera. */
    static float[] stretch(float[] x, double k) {
        final int win = 1024, hs = win / 2, tol = 256;
        if (x.length < win * 3) return resample(x, k);       // curto demais para o metodo: reamostra
        int outLen = (int) (x.length / k) + win;
        float[] out = new float[outLen];
        float[] w = new float[win];
        for (int i = 0; i < win; i++) w[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / win));
        // primeiro quadro: so a metade final da janela (sem entrada gradual no comeco)
        for (int i = 0; i < win && i < x.length; i++) out[i] += x[i] * (i < hs ? 1f : w[i]);
        int prev = 0;
        for (int m = 1; ; m++) {
            int outPos = m * hs;
            if (outPos + win >= outLen) break;
            int target = (int) Math.round(m * hs * k);
            if (target - tol > x.length - win) break;
            int lo = Math.max(0, target - tol), hi = Math.min(x.length - win, target + tol);
            int ref = prev + hs;                              // continuacao natural do quadro anterior
            int best = Math.max(lo, Math.min(hi, target));
            if (ref + hs <= x.length) {
                double bs = -Double.MAX_VALUE;
                for (int c = lo; c <= hi; c += 2) {
                    double s = 0;
                    for (int i = 0; i < hs; i += 4) s += (double) x[ref + i] * x[c + i];
                    if (s > bs) { bs = s; best = c; }
                }
            }
            for (int i = 0; i < win; i++) out[outPos + i] += x[best + i] * w[i];
            prev = best;
        }
        int len = Math.max(1, Math.min(outLen - win, (int) Math.round(x.length / k)));
        float[] o = new float[len];
        System.arraycopy(out, 0, o, 0, len);
        return o;
    }
}
