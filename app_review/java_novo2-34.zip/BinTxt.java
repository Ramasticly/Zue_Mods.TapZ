package com.zue.attackeditor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Le o TXT no formato {@code BIN_CNV_ {$COUNT: n, $HDAT_i:{$info:{$COL,$ROW,$SZ}, ...}}} (o {@code 000.bin.txt} do personagem e o {@code *.dac.txt} da gamedata, ambos gerados
 * pelo extrator do jogo) e monta os bytes de HDAT NA MEMORIA, no mesmo layout do binario ({@link HdatTable}), para os leitores {@link CharData#read} e
 * {@link GameData#fromBytes} de sempre. Nenhum arquivo binario e lido: o app so le TXT. So os HDATs que o app usa sao decodificados (os mesmos formatos do compilador do jogo):
 * <ul>
 * <li>3 {@code $STATUS_BASE_E_FISICA}, 4 {@code $ATRIBUTOS_DE_GOLPE} ({@code $GOLPE_n}), 13 {@code $ROTEIRO_CUTSCENE}, 14-33 {@code $REACAO_DANO_n} (personagem);</li>
 * <li>10-39 {@code $REACAO_DANO_GD_n}, 2 {@code $DISTANCIAS_IA}, 5 {@code $MULTIPLICADOR_COMBO} (gamedata); 7 {@code $CRESCIMENTO_POR_NIVEL} (personagem);</li>
 * <li>qualquer HDAT em {@code $RAW:B[&xx, ...]}; os demais ficam vazios.</li>
 * </ul>
 * Java puro.
 */
final class BinTxt {
    private BinTxt() { }

    private static final String[] FR_KEYS = {"DUR_C", "DUR_A", "ANO", "XSPEED", "YSPEED", "XACCEL", "YACCEL", "XSPEED_A", "YSPEED_A", "XACCEL_A", "YACCEL_A", "COMP", "WALL", "VOZ"};

    /** O texto e do formato BIN_CNV_ (e nao um DAC de ANOs nem um CNV)? */
    static boolean isBin(String text) {
        if (text == null) return false;
        int n = Math.min(text.length(), 400);
        return text.substring(0, n).contains("BIN_CNV_") && text.contains("$COUNT");
    }

    /** Um bloco {@code $HDAT_i:{...}}: posicao no texto. */
    private static final class Blk { int hdat, start, end; }

    /** Blocos {@code $HDAT_i:{...}} do nivel raiz, numa so passada (pula comentarios // e textos entre aspas). */
    private static List<Blk> hdatBlocks(String t) {
        List<Blk> out = new ArrayList<Blk>();
        int root = t.indexOf('{');
        if (root < 0) return out;
        int depth = 0;
        Blk cur = null;
        for (int p = root; p < t.length(); p++) {
            char c = t.charAt(p);
            if (c == '/' && p + 1 < t.length() && t.charAt(p + 1) == '/') { while (p < t.length() && t.charAt(p) != '\n') p++; continue; }
            if (c == '"') { p++; while (p < t.length() && t.charAt(p) != '"') { if (t.charAt(p) == '\\') p++; p++; } continue; }
            if (c == '$' && depth == 1 && cur == null && t.startsWith("$HDAT_", p)) {
                int q = p + 6, d0 = q;
                while (q < t.length() && Character.isDigit(t.charAt(q))) q++;
                int r = q;
                while (r < t.length() && Character.isWhitespace(t.charAt(r))) r++;
                if (q > d0 && r < t.length() && t.charAt(r) == ':') {
                    r++;
                    while (r < t.length() && Character.isWhitespace(t.charAt(r))) r++;
                    if (r < t.length() && t.charAt(r) == '{') {
                        cur = new Blk();
                        cur.hdat = Integer.parseInt(t.substring(d0, q));
                        cur.start = p;
                        depth++;
                        p = r;
                        continue;
                    }
                }
            }
            if (c == '{') depth++;
            else if (c == '}') {
                depth--;
                if (cur != null && depth == 1) { cur.end = p; out.add(cur); cur = null; }
                if (depth == 0) break;
            }
        }
        return out;
    }

    private static String stripComments(String blk) {
        StringBuilder sb = new StringBuilder();
        for (String ln : blk.split("\n", -1)) {
            int c = ln.indexOf("//");
            sb.append(c >= 0 ? ln.substring(0, c) : ln).append('\n');
        }
        return sb.toString();
    }

    private static int num(String blk, String regex, int def) {
        Matcher m = Pattern.compile(regex).matcher(blk);
        if (!m.find()) return def;
        try { return (int) Math.round(Double.parseDouble(m.group(1))); } catch (NumberFormatException e) { return def; }
    }

    private static double dbl(String blk, String regex) {
        Matcher m = Pattern.compile(regex).matcher(blk);
        if (!m.find()) return 0;
        try { return Double.parseDouble(m.group(1)); } catch (NumberFormatException e) { return 0; }
    }

    /** Os bytes do arquivo BIN_CNV_ montados dos blocos do texto. */
    static byte[] compile(String text) throws IOException {
        Matcher mc = Pattern.compile("\\$COUNT\\s*:\\s*(\\d+)").matcher(text);
        if (!mc.find()) throw new IOException("TXT sem $COUNT (nao e o formato BIN_CNV_)");
        int count = Integer.parseInt(mc.group(1));
        if (count <= 0 || count > 4000) throw new IOException("$COUNT invalido: " + count);
        byte[][] body = new byte[count][];
        int[] cols = new int[count], rows = new int[count];
        for (int i = 0; i < count; i++) body[i] = new byte[0];
        for (Blk b : hdatBlocks(text)) {
            if (b.hdat < 0 || b.hdat >= count) continue;
            String blk = text.substring(b.start, b.end + 1);
            String clean = stripComments(blk);
            int c = num(clean, "\\$COL\\s*:\\s*(-?\\d+)", 0), r = num(clean, "\\$ROW\\s*:\\s*(-?\\d+)", 0);
            body[b.hdat] = decode(clean, c, r);
            cols[b.hdat] = c;
            rows[b.hdat] = r;
        }
        ByteArrayOutputStream head = new ByteArrayOutputStream(), data = new ByteArrayOutputStream();
        int off = 2 + count * 8;
        for (int i = 0; i < count; i++) {
            le(head, off, 4);
            le(head, cols[i], 2);
            le(head, rows[i], 2);
            data.write(body[i]);
            off += body[i].length;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        le(out, count, 2);
        out.write(head.toByteArray());
        out.write(data.toByteArray());
        return out.toByteArray();
    }

    private static void le(ByteArrayOutputStream o, long v, int n) {
        for (int i = 0; i < n; i++) o.write((int) ((v >> (8 * i)) & 255));
    }

    /** Bytes de UM bloco {@code $HDAT_i} (ja sem comentarios). */
    private static byte[] decode(String blk, int cols, int rows) throws IOException {
        if (blk.contains("$STATUS_BASE_E_FISICA")) return status(blk);
        if (blk.contains("$ATRIBUTOS_DE_GOLPE")) return moves(blk, rows);
        if (blk.contains("$ROTEIRO_CUTSCENE")) return cutscene(blk);
        if (Pattern.compile("\\$REACAO_DANO_(GD_)?\\d+").matcher(blk).find()) return reaction(blk);
        if (blk.contains("$MULTIPLICADOR_COMBO")) return lines(blk, true);
        if (blk.contains("$DISTANCIAS_IA") || blk.contains("$CRESCIMENTO_POR_NIVEL")) return lines(blk, false);
        if (blk.contains("$RAW:B[")) return raw(blk);
        return new byte[0];
    }

    private static byte[] raw(String blk) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int s = blk.indexOf('['), e = blk.lastIndexOf(']');
        if (s >= 0 && e > s) {
            Matcher m = Pattern.compile("&([0-9A-Fa-f]{2})").matcher(blk.substring(s, e));
            while (m.find()) o.write(Integer.parseInt(m.group(1), 16));
        }
        return o.toByteArray();
    }

    /** HDAT 3 (18 bytes): os mesmos campos e escalas do compilador ($LARGURA x2, $KI_MAXIMO_BASE / 100, $ATK_BASE e $DEFESA_BASE / 10). */
    private static byte[] status(String blk) {
        byte[] d = new byte[18];
        d[0] = (byte) num(blk, "\\$VELOCIDADE_MOVIMENTO\\s*:\\s*(-?[\\d.]+)", 0);
        d[1] = (byte) num(blk, "\\$VELOCIDADE_RECUO\\s*:\\s*(-?[\\d.]+)", 0);
        d[2] = (byte) num(blk, "\\$DESCONHECIDO_2\\s*:\\s*(-?[\\d.]+)", 0);
        d[3] = (byte) Math.round(dbl(blk, "\\$LARGURA\\s*:\\s*(-?[\\d.]+)") * 2);
        d[4] = (byte) num(blk, "\\$ALTURA\\s*:\\s*(-?[\\d.]+)", 0);
        d[5] = (byte) num(blk, "\\$DISTANCIA_AGARRE\\s*:\\s*(-?[\\d.]+)", 0);
        d[6] = (byte) num(blk, "\\$PODE_VOAR\\s*:\\s*(-?[\\d.]+)", 0);
        d[7] = (byte) num(blk, "\\$VELOCIDADE_DASH_VERTICAL\\s*:\\s*(-?[\\d.]+)", 0);
        d[8] = (byte) (num(blk, "\\$KI_MAXIMO_BASE\\s*:\\s*(-?[\\d.]+)", 0) / 100);
        d[9] = (byte) num(blk, "\\$ID_ATRIBUTO\\s*:\\s*(-?[\\d.]+)", 0);
        d[10] = (byte) num(blk, "\\$VELOCIDADE_CARGA_KI\\s*:\\s*(-?[\\d.]+)", 0);
        d[11] = (byte) num(blk, "\\$VIDA_INICIAL\\s*:\\s*(-?[\\d.]+)", 0);
        d[12] = (byte) (num(blk, "\\$ATK_BASE\\s*:\\s*(-?[\\d.]+)", 0) / 10);
        d[13] = (byte) num(blk, "\\$TIPO_COUNTER\\s*:\\s*(-?[\\d.]+)", 0);
        d[14] = (byte) (num(blk, "\\$DEFESA_BASE\\s*:\\s*(-?[\\d.]+)", 0) / 10);
        d[15] = (byte) num(blk, "\\$DESCONHECIDO_15\\s*:\\s*(-?[\\d.]+)", 0);
        d[16] = (byte) num(blk, "\\$ANIM_ENTRADA\\s*:\\s*(-?[\\d.]+)", 0);
        d[17] = (byte) num(blk, "\\$PONTOS_EQUIPAR_CARTAS\\s*:\\s*(-?[\\d.]+)", 0);
        return d;
    }

    /** HDAT 4: 48 bytes por golpe (24 shorts); golpe sem bloco fica zerado. */
    private static byte[] moves(String blk, int rowsInfo) throws IOException {
        TreeMap<Integer, CharData.Move> ms = new TreeMap<Integer, CharData.Move>();
        Matcher m = Pattern.compile("\\$GOLPE_(\\d+)\\s*:\\s*\\{").matcher(blk);
        int max = rowsInfo - 1;
        List<Integer> idx = new ArrayList<Integer>();
        while (m.find()) { int n = Integer.parseInt(m.group(1)); idx.add(Integer.valueOf(n)); max = Math.max(max, n); }
        for (Integer n : idx) {
            int[] b = Saver.findBlock(blk, "GOLPE_" + n);
            if (b == null) continue;
            CharData.Move mv = new CharData.Move();
            try { DacText.parseMove(blk.substring(b[0], b[2] + 1), mv); } catch (Exception ex) { throw new IOException("$GOLPE_" + n + ": " + ex.getMessage()); }
            ms.put(n, mv);
        }
        byte[] out = new byte[(max + 1) * CharData.MOVE_STRIDE];
        for (java.util.Map.Entry<Integer, CharData.Move> e : ms.entrySet()) System.arraycopy(CharData.moveBytes(e.getValue()), 0, out, e.getKey().intValue() * CharData.MOVE_STRIDE, CharData.MOVE_STRIDE);
        return out;
    }

    /** HDAT 13: shorts com sinal (little endian), {@link CharData#EV_COLS} por evento. */
    private static byte[] cutscene(String blk) {
        int[][] ev = CutsceneText.parse(blk);
        if (ev == null) return new byte[0];
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (int[] row : ev) for (int c = 0; c < CharData.EV_COLS; c++) le(o, c < row.length ? row[c] : 0, 2);
        return o.toByteArray();
    }

    /** HDAT de reacao: 14 bytes por passo ($FR_n com $DUR_C, $DUR_A, $ANO, ... $WALL, $VOZ). */
    private static byte[] reaction(String blk) {
        Matcher fm = Pattern.compile("\\$FR_(\\d+)\\s*:\\s*\\{([^}]*)\\}").matcher(blk);
        TreeMap<Integer, int[]> rows = new TreeMap<Integer, int[]>();
        while (fm.find()) {
            int[] v = new int[FR_KEYS.length];
            Matcher km = Pattern.compile("\\$([A-Za-z_]+)\\s*:\\s*(-?\\d+)").matcher(fm.group(2));
            while (km.find()) for (int k = 0; k < FR_KEYS.length; k++) if (FR_KEYS[k].equalsIgnoreCase(km.group(1))) v[k] = Integer.parseInt(km.group(2));
            rows.put(Integer.valueOf(Integer.parseInt(fm.group(1))), v);
        }
        if (rows.isEmpty()) return new byte[0];
        int n = rows.lastKey().intValue() + 1;
        byte[] out = new byte[n * ReactionTable.STRIDE];
        for (java.util.Map.Entry<Integer, int[]> e : rows.entrySet()) for (int k = 0; k < FR_KEYS.length; k++) out[e.getKey().intValue() * ReactionTable.STRIDE + k] = (byte) e.getValue()[k];
        return out;
    }

    /** Tabelas "linha x coluna" ($NOME: [v0, v1, ...] por linha): bytes, ou shorts little endian. */
    private static byte[] lines(String blk, boolean shorts) {
        Matcher m = Pattern.compile("\\$([A-Za-z_][A-Za-z_0-9]*)\\s*:\\s*\\[([^\\]]*)\\]").matcher(blk);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        while (m.find()) {
            for (String s : m.group(2).split(",")) {
                s = s.trim();
                if (s.isEmpty()) continue;
                int v;
                try { v = s.startsWith("&") ? Integer.parseInt(s.substring(1), 16) : Integer.parseInt(s); } catch (NumberFormatException e) { v = 0; }
                le(o, v, shorts ? 2 : 1);
            }
        }
        return o.toByteArray();
    }
}
