package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Janela de "carregando" com barra de progresso, para trabalho em segundo plano (nao fecha ao tocar fora nem no voltar). */
final class BusyDialog {
    private final Activity a;
    private final Dialog dlg;
    private final TextView msg, cnt;
    private final ProgressBar bar;
    private final Handler ui = new Handler(Looper.getMainLooper());
    /** A janela fica no minimo 1 s na tela (em casos leves ela nao pisca). */
    private static final long MIN_MS = 1000;
    private long shownAt;

    private BusyDialog(Activity a, String title) {
        this.a = a;
        float d = a.getResources().getDisplayMetrics().density;
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setCancelable(false);
        dlg.setCanceledOnTouchOutside(false);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(14 * d);
        box.setBackground(bg);
        int pad = Math.round(18 * d);
        box.setPadding(pad, pad, pad, pad);
        TextView t = new TextView(a);
        t.setText(title);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t.setTextColor(LayoutManager.TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(t);
        msg = new TextView(a);
        msg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        msg.setTextColor(LayoutManager.DIM);
        msg.setSingleLine(true);
        msg.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        msg.setPadding(0, Math.round(6 * d), 0, Math.round(10 * d));
        box.addView(msg);
        bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setMax(1000);
        try { bar.getProgressDrawable().setColorFilter(LayoutManager.ACCENT, android.graphics.PorterDuff.Mode.SRC_IN); } catch (Exception ignored) { }
        try { bar.getIndeterminateDrawable().setColorFilter(LayoutManager.ACCENT, android.graphics.PorterDuff.Mode.SRC_IN); } catch (Exception ignored) { }
        box.addView(bar, new LinearLayout.LayoutParams(-1, Math.round(12 * d)));
        cnt = new TextView(a);
        cnt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        cnt.setTextColor(LayoutManager.DIM);
        cnt.setGravity(Gravity.END);
        cnt.setPadding(0, Math.round(6 * d), 0, 0);
        box.addView(cnt);
        dlg.setContentView(box);
        dlg.show();
        shownAt = android.os.SystemClock.uptimeMillis();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            dlg.getWindow().setLayout(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.86f), android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    static BusyDialog show(Activity a, String title) { return new BusyDialog(a, title); }

    /** Pode ser chamado de qualquer thread. {@code total <= 0}: barra sem fim, so mostra a contagem. */
    void set(final String text, final int done, final int total) {
        ui.post(new Runnable() {
            @Override public void run() {
                msg.setText(text == null ? "" : text);
                if (total > 0) {
                    bar.setIndeterminate(false);
                    bar.setProgress(Math.min(1000, Math.round(1000f * done / total)));
                    cnt.setText(done + " / " + total + "  (" + Math.round(100f * done / total) + "%)");
                } else {
                    bar.setIndeterminate(true);
                    cnt.setText(done > 0 ? String.valueOf(done) : "");
                }
            }
        });
    }

    /** Chamado da thread de trabalho: espera o que falta para completar 1 s antes de fechar (e de seguir para o proximo passo). */
    void dismiss() {
        long left = MIN_MS - (android.os.SystemClock.uptimeMillis() - shownAt);
        final Runnable close = new Runnable() { @Override public void run() { try { dlg.dismiss(); } catch (Exception ignored) { } } };
        if (left > 0) {
            if (Looper.myLooper() == Looper.getMainLooper()) { ui.postDelayed(close, left); return; }
            try { Thread.sleep(left); } catch (InterruptedException ignored) { }
        }
        ui.post(close);
    }
}
