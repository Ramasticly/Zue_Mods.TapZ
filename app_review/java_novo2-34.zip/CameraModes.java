package com.zue.attackeditor;

/**
 * Modos de camera da previa (os mesmos da principal): 0 NORMAL (manual), 1 TELA (centraliza o retangulo 480 x 320 da camera do jogo; com zoom ativo segue o
 * retangulo do zoom), 2 CHAR (enquadra os dois personagens, margem de 50 px). Java puro.
 */
final class CameraModes {
    private CameraModes() { }

    static final int NORMAL = 0, SCREEN = 1, CHAR = 2;

    /** Nome do modo no botao CENTRO. */
    static String label(int mode) { return mode == 0 ? "CENTRO: NORMAL" : mode == 1 ? "CENTRO: TELA" : "CENTRO: CHAR"; }

    /** Retangulo do mundo (px) que o modo quer enquadrar: {x0, y0, x1, y1}; null no modo NORMAL ou sem simulacao. */
    static float[] bounds(int mode, BattleSim sim) {
        if (mode == NORMAL || sim == null) return null;
        float x0, x1, y0, y1;
        if (mode == SCREEN) {
            float sl = sim.screenLeft() / 65536f;
            float st = sim.screenTop() / 65536f;
            x0 = sl; x1 = sl + 480f; y0 = st; y1 = st + 320f;
            float[] zr = sim.zoomRect();         // com zoom ativo, a tela segue o retangulo amarelo (o que o jogo realmente mostra)
            if (zr != null) { x0 = zr[0]; y0 = zr[1]; x1 = zr[2]; y1 = zr[3]; }
        } else {
            float ax = sim.attackerX(), ox = sim.opponentX();
            AttackSim.Obj r = sim.attacker().root();
            float ay = r == null ? 0f : r.y / 65536f;
            float body = 30f, margin = 50f;
            x0 = Math.min(ax, ox) - body - margin;
            x1 = Math.max(ax, ox) + body + margin;
            y0 = Math.min(0f, ay) - 100f - margin;
            y1 = 30f;
        }
        return new float[]{x0, y0, x1, y1};
    }
}
