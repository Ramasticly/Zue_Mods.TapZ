package com.zue.attackeditor;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * CENTRALIZAR: o zoom das sprites marcadas faz a altura delas (em pixels da tela) igual a da 1a sprite do Parado (ANO 0) e o MID as poe com os pes no chao e
 * centradas: x = -largura x zoom / 2, y = -altura x zoom. Vale para o padrao da sprite e para os Frames do DAC que a usam. Java puro.
 */
final class Centralize {
    private Centralize() { }

    /** Zoom (%) e MID resultantes para uma sprite. */
    static final class Plan {
        final int zoom, midX, midY;
        Plan(int zoom, int midX, int midY) { this.zoom = zoom; this.midX = midX; this.midY = midY; }
    }

    interface Sizes { int[] logical(int image); }          // {largura, altura} logicas ou null

    /** Altura (em unidades da tela) da 1a sprite do Parado: altura logica do recorte x zoom Y do frame; -1 se nao ha Parado/imagem. */
    static double refHeight(Dac dac, Sizes sizes) {
        if (dac == null || sizes == null) return -1;
        Ano a = dac.getAno(0);
        if (a == null || !a.present || a.mpts == null || a.mpts.length == 0) return -1;
        Ano.Mpt m = a.mpts[0];
        int[] s = m.image < 0 ? null : sizes.logical(m.image);
        if (s == null || s[1] <= 0) return -1;
        return s[1] * SpriteDefaults.read(m).zy / 100.0;
    }

    /** Plano de uma sprite {@code w x h} para chegar na altura {@code refH}. */
    static Plan plan(double refH, int w, int h) {
        int zoom = Math.max(1, (int) Math.round(refH / Math.max(1, h) * 100.0));
        double z = zoom / 100.0;
        return new Plan(zoom, -(int) Math.round(w * z / 2.0), -(int) Math.round(h * z));
    }

    /** Padrao visual da sprite depois de centralizada (rotacao, alpha e flips ficam como estavam em {@code base}). */
    static SpriteDefaults.Def toDef(SpriteDefaults.Def base, Plan p) {
        SpriteDefaults.Def d = base.copy();
        d.zx = p.zoom; d.zy = p.zoom; d.midX = p.midX; d.midY = p.midY;
        return d;
    }

    /** Copia do Frame com zoom X=Y e MID do plano (rotacao, alpha e flips ficam). */
    static Ano.Mpt applyToFrame(Ano.Mpt m, Plan p) {
        return SpriteDefaults.write(m, toDef(SpriteDefaults.read(m), p));
    }

    /** Reescreve zoom X=Y e MID de todo Frame que usa uma das sprites de {@code plans}; devolve as ANOs alteradas ({@code count[0]} = Frames). */
    static TreeSet<Integer> applyToFrames(Dac dac, Map<Integer, Plan> plans, int[] count) {
        TreeSet<Integer> changed = new TreeSet<Integer>();
        if (count != null && count.length > 0) count[0] = 0;
        if (dac == null) return changed;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            Ano.Mpt[] out = a.mpts.clone();
            boolean any = false;
            for (int k = 0; k < out.length; k++) {
                Plan p = plans.get(Integer.valueOf(out[k].image));
                if (p == null) continue;
                out[k] = applyToFrame(out[k], p);
                any = true;
                if (count != null && count.length > 0) count[0]++;
            }
            if (any) { dac.setAno(i, new Ano(i, true, a.flags, a.priority, a.links, out)); changed.add(Integer.valueOf(i)); }
        }
        return changed;
    }
}
