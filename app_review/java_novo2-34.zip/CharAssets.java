package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

/** Tudo de uma pasta de personagem (ou do effect): DAC, CNV, sprites e quantidade de WAVs. */
public final class CharAssets {
    public final File dir;
    public final Dac dac;
    public final Cnv cnv;
    public final SpriteCache sprites;
    public int wavCount;
    /** Conteudo do 000.bin (so personagens). */
    public final CharData data;

    private final File cnvFile;
    private SpriteLib lib;
    /** Quantas PNGs soltas da pasta entraram como sprites nesta carga (0 se nenhuma). */
    public int importedLoose;

    private CharAssets(File dir, File cnvFile, Dac dac, Cnv cnv, CharData data, int wavCount) {
        this.dir = dir;
        this.cnvFile = cnvFile;
        this.dac = dac;
        this.cnv = cnv;
        this.data = data;
        this.wavCount = wavCount;
        this.sprites = new SpriteCache(dir, cnv);
    }

    /** De onde veio o ultimo CNV lido por {@link #readCnv} (para o seletor de sprites mostrar como o arquivo foi entendido). */
    static final String KIND_TXT = "txt", KIND_TEXT = "text", KIND_BIN = "bin";
    static volatile String lastCnvKind = KIND_TXT;

    /**
     * CNV a partir do TXT (coordenadas finais, ja x2 no personagem). {@code cnvF} e o nome logico "x.cnv" (o "x.cnv.txt" ao lado e lido) ou o proprio "x.cnv.txt".
     * Um ".cnv" em texto puro (CNV_TXT_, coordenadas originais) tambem serve de origem de sprites; o binario NAO e lido: sem TXT, {@link TxtFiles.Missing}.
     */
    static Cnv readCnv(File cnvF, boolean character) throws IOException {
        File txt = cnvF.getName().toLowerCase(java.util.Locale.US).endsWith(".txt") ? cnvF : new File(cnvF.getPath() + ".txt");
        if (!txt.isFile()) {
            File any = TxtFiles.find(cnvF.getParentFile(), "cnv");
            if (any != null && TxtFiles.withoutTxt(any).getName().equalsIgnoreCase(cnvF.getName())) txt = any;
        }
        if (txt.isFile()) {
            try {
                Cnv c = Cnv.fromTxt(TxtFiles.read(txt), character);
                if (c != null) { lastCnvKind = KIND_TXT; return c; }
            } catch (RuntimeException ignored) { }
            throw new IOException(txt.getName() + ": nao consegui ler os $SPR_n do CNV");
        }
        if (cnvF.isFile() && !cnvF.getName().toLowerCase(java.util.Locale.US).endsWith(".txt")) {
            try {
                Cnv c = Cnv.fromTxt(TxtFiles.read(cnvF), character, false);       // .cnv em texto puro (so texto; o binario nao e lido)
                if (c != null) { lastCnvKind = KIND_TEXT; return c; }
            } catch (RuntimeException ignored) { }
        }
        throw new TxtFiles.Missing(cnvF.getParentFile(), "cnv");
    }

    private SpriteDefaults.Store defs;

    /** Padrao visual de cada sprite (zoom, rotacao, alpha, MID, flip) para novas adicoes na timeline; fica em TBRE/utils/charNN. */
    public SpriteDefaults.Store defaults() {
        if (defs == null) {
            defs = SpriteDefaults.Store.load(dir);
            defs.setSizes(new SpriteDefaults.Store.Sizes() {
                @Override public int[] logical(int sprite) {
                    Cnv.Entry e = cnv.byImage(sprite);
                    return e == null || e.width <= 0 || e.height <= 0 ? null : new int[]{e.width, e.height};
                }
            });
        }
        return defs;
    }

    /** Tamanho logico (largura, altura) de cada sprite, para Centralizar/Reescalar e Adicionar Sprites. */
    public Centralize.Sizes sizes() {
        return new Centralize.Sizes() {
            @Override public int[] logical(int image) {
                Cnv.Entry e = cnv.byImage(image);
                return e == null || e.width <= 0 || e.height <= 0 ? null : new int[]{e.width, e.height};
            }
        };
    }

    /** Grava os padroes se mudaram; devolve o erro (ou null). */
    public String saveDefaults() {
        try { defaults().save(dir); return null; } catch (Exception e) { return e.getMessage(); }
    }

    /** Lista de sprites desta pasta (folhas + CNV em memoria). */
    public SpriteLib lib() {
        if (lib == null) lib = new SpriteLib(dir, cnvFile, cnv, cnv.scale());
        return lib;
    }

    /** Poe image = -1 em todo frame (MPT) do DAC que usa a imagem {@code image}; devolve quantos frames mudaram. */
    public int clearImageUses(int image) {
        int n = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (int m = 0; m < a.mpts.length; m++) if (a.mpts[m].image == image) { a.mpts[m].image = -1; n++; }
        }
        return n;
    }

    /** Todo frame do DAC que usa a imagem {@code from} passa a usar {@code to}; devolve quantos mudaram. */
    public int remapImageUses(int from, int to) {
        int n = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (int m = 0; m < a.mpts.length; m++) if (a.mpts[m].image == from) { a.mpts[m].image = to; n++; }
        }
        return n;
    }

    /** Depois de gravar sprites: o preview relê folhas e CNV. */
    public void reloadSprites() { sprites.reload(); }

    /** PNGs soltos na pasta (colocados por fora) viram sprites novas antes de qualquer coisa ser lida. */
    private void importLoose() {
        if (SpriteLib.loose(dir).length == 0) return;
        try {
            importedLoose = lib().importLoose();
            if (importedLoose > 0) sprites.reload();
        } catch (Exception e) {
            importError = e.getMessage();
        }
    }
    public String importError;

    public static CharAssets loadChar(File dir) throws IOException {
        File dacT = TxtFiles.require(dir, "dac"), binT = TxtFiles.require(dir, "bin"), cnvT = TxtFiles.require(dir, "cnv");
        Dac dac = Dac.fromTxt(TxtFiles.read(dacT));
        File cnvF = TxtFiles.withoutTxt(cnvT);
        Cnv cnv = readCnv(cnvT, true);
        CharData cd = CharData.fromTxt(TxtFiles.read(binT));
        CharAssets ca = new CharAssets(dir, cnvF, dac, cnv, cd, listWavs(dir).length);
        ca.importLoose();
        return ca;
    }

    /** assets/effect: usa o primeiro *.dac.txt e o primeiro *.cnv.txt da pasta (escala 1, nao e personagem). */
    public static CharAssets loadEffect(File assetsRoot) throws IOException {
        File dir = new File(assetsRoot, "effect");
        CharAssets ca = pack(dir, false);
        ca.importLoose();
        return ca;
    }

    /** So DAC, CNV e sprites do personagem, para previas (sem o bin.txt, sem importar PNGs soltas e sem mexer no CNV lido por ultimo). */
    public static CharAssets loadPreview(File dir) throws IOException {
        String kind = lastCnvKind;
        try {
            File cnvT = TxtFiles.require(dir, "cnv");
            Dac dac = Dac.fromTxt(TxtFiles.read(TxtFiles.require(dir, "dac")));
            Cnv cnv = readCnv(cnvT, true);
            return new CharAssets(dir, TxtFiles.withoutTxt(cnvT), dac, cnv, null, 0);
        } finally {
            lastCnvKind = kind;
        }
    }

    /** Pack auxiliar do personagem (charfNN, bobj): escala 1, *.dac.txt e *.cnv.txt da pasta. */
    public static CharAssets loadPack(File dir) throws IOException {
        CharAssets ca = pack(dir, false);
        ca.importLoose();
        return ca;
    }

    private static CharAssets pack(File dir, boolean character) throws IOException {
        File dacT = TxtFiles.require(dir, "dac"), cnvT = TxtFiles.require(dir, "cnv");
        return new CharAssets(dir, TxtFiles.withoutTxt(cnvT), Dac.fromTxt(TxtFiles.read(dacT)), readCnv(cnvT, character), null, 0);
    }

    /** Recontagem depois de adicionar/trocar sons. */
    public void refreshWavCount() { wavCount = listWavs(dir).length; }

    public static File[] listWavs(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) return new File[0];
        java.util.ArrayList<File> out = new java.util.ArrayList<File>();
        for (File f : fs) if (f.isFile() && f.getName().toLowerCase().endsWith(".wav")) out.add(f);
        File[] a = out.toArray(new File[0]);
        Arrays.sort(a);
        return a;
    }

    public static final int KIND_NORMAL = 0, KIND_PROJECTILE = 1, KIND_ATTACK = 2;
    private int[] kinds;

    /** Tipo de cada ANO: 2 = tem hitbox flag 2 (ataque), 1 = tem flag 0 (projetil), 0 = resto. Considera os links. */
    public int[] anoKinds() {
        if (kinds != null) return kinds;
        int n = dac.size();
        int[] k = new int[n];
        for (int i = 0; i < n; i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            int kind = kindOf(a);
            for (int l = 0; l < a.links.length; l++) {
                Ano c = dac.getAno(a.links[l].getAno());
                if (c != null && c.present && c != a) kind = Math.max(kind, kindOf(c));
            }
            k[i] = kind;
        }
        kinds = k;
        return k;
    }

    private static int kindOf(Ano a) {
        int kind = KIND_NORMAL;
        for (int m = 0; m < a.mpts.length; m++) {
            Ano.Hit[] hs = a.mpts[m].hits;
            for (int h = 0; h < hs.length; h++) {
                if (hs[h].flag == 2) return KIND_ATTACK;
                if (hs[h].flag == 0) kind = KIND_PROJECTILE;
            }
        }
        return kind;
    }

    /** Depois de criar/trocar ANOs: o cache de {@link #anoKinds()} e refeito na proxima chamada. */
    public void invalidateKinds() { kinds = null; }

    public void release() { sprites.clear(); if (lib != null) { lib.release(); lib = null; } }
}
