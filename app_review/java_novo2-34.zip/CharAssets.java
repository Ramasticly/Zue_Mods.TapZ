package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

/** Tudo de uma pasta de personagem (ou do effect): DAC, CNV, sprites e quantidade de WAVs. */
public final class CharAssets {
    public final File dir;
    public final Dac dac;
    public final Cnv cnv;
    public final SpriteCache sprites;
    public int wavCount;
    /** Conteudo do 000.bin (so personagens). */
    public final CharData data;

    private final File cnvFile;
    private SpriteLib lib;
    /** Quantas PNGs soltas da pasta entraram como sprites nesta carga (0 se nenhuma). */
    public int importedLoose;

    private CharAssets(File dir, File cnvFile, Dac dac, Cnv cnv, CharData data, int wavCount) {
        this.dir = dir;
        this.cnvFile = cnvFile;
        this.dac = dac;
        this.cnv = cnv;
        this.data = data;
        this.wavCount = wavCount;
        this.sprites = new SpriteCache(dir, cnv);
    }

    /** De onde veio o ultimo CNV lido por {@link #readCnv} (para o seletor de sprites mostrar como o arquivo foi entendido). */
    static final String KIND_TXT = "txt", KIND_TEXT = "text", KIND_BIN = "bin";
    static volatile String lastCnvKind = KIND_BIN;

    /** CNV da pasta: o .cnv.txt (coordenadas finais, ja x2 no personagem) se existir; senao o .cnv, lido como texto (coordenadas originais) e, se nao tiver texto, como binario. */
    static Cnv readCnv(File cnvF, boolean character) throws IOException {
        File txt = new File(cnvF.getPath() + ".txt");
        if (txt.isFile()) {
            try {
                Cnv c = Cnv.fromTxt(new String(GameData.readAll(txt), "UTF-8"), character);
                if (c != null) { lastCnvKind = KIND_TXT; return c; }
            } catch (RuntimeException ignored) { }
        }
        byte[] raw = GameData.readAll(cnvF);
        // o .cnv fora do PAC e texto (CNV_TXT_ { $SPR_n:{...} }) com as coordenadas originais, sem x2: tenta texto primeiro, binario so se nao houver texto
        try {
            Cnv c = Cnv.fromTxt(new String(raw, "UTF-8"), character, false);
            if (c != null) { lastCnvKind = KIND_TEXT; return c; }
        } catch (RuntimeException ignored) { }
        lastCnvKind = KIND_BIN;
        return Cnv.read(raw, character);
    }

    private SpriteDefaults.Store defs;

    /** Padrao visual de cada sprite (zoom, rotacao, alpha, MID, flip) para novas adicoes na timeline; fica em TBRE/utils/charNN. */
    public SpriteDefaults.Store defaults() {
        if (defs == null) {
            defs = SpriteDefaults.Store.load(dir);
            defs.setSizes(new SpriteDefaults.Store.Sizes() {
                @Override public int[] logical(int sprite) {
                    Cnv.Entry e = cnv.byImage(sprite);
                    return e == null || e.width <= 0 || e.height <= 0 ? null : new int[]{e.width, e.height};
                }
            });
        }
        return defs;
    }

    /** Grava os padroes se mudaram; devolve o erro (ou null). */
    public String saveDefaults() {
        try { defaults().save(dir); return null; } catch (Exception e) { return e.getMessage(); }
    }

    /** Lista de sprites desta pasta (folhas + CNV em memoria). */
    public SpriteLib lib() {
        if (lib == null) lib = new SpriteLib(dir, cnvFile, cnv, cnv.scale());
        return lib;
    }

    /** Poe image = -1 em todo frame (MPT) do DAC que usa a imagem {@code image}; devolve quantos frames mudaram. */
    public int clearImageUses(int image) {
        int n = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (int m = 0; m < a.mpts.length; m++) if (a.mpts[m].image == image) { a.mpts[m].image = -1; n++; }
        }
        return n;
    }

    /** Todo frame do DAC que usa a imagem {@code from} passa a usar {@code to}; devolve quantos mudaram. */
    public int remapImageUses(int from, int to) {
        int n = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (int m = 0; m < a.mpts.length; m++) if (a.mpts[m].image == from) { a.mpts[m].image = to; n++; }
        }
        return n;
    }

    /** Depois de gravar sprites: o preview relê folhas e CNV. */
    public void reloadSprites() { sprites.reload(); }

    /** PNGs soltos na pasta (colocados por fora) viram sprites novas antes de qualquer coisa ser lida. */
    private void importLoose() {
        if (SpriteLib.loose(dir).length == 0) return;
        try {
            importedLoose = lib().importLoose();
            if (importedLoose > 0) sprites.reload();
        } catch (Exception e) {
            importError = e.getMessage();
        }
    }
    public String importError;

    public static CharAssets loadChar(File dir) throws IOException {
        Dac dac = Dac.read(GameData.readAll(new File(dir, "000.dac")));
        applyDacTxt(dac, new File(dir, "000.dac"));
        Cnv cnv = readCnv(new File(dir, "000.cnv"), true);
        CharData cd = CharData.read(GameData.readAll(new File(dir, "000.bin")));
        applyBinTxt(cd, new File(dir, "000.bin"));
        CharAssets ca = new CharAssets(dir, new File(dir, "000.cnv"), dac, cnv, cd, listWavs(dir).length);
        ca.importLoose();
        return ca;
    }

    /** Texto sem comentarios, espacos e virgula final: para comparar o bloco do .txt com o que o app geraria. */
    private static String norm(String t) {
        StringBuilder sb = new StringBuilder();
        for (String ln : t.split("\n")) {
            int c = ln.indexOf("//");
            if (c >= 0) ln = ln.substring(0, c);
            sb.append(ln.replaceAll("\\s+", ""));
        }
        String r = sb.toString();
        return r.endsWith(",") ? r.substring(0, r.length() - 1) : r;
    }

    /**
     * O app grava as edicoes em 000.dac.txt (o .dac binario nao e reescrito aqui). O .txt manda (o .dac binario e so uma compilacao dele): os blocos $ANO_n
     * que diferem do binario sao lidos de volta, senao uma ANO editada/esvaziada voltaria ao que era ao reabrir o app.
     */
    static void applyDacTxt(Dac dac, File dacFile) {
        File txt = new File(dacFile.getPath() + ".txt");
        if (!txt.isFile()) return;
        String text;
        try { text = new String(GameData.readAll(txt), "UTF-8"); } catch (Exception e) { return; }
        for (int i = 0; i < dac.size(); i++) {
            int[] b = Saver.findBlock(text, "ANO_" + i);
            if (b == null) continue;
            String blk = text.substring(b[0], b[2] + 1);
            Ano old = dac.getAno(i);
            String cur = old == null ? "$ANO_" + i + ":{}" : DacText.ano(old, -1);
            String nb = norm(blk);
            if (nb.equals(norm(cur))) continue;
            try {
                Ano na = DacText.parseAno(blk, i, old);
                if (na.mpts.length == 0 && na.links.length == 0) na = new Ano(i, false, 0, 0, new Ano.Link[0], new Ano.Mpt[0]);
                dac.setAno(i, na);
            } catch (Exception ex) { /* bloco que nao le: fica o binario */ }
        }
        // ANOs que o .txt tem alem do binario (ex.: golpe transplantado de outro personagem): entram no fim da tabela
        int maxIdx = -1;
        java.util.regex.Matcher mm = java.util.regex.Pattern.compile("\\$ANO_(\\d+)\\s*:").matcher(text);
        while (mm.find()) {
            int ls = text.lastIndexOf('\n', mm.start()) + 1;
            if (text.substring(ls, mm.start()).contains("//")) continue;
            try { maxIdx = Math.max(maxIdx, Integer.parseInt(mm.group(1))); } catch (NumberFormatException ignored) { }
        }
        int old0 = dac.size();
        if (maxIdx >= old0 && maxIdx <= 0x0FFF) {
            dac.growTo(maxIdx + 1);
            for (int i = old0; i <= maxIdx; i++) {
                int[] b = Saver.findBlock(text, "ANO_" + i);
                if (b == null) continue;
                try {
                    Ano na = DacText.parseAno(text.substring(b[0], b[2] + 1), i, dac.getAno(i));
                    if (na.mpts.length > 0 || na.links.length > 0) dac.setAno(i, na);
                } catch (Exception ex) { /* bloco que nao le: o ANO fica ausente */ }
            }
        }
    }

    private static final String[] FR_KEYS = {"DUR_C", "DUR_A", "ANO", "XSPEED", "YSPEED", "XACCEL", "YACCEL", "XSPEED_A", "YSPEED_A", "XACCEL_A", "YACCEL_A", "COMP", "WALL", "VOZ"};

    /** O 000.bin.txt manda sobre o 000.bin: golpes ($GOLPE_n) e tabelas de reacao ($REACAO_DANO_n) sao lidos dele. */
    static void applyBinTxt(CharData cd, File binFile) {
        File txt = new File(binFile.getPath() + ".txt");
        if (!txt.isFile()) return;
        String text;
        try { text = new String(GameData.readAll(txt), "UTF-8"); } catch (Exception e) { return; }
        for (int i = 0; i < cd.moves.length; i++) {
            int[] b = Saver.findBlock(text, "GOLPE_" + i);
            if (b == null) continue;
            try { DacText.parseMove(text.substring(b[0], b[2] + 1), cd.moves[i]); } catch (Exception ex) { /* fica o binario */ }
        }
        int[] bb = Saver.findBlock(text, "STATUS_BASE_E_FISICA");
        if (bb != null) {
            String blk = text.substring(bb[0], bb[2] + 1);
            java.util.regex.Matcher mw = java.util.regex.Pattern.compile("\\$LARGURA\\s*:\\s*(\\d+)").matcher(blk);
            java.util.regex.Matcher mh = java.util.regex.Pattern.compile("\\$ALTURA\\s*:\\s*(\\d+)").matcher(blk);
            if (mw.find() && mh.find()) cd.setBody(Integer.parseInt(mw.group(1)) * 2, Integer.parseInt(mh.group(1)));
            java.util.regex.Matcher mp = java.util.regex.Pattern.compile("\\$DISTANCIA_AGARRE\\s*:\\s*(\\d+)").matcher(blk);
            if (mp.find()) cd.setPullDistance(Integer.parseInt(mp.group(1)));
        }
        int[][] evs = CutsceneText.parse(text);                  // $ROTEIRO_CUTSCENE (HDAT 13): o texto manda sobre o binario
        if (evs != null) cd.loadEvents(evs);
        for (int ty = 0; ty < CharData.REACTION_COUNT; ty++) {
            ReactionTable t = cd.reaction(ty);
            int[] b = Saver.findBlock(text, "REACAO_DANO_" + ty);
            if (t == null || b == null) continue;
            StringBuilder sb = new StringBuilder();
            for (String ln : text.substring(b[1], b[2] + 1).split("\n")) {
                int c = ln.indexOf("//");
                sb.append(c >= 0 ? ln.substring(0, c) : ln).append('\n');
            }
            java.util.regex.Matcher fm = java.util.regex.Pattern.compile("\\$FR_(\\d+)\\s*:\\s*\\{([^}]*)\\}").matcher(sb);
            java.util.TreeMap<Integer, int[]> rows = new java.util.TreeMap<Integer, int[]>();
            while (fm.find()) {
                int[] v = new int[FR_KEYS.length];
                java.util.regex.Matcher km = java.util.regex.Pattern.compile("\\$([A-Za-z_]+)\\s*:\\s*(-?\\d+)").matcher(fm.group(2));
                while (km.find()) for (int k = 0; k < FR_KEYS.length; k++) if (FR_KEYS[k].equalsIgnoreCase(km.group(1))) v[k] = Integer.parseInt(km.group(2));
                rows.put(Integer.valueOf(Integer.parseInt(fm.group(1))), v);
            }
            if (rows.isEmpty()) continue;
            ReactionTable nt = new ReactionTable(new byte[rows.size() * ReactionTable.STRIDE], rows.size());
            int r = 0;
            for (int[] v : rows.values()) { for (int k = 0; k < v.length; k++) nt.set(r, k, v[k]); r++; }
            t.restoreFrom(nt);
        }
    }

    /** assets/effect: usa o primeiro .dac e o primeiro .cnv da pasta (escala 1, nao e personagem). */
    public static CharAssets loadEffect(File assetsRoot) throws IOException {
        File dir = new File(assetsRoot, "effect");
        File dacF = first(dir, ".dac");
        File cnvF = first(dir, ".cnv");
        if (dacF == null || cnvF == null)
            throw new IOException("effect: .dac/.cnv nao encontrados em " + dir.getPath());
        Dac dac = Dac.read(GameData.readAll(dacF));
        Cnv cnv = readCnv(cnvF, false);
        CharAssets ca = new CharAssets(dir, cnvF, dac, cnv, null, 0);
        ca.importLoose();
        return ca;
    }

    /** So DAC, CNV e sprites do personagem, para previas (sem 000.bin, sem importar PNGs soltas e sem mexer no CNV lido por ultimo). */
    public static CharAssets loadPreview(File dir) throws IOException {
        String kind = lastCnvKind;
        try {
            Dac dac = Dac.read(GameData.readAll(new File(dir, "000.dac")));
            applyDacTxt(dac, new File(dir, "000.dac"));
            Cnv cnv = readCnv(new File(dir, "000.cnv"), true);
            return new CharAssets(dir, new File(dir, "000.cnv"), dac, cnv, null, 0);
        } finally {
            lastCnvKind = kind;
        }
    }

    /** Pack auxiliar do personagem (charfNN): escala 1, 000.dac/000.cnv ou os primeiros .dac/.cnv da pasta. */
    public static CharAssets loadPack(File dir) throws IOException {
        File dacF = new File(dir, "000.dac");
        File cnvF = new File(dir, "000.cnv");
        if (!dacF.isFile()) dacF = first(dir, ".dac");
        if (!cnvF.isFile()) cnvF = first(dir, ".cnv");
        if (dacF == null || cnvF == null) throw new IOException(dir.getName() + ": .dac/.cnv nao encontrados");
        CharAssets ca = new CharAssets(dir, cnvF, Dac.read(GameData.readAll(dacF)), readCnv(cnvF, false), null, 0);
        ca.importLoose();
        return ca;
    }

    /** Recontagem depois de adicionar/trocar sons. */
    public void refreshWavCount() { wavCount = listWavs(dir).length; }

    public static File[] listWavs(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) return new File[0];
        java.util.ArrayList<File> out = new java.util.ArrayList<File>();
        for (File f : fs) if (f.isFile() && f.getName().toLowerCase().endsWith(".wav")) out.add(f);
        File[] a = out.toArray(new File[0]);
        Arrays.sort(a);
        return a;
    }

    private static File first(File dir, String ext) {
        File[] fs = dir.listFiles();
        if (fs == null) return null;
        Arrays.sort(fs);
        for (File f : fs) if (f.isFile() && f.getName().toLowerCase().endsWith(ext)) return f;
        return null;
    }

    public static final int KIND_NORMAL = 0, KIND_PROJECTILE = 1, KIND_ATTACK = 2;
    private int[] kinds;

    /** Tipo de cada ANO: 2 = tem hitbox flag 2 (ataque), 1 = tem flag 0 (projetil), 0 = resto. Considera os links. */
    public int[] anoKinds() {
        if (kinds != null) return kinds;
        int n = dac.size();
        int[] k = new int[n];
        for (int i = 0; i < n; i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            int kind = kindOf(a);
            for (int l = 0; l < a.links.length; l++) {
                Ano c = dac.getAno(a.links[l].getAno());
                if (c != null && c.present && c != a) kind = Math.max(kind, kindOf(c));
            }
            k[i] = kind;
        }
        kinds = k;
        return k;
    }

    private static int kindOf(Ano a) {
        int kind = KIND_NORMAL;
        for (int m = 0; m < a.mpts.length; m++) {
            Ano.Hit[] hs = a.mpts[m].hits;
            for (int h = 0; h < hs.length; h++) {
                if (hs[h].flag == 2) return KIND_ATTACK;
                if (hs[h].flag == 0) kind = KIND_PROJECTILE;
            }
        }
        return kind;
    }

    /** Depois de criar/trocar ANOs: o cache de {@link #anoKinds()} e refeito na proxima chamada. */
    public void invalidateKinds() { kinds = null; }

    public void release() { sprites.clear(); if (lib != null) { lib.release(); lib = null; } }
}
