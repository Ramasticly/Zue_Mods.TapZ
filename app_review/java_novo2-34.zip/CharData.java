package com.zue.attackeditor;

import java.io.IOException;

/**
 * 000.bin do personagem: HDAT 4 (atributos de golpe, 48 bytes por golpe) e HDAT 14-33
 * (reacoes de dano que este personagem aplica ao oponente, indices 30-49 do OPT 1).
 */
public final class CharData {
    public static final int MOVE_STRIDE = 48;
    public static final int HDAT_MOVES = 4;
    public static final int FIRST_REACTION_HDAT = 14;
    public static final int REACTION_COUNT = 20;

    /** Campos do HDAT 4 (s16 little-endian), com os offsets do hdatChar.exHDAT4. */
    public static final class Move {
        public int flags;
        public int animInicial;
        public int projNormal;
        public int projAbaixo;
        public int projAcima;
        public int projGlobal;
        public int projAoAcertar;
        public int projChao;
        public int homing;
        public int homingSpeed;
        public int maxRep;
        public int subId;
        public int subAoAcertar;
        public int subChao;
        public int animAoAcertar;
        public int animSeqChao, animEndChao, animSeqAr, animEndAr;
        public int pousoErrar, pousoAcertar;
        public int oponenteAgarrado;
        public int unk44, unk46;
        /** true = ANO tocado sozinho (nao e golpe do HDAT 4): segue as regras de estado do jogo (md 886/891). */
        public boolean generic;
        /** true = ANO de projetil aberta sozinha: o oponente se orienta pelo personagem real, nao pelo projetil. */
        public boolean projectile;
        /** O que o ANO aberto sozinho e (so vale com {@link #generic}): personagem, projetil (md 970/971) ou efeito/aura (md 965/977). */
        public static final int ROOT_CHAR = 0, ROOT_PROJ = 1, ROOT_EFFECT = 2;
        public int rootKind = ROOT_CHAR;

        /** Copia todos os campos do HDAT 4 (edicao em runtime). */
        public void copyFrom(Move o) {
            flags = o.flags; animInicial = o.animInicial; projNormal = o.projNormal; projAbaixo = o.projAbaixo;
            projAcima = o.projAcima; projGlobal = o.projGlobal; projAoAcertar = o.projAoAcertar; projChao = o.projChao;
            homing = o.homing; homingSpeed = o.homingSpeed; maxRep = o.maxRep; subId = o.subId;
            subAoAcertar = o.subAoAcertar; subChao = o.subChao; animAoAcertar = o.animAoAcertar;
            animSeqChao = o.animSeqChao; animEndChao = o.animEndChao; animSeqAr = o.animSeqAr; animEndAr = o.animEndAr;
            pousoErrar = o.pousoErrar; pousoAcertar = o.pousoAcertar; oponenteAgarrado = o.oponenteAgarrado;
            unk44 = o.unk44; unk46 = o.unk46;
        }

        /**
         * Cada campo do golpe (HDAT 4, 24 colunas de 2 bytes) e um short: o jogo monta o valor com dois bytes (BulletAction jogo:2590-2591,
         * ANIM_INICIAL 2569-2570, SEQ/END 13260-13265, ...). ANOs acima de 255 sao normais (ex.: 310, 342, 368).
         */
        public static final int MAX = 32767;

        public void clamp() {
            flags = Math.min(MAX, flags); animInicial = Math.min(MAX, animInicial); projNormal = Math.min(MAX, projNormal);
            projAbaixo = Math.min(MAX, projAbaixo); projAcima = Math.min(MAX, projAcima); projGlobal = Math.min(MAX, projGlobal);
            projAoAcertar = Math.min(MAX, projAoAcertar); projChao = Math.min(MAX, projChao); homing = Math.min(MAX, homing);
            homingSpeed = Math.min(MAX, homingSpeed); maxRep = Math.min(MAX, maxRep); subId = Math.min(MAX, subId);
            subAoAcertar = Math.min(MAX, subAoAcertar); subChao = Math.min(MAX, subChao); animAoAcertar = Math.min(MAX, animAoAcertar);
            animSeqChao = Math.min(MAX, animSeqChao); animEndChao = Math.min(MAX, animEndChao);
            animSeqAr = Math.min(MAX, animSeqAr); animEndAr = Math.min(MAX, animEndAr);
            pousoErrar = Math.min(MAX, pousoErrar); pousoAcertar = Math.min(MAX, pousoAcertar);
            oponenteAgarrado = Math.min(MAX, oponenteAgarrado); unk44 = Math.min(MAX, unk44); unk46 = Math.min(MAX, unk46);
        }

        /** Golpe com repeticao de projetil: tipos 0, 3 e 6 do HDAT 4 com MAX_REPETICOES > 0 (usa a janela 512 do frame). */
        public boolean repeats(int moveIndex) { return (moveIndex == 0 || moveIndex == 3 || moveIndex == 6) && maxRep > 0; }

        /** Tem sequencia (SEQ chao/ar ou SEQ_PROJETIL): a sequencia assume no acerto e a flag 128 (agarrao com hit) nao chega a agarrar. */
        public boolean hasSequence() { return animSeqChao > 0 || animSeqAr > 0 || animAoAcertar > 0; }

        /** Agarrao que pode funcionar de fato: flag 8, ou 128 em golpe sem sequencia. */
        public boolean grabWorks() { return (flags & 8) != 0 || ((flags & 128) != 0 && !hasSequence()); }

        /** Ha projetil definido (animacao de lancamento normal, abaixo ou acima). */
        public boolean hasProjectile() { return projNormal != 0 || projAbaixo != 0 || projAcima != 0; }

        /** Golpe com agarrao (ATK_FLAGS 8 ou 128): tambem usa a janela 512 do frame. */
        public boolean grabs() { return (flags & (8 | 128)) != 0; }

        public Move copy() { Move m = new Move(); m.copyFrom(this); m.generic = generic; m.projectile = projectile; m.rootKind = rootKind; return m; }
    }

    /** Golpe vazio cuja ANIM_INICIAL e {@code ano} (para tocar ANOs que nao sao golpes). */
    public static Move blank(int ano) {
        Move m = new Move();
        m.animInicial = ano;
        m.generic = true;
        return m;
    }

    /**
     * Modo ANO: toca so o ANO. Ignora o HDAT 4 (ANIM_AO_ACERTAR, SEQ, END, pouso, agarrao);
     * mantem apenas o necessario para as flags do proprio DAC criarem projeteis (ANOs de projetil).
     * {@code src} pode ser null.
     */
    public static Move genericFrom(int ano, Move src) {
        Move m = blank(ano);
        if (src == null) return m;
        m.flags = src.flags;
        m.projNormal = src.projNormal; m.projAbaixo = src.projAbaixo; m.projAcima = src.projAcima;
        m.projGlobal = src.projGlobal; m.projAoAcertar = src.projAoAcertar; m.projChao = src.projChao;
        m.homing = src.homing; m.homingSpeed = src.homingSpeed; m.maxRep = src.maxRep;
        m.subId = src.subId; m.subAoAcertar = src.subAoAcertar; m.subChao = src.subChao;
        return m;
    }

    /**
     * Golpe do HDAT 4 que "dono" do ANO: primeiro o que o tem como ANIM_INICIAL; senao qualquer
     * golpe que o referencia (SEQ, END, AO_ACERTAR, pouso, agarrao, projeteis). Serve para saber
     * qual projetil uma flag 0 do ANO cria. Retorna null se nenhum golpe usa o ANO.
     */
    public Move ownerOf(int ano) {
        for (Move m : moves) if (m.animInicial == ano) return m;
        for (Move m : moves) {
            int[] refs = {m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr, m.animEndAr,
                    m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado,
                    m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao,
                    m.subId, m.subAoAcertar, m.subChao};
            for (int r : refs) if (r == ano && r != 0) return m;
        }
        return null;
    }

    /**
     * Que tipo de objeto e o ANO quando aberto sozinho (modo ANO): ANIM_INICIAL de algum golpe = personagem; ANO de projetil de algum golpe
     * (PROJETIL_*, SUBPROJETIL_*) = projetil; 201..255 (auras/efeitos das flags 71-125) = efeito; o resto = personagem.
     */
    public int rootKindOf(int ano) {
        for (Move m : moves) if (m.animInicial == ano) return Move.ROOT_CHAR;
        for (Move m : moves) {
            int[] refs = {m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao, m.subId, m.subAoAcertar, m.subChao};
            for (int r : refs) if (r == ano && r != 0) return Move.ROOT_PROJ;
        }
        return ano >= 201 && ano <= 255 ? Move.ROOT_EFFECT : Move.ROOT_CHAR;
    }

    public final Move[] moves;
    /** AirType: HDAT 3, byte 6 (PODE_VOAR) != 0 (personagem voa). Sem HDAT 3 assume que voa. */
    public boolean flies = true;
    /** Meia largura do corpo: HDAT 3, byte 3, dividido por 2 (px). Usada nas paredes. */
    public int halfWidth = 30;
    private final ReactionTable[] reactions = new ReactionTable[REACTION_COUNT];
    private byte[] h3 = new byte[0];
    private byte[] h7 = new byte[0];
    /** HDAT 13 (eventos da flag 20): geometria do cabecalho (XSize em shorts => linha = 2*XSize bytes, YSize linhas), lida do arquivo inteiro como o jogo. */
    private byte[] raw = new byte[0];
    private int h13Start, h13Cols, h13Rows;
    private int h7Stride = 0;

    private static int u(byte[] b, int i) { return i >= 0 && i < b.length ? (b[i] & 255) : 0; }

    private int levelSum(int col, int level) {
        if (h7Stride <= 0) return 0;
        int last = Math.min(level, 98), sum = 0;
        for (int r = 0; r <= last; r++) sum += u(h7, r * h7Stride + col);
        return sum;
    }

    /** GetHP: HDAT 3 byte 11 + soma da coluna 0 do HDAT 7 (linhas 0..nivel, maximo 98). Sem HDAT 3 assume 100. */
    /** Corpo do jogador (HDAT 3): largura total = byte 3 (a meia largura das paredes e metade disso), altura = byte 4, em px. */
    public int bodyWidth() { return u(h3, 3); }

    /** HDAT 3, byte 13: reacao em que o oponente entra quando a hitbox do golpe destroi a dele (ATK_FLAGS 2); 30 ou mais = tabela do personagem. */
    public int clashReaction() { return u(h3, 13); }

    /** "do jogo N" (0 a 29) ou "do personagem N" (30 ou mais vira N - 30), como o jogo escolhe a reacao (md 876 / 877). */
    public static String reactionName(int raw) { return raw >= 30 ? "do personagem " + (raw - 30) : "do jogo " + raw; }
    public int bodyHeight() { return u(h3, 4); }

    /** Muda largura/altura do corpo direto no HDAT 3 (largura sempre par: o .txt guarda a metade). */
    public void setBody(int width, int height) {
        if (h3.length < 5) h3 = java.util.Arrays.copyOf(h3, 5);
        int w = Math.max(0, Math.min(254, width)) & ~1;
        h3[3] = (byte) w;
        h3[4] = (byte) Math.max(0, Math.min(255, height));
        halfWidth = w / 2;
    }

    /** Distancia (px) em que o agarrao simples/condicional (flags 8/128) deixa o atacante do oponente: HDAT 3, byte 5. */
    public int pullDistance() { return u(h3, 5); }

    /** Muda a distancia do agarrao (HDAT 3, byte 5; 0 a 255 px). */
    public void setPullDistance(int px) {
        if (h3.length < 6) h3 = java.util.Arrays.copyOf(h3, 6);
        h3[5] = (byte) Math.max(0, Math.min(255, px));
    }

    public int hp(int level) { return h3.length > 11 ? u(h3, 11) + levelSum(0, level) : 100; }
    /** GetAttack: HDAT 3 byte 12 + coluna 1 do HDAT 7. */
    public int attackMul(int level) { return h3.length > 12 ? u(h3, 12) + levelSum(1, level) : 100; }
    /** GetDeffence: HDAT 3 byte 14 + coluna 3 do HDAT 7. */
    public int defenceMul(int level) { return h3.length > 14 ? u(h3, 14) + levelSum(3, level) : 0; }

    /**
     * Eventos de cutscene (flag 20, md 996): a linha {@code id} do HDAT 13 comeca em {@code id * 2 * XSize} bytes e o jogo mata a task
     * quando {@code id >= YSize}. {@code hasEvent} = linha existe (id < YSize do cabecalho).
     */
    public boolean hasEvent(int id) { return id >= 0 && id < h13Rows; }
    /** Linhas (YSize) e shorts por linha (XSize) do HDAT 13, como no cabecalho. */
    public int eventRows() { return h13Rows; }
    public int eventCols() { return h13Cols; }
    /** Campo s16 de byte-offset {@code off} da linha {@code id}; o jogo le o arquivo inteiro, entao campos alem da linha vazam para a seguinte. */
    public int eventField(int id, int off) {
        int i = id * h13Cols + off / 2;
        if (i >= 0 && i < h13.length && id >= 0) return h13[i];          // copia editavel (campos alem da linha vazam para a seguinte, como no jogo)
        int p = h13Start + id * 2 * h13Cols + off;
        if (h13Edited || p < 0 || p + 1 >= raw.length) return 0;
        return (short) ((raw[p] & 255) | ((raw[p + 1] & 255) << 8));
    }

    // ---- edicao do HDAT 13 (linhas de 8 shorts: ALVO, DURACAO, Z_LAYER, ANIM_ID, ANIM_FLIP, CAM_MODE, TRAVAR_VIT, FLAG) ----
    public static final int EV_ALVO = 0, EV_DURACAO = 2, EV_Z = 4, EV_ANIM = 6, EV_ANIM_FLIP = 8, EV_CAM = 10, EV_STUN = 12, EV_FLAG = 14, EV_COLS = 8;
    private short[] h13 = new short[0];
    private boolean h13Edited;

    /** Os eventos foram mudados no app (o Saver so regrava o HDAT 13 quando isso e verdade). */
    public boolean eventsEdited() { return h13Edited; }

    /** Muda um campo (deslocamento em bytes, par) da linha {@code id}; ignora linha/campo inexistente. */
    public void setEventField(int id, int off, int v) {
        int i = id * h13Cols + off / 2;
        if (!hasEvent(id) || off < 0 || off / 2 >= h13Cols || i >= h13.length) return;
        h13[i] = (short) v;
        h13Edited = true;
    }

    /** Nova linha no fim (copia de {@code copyFrom}, ou zerada se invalido); devolve o id novo. */
    public int addEvent(int copyFrom) {
        if (h13Cols <= 0) { h13Cols = EV_COLS; h13Rows = 0; h13 = new short[0]; }
        short[] n = java.util.Arrays.copyOf(h13, (h13Rows + 1) * h13Cols);
        if (hasEvent(copyFrom)) System.arraycopy(h13, copyFrom * h13Cols, n, h13Rows * h13Cols, h13Cols);
        h13 = n;
        h13Edited = true;
        return h13Rows++;
    }

    /** Tira a ultima linha (tirar do meio mudaria o numero dos eventos seguintes, que os hits usam). */
    public boolean removeLastEvent() {
        if (h13Rows <= 0) return false;
        h13Rows--;
        h13 = java.util.Arrays.copyOf(h13, h13Rows * h13Cols);
        h13Edited = true;
        return true;
    }

    /** Zera a linha (o evento fica sem animacao nem efeito). */
    public void clearEvent(int id) {
        if (!hasEvent(id)) return;
        for (int c = 0; c < h13Cols; c++) h13[id * h13Cols + c] = 0;
        h13Edited = true;
    }

    /** Foto dos eventos (para desfazer). */
    public static final class EventsSnap {
        final short[] flat; final int rows, cols; final boolean edited;
        EventsSnap(short[] f, int r, int c, boolean e) { flat = f; rows = r; cols = c; edited = e; }
    }

    public EventsSnap snapshotEvents() { return new EventsSnap(h13.clone(), h13Rows, h13Cols, h13Edited); }

    public void restoreEvents(EventsSnap s) {
        h13 = s.flat.clone();
        h13Rows = s.rows;
        h13Cols = s.cols;
        h13Edited = s.edited;
    }

    /** Eventos lidos do 000.bin.txt ($ROTEIRO_CUTSCENE): o texto manda sobre o binario. Cada linha tem {@link #EV_COLS} shorts. */
    public void loadEvents(int[][] rowsIn) {
        if (rowsIn == null) return;
        int oldCols = h13Cols;
        short[] old = h13;
        h13Cols = EV_COLS;
        h13Rows = rowsIn.length;
        h13 = new short[h13Rows * h13Cols];
        for (int r = 0; r < rowsIn.length; r++) for (int c = 0; c < EV_COLS && c < rowsIn[r].length; c++) h13[r * h13Cols + c] = (short) rowsIn[r][c];
        h13Edited = false;
    }

    /** Linha inteira {@code id} (EV_COLS campos); zeros se nao existe. */
    public int[] eventRow(int id) {
        int[] out = new int[EV_COLS];
        for (int c = 0; c < EV_COLS; c++) out[c] = eventField(id, c * 2);
        return out;
    }

    private CharData(Move[] moves, HdatTable t, byte[] raw) {
        this.moves = moves;
        this.raw = raw;
        if (t.size() > 3) h3 = t.bytes(3);
        if (t.size() > 13) {
            h13Start = t.start(13); h13Cols = t.cols(13); h13Rows = t.rows(13);
            int n = Math.max(0, h13Rows * h13Cols);
            h13 = new short[n];
            for (int i = 0; i < n; i++) {
                int q = h13Start + i * 2;
                h13[i] = (short) (u(raw, q) | (u(raw, q + 1) << 8));
            }
        }
        if (t.size() > 7 && t.rows(7) > 0) { h7 = t.bytes(7); h7Stride = h7.length / t.rows(7); }
        for (int i = 0; i < REACTION_COUNT; i++) {
            int h = FIRST_REACTION_HDAT + i;
            reactions[i] = new ReactionTable(t.bytes(h), t.rows(h));
        }
    }

    public static CharData read(byte[] bin) throws IOException {
        HdatTable t = HdatTable.parse(bin);
        if (t.size() <= HDAT_MOVES) throw new IOException("000.bin sem HDAT 4");
        byte[] b = t.bytes(HDAT_MOVES);
        int n = b.length / MOVE_STRIDE;
        Move[] moves = new Move[n];
        for (int i = 0; i < n; i++) {
            int p = i * MOVE_STRIDE;
            Move m = new Move();
            m.flags = s16(b, p);
            m.animInicial = s16(b, p + 2);
            m.projNormal = s16(b, p + 4);
            m.projAoAcertar = s16(b, p + 6);
            m.pousoErrar = s16(b, p + 8);
            m.animSeqChao = s16(b, p + 10);
            m.animEndChao = s16(b, p + 12);
            m.animSeqAr = s16(b, p + 14);
            m.animEndAr = s16(b, p + 16);
            m.subId = s16(b, p + 18);
            m.subAoAcertar = s16(b, p + 20);
            m.pousoAcertar = s16(b, p + 22);
            m.oponenteAgarrado = s16(b, p + 24);
            m.homing = s16(b, p + 26);
            m.homingSpeed = s16(b, p + 28);
            m.maxRep = s16(b, p + 30);
            m.animAoAcertar = s16(b, p + 32);
            m.projAbaixo = s16(b, p + 34);
            m.projAcima = s16(b, p + 36);
            m.projGlobal = s16(b, p + 38);
            m.projChao = s16(b, p + 40);
            m.subChao = s16(b, p + 42);
            if (p + 48 <= b.length) { m.unk44 = s16(b, p + 44); m.unk46 = s16(b, p + 46); }
            moves[i] = m;
        }
        CharData cd = new CharData(moves, t, bin);
        if (t.size() > 3 && t.bytes(3).length >= 7) cd.flies = (t.bytes(3)[6] & 255) != 0;       // PODE_VOAR (byte 6)
        if (t.size() > 3 && t.bytes(3).length >= 4) cd.halfWidth = (t.bytes(3)[3] & 255) / 2;       // LARGURA (byte 3 / 2)
        return cd;
    }

    /** Os 48 bytes (24 shorts) do golpe no HDAT 4: o inverso da leitura em {@link #read}. */
    static byte[] moveBytes(Move m) {
        int[] v = new int[MOVE_STRIDE / 2];
        v[0] = m.flags; v[1] = m.animInicial; v[2] = m.projNormal; v[3] = m.projAoAcertar; v[4] = m.pousoErrar; v[5] = m.animSeqChao; v[6] = m.animEndChao;
        v[7] = m.animSeqAr; v[8] = m.animEndAr; v[9] = m.subId; v[10] = m.subAoAcertar; v[11] = m.pousoAcertar; v[12] = m.oponenteAgarrado; v[13] = m.homing;
        v[14] = m.homingSpeed; v[15] = m.maxRep; v[16] = m.animAoAcertar; v[17] = m.projAbaixo; v[18] = m.projAcima; v[19] = m.projGlobal; v[20] = m.projChao;
        v[21] = m.subChao; v[22] = m.unk44; v[23] = m.unk46;
        byte[] b = new byte[MOVE_STRIDE];
        for (int i = 0; i < v.length; i++) { b[i * 2] = (byte) v[i]; b[i * 2 + 1] = (byte) (v[i] >> 8); }
        return b;
    }

    /** Personagem lido do TXT {@code 000.bin.txt} (formato BIN_CNV_): os bytes de HDAT sao montados na memoria ({@link BinTxt}); nenhum binario e lido. */
    public static CharData fromTxt(String text) throws IOException {
        return read(BinTxt.compile(text));
    }

    /** Reacao do char (tipo 0..19 = indice 30..49 do OPT 1) ou null. */
    public ReactionTable reaction(int type) {
        return (type >= 0 && type < REACTION_COUNT) ? reactions[type] : null;
    }

    private static int s16(byte[] b, int p) {
        if (p + 2 > b.length) return 0;
        return (short) ((b[p] & 255) | ((b[p + 1] & 255) << 8));
    }
}
