package com.zue.attackeditor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Logica pura da grade de escolha de personagens (atacante / oponente): nomes, ANO da previa, destaque e quais previas manter na memoria. */
final class CharGrid {
    private CharGrid() { }

    /** ANO mostrada na previa de cada personagem. */
    static final int PREVIEW_ANO = 76;
    static final int COLUMNS = 3;
    /** Quantas previas (DAC + CNV + sprites) ficam carregadas ao mesmo tempo. */
    static final int KEEP = 15;

    /** ANO da previa: a 76 se o personagem a tem; senao a 0 (parado); -1 se nem essa existe. */
    static int previewAno(Dac d) {
        if (d == null) return -1;
        return usable(d.getAno(PREVIEW_ANO)) ? PREVIEW_ANO : usable(d.getAno(0)) ? 0 : -1;
    }

    private static boolean usable(Ano a) { return a != null && a.present && a.mpts.length > 0; }

    /** Nomes das pastas, na ordem dada. */
    static List<String> names(List<File> dirs) {
        List<String> out = new ArrayList<String>();
        for (File f : dirs) out.add(f.getName());
        return out;
    }

    /** Indice do personagem pelo nome; -1 se nao esta na lista. */
    static int indexOf(List<String> names, String name) {
        return names.indexOf(name);
    }

    /** O cartao {@code i} e o personagem atual (vem destacado). */
    static boolean isCurrent(int i, int selected) { return i == selected; }

    /** Primeiro cartao a mostrar ao abrir: a linha do atual fica no topo (uma linha de folga acima, se houver). */
    static int scrollTo(int selected, int count) {
        if (selected < 0 || selected >= count) return 0;
        int row = selected / COLUMNS;
        return Math.max(0, row - 1) * COLUMNS;
    }

    /**
     * Qual previa descarregar quando passa de {@link #KEEP}: a mais antiga (ordem de uso) que nao esta na tela; -1 se nada a descarregar.
     * {@code attached}: para cada previa carregada, da mais antiga para a mais nova, se a View dela ainda esta na tela.
     */
    static int evict(List<Boolean> attached) {
        if (attached.size() <= KEEP) return -1;
        for (int i = 0; i < attached.size(); i++) if (!attached.get(i).booleanValue()) return i;
        return -1;
    }

    /** Rotulo do cartao: nome da pasta, com marca no atual. */
    static String label(String name, boolean current) {
        return current ? "✓ " + name + "  (atual)" : name;
    }
}
