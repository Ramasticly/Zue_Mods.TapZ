package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Escolha de personagem em grade escura: cada pasta charNN com a previa animada da ANO 76 dela (ou a 0). O DAC, o CNV e as sprites de cada um so
 * carregam quando o cartao aparece (fora da thread da tela) e as mais antigas fora da tela sao descarregadas; tudo e liberado ao fechar.
 */
final class CharPicker {
    interface Listener { void onPick(int index); }

    private static final class Entry {
        CharAssets assets;
        AnimPreview view;
    }

    private final Activity a;
    private final List<File> dirs;
    private final int selected;
    private final Listener listener;
    private final float d;
    private Dialog dlg;
    private boolean closed;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Map<Integer, Entry> loaded = new LinkedHashMap<Integer, Entry>();

    static void show(Activity a, String title, List<File> dirs, int selected, Listener l) {
        new CharPicker(a, dirs, selected, l).open(title);
    }

    private CharPicker(Activity a, List<File> dirs, int selected, Listener l) {
        this.a = a; this.dirs = dirs; this.selected = selected; this.listener = l;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void open(String title) {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv(title, 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        TextView hint = tv("Cada personagem mostra a ANO " + CharGrid.PREVIEW_ANO + " dele (a ANO 0 se não tiver). Toque para escolher.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(8));
        root.addView(hint);

        final GridView gv = new GridView(a);
        gv.setNumColumns(CharGrid.COLUMNS);
        gv.setVerticalSpacing(dp(6));
        gv.setHorizontalSpacing(dp(6));
        final int side = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(12)) / CharGrid.COLUMNS - dp(8);
        gv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return dirs.size(); }
            @Override public Object getItem(int i) { return Integer.valueOf(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(final int i, View cv, ViewGroup parent) {
                boolean cur = CharGrid.isCurrent(i, selected);
                LinearLayout cell = new LinearLayout(a);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                GradientDrawable g = new GradientDrawable();
                g.setColor(cur ? LayoutManager.PANEL_HI : LayoutManager.PANEL);
                g.setCornerRadius(dp(8));
                if (cur) g.setStroke(dp(2), LayoutManager.ACCENT);
                cell.setBackground(g);
                cell.setPadding(dp(3), dp(3), dp(3), dp(3));
                AnimPreview pv = new AnimPreview(a);
                pv.setZoom(1.2f);
                pv.setBackgroundColor(0xFF0D0F13);
                pv.setLoading(true);
                cell.addView(pv, new LinearLayout.LayoutParams(side, side));
                TextView n = tv(CharGrid.label(dirs.get(i).getName(), cur), 11, cur ? LayoutManager.ACCENT : LayoutManager.TEXT, true);
                n.setGravity(Gravity.CENTER);
                cell.addView(n);
                cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); listener.onPick(i); } });
                bind(i, pv);
                return cell;
            }
        });
        root.addView(gv, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView back = tv("VOLTAR", 13, LayoutManager.DIM, true);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL_HI);
        bg.setCornerRadius(dp(8));
        back.setBackground(bg);
        back.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        root.addView(back);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface di) { closeAll(); }
        });
        dlg.show();
        gv.setSelection(CharGrid.scrollTo(selected, dirs.size()));
    }

    /** Liga a View do cartao ao personagem {@code i}: usa o que ja esta carregado ou carrega em segundo plano. */
    private void bind(final int i, final AnimPreview pv) {
        Entry e = loaded.get(i);
        if (e != null && e.assets != null) {
            loaded.remove(i);                    // reinsere no fim: mais recente
            loaded.put(i, e);
            e.view = pv;
            show(e.assets, pv);
            return;
        }
        pool.execute(new Runnable() { public void run() {
            if (closed) return;
            CharAssets ca;
            try { ca = CharAssets.loadPreview(dirs.get(i)); }
            catch (Throwable t) { a.runOnUiThread(new Runnable() { public void run() { if (!closed) pv.setLoading(false); } }); return; }
            final CharAssets got = ca;
            a.runOnUiThread(new Runnable() { public void run() {
                if (closed) { got.release(); return; }
                Entry old = loaded.get(i);
                if (old != null && old.assets != null) got.release();
                else {
                    Entry en = new Entry();
                    en.assets = got;
                    loaded.put(i, en);
                    old = en;
                }
                old.view = pv;
                show(old.assets, pv);
                trim();
            } });
        } });
    }

    private static void show(CharAssets ca, AnimPreview pv) {
        int ano = CharGrid.previewAno(ca.dac);
        if (ano >= 0) pv.set(ca.dac, ca.sprites, ano);
        else pv.setLoading(false);                   // terminou de carregar e nao ha ANO 76 nem 0: "sem animacao"
    }

    /** Passou de KEEP: descarrega as mais antigas cujo cartao ja saiu da tela. */
    private void trim() {
        while (true) {
            List<Integer> keys = new ArrayList<Integer>(loaded.keySet());
            List<Boolean> att = new ArrayList<Boolean>();
            for (Integer k : keys) { Entry e = loaded.get(k); att.add(Boolean.valueOf(e.view != null && e.view.isAttachedToWindow())); }
            int v = CharGrid.evict(att);
            if (v < 0) return;
            Entry e = loaded.remove(keys.get(v));
            if (e != null && e.view != null) e.view.set(null, null, -1);        // a View nao desenha mais bitmaps liberados
            if (e != null && e.assets != null) e.assets.release();
        }
    }

    private void closeAll() {
        closed = true;
        pool.shutdownNow();
        for (Entry e : loaded.values()) if (e.assets != null) e.assets.release();
        loaded.clear();
    }
}
