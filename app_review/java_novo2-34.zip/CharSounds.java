package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.regex.Pattern;

/** Os WAVs de um personagem (NNN.wav depois das folhas de PNG): o som N do jogo e o N-esimo na ordem dos nomes. */
public final class CharSounds {
    private CharSounds() { }

    /** O SoundEffect do jogo guarda no maximo 20 audios por personagem (SE_MAX). */
    public static final int MAX = 20;

    private static final Pattern NUM = Pattern.compile("(\\d{3})\\.(png|wav)", Pattern.CASE_INSENSITIVE);

    public static File[] list(File dir) { return CharAssets.listWavs(dir); }

    /** Excluir = mutar: o arquivo continua (senao os seguintes mudariam de numero) e passa a ser silencio. */
    public static void mute(File wav) throws IOException {
        SpriteLib.writeAtomic(wav, AudioConvert.silentWav());
        forget(wav);
    }

    /** Troca o conteudo do WAV pelo audio escolhido, convertido para o formato do jogo. */
    public static void replace(File wav, File src) throws IOException {
        SpriteLib.writeAtomic(wav, AudioConvert.toGameWav(src));
        forget(wav);
    }

    /** Grava um WAV ja convertido por cima de um som existente. */
    public static void replaceBytes(File wav, byte[] data) throws IOException { SpriteLib.writeAtomic(wav, data); forget(wav); }

    /** Grava um WAV ja convertido como novo som no fim da lista. */
    public static File addBytes(File dir, byte[] data) throws IOException {
        if (list(dir).length >= MAX) throw new IOException("limite de " + MAX + " sons por personagem");
        File out = new File(dir, String.format(Locale.US, "%03d.wav", nextNumber(dir)));
        SpriteLib.writeAtomic(out, data);
        forget(out);
        return out;
    }

    private static final java.util.Map<String, long[]> EMPTY_CACHE = new java.util.HashMap<String, long[]>();

    /**
     * Vazio = sem nenhuma amostra diferente de zero (o silencio gerado ao excluir, ou um arquivo sem dados). O tamanho sozinho NAO decide: antes um WAV de ate 926 bytes era
     * "excluido" e o app retirava os usos dele e apagava o arquivo, mesmo sendo um som curto de verdade. O resultado fica em cache por (tamanho, data) e a leitura para no
     * primeiro byte nao zero, entao a lista nao relê todos os WAV a cada linha.
     */
    public static boolean isEmpty(File wav) {
        long len = wav.length(), mt = wav.lastModified();
        String k = wav.getAbsolutePath();
        synchronized (EMPTY_CACHE) {
            long[] c = EMPTY_CACHE.get(k);
            if (c != null && c[0] == len && c[1] == mt) return c[2] == 1;
        }
        boolean e;
        try { e = scanEmpty(wav, len); } catch (IOException ex) { return false; }
        synchronized (EMPTY_CACHE) { EMPTY_CACHE.put(k, new long[]{len, mt, e ? 1 : 0}); }
        return e;
    }

    /** Esquece o resultado guardado de {@code wav} (o arquivo foi regravado). */
    public static void forget(File wav) {
        synchronized (EMPTY_CACHE) { EMPTY_CACHE.remove(wav.getAbsolutePath()); }
    }

    private static boolean scanEmpty(File wav, long len) throws IOException {
        if (len <= 44) return true;
        java.io.FileInputStream in = new java.io.FileInputStream(wav);
        try {
            long sk = 0;
            while (sk < 44) { long n = in.skip(44 - sk); if (n <= 0) break; sk += n; }
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) for (int i = 0; i < n; i++) if (buf[i] != 0) return false;
            return true;
        } finally {
            in.close();
        }
    }

    /** Sons (numero do jogo = 80 + indice) dos WAVs vazios. */
    public static java.util.Set<Integer> emptySounds(File dir) {
        java.util.Set<Integer> s = new java.util.HashSet<Integer>();
        File[] w = list(dir);
        for (int i = 0; i < w.length; i++) if (isEmpty(w[i])) s.add(Integer.valueOf(80 + i));
        return s;
    }

    /** Sons vazios no fim da lista nao seguram o numero de ninguem: os arquivos sao apagados para liberar os espacos. Devolve quantos. */
    public static int trimTrailing(File dir) {
        File[] w = list(dir);
        int n = 0;
        for (int i = w.length - 1; i >= 0 && isEmpty(w[i]); i--) {
            if (w[i].delete()) { n++; forget(w[i]); } else break;
        }
        return n;
    }

    /** Novo WAV no fim da lista; devolve o arquivo criado. */
    public static File add(File dir, File src) throws IOException {
        if (list(dir).length >= MAX) throw new IOException("limite de " + MAX + " sons por personagem");
        byte[] wav = AudioConvert.toGameWav(src);
        File out = new File(dir, String.format(Locale.US, "%03d.wav", nextNumber(dir)));
        SpriteLib.writeAtomic(out, wav);
        forget(out);
        return out;
    }

    /** Proximo numero livre: depois do maior NNN.png / NNN.wav da pasta. */
    static int nextNumber(File dir) {
        int max = -1;
        String[] names = dir.list();
        if (names != null) {
            for (String n : names) {
                java.util.regex.Matcher m = NUM.matcher(n);
                if (m.matches()) max = Math.max(max, Integer.parseInt(m.group(1)));
            }
        }
        return max + 1;
    }
}
