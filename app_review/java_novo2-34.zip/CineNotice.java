package com.zue.attackeditor;

/**
 * Aviso da trava cinematica ao avancar tick pelo botao (Java puro), no estilo do {@link HitstopNotice}: o especial (9-12) congela tudo por
 * N ticks (md 923/926 do jogo) com o zoom da camera; enquanto isso o contador de tick mostrado fica travado e o aviso (com o botao PULAR) diz
 * quantos ticks faltam. Quando a trava acaba (ou e pulada) o aviso some e o tick e liberado.
 */
final class CineNotice {
    private int left;
    private int locked = -1;

    /** Depois de um passo do botao: {@code tick} = tick da simulacao agora, {@code cineLeft} = ticks de trava que ainda faltam. */
    void afterStep(int tick, int cineLeft) {
        if (cineLeft > 0) {
            if (left == 0) locked = tick;          // entrou na trava: o numero do tick fica neste
            left = cineLeft;
        } else {
            left = 0;
            locked = -1;
        }
    }

    void clear() { left = 0; locked = -1; }

    boolean active() { return left > 0; }
    int left() { return left; }

    /** Tick a mostrar: o travado durante a trava, o real no resto. */
    int shownTick(int realTick) { return active() ? locked : realTick; }

    /** Texto do aviso amarelo. */
    String text() {
        return "Trava cinemática: tudo fica congelado por mais " + left + (left == 1 ? " tick" : " ticks")
                + " e a câmera dá zoom de 200%. PULAR passa pela trava e libera o tick.";
    }
}
