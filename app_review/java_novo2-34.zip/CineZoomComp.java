package com.zue.attackeditor;

/**
 * "Compensar o zoom da trava cinematica" (Java puro): a camera da trava (golpes 9-12, md 923/926) da zoom de 200 % e o frame 0 do golpe fica
 * congelado na tela durante ~120 ticks. Com o frame 0 em 1 tick e zoom de sprite 50 % (100 / 200), o atacante aparece do tamanho normal sob
 * o zoom; o frame seguinte volta a escala original. O oponente, o cenario e os efeitos continuam em 200 %.
 */
final class CineZoomComp {
    private CineZoomComp() { }

    /** Escala do sprite (%) que desfaz o zoom da camera da trava. */
    static int scalePercent() { return Math.round(100f * 100f / BattleSim.CINE_ZOOM); }

    /** Vale so para golpes do HDAT 4 nos slots 9 a 12 (os que o jogo trava). */
    static boolean applies(int moveIndex, boolean generic) { return !generic && moveIndex >= 9 && moveIndex <= 12; }

    private static int zx(Ano.Mpt m) { return (m.flags & 0x80) != 0 ? m.xZoom : 100; }
    private static int zy(Ano.Mpt m) { return (m.flags & 0x80) != 0 ? m.yZoom : 100; }

    /** Ligada: frame 0 de 1 tick com a escala da compensacao em relacao ao frame seguinte. */
    static boolean isOn(Ano.Mpt[] m) {
        if (m == null || m.length < 2 || FrameTools.ticks(m[0]) != 1) return false;
        int s = scalePercent();
        return (m[0].flags & 0x80) != 0 && m[0].xZoom == zx(m[1]) * s / 100 && m[0].yZoom == zy(m[1]) * s / 100;
    }

    private static void setZoom(Ano.Mpt p, int x, int y) {
        x = Math.max(1, Math.min(4095, x));
        y = Math.max(1, Math.min(4095, y));
        if ((p.flags & 0x80) == 0) { p.flags |= 0x80; p.rot = 0; p.alphaRaw = 0; }
        p.xZoom = x;
        p.yZoom = y;
        if (p.rot == 0 && p.alphaRaw == 0 && x == 100 && y == 100) { p.flags &= ~0x80; p.xZoom = 100; p.yZoom = 100; }
        p.normalize();
    }

    /** Liga: o 1o tick do golpe (frame 0 dividido em 1 tick + resto, se preciso) fica na escala compensada. Devolve {@code m} se nao ha o que fazer. */
    static Ano.Mpt[] apply(Ano.Mpt[] m) {
        if (m == null || m.length == 0 || isOn(m)) return m;
        Ano.Mpt[] out = m;
        if (FrameTools.ticks(m[0]) > 1) {
            FrameOps.Split sp = FrameOps.splitAt(m, 1);
            if (sp == null || sp.mpts == m) return m;
            out = sp.mpts;
        }
        out = out.clone();
        Ano.Mpt first = out[0].copy();
        int rx = out.length > 1 ? zx(out[1]) : zx(first), ry = out.length > 1 ? zy(out[1]) : zy(first);
        setZoom(first, rx * scalePercent() / 100, ry * scalePercent() / 100);
        out[0] = first;
        return out;
    }

    /** Desliga: o frame 0 volta a escala do frame seguinte (a divisao em 2 frames fica). */
    static Ano.Mpt[] remove(Ano.Mpt[] m) {
        if (!isOn(m)) return m;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt first = out[0].copy();
        setZoom(first, zx(out[1]), zy(out[1]));
        out[0] = first;
        return out;
    }
}
