package com.zue.attackeditor;

import java.io.IOException;

/**
 * Leitor do CNV (secao 0 do .pac): tabela de 9 bytes por imagem.
 * [0]=PNG de origem, [1..2]=x, [3..4]=y, [5..6]=largura, [7..8]=altura (short big-endian, logicos).
 * No jogo a entrada e data[img * 9]; aqui o array ja e indexado por imagem.
 */
public final class Cnv {
    public static final int ENTRY_SIZE = 9;

    public static final class Entry {
        public final int index;
        public final int source;
        public final int x;
        public final int y;
        public final int width;
        public final int height;

        Entry(int index, int source, int x, int y, int width, int height) {
            this.index = index;
            this.source = source;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
    }

    private Entry[] entries;
    private final boolean characterCnv;
    private final int scale;

    private Cnv(byte[] data, boolean characterCnv) throws IOException {
        if (data == null || data.length < ENTRY_SIZE) throw new IOException("CNV vazio ou pequeno demais.");
        this.characterCnv = characterCnv;
        // folderScale do jogo: 2 para acttype 3/4 (personagens), 1 para o resto.
        this.scale = characterCnv ? 2 : 1;
        this.entries = new Entry[data.length / ENTRY_SIZE];
        for (int i = 0; i < entries.length; i++) {
            int p = i * ENTRY_SIZE;
            entries[i] = new Entry(i, data[p] & 0xFF,
                    shortBE(data, p + 1), shortBE(data, p + 3),
                    shortBE(data, p + 5), shortBE(data, p + 7));
        }
    }

    public static Cnv read(byte[] data, boolean characterCnv) throws IOException {
        return new Cnv(data, characterCnv);
    }

    /** Entrada da imagem {@code image} do DAC; null se for -1 (nada a desenhar) ou fora da tabela. */
    public Entry byImage(int image) {
        if (image < 0 || image >= entries.length) return null;
        return entries[image];
    }

    /** Troca a entrada {@code image} (cresce a tabela com entradas vazias se preciso). */
    public void set(int image, int source, int x, int y, int w, int h) {
        ensureSize(image + 1);
        entries[image] = new Entry(image, source, x, y, w, h);
    }

    /** Entrada vazia (largura/altura 0): a imagem continua existindo como indice, sem desenho. */
    public void clear(int image) { set(image, 0, 0, 0, 0, 0); }

    /** Reduz a tabela para {@code n} entradas (descarta as do fim). */
    public void truncate(int n) {
        n = Math.max(1, n);
        if (n >= entries.length) return;
        entries = java.util.Arrays.copyOf(entries, n);
    }

    public void ensureSize(int n) {
        if (n <= entries.length) return;
        Entry[] n2 = new Entry[n];
        System.arraycopy(entries, 0, n2, 0, entries.length);
        for (int i = entries.length; i < n; i++) n2[i] = new Entry(i, 0, 0, 0, 0, 0);
        entries = n2;
    }

    /** Bytes do .cnv (9 por imagem, shorts big-endian). */
    public byte[] encode() {
        byte[] out = new byte[entries.length * ENTRY_SIZE];
        for (int i = 0; i < entries.length; i++) {
            byte[] e = encode(entries[i].source, entries[i].x, entries[i].y, entries[i].width, entries[i].height);
            System.arraycopy(e, 0, out, i * ENTRY_SIZE, ENTRY_SIZE);
        }
        return out;
    }

    /**
     * Texto do .cnv.txt que o jogo transforma em .cnv (mesmo formato do extrator): personagens em pixels fisicos (x2), os demais iguais ao CNV.
     */
    public String toTxt() {
        StringBuilder sb = new StringBuilder("CNV_TXT_ {\n");
        int k = characterCnv ? 2 : 1;
        for (int i = 0; i < entries.length; i++) {
            Entry e = entries[i];
            sb.append("   $SPR_").append(i).append(":{$src:").append(e.source).append(", $x:").append(e.x * k).append(", $y:").append(e.y * k)
                    .append(", $w:").append(e.width * k).append(", $h:").append(e.height * k).append("},\n");
        }
        return sb.append("}\n").toString();
    }

    private static final java.util.regex.Pattern TXT = java.util.regex.Pattern.compile(
            "\\$src:(-?\\d+),\\s*\\$x:(-?\\d+),\\s*\\$y:(-?\\d+),\\s*\\$w:(-?\\d+),\\s*\\$h:(-?\\d+)");

    /** Le o .cnv.txt (como o CnvBuilder do jogo: personagem divide por 2). Devolve null se nao achou nenhuma entrada. */
    public static Cnv fromTxt(String text, boolean characterCnv) throws IOException {
        java.util.regex.Matcher m = TXT.matcher(text);
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        while (m.find()) {
            int src = Integer.parseInt(m.group(1)), x = Integer.parseInt(m.group(2)), y = Integer.parseInt(m.group(3));
            int w = Integer.parseInt(m.group(4)), h = Integer.parseInt(m.group(5));
            if (characterCnv) { x >>= 1; y >>= 1; w >>= 1; h >>= 1; }
            byte[] e = encode(src, x, y, w, h);
            out.write(e, 0, e.length);
        }
        return out.size() < ENTRY_SIZE ? null : new Cnv(out.toByteArray(), characterCnv);
    }

    public static byte[] encode(int source, int x, int y, int w, int h) {
        return new byte[]{(byte) source, (byte) (x >> 8), (byte) x, (byte) (y >> 8), (byte) y, (byte) (w >> 8), (byte) w, (byte) (h >> 8), (byte) h};
    }

    public int size() { return entries.length; }
    public int scale() { return scale; }
    public boolean isCharacterCnv() { return characterCnv; }

    private static int shortBE(byte[] b, int p) {
        return (short) (((b[p] & 255) << 8) | (b[p + 1] & 255));
    }
}
