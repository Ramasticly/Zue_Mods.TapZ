package com.zue.attackeditor;

/**
 * Por que um recorte do CNV nao funciona (Java puro, testado sem Android). {@link #check} devolve null se o recorte esta certo;
 * {@code fatal} = nao da para desenhar; senao e so aviso (passa da borda da folha e o app desenha o que existe).
 */
final class CropProblem {
    final String text;
    final boolean fatal;

    private CropProblem(String text, boolean fatal) { this.text = text; this.fatal = fatal; }

    /**
     * @param e          entrada do CNV (coordenadas logicas)
     * @param scale      escala do pac (2 em personagem)
     * @param sheetName  nome do arquivo da folha de indice {@code e.source}, ou null se essa folha nao existe
     * @param sheetCount quantas folhas PNG a pasta tem
     * @param sheetW     largura do PNG (0 = ilegivel)
     * @param sheetH     altura do PNG (0 = ilegivel)
     */
    static CropProblem check(Cnv.Entry e, int scale, String sheetName, int sheetCount, int sheetW, int sheetH) {
        if (e == null) return new CropProblem("sem entrada no CNV", true);
        if (e.width <= 0 || e.height <= 0) return new CropProblem("recorte vazio (largura ou altura 0)", true);
        if (e.x < 0 || e.y < 0) return new CropProblem("coordenada negativa (x " + e.x + ", y " + e.y + ")", true);
        if (sheetName == null) {
            return new CropProblem("folha $src:" + e.source + " nao existe (a pasta tem " + sheetCount + " folha(s) PNG"
                    + (sheetCount > 0 ? ", indices 0 a " + (sheetCount - 1) : "") + "); o $src e o indice na lista dos PNG, nao o numero do arquivo", true);
        }
        if (sheetW <= 0 || sheetH <= 0) return new CropProblem("PNG ilegivel: " + sheetName, true);
        int s = Math.max(1, scale);
        long l = (long) e.x * s, t = (long) e.y * s, r = l + (long) e.width * s, b = t + (long) e.height * s;
        String where = "folha " + sheetName + " (" + sheetW + "x" + sheetH + "): x " + l + ".." + r + ", y " + t + ".." + b + (s > 1 ? " (CNV x" + s + ")" : "");
        if (l >= sheetW || t >= sheetH) return new CropProblem("recorte fora da " + where, true);
        if (r > sheetW || b > sheetH) return new CropProblem("recorte passa da borda da " + where, false);
        return null;
    }

    static String reason(Cnv.Entry e, int scale, String sheetName, int sheetCount, int sheetW, int sheetH) {
        CropProblem p = check(e, scale, sheetName, sheetCount, sheetW, sheetH);
        return p == null ? null : p.text;
    }
}
