package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Barra de progresso da previa CHAR do editor de cutscenes: o trilho fica VERMELHO nos ticks em que a cutscene esta viva
 * ({@link AttackView#cutsceneTicks}); a parte ja tocada e mais forte. Toque/arrasto = ir ao tick.
 */
final class CutTimeBar extends View {
    interface OnSeek { void seek(int tick, boolean done); }

    static final int RED = 0xFFE5484D;

    private int length = 1, pos;
    private boolean[] active = new boolean[0];
    private OnSeek listener;
    private boolean dragging;
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    CutTimeBar(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    void setOnSeek(OnSeek l) { listener = l; }

    /** {@code len} ticks da previa; {@code act[t]} = cena viva no tick t (pode ser mais curto que len). */
    void setRange(int len, boolean[] act) {
        length = Math.max(1, len);
        active = act == null ? new boolean[0] : act;
        invalidate();
    }

    /** Tick atual (ignorado enquanto o dedo arrasta). */
    void setPos(int tick) {
        if (dragging) return;
        pos = Math.max(0, Math.min(length - 1, tick));
        invalidate();
    }

    boolean isDragging() { return dragging; }

    private float pad() { return 10 * d; }

    private float xOf(int t) {
        float w = getWidth() - 2 * pad();
        return pad() + (length <= 1 ? 0 : w * t / (float) (length - 1));
    }

    private int tickAt(float x) {
        float w = getWidth() - 2 * pad();
        if (w <= 0 || length <= 1) return 0;
        int t = Math.round((x - pad()) / w * (length - 1));
        return Math.max(0, Math.min(length - 1, t));
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), Math.round(34 * d));
    }

    @Override protected void onDraw(Canvas c) {
        float cy = getHeight() / 2f, h = 3 * d;
        float x0 = xOf(0), x1 = xOf(length - 1), xp = xOf(pos);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF3A3F4A);                                    // trilho
        c.drawRect(x0, cy - h, x1, cy + h, p);
        p.setColor(LayoutManager.ACCENT);                          // ja tocado
        c.drawRect(x0, cy - h, xp, cy + h, p);
        int n = Math.min(active.length, length);
        float step = length <= 1 ? 0 : (x1 - x0) / (length - 1);
        for (int t = 0; t < n; t++) {                              // cena viva: vermelho (mais fraco no que falta tocar)
            if (!active[t]) continue;
            int e = t;
            while (e + 1 < n && active[e + 1]) e++;
            float a = xOf(t) - step / 2f, b = xOf(e) + step / 2f;
            a = Math.max(x0, a);
            b = Math.min(x1, Math.max(b, a + 2 * d));
            p.setColor(0x88E5484D);
            c.drawRect(a, cy - h - d, b, cy + h + d, p);
            float pb = Math.min(b, xp);
            if (pb > a) { p.setColor(RED); c.drawRect(a, cy - h - d, pb, cy + h + d, p); }
            t = e;
        }
        p.setColor(0xFFFFFFFF);                                    // polegar
        c.drawCircle(xp, cy, 8 * d, p);
        boolean on = pos < active.length && active[pos];
        p.setColor(on ? RED : LayoutManager.ACCENT);
        c.drawCircle(xp, cy, 5 * d, p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                move(e.getX(), false);
                return true;
            case MotionEvent.ACTION_MOVE:
                move(e.getX(), false);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                move(e.getX(), true);
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    private void move(float x, boolean done) {
        int t = tickAt(x);
        boolean changed = t != pos;
        pos = t;
        invalidate();
        if (listener != null && (changed || done)) listener.seek(t, done);
    }
}
