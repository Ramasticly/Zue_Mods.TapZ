package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/** Ajudas puras do editor de cutscenes (HDAT 13): quais ANOs usam um evento, rotulos dos campos. */
final class CutsceneEdit {
    private CutsceneEdit() { }

    /** Indices (na ordem dada) das ANOs com algum hit flag 20 que usa o evento {@code ev} (o 3o valor da hitbox, {@code width}). */
    static List<Integer> users(Ano[] anos, int ev) {
        List<Integer> out = new ArrayList<Integer>();
        if (anos == null) return out;
        for (Ano a : anos) {
            if (a == null || !a.present) continue;
            boolean used = false;
            for (Ano.Mpt m : a.mpts) {
                if ((m.flags & 0x10) == 0) continue;
                for (Ano.Hit h : m.hits) if (h.flag == 20 && h.width == ev) used = true;
            }
            if (used) out.add(Integer.valueOf(a.index));
        }
        return out;
    }

    /** Todas as ANOs de um DAC (para {@link #users}). */
    static Ano[] all(Dac d) {
        Ano[] r = new Ano[d == null ? 0 : d.size()];
        for (int i = 0; i < r.length; i++) r[i] = d.getAno(i);
        return r;
    }
}
