package com.zue.attackeditor;

/**
 * Quais campos do editor de cutscenes o jogo ignora ou fixa, dependendo do modo do evento (Java puro). Deduzido da task md 996 ({@code BattleSim.runCut}):
 * sem animacao (ANIM_ID = 0) nada e desenhado; CAM_MODE diferente de 0 prende a cena ao canto (0, 0) da tela; FLAG 3 move a camera ate o dono e a cena termina
 * quando ela chega. Cada metodo recebe a linha do evento ({@link CharData#eventRow}, {@link CharData#EV_COLS} campos) e o numero do evento.
 */
final class CutsceneFields {
    private CutsceneFields() { }

    private static int f(int[] row, int off) { return row == null || off / 2 >= row.length ? 0 : row[off / 2]; }

    /** Null = o campo vale neste modo; senao o texto do porque nao muda (aparece esmaecido embaixo do campo). {@code off} = CharData.EV_*. */
    static String fixed(int[] row, int ev, int off) {
        boolean anim = f(row, CharData.EV_ANIM) != 0;
        int flag = f(row, CharData.EV_FLAG);
        switch (off) {
            case CharData.EV_ALVO:
            case CharData.EV_ANIM_FLIP:
            case CharData.EV_Z:
                return anim ? null : "sem efeito neste modo/evento: sem animação (ANIM_ID = 0), nada é desenhado";
            case CharData.EV_CAM:
                return anim || flag == 3 ? null : "sem efeito neste modo/evento: sem animação e FLAG diferente de 3";
            case CharData.EV_DURACAO:
                return flag == 3 ? "sem efeito neste modo/evento: com FLAG 3 a cena termina quando a câmera chega ao alvo" : null;
            default:
                return null;
        }
    }

    /** Posicao da cena (o X/Y do hit flag 20 na timeline): modo em texto, o que pode mudar e, no que e fixo, o porque. */
    static final class Pos {
        String mode;
        String camera;                      // frase extra quando a FLAG 3 move a camera (null se nao)
        boolean xEdit, yEdit;
        int xShown, yShown;                 // valor mostrado quando fixo (o do hit continua guardado como esta)
        String xNote, yNote;                // null quando editavel
    }

    /** {@code hx}, {@code hy}: X/Y atuais do hit (mostrados quando o campo e editavel ou "nao usado"). */
    static Pos position(int[] row, int ev, int hx, int hy) {
        boolean anim = f(row, CharData.EV_ANIM) != 0;
        int cam = f(row, CharData.EV_CAM), flag = f(row, CharData.EV_FLAG), stun = f(row, CharData.EV_STUN);
        Pos p = new Pos();
        p.xShown = hx;
        p.yShown = hy;
        boolean worldAnim = anim && cam == 0;
        boolean screenAnim = anim && cam != 0;
        boolean camX = flag == 3 && stun == 0;                 // FLAG 3: o X do hit e o alvo da camera (com TRAVAR_VIT o X vira o estado do alvo, ~0 px)
        if (worldAnim) p.mode = "Segue o mundo: a cena fica no golpe + X/Y do hit (X espelhado pelo lado do dono)";
        else if (screenAnim) p.mode = (ev == 8 || ev == 9)
                ? "Segue a tela: só no 1º tick vai para o canto (0, 0) da tela; depois anda pela velocidade da própria animação"
                : "Segue a tela: presa ao canto (0, 0) da tela, sem rolar com a câmera";
        else p.mode = flag == 3 ? "Sem animação: só a câmera usa a posição (FLAG 3)" : "Sem animação: a posição não é usada";
        if (flag == 3) p.camera = stun == 0 ? "Segue a câmera: o X é o ponto para onde a câmera vai (10 px por tick)" : "Segue a câmera: com TRAVAR_VIT o X vira o estado do alvo (≈ 0 px)";
        p.xEdit = worldAnim || camX;
        p.yEdit = worldAnim;
        if (!p.xEdit) {
            p.xShown = 0;
            p.xNote = screenAnim ? "fixo em 0 para este modo/evento (cena presa à tela: o X do hit é ignorado)"
                    : flag == 3 ? "fixo em 0 para este modo/evento (TRAVAR_VIT: o X vira o estado do alvo)"
                    : "fixo em 0 para este modo/evento (sem animação: não usado)";
        }
        if (!p.yEdit) {
            p.yShown = 0;
            p.yNote = screenAnim ? "fixo em 0 para este modo/evento (cena presa à tela: o Y do hit é ignorado)"
                    : "fixo em 0 para este modo/evento (sem animação: não usado)";
        }
        return p;
    }

    // ---- camadas, camera, duracao e FLAG com nomes pela funcao (textos do editor) ----

    /** Z_LAYER de Fundo, Meio e Frente, nessa ordem (pelo _SetObj do jogo: normal 17 / 200 / 400; eventos 8 e 9: 10 / 19-21 / 400). */
    static int[] layerOrder(int ev) { return ev == 8 || ev == 9 ? new int[] {0, 1, 2} : new int[] {1, 0, 2}; }

    static final String[] LAYER_NAMES = {"Fundo", "Meio", "Frente"};

    /** Posicao (0 Fundo, 1 Meio, 2 Frente) do Z_LAYER guardado; valores fora de 0..1 valem como 400 (Frente), como no jogo. */
    static int layerIndexOf(int ev, int z) {
        int[] o = layerOrder(ev);
        int zz = z == 0 || z == 1 ? z : 2;
        for (int i = 0; i < 3; i++) if (o[i] == zz) return i;
        return 2;
    }

    static String layerHelp(int ev, int idx) {
        if (idx == 0) return ev == 8 || ev == 9 ? "atrás das sombras e dos lutadores" : "atrás dos lutadores (junto das sombras)";
        if (idx == 1) return ev == 8 || ev == 9 ? "atrás dos lutadores, acima das sombras" : "na frente dos lutadores";
        return "na frente de tudo";
    }

    /** Valores de CAM_MODE na ordem da lista: segue o mundo (0), canto da tela (2) e canto da tela + tela cheia (1). */
    static final int[] CAM_VALUES = {0, 2, 1};

    static String camName(int cam) {
        return cam == 0 ? "Segue o mundo (no golpe)" : cam == 1 ? "Canto da tela + tela cheia" : "Canto da tela";
    }

    static String camHelp(int cam, int ev) {
        if (cam == 0) return "a cena fica no golpe, no X/Y do hit, e anda com a câmera do cenário";
        String base = cam == 1 ? "presa ao canto (0, 0) da tela, sem rolar; o fundo e a HUD deixam de ser desenhados enquanto a cena existe (tela cheia)"
                : "presa ao canto (0, 0) da tela, sem rolar com a câmera";
        return ev == 8 || ev == 9 ? base + ". Eventos 8 e 9: só no 1º tick vai ao canto; depois anda pela velocidade da própria animação" : base;
    }

    /** "Até o ANO acabar" (duracao 0 ou negativa) ou "Dura N MPT(s)": frames (MPTs) do ANO, nao ticks. */
    static String durationLabel(int dur) { return dur <= 0 ? "Até o ANO acabar" : (dur == 1 ? "Dura 1 MPT" : "Dura " + dur + " MPTs"); }

    static final String DURATION_NOTE = "A cena também acaba quando o ANO muda. Parado no último frame o ANO não acabou, então ela continua.";

    static final class FlagOpt {
        final int value; final String name;
        FlagOpt(int v, String n) { value = v; name = n; }
    }

    static final class FlagGroup {
        final String title; final boolean boxes; final FlagOpt[] opts;
        FlagGroup(String t, boolean b, FlagOpt... o) { title = t; boxes = b; opts = o; }
    }

    /** As opcoes da FLAG (0 a 15) em grupos pela funcao. O grupo "sem limite de tela" e de caixas: 7 oponente, 8 dono, 9 os dois. */
    static FlagGroup[] flagGroups() {
        return new FlagGroup[] {
            new FlagGroup("Luta", false, new FlagOpt(0, "Nenhum efeito extra"), new FlagOpt(1, "Adiar o fim da luta (KO) enquanto a cena existe"), new FlagOpt(2, "Esconder o oponente se ele estiver derrotado")),
            new FlagGroup("Câmera", false, new FlagOpt(3, "Câmera vai até o dono do golpe"), new FlagOpt(4, "Travar a rolagem da câmera"), new FlagOpt(5, "Câmera centraliza o oponente")),
            new FlagGroup("Paredes", false, new FlagOpt(6, "Forçar parede (o oponente bate em qualquer ponto da tela)")),
            new FlagGroup("Sem limite de tela", true, new FlagOpt(7, "Oponente"), new FlagOpt(8, "Dono do golpe")),
            new FlagGroup("Prender o oponente na borda da tela", false, new FlagOpt(10, "Esquerda"), new FlagOpt(11, "Direita"), new FlagOpt(12, "Acima")),
            new FlagGroup("Teleportar o dono para a borda (só no 1º tick)", false, new FlagOpt(13, "Esquerda"), new FlagOpt(14, "Direita"), new FlagOpt(15, "Acima")),
        };
    }

    /** Bits das caixas "sem limite de tela": 1 = oponente (FLAG 7), 2 = dono (FLAG 8), 3 = os dois (FLAG 9); 0 se a FLAG nao e desse grupo. */
    static int boxesOf(int flag) { return flag == 7 ? 1 : flag == 8 ? 2 : flag == 9 ? 3 : 0; }

    static int flagOfBoxes(boolean opponent, boolean owner) { return opponent && owner ? 9 : opponent ? 7 : owner ? 8 : 0; }

    /** Efeito extra da FLAG escolhida, em uma frase (o que o jogo faz). */
    static String flagHelp(int flag) { return flag == 0 ? "nada" : CutsceneInfo.mapaName(flag); }

    /** Avisos das combinacoes que o jogo anula ou estranha (mudam conforme os valores mudam). {@code fromProjectile}: o hit esta num ANO de projetil. */
    static java.util.List<String> warnings(int[] row, int ev, boolean fromProjectile) {
        java.util.List<String> w = new java.util.ArrayList<String>();
        boolean anim = f(row, CharData.EV_ANIM) != 0;
        int cam = f(row, CharData.EV_CAM), flag = f(row, CharData.EV_FLAG), stun = f(row, CharData.EV_STUN), alvo = f(row, CharData.EV_ALVO);
        if (!anim && flag == 0 && stun == 0) w.add("Sem animação, sem FLAG e sem travar o oponente: este evento não faz nada.");
        if (flag == 3) {
            w.add("FLAG 3: a cena termina quando a câmera chega ao dono; a DURAÇÃO não vale.");
            if (cam == 0) w.add("FLAG 3 com a câmera \"Segue o mundo\": a câmera salta direto e a cena nunca aparece. Use um canto da tela.");
            if (stun != 0) w.add("FLAG 3 com TRAVAR OPONENTE: o jogo nunca devolve o estado do oponente, ele fica parado.");
        }
        if (stun != 0 && fromProjectile) w.add("Num ANO de projétil o travar pausa o próprio projétil, que nunca avança até a cena acabar: ela fica presa.");
        if (anim && cam == 1) w.add("Tela cheia: o fundo e a HUD deixam de ser desenhados enquanto a cena existe.");
        if (anim && cam != 0 && (ev == 8 || ev == 9)) w.add("Eventos 8 e 9 no canto da tela: só no 1º tick vão ao canto, depois andam pela velocidade da animação.");
        if (anim && alvo >= 2) w.add("ALVO bobj: precisa da pasta bobj em assets, senão nada é desenhado.");
        if (flag >= 13 && flag <= 15) w.add("Esta FLAG move o dono só no 1º tick da cena.");
        if (flag >= 10 && flag <= 12) w.add("Esta FLAG prende o oponente na borda a cada tick enquanto a cena existe.");
        if (flag == 4 || flag == 7 || flag == 8 || flag == 9) w.add("Esta FLAG trava a rolagem da câmera enquanto a cena existe.");
        return w;
    }

    /** Linha vazia (todos os campos zero)? */
    static boolean isEmpty(int[] row) {
        if (row == null) return true;
        for (int v : row) if (v != 0) return false;
        return true;
    }
}
