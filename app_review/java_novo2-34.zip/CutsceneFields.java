package com.zue.attackeditor;

/**
 * Quais campos do editor de cutscenes o jogo ignora ou fixa, dependendo do modo do evento (Java puro). Deduzido da task md 996 ({@code BattleSim.runCut}):
 * sem animacao (ANIM_ID = 0) nada e desenhado; CAM_MODE diferente de 0 prende a cena ao canto (0, 0) da tela; FLAG 3 move a camera ate o dono e a cena termina
 * quando ela chega. Cada metodo recebe a linha do evento ({@link CharData#eventRow}, {@link CharData#EV_COLS} campos) e o numero do evento.
 */
final class CutsceneFields {
    private CutsceneFields() { }

    private static int f(int[] row, int off) { return row == null || off / 2 >= row.length ? 0 : row[off / 2]; }

    /** Null = o campo vale neste modo; senao o texto do porque nao muda (aparece esmaecido embaixo do campo). {@code off} = CharData.EV_*. */
    static String fixed(int[] row, int ev, int off) {
        boolean anim = f(row, CharData.EV_ANIM) != 0;
        int flag = f(row, CharData.EV_FLAG);
        switch (off) {
            case CharData.EV_ALVO:
            case CharData.EV_ANIM_FLIP:
            case CharData.EV_Z:
                return anim ? null : "sem efeito neste modo/evento: sem animação (ANIM_ID = 0), nada é desenhado";
            case CharData.EV_CAM:
                return anim || flag == 3 ? null : "sem efeito neste modo/evento: sem animação e FLAG diferente de 3";
            case CharData.EV_DURACAO:
                return flag == 3 ? "sem efeito neste modo/evento: com FLAG 3 a cena termina quando a câmera chega ao alvo" : null;
            default:
                return null;
        }
    }

    /** Posicao da cena (o X/Y do hit flag 20 na timeline): modo em texto, o que pode mudar e, no que e fixo, o porque. */
    static final class Pos {
        String mode;
        String camera;                      // frase extra quando a FLAG 3 move a camera (null se nao)
        boolean xEdit, yEdit;
        int xShown, yShown;                 // valor mostrado quando fixo (o do hit continua guardado como esta)
        String xNote, yNote;                // null quando editavel
    }

    /** {@code hx}, {@code hy}: X/Y atuais do hit (mostrados quando o campo e editavel ou "nao usado"). */
    static Pos position(int[] row, int ev, int hx, int hy) {
        boolean anim = f(row, CharData.EV_ANIM) != 0;
        int cam = f(row, CharData.EV_CAM), flag = f(row, CharData.EV_FLAG), stun = f(row, CharData.EV_STUN);
        Pos p = new Pos();
        p.xShown = hx;
        p.yShown = hy;
        boolean worldAnim = anim && cam == 0;
        boolean screenAnim = anim && cam != 0;
        boolean camX = flag == 3 && stun == 0;                 // FLAG 3: o X do hit e o alvo da camera (com TRAVAR_VIT o X vira o estado do alvo, ~0 px)
        if (worldAnim) p.mode = "Segue o mundo: a cena fica no golpe + X/Y do hit (X espelhado pelo lado do dono)";
        else if (screenAnim) p.mode = (ev == 8 || ev == 9)
                ? "Segue a tela: só no 1º tick vai para o canto (0, 0) da tela; depois anda pela velocidade da própria animação"
                : "Segue a tela: presa ao canto (0, 0) da tela, sem rolar com a câmera";
        else p.mode = flag == 3 ? "Sem animação: só a câmera usa a posição (FLAG 3)" : "Sem animação: a posição não é usada";
        if (flag == 3) p.camera = stun == 0 ? "Segue a câmera: o X é o ponto para onde a câmera vai (10 px por tick)" : "Segue a câmera: com TRAVAR_VIT o X vira o estado do alvo (≈ 0 px)";
        p.xEdit = worldAnim || camX;
        p.yEdit = worldAnim;
        if (!p.xEdit) {
            p.xShown = 0;
            p.xNote = screenAnim ? "fixo em 0 para este modo/evento (cena presa à tela: o X do hit é ignorado)"
                    : flag == 3 ? "fixo em 0 para este modo/evento (TRAVAR_VIT: o X vira o estado do alvo)"
                    : "fixo em 0 para este modo/evento (sem animação: não usado)";
        }
        if (!p.yEdit) {
            p.yShown = 0;
            p.yNote = screenAnim ? "fixo em 0 para este modo/evento (cena presa à tela: o Y do hit é ignorado)"
                    : "fixo em 0 para este modo/evento (sem animação: não usado)";
        }
        return p;
    }

    /** Linha vazia (todos os campos zero)? */
    static boolean isEmpty(int[] row) {
        if (row == null) return true;
        for (int v : row) if (v != 0) return false;
        return true;
    }
}
