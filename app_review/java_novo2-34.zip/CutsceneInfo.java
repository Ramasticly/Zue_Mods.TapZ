package com.zue.attackeditor;

/**
 * Texto do painel da flag 20 (cutscene): a linha do HDAT 13 decodificada como o md 996 do jogo a le, mais os avisos
 * de campos que o jogo ignora. Java puro (testado sem Android).
 */
final class CutsceneInfo {
    private CutsceneInfo() { }

    /** Campos s16 da linha: +0 alvo, +2 sync, +4 z, +6 anim, +8 anim espelhada, +10 cam, +12 stun, +14 mapa. */
    static String describe(CharData ch, int ev, int hx, int hy) {
        if (ch == null) return "Sem dados do personagem: nao da para ler o HDAT 13.";
        if (!ch.hasEvent(ev)) {
            return "O evento " + ev + " nao existe no HDAT 13 deste personagem (tem " + ch.eventRows() + " linha"
                    + (ch.eventRows() == 1 ? "" : "s") + "): o jogo encerra a task na hora e nada acontece.";
        }
        int alvo = ch.eventField(ev, 0), sync = ch.eventField(ev, 2), z = ch.eventField(ev, 4);
        int animN = ch.eventField(ev, 6), animF = ch.eventField(ev, 8), cam = ch.eventField(ev, 10);
        int stun = ch.eventField(ev, 12), mapa = ch.eventField(ev, 14);
        StringBuilder b = new StringBuilder();
        b.append("Evento ").append(ev).append(" (HDAT 13): ");
        if (animN == 0) {
            b.append("sem animacao (ANIM_ID = 0)");
        } else {
            b.append(packName(alvo)).append(" · ANO ").append(animN);
            if (animF != animN) b.append(" (espelhada: ").append(animF).append(')');
            b.append(" · camada ").append(zValue(ev, z));
            b.append(" · ").append(cam == 0 ? "presa ao mundo" : cam == 1 ? "presa a tela (tela cheia)" : "presa a tela");
        }
        b.append('\n').append(sync > 0 ? "Dura " + sync + " frame(s) do ANO do golpe (frames, nao ticks)" : "Dura enquanto o ANO do golpe nao mudar")
                .append(" ou ate o ANO acabar.");
        if (stun != 0) b.append("\nCongela o outro lutador (md 925) ate acabar: projeteis, auras e agarrao tambem pausam.");
        if (mapa != 0) b.append("\nFLAG ").append(mapa).append(": ").append(mapaName(mapa));
        if (alvo >= 2) b.append("\nALVO ").append(alvo).append(" usa o pack bobjNN do cenario (precisa da pasta bobj* em assets).");
        if (animN != 0 && cam != 0 && (hx != 0 || hy != 0) && mapa != 3)
            b.append("\nAviso: com cam diferente de 0 o jogo posiciona a cena em (0, 0) da tela e ignora o x/y deste hit.");
        if (animN != 0 && (ev == 8 || ev == 9) && cam != 0)
            b.append("\nEventos 8 e 9 com cam diferente de 0: so no 1o tick vai para (0, 0) da tela; depois anda pela velocidade do proprio ANO.");
        if (mapa == 3 && cam == 0) b.append("\nCom cam 0 a camera salta direto para o alvo e a cena nunca aparece.");
        if (mapa == 3 && stun != 0) b.append("\nAviso: o stun do FLAG 3 nunca e desfeito pelo jogo (o alvo fica parado) e o x do hit vira o estado do alvo (~0 px).");
        return b.toString();
    }

    private static String packName(int alvo) {
        return alvo == 0 ? "effect.pac" : alvo == 1 ? "pack do personagem" : "bobj";
    }

    /** _SetObj da cutscene: 0 => 200 (10 nos eventos 8/9); 1 => 17/19/21; resto => 400. */
    static int zValue(int ev, int z) {
        if (z == 0) return (ev == 8 || ev == 9) ? 10 : 200;
        if (z == 1) return ev == 8 ? 19 : (ev == 9 ? 21 : 17);
        return 400;
    }

    static String mapaName(int m) {
        switch (m) {
            case 1: return "adia o fim da luta (KO) enquanto a cena existe";
            case 2: return "esconde o alvo se ele estiver derrotado (para sempre)";
            case 3: return "a camera vai ate o dono do golpe (10 px por tick; cam 0 = salta)";
            case 4: return "trava a rolagem da camera para o dono";
            case 5: return "a camera centraliza o alvo (outro lutador)";
            case 6: return "forca parede: o alvo bate em qualquer ponto da tela";
            case 7: return "tira o limite de tela do alvo e trava a rolagem do dono";
            case 8: return "tira o limite de tela do dono e trava a rolagem do alvo";
            case 9: return "tira o limite de tela dos dois e trava a rolagem";
            case 10: return "prende o alvo, todo tick, a esquerda da tela";
            case 11: return "prende o alvo, todo tick, a direita da tela";
            case 12: return "prende o alvo, todo tick, acima da tela";
            case 13: return "o dono vai para a esquerda da tela (so no 1o tick)";
            case 14: return "o dono vai para a direita da tela (so no 1o tick)";
            case 15: return "o dono vai para cima da tela (so no 1o tick)";
            default: return "valor sem efeito no jogo";
        }
    }
}
