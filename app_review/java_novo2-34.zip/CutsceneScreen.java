package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * Editor das cutscenes da flag 20 (HDAT 13 do personagem). Abre so pelo hit da cutscene na timeline (EDITAR CUTSCENE).
 * Topo: EVENTO (abre a grade de eventos) e, com o modo CHAR ligado, o ANO que usa o evento (radio). Prévia: com CHAR o golpe/ANO do personagem inteiro, com play
 * (qualquer alteracao pausa e atualiza); sem CHAR so a cutscene. Abaixo: ANIM (animacao normal e virada, PAC e grade de ANOs), X/Y do hit e DURACAO, TRAVAR
 * OPONENTE, CAMADA (Fundo/Meio/Frente), CAMERA e FLAG em grupos. O que o jogo ignora naquele modo fica esmaecido, com o motivo ({@link CutsceneFields}).
 * Mexe direto no CharData (o Saver grava o $ROTEIRO_CUTSCENE no *.bin.txt).
 */
final class CutsceneScreen {
    interface Use { void on(int event); }

    /** O hit da timeline que abriu o editor: sua posicao (X/Y), se esta num ANO de projetil e qual ANO e. */
    interface HitPos {
        int x();
        int y();
        void setX(int v);
        void setY(int v);
        boolean projectile();
    }

    /** Linha copiada (COPIAR/COLAR): vale entre eventos e entre personagens. */
    private static int[] clip;

    private final Activity a;
    private final AttackView view;
    private final CharAssets ch;
    private final CharData cd;
    private final Use use;
    private final HitPos pos;
    private final int hitEvent, hitAno;
    /** Abre um ANO do personagem na timeline (EDITAR ANO); pode ser null. */
    private final Navigator nav;
    private int previewHgt;
    private final float d;
    private Dialog dlg;
    private int sel;
    private final List<CharData.EventsSnap> undo = new ArrayList<CharData.EventsSnap>();
    private LinearLayout topBox, camBox, detail;
    private FrameLayout previewHolder;
    private TextView undoBtn, charBtn;
    private boolean charOn = true;
    private int selAno = -1;
    private AttackView pv;
    private TextView playBtn, cutLabel;
    private CutTimeBar timeBar;

    /** {@code start} = evento do hit; {@code hitAno} = ANO do hit (-1 se nao se sabe); {@code use} (pode ser null) = USAR NESTE HIT; {@code pos} = X/Y do hit. */
    static void show(Activity a, AttackView view, int start, int hitAno, Use use, HitPos pos, Navigator nav) {
        view.pause();
        AttackData ad = view.attackData();
        if (ad == null || ad.attacker == null || ad.attacker.data == null) {
            I18nUi.toast(a, "Carregue um personagem para editar as cutscenes", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        new CutsceneScreen(a, view, ad.attacker, start, hitAno, use, pos, nav).open();
    }

    private CutsceneScreen(Activity a, AttackView view, CharAssets ch, int start, int hitAno, Use use, HitPos pos, Navigator nav) {
        this.nav = nav;
        this.a = a; this.view = view; this.ch = ch; this.cd = ch.data; this.use = use; this.pos = pos;
        this.d = a.getResources().getDisplayMetrics().density;
        this.hitEvent = start;
        this.hitAno = hitAno;
        this.sel = Math.max(0, Math.min(Math.max(0, cd.eventRows() - 1), start));
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Texto montado na hora (numeros): nao passa pelo catalogo, as partes fixas ja vem traduzidas. */
    private TextView raw(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a).noTranslate();
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 12, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private TextView chip(String s, boolean on, View.OnClickListener l) {
        TextView t = tv(s, 12, on ? 0xFFFFFFFF : LayoutManager.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    interface Toggle { void on(boolean v); }

    /** Linha com o nome (e uma frase) e uma chave a direita: liga e DESLIGA (tocar na linha tambem alterna). */
    private View switchRow(String label, String help, boolean on, final Toggle t) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(4), dp(4), dp(4));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? 0x334C8DFF : LayoutManager.PANEL_HI);
        g.setStroke(dp(1), on ? LayoutManager.ACCENT : 0x00000000);
        g.setCornerRadius(dp(8));
        r.setBackground(g);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(tv(label, 12, on ? 0xFFFFFFFF : LayoutManager.TEXT, true));
        if (help != null) col.addView(tv(help, 10, LayoutManager.DIM, false));
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        final android.widget.Switch sw = new android.widget.Switch(a);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean v) { t.on(v); }
        });
        r.addView(sw, new LinearLayout.LayoutParams(-2, -2));
        r.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sw.toggle(); } });
        return r;
    }

    private LinearLayout.LayoutParams lp(float w, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w > 0 ? 0 : -2, -2, w);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    // ---- janela ----

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("CUTSCENE (HDAT 13)", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        undoBtn = button("↶", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { undoLast(); } });
        h.addView(undoBtn, new LinearLayout.LayoutParams(dp(48), dp(40)));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        topBox = new LinearLayout(a);                                // EVENTO + USAR NESTE HIT, e o radio de ANOs (modo CHAR)
        topBox.setOrientation(LinearLayout.VERTICAL);
        topBox.setPadding(0, dp(4), 0, dp(4));
        root.addView(topBox, new LinearLayout.LayoutParams(-1, -2));
        int w = a.getResources().getDisplayMetrics().widthPixels - dp(20);
        int hgt = Math.min(w, Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.36f));
        previewHolder = new FrameLayout(a);                          // previa com o botao CHAR no canto inferior direito
        previewHolder.setBackgroundColor(0xFF0D0F13);
        previewHgt = hgt;
        root.addView(previewHolder, new LinearLayout.LayoutParams(-1, hgt));
        camBox = new LinearLayout(a);                                // controles de play (modo CHAR) e o botao ANIM
        camBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(camBox, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new SafeScrollView(a);
        detail = new LinearLayout(a);
        detail.setOrientation(LinearLayout.VERTICAL);
        detail.setPadding(0, dp(2), 0, dp(8));
        sv.addView(detail);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar2 = new LinearLayout(a);
        bar2.addView(button("FECHAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }), lp(1, 0, 0, 0, 0));
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.topMargin = dp(6);
        root.addView(bar2, b2);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface di) {
                if (pv != null) pv.pause();
                view.refreshAfterExternalEdit();                      // a previa do CHAR mexeu no contexto estatico da simulacao: a principal se refaz
            }
        });
        pickAno();
        rebuild();
        dlg.show();
    }

    private boolean changed;

    private void push() {
        undo.add(cd.snapshotEvents());
        changed = true;
    }

    private void undoLast() {
        if (undo.isEmpty()) return;
        cd.restoreEvents(undo.remove(undo.size() - 1));
        sel = Math.min(sel, Math.max(0, cd.eventRows() - 1));
        pickAno();
        rebuild();
        if (grid != null && grid.isShowing()) fillGrid();
    }

    private void set(int off, int v) {
        push();
        cd.setEventField(sel, off, v);
        edited();
    }

    private boolean detailPending;

    /** Alteracao feita: pausa a previa e a atualiza; refaz os campos DEPOIS do callback atual (o Stepper confirma dentro do onFocusChange do EditText). */
    private void edited() {
        if (pv != null) pv.pause();
        refreshPreview();
        if (detailPending) return;
        detailPending = true;
        detail.post(new Runnable() { public void run() { detailPending = false; rebuildTop(); rebuildCam(); rebuildDetail(); } });
    }

    private void rebuild() {
        undoBtn.setAlpha(undo.isEmpty() ? 0.4f : 1f);
        rebuildTop();
        showPreview();
        rebuildCam();
        rebuildDetail();
    }

    // ---- ANOs que usam o evento ----

    private List<Integer> users() { return AnoMoves.usersOf(ch, sel); }

    /** Escolhe o ANO a renderizar: o que ja estava, senao o ANO do hit (se usa o evento), senao o primeiro que usa. */
    private void pickAno() {
        List<Integer> u = users();
        if (selAno >= 0 && u.contains(Integer.valueOf(selAno))) return;
        if (hitAno >= 0 && u.contains(Integer.valueOf(hitAno))) { selAno = hitAno; return; }
        selAno = u.isEmpty() ? -1 : u.get(0).intValue();
    }

    // ---- topo ----

    private void rebuildTop() {
        SafeScrollView.releaseFocus(topBox);
        topBox.removeAllViews();
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView evBtn = button(I18n.tr("EVENTO") + ": " + sel + "  ▾", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { openGrid(); } });
        r.addView(evBtn, lp(0, 0, 0, 6, 0));
        if (use != null) r.addView(button(sel == hitEvent ? "USAR NESTE HIT ✓" : "USAR NESTE HIT", sel == hitEvent ? LayoutManager.DIM : 0xFF7CE08A, new View.OnClickListener() { public void onClick(View v) {
            if (cd.hasEvent(sel)) { use.on(sel); dlg.dismiss(); }
        } }), lp(0, 0, 0, 0, 0));
        topBox.addView(r);
        if (charOn) {
            List<Integer> u = users();
            HorizontalScrollView hs = new HorizontalScrollView(a);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout ar = new LinearLayout(a);
            ar.setGravity(Gravity.CENTER_VERTICAL);
            ar.addView(tv("ANO:", 12, LayoutManager.TEXT, true), lp(0, 2, 0, 6, 0));
            if (u.isEmpty()) ar.addView(tv("nenhuma ANO usa este evento", 11, LayoutManager.DIM, false));
            for (final Integer an : u) {
                ar.addView(chip(String.valueOf(an), an.intValue() == selAno, new View.OnClickListener() { public void onClick(View v) {
                    selAno = an.intValue();
                    if (pv != null) pv.pause();
                    rebuildTop();
                    showPreview();
                    rebuildCam();
                } }), lp(0, 2, 2, 2, 2));
            }
            hs.addView(ar);
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
            hp.topMargin = dp(4);
            topBox.addView(hs, hp);
        }
    }

    // ---- previa ----

    private Dac packDac(int alvo) { return view.packDac(alvo == 0 ? 0 : alvo == 1 ? 2 : 3); }
    private SpriteCache packSprites(int alvo) { return view.packSprites(alvo == 0 ? 0 : alvo == 1 ? 2 : 3); }

    private View previewCell(String title, int alvo, int ano, int side, boolean firstFrameOnly) {
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        Dac dac = packDac(alvo);
        Ano an = dac == null ? null : dac.getAno(ano);
        if (ano > 0 && an != null && an.present && an.mpts.length > 0) {
            AnimPreview pvw = new AnimPreview(a);
            if (firstFrameOnly) pvw.setFirstFrameOnly(true);
            pvw.set(dac, packSprites(alvo), ano);
            cell.addView(pvw, new LinearLayout.LayoutParams(side, side));
        } else {
            TextView e = tv(ano == 0 ? "sem animação" : dac == null ? "pacote não carregado" : "ANO vazia", 11, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            cell.addView(e, new LinearLayout.LayoutParams(side, side));
        }
        if (title != null) cell.addView(tv(title, 11, LayoutManager.DIM, false));
        return cell;
    }

    /** Refaz a area da previa: CHAR ligado (e com ANO) = o golpe/ANO inteiro com play; senao so a cutscene. */
    private void showPreview() {
        previewHolder.removeAllViews();
        pv = null;
        playBtn = null;
        timeBar = null;
        cutLabel = null;
        boolean full = charOn && selAno >= 0 && view.attackData() != null;
        if (full) {
            pv = new AttackView(a);
            pv.setSoundPlayer(view.soundPlayer());
            pv.setSoundOn(false);
            pv.setCenterMode(1);                                   // TELA: enquadra o retangulo da camera do jogo (onde a cutscene de canto aparece)
            pv.setListener(new AttackView.Listener() {
                @Override public void onFrame(int frame, int length, boolean playing) { onPvFrame(frame, length, playing); }
            });
            pv.setData(AnoMoves.dataFor(view.attackData(), selAno));
            pv.pause();
            previewHolder.addView(pv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            if (cd.hasEvent(sel)) {
                col.addView(screenCell("virado para a direita (ANIM_ID)", CharData.EV_ANIM, false));
                col.addView(screenCell("virado para a esquerda (ANIM_FLIP)", CharData.EV_ANIM_FLIP, true));
            } else {
                col.addView(tv("Sem eventos: toque em EVENTO e depois em NOVO.", 12, LayoutManager.DIM, false));
            }
            if (charOn && selAno < 0) col.addView(tv("Nenhuma ANO usa este evento: só a cutscene.", 11, LayoutManager.DIM, false), 0);
            previewHolder.addView(col, new FrameLayout.LayoutParams(-1, -2));
        }
        ViewGroup.LayoutParams hp = previewHolder.getLayoutParams();
        if (hp != null) { hp.height = full ? previewHgt : ViewGroup.LayoutParams.WRAP_CONTENT; previewHolder.setLayoutParams(hp); }
        charBtn = chip("CHAR", charOn, new View.OnClickListener() { public void onClick(View v) {
            charOn = !charOn;
            if (pv != null) pv.pause();
            pickAno();
            rebuildTop();
            showPreview();
            rebuildCam();
        } });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        cp.setMargins(0, 0, dp(6), dp(6));
        previewHolder.addView(charBtn, cp);
    }

    /**
     * Uma animacao do evento como o jogo a mostraria NESTE aparelho (CHAR desligado): o quadro e a tela do celular; no canto da tela a ANO nasce no 0, 0;
     * no mundo nasce no ponto do hit (lutador no meio, no chao). Embaixo, EDITAR ANO (so o PAC do personagem pode ser editado no app).
     */
    private View screenCell(String title, int off, boolean flipped) {
        int alvo = cd.eventField(sel, CharData.EV_ALVO), ano = cd.eventField(sel, off), cam = cd.eventField(sel, CharData.EV_CAM);
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(0, dp(2), 0, dp(4));
        LinearLayout head = new LinearLayout(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(tv(title, 11, LayoutManager.DIM, false), new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(raw("ANO " + ano, 11, LayoutManager.ACCENT, true));
        cell.addView(head);
        GameScreen gs = GameScreenDraw.forContext(a);
        int w = a.getResources().getDisplayMetrics().widthPixels - dp(20);
        int h = Math.min(Math.round(w * 320f / gs.scalW), dp(150));
        int ww = Math.min(w, Math.round(h * gs.scalW / 320f));
        Dac dac = packDac(alvo);
        Ano an = dac == null ? null : dac.getAno(ano);
        if (ano > 0 && an != null && an.present && an.mpts.length > 0) {
            AnimPreview pvw = new AnimPreview(a);
            int hx = pos == null ? 0 : pos.x(), hy = pos == null ? 0 : pos.y();
            pvw.set(dac, packSprites(alvo), ano);
            pvw.setGameScreen(gs, CutsceneFields.zKey(sel, cd.eventField(sel, CharData.EV_Z)), cam != 0, 240 + (flipped ? -hx : hx), 240 + hy);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(ww, h);
            pl.gravity = Gravity.CENTER_HORIZONTAL;
            cell.addView(pvw, pl);
            if (cam == 0) cell.addView(tv("No mundo: posição relativa ao hit (cruz), lutador no meio da tela. Veja a posição certa no modo CHAR.", 10, LayoutManager.DIM, false));
        } else {
            TextView e = tv(ano == 0 ? "sem animação" : dac == null ? "pacote não carregado" : "ANO vazia", 11, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            cell.addView(e, new LinearLayout.LayoutParams(-1, dp(48)));
        }
        final int fano = ano;
        String why = ano <= 0 ? I18n.tr("sem animação") : alvo == 0 ? I18n.tr("o app ainda não edita o effect.pac") : alvo != 1 ? I18n.tr("o app ainda não edita o bobj") : nav == null ? I18n.tr("indisponível aqui") : null;
        TextView ed = button(I18n.tr("EDITAR ANO") + " " + ano, why == null ? LayoutManager.ACCENT : LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) {
            dlg.dismiss();                                          // a volta e pelo VOLTAR de sempre da timeline
            nav.openAno(fano, false);
        } });
        if (why != null) { ed.setEnabled(false); ed.setAlpha(0.45f); }
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(3);
        cell.addView(ed, ep);
        if (why != null) cell.addView(raw(why, 10, LayoutManager.DIM, false));
        return cell;
    }

    /** Depois de uma alteracao: a previa se atualiza (CHAR: a simulacao relê o HDAT 13 e o ANO, pausada; senao refaz as animacoes). */
    private void refreshPreview() {
        if (pv != null) {
            pv.pause();
            pv.refreshAfterExternalEdit();
        } else {
            showPreview();
        }
    }

    private void onPvFrame(int frame, int length, boolean playing) {
        if (playBtn != null) playBtn.setText(playing ? "⏸" : "▶");
        if (timeBar != null && pv != null) {
            boolean[] act = pv.cutsceneTicks(sel);
            timeBar.setRange(length, act);
            timeBar.setPos(frame);
            if (cutLabel != null) cutLabel.setText(cutText(act, frame));
        }
    }

    /** "Cena ativa nos ticks a–b" (ou em N trechos) e se ela esta viva no tick atual; o aviso quando ela nao aparece. */
    private static String cutText(boolean[] act, int frame) {
        int first = -1, last = -1, runs = 0;
        for (int i = 0; i < act.length; i++) {
            if (!act[i]) continue;
            if (i == 0 || !act[i - 1]) runs++;
            if (first < 0) first = i;
            last = i;
        }
        if (first < 0) return I18n.tr("A cena não aparece neste golpe/ANO");
        String s = runs == 1 ? I18n.tr("Cena ativa nos ticks") + " " + first + "–" + last
                : I18n.tr("Cena ativa em") + " " + runs + " " + I18n.tr("trechos") + " (" + first + "–" + last + ")";
        boolean on = frame >= 0 && frame < act.length && act[frame];
        return s + "  ·  " + I18n.tr("tick") + " " + frame + (on ? " ● " + I18n.tr("cena viva") : "");
    }

    // ---- ANIM + controles de play ----

    private void rebuildCam() {
        SafeScrollView.releaseFocus(camBox);
        camBox.removeAllViews();
        if (pv != null) {
            LinearLayout c = new LinearLayout(a);
            c.setGravity(Gravity.CENTER_VERTICAL);
            TextView toCut = button("⏮ CENA", CutTimeBar.RED, new View.OnClickListener() { public void onClick(View v) {
                if (pv == null) return;
                pv.pause();
                int t = pv.firstCutsceneTick(sel);
                if (t < 0) { I18nUi.toast(a, "A cena não aparece neste golpe/ANO", android.widget.Toast.LENGTH_SHORT).show(); return; }
                pv.seekTo(t);
            } });
            toCut.setPadding(dp(6), dp(10), dp(6), dp(10));
            c.addView(toCut, new LinearLayout.LayoutParams(-2, dp(40)));
            playBtn = button(pv.isPlaying() ? "⏸" : "▶", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { pv.togglePlay(); } });
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(52), dp(40));
            pp.leftMargin = dp(4);
            c.addView(playBtn, pp);
            timeBar = new CutTimeBar(a);
            timeBar.setOnSeek(new CutTimeBar.OnSeek() { public void seek(int tick, boolean done) {
                if (pv == null) return;
                pv.pause();
                pv.seekTo(tick);
                if (done) pv.finishSeek();
            } });
            boolean[] act = pv.cutsceneTicks(sel);
            timeBar.setRange(pv.getLength(), act);
            timeBar.setPos(pv.getFrame());
            c.addView(timeBar, new LinearLayout.LayoutParams(0, -2, 1f));
            camBox.addView(c);
            cutLabel = raw(cutText(act, pv.getFrame()), 10, LayoutManager.DIM, false);
            camBox.addView(cutLabel);
        }
        int animN = cd.eventField(sel, CharData.EV_ANIM), animF = cd.eventField(sel, CharData.EV_ANIM_FLIP);
        TextView anim = button(I18n.tr("ANIM") + "   " + packName(cd.eventField(sel, CharData.EV_ALVO)) + " · ANIM_ID " + animN + " · ANIM_FLIP_ID " + animF + "   ▸", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) openAnim(); } });
        anim.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(4);
        camBox.addView(anim, ap);
    }

    private static String packName(int alvo) { return alvo == 0 ? "effect.pac" : alvo == 1 ? I18n.tr("char do player") : "bobj"; }

    // ---- tela ANIM: ANIM_ID e ANIM_FLIP_ID lado a lado; slots com ESCOLHER e EDITAR (zoom/posicao); tudo em rascunho ate o SALVAR ----

    private static final int COL_ID = 0xFF4C8DFF, COL_FLIP = 0xFFFF9F43;
    private static final int[] SLOT_OFF = {CharData.EV_ANIM, CharData.EV_ANIM_FLIP};

    private Dialog animDlg;
    /** Rascunho da tela ANIM: PAC (ALVO), os dois ANOs e os ANOs do personagem com zoom/posicao editados (indice -> copia editada). */
    private int dAlvo;
    private final int[] dAnim = new int[2];
    private final java.util.LinkedHashMap<Integer, Ano> dAnos = new java.util.LinkedHashMap<Integer, Ano>();
    private int editSlot = -1;
    private boolean onlyFrame;
    private final boolean[] unite = {true, true};
    private final AnimPreview[] animPv = new AnimPreview[2];
    private final TextView[] frameLbl = new TextView[2];
    private final FrameLayout[] pvBox = new FrameLayout[2];
    private LinearLayout slotsBox;
    private TextView saveBtn, pauseBtn;
    private Stepper sZ, sZx, sZy, sX, sY;
    private View rowZ, rowZx, rowZy;
    /** Valores mostrados nos campos {zoom X, zoom Y, X, Y} e o frame deles: mudar um campo soma (novo − mostrado). */
    private final int[] shown = new int[4];
    private int shownPat = -1;

    private static String slotName(int k) { return k == 0 ? "ANIM_ID" : "ANIM_FLIP_ID"; }

    private void openAnim() {
        dAlvo = cd.eventField(sel, CharData.EV_ALVO);
        dAnim[0] = cd.eventField(sel, CharData.EV_ANIM);
        dAnim[1] = cd.eventField(sel, CharData.EV_ANIM_FLIP);
        dAnos.clear();
        editSlot = -1;
        onlyFrame = false;
        if (pv != null) pv.pause();
        animDlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        animDlg.setCancelable(false);
        animDlg.setOnKeyListener(new android.content.DialogInterface.OnKeyListener() {
            public boolean onKey(android.content.DialogInterface di, int code, android.view.KeyEvent e) {
                if (code != android.view.KeyEvent.KEYCODE_BACK) return false;
                if (e.getAction() == android.view.KeyEvent.ACTION_UP) askDiscard();
                return true;
            }
        });
        buildAnim();
        animDlg.show();
    }

    private Ano origAno(int idx) { Dac d = packDac(1); return d == null ? null : d.getAno(idx); }

    /** ANO do slot como esta no rascunho (editado ou o original do pacote). */
    private Ano slotAno(int k) {
        Ano e = dAlvo == 1 ? dAnos.get(Integer.valueOf(dAnim[k])) : null;
        if (e != null) return e;
        Dac d = packDac(dAlvo);
        return d == null ? null : d.getAno(dAnim[k]);
    }

    private boolean anoEdited(int idx) {
        Ano e = dAnos.get(Integer.valueOf(idx));
        return e != null && dAlvo == 1 && AnoXform.differs(origAno(idx), e);
    }

    private boolean eventDraftChanged() {
        return dAlvo != cd.eventField(sel, CharData.EV_ALVO) || dAnim[0] != cd.eventField(sel, CharData.EV_ANIM) || dAnim[1] != cd.eventField(sel, CharData.EV_ANIM_FLIP);
    }

    private boolean draftChanged() {
        if (eventDraftChanged()) return true;
        for (Integer i : dAnos.keySet()) if (anoEdited(i.intValue())) return true;
        return false;
    }

    /** DAC das previas: o pacote do ALVO do rascunho, com os ANOs editados por cima (so o pacote do personagem; o DAC real nao muda). */
    private Dac draftDac() {
        Dac base = packDac(dAlvo);
        if (base == null || dAlvo != 1) return base;
        Dac d = base;
        for (java.util.Map.Entry<Integer, Ano> e : dAnos.entrySet()) d = d.copyWith(e.getKey().intValue(), e.getValue());
        return d;
    }

    private void askDiscard() {
        if (!draftChanged()) { animDlg.dismiss(); return; }
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Descartar as mudanças?")
                .setMessage("A animação escolhida e o zoom/posição editados nesta tela ainda não foram salvos.")
                .setPositiveButton("DESCARTAR", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface x, int w) { animDlg.dismiss(); }
                }).setNegativeButton("CONTINUAR EDITANDO", null).show();
    }

    private void buildAnim() {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("ANIMAÇÃO DA CUTSCENE", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { askDiscard(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        // as duas animacoes lado a lado, na tela do jogo deste aparelho
        GameScreen gs = GameScreenDraw.forContext(a);
        int w = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(8)) / 2;
        int hh = Math.round(w * 320f / gs.scalW);
        LinearLayout pair = new LinearLayout(a);
        for (int k = 0; k < 2; k++) pair.addView(animCell(k, w, hh, gs, true), lp(1, k == 0 ? 0 : 4, 0, k == 0 ? 4 : 0, 0));
        root.addView(pair, new LinearLayout.LayoutParams(-1, -2));
        root.addView(raw(I18n.tr("PAC das duas animações:") + " " + packName(dAlvo), 11, LayoutManager.DIM, false));
        ScrollView sv = new SafeScrollView(a);
        slotsBox = new LinearLayout(a);
        slotsBox.setOrientation(LinearLayout.VERTICAL);
        sv.addView(slotsBox);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(a);
        bar.addView(button("CANCELAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { askDiscard(); } }), lp(1, 0, 0, 3, 0));
        saveBtn = button("SALVAR", 0xFF7CE08A, new View.OnClickListener() { public void onClick(View v) { confirmSave(); } });
        bar.addView(saveBtn, lp(1, 3, 0, 0, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(6);
        root.addView(bar, bp);
        animDlg.setContentView(root);
        fillSlots();
        updateSave();
    }

    private void updateSave() { if (saveBtn != null) saveBtn.setAlpha(draftChanged() ? 1f : 0.45f); }

    /** Um quadro da tela do jogo com a animacao do slot (rascunho), a faixa colorida com o nome do campo e o frame atual. */
    private View animCell(final int k, int w, int hh, GameScreen gs, boolean main) {
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        TextView band = raw(slotName(k), 13, 0xFFFFFFFF, true);
        band.setGravity(Gravity.CENTER);
        band.setPadding(0, dp(3), 0, dp(3));
        band.setBackgroundColor(k == 0 ? COL_ID : COL_FLIP);
        cell.addView(band, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = tv(k == 0 ? "virado para a frente" : "virado para trás", 10, LayoutManager.DIM, false);
        sub.setGravity(Gravity.CENTER);
        cell.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout box = new FrameLayout(a);
        box.setPadding(dp(2), dp(2), dp(2), dp(2));
        Dac dac = draftDac();
        int ano = dAnim[k];
        Ano an = dac == null ? null : dac.getAno(ano);
        AnimPreview p = null;
        if (ano > 0 && an != null && an.present && an.mpts.length > 0) {
            p = new AnimPreview(a);
            int cam = cd.eventField(sel, CharData.EV_CAM), hx = pos == null ? 0 : pos.x(), hy = pos == null ? 0 : pos.y();
            p.set(dac, packSprites(dAlvo), ano);
            p.setGameScreen(gs, CutsceneFields.zKey(sel, cd.eventField(sel, CharData.EV_Z)), cam != 0, 240 + (k == 1 ? -hx : hx), 240 + hy);
            box.addView(p, new FrameLayout.LayoutParams(w, hh));
        } else {
            TextView e = tv(ano == 0 ? "sem animação" : dac == null ? "pacote não carregado" : "ANO vazia", 11, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            box.addView(e, new FrameLayout.LayoutParams(w, hh));
        }
        cell.addView(box);
        TextView fl = raw("ANO " + ano, 10, LayoutManager.TEXT, false);
        cell.addView(fl);
        if (main) {
            animPv[k] = p;
            pvBox[k] = box;
            frameLbl[k] = fl;
            if (p != null) p.setOnPat(new AnimPreview.OnPat() { public void pat(int pat) { onAnimPat(k, pat); } });
            markBox(k);
        } else {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF0D0F13);
            g.setStroke(dp(2), k == 0 ? COL_ID : COL_FLIP);
            box.setBackground(g);
        }
        return cell;
    }

    private void markBox(int k) {
        if (pvBox[k] == null) return;
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF0D0F13);
        boolean on = k == editSlot;
        g.setStroke(dp(on ? 3 : 1), on ? (k == 0 ? COL_ID : COL_FLIP) : 0xFF2C313C);
        pvBox[k].setBackground(g);
    }

    /** O frame da previa mudou: atualiza o rotulo e, no slot em edicao, os campos (valores do frame que esta na tela). */
    private void onAnimPat(int k, int pat) {
        if (frameLbl[k] != null && animPv[k] != null)
            frameLbl[k].setText("ANO " + dAnim[k] + " · " + I18n.tr("frame") + " " + (pat + 1) + "/" + animPv[k].frameCount() + (anoEdited(dAnim[k]) ? " ✎" : ""));
        if (k == editSlot) fillEditor(pat);
    }

    private void fillSlots() {
        SafeScrollView.releaseFocus(slotsBox);
        slotsBox.removeAllViews();
        sZ = sZx = sZy = sX = sY = null;
        pauseBtn = null;
        for (int k = 0; k < 2; k++) {
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.topMargin = dp(8);
            slotsBox.addView(slotCard(k), cp);
        }
        int[] r = cd.eventRow(sel).clone();
        r[CharData.EV_ALVO / 2] = dAlvo;
        r[CharData.EV_ANIM / 2] = dAnim[0];
        r[CharData.EV_ANIM_FLIP / 2] = dAnim[1];
        String fx = CutsceneFields.fixed(r, sel, CharData.EV_ANIM_FLIP);
        if (fx != null) slotsBox.addView(tv(fx, 11, 0xFFFFB454, false));
        for (int k = 0; k < 2; k++) markBox(k);
        if (editSlot >= 0) fillEditor(Math.max(0, animPv[editSlot] == null ? 0 : animPv[editSlot].currentPat()));
    }

    /** Por que o slot nao pode ser editado aqui (null = pode). */
    private String editWhy(int k) {
        int ano = dAnim[k];
        if (ano <= 0) return I18n.tr("sem animação");
        if (dAlvo == 0) return I18n.tr("o app ainda não edita o effect.pac");
        if (dAlvo != 1) return I18n.tr("o app ainda não edita o bobj");
        Ano an = slotAno(k);
        if (an == null || !an.present || an.mpts.length == 0) return I18n.tr("ANO vazia");
        return null;
    }

    private View slotCard(final int k) {
        int col = k == 0 ? COL_ID : COL_FLIP;
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL);
        g.setStroke(dp(k == editSlot ? 2 : 1), k == editSlot ? col : 0xFF2C313C);
        g.setCornerRadius(dp(10));
        card.setBackground(g);
        LinearLayout head = new LinearLayout(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(raw(slotName(k), 14, col, true));
        head.addView(raw(":  " + packName(dAlvo) + " · ANO " + dAnim[k] + (anoEdited(dAnim[k]) ? "  ✎" : ""), 13, LayoutManager.TEXT, true));
        card.addView(head);
        card.addView(tv(k == 0 ? "Animação da cena quando o personagem está virado para a frente (para a direita)."
                : "Animação da cena quando o personagem está virado para trás (para a esquerda).", 11, LayoutManager.DIM, false));
        LinearLayout btns = new LinearLayout(a);
        btns.addView(button("ESCOLHER", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { pickPac(k); } }), lp(1, 0, 6, 3, 0));
        final String why = editWhy(k);
        TextView ed = button(k == editSlot ? I18n.tr("FECHAR EDIÇÃO") : I18n.tr("EDITAR ANO") + " " + dAnim[k], why == null ? col : LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) {
            if (editSlot == k) { editSlot = -1; fillSlots(); return; }
            openEditor(k);
        } });
        if (why != null) { ed.setEnabled(false); ed.setAlpha(0.45f); }
        btns.addView(ed, lp(1, 3, 6, 0, 0));
        card.addView(btns);
        if (why != null) card.addView(raw(why, 10, LayoutManager.DIM, false));
        if (k == editSlot) card.addView(editorView(k));
        return card;
    }

    /** EDITAR: o slot cresce com o editor de zoom/posicao; comeca parado no 1o frame do ANO. */
    private void openEditor(int k) {
        editSlot = k;
        onlyFrame = false;
        unite[k] = AnoXform.uniteOf(slotAno(k), 0);
        for (int j = 0; j < 2; j++) if (j != k && animPv[j] != null) animPv[j].setPaused(false);
        if (animPv[k] != null) { animPv[k].setPaused(true); animPv[k].goToPat(0); }
        fillSlots();
        fillEditor(0);
    }

    private Stepper stepper(int min, int max, Stepper.OnValue l) { return new Stepper(a).step(1).range(min, max).keyboard(l).live(true); }

    private LinearLayout field(String label, Stepper st) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(tv(label, 12, LayoutManager.DIM, false), new LinearLayout.LayoutParams(dp(92), -2));
        r.addView(st.view());
        return r;
    }

    private View editorView(final int k) {
        LinearLayout e = new LinearLayout(a);
        e.setOrientation(LinearLayout.VERTICAL);
        e.setPadding(0, dp(8), 0, 0);
        // andar nos frames da previa deste slot
        LinearLayout nav = new LinearLayout(a);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.addView(button("◀ FRAME", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { stepFrame(k, -1); } }), lp(1, 0, 0, 3, 0));
        final AnimPreview p = animPv[k];
        pauseBtn = button(p != null && !p.isPaused() ? "⏸" : "▶", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            if (p == null) return;
            p.setPaused(!p.isPaused());
            if (!p.isPaused() && onlyFrame) { onlyFrame = false; fillSlots(); return; }   // tocando, "apenas nesse Frame" nao faz sentido
            pauseBtn.setText(p.isPaused() ? "▶" : "⏸");
        } });
        nav.addView(pauseBtn, lp(0, 3, 0, 3, 0));
        nav.addView(button("FRAME ▶", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { stepFrame(k, 1); } }), lp(1, 3, 0, 0, 0));
        e.addView(nav);
        final CheckBox only = new I18nCheckBox(a);
        only.setText("Aplicar apenas nesse Frame");
        only.setTextColor(LayoutManager.TEXT);
        only.setChecked(onlyFrame);
        only.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                onlyFrame = on;
                if (on && p != null) { p.setPaused(true); if (pauseBtn != null) pauseBtn.setText("▶"); }
            }
        });
        e.addView(only);
        // zoom
        LinearLayout zh = new LinearLayout(a);
        zh.setGravity(Gravity.CENTER_VERTICAL);
        zh.addView(tv("Zoom", 12, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        final CheckBox join = new I18nCheckBox(a);
        join.setText("Unir zoom");
        join.setTextColor(LayoutManager.TEXT);
        join.setChecked(unite[k]);
        zh.addView(join);
        e.addView(zh);
        sZ = stepper(AnoXform.ZOOM_MIN, AnoXform.ZOOM_MAX, new Stepper.OnValue() { public void on(double v) { int d = (int) v - shown[0]; applyDelta(d, d, 0, 0); } });
        sZx = stepper(AnoXform.ZOOM_MIN, AnoXform.ZOOM_MAX, new Stepper.OnValue() { public void on(double v) { applyDelta((int) v - shown[0], 0, 0, 0); } });
        sZy = stepper(AnoXform.ZOOM_MIN, AnoXform.ZOOM_MAX, new Stepper.OnValue() { public void on(double v) { applyDelta(0, (int) v - shown[1], 0, 0); } });
        rowZ = field("Zoom %", sZ);
        rowZx = field("Zoom X %", sZx);
        rowZy = field("Zoom Y %", sZy);
        e.addView(rowZ);
        e.addView(rowZx);
        e.addView(rowZy);
        join.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { unite[k] = on; showZoomRows(); }
        });
        showZoomRows();
        // posicao
        e.addView(tv("Posição", 12, LayoutManager.TEXT, true), lp(0, 0, 6, 0, 0));
        sX = stepper(-4000, 4000, new Stepper.OnValue() { public void on(double v) { applyDelta(0, 0, (int) v - shown[2], 0); } });
        sY = stepper(-4000, 4000, new Stepper.OnValue() { public void on(double v) { applyDelta(0, 0, 0, (int) v - shown[3]); } });
        e.addView(field("X", sX));
        e.addView(field("Y", sY));
        e.addView(tv("Os campos mostram o frame que está na prévia e acompanham os frames. Mudar um valor soma a mesma diferença em todos os frames do ANO (os links não mudam); com «Aplicar apenas nesse Frame» só o frame da prévia muda.", 10, LayoutManager.DIM, false));
        return e;
    }

    private void showZoomRows() {
        if (rowZ == null || editSlot < 0) return;
        boolean u = unite[editSlot];
        rowZ.setVisibility(u ? View.VISIBLE : View.GONE);
        rowZx.setVisibility(u ? View.GONE : View.VISIBLE);
        rowZy.setVisibility(u ? View.GONE : View.VISIBLE);
    }

    private void stepFrame(int k, int dir) {
        AnimPreview p = animPv[k];
        if (p == null) return;
        int n = p.frameCount();
        if (n <= 0) return;
        p.setPaused(true);
        if (pauseBtn != null) pauseBtn.setText("▶");
        int cur = Math.max(0, p.currentPat());
        p.goToPat(((cur + dir) % n + n) % n);
    }

    /** Campos = valores do frame {@code pat} do ANO (rascunho) do slot em edicao. */
    private void fillEditor(int pat) {
        if (editSlot < 0 || sZ == null) return;
        int[] v = AnoXform.valuesAt(slotAno(editSlot), Math.max(0, pat));
        if (v == null) return;
        System.arraycopy(v, 0, shown, 0, 4);
        shownPat = Math.max(0, pat);
        sZ.value(v[0]);
        sZx.value(v[0]);
        sZy.value(v[1]);
        sX.value(v[2]);
        sY.value(v[3]);
    }

    /** Soma a diferenca no ANO do slot em edicao (em todos os frames, ou so no da previa) e atualiza as previas, sem mexer no DAC real. */
    private void applyDelta(int dzx, int dzy, int dx, int dy) {
        if (editSlot < 0 || (dzx == 0 && dzy == 0 && dx == 0 && dy == 0)) return;
        final int k = editSlot;
        Ano cur = slotAno(k);
        if (cur == null) return;
        AnimPreview p = animPv[k];
        if (p != null && !p.isPaused()) { p.setPaused(true); if (pauseBtn != null) pauseBtn.setText("▶"); }
        Ano n = AnoXform.addDelta(cur, onlyFrame ? shownPat : -1, dzx, dzy, dx, dy);
        dAnos.put(Integer.valueOf(dAnim[k]), n);
        Dac dd = draftDac();
        for (int j = 0; j < 2; j++) if (animPv[j] != null && dAnim[j] == dAnim[k]) animPv[j].swapDac(dd);
        int[] v = AnoXform.valuesAt(n, shownPat);
        if (v != null) System.arraycopy(v, 0, shown, 0, 4);
        updateSave();
        slotsBox.post(new Runnable() { public void run() { fillEditor(shownPat); onAnimPat(k, shownPat); } });
    }

    /** ESCOLHER: primeiro o PAC (vira o ALVO, vale para as duas), depois a grade dos ANOs daquele PAC. So muda o rascunho. */
    private void pickPac(final int k) {
        final int curChoice = dAlvo == 0 || dAlvo == 1 ? dAlvo : 2;
        String[] names = {"effect.pac", I18n.tr("char do player"), packDac(2) == null ? "bobj (" + I18n.tr("pasta não encontrada em assets") + ")" : "bobj"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Escolher o PAC")
                .setSingleChoiceItems(names, curChoice, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface di, int which) {
                        di.dismiss();
                        if (packDac(which) == null) { I18nUi.toast(a, "Pacote não carregado (para o ALVO 2 é preciso a pasta bobj em assets)", android.widget.Toast.LENGTH_LONG).show(); return; }
                        if (which != curChoice) {
                            if (which != 1 && !dAnos.isEmpty()) { dAnos.clear(); I18nUi.toast(a, "Os ajustes de zoom/posição só valem no PAC do personagem: foram descartados", android.widget.Toast.LENGTH_LONG).show(); }
                            else if (dAnim[1 - k] != 0) I18nUi.toast(a, "A outra animação passa a ser lida do novo PAC", android.widget.Toast.LENGTH_SHORT).show();
                            dAlvo = which;
                            editSlot = -1;
                            buildAnim();
                        }
                        final int alvo = which;
                        AnoPicker.showAll(a, packDac(alvo), packSprites(alvo), dAnim[k], packName(alvo) + " · " + slotName(k), new AnoPicker.Listener() {
                            public void onPick(int ano) {
                                dAnim[k] = ano;
                                if (editSlot == k) editSlot = -1;
                                if (animDlg != null && animDlg.isShowing()) buildAnim();
                            }
                        });
                    }
                }).setNegativeButton("CANCELAR", null).show();
    }

    /** Texto de uma mudanca de zoom/posicao de um ANO (partes fixas traduzidas). */
    private static String changeText(AnoXform.Change c) {
        if (c.delta == null) return I18n.tr("zoom/posição diferentes por frame") + " · " + c.changed + "/" + c.total + " " + I18n.tr("frames");
        StringBuilder b = new StringBuilder();
        if (c.delta[2] != 0 || c.delta[3] != 0) b.append(I18n.tr("posição")).append(' ').append(AnoXform.sign(c.delta[2])).append(", ").append(AnoXform.sign(c.delta[3]));
        if (c.delta[0] != 0 || c.delta[1] != 0) {
            if (b.length() > 0) b.append(" · ");
            b.append(I18n.tr("zoom")).append(' ').append(AnoXform.sign(c.delta[0])).append("%, ").append(AnoXform.sign(c.delta[1])).append('%');
        }
        b.append(" · ").append(c.changed == c.total ? I18n.tr("em todos os frames") : c.changed + "/" + c.total + " " + I18n.tr("frames"));
        return b.toString();
    }

    /** SALVAR: mostra as duas animacoes juntas (para nao ajustar uma e esquecer a outra) e o resumo; CONFIRMAR aplica. */
    private void confirmSave() {
        if (!draftChanged()) { animDlg.dismiss(); return; }
        for (int k = 0; k < 2; k++) if (animPv[k] != null) animPv[k].setPaused(true);
        final Dialog c = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        root.addView(tv("CONFIRA AS DUAS ANIMAÇÕES", 17, LayoutManager.TEXT, true));
        root.addView(tv("A cena usa a ANIM_ID com o personagem virado para a frente e a ANIM_FLIP_ID virado para trás: confira as duas antes de salvar.", 11, LayoutManager.DIM, false));
        GameScreen gs = GameScreenDraw.forContext(a);
        int w = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(8)) / 2;
        int hh = Math.round(w * 320f / gs.scalW);
        LinearLayout pair = new LinearLayout(a);
        for (int k = 0; k < 2; k++) pair.addView(animCell(k, w, hh, gs, false), lp(1, k == 0 ? 0 : 4, 6, k == 0 ? 4 : 0, 0));
        root.addView(pair, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout info = new LinearLayout(a);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(0, dp(8), 0, 0);
        int alvo0 = cd.eventField(sel, CharData.EV_ALVO);
        for (int k = 0; k < 2; k++) {
            int before = cd.eventField(sel, SLOT_OFF[k]);
            String line = slotName(k) + ": " + packName(dAlvo) + " · ANO " + dAnim[k];
            if (before != dAnim[k] || alvo0 != dAlvo) line += "   (" + I18n.tr("antes:") + " " + packName(alvo0) + " · ANO " + before + ")";
            info.addView(raw(line, 12, k == 0 ? COL_ID : COL_FLIP, true));
        }
        java.util.List<Integer> edited = new java.util.ArrayList<Integer>();
        for (Integer i : dAnos.keySet()) {
            if (!anoEdited(i.intValue())) continue;
            edited.add(i);
            AnoXform.Change ch = AnoXform.change(origAno(i.intValue()), dAnos.get(i));
            info.addView(raw("ANO " + i + ": " + changeText(ch), 12, LayoutManager.TEXT, false));
        }
        if (dAnim[0] != dAnim[1] && dAnim[0] > 0 && dAnim[1] > 0) {
            boolean e0 = anoEdited(dAnim[0]), e1 = anoEdited(dAnim[1]);
            if (e0 != e1) info.addView(tv(e0 ? "⚠ Só a ANIM_ID foi editada: confira se a ANIM_FLIP_ID (virado para trás) precisa do mesmo ajuste."
                    : "⚠ Só a ANIM_FLIP_ID foi editada: confira se a ANIM_ID (virado para a frente) precisa do mesmo ajuste.", 12, 0xFFFFB454, true));
        }
        if (!edited.isEmpty()) info.addView(tv("Os ANOs editados mudam em todo lugar que os usa. O ↶ do app desfaz; o SALVAR do app grava no arquivo.", 10, LayoutManager.DIM, false));
        ScrollView sv = new SafeScrollView(a);
        sv.addView(info);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(a);
        bar.addView(button("VOLTAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { c.dismiss(); } }), lp(1, 0, 0, 3, 0));
        final java.util.List<Integer> fe = edited;
        bar.addView(button("CONFIRMAR", 0xFF7CE08A, new View.OnClickListener() { public void onClick(View v) { c.dismiss(); applyDraft(fe); } }), lp(1, 3, 0, 0, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(6);
        root.addView(bar, bp);
        c.setContentView(root);
        c.show();
    }

    /** CONFIRMAR: grava o evento (com o ↶ do editor) e troca os ANOs editados no DAC do personagem (com o ↶ do app), marcando-os para o SALVAR do app. */
    private void applyDraft(java.util.List<Integer> edited) {
        if (eventDraftChanged()) {
            push();
            cd.setEventField(sel, CharData.EV_ALVO, dAlvo);
            cd.setEventField(sel, CharData.EV_ANIM, dAnim[0]);
            cd.setEventField(sel, CharData.EV_ANIM_FLIP, dAnim[1]);
            undoBtn.setAlpha(1f);
        }
        if (!edited.isEmpty()) {
            java.util.List<Ano> list = new java.util.ArrayList<Ano>();
            for (Integer i : edited) list.add(dAnos.get(i));
            view.markPendingAnos(edited);
            view.replaceAnosAsync(list, new Runnable() { public void run() { edited(); } });
        } else {
            edited();
        }
        I18nUi.toast(a, "Aplicado. O ↶ desfaz; o SALVAR do app grava no arquivo.", android.widget.Toast.LENGTH_LONG).show();
        animDlg.dismiss();
    }

    // ---- campos ----

    private int[] row() { return cd.eventRow(sel); }

    private void label(String s) {
        TextView t = tv(s, 12, LayoutManager.TEXT, true);
        t.setPadding(0, dp(10), 0, dp(2));
        detail.addView(t);
    }

    private void note(String s, int color) { detail.addView(tv(s, 11, color, false)); }

    /** Desliga a view e tudo dentro dela: campo fixo nao responde ao toque. */
    private static void disable(View v) {
        v.setEnabled(false);
        v.setFocusable(false);
        if (v instanceof ViewGroup) { ViewGroup g = (ViewGroup) v; for (int i = 0; i < g.getChildCount(); i++) disable(g.getChildAt(i)); }
    }

    /** Esmaece e desliga o bloco quando o jogo ignora o campo neste modo. */
    private LinearLayout block(String title, boolean off) {
        LinearLayout g = new LinearLayout(a);
        g.setOrientation(LinearLayout.VERTICAL);
        if (title != null) {
            TextView t = tv(title, 12, LayoutManager.TEXT, true);
            t.setPadding(0, dp(10), 0, dp(2));
            g.addView(t);
        }
        return g;
    }

    private void finish(LinearLayout g, String fixedNote) {
        if (fixedNote != null) { disable(g); g.setAlpha(0.4f); }
        detail.addView(g);
        if (fixedNote != null) note(fixedNote, LayoutManager.DIM);
    }

    private LinearLayout choices(String[] names, int curIdx, final int off, int[] values) {
        LinearLayout r = new LinearLayout(a);
        for (int i = 0; i < names.length; i++) {
            final int val = values[i];
            r.addView(chip(names[i], i == curIdx, new View.OnClickListener() { public void onClick(View v) { set(off, val); } }), lp(1, 2, 2, 2, 2));
        }
        return r;
    }

    private void rebuildDetail() {
        SafeScrollView.releaseFocus(detail);
        detail.removeAllViews();
        if (!cd.hasEvent(sel)) return;
        int[] row = row();
        int ev = sel;
        // avisos (mudam conforme os valores)
        List<String> warns = CutsceneFields.warnings(row, ev, pos != null && pos.projectile());
        for (String w : warns) {
            TextView t = tv("⚠ " + w, 11, 0xFFFFB454, false);
            t.setPadding(0, 0, 0, dp(2));
            detail.addView(t);
        }
        // X / Y do hit (esquerda) e DURACAO (na frente)
        LinearLayout xy = new LinearLayout(a);
        xy.setOrientation(LinearLayout.HORIZONTAL);
        xy.setPadding(0, dp(6), 0, 0);
        LinearLayout left = new LinearLayout(a);
        left.setOrientation(LinearLayout.VERTICAL);
        if (pos != null) {
            CutsceneFields.Pos p = CutsceneFields.position(row, ev, pos.x(), pos.y());
            left.addView(tv(p.mode, 10, LayoutManager.ACCENT, false));
            if (p.camera != null) left.addView(tv(p.camera, 10, LayoutManager.ACCENT, false));
            left.addView(posRow("X", p.xEdit, p.xShown, p.xNote, true));
            left.addView(posRow("Y", p.yEdit, p.yShown, p.yNote, false));
        }
        xy.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        xy.addView(durationBlock(row), lp(1, 8, 0, 0, 0));
        detail.addView(xy);
        // TRAVAR OPONENTE (abaixo da duracao)
        LinearLayout stun = block("TRAVAR OPONENTE", false);
        stun.addView(switchRow("Travar o oponente", null, row[CharData.EV_STUN / 2] != 0, new Toggle() { public void on(boolean v) { set(CharData.EV_STUN, v ? 1 : 0); } }));
        finish(stun, null);
        note("Congela a animação do oponente (estado 925 do jogo) enquanto a cena existir e devolve o estado dele quando ela acaba. Atenção: o jogo pode trocar o estado dele no meio (por exemplo, ele pode continuar um pulo).", LayoutManager.DIM);
        // CAMADA
        int[] order = CutsceneFields.layerOrder(ev);
        int li = CutsceneFields.layerIndexOf(ev, row[CharData.EV_Z / 2]);
        LinearLayout lay = block("CAMADA", false);
        String[] ln = new String[3];
        for (int i = 0; i < 3; i++) ln[i] = I18n.tr(CutsceneFields.LAYER_NAMES[i]);
        lay.addView(choices(ln, li, CharData.EV_Z, order));
        lay.addView(tv(CutsceneFields.layerHelp(ev, li), 11, LayoutManager.DIM, false));
        finish(lay, CutsceneFields.fixed(row, ev, CharData.EV_Z));
        // MODO DE CAMERA
        int cam = row[CharData.EV_CAM / 2];
        final boolean corner = CutsceneFields.cornerOf(cam);
        LinearLayout cm = block("MODO DE CÂMERA", false);
        cm.addView(raw(I18n.tr(CutsceneFields.camName(cam == 0 ? 0 : cam == 1 ? 1 : 2)), 12, LayoutManager.ACCENT, true));
        cm.addView(switchRow("Canto da tela", "desligado: segue o mundo (fica no golpe)", corner, new Toggle() { public void on(boolean v) {
            set(CharData.EV_CAM, CutsceneFields.camOf(v, false));
        } }), lp(0, 0, 3, 0, 2));
        if (corner) {
            LinearLayout.LayoutParams fp = lp(0, 22, 2, 0, 2);
            cm.addView(switchRow("Tela cheia", "o jogo esconde o cenário enquanto a cena existe", CutsceneFields.fullOf(cam), new Toggle() { public void on(boolean v) {
                set(CharData.EV_CAM, CutsceneFields.camOf(true, v));
            } }), fp);
        }
        cm.addView(tv(CutsceneFields.camHelp(cam == 0 ? 0 : cam == 1 ? 1 : 2, ev), 11, LayoutManager.DIM, false));
        finish(cm, CutsceneFields.fixed(row, ev, CharData.EV_CAM));
        // FLAG em grupos
        flagBlock(row[CharData.EV_FLAG / 2]);
    }

    private View durationBlock(int[] row) {
        int dur = row[CharData.EV_DURACAO / 2];
        String fx = CutsceneFields.fixed(row, sel, CharData.EV_DURACAO);
        LinearLayout g = new LinearLayout(a);
        g.setOrientation(LinearLayout.VERTICAL);
        LinearLayout inner = new LinearLayout(a);
        inner.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv("DURAÇÃO", 12, LayoutManager.TEXT, true);
        inner.addView(t);
        LinearLayout ch2 = new LinearLayout(a);
        ch2.setOrientation(LinearLayout.VERTICAL);
        ch2.addView(chip("Até o ANO acabar", dur <= 0, new View.OnClickListener() { public void onClick(View v) { set(CharData.EV_DURACAO, 0); } }), lp(0, 0, 2, 0, 2));
        ch2.addView(chip("N MPTs", dur > 0, new View.OnClickListener() { public void onClick(View v) { if (cd.eventField(sel, CharData.EV_DURACAO) <= 0) set(CharData.EV_DURACAO, 1); } }), lp(0, 0, 2, 0, 2));
        inner.addView(ch2);
        if (dur > 0) inner.addView(new Stepper(a).range(1, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { set(CharData.EV_DURACAO, (int) v); } }).value(dur).view());
        String lbl = dur <= 0 ? I18n.tr("Até o ANO acabar") : I18n.tr("Dura ") + dur + (dur == 1 ? I18n.tr(" MPT") : I18n.tr(" MPTs"));
        inner.addView(raw(lbl, 12, LayoutManager.ACCENT, true));
        inner.addView(tv(CutsceneFields.DURATION_NOTE, 10, LayoutManager.DIM, false));
        if (fx != null) { disable(inner); inner.setAlpha(0.4f); }
        g.addView(inner);
        if (fx != null) g.addView(tv(fx, 10, LayoutManager.DIM, false));
        return g;
    }

    private View posRow(String name, boolean edit, int shown, String fixedNote, final boolean isX) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(raw(name, 13, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(dp(22), -2));
        r.addView(new Stepper(a).range(-4000, 4000).step(1).keyboard(new Stepper.OnValue() {
            public void on(double v) { changed = true; if (isX) pos.setX((int) v); else pos.setY((int) v); if (pv != null) pv.pause(); refreshPreview(); }
        }).value(shown).view(), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout g = new LinearLayout(a);
        g.setOrientation(LinearLayout.VERTICAL);
        g.addView(r);
        if (!edit) { disable(g); g.setAlpha(0.4f); }
        box.addView(g);
        if (!edit && fixedNote != null) box.addView(tv(fixedNote, 10, LayoutManager.DIM, false));
        return box;
    }

    private void flagBlock(int flag) {
        label("FLAG (efeito extra da cena)");
        for (final CutsceneFields.FlagGroup g : CutsceneFields.flagGroups()) {
            TextView t = tv(g.title, 11, LayoutManager.DIM, true);
            t.setPadding(0, dp(6), 0, dp(1));
            detail.addView(t);
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.VERTICAL);
            if (g.boxes) {
                final int bits = CutsceneFields.boxesOf(flag);
                for (int i = 0; i < g.opts.length; i++) {
                    final int bit = i == 0 ? 1 : 2;
                    r.addView(switchRow(g.opts[i].name, null, (bits & bit) != 0, new Toggle() { public void on(boolean v) {
                        int nb = v ? bits | bit : bits & ~bit;
                        set(CharData.EV_FLAG, CutsceneFields.flagOfBoxes((nb & 1) != 0, (nb & 2) != 0));
                    } }), lp(0, 0, 2, 0, 2));
                }
            } else {
                final int cur = flag;
                for (final CutsceneFields.FlagOpt o : g.opts) {
                    r.addView(switchRow(o.name, null, o.value == flag, new Toggle() { public void on(boolean v) {
                        set(CharData.EV_FLAG, CutsceneFields.flagToggle(cur, o.value, v));
                    } }), lp(0, 0, 2, 0, 2));
                }
            }
            detail.addView(r);
        }
        note(flag == 0 ? "FLAG 0: nada (todas as chaves desligadas)" : "FLAG " + flag + ": " + CutsceneFields.flagHelp(flag), LayoutManager.ACCENT);
        note("Só uma chave fica ligada por vez (o jogo guarda um número só); desligar a ligada volta a FLAG 0.", LayoutManager.DIM);
    }

    // ---- grade de eventos ----

    private Dialog grid;
    private LinearLayout gridBox;
    private final List<View> cards = new ArrayList<View>();

    private void openGrid() {
        grid = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        grid.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("EVENTOS (HDAT 13)", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { grid.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        TextView hint = tv("Toque para escolher o evento a editar. O hit da timeline só muda com USAR NESTE HIT. Só dá para ZERAR (não excluir): o número dos eventos seguintes é usado pelos hits.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(6));
        root.addView(hint);
        ScrollView sv = new SafeScrollView(a);
        gridBox = new LinearLayout(a);
        gridBox.setOrientation(LinearLayout.VERTICAL);
        sv.addView(gridBox);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(a);
        bar.addView(button("NOVO", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { push(); sel = cd.addEvent(-1); afterGridEdit(); } }), lp(1, 0, 0, 3, 0));
        bar.addView(button("DUPLICAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) { push(); sel = cd.addEvent(sel); afterGridEdit(); } } }), lp(1, 3, 0, 3, 0));
        bar.addView(button("COPIAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
            if (cd.hasEvent(sel)) { clip = cd.eventRow(sel); I18nUi.toast(a, "Evento copiado", android.widget.Toast.LENGTH_SHORT).show(); }
        } }), lp(1, 3, 0, 3, 0));
        bar.addView(button("COLAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
            if (clip == null) { I18nUi.toast(a, "Nada copiado", android.widget.Toast.LENGTH_SHORT).show(); return; }
            if (cd.hasEvent(sel)) { push(); cd.setEventRow(sel, clip); afterGridEdit(); }
        } }), lp(1, 3, 0, 0, 0));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout bar2 = new LinearLayout(a);
        bar2.addView(button("ZERAR", 0xFFFFB454, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) { push(); cd.clearEvent(sel); afterGridEdit(); } } }), lp(1, 0, 0, 3, 0));
        bar2.addView(button("USAR ESTE EVENTO", 0xFF7CE08A, new View.OnClickListener() { public void onClick(View v) { grid.dismiss(); } }), lp(2, 3, 0, 0, 0));
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.topMargin = dp(6);
        root.addView(bar2, b2);
        grid.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() { public void onDismiss(android.content.DialogInterface di) { grid = null; pickAno(); rebuild(); } });
        fillGrid();
        grid.show();
    }

    private void afterGridEdit() {
        undoBtn.setAlpha(undo.isEmpty() ? 0.4f : 1f);
        fillGrid();
    }

    private void fillGrid() {
        if (gridBox == null) return;
        SafeScrollView.releaseFocus(gridBox);
        gridBox.removeAllViews();
        cards.clear();
        int n = cd.eventRows();
        if (n == 0) { gridBox.addView(tv("Este personagem não tem eventos no HDAT 13. Toque em NOVO para criar o primeiro.", 12, LayoutManager.DIM, false)); return; }
        Ano[] anos = CutsceneEdit.all(ch.dac);
        int side = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(6) * 3 * 2) / 3;
        LinearLayout row = null;
        for (int i = 0; i < n; i++) {
            if (i % 3 == 0) { row = new LinearLayout(a); gridBox.addView(row); }
            final int id = i;
            int[] r = cd.eventRow(i);
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            card.setPadding(dp(3), dp(3), dp(3), dp(3));
            FrameLayout fl = new FrameLayout(a);
            fl.addView(previewCell(null, r[CharData.EV_ALVO / 2], r[CharData.EV_ANIM / 2], side - dp(6), true));
            int uses = CutsceneEdit.users(anos, i).size();
            if (uses > 0) {
                TextView b = tv("×" + uses, 10, 0xFFFFFFFF, true);
                b.setBackgroundColor(0xAA000000);
                b.setPadding(dp(4), 0, dp(4), 0);
                fl.addView(b, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
            }
            if (i == hitEvent) {
                TextView b = tv("HIT", 10, 0xFF7CE08A, true);
                b.setBackgroundColor(0xAA000000);
                b.setPadding(dp(4), 0, dp(4), 0);
                fl.addView(b, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
            }
            card.addView(fl);
            boolean empty = CutsceneFields.isEmpty(r);
            TextView lab = new I18nTextView(a).noTranslate();
            lab.setText(String.format(java.util.Locale.US, "EV %02d", i) + (empty ? "  (vazio)" : ""));
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            lab.setTextColor(empty ? LayoutManager.DIM : LayoutManager.TEXT);
            lab.setTypeface(Typeface.DEFAULT_BOLD);
            lab.setGravity(Gravity.CENTER);
            card.addView(lab);
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sel = id; markSel(); } });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            cp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(card, cp);
            cards.add(card);
        }
        markSel();
    }

    private void markSel() {
        for (int i = 0; i < cards.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == sel ? 0x334C8DFF : 0x00000000);
            g.setStroke(dp(2), i == sel ? LayoutManager.ACCENT : 0x00000000);
            g.setCornerRadius(dp(8));
            cards.get(i).setBackground(g);
        }
    }
}
