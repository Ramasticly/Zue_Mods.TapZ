package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * Editor das cutscenes da flag 20 (HDAT 13 do personagem). Abre so pelo hit da cutscene na timeline (EDITAR CUTSCENE). Em cima a previa das 2 animacoes do evento;
 * logo abaixo o evento (toque para abrir a GRADE de eventos: trocar, NOVO, DUPLICAR, COPIAR, COLAR, ZERAR) e USAR NESTE HIT; embaixo os campos, com a POSICAO do
 * hit (modo "segue o mundo / a tela / a camera") e os campos que o jogo ignora ou fixa esmaecidos e sem poder mudar ({@link CutsceneFields}). Mexe direto no
 * CharData (o Saver grava o $ROTEIRO_CUTSCENE no *.bin.txt); a simulacao da tela principal e refeita ao fechar.
 */
final class CutsceneScreen {
    interface Use { void on(int event); }

    /** O hit da timeline que abriu o editor: sua posicao (X/Y) e se esta num ANO de projetil. */
    interface HitPos {
        int x();
        int y();
        void setX(int v);
        void setY(int v);
        boolean projectile();
    }

    /** Linha copiada (COPIAR/COLAR): vale entre eventos e entre personagens. */
    private static int[] clip;

    private final Activity a;
    private final AttackView view;
    private final CharAssets ch;
    private final CharData cd;
    private final Use use;
    private final HitPos pos;
    private final int hitEvent;
    private final float d;
    private Dialog dlg;
    private int sel;
    private final List<CharData.EventsSnap> undo = new ArrayList<CharData.EventsSnap>();
    private LinearLayout previewBox, barBox, detail;
    private TextView undoBtn;

    /** {@code start} = evento do hit; {@code use} (pode ser null) = "USAR NESTE HIT"; {@code pos} (pode ser null) = X/Y do hit. */
    static void show(Activity a, AttackView view, int start, Use use, HitPos pos) {
        view.pause();
        AttackData ad = view.attackData();
        if (ad == null || ad.attacker == null || ad.attacker.data == null) {
            I18nUi.toast(a, "Carregue um personagem para editar as cutscenes", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        new CutsceneScreen(a, view, ad.attacker, start, use, pos).open();
    }

    private CutsceneScreen(Activity a, AttackView view, CharAssets ch, int start, Use use, HitPos pos) {
        this.a = a; this.view = view; this.ch = ch; this.cd = ch.data; this.use = use; this.pos = pos;
        this.d = a.getResources().getDisplayMetrics().density;
        this.hitEvent = start;
        this.sel = Math.max(0, Math.min(Math.max(0, cd.eventRows() - 1), start));
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 12, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private TextView chip(String s, boolean on, View.OnClickListener l) {
        TextView t = tv(s, 12, on ? 0xFFFFFFFF : LayoutManager.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout.LayoutParams lp(float w, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w > 0 ? 0 : -2, -2, w);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("CUTSCENE (HDAT 13)", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        undoBtn = button("↶", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { undoLast(); } });
        h.addView(undoBtn, new LinearLayout.LayoutParams(dp(48), dp(40)));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        previewBox = new LinearLayout(a);                        // em cima: as 2 animacoes do evento
        previewBox.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(previewBox, new LinearLayout.LayoutParams(-1, -2));
        barBox = new LinearLayout(a);                            // o evento (abre a grade) e USAR NESTE HIT
        barBox.setOrientation(LinearLayout.VERTICAL);
        barBox.setPadding(0, dp(6), 0, dp(4));
        root.addView(barBox, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new SafeScrollView(a);                   // embaixo: os campos
        detail = new LinearLayout(a);
        detail.setOrientation(LinearLayout.VERTICAL);
        detail.setPadding(0, dp(4), 0, dp(8));
        sv.addView(detail);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar2 = new LinearLayout(a);
        bar2.addView(button("FECHAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }), lp(1, 0, 0, 0, 0));
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.topMargin = dp(6);
        root.addView(bar2, b2);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface di) { if (changed) view.refreshAfterExternalEdit(); }
        });
        rebuild();
        dlg.show();
    }

    private boolean changed;

    private void push() {
        undo.add(cd.snapshotEvents());
        changed = true;
    }

    private void undoLast() {
        if (undo.isEmpty()) return;
        cd.restoreEvents(undo.remove(undo.size() - 1));
        sel = Math.min(sel, Math.max(0, cd.eventRows() - 1));
        rebuild();
        if (grid != null && grid.isShowing()) fillGrid();
    }

    private void set(int off, int v) {
        push();
        cd.setEventField(sel, off, v);
        postDetail();
    }

    private boolean detailPending;

    /**
     * Refaz previa e campos DEPOIS do callback atual: o Stepper confirma o valor dentro do onFocusChange/IME do proprio EditText, e remover esse EditText da tela nessa hora
     * deixava o ScrollView com um foco que ja nao e filho dela (IllegalArgumentException "parameter must be a descendant of this view" no proximo layout).
     */
    private void postDetail() {
        if (detailPending) return;
        detailPending = true;
        detail.post(new Runnable() { public void run() { detailPending = false; rebuild(); } });
    }

    /** Previa, barra do evento e campos. */
    private void rebuild() {
        undoBtn.setAlpha(undo.isEmpty() ? 0.4f : 1f);
        rebuildPreview();
        rebuildBar();
        rebuildDetail();
    }

    private Dac packDac(int alvo) { return view.packDac(alvo == 0 ? 0 : alvo == 1 ? 2 : 3); }
    private SpriteCache packSprites(int alvo) { return view.packSprites(alvo == 0 ? 0 : alvo == 1 ? 2 : 3); }

    private int cellSide() { return Math.min(dp(150), (a.getResources().getDisplayMetrics().widthPixels - dp(60)) / 2); }

    private View previewCell(String title, int alvo, int ano, int side, boolean firstFrameOnly) {
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        Dac dac = packDac(alvo);
        Ano an = dac == null ? null : dac.getAno(ano);
        if (ano > 0 && an != null && an.present && an.mpts.length > 0) {
            AnimPreview pv = new AnimPreview(a);
            if (firstFrameOnly) pv.setFirstFrameOnly(true);
            pv.set(dac, packSprites(alvo), ano);
            cell.addView(pv, new LinearLayout.LayoutParams(side, side));
        } else {
            TextView e = tv(ano == 0 ? "sem animação" : dac == null ? "pacote não carregado" : "ANO vazia", 11, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            cell.addView(e, new LinearLayout.LayoutParams(side, side));
        }
        if (title != null) cell.addView(tv(title, 11, LayoutManager.DIM, false));
        return cell;
    }

    private void rebuildPreview() {
        SafeScrollView.releaseFocus(previewBox);
        previewBox.removeAllViews();
        if (!cd.hasEvent(sel)) { previewBox.addView(tv("Sem eventos: abra o EVENTO e toque em NOVO.", 12, LayoutManager.DIM, false)); return; }
        int alvo = cd.eventField(sel, CharData.EV_ALVO), animN = cd.eventField(sel, CharData.EV_ANIM), animF = cd.eventField(sel, CharData.EV_ANIM_FLIP);
        int side = cellSide();
        previewBox.addView(previewCell("virado para a direita (ANIM_ID)", alvo, animN, side, false), lp(1, 2, 0, 2, 0));
        previewBox.addView(previewCell("virado para a esquerda (ANIM_FLIP)", alvo, animF, side, false), lp(1, 2, 0, 2, 0));
    }

    private void rebuildBar() {
        SafeScrollView.releaseFocus(barBox);
        barBox.removeAllViews();
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView evBtn = button(I18n.tr("EVENTO ") + String.format(java.util.Locale.US, "%02d", sel) + " ▾  ·  " + I18n.tr("trocar · novo · copiar…"), LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { openGrid(); } });
        evBtn.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        r.addView(evBtn, lp(1, 0, 0, 0, 0));
        if (use != null) r.addView(button(sel == hitEvent ? "USAR NESTE HIT ✓" : "USAR NESTE HIT", sel == hitEvent ? LayoutManager.DIM : 0xFF7CE08A, new View.OnClickListener() { public void onClick(View v) {
            if (cd.hasEvent(sel)) { use.on(sel); dlg.dismiss(); }
        } }), lp(0, 6, 0, 0, 0));
        barBox.addView(r);
        List<Integer> users = CutsceneEdit.users(CutsceneEdit.all(ch.dac), sel);
        TextView u = tv(users.isEmpty() ? "Nenhuma ANO deste personagem usa o evento " + sel + "." : "Usado pelas ANOs " + users + ".", 11, LayoutManager.DIM, false);
        u.setPadding(dp(2), dp(3), 0, 0);
        barBox.addView(u);
    }

    // ---- campos ----

    private void label(String s) {
        TextView t = tv(s, 12, LayoutManager.TEXT, true);
        t.setPadding(0, dp(10), 0, dp(2));
        detail.addView(t);
    }

    private void note(String s) {
        TextView t = tv(s, 11, LayoutManager.DIM, false);
        detail.addView(t);
    }

    /** Desliga a view e tudo dentro dela: campo fixo nao responde ao toque. */
    private static void disable(View v) {
        v.setEnabled(false);
        v.setFocusable(false);
        if (v instanceof ViewGroup) { ViewGroup g = (ViewGroup) v; for (int i = 0; i < g.getChildCount(); i++) disable(g.getChildAt(i)); }
    }

    /** Um campo: titulo + controle; se o jogo o ignora/fixa neste modo, fica esmaecido, desligado e com o motivo embaixo. */
    private void field(int off, String title, View content, String help) {
        String fx = CutsceneFields.fixed(row(), sel, off);
        LinearLayout g = new LinearLayout(a);
        g.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(title, 12, LayoutManager.TEXT, true);
        t.setPadding(0, dp(10), 0, dp(2));
        g.addView(t);
        g.addView(content);
        if (fx != null) { disable(g); g.setAlpha(0.4f); }
        detail.addView(g);
        if (fx != null) note(fx);
        else if (help != null) note(help);
    }

    private int[] row() { return cd.eventRow(sel); }

    private LinearLayout choices(String[] names, int cur, final int off, int[] values) {
        LinearLayout r = new LinearLayout(a);
        for (int i = 0; i < names.length; i++) {
            final int val = values[i];
            r.addView(chip(names[i], val == cur, new View.OnClickListener() { public void onClick(View v) { set(off, val); } }), lp(1, 2, 2, 2, 2));
        }
        return r;
    }

    private View animField(final String name, final int off, final int alvo) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(new Stepper(a).range(0, 4095).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { set(off, (int) v); } }).value(cd.eventField(sel, off)).view(), lp(1, 0, 0, 6, 0));
        r.addView(button("ESCOLHER", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            Dac dac = packDac(alvo);
            if (dac == null) { I18nUi.toast(a, "Pacote não carregado (para o ALVO 2 é preciso a pasta bobj em assets)", android.widget.Toast.LENGTH_LONG).show(); return; }
            AnoPicker.showAll(a, dac, packSprites(alvo), cd.eventField(sel, off), name, new AnoPicker.Listener() { public void onPick(int ano) { set(off, ano); } });
        } }), new LinearLayout.LayoutParams(-2, -2));
        return r;
    }

    private void positionBlock() {
        if (pos == null) return;
        CutsceneFields.Pos p = CutsceneFields.position(row(), sel, pos.x(), pos.y());
        label("POSIÇÃO (X / Y do hit na timeline)");
        TextView m = tv(p.mode, 11, LayoutManager.ACCENT, false);
        m.setPadding(0, 0, 0, dp(4));
        detail.addView(m);
        if (p.camera != null) { TextView k = tv(p.camera, 11, LayoutManager.ACCENT, false); k.setPadding(0, 0, 0, dp(4)); detail.addView(k); }
        detail.addView(posRow("X", p.xEdit, p.xShown, p.xNote, true));
        detail.addView(posRow("Y", p.yEdit, p.yShown, p.yNote, false));
    }

    private View posRow(String name, boolean edit, int shown, String fixedNote, final boolean isX) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(tv(name, 13, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(dp(28), -2));
        r.addView(new Stepper(a).range(-4000, 4000).step(1).keyboard(new Stepper.OnValue() {
            public void on(double v) { changed = true; if (isX) pos.setX((int) v); else pos.setY((int) v); }
        }).value(shown).view(), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout g = new LinearLayout(a);
        g.setOrientation(LinearLayout.VERTICAL);
        g.addView(r);
        if (!edit) { disable(g); g.setAlpha(0.4f); }
        box.addView(g);
        if (!edit && fixedNote != null) box.addView(tv(fixedNote, 11, LayoutManager.DIM, false));
        return box;
    }

    private void rebuildDetail() {
        SafeScrollView.releaseFocus(detail);
        detail.removeAllViews();
        if (!cd.hasEvent(sel)) return;
        int alvo = cd.eventField(sel, CharData.EV_ALVO);
        positionBlock();
        field(CharData.EV_ALVO, "ALVO (de onde vem a animação)", choices(new String[] {"effect.pac", "char do player", "bobj"}, alvo == 0 || alvo == 1 ? alvo : 2, CharData.EV_ALVO, new int[] {0, 1, 2}), null);
        field(CharData.EV_ANIM, "ANIM_ID (virado para a direita; 0 = sem animação)", animField("ANIM_ID", CharData.EV_ANIM, alvo), null);
        field(CharData.EV_ANIM_FLIP, "ANIM_FLIP (virado para a esquerda)", animField("ANIM_FLIP", CharData.EV_ANIM_FLIP, alvo), null);
        field(CharData.EV_DURACAO, "DURAÇÃO", new Stepper(a).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { set(CharData.EV_DURACAO, (int) v); } }).value(cd.eventField(sel, CharData.EV_DURACAO)).view(),
                "0 ou negativo = até a animação do golpe mudar (ou acabar); N positivo = limite de N frames do ANO do golpe (frames, não ticks).");
        field(CharData.EV_Z, "Z_LAYER (camada de desenho)", choices(new String[] {"0 · " + CutsceneInfo.zValue(sel, 0), "1 · " + CutsceneInfo.zValue(sel, 1), "2 · " + CutsceneInfo.zValue(sel, 2)}, Math.max(0, Math.min(2, cd.eventField(sel, CharData.EV_Z))), CharData.EV_Z, new int[] {0, 1, 2}), null);
        field(CharData.EV_CAM, "CAM_MODE", choices(new String[] {"0 · mundo", "1 · tela cheia", "2 · tela"}, Math.max(0, Math.min(2, cd.eventField(sel, CharData.EV_CAM))), CharData.EV_CAM, new int[] {0, 1, 2}),
                "0 = a cena segue o mundo; diferente de 0 = origem na tela (0, 0), ignorando o X/Y do hit; 1 também ativa a tela cheia.");
        field(CharData.EV_STUN, "TRAVAR_VIT (congela o oponente no estado 925)", choices(new String[] {"não", "sim"}, cd.eventField(sel, CharData.EV_STUN) != 0 ? 1 : 0, CharData.EV_STUN, new int[] {0, 1}), null);
        int fl = cd.eventField(sel, CharData.EV_FLAG);
        LinearLayout flags = new LinearLayout(a);
        flags.setOrientation(LinearLayout.VERTICAL);
        LinearLayout rowL = null;
        for (int f = 0; f <= 15; f++) {
            if (f % 8 == 0) { rowL = new LinearLayout(a); flags.addView(rowL); }
            final int fv = f;
            rowL.addView(chip(String.valueOf(f), f == fl, new View.OnClickListener() { public void onClick(View v) { set(CharData.EV_FLAG, fv); } }), lp(1, 1, 1, 1, 1));
        }
        field(CharData.EV_FLAG, "FLAG (efeito extra da cena)", flags, fl == 0 ? "0 · nada" : CutsceneInfo.mapaName(fl));
        label("Como o jogo lê este evento");
        note(CutsceneInfo.describe(cd, sel, pos == null ? 0 : pos.x(), pos == null ? 0 : pos.y(), pos != null && pos.projectile()));
    }

    // ---- grade de eventos ----

    private Dialog grid;
    private LinearLayout gridBox;
    private final List<View> cards = new ArrayList<View>();

    private void openGrid() {
        grid = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        grid.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("EVENTOS (HDAT 13)", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { grid.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        TextView hint = tv("Toque para escolher o evento a editar. O hit da timeline só muda com USAR NESTE HIT. Só dá para ZERAR (não excluir): o número dos eventos seguintes é usado pelos hits.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(6));
        root.addView(hint);
        ScrollView sv = new SafeScrollView(a);
        gridBox = new LinearLayout(a);
        gridBox.setOrientation(LinearLayout.VERTICAL);
        sv.addView(gridBox);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(a);
        bar.addView(button("NOVO", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { push(); sel = cd.addEvent(-1); afterGridEdit(); } }), lp(1, 0, 0, 3, 0));
        bar.addView(button("DUPLICAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) { push(); sel = cd.addEvent(sel); afterGridEdit(); } } }), lp(1, 3, 0, 3, 0));
        bar.addView(button("COPIAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
            if (cd.hasEvent(sel)) { clip = cd.eventRow(sel); I18nUi.toast(a, "Evento copiado", android.widget.Toast.LENGTH_SHORT).show(); }
        } }), lp(1, 3, 0, 3, 0));
        bar.addView(button("COLAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
            if (clip == null) { I18nUi.toast(a, "Nada copiado", android.widget.Toast.LENGTH_SHORT).show(); return; }
            if (cd.hasEvent(sel)) { push(); cd.setEventRow(sel, clip); afterGridEdit(); }
        } }), lp(1, 3, 0, 0, 0));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout bar2 = new LinearLayout(a);
        bar2.addView(button("ZERAR", 0xFFFFB454, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) { push(); cd.clearEvent(sel); afterGridEdit(); } } }), lp(1, 0, 0, 3, 0));
        bar2.addView(button("USAR ESTE EVENTO", 0xFF7CE08A, new View.OnClickListener() { public void onClick(View v) { grid.dismiss(); } }), lp(2, 3, 0, 0, 0));
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.topMargin = dp(6);
        root.addView(bar2, b2);
        grid.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() { public void onDismiss(android.content.DialogInterface di) { grid = null; rebuild(); } });
        fillGrid();
        grid.show();
    }

    private void afterGridEdit() {
        undoBtn.setAlpha(undo.isEmpty() ? 0.4f : 1f);
        fillGrid();
    }

    private void fillGrid() {
        if (gridBox == null) return;
        SafeScrollView.releaseFocus(gridBox);
        gridBox.removeAllViews();
        cards.clear();
        int n = cd.eventRows();
        if (n == 0) { gridBox.addView(tv("Este personagem não tem eventos no HDAT 13. Toque em NOVO para criar o primeiro.", 12, LayoutManager.DIM, false)); return; }
        Ano[] anos = CutsceneEdit.all(ch.dac);
        int side = (a.getResources().getDisplayMetrics().widthPixels - dp(20) - dp(6) * 3 * 2) / 3;
        LinearLayout row = null;
        for (int i = 0; i < n; i++) {
            if (i % 3 == 0) { row = new LinearLayout(a); gridBox.addView(row); }
            final int id = i;
            int[] r = cd.eventRow(i);
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            card.setPadding(dp(3), dp(3), dp(3), dp(3));
            FrameLayout fl = new FrameLayout(a);
            fl.addView(previewCell(null, r[CharData.EV_ALVO / 2], r[CharData.EV_ANIM / 2], side - dp(6), true));
            int uses = CutsceneEdit.users(anos, i).size();
            if (uses > 0) {
                TextView b = tv("×" + uses, 10, 0xFFFFFFFF, true);
                b.setBackgroundColor(0xAA000000);
                b.setPadding(dp(4), 0, dp(4), 0);
                fl.addView(b, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
            }
            if (i == hitEvent) {
                TextView b = tv("HIT", 10, 0xFF7CE08A, true);
                b.setBackgroundColor(0xAA000000);
                b.setPadding(dp(4), 0, dp(4), 0);
                fl.addView(b, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
            }
            card.addView(fl);
            boolean empty = CutsceneFields.isEmpty(r);
            TextView lab = new I18nTextView(a).noTranslate();
            lab.setText(String.format(java.util.Locale.US, "EV %02d", i) + (empty ? "  (vazio)" : ""));
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            lab.setTextColor(empty ? LayoutManager.DIM : LayoutManager.TEXT);
            lab.setTypeface(Typeface.DEFAULT_BOLD);
            lab.setGravity(Gravity.CENTER);
            card.addView(lab);
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sel = id; markSel(); } });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            cp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(card, cp);
            cards.add(card);
        }
        markSel();
    }

    private void markSel() {
        for (int i = 0; i < cards.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == sel ? 0x334C8DFF : 0x00000000);
            g.setStroke(dp(2), i == sel ? LayoutManager.ACCENT : 0x00000000);
            g.setCornerRadius(dp(8));
            cards.get(i).setBackground(g);
        }
    }
}
