package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * Editor das cutscenes da flag 20 (HDAT 13 do personagem): lista de eventos, e por evento ALVO, animacoes (virado para a direita / esquerda) com
 * previa, DURACAO, camada, camera, trava do oponente e FLAG, com o texto de CutsceneInfo ao vivo. Mexe direto no CharData (o Saver grava o
 * $ROTEIRO_CUTSCENE no 000.bin.txt); a simulacao da tela principal e refeita ao fechar.
 */
final class CutsceneScreen {
    interface Use { void on(int event); }

    private final Activity a;
    private final AttackView view;
    private final CharAssets ch;
    private final CharData cd;
    private final Use use;
    private final float d;
    private Dialog dlg;
    private int sel;
    private final List<CharData.EventsSnap> undo = new ArrayList<CharData.EventsSnap>();
    private LinearLayout chips, detail;
    private TextView undoBtn;

    /** {@code start} = evento aberto de inicio; {@code use} (pode ser null) = "USAR NESTE HIT". */
    static void show(Activity a, AttackView view, int start, Use use) {
        view.pause();
        AttackData ad = view.attackData();
        if (ad == null || ad.attacker == null || ad.attacker.data == null) {
            I18nUi.toast(a, "Carregue um personagem para editar as cutscenes", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        new CutsceneScreen(a, view, ad.attacker, start, use).open();
    }

    private CutsceneScreen(Activity a, AttackView view, CharAssets ch, int start, Use use) {
        this.a = a; this.view = view; this.ch = ch; this.cd = ch.data; this.use = use;
        this.d = a.getResources().getDisplayMetrics().density;
        this.sel = Math.max(0, Math.min(Math.max(0, cd.eventRows() - 1), start));
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 12, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private TextView chip(String s, boolean on, View.OnClickListener l) {
        TextView t = tv(s, 12, on ? 0xFFFFFFFF : LayoutManager.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout.LayoutParams lp(float w, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w > 0 ? 0 : -2, -2, w);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("CUTSCENES (HDAT 13)", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        undoBtn = button("↶", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { undoLast(); } });
        h.addView(undoBtn, new LinearLayout.LayoutParams(dp(48), dp(40)));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        TextView hint = tv("O 3º valor da hitbox da flag 20 escolhe o evento. Mudanças valem na hora e vão para o 000.bin.txt ao salvar.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(6));
        root.addView(hint);
        ScrollView sv = new SafeScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        sv.addView(col);
        chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.VERTICAL);
        col.addView(chips);
        detail = new LinearLayout(a);
        detail.setOrientation(LinearLayout.VERTICAL);
        detail.setPadding(0, dp(8), 0, dp(8));
        col.addView(detail);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(a);
        bar.addView(button("NOVO", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { push(); sel = cd.addEvent(-1); rebuild(); } }), lp(1, 0, 0, 3, 0));
        bar.addView(button("DUPLICAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) { push(); sel = cd.addEvent(sel); rebuild(); } } }), lp(1, 3, 0, 3, 0));
        bar.addView(button("ZERAR", 0xFFFFB454, new View.OnClickListener() { public void onClick(View v) { if (cd.hasEvent(sel)) { push(); cd.clearEvent(sel); rebuild(); } } }), lp(1, 3, 0, 3, 0));
        bar.addView(button("EXCLUIR", 0xFFFF6B6B, new View.OnClickListener() { public void onClick(View v) { deleteLast(); } }), lp(1, 3, 0, 0, 0));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout bar2 = new LinearLayout(a);
        if (use != null) bar2.addView(button("USAR NESTE HIT", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            if (cd.hasEvent(sel)) { use.on(sel); dlg.dismiss(); }
        } }), lp(1, 0, 0, 3, 0));
        bar2.addView(button("FECHAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }), lp(1, use != null ? 3 : 0, 0, 0, 0));
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.topMargin = dp(6);
        root.addView(bar2, b2);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface di) { if (changed) view.refreshAfterExternalEdit(); }
        });
        rebuild();
        dlg.show();
    }

    private boolean changed;

    private void push() {
        undo.add(cd.snapshotEvents());
        changed = true;
    }

    private void undoLast() {
        if (undo.isEmpty()) return;
        cd.restoreEvents(undo.remove(undo.size() - 1));
        sel = Math.min(sel, Math.max(0, cd.eventRows() - 1));
        rebuild();
    }

    private void deleteLast() {
        if (cd.eventRows() == 0) return;
        final int last = cd.eventRows() - 1;
        List<Integer> users = CutsceneEdit.users(CutsceneEdit.all(ch.dac), last);
        Runnable go = new Runnable() { public void run() { push(); cd.removeLastEvent(); sel = Math.min(sel, Math.max(0, cd.eventRows() - 1)); rebuild(); } };
        if (users.isEmpty()) { go.run(); return; }
        final Runnable fgo = go;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Excluir o último evento?")
                .setMessage("O evento " + last + " é usado pelas ANOs " + users + ". Só o último evento pode ser excluído (tirar do meio mudaria o número dos seguintes); use ZERAR para esvaziar outro.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("EXCLUIR", new android.content.DialogInterface.OnClickListener() { public void onClick(android.content.DialogInterface di, int w) { fgo.run(); } }).show();
    }

    private void set(int off, int v) {
        push();
        cd.setEventField(sel, off, v);
        postDetail();
    }

    private boolean detailPending;

    /**
     * Refaz os campos DEPOIS do callback atual: o Stepper confirma o valor dentro do onFocusChange/IME do proprio EditText, e remover esse EditText da tela nessa hora
     * deixava o ScrollView com um foco que ja nao e filho dela (IllegalArgumentException "parameter must be a descendant of this view" no proximo layout).
     */
    private void postDetail() {
        if (detailPending) return;
        detailPending = true;
        detail.post(new Runnable() { public void run() { detailPending = false; rebuildDetail(); } });
    }

    private void rebuild() {
        undoBtn.setAlpha(undo.isEmpty() ? 0.4f : 1f);
        SafeScrollView.releaseFocus(chips);
        chips.removeAllViews();
        LinearLayout row = null;
        for (int i = 0; i < cd.eventRows(); i++) {
            if (i % 6 == 0) { row = new LinearLayout(a); chips.addView(row); }
            final int id = i;
            row.addView(chip(String.format(java.util.Locale.US, "%02d", i), i == sel, new View.OnClickListener() { public void onClick(View v) { sel = id; rebuild(); } }), lp(1, 2, 2, 2, 2));
        }
        if (cd.eventRows() == 0) chips.addView(tv("Este personagem não tem eventos no HDAT 13. Toque em NOVO para criar o primeiro.", 12, LayoutManager.DIM, false));
        rebuildDetail();
    }

    private Dac packDac(int alvo) { return view.packDac(alvo == 0 ? 0 : alvo == 1 ? 2 : 3); }
    private SpriteCache packSprites(int alvo) { return view.packSprites(alvo == 0 ? 0 : alvo == 1 ? 2 : 3); }

    private View previewCell(String title, int alvo, int ano) {
        LinearLayout cell = new LinearLayout(a);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        Dac dac = packDac(alvo);
        Ano an = dac == null ? null : dac.getAno(ano);
        int side = Math.min(dp(130), (a.getResources().getDisplayMetrics().widthPixels - dp(60)) / 2);
        if (ano > 0 && an != null && an.present && an.mpts.length > 0) {
            AnimPreview pv = new AnimPreview(a);
            pv.set(dac, packSprites(alvo), ano);
            cell.addView(pv, new LinearLayout.LayoutParams(side, side));
        } else {
            TextView e = tv(ano == 0 ? "sem animação" : dac == null ? "pacote não carregado" : "ANO vazia", 11, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            cell.addView(e, new LinearLayout.LayoutParams(side, side));
        }
        cell.addView(tv(title, 11, LayoutManager.DIM, false));
        return cell;
    }

    private void label(String s) {
        TextView t = tv(s, 12, LayoutManager.TEXT, true);
        t.setPadding(0, dp(10), 0, dp(2));
        detail.addView(t);
    }

    private void note(String s) {
        TextView t = tv(s, 11, LayoutManager.DIM, false);
        detail.addView(t);
    }

    private LinearLayout choices(String[] names, int cur, final int off, int[] values) {
        LinearLayout r = new LinearLayout(a);
        for (int i = 0; i < names.length; i++) {
            final int val = values[i];
            r.addView(chip(names[i], val == cur, new View.OnClickListener() { public void onClick(View v) { set(off, val); } }), lp(1, 2, 2, 2, 2));
        }
        return r;
    }

    private void animField(final String name, final int off, final int alvo) {
        label(name);
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(new Stepper(a).range(0, 4095).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { set(off, (int) v); } }).value(cd.eventField(sel, off)).view(), lp(1, 0, 0, 6, 0));
        r.addView(button("ESCOLHER", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
            Dac dac = packDac(alvo);
            if (dac == null) { I18nUi.toast(a, "Pacote não carregado (para o ALVO 2 é preciso a pasta bobj em assets)", android.widget.Toast.LENGTH_LONG).show(); return; }
            AnoPicker.showAll(a, dac, packSprites(alvo), cd.eventField(sel, off), name, new AnoPicker.Listener() { public void onPick(int ano) { set(off, ano); } });
        } }), new LinearLayout.LayoutParams(-2, -2));
        detail.addView(r);
    }

    private void rebuildDetail() {
        SafeScrollView.releaseFocus(detail);
        detail.removeAllViews();
        if (!cd.hasEvent(sel)) return;
        int alvo = cd.eventField(sel, CharData.EV_ALVO), animN = cd.eventField(sel, CharData.EV_ANIM), animF = cd.eventField(sel, CharData.EV_ANIM_FLIP);
        LinearLayout pv = new LinearLayout(a);
        pv.setGravity(Gravity.CENTER_HORIZONTAL);
        pv.addView(previewCell("virado para a direita (ANIM_ID)", alvo, animN), lp(1, 2, 0, 2, 0));
        pv.addView(previewCell("virado para a esquerda (ANIM_FLIP)", alvo, animF), lp(1, 2, 0, 2, 0));
        detail.addView(pv);
        List<Integer> users = CutsceneEdit.users(CutsceneEdit.all(ch.dac), sel);
        note(users.isEmpty() ? "Nenhuma ANO deste personagem usa o evento " + sel + "." : "Usado pelas ANOs " + users + ".");
        label("ALVO (de onde vem a animação)");
        detail.addView(choices(new String[] {"effect.pac", "char do player", "bobj"}, alvo == 0 || alvo == 1 ? alvo : 2, CharData.EV_ALVO, new int[] {0, 1, 2}));
        animField("ANIM_ID (virado para a direita; 0 = sem animação)", CharData.EV_ANIM, alvo);
        animField("ANIM_FLIP (virado para a esquerda)", CharData.EV_ANIM_FLIP, alvo);
        label("DURAÇÃO");
        detail.addView(new Stepper(a).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { set(CharData.EV_DURACAO, (int) v); } }).value(cd.eventField(sel, CharData.EV_DURACAO)).view());
        note("0 ou negativo = até a animação do golpe mudar (ou acabar); N positivo = limite de N frames do ANO do golpe (frames, não ticks).");
        label("Z_LAYER (camada de desenho)");
        detail.addView(choices(new String[] {"0 · " + CutsceneInfo.zValue(sel, 0), "1 · " + CutsceneInfo.zValue(sel, 1), "2 · " + CutsceneInfo.zValue(sel, 2)}, Math.max(0, Math.min(2, cd.eventField(sel, CharData.EV_Z))), CharData.EV_Z, new int[] {0, 1, 2}));
        label("CAM_MODE");
        detail.addView(choices(new String[] {"0 · mundo", "1 · tela cheia", "2 · tela"}, Math.max(0, Math.min(2, cd.eventField(sel, CharData.EV_CAM))), CharData.EV_CAM, new int[] {0, 1, 2}));
        note("0 = a cena segue o mundo; diferente de 0 = origem na tela (0, 0), ignorando o x/y do hit; 1 também ativa a tela cheia. Eventos 8 e 9 sempre ficam em (0, 0).");
        label("TRAVAR_VIT (congela o oponente no estado 925)");
        detail.addView(choices(new String[] {"não", "sim"}, cd.eventField(sel, CharData.EV_STUN) != 0 ? 1 : 0, CharData.EV_STUN, new int[] {0, 1}));
        label("FLAG (efeito extra da cena)");
        int fl = cd.eventField(sel, CharData.EV_FLAG);
        LinearLayout row = null;
        for (int f = 0; f <= 15; f++) {
            if (f % 8 == 0) { row = new LinearLayout(a); detail.addView(row); }
            final int fv = f;
            row.addView(chip(String.valueOf(f), f == fl, new View.OnClickListener() { public void onClick(View v) { set(CharData.EV_FLAG, fv); } }), lp(1, 1, 1, 1, 1));
        }
        note(fl == 0 ? "0 · nada" : CutsceneInfo.mapaName(fl));
        label("Como o jogo lê este evento");
        note(CutsceneInfo.describe(cd, sel, 0, 0));
    }
}
