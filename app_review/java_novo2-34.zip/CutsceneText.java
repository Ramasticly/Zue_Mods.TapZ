package com.zue.attackeditor;

import java.util.Locale;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * HDAT 13 (eventos da flag 20) no 000.bin.txt (Java puro): {@code $HDAT_13:{$info:{$COL: 8, $ROW: N, $SZ: &XXXXXXXX}, $ROTEIRO_CUTSCENE:{ comentarios,
 * $EVT_00: { $ALVO:0, $DURACAO:1, $Z_LAYER:1, $ANIM_ID:145, $ANIM_FLIP:145, $CAM_MODE:1, $TRAVAR_VIT:0, $FLAG:0 }, ... }}}.
 */
final class CutsceneText {
    private CutsceneText() { }

    static final String[] KEYS = {"ALVO", "DURACAO", "Z_LAYER", "ANIM_ID", "ANIM_FLIP", "CAM_MODE", "TRAVAR_VIT", "FLAG"};

    private static String stripComments(String blk) {
        StringBuilder sb = new StringBuilder();
        for (String ln : blk.split("\n")) {
            int c = ln.indexOf("//");
            sb.append(c >= 0 ? ln.substring(0, c) : ln).append('\n');
        }
        return sb.toString();
    }

    /** Linhas $EVT_nn do bloco $ROTEIRO_CUTSCENE (8 valores cada, na ordem de {@link #KEYS}); null se o bloco nao existe. Eventos que faltam ficam zerados. */
    static int[][] parse(String text) {
        int[] b = Saver.findBlock(text, "ROTEIRO_CUTSCENE");
        if (b == null) return null;
        String blk = stripComments(text.substring(b[1], b[2] + 1));
        Matcher fm = Pattern.compile("\\$EVT_(\\d+)\\s*:\\s*\\{([^}]*)\\}").matcher(blk);
        TreeMap<Integer, int[]> rows = new TreeMap<Integer, int[]>();
        while (fm.find()) {
            int[] v = new int[KEYS.length];
            Matcher km = Pattern.compile("\\$([A-Za-z_]+)\\s*:\\s*(-?\\d+)").matcher(fm.group(2));
            while (km.find()) for (int k = 0; k < KEYS.length; k++) if (KEYS[k].equalsIgnoreCase(km.group(1))) v[k] = Integer.parseInt(km.group(2));
            rows.put(Integer.valueOf(Integer.parseInt(fm.group(1))), v);
        }
        if (rows.isEmpty()) return null;
        int n = rows.lastKey().intValue() + 1;
        int[][] out = new int[n][KEYS.length];
        for (java.util.Map.Entry<Integer, int[]> e : rows.entrySet()) out[e.getKey().intValue()] = e.getValue();
        return out;
    }

    static String evtLine(String ind, int id, int[] v) {
        StringBuilder sb = new StringBuilder(ind).append(String.format(Locale.US, "$EVT_%02d: {", id));
        for (int k = 0; k < KEYS.length; k++) sb.append(k == 0 ? " " : ", ").append('$').append(KEYS[k]).append(':').append(v[k]);
        return sb.append(" },\n").toString();
    }

    /**
     * Troca as linhas $EVT_nn pelas de {@code cd} (comentarios do bloco ficam) e corrige $COL/$ROW/$SZ do $info. Se o bloco $ROTEIRO_CUTSCENE nao
     * existe e o $HDAT_13 sim, ele e criado; sem $HDAT_13, {@code found[0]} = false e nada muda.
     */
    static String patch(String text, CharData cd, boolean[] found) {
        int[] hb = Saver.findBlock(text, "HDAT_13");
        found[0] = hb != null;
        if (hb == null) return text;
        StringBuilder lines = new StringBuilder();
        int rows = cd.eventRows();
        String ind = "         ";
        int[] rb = Saver.findBlock(text, "ROTEIRO_CUTSCENE");
        int firstEvt = -1, lastEnd = -1;
        if (rb != null) {
            Matcher m = Pattern.compile("\\$EVT_\\d+\\s*:\\s*\\{[^}]*\\},?[ \\t]*\\n?").matcher(text);
            for (int from = rb[1]; from <= rb[2] && m.find(from); from = m.end()) {
                if (m.start() > rb[2]) break;
                int ls = text.lastIndexOf('\n', m.start()) + 1;
                if (text.substring(ls, m.start()).contains("//")) continue;       // dentro de comentario
                if (firstEvt < 0) { firstEvt = ls; ind = text.substring(ls, m.start()); }
                lastEnd = m.end();
            }
        }
        for (int r = 0; r < rows; r++) lines.append(evtLine(ind, r, cd.eventRow(r)));
        String out;
        if (rb != null && firstEvt >= 0) {
            out = text.substring(0, firstEvt) + lines + text.substring(lastEnd);
        } else if (rb != null) {
            int cl = text.lastIndexOf('\n', rb[2]) + 1;
            boolean own = text.substring(cl, rb[2]).trim().isEmpty();
            out = own ? text.substring(0, cl) + lines + text.substring(cl)
                      : text.substring(0, rb[2]) + "\n" + lines + text.substring(rb[2]);
        } else {
            String hind = "   ";
            int cl = text.lastIndexOf('\n', hb[2]) + 1;
            boolean own = text.substring(cl, hb[2]).trim().isEmpty();
            String blk = hind + "   $ROTEIRO_CUTSCENE:{\n" + lines + hind + "   },\n";
            String before = text.substring(0, own ? cl : hb[2]);
            int q = before.length() - 1;
            while (q >= 0 && Character.isWhitespace(before.charAt(q))) q--;
            String comma = q >= 0 && before.charAt(q) == '}' ? "," : "";
            out = before.substring(0, q + 1) + comma + before.substring(q + 1) + (own ? "" : "\n") + blk + text.substring(own ? cl : hb[2]);
        }
        return fixInfo(out, rows);
    }

    private static String fixInfo(String out, int rows) {
        int[] hb = Saver.findBlock(out, "HDAT_13");
        if (hb == null) return out;
        int end = out.indexOf('}', hb[1]) + 1;               // fim do $info{...}
        String hs = out.substring(hb[0], end);
        String fixed = hs.replaceFirst("(\\$COL\\s*:\\s*)\\d+", "$1" + CharData.EV_COLS)
                .replaceFirst("(\\$ROW\\s*:\\s*)\\d+", "$1" + rows)
                .replaceFirst("(\\$SZ\\s*:\\s*&)[0-9A-Fa-f]+", "$1" + String.format(Locale.US, "%08X", rows * CharData.EV_COLS * 2));
        return out.substring(0, hb[0]) + fixed + out.substring(end);
    }
}
