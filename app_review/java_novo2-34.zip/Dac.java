package com.zue.attackeditor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Leitor DAC (secao 3 do .pac do personagem). O modelo fica em {@link Ano}.
 * Uma ANO quebrada nao derruba o arquivo inteiro: ela vira "ausente" e entra em getWarnings().
 */
public final class Dac {
    private Ano[] anos;
    private final List<String> warnings;

    private Dac(Ano[] anos, List<String> warnings) {
        this.anos = anos;
        this.warnings = warnings;
    }

    public static Dac read(byte[] data) throws IOException {
        if (data == null || data.length < 8) throw new IOException("DAC pequeno demais.");
        Reader r = new Reader(data);
        r.seek(2);
        int count = r.u16();
        int tableOffset = r.u16();
        int dataOffset = r.u16();

        Ano[] anos = new Ano[count];
        List<String> warnings = new ArrayList<String>();
        for (int ai = 0; ai < count; ai++) {
            try {
                anos[ai] = readAno(r, data, ai, tableOffset, dataOffset);
            } catch (IOException e) {
                anos[ai] = missing(ai);
                warnings.add("ANO " + ai + ": " + e.getMessage());
            }
        }
        return new Dac(anos, warnings);
    }

    /**
     * DAC lido do TXT ({@code DAC_ACT_ { $ANO_n: {...} }}): o tamanho e o maior {@code $ANO_n} + 1 (como o compilador do jogo); ANO sem bloco ou com bloco que nao le fica
     * ausente (com aviso). Nenhum binario e lido.
     */
    public static Dac fromTxt(String text) throws IOException {
        if (text == null) throw new IOException("DAC vazio");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\$ANO_(\\d+)\\s*:\\s*\\{").matcher(text);
        java.util.TreeMap<Integer, int[]> blocks = new java.util.TreeMap<Integer, int[]>();
        while (m.find()) {
            int ls = text.lastIndexOf('\n', m.start()) + 1;
            if (text.substring(ls, m.start()).contains("//")) continue;          // dentro de comentario
            int open = m.end() - 1, depth = 0, end = -1;
            for (int p = open; p < text.length(); p++) {
                char ch = text.charAt(p);
                if (ch == '/' && p + 1 < text.length() && text.charAt(p + 1) == '/') { while (p < text.length() && text.charAt(p) != '\n') p++; continue; }
                if (ch == '{') depth++;
                else if (ch == '}') { depth--; if (depth == 0) { end = p; break; } }
            }
            int idx;
            try { idx = Integer.parseInt(m.group(1)); } catch (NumberFormatException e) { continue; }
            if (end > 0 && idx >= 0 && idx <= 0x0FFF && !blocks.containsKey(Integer.valueOf(idx))) blocks.put(Integer.valueOf(idx), new int[]{m.start(), end});
        }
        if (blocks.isEmpty()) throw new IOException("DAC sem nenhum $ANO_n");
        Ano[] anos = new Ano[blocks.lastKey().intValue() + 1];
        List<String> warnings = new ArrayList<String>();
        for (int i = 0; i < anos.length; i++) {
            int[] b = blocks.get(Integer.valueOf(i));
            anos[i] = missing(i);
            if (b == null) continue;
            try {
                Ano a = DacText.parseAno(text.substring(b[0], b[1] + 1), i, null);
                if (a.mpts.length > 0 || a.links.length > 0) anos[i] = a;
            } catch (Exception ex) {
                warnings.add("ANO " + i + ": " + ex.getMessage());
            }
        }
        return new Dac(anos, warnings);
    }

    private static Ano missing(int index) {
        return new Ano(index, false, 0, 0, new Ano.Link[0], new Ano.Mpt[0]);
    }

    private static Ano readAno(Reader r, byte[] data, int ai, int tableOffset, int dataOffset)
            throws IOException {
        int tablePos = tableOffset + ai * 2;
        if (tablePos < 0 || tablePos + 2 > data.length)
            throw new IOException("tabela fora do DAC (" + tablePos + ")");
        r.seek(tablePos);
        int entryPtr = r.s16();
        if (entryPtr == -1) return missing(ai);

        int entryPos = dataOffset + (entryPtr << 2);
        if (entryPos < 0 || entryPos + 2 > data.length)
            throw new IOException("entrada fora do DAC (" + entryPos + ")");
        r.seek(entryPos);

        int pflags = r.u8();
        int mptCount = r.u8();
        int priority = ((pflags & 4) != 0) ? r.s8() : 0;

        Ano.Link[] links;
        if ((pflags & 2) != 0) {
            int linkCount = r.u8();
            links = new Ano.Link[linkCount];
            for (int i = 0; i < linkCount; i++) {
                links[i] = new Ano.Link(r.s16(), r.s16(), r.u16());
            }
        } else {
            links = new Ano.Link[0];
        }

        int mptBase = r.position();
        Ano.Mpt[] mpts = new Ano.Mpt[mptCount];
        for (int mi = 0; mi < mptCount; mi++) {
            int pointerPos = mptBase + mi * 2;
            if (pointerPos + 2 > data.length) throw new IOException("ponteiro MPT fora do DAC");
            r.seek(pointerPos);
            // No jogo este offset e lido SEM sinal (0..65535). Com sinal quebrava ANOs grandes.
            int relative = r.u16();
            int mptPos = relative + mptBase + mptCount * 2;
            if (mptPos < 0 || mptPos >= data.length)
                throw new IOException("MPT " + mi + " fora do DAC (" + mptPos + ")");
            r.seek(mptPos);
            mpts[mi] = readMpt(r);
        }
        return new Ano(ai, true, pflags, priority, links, mpts);
    }

    public Ano getAno(int index) {
        if (index < 0 || index >= anos.length) return null;
        return anos[index];
    }

    /** Troca a ANO em memoria (edicao em runtime); devolve a anterior. */
    public Ano setAno(int index, Ano a) {
        if (index < 0 || index >= anos.length) return null;
        Ano old = anos[index];
        anos[index] = a;
        return old;
    }

    public int size() { return anos.length; }

    /** Aumenta a tabela para {@code n} ANOs (as novas ficam ausentes ate serem trocadas): ANOs que o .dac.txt tem alem do binario. */
    public void growTo(int n) {
        if (n <= anos.length) return;
        Ano[] g = new Ano[n];
        System.arraycopy(anos, 0, g, 0, anos.length);
        for (int i = anos.length; i < n; i++) g[i] = missing(i);
        anos = g;
    }

    /** Copia rasa (so a tabela de ANOs) com a ANO {@code index} trocada: serve para previas sem mexer no DAC real. */
    public Dac copyWith(int index, Ano a) {
        Ano[] c = anos.clone();
        if (index >= 0 && index < c.length) c[index] = a;
        return new Dac(c, warnings);
    }

    public List<String> getWarnings() { return Collections.unmodifiableList(warnings); }

    /** Mesma ordem de campos do _ActReqMain do jogo. */
    private static Ano.Mpt readMpt(Reader r) throws IOException {
        Ano.Mpt m = new Ano.Mpt();
        int f = r.u8();
        m.flags = f;

        m.hasTime = (f & 0x20) != 0;
        m.time = m.hasTime ? r.u8() : 0;

        m.image = r.s16();

        m.hasMid = (f & 0x01) != 0;
        if (m.hasMid) { m.midX = r.s16(); m.midY = r.s16(); }

        if ((f & 0x02) != 0) m.wActFlag = r.u16();

        if ((f & 0x08) != 0) m.se = r.u8();           // id do SE: byte sem sinal (0..255)

        m.hasMove = (f & 0x04) != 0;
        if (m.hasMove) {
            int mf = r.u8();
            m.moveMask = mf;
            if ((mf & 1) != 0) m.speedX = r.i32();
            if ((mf & 2) != 0) m.speedY = r.i32();
            if ((mf & 4) != 0) m.accelX = r.i32();
            if ((mf & 8) != 0) m.accelY = r.i32();
        }

        if ((f & 0x10) != 0) {
            int n = r.u8();
            m.hits = new Ano.Hit[n];
            for (int i = 0; i < n; i++) {
                Ano.Hit h = new Ano.Hit();
                int hf = r.u8();
                h.flag = hf & 0x7F;
                if ((hf & 0x80) != 0) {
                    h.x = r.s16(); h.y = r.s16(); h.width = r.s16(); h.height = r.s16();
                } else {
                    h.x = r.s8(); h.y = r.s8(); h.width = r.u8(); h.height = r.u8();
                }
                m.hits[i] = h;
            }
        }

        // OPT: 2 bytes de flag + 4 bytes. Frames com "extras" tem tamanho variavel e nao sao
        // suportados aqui (combinado: extras sao ignorados no simulador).
        m.hasOpt = (f & 0x40) != 0;
        if (m.hasOpt) {
            m.optFlag = r.u16();
            for (int i = 0; i < 4; i++) m.optData[i] = r.u8();
        }

        m.hasRaz = (f & 0x80) != 0;
        if (m.hasRaz) {
            m.rot = r.s16();
            m.alphaRaw = r.s16();
            m.xZoom = r.s16();
            m.yZoom = r.s16();
            finishRaz(m);
        }
        return m;
    }

    /** Deriva razFlags/alpha de alphaRaw (como o jogo faz ao ler o campo 0x80). */
    static void finishRaz(Ano.Mpt m) {
        m.razFlags = 2048;
        if (m.alphaRaw != 0) {
            int blend = m.alphaRaw >> 8;
            if (blend != 0) m.razFlags |= (blend == 1) ? 512 : 1024;
            m.alpha = 255 - (m.alphaRaw & 255);
        } else {
            m.alpha = 255;
        }
    }

    private static final class Reader {
        final byte[] b;
        int p;

        Reader(byte[] b) { this.b = b; }

        void seek(int x) throws IOException {
            if (x < 0 || x > b.length) throw new IOException("seek fora: " + x);
            p = x;
        }

        int position() { return p; }
        int u8() throws IOException { need(1); return b[p++] & 255; }
        int s8() throws IOException { return (byte) u8(); }
        int u16() throws IOException { need(2); return (b[p++] & 255) | ((b[p++] & 255) << 8); }
        int s16() throws IOException { return (short) u16(); }
        int i32() throws IOException {
            need(4);
            return (b[p++] & 255) | ((b[p++] & 255) << 8) | ((b[p++] & 255) << 16) | ((b[p++] & 255) << 24);
        }
        void need(int n) throws IOException {
            if (p + n > b.length) throw new IOException("fim do DAC em " + p);
        }
    }
}
