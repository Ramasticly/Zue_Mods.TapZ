package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Formato texto do DAC / HDAT 4 ($ANO_n, $MPT_n, $LNKS, $GOLPE_n): gera o texto a partir do modelo
 * em memoria e le o texto editado de volta (edicao em runtime).
 */
final class DacText {
    private DacText() { }

    // ============================================================ escrita

    static String ano(Ano a, int markPat) {
        StringBuilder sb = new StringBuilder();
        sb.append("$ANO_").append(a.index).append(": {\n");
        if (!a.present || (a.mpts.length == 0 && a.links.length == 0 && (a.flags & 4) == 0)) { sb.append("},"); return sb.toString(); }
        if ((a.flags & 4) != 0) sb.append("   $PRIO: ").append(a.priority).append(",\n");
        if (a.links.length > 0 || (a.flags & 2) != 0) sb.append(links(a.links, "   ")).append('\n');
        sb.append("   $MPTS:{\n");
        for (int i = 0; i < a.mpts.length; i++) {
            String m = mpt(a.mpts[i], i, "      ");
            if (i == markPat) m = "»" + m.substring(1);
            sb.append(m).append('\n');
        }
        sb.append("   },\n},");
        return sb.toString();
    }

    static String links(Ano.Link[] ls, String ind) {
        StringBuilder sb = new StringBuilder();
        sb.append(ind).append("$LNKS:{\n");
        for (int i = 0; i < ls.length; i++) {
            Ano.Link l = ls[i];
            sb.append(ind).append("   $LINK_").append(i).append(": {$BX: ").append(l.baseX).append(", $BY: ").append(l.baseY)
              .append(", $SYNC{SPAWN_POS: ").append(l.spawnPos() ? "YES" : "NOT").append(", XY: ").append(l.syncXY() ? "YES" : "NOT")
              .append(", MPT: ").append(l.syncMpt() ? "YES" : "NOT").append("}, $ANO: ").append(l.getAno()).append("},\n");
        }
        sb.append(ind).append("},");
        return sb.toString();
    }

    static String mpt(Ano.Mpt m, int idx, String ind) {
        StringBuilder sb = new StringBuilder();
        String in2 = ind + "   ", in3 = in2 + "   ";
        sb.append(ind).append("$MPT_").append(idx).append(":{\n").append(in2);
        boolean first = true;
        if ((m.flags & 0x20) != 0) { sb.append("$TIME: ").append(m.time); first = false; }
        sb.append(first ? "" : ", ").append("$IMG: ").append(m.image);
        if ((m.flags & 1) != 0) sb.append(", $MID:[").append(m.midX).append(", ").append(m.midY).append(']');
        if ((m.flags & 2) != 0) sb.append(", $WACTFLAG: ").append(m.wActFlag);
        if ((m.flags & 8) != 0) sb.append(", $SE: ").append(m.se);
        sb.append(",\n");
        if ((m.flags & 4) != 0) {
            sb.append(in2).append("$MOVE:{");
            if ((m.moveMask & 1) != 0) sb.append("$XSPEED: ").append(fix(m.speedX)).append(", ");
            if ((m.moveMask & 2) != 0) sb.append("$YSPEED: ").append(fix(m.speedY)).append(", ");
            if ((m.moveMask & 4) != 0) sb.append("$XACCEL: ").append(fix(m.accelX)).append(", ");
            if ((m.moveMask & 8) != 0) sb.append("$YACCEL: ").append(fix(m.accelY)).append(", ");
            sb.append("},\n");
        }
        if ((m.flags & 0x10) != 0) {
            sb.append(in2).append("$HITS:{\n");
            for (int i = 0; i < m.hits.length; i++) {
                Ano.Hit h = m.hits[i];
                sb.append(in3).append("$HT_").append(i).append(":{$FLAG: ").append(h.flag).append(", $COORDS: [")
                  .append(h.x).append(',').append(h.y).append(',').append(h.width).append(',').append(h.height).append("]},\n");
            }
            sb.append(in2).append("},\n");
        }
        if ((m.flags & 0x40) != 0) {
            sb.append(in2).append("$OPT:{$FLAG: ").append((short) m.optFlag).append(", $DATA: B[")
              .append(m.optData[0]).append(',').append(m.optData[1]).append(',').append(m.optData[2]).append(',').append(m.optData[3]).append("]},\n");
        }
        if ((m.flags & 0x80) != 0) {
            sb.append(in2).append("$RAZ:{$ROT: ").append(m.rot).append(", $ALPHA: ").append(m.alphaRaw)
              .append(", $XZOOM: ").append(m.xZoom).append(", $YZOOM: ").append(m.yZoom).append("},\n");
        }
        sb.append(ind).append("},");
        return sb.toString();
    }

    /** 16.16 -> decimal mais curto que volta ao mesmo valor (o jogo trunca: (int)(v * 65536)). */
    static String fix(int raw) {
        if ((raw & 0xFFFF) == 0) return String.valueOf(raw >> 16);
        for (int d = 1; d <= 8; d++) {
            String s = String.format(Locale.US, "%." + d + "f", raw / 65536.0);
            if ((int) (Double.parseDouble(s) * 65536.0) == raw) return s;
        }
        return String.format(Locale.US, "%.8f", raw / 65536.0);
    }

    static final String[] MOVE_KEYS = {"ATK_FLAGS", "ANIM_INICIAL", "PROJETIL_ANIM_NORMAL", "PROJETIL_ANIM_ABAIXO",
            "PROJETIL_ANIM_ACIMA", "PROJETIL_ANIM_ACERTAR_GLOBAL", "PROJETIL_ANIM_AO_ACERTAR", "PROJETIL_COLISAO_CHAO",
            "HOMING", "HOMING_VELOCIDADE", "MAX_REPETICOES", "SUBPROJETIL_ANIM_ID", "SUBPROJETIL_ANIM_AO_ACERTAR",
            "SUBPROJETIL_COLISAO_CHAO", "ANIM_AO_ACERTAR", "ANIM_SEQ_CHAO", "ANIM_END_CHAO", "ANIM_SEQ_AR", "ANIM_END_AR",
            "POUSO_AO_ERRAR", "POUSO_AO_ACERTAR", "OPONENTE_ANIM_SENDO_AGARRADO", "DESCONHECIDO_44", "DESCONHECIDO_46"};

    static int[] moveVals(CharData.Move m) {
        return new int[]{m.flags, m.animInicial, m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar,
                m.projChao, m.homing, m.homingSpeed, m.maxRep, m.subId, m.subAoAcertar, m.subChao, m.animAoAcertar,
                m.animSeqChao, m.animEndChao, m.animSeqAr, m.animEndAr, m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado,
                m.unk44, m.unk46};
    }

    static String move(CharData.Move m, int idx) {
        int[] v = moveVals(m);
        StringBuilder sb = new StringBuilder("$GOLPE_" + idx + ":{\n");
        for (int i = 0; i < MOVE_KEYS.length; i++) {
            if (i == 2 || i == 14 || i == 21 || i == 22) sb.append('\n');
            sb.append("   $").append(MOVE_KEYS[i]).append(": ").append(v[i]).append(i == MOVE_KEYS.length - 1 ? "\n" : ",\n");
        }
        return sb.append("},").toString();
    }

    // ============================================================ leitura

    static final class Node {
        String key;
        String val;                 // escalar (numero ou palavra)
        double[] nums;              // [..] ou B[..]
        List<Node> kids;            // {..}
        Node kid(String k) {
            if (kids == null) return null;
            for (int i = 0; i < kids.size(); i++) if (kids.get(i).key.equalsIgnoreCase(k)) return kids.get(i);
            return null;
        }
    }

    static final class ParseError extends Exception {
        ParseError(String m) { super(m); }
    }

    private static final class P {
        final String s;
        int p;
        P(String s) { this.s = s; }

        int line() { int n = 1; for (int i = 0; i < p && i < s.length(); i++) if (s.charAt(i) == '\n') n++; return n; }
        ParseError err(String m) { return new ParseError("linha " + line() + ": " + m); }

        void skip() {
            while (p < s.length()) {
                char c = s.charAt(p);
                if (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == ',' || c == '»') p++;
                else if (c == '/' && p + 1 < s.length() && s.charAt(p + 1) == '/') { while (p < s.length() && s.charAt(p) != '\n') p++; }
                else break;
            }
        }

        List<Node> entries(boolean nested) throws ParseError {
            List<Node> out = new ArrayList<Node>();
            while (true) {
                skip();
                if (p >= s.length()) { if (nested) throw err("falta '}'"); return out; }
                char c = s.charAt(p);
                if (c == '}') { if (!nested) throw err("'}' sobrando"); p++; return out; }
                out.add(entry());
            }
        }

        Node entry() throws ParseError {
            Node n = new Node();
            if (s.charAt(p) == '$') p++;
            int a = p;
            while (p < s.length() && (Character.isLetterOrDigit(s.charAt(p)) || s.charAt(p) == '_')) p++;
            if (p == a) throw err("esperava um nome ('" + s.charAt(p) + "')");
            n.key = s.substring(a, p);
            while (p < s.length() && (s.charAt(p) == ' ' || s.charAt(p) == '\t')) p++;
            if (p < s.length() && s.charAt(p) == ':') p++;
            while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++;
            if (p >= s.length()) throw err("falta o valor de " + n.key);
            char c = s.charAt(p);
            if (c == '{') { p++; n.kids = entries(true); }
            else if (c == '[' || (c == 'B' && p + 1 < s.length() && s.charAt(p + 1) == '[')) {
                if (c == 'B') p++;
                p++;
                List<Double> l = new ArrayList<Double>();
                while (true) {
                    skip();
                    if (p >= s.length()) throw err("falta ']'");
                    if (s.charAt(p) == ']') { p++; break; }
                    l.add(Double.valueOf(num(token())));
                }
                n.nums = new double[l.size()];
                for (int i = 0; i < n.nums.length; i++) n.nums[i] = l.get(i).doubleValue();
            } else {
                n.val = token();
            }
            return n;
        }

        String token() throws ParseError {
            int a = p;
            while (p < s.length()) {
                char c = s.charAt(p);
                if (c == ',' || c == '}' || c == ']' || Character.isWhitespace(c)) break;
                p++;
            }
            if (p == a) throw err("valor vazio");
            return s.substring(a, p);
        }

        double num(String t) throws ParseError {
            try {
                if (t.startsWith("&")) return Long.parseLong(t.substring(1), 16);
                return Double.parseDouble(t);
            } catch (NumberFormatException e) {
                throw err("numero invalido: " + t);
            }
        }
    }

    private static Node root(String text) throws ParseError {
        P p = new P(text);
        List<Node> l = p.entries(false);
        if (l.size() != 1) throw new ParseError(l.isEmpty() ? "texto vazio" : "esperava um unico bloco, achei " + l.size());
        return l.get(0);
    }

    private static int intOf(P ctx, Node n, String key, int def, boolean required) throws ParseError {
        Node k = n.kid(key);
        if (k == null) {
            if (required) throw new ParseError(n.key + ": falta $" + key);
            return def;
        }
        if (k.val == null) throw new ParseError(n.key + ": $" + key + " precisa de um numero");
        return (int) new P("").num(k.val);
    }

    private static int toInt(String v, String where) throws ParseError {
        try {
            if (v.startsWith("&")) return (int) Long.parseLong(v.substring(1), 16);
            return (int) Math.round(Double.parseDouble(v));
        } catch (NumberFormatException e) {
            throw new ParseError(where + ": numero invalido " + v);
        }
    }

    private static int req(Node n, String key, boolean required, int def) throws ParseError {
        Node k = n.kid(key);
        if (k == null) {
            if (required) throw new ParseError(n.key + ": falta $" + key);
            return def;
        }
        if (k.val == null) throw new ParseError(n.key + ": $" + key + " precisa de um numero");
        return toInt(k.val, n.key + " $" + key);
    }

    private static int fixed(String v, String where) throws ParseError {
        try { return (int) (Double.parseDouble(v) * 65536.0); }
        catch (NumberFormatException e) { throw new ParseError(where + ": numero invalido " + v); }
    }

    static Ano.Mpt parseMpt(String text) throws ParseError {
        return mptOf(root(text));
    }

    private static Ano.Mpt mptOf(Node n) throws ParseError {
        if (n.kids == null) throw new ParseError(n.key + ": esperava { ... }");
        Ano.Mpt m = new Ano.Mpt();
        int f = 0;
        for (Node k : n.kids) {
            String key = k.key.toUpperCase(Locale.US);
            if (key.equals("TIME")) { m.hasTime = true; m.time = req(n, "TIME", true, 0) & 255; f |= 0x20; }
            else if (key.equals("IMG")) m.image = req(n, "IMG", true, 0);
            else if (key.equals("MID")) {
                if (k.nums == null || k.nums.length != 2) throw new ParseError("$MID precisa de [x, y]");
                m.hasMid = true; m.midX = (int) k.nums[0]; m.midY = (int) k.nums[1]; f |= 1;
            }
            else if (key.equals("WACTFLAG")) { m.wActFlag = req(n, "WACTFLAG", true, 0) & 0xFFFF; f |= 2; }
            else if (key.equals("SE")) {
                m.se = req(n, "SE", true, 0);
                if (m.se < 0 || m.se > SoundIds.MAX_ID) throw new ParseError(n.key + ": $SE precisa estar entre 0 e " + SoundIds.MAX_ID + " (e " + m.se + ")");
                f |= 8;
            }
            else if (key.equals("MOVE")) {
                if (k.kids == null) throw new ParseError("$MOVE precisa de { }");
                m.hasMove = true; f |= 4;
                for (Node q : k.kids) {
                    String qk = q.key.toUpperCase(Locale.US);
                    if (q.val == null) throw new ParseError("$" + q.key + " precisa de um numero");
                    int v = fixed(q.val, "$" + q.key);
                    if (qk.equals("XSPEED")) { m.moveMask |= 1; m.speedX = v; }
                    else if (qk.equals("YSPEED")) { m.moveMask |= 2; m.speedY = v; }
                    else if (qk.equals("XACCEL")) { m.moveMask |= 4; m.accelX = v; }
                    else if (qk.equals("YACCEL")) { m.moveMask |= 8; m.accelY = v; }
                    else throw new ParseError("campo desconhecido em $MOVE: " + q.key);
                }
            }
            else if (key.equals("HITS")) {
                if (k.kids == null) throw new ParseError("$HITS precisa de { }");
                f |= 0x10;
                m.hits = new Ano.Hit[k.kids.size()];
                for (int i = 0; i < m.hits.length; i++) {
                    Node h = k.kids.get(i);
                    Node c = h.kid("COORDS");
                    if (h.kids == null || c == null || c.nums == null || c.nums.length != 4)
                        throw new ParseError(h.key + ": precisa de $FLAG e $COORDS: [x,y,w,h]");
                    Ano.Hit ht = new Ano.Hit();
                    ht.flag = req(h, "FLAG", true, 0);
                    ht.x = (int) c.nums[0]; ht.y = (int) c.nums[1]; ht.width = (int) c.nums[2]; ht.height = (int) c.nums[3];
                    m.hits[i] = ht;
                }
            }
            else if (key.equals("OPT")) {
                Node d = k.kid("DATA");
                if (k.kids == null || d == null || d.nums == null || d.nums.length != 4) throw new ParseError("$OPT precisa de $FLAG e $DATA: B[a,b,c,d]");
                m.hasOpt = true; f |= 0x40;
                m.optFlag = req(k, "FLAG", true, 0) & 0xFFFF;
                for (int i = 0; i < 4; i++) m.optData[i] = ((int) d.nums[i]) & 255;
            }
            else if (key.equals("RAZ")) {
                if (k.kids == null) throw new ParseError("$RAZ precisa de { }");
                m.hasRaz = true; f |= 0x80;
                m.rot = req(k, "ROT", false, 0);
                m.alphaRaw = req(k, "ALPHA", false, 0);
                m.xZoom = req(k, "XZOOM", false, 100);
                m.yZoom = req(k, "YZOOM", false, 100);
                Dac.finishRaz(m);
            }
            else throw new ParseError("campo desconhecido no frame: $" + k.key);
        }
        if (n.kid("IMG") == null) throw new ParseError(n.key + ": falta $IMG");
        m.flags = f;
        return m;
    }

    static Ano.Link[] parseLinks(String text, Ano.Link[] old) throws ParseError {
        return linksOf(root(text), old);
    }

    private static Ano.Link[] linksOf(Node n, Ano.Link[] old) throws ParseError {
        if (n.kids == null) throw new ParseError("$LNKS precisa de { ... }");
        Ano.Link[] out = new Ano.Link[n.kids.size()];
        for (int i = 0; i < out.length; i++) {
            Node l = n.kids.get(i);
            if (l.kids == null) throw new ParseError(l.key + ": esperava { ... }");
            int bx = req(l, "BX", false, 0), by = req(l, "BY", false, 0);
            int ano = req(l, "ANO", true, 0);
            if (ano < 0 || ano > 0xFFF) throw new ParseError(l.key + ": $ANO fora de 0..4095");
            int fl = ano;
            Node sy = l.kid("SYNC");
            if (sy != null) {
                if (sy.kids == null) throw new ParseError(l.key + ": $SYNC{SPAWN_POS: .., XY: .., MPT: ..}");
                for (Node q : sy.kids) {
                    boolean on = q.val != null && (q.val.equalsIgnoreCase("YES") || q.val.equals("1") || q.val.equalsIgnoreCase("TRUE"));
                    String qk = q.key.toUpperCase(Locale.US);
                    if (qk.equals("SPAWN_POS")) { if (on) fl |= 0x1000; }
                    else if (qk.equals("XY")) { if (on) fl |= 0x4000; }
                    else if (qk.equals("MPT")) { if (on) fl |= 0x8000; }
                    else throw new ParseError("campo desconhecido em $SYNC: " + q.key);
                }
            }
            if (old != null && i < old.length) fl |= old[i].flags & 0x2000;     // bit sem nome: preserva
            out[i] = new Ano.Link(bx, by, fl);
        }
        return out;
    }

    static Ano parseAno(String text, int index, Ano old) throws ParseError {
        Node n = root(text);
        if (n.kids == null) throw new ParseError("esperava $ANO_n: { ... }");
        int flags = old == null ? 0 : old.flags & ~6;
        int prio = 0;
        Ano.Link[] links = new Ano.Link[0];
        Ano.Mpt[] mpts = new Ano.Mpt[0];
        for (Node k : n.kids) {
            String key = k.key.toUpperCase(Locale.US);
            if (key.equals("PRIO")) {
                if (k.val == null) throw new ParseError("$PRIO precisa de um numero");
                prio = toInt(k.val, "$PRIO"); flags |= 4;
            } else if (key.equals("LNKS")) {
                links = linksOf(k, old == null ? null : old.links); flags |= 2;
            } else if (key.equals("MPTS")) {
                if (k.kids == null) throw new ParseError("$MPTS precisa de { ... }");
                mpts = new Ano.Mpt[k.kids.size()];
                for (int i = 0; i < mpts.length; i++) mpts[i] = mptOf(k.kids.get(i));
            } else throw new ParseError("campo desconhecido na ANO: $" + k.key);
        }
        if (mpts.length > 255) throw new ParseError("no maximo 255 MPTs");
        return new Ano(index, true, flags, prio, links, mpts);
    }

    /** Aplica os campos do texto $GOLPE_n em {@code dst}. */
    static void parseMove(String text, CharData.Move dst) throws ParseError {
        Node n = root(text);
        if (n.kids == null) throw new ParseError("esperava $GOLPE_n:{ ... }");
        CharData.Move m = dst.copy();
        for (Node k : n.kids) {
            int idx = -1;
            for (int i = 0; i < MOVE_KEYS.length; i++) if (MOVE_KEYS[i].equalsIgnoreCase(k.key)) idx = i;
            if (idx < 0) throw new ParseError("campo desconhecido: $" + k.key);
            if (k.val == null) throw new ParseError("$" + k.key + " precisa de um numero");
            int v = toInt(k.val, "$" + k.key);
            switch (idx) {
                case 0: m.flags = v; break;
                case 1: m.animInicial = v; break;
                case 2: m.projNormal = v; break;
                case 3: m.projAbaixo = v; break;
                case 4: m.projAcima = v; break;
                case 5: m.projGlobal = v; break;
                case 6: m.projAoAcertar = v; break;
                case 7: m.projChao = v; break;
                case 8: m.homing = v; break;
                case 9: m.homingSpeed = v; break;
                case 10: m.maxRep = v; break;
                case 11: m.subId = v; break;
                case 12: m.subAoAcertar = v; break;
                case 13: m.subChao = v; break;
                case 14: m.animAoAcertar = v; break;
                case 15: m.animSeqChao = v; break;
                case 16: m.animEndChao = v; break;
                case 17: m.animSeqAr = v; break;
                case 18: m.animEndAr = v; break;
                case 19: m.pousoErrar = v; break;
                case 20: m.pousoAcertar = v; break;
                case 21: m.oponenteAgarrado = v; break;
                case 22: m.unk44 = v; break;
                default: m.unk46 = v; break;
            }
        }
        m.clamp();                    // campos de 16 bits (short), nao de 1 byte
        dst.copyFrom(m);
    }
}
