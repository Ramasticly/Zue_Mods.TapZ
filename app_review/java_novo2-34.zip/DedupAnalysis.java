package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tabela de pares de "Remover Sprites repetidas": calculada UMA vez ao abrir (triagem por celulas + busca de angulo + conferencia em pixels) e depois so filtrada
 * pelos criterios ({@link DedupOptions}) e pela barra de semelhanca. R e sempre a menor do par (a que pode sair); K a maior (ou igual com indice menor). Java puro.
 */
final class DedupAnalysis {
    /** Nota minima das celulas para o par entrar na tabela (a barra vai de 50 a 100). */
    static final int FLOOR = 50;
    /** Parceiras (por nota das celulas) de cada sprite que seguem para a conferencia em pixels. */
    static final int MAX_PARTNERS = 8;

    interface Progress { /** @return false para cancelar */ boolean on(String stage, int done, int total); }

    final Map<Long, SpriteDedup.Match> pairs = new HashMap<Long, SpriteDedup.Match>();
    final Map<Integer, SpriteDedup.Sig> byIndex = new HashMap<Integer, SpriteDedup.Sig>();
    boolean complete = true;       // false = acabou o tempo ou foi cancelada
    int unverified;                // pares que ficaram sem a conferencia em pixels
    SpriteDedup.Matcher matcher = SpriteDedup.NONE;

    static long key(int r, int k) { return SpriteDedup.Matcher.key(r, k); }

    /** K vem antes de R na ordem de area (K pode representar R)? */
    static boolean before(SpriteDedup.Sig k, SpriteDedup.Sig r) {
        return k.area() > r.area() || (k.area() == r.area() && k.index < r.index);
    }

    /** So as celulas (sem conferencia em pixels): usado pelos testes e pelo caminho antigo. */
    static DedupAnalysis coarse(List<SpriteDedup.Sig> sigs, SpriteDedup.Matcher mx, int floor) {
        DedupAnalysis an = new DedupAnalysis();
        an.matcher = mx;
        for (SpriteDedup.Sig s : sigs) an.byIndex.put(Integer.valueOf(s.index), s);
        for (SpriteDedup.Sig r : sigs) {
            if (r.empty) continue;
            for (SpriteDedup.Sig k : sigs) {
                if (k == r || k.empty || !before(k, r)) continue;
                SpriteDedup.Match m = mx.match(r, k, floor);
                if (m != null) an.pairs.put(Long.valueOf(key(r.index, k.index)), m);
            }
        }
        return an;
    }

    /** Analise completa. {@code deadlineMs}: tempo maximo de tudo; passou disso, o que faltar fica sem conferencia (e nao entra nos grupos). */
    static DedupAnalysis analyze(final List<SpriteDedup.Sig> sigs, final Progress prog, final long deadlineMs) {
        final long t0 = System.currentTimeMillis();
        DedupAnalysis an = new DedupAnalysis();
        for (SpriteDedup.Sig s : sigs) an.byIndex.put(Integer.valueOf(s.index), s);
        // 1) giros em angulo qualquer
        an.matcher = SpriteRotSearch.run(sigs, SpriteRotSearch.FLOOR, deadlineMs / 3, new SpriteRotSearch.Progress() {
            @Override public boolean on(int done, int total) { return prog == null || prog.on("Procurando cópias giradas", done, total); }
        });
        if (!an.matcher.complete) an.complete = false;
        // 2) pares candidatos (celulas)
        List<SpriteDedup.Sig> live = new ArrayList<SpriteDedup.Sig>();
        for (SpriteDedup.Sig s : sigs) if (!s.empty) live.add(s);
        int n = live.size();
        for (int i = 0; i < n; i++) {
            if (prog != null && !prog.on("Comparando sprites", i, n)) { an.complete = false; return an; }
            SpriteDedup.Sig r = live.get(i);
            final List<Object[]> found = new ArrayList<Object[]>();         // {k, Match}
            for (SpriteDedup.Sig k : live) {
                if (k == r || !before(k, r)) continue;
                SpriteDedup.Match m = an.matcher.match(r, k, FLOOR);
                if (m != null) found.add(new Object[]{k, m});
            }
            // so as MAX_PARTNERS melhores (por nota das celulas) de cada sprite vao para a conferencia em pixels
            Collections.sort(found, new Comparator<Object[]>() {
                @Override public int compare(Object[] x, Object[] y) { return ((SpriteDedup.Match) y[1]).score - ((SpriteDedup.Match) x[1]).score; }
            });
            for (int q = 0; q < found.size() && q < MAX_PARTNERS; q++) an.pairs.put(Long.valueOf(key(r.index, ((SpriteDedup.Sig) found.get(q)[0]).index)), (SpriteDedup.Match) found.get(q)[1]);
        }
        // 3) conferencia em pixels
        int total = an.pairs.size(), done = 0;
        for (Map.Entry<Long, SpriteDedup.Match> e : an.pairs.entrySet()) {
            if (prog != null && !prog.on("Conferindo pixels", done, total)) { an.complete = false; }
            SpriteDedup.Match m = e.getValue();
            if (!an.complete || System.currentTimeMillis() - t0 > deadlineMs) { an.complete = false; an.unverified++; continue; }
            int ri = (int) (e.getKey().longValue() >> 32), ki = (int) e.getKey().longValue();
            SpriteDedup.Sig r = an.byIndex.get(Integer.valueOf(ri)), k = an.byIndex.get(Integer.valueOf(ki));
            if (m.score >= 100) { m.verified = true; m.iou = m.color = m.detail = m.palette = 100; }
            else SpriteVerify.verify(r, k, m);
            done++;
        }
        return an;
    }

    /**
     * Relacao de R com K: da tabela quando R e a menor; senao calcula na hora (so as 8 relacoes, conferida em pixels). null se nao ha relacao pelo piso.
     */
    SpriteDedup.Match matchFor(SpriteDedup.Sig r, SpriteDedup.Sig k) {
        SpriteDedup.Match m = pairs.get(Long.valueOf(key(r.index, k.index)));
        if (m != null) return m;
        if (before(k, r)) return null;                         // R menor e nao esta na tabela: nao casa
        m = matcher.match(r, k, FLOOR);
        if (m == null) return null;
        if (m.score >= 100) { m.verified = true; m.iou = m.color = m.detail = m.palette = 100; }
        else SpriteVerify.verify(r, k, m);
        pairs.put(Long.valueOf(key(r.index, k.index)), m);
        return m;
    }

    private static boolean better(SpriteDedup.Match a, SpriteDedup.Match b) {
        if (b == null) return true;
        boolean ua = a.up > 105, ub = b.up > 105;
        if (ua != ub) return !ua;
        return a.score > b.score;
    }

    /**
     * Grupos pela ordem de area (maior primeiro): cada sprite entra na raiz (a maior do grupo ou uma ainda solta) com a melhor relacao que passa nos criterios.
     * Com a opcao "cadeia", se nenhuma raiz serve, tenta os membros dos grupos. Grupos de 2 ou mais, em ordem da representante.
     */
    List<SpriteDedup.Group> groups(List<SpriteDedup.Sig> sigs, int minPct, DedupOptions opt) {
        List<SpriteDedup.Sig> order = new ArrayList<SpriteDedup.Sig>();
        for (SpriteDedup.Sig s : sigs) if (!s.empty) order.add(s);
        Collections.sort(order, new Comparator<SpriteDedup.Sig>() {
            @Override public int compare(SpriteDedup.Sig a, SpriteDedup.Sig b) { return a.area() != b.area() ? (a.area() > b.area() ? -1 : 1) : (a.index < b.index ? -1 : a.index > b.index ? 1 : 0); }
        });
        int n = order.size();
        Map<Integer, Integer> pos = new HashMap<Integer, Integer>();
        for (int i = 0; i < n; i++) pos.put(Integer.valueOf(order.get(i).index), Integer.valueOf(i));
        List<List<Object[]>> partners = new ArrayList<List<Object[]>>();       // por R: {posicao de K, Match}
        for (int i = 0; i < n; i++) partners.add(new ArrayList<Object[]>());
        for (Map.Entry<Long, SpriteDedup.Match> e : pairs.entrySet()) {
            SpriteDedup.Match m = e.getValue();
            if (!opt.accepts(m, minPct)) continue;
            int ri = (int) (e.getKey().longValue() >> 32), ki = (int) e.getKey().longValue();
            Integer pr = pos.get(Integer.valueOf(ri)), pk = pos.get(Integer.valueOf(ki));
            if (pr == null || pk == null) continue;
            partners.get(pr.intValue()).add(new Object[]{pk, m});
        }
        SpriteDedup.Group[] of = new SpriteDedup.Group[n];
        boolean[] member = new boolean[n];
        List<SpriteDedup.Group> out = new ArrayList<SpriteDedup.Group>();
        for (int j = 0; j < n; j++) {
            int bi = -1, via = -1;
            SpriteDedup.Match bm = null;
            for (Object[] p : partners.get(j)) {
                int pk = ((Integer) p[0]).intValue();
                if (!member[pk] && better((SpriteDedup.Match) p[1], bm)) { bm = (SpriteDedup.Match) p[1]; bi = pk; }
            }
            if (bm == null && opt.chain.on) {
                for (Object[] p : partners.get(j)) {
                    int pk = ((Integer) p[0]).intValue();
                    if (member[pk] && better((SpriteDedup.Match) p[1], bm)) { bm = (SpriteDedup.Match) p[1]; bi = pk; via = order.get(pk).index; }
                }
            }
            if (bm == null) continue;
            SpriteDedup.Group g = of[bi];
            if (g == null) {
                g = new SpriteDedup.Group();
                SpriteDedup.Member r = new SpriteDedup.Member();
                r.index = order.get(bi).index;
                g.members.add(r);
                of[bi] = g;
                out.add(g);
            }
            SpriteDedup.Member mem = new SpriteDedup.Member();
            mem.index = order.get(j).index; mem.toRep = bm; mem.via = via;
            g.members.add(mem);
            of[j] = g;
            member[j] = true;
        }
        Collections.sort(out, new Comparator<SpriteDedup.Group>() {
            @Override public int compare(SpriteDedup.Group a, SpriteDedup.Group b) { return a.rep() - b.rep(); }
        });
        return out;
    }

    /** Entre as que ficam, a que melhor substitui R (so relacoes que passam nos criterios); null se nenhuma. */
    SpriteDedup.Choice choose(SpriteDedup.Sig r, List<SpriteDedup.Sig> kept, int minPct, DedupOptions opt) {
        SpriteDedup.Choice c = null;
        for (SpriteDedup.Sig k : kept) {
            if (k.index == r.index || k.empty) continue;
            SpriteDedup.Match m = matchFor(r, k);
            if (m == null || !opt.accepts(m, minPct)) continue;
            if (c == null || better(m, c.match)) { c = new SpriteDedup.Choice(); c.removed = r; c.kept = k; c.match = m; }
        }
        return c;
    }
}
