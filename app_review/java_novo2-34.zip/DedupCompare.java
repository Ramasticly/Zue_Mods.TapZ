package com.zue.attackeditor;

/** Logica pura da tela COMPARAR: a sprite que fica e a removida alternam como dois Frames de uma animacao (400 ms padrao, em laco). */
final class DedupCompare {
    private DedupCompare() { }

    static final int DEFAULT_MS = 400;
    static final int[] DURATIONS = {200, 400, 800, 1200};

    /** Qual dos dois quadros aparece {@code elapsedMs} depois do inicio: 0 = a que fica (ajustada), 1 = a comparada. */
    static int phaseAt(long elapsedMs, int frameMs) {
        if (frameMs <= 0) return 0;
        return (int) ((Math.max(0L, elapsedMs) / frameMs) % 2);
    }

    /** Proxima duracao do ciclo 200 / 400 / 800 / 1200 ms (qualquer outro valor volta ao padrao). */
    static int nextDuration(int current) {
        for (int i = 0; i < DURATIONS.length; i++) if (DURATIONS[i] == current) return DURATIONS[(i + 1) % DURATIONS.length];
        return DEFAULT_MS;
    }

    /** Texto da tela: {@code SPR_0(mantida)} e, no outro quadro, {@code SPR_7(removida)} ou {@code SPR_7(mantida)} conforme a chave MANTER/REMOVER. */
    static String caption(int phase, int keptSprite, int comparedSprite, boolean removeSelected) {
        if (phase == 0) return "SPR_" + keptSprite + "(mantida)";
        return "SPR_" + comparedSprite + (removeSelected ? "(removida)" : "(mantida)");
    }

    /** Resultado de tocar na chave: a nova marca ({@code true} = REMOVER). */
    static boolean toggled(boolean currentlyRemove) { return !currentlyRemove; }
}
