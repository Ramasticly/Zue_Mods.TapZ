package com.zue.attackeditor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Marcas da grade de "Remover Sprites repetidas" (logica pura): quem sera removido e a regra "ao menos uma fica". Marcar so pela tela de comparacao. */
final class DedupMarks {
    final List<SpriteDedup.Group> groups;
    final Set<Integer> removed = new HashSet<Integer>();
    /** Sprites que pertencem a um GIF: nunca saem por aqui (so pela funcao "Otimizar GIF"). */
    final Set<Integer> fixed;

    DedupMarks(List<SpriteDedup.Group> groups) { this(groups, new HashSet<Integer>()); }

    DedupMarks(List<SpriteDedup.Group> groups, Set<Integer> fixed) { this.groups = groups; this.fixed = fixed; }

    boolean isFixed(int sprite) { return fixed.contains(Integer.valueOf(sprite)); }

    private static int indexOf(SpriteDedup.Group g, int sprite) {
        for (int i = 0; i < g.members.size(); i++) if (g.members.get(i).index == sprite) return i;
        return -1;
    }

    boolean isMarked(int sprite) { return removed.contains(Integer.valueOf(sprite)); }

    /** Quantas do grupo ficam se {@code sprite} for marcada (alem das ja marcadas). */
    private int stayingWithout(SpriteDedup.Group g, int sprite) {
        int n = 0;
        for (SpriteDedup.Member m : g.members) if (m.index != sprite && !isMarked(m.index)) n++;
        return n;
    }

    /** Marca/desmarca; recusa marcar a ultima que ficaria. Devolve se ficou como pedido. */
    boolean set(SpriteDedup.Group g, int sprite, boolean mark) {
        if (indexOf(g, sprite) < 0) return false;
        if (mark && isFixed(sprite)) return false;                 // sprite de GIF: so sai pelo Otimizar GIF
        if (!mark) { removed.remove(Integer.valueOf(sprite)); return true; }
        if (stayingWithout(g, sprite) == 0) return false;
        removed.add(Integer.valueOf(sprite));
        return true;
    }

    /** Tocar na sprite abre a comparacao? So as que nao sao a maior do grupo (a maior e a referencia fixa). */
    boolean canCompare(SpriteDedup.Group g, int sprite) {
        int i = indexOf(g, sprite);
        return i >= 1 && !isFixed(sprite);
    }

    /** Selo da linha no grupo: a maior = MANTER (FIXA); marcada = REMOVER; senao MANTER. */
    String chip(SpriteDedup.Group g, int sprite) {
        if (isFixed(sprite)) return "Sprite de Gif, mantida";
        if (!g.members.isEmpty() && g.members.get(0).index == sprite) return "MANTER (FIXA)";
        return isMarked(sprite) ? "REMOVER" : "MANTER";
    }

    int totalMarked() { return removed.size(); }

    int groupsWithMarks() {
        int n = 0;
        for (SpriteDedup.Group g : groups) for (SpriteDedup.Member m : g.members) if (isMarked(m.index)) { n++; break; }
        return n;
    }
}
