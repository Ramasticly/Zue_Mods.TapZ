package com.zue.attackeditor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Marcas da grade de "Remover Sprites repetidas" (logica pura): quem sera removido, MARCAR TUDO, regra "ao menos uma fica" e a navegacao do COMPARAR. */
final class DedupMarks {
    final List<SpriteDedup.Group> groups;
    final Set<Integer> removed = new HashSet<Integer>();

    DedupMarks(List<SpriteDedup.Group> groups) { this.groups = groups; }

    private static int indexOf(SpriteDedup.Group g, int sprite) {
        for (int i = 0; i < g.members.size(); i++) if (g.members.get(i).index == sprite) return i;
        return -1;
    }

    boolean isMarked(int sprite) { return removed.contains(Integer.valueOf(sprite)); }

    /** Quantas do grupo ficam se {@code sprite} for marcada (alem das ja marcadas). */
    private int stayingWithout(SpriteDedup.Group g, int sprite) {
        int n = 0;
        for (SpriteDedup.Member m : g.members) if (m.index != sprite && !isMarked(m.index)) n++;
        return n;
    }

    /** Marca/desmarca; recusa marcar a ultima que ficaria. Devolve se ficou como pedido. */
    boolean set(SpriteDedup.Group g, int sprite, boolean mark) {
        if (indexOf(g, sprite) < 0) return false;
        if (!mark) { removed.remove(Integer.valueOf(sprite)); return true; }
        if (stayingWithout(g, sprite) == 0) return false;
        removed.add(Integer.valueOf(sprite));
        return true;
    }

    /** MARCAR TUDO: todas menos a maior (a primeira do grupo). */
    void markAll(SpriteDedup.Group g) {
        for (int i = 1; i < g.members.size(); i++) removed.add(Integer.valueOf(g.members.get(i).index));
        removed.remove(Integer.valueOf(g.members.get(0).index));
    }

    void unmarkAll(SpriteDedup.Group g) {
        for (SpriteDedup.Member m : g.members) removed.remove(Integer.valueOf(m.index));
    }

    /** Todas as que nao sao a maior estao marcadas? (o botao vira DESMARCAR TUDO) */
    boolean allMarked(SpriteDedup.Group g) {
        if (g.members.size() < 2) return false;
        for (int i = 1; i < g.members.size(); i++) if (!isMarked(g.members.get(i).index)) return false;
        return true;
    }

    int totalMarked() { return removed.size(); }

    int groupsWithMarks() {
        int n = 0;
        for (SpriteDedup.Group g : groups) for (SpriteDedup.Member m : g.members) if (isMarked(m.index)) { n++; break; }
        return n;
    }

    /** COMPARAR: proximo/anterior do grupo entre as que nao sao a maior (circular). {@code dir} = +1 ou -1; sprite fora do grupo comeca na primeira. */
    int step(SpriteDedup.Group g, int current, int dir) {
        int n = g.members.size() - 1;
        if (n <= 0) return current;
        int i = indexOf(g, current);
        if (i < 1) return g.members.get(1).index;
        int j = (i - 1 + (dir >= 0 ? 1 : -1) + n) % n;
        return g.members.get(1 + j).index;
    }
}
