package com.zue.attackeditor;

/**
 * Criterios do "Remover Sprites repetidas": cada um pode ser ligado/desligado e ter a sua tolerancia. A "Semelhanca minima" (barra) e a nota das celulas 32 x 32
 * e fica fora daqui. Java puro; so le as metricas que {@link SpriteVerify} deixou no {@link SpriteDedup.Match}.
 */
final class DedupOptions {
    static final class Crit {
        final String id;
        final boolean defOn, hasValue;
        final int defVal, min, max;
        boolean on;
        int value;
        Crit(String id, boolean defOn, int defVal, int min, int max, boolean hasValue) {
            this.id = id; this.defOn = defOn; this.defVal = defVal; this.min = min; this.max = max; this.hasValue = hasValue;
            reset();
        }
        void reset() { on = defOn; value = defVal; }
        void set(int v) { value = Math.max(min, Math.min(max, v)); }
    }

    /** Forma: IoU da silhueta (%). */
    final Crit shape = new Crit("shape", true, 96, 50, 100, true);
    /** Cor dos pixels opacos nos dois (%). */
    final Crit color = new Crit("color", true, 95, 50, 100, true);
    /** Detalhes internos / bordas (%). */
    final Crit detail = new Crit("detail", true, 65, 0, 100, true);
    /** Paleta de cores (%). */
    final Crit palette = new Crit("palette", true, 70, 30, 100, true);
    /** Achatamento maximo, em decimos (40 = 4,0x). */
    final Crit stretch = new Crit("stretch", true, 40, 10, 80, true);
    /** Ampliacao maxima da que fica (%; 100 = nunca amplia). */
    final Crit enlarge = new Crit("enlarge", false, 125, 100, 400, true);
    final Crit mirror = new Crit("mirror", true, 0, 0, 0, false);
    final Crit turn90 = new Crit("turn90", true, 0, 0, 0, false);
    /** Giro em angulo qualquer; o valor e a nota minima (%) das celulas. */
    final Crit anyAngle = new Crit("angle", true, 80, 50, 99, true);
    /** Cadeia A~B, B~C: o membro so precisa casar com algum membro do grupo (nao com a maior). */
    final Crit chain = new Crit("chain", false, 0, 0, 0, false);

    Crit[] all() { return new Crit[]{shape, color, detail, palette, stretch, enlarge, mirror, turn90, anyAngle, chain}; }

    void reset() { for (Crit c : all()) c.reset(); }

    DedupOptions copy() {
        DedupOptions o = new DedupOptions();
        Crit[] a = all(), b = o.all();
        for (int i = 0; i < a.length; i++) { b[i].on = a[i].on; b[i].value = a[i].value; }
        return o;
    }

    boolean isDefault() {
        for (Crit c : all()) if (c.on != c.defOn || c.value != c.defVal) return false;
        return true;
    }

    /** Como era antes da 3.1zzzh (sem a conferencia em pixels; cadeia ligada; achatamento ate 8x). */
    static DedupOptions legacy() {
        DedupOptions o = new DedupOptions();
        o.chain.on = true;
        o.stretch.value = 80;
        return o;
    }

    /** A relacao {@code g} (0..7) espelha? (determinante da parte linear negativo) */
    static boolean mirrored(int g) {
        double[] t = SpriteXform.G[g];
        return t[0] * t[3] - t[1] * t[2] < 0;
    }

    /** Este par passa em todos os criterios ligados (alem da nota minima das celulas {@code minPct})? */
    boolean accepts(SpriteDedup.Match m, int minPct) {
        if (m == null || m.score < minPct) return false;
        if (m.g < 0) {
            if (!anyAngle.on || m.score < anyAngle.value) return false;
            if (m.mirror && !mirror.on) return false;
        } else {
            if (mirrored(m.g) && !mirror.on) return false;
            if (m.g >= 3 && !turn90.on) return false;
        }
        double st = Math.max(m.sx / m.sy, m.sy / m.sx);
        if (stretch.on && st > stretch.value / 10.0 + 1e-9) return false;
        if (enlarge.on && m.up > enlarge.value + 1e-9) return false;
        if (m.verified) {
            if (shape.on && m.iou < shape.value) return false;
            if (color.on && m.color < color.value) return false;
            if (detail.on && m.detail < detail.value) return false;
            if (palette.on && m.palette < palette.value) return false;
        }
        return true;
    }
}
