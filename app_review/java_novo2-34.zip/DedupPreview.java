package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

/** VER ANOS: quais ANOs usam as sprites de um grupo e como cada uma ficaria depois da troca (cópia do DAC; o real nao muda). Java puro. */
final class DedupPreview {
    private DedupPreview() { }

    /** ANOs (em ordem) que usam alguma das sprites. */
    static List<Integer> affected(Dac dac, Collection<Integer> sprites) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        for (Integer sp : sprites) for (int[] row : SpriteUses.find(dac, sp.intValue())) out.add(Integer.valueOf(row[0]));
        return new ArrayList<Integer>(out);
    }

    /** Linha "Ano N · SPR_a, SPR_b (Frames 1, 4)": as sprites do grupo que a ANO usa. */
    static String line(Dac dac, int ano, Collection<Integer> sprites) {
        Ano a = dac.getAno(ano);
        StringBuilder sp = new StringBuilder();
        StringBuilder fr = new StringBuilder();
        TreeSet<Integer> used = new TreeSet<Integer>();
        if (a != null) for (int f = 0; f < a.mpts.length; f++) {
            Integer img = Integer.valueOf(a.mpts[f].image);
            if (sprites.contains(img)) { used.add(img); if (fr.length() > 0) fr.append(", "); fr.append(f + 1); }
        }
        for (Integer u : used) { if (sp.length() > 0) sp.append(", "); sp.append("SPR_").append(u); }
        return "Ano " + ano + " · " + sp + " (Frames " + fr + ")";
    }

    static final class Result {
        Dac dac;                                         // copia com as ANOs reescritas
        final TreeSet<Integer> changedAnos = new TreeSet<Integer>();
        final List<Integer> skipped = new ArrayList<Integer>();       // sprites que nao dariam para trocar (algum frame sem solucao)
    }

    /**
     * Copia do DAC como ficaria depois de trocar as sprites das {@code choices}: as ANOs que usam alguma sprite removida ganham copias dos frames e o mesmo
     * {@link SpriteDedup#apply} (inclusive a regra de ANO filha de link e "tudo ou nada" por sprite) roda sobre a copia. {@code dac} nao e alterado.
     */
    static Result preview(Dac dac, List<SpriteDedup.Choice> choices) {
        Result r = new Result();
        List<Integer> removed = new ArrayList<Integer>();
        for (SpriteDedup.Choice c : choices) removed.add(Integer.valueOf(c.removed.index));
        Dac copy = dac;
        for (Integer i : affected(dac, removed)) {
            Ano a = dac.getAno(i.intValue());
            Ano.Mpt[] m = new Ano.Mpt[a.mpts.length];
            for (int k = 0; k < m.length; k++) m[k] = a.mpts[k].copy();
            copy = copy.copyWith(i.intValue(), new Ano(a.index, a.present, a.flags, a.priority, a.links, m));
        }
        SpriteDedup.Result res = SpriteDedup.apply(copy, choices);
        r.dac = copy;
        r.changedAnos.addAll(res.changedAnos);
        r.skipped.addAll(res.skipped);
        return r;
    }
}
