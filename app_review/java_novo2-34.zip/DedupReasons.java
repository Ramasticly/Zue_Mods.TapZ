package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

/** Por que sprites marcadas para sair NAO sairam (tela pos-remocao), em termos simples. Java puro. */
final class DedupReasons {
    private DedupReasons() { }

    /** Nenhuma sprite do grupo serve no lugar dela com os criterios atuais. */
    static final int NO_REPLACEMENT = 10;

    static final class Entry {
        int oldSprite, newSprite;       // numero antes e depois da renumeracao
        int code;                       // SpriteXform.WHY_* ou NO_REPLACEMENT
        int ano, frame;                 // onde deu errado (0 = nao se aplica)
        boolean hasWhere() { return ano >= 0 && frame > 0; }
    }

    /** Frase fixa que abre a explicacao. */
    static final String GENERAL = "Uma sprite só sai se TODOS os Frames que a usam puderem ser refeitos com a que fica; se um só não der, ela inteira é mantida para nada mudar de lugar.";

    /**
     * As marcadas que ficaram: com o motivo do {@link SpriteDedup#apply} ou {@link #NO_REPLACEMENT} quando nao havia substituta.
     * {@code map}: antigo -> novo depois de remover as que sairam (null = sem renumeracao).
     */
    static List<Entry> notRemoved(Collection<Integer> marked, SpriteDedup.Result res, int[] map) {
        List<Entry> out = new ArrayList<Entry>();
        for (Integer old : new TreeSet<Integer>(marked)) {
            if (res.removedSprites.contains(old)) continue;
            Entry e = new Entry();
            e.oldSprite = old.intValue();
            e.newSprite = map != null && e.oldSprite >= 0 && e.oldSprite < map.length && map[e.oldSprite] >= 0 ? map[e.oldSprite] : e.oldSprite;
            SpriteDedup.Reason r = res.reasons.get(old);
            if (r == null) { e.code = NO_REPLACEMENT; e.ano = -1; e.frame = 0; }
            else { e.code = r.code; e.ano = r.ano; e.frame = r.frame; }
            out.add(e);
        }
        java.util.Collections.sort(out, new java.util.Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) { return a.newSprite - b.newSprite; }
        });
        return out;
    }

    /** "SPR_3", "SPR_3 e 7", "SPR_3, 7 e 9", "SPR_3, 7, 9 e 12" (numeros ja em ordem). */
    static String names(List<Integer> sprites) {
        StringBuilder b = new StringBuilder();
        int n = sprites.size();
        for (int i = 0; i < n; i++) {
            if (i == 0) b.append("SPR_");
            else b.append(i == n - 1 ? " e " : ", ");
            b.append(sprites.get(i));
        }
        return b.toString();
    }

    static List<Integer> newNumbers(List<Entry> es) {
        List<Integer> l = new ArrayList<Integer>();
        for (Entry e : es) l.add(Integer.valueOf(e.newSprite));
        return l;
    }

    /** Frase simples do motivo (sem numeros: a tela acrescenta a sprite e o "Onde"). */
    static String body(int code) {
        switch (code) {
            case SpriteXform.WHY_FLIP:
                return "Ela aparece numa ANO que é usada como link de outra. O jogo espelha o deslocamento do link junto com a imagem, então não dá para trocar a imagem espelhando sem mover a peça.";
            case SpriteXform.WHY_ORTHO:
                return "Num Frame a imagem está esticada só num lado e girada ao mesmo tempo. O jogo estica antes de girar e não consegue desenhar a sprite que fica desse jeito.";
            case SpriteXform.WHY_ZOOM:
                return "O zoom necessário passa do que o DAC consegue guardar.";
            case SpriteXform.WHY_ERROR:
                return "O DAC só guarda números inteiros (zoom em %, rotação em graus) e, nesse Frame, arredondar deixaria a sprite mais de 2 px fora do lugar.";
            case NO_REPLACEMENT:
                return "Não sobrou nenhuma sprite do grupo que sirva no lugar dela com os critérios atuais (por exemplo, a que serviria também foi marcada para sair).";
            default:
                return "Um Frame tem tamanho zero e por isso não dá para calcular a troca.";
        }
    }

    /** Texto completo em portugues (a tela monta o mesmo texto traduzindo cada parte). */
    static String explain(Entry e) {
        StringBuilder b = new StringBuilder("SPR_").append(e.newSprite);
        if (e.oldSprite != e.newSprite) b.append(" (antes SPR_").append(e.oldSprite).append(')');
        b.append(": ").append(body(e.code));
        if (e.hasWhere()) b.append(" Onde: ANO ").append(e.ano).append(", Frame ").append(e.frame).append('.');
        return b.toString();
    }
}
