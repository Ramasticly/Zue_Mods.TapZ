package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tela de "Remover Sprites repetidas": grupos com MARCAR TUDO e COMPARAR, barra de semelhanca, OPCOES (criterios), CANCELAR e REMOVER MARCADAS com confirmacao.
 * A logica (grupos, marcas, criterios) esta em {@link DedupAnalysis}, {@link DedupMarks} e {@link DedupOptions} (testadas sem Android); aqui so a tela.
 */
final class DedupScreen {
    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, WARN = 0xFFFFB454, RED = 0xFFFF6B6B;
    private static final int RED_BG = 0xFF4A1F24, GREEN_BG = 0xFF1F4A2B, ROW_MARKED = 0xFF3A1F24;

    private final Activity a;
    private final CharAssets ca;
    private final SpriteLib lib;
    private final List<SpriteDedup.Sig> sigs;
    private final DedupAnalysis an;
    private final Runnable applied;
    private final DedupOptions opt = new DedupOptions();
    private final int[] minPct = {90};
    private List<SpriteDedup.Group> groups = new ArrayList<SpriteDedup.Group>();
    private DedupMarks marks = new DedupMarks(groups);
    private final Map<Integer, LinearLayout> rows = new HashMap<Integer, LinearLayout>();
    private final Map<Integer, TextView> chips = new HashMap<Integer, TextView>();
    private final Map<Integer, SpriteDedup.Group> groupOf = new HashMap<Integer, SpriteDedup.Group>();
    private final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
    private ScrollView scroll;
    private int token;
    private Dialog dialog;
    private TextView tol, sum, ok;
    private SeekBar sb;
    private LinearLayout list;

    private DedupScreen(Activity a, CharAssets ca, SpriteLib lib, List<SpriteDedup.Sig> sigs, DedupAnalysis an, Runnable applied) {
        this.a = a; this.ca = ca; this.lib = lib; this.sigs = sigs; this.an = an; this.applied = applied;
    }

    static void show(Activity a, CharAssets ca, SpriteLib lib, List<SpriteDedup.Sig> sigs, DedupAnalysis an, Runnable applied) {
        new DedupScreen(a, ca, lib, sigs, an, applied).build();
    }

    private int dp(int v) { return SpriteListScreen.dp(a, v); }

    /** Botao colorido (mesmo formato do SpriteListScreen.button). */
    private TextView colored(String s, int fill, int stroke, int textColor, View.OnClickListener c) {
        TextView t = SpriteListScreen.button(a, s, c);
        t.setTextColor(textColor);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(1), stroke);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        return t;
    }

    // ---- tela principal ----

    private void build() {
        dialog = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(12), 0, 0);
        dialog.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Remover Sprites repetidas", 16, TEXT, true);
        ti.setPadding(dp(14), 0, dp(14), dp(2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Sprites iguais ou parecidas formam um grupo: também as espelhadas, giradas (90° ou qualquer ângulo, aproximado ~), em outra escala ou achatadas "
                + "(zoom X diferente de Y). Marque as que quer REMOVER: os frames do DAC passam a usar a que fica, com Flip, zoom, rotação e posição ajustados para o desenho ficar igual. "
                + "Em cada grupo precisa ficar ao menos uma.", 11, DIM, false);
        hint.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(hint);
        LinearLayout tolRow = new LinearLayout(a);
        tolRow.setOrientation(LinearLayout.HORIZONTAL);
        tolRow.setGravity(Gravity.CENTER_VERTICAL);
        tolRow.setPadding(dp(14), 0, dp(14), 0);
        tol = SpriteListScreen.text(a, "", 14, ACCENT, true);
        tolRow.addView(tol, new LinearLayout.LayoutParams(0, -2, 1f));
        tolRow.addView(SpriteListScreen.button(a, "OPÇÕES", new View.OnClickListener() { @Override public void onClick(View v) { options(); } }));
        root.addView(tolRow);
        sb = new SeekBar(a);
        sb.setMax(50);
        sb.setProgress(40);
        sb.setPadding(dp(18), dp(6), dp(18), dp(6));
        root.addView(sb);
        sum = SpriteListScreen.text(a, "", 12, TEXT, false);
        sum.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(sum);
        list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll = new ScrollView(a);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { tol.setText("Semelhança mínima: " + (50 + p) + "%"); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { rebuild(); }
        });
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(12), dp(8), dp(12), dp(12));
        foot.addView(colored("CANCELAR", RED_BG, RED, RED, new View.OnClickListener() { @Override public void onClick(View v) { dialog.dismiss(); } }));
        ok = colored("REMOVER MARCADAS", GREEN_BG, OK, OK, new View.OnClickListener() { @Override public void onClick(View v) { confirm(); } });
        foot.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        dialog.show();
        rebuild();
    }

    /** Refaz os grupos (so filtra a tabela; fora da tela por precaucao) e a lista. */
    private void rebuild() {
        minPct[0] = 50 + sb.getProgress();
        tol.setText("Semelhança mínima: " + minPct[0] + "%" + (minPct[0] == 100 ? "  (só idênticas)" : ""));
        sum.setText("Comparando sprites...");
        ok.setEnabled(false);
        ok.setAlpha(0.4f);
        final int pct = minPct[0], mine = ++token;
        final DedupOptions o = opt.copy();
        new Thread(new Runnable() {
            @Override public void run() {
                final List<SpriteDedup.Group> gs = an.groups(sigs, pct, o);
                a.runOnUiThread(new Runnable() { @Override public void run() { if (mine == token) populate(gs); } });
            }
        }).start();
    }

    private void populate(List<SpriteDedup.Group> gs) {
        groups = gs;
        marks = new DedupMarks(groups);
        rows.clear();
        chips.clear();
        groupOf.clear();
        list.removeAllViews();
        int gi = 0;
        for (final SpriteDedup.Group g : groups) {
            gi++;
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(8), dp(12), dp(8));
            card.setBackgroundColor(CARD);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
            clp.setMargins(dp(8), dp(4), dp(8), dp(4));
            card.addView(SpriteListScreen.text(a, "Grupo " + gi + " · SPR_" + g.rep() + " (a maior)", 13, ACCENT, true));
            for (final SpriteDedup.Member m : g.members) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(4), dp(4), dp(4), dp(4));
                row.addView(thumb(m.index), new LinearLayout.LayoutParams(dp(56), dp(56)));
                SpriteDedup.Sig sg = an.byIndex.get(Integer.valueOf(m.index));
                TextView t = new I18nTextView(a);
                t.setTextSize(12);
                t.setTextColor(m.toRep == null ? OK : TEXT);
                t.setPadding(dp(10), 0, dp(6), 0);
                t.setText("SPR_" + m.index + "  (" + (sg == null ? 0 : sg.w) + "×" + (sg == null ? 0 : sg.h) + ")\n"
                        + (m.toRep == null ? "a maior do grupo" : relation(m.toRep) + " · " + m.toRep.score + "%" + (m.toRep.approx ? "~" : "") + zoomNote(m.toRep) + metricsNote(m.toRep)));
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                groupOf.put(Integer.valueOf(m.index), g);
                TextView chip = SpriteListScreen.text(a, "MANTER", 11, OK, true);
                chip.setPadding(dp(8), dp(4), dp(8), dp(4));
                chips.put(Integer.valueOf(m.index), chip);
                row.addView(chip);
                if (marks.canCompare(g, m.index)) {
                    row.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { compare(g, m.index); } });
                }
                rows.put(Integer.valueOf(m.index), row);
                paintRow(m.index);
                card.addView(row);
            }
            list.addView(card, clp);
        }
        counts();
    }

    /** Fundo e selo da linha conforme a marca: marcada = avermelhada + REMOVER; as outras = MANTER. */
    private void paintRow(int sprite) {
        LinearLayout row = rows.get(Integer.valueOf(sprite));
        if (row == null) return;
        boolean rem = marks.isMarked(sprite);
        row.setBackgroundColor(rem ? ROW_MARKED : CARD);
        TextView chip = chips.get(Integer.valueOf(sprite));
        SpriteDedup.Group g = groupOf.get(Integer.valueOf(sprite));
        if (chip != null && g != null) {
            chip.setText(marks.chip(g, sprite));        // a maior: MANTER (FIXA)
            chip.setTextColor(rem ? RED : OK);
        }
    }

    /** Destaque rapido na linha comparada (aparece e some em ~0,9 s) e rolagem ate ela. */
    private void flash(int sprite) {
        final LinearLayout row = rows.get(Integer.valueOf(sprite));
        if (row == null) return;
        paintRow(sprite);
        final int base = marks.isMarked(sprite) ? ROW_MARKED : CARD;
        android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(900);
        va.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(android.animation.ValueAnimator an) {
                float k = (float) Math.sin(Math.PI * (Float) an.getAnimatedValue()) * 0.75f;      // sobe e desce
                row.setBackgroundColor(blend(base, ACCENT, k));
            }
        });
        va.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) { row.setBackgroundColor(base); }
        });
        va.start();
        scroll.post(new Runnable() {
            @Override public void run() {
                View card = (View) row.getParent();
                scroll.smoothScrollTo(0, Math.max(0, card.getTop() + row.getTop() - dp(120)));
            }
        });
    }

    private static int blend(int from, int to, float k) {
        int r = (int) (((from >> 16) & 255) * (1 - k) + ((to >> 16) & 255) * k), g = (int) (((from >> 8) & 255) * (1 - k) + ((to >> 8) & 255) * k), b = (int) ((from & 255) * (1 - k) + (to & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void counts() {
        int n = marks.totalMarked();
        String warn = an.complete ? "" : "  ⚠ análise incompleta (" + an.unverified + " par(es) sem conferência)";
        sum.setText((groups.isEmpty() ? "Nenhum grupo de sprites repetidas com esta semelhança." : groups.size() + " grupo(s); " + n + " sprite(s) marcada(s) para remover de " + sigs.size() + ".") + warn);
        ok.setEnabled(n > 0);
        ok.setAlpha(n > 0 ? 1f : 0.4f);
    }

    private static String relation(SpriteDedup.Match m) {
        if (m.g < 0) return "girada " + Math.round(m.rotDeg) + "°" + (m.mirror ? " e espelhada" : "") + " (aproximado)";
        switch (m.g) {
            case 0: return "igual (ou só em outra escala)";
            case 1: return "espelhada na horizontal (Flip X)";
            case 2: return "espelhada na vertical (Flip Y)";
            case 3: return "girada 180°";
            default: return "girada 90° (ou espelhada na diagonal)";
        }
    }

    /** Linha extra com o zoom que a sprite que fica vai ter (quando a escala ou o achatamento mudam). */
    private static String zoomNote(SpriteDedup.Match m) {
        long zx = Math.round(100 / m.sx), zy = Math.round(100 / m.sy);
        String t = "";
        if (Math.abs(zx - 100) > 2 || Math.abs(zy - 100) > 2) {
            t = Math.abs(zx - zy) > 2 ? "\nzoom " + zx + "% × " + zy + "% (achatada)" : "\nzoom " + zx + "%";
            if (m.up > 105) t += " — amplia, perde qualidade";
        }
        return t;
    }

    private static String metricsNote(SpriteDedup.Match m) {
        if (!m.verified) return "";
        return "\nforma " + Math.round(m.iou) + "% · cor " + Math.round(m.color) + "% · detalhes " + Math.round(m.detail) + "%";
    }

    private ImageView thumb(int idx) {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        Bitmap tb = thumbs.get(Integer.valueOf(idx));
        if (tb == null) {
            Bitmap full = lib.cut(idx);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(idx), tb);
            }
        }
        if (tb != null) iv.setImageBitmap(tb);
        return iv;
    }

    // ---- remover ----

    private void confirm() {
        final int n = marks.totalMarked(), gn = marks.groupsWithMarks();
        if (n == 0) return;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover sprites repetidas")
                .setMessage("Remover " + n + " sprite(s) de " + gn + " grupo(s)? Os Frames do DAC serão reescritos para usar a que fica, e as sprites seguintes serão renumeradas. "
                        + "Antes é feita uma cópia bruta do personagem inteiro (DAC, CNV, Bin, áudios, PNGs e GIFs) em Backups/PreOptim/, que ocupa o mesmo espaço do personagem.")
                .setNegativeButton("VOLTAR", null)
                .setPositiveButton("SIM, REMOVER", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { dialog.dismiss(); apply(); }
                }).show();
    }

    /** Trocas que valem para as marcas atuais (mais {@code extra}, se >= 0, tratada como removida): para cada marcada, a melhor das que ficam no grupo. */
    private List<SpriteDedup.Choice> buildChoices(int extra, DedupOptions o, int pct) {
        List<SpriteDedup.Choice> choices = new ArrayList<SpriteDedup.Choice>();
        for (SpriteDedup.Group g : groups) {
            List<SpriteDedup.Sig> kept = new ArrayList<SpriteDedup.Sig>();
            for (SpriteDedup.Member m : g.members) if (!marks.isMarked(m.index) && m.index != extra) kept.add(an.byIndex.get(Integer.valueOf(m.index)));
            for (SpriteDedup.Member m : g.members) {
                if (!marks.isMarked(m.index) && m.index != extra) continue;
                SpriteDedup.Choice c = an.choose(an.byIndex.get(Integer.valueOf(m.index)), kept, pct, o);
                if (c != null) choices.add(c);
            }
        }
        return choices;
    }

    private void apply() {
        final BusyDialog busy = BusyDialog.show(a, "Removendo sprites repetidas");
        busy.set("Reescrevendo os frames...", 0, 0);
        final DedupOptions o = opt.copy();
        final int pct = minPct[0];
        final java.util.Set<Integer> markedBefore = new java.util.HashSet<Integer>(marks.removed);
        final List<DedupReasons.Entry> notRemoved = new ArrayList<DedupReasons.Entry>();
        new Thread(new Runnable() {
            @Override public void run() {
                String out;
                try {
                    // copia bruta do personagem inteiro antes de mexer em qualquer coisa
                    File bk = PreOptimBackup.run(ca.dir, new java.util.Date(), new Saver.CopyProgress() {
                        @Override public void on(String file, int d, int total) { busy.set("Copiando o personagem\n" + file, d, total); }
                    });
                    List<SpriteDedup.Choice> choices = buildChoices(-1, o, pct);
                    SpriteDedup.Result res = SpriteDedup.apply(ca.dac, choices);
                    java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>(res.changedAnos);
                    int[] map = null;
                    if (!res.removedSprites.isEmpty()) {
                        map = lib.removeShift(res.removedSprites);
                        changed.addAll(SpriteRenumber.remapDac(ca.dac, map));
                    }
                    notRemoved.addAll(DedupReasons.notRemoved(markedBefore, res, map));
                    String saved = SpriteMassDialogs.persist(ca, changed);
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(res.removedSprites.size()).append(" sprite(s) removida(s); ").append(res.framesRewritten).append(" frame(s) reescrito(s) em ").append(res.changedAnos.size()).append(" ANO(s).\n");
                    sb2.append("As sprites seguintes foram renumeradas.\n");
                    sb2.append("\nCópia bruta do personagem: ").append(bk.getPath()).append(saved.isEmpty() ? "" : "\n" + SpriteMassDialogs.lastPersist);
                    out = sb2.toString();
                } catch (Throwable t) {
                    out = "Erro ao remover sprites repetidas: " + t;
                }
                busy.dismiss();
                final String text = out;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        applied.run();
                        LinearLayout body = new LinearLayout(a);
                        body.setOrientation(LinearLayout.VERTICAL);
                        body.setPadding(dp(16), dp(8), dp(16), dp(8));
                        body.addView(SpriteListScreen.text(a, text, 13, TEXT, false));
                        if (!notRemoved.isEmpty()) body.addView(keptLine(notRemoved));
                        ScrollView s = new ScrollView(a);
                        s.addView(body);
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Sprites repetidas").setView(s).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }

    /** "Foram mantidas: SPR_3, 7 e 12 (Ver motivo.)" com o "Ver motivo." azul e clicavel; o motivo (simples) so aparece ao tocar. */
    private View keptLine(final List<DedupReasons.Entry> es) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(10), 0, 0);
        final TextView line = new TextView(a);          // comum (nao I18nTextView): o texto tem span e as partes ja saem traduzidas
        line.setTextSize(13);
        line.setTextColor(TEXT);
        line.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
        final TextView why = new TextView(a);
        why.setTextSize(12);
        why.setTextColor(DIM);
        why.setPadding(0, dp(6), 0, 0);
        why.setVisibility(View.GONE);
        StringBuilder wt = new StringBuilder(I18n.tr(DedupReasons.GENERAL));
        for (DedupReasons.Entry e : es) {
            wt.append("\n\nSPR_").append(e.newSprite);
            if (e.oldSprite != e.newSprite) wt.append(" (").append(I18n.tr("antes")).append(" SPR_").append(e.oldSprite).append(')');
            wt.append(": ").append(I18n.tr(DedupReasons.body(e.code)));
            if (e.hasWhere()) wt.append(' ').append(I18n.tr("Onde:")).append(' ').append("ANO ").append(e.ano).append(", Frame ").append(e.frame).append('.');
        }
        why.setText(wt.toString());
        final String names = DedupReasons.names(DedupReasons.newNumbers(es));
        final Runnable[] paint = new Runnable[1];
        paint[0] = new Runnable() {
            @Override public void run() {
                boolean open = why.getVisibility() == View.VISIBLE;
                android.text.SpannableStringBuilder sbd = new android.text.SpannableStringBuilder(I18n.tr("Foram mantidas:") + " " + names + " (");
                String link = I18n.tr(open ? "Ocultar motivo." : "Ver motivo.");
                int st = sbd.length();
                sbd.append(link);
                sbd.setSpan(new android.text.style.ClickableSpan() {
                    @Override public void onClick(View v) { why.setVisibility(why.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE); paint[0].run(); }
                    @Override public void updateDrawState(android.text.TextPaint ds) { ds.setColor(ACCENT); ds.setUnderlineText(true); }
                }, st, st + link.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sbd.append(")");
                line.setText(sbd);
            }
        };
        paint[0].run();
        box.addView(line);
        box.addView(why);
        return box;
    }

    // ---- comparar ----

    private int cmpToken;

    /**
     * Comparacao: UMA sprite (area 1:1) que alterna a que fica (desenhada com os ajustes de zoom/rotacao/flip para parecer a comparada) e a comparada,
     * como dois Frames de uma animacao (400 ms, em laco). Chave MANTER/REMOVER no canto inferior direito; PLAY/PAUSE, VER ANOS e CANCELAR embaixo.
     */
    private void compare(final SpriteDedup.Group g, final int rIdx) {
        final SpriteDedup.Sig r = an.byIndex.get(Integer.valueOf(rIdx));
        List<SpriteDedup.Sig> kept = new ArrayList<SpriteDedup.Sig>();
        for (SpriteDedup.Member m : g.members) if (m.index != rIdx && !marks.isMarked(m.index)) kept.add(an.byIndex.get(Integer.valueOf(m.index)));
        final SpriteDedup.Choice c = r == null ? null : an.choose(r, kept, minPct[0], opt);
        if (c == null) { SpriteListScreen.toast(a, "Nenhuma outra sprite do grupo fica no lugar desta para comparar"); return; }
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), dp(10));
        d.setContentView(root);
        TextView title = SpriteListScreen.text(a, "Comparar SPR_" + rIdx + " com SPR_" + c.kept.index, 15, TEXT, true);
        title.setPadding(dp(2), 0, dp(2), dp(6));
        root.addView(title);
        android.util.DisplayMetrics dm = a.getResources().getDisplayMetrics();
        int side = Math.min(dm.widthPixels - dp(24), Math.round(dm.heightPixels * 0.5f));
        FrameLayout box = new FrameLayout(a);
        box.setBackgroundColor(0xFF0D0F13);
        final ImageView img = new ImageView(a);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        box.addView(img, new FrameLayout.LayoutParams(-1, -1));
        final int[] frameMs = {DedupCompare.DEFAULT_MS};
        final TextView durChip = SpriteListScreen.text(a, frameMs[0] + " ms", 11, TEXT, true);
        durChip.setPadding(dp(8), dp(4), dp(8), dp(4));
        durChip.setBackgroundColor(0xAA14171C);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        dlp.setMargins(dp(6), dp(6), dp(6), dp(6));
        box.addView(durChip, dlp);
        final boolean[] remove = {marks.isMarked(rIdx)};
        final TextView sw = SpriteListScreen.button(a, "", null);
        sw.setTextSize(15);
        sw.setPadding(dp(18), dp(12), dp(18), dp(12));
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        slp.setMargins(dp(8), dp(8), dp(8), dp(8));
        box.addView(sw, slp);
        root.addView(box, new LinearLayout.LayoutParams(side, side));
        final TextView cap = SpriteListScreen.text(a, "", 18, TEXT, true);
        cap.setPadding(dp(2), dp(8), dp(2), dp(2));
        root.addView(cap);
        final SpriteDedup.Match mt = c.match;
        TextView info = SpriteListScreen.text(a, relation(mt) + " · " + mt.score + "%" + (mt.approx ? "~" : "") + zoomNote(mt).replace('\n', ' ') + metricsNote(mt).replace('\n', ' '), 11, DIM, false);
        info.setPadding(dp(2), 0, dp(2), dp(6));
        root.addView(info);
        final Handler h = new Handler();
        final int[] phase = {0};
        final boolean[] playing = {true};
        final Bitmap[] bm = new Bitmap[2];
        final Runnable show = new Runnable() {
            @Override public void run() {
                if (bm[phase[0]] != null) img.setImageBitmap(bm[phase[0]]);
                cap.setText(DedupCompare.caption(phase[0], c.kept.index, rIdx, remove[0]));
                cap.setTextColor(phase[0] == 0 ? OK : (remove[0] ? RED : OK));
            }
        };
        final Runnable[] tick = new Runnable[1];
        tick[0] = new Runnable() {
            @Override public void run() {
                if (!playing[0]) return;
                phase[0] = 1 - phase[0];
                show.run();
                h.postDelayed(tick[0], frameMs[0]);
            }
        };
        final Runnable paintSwitch = new Runnable() {
            @Override public void run() {
                GradientDrawable gd = new GradientDrawable();
                // o botao mostra a ACAO ao tocar (sprite marcada -> MANTER, verde; nao marcada -> REMOVER, vermelho); o selo do grupo mostra o estado
                boolean toRemove = !remove[0];
                gd.setColor(toRemove ? RED_BG : GREEN_BG);
                gd.setStroke(dp(2), toRemove ? RED : OK);
                gd.setCornerRadius(dp(10));
                sw.setBackground(gd);
                sw.setText(DedupCompare.actionLabel(remove[0]));
                sw.setTextColor(toRemove ? RED : OK);
                show.run();
            }
        };
        paintSwitch.run();
        durChip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { frameMs[0] = DedupCompare.nextDuration(frameMs[0]); durChip.setText(frameMs[0] + " ms"); }
        });
        img.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (!playing[0]) { phase[0] = 1 - phase[0]; show.run(); } }       // pausado: um toque alterna o quadro
        });
        sw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean now = DedupCompare.toggled(remove[0]);
                if (!marks.set(g, rIdx, now)) { SpriteListScreen.toast(a, "Precisa ficar ao menos uma sprite em cada grupo"); return; }
                remove[0] = now;
                paintSwitch.run();
                d.dismiss();
                counts();
                flash(rIdx);
            }
        });
        final TextView play = SpriteListScreen.button(a, "PAUSAR", null);
        play.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                playing[0] = !playing[0];
                play.setText(playing[0] ? "PAUSAR" : "TOCAR");
                h.removeCallbacks(tick[0]);
                if (playing[0]) h.postDelayed(tick[0], frameMs[0]);
            }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.setMargins(0, dp(6), 0, 0);
        root.addView(play, blp);
        root.addView(SpriteListScreen.button(a, "VER ANOS", new View.OnClickListener() { @Override public void onClick(View v) { anos(g, rIdx); } }), blp);
        root.addView(colored("CANCELAR", RED_BG, RED, RED, new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); flash(rIdx); }
        }), blp);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) { playing[0] = false; h.removeCallbacks(tick[0]); }
        });
        d.show();
        final int mine = ++cmpToken;
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap rb = lib.cut(rIdx), kb = lib.cut(c.kept.index);
                if (rb == null || kb == null) return;
                int[] kpx = new int[kb.getWidth() * kb.getHeight()];
                kb.getPixels(kpx, 0, kb.getWidth(), 0, 0, kb.getWidth(), kb.getHeight());
                double[] gen = SpriteVerify.quantized(mt.map(), c.removed.w, c.removed.h, c.kept.w, c.kept.h);      // o que o DAC vai desenhar
                if (gen == null) gen = mt.map();
                int[] shown = SpriteVerify.renderRect(kpx, kb.getWidth(), kb.getHeight(), gen, rb.getWidth(), rb.getHeight());
                final Bitmap lb = Bitmap.createBitmap(shown, rb.getWidth(), rb.getHeight(), Bitmap.Config.ARGB_8888);
                final Bitmap rr = rb;
                kb.recycle();
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (mine != cmpToken) return;
                        bm[0] = lb; bm[1] = rr;
                        show.run();
                        h.removeCallbacks(tick[0]);
                        if (playing[0]) h.postDelayed(tick[0], frameMs[0]);
                    }
                });
            }
        }).start();
    }

    // ---- ver anos ----

    /** Lista as ANOs que usam as sprites do grupo; tocar numa abre a previa (ANTES/DEPOIS) como ficaria se {@code rIdx} fosse removida (alem das marcas atuais). */
    private void anos(final SpriteDedup.Group g, final int rIdx) {
        final List<Integer> sprites = new ArrayList<Integer>();
        for (SpriteDedup.Member m : g.members) sprites.add(Integer.valueOf(m.index));
        final List<SpriteDedup.Choice> choices = buildChoices(rIdx, opt, minPct[0]);
        final DedupPreview.Result pr = DedupPreview.preview(ca.dac, choices);
        final List<Integer> list2 = DedupPreview.affected(ca.dac, sprites);
        if (list2.isEmpty()) { SpriteListScreen.toast(a, "Nenhuma ANO usa as sprites deste grupo"); return; }
        LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(8), dp(4), dp(8), dp(4));
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        for (final Integer ano : list2) {
            boolean changes = pr.changedAnos.contains(ano);
            TextView row = SpriteListScreen.text(a, DedupPreview.line(ca.dac, ano.intValue(), sprites) + (changes ? "  · muda" : ""), 13, changes ? TEXT : DIM, false);
            row.setPadding(dp(10), dp(10), dp(10), dp(10));
            row.setBackgroundColor(CARD);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
            rlp.setMargins(0, dp(3), 0, dp(3));
            row.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { previewAno(ano.intValue(), pr.dac); } });
            body.addView(row, rlp);
        }
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), dp(10));
        d.setContentView(root);
        TextView t = SpriteListScreen.text(a, "ANOs que usam as sprites do grupo", 15, TEXT, true);
        t.setPadding(dp(2), 0, dp(2), dp(2));
        root.addView(t);
        TextView hint = SpriteListScreen.text(a, "Toque numa ANO para ver como ela fica depois da troca (considerando as marcas atuais e esta sprite como removida).", 11, DIM, false);
        hint.setPadding(dp(2), 0, dp(2), dp(6));
        root.addView(hint);
        ScrollView sv = new ScrollView(a);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(SpriteListScreen.button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        d.show();
    }

    /** Previa animada de uma ANO: DEPOIS (padrao) com as sprites trocadas, ou ANTES com o DAC atual. */
    private void previewAno(final int ano, final Dac after) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), dp(10));
        d.setContentView(root);
        TextView title = SpriteListScreen.text(a, "Ano " + ano, 15, TEXT, true);
        title.setPadding(dp(2), 0, dp(2), dp(6));
        root.addView(title);
        android.util.DisplayMetrics dm = a.getResources().getDisplayMetrics();
        int side = Math.min(dm.widthPixels - dp(24), Math.round(dm.heightPixels * 0.5f));
        final FrameLayout box = new FrameLayout(a);
        box.setBackgroundColor(0xFF0D0F13);
        root.addView(box, new LinearLayout.LayoutParams(side, side));
        final boolean[] showAfter = {true};
        final TextView cap = SpriteListScreen.text(a, "", 18, OK, true);
        cap.setPadding(dp(2), dp(8), dp(2), dp(2));
        final Runnable[] load = new Runnable[1];
        load[0] = new Runnable() {
            @Override public void run() {
                box.removeAllViews();
                Dac use = showAfter[0] ? after : ca.dac;
                Ano an0 = use.getAno(ano);
                if (an0 == null || !an0.present) { box.addView(SpriteListScreen.text(a, "ANO vazia", 12, DIM, false)); return; }
                AnimPreview pv = new AnimPreview(a);
                pv.set(use, ca.sprites, ano, false);
                // como na grade de ANOs: sem a flag de loop toca uma vez, segura o ultimo Frame ~1 s e recomeca; COM a flag de loop fica em laco continuo, sem pausa
                if (!ObjModel.loops(an0.mpts)) { pv.setPlayUntil(-1); pv.setAutoReplay(true); }
                box.addView(pv, new FrameLayout.LayoutParams(-1, -1));
                cap.setText(showAfter[0] ? "DEPOIS (com as sprites trocadas)" : "ANTES (como está agora)");
                cap.setTextColor(showAfter[0] ? OK : WARN);
            }
        };
        load[0].run();
        root.addView(cap);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.setMargins(0, dp(8), 0, 0);
        final TextView toggle = SpriteListScreen.button(a, "VER ANTES", null);
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showAfter[0] = !showAfter[0];
                toggle.setText(showAfter[0] ? "VER ANTES" : "VER DEPOIS");
                load[0].run();
            }
        });
        root.addView(toggle, blp);
        root.addView(SpriteListScreen.button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }), blp);
        d.show();
    }

    // ---- opcoes ----

    private static String name(String id) {
        if ("shape".equals(id)) return "Forma (silhueta)";
        if ("color".equals(id)) return "Cor dos pixels";
        if ("detail".equals(id)) return "Detalhes (bordas internas)";
        if ("palette".equals(id)) return "Paleta de cores";
        if ("stretch".equals(id)) return "Achatamento máximo";
        if ("enlarge".equals(id)) return "Ampliação máxima da que fica";
        if ("mirror".equals(id)) return "Aceitar espelhadas";
        if ("turn90".equals(id)) return "Aceitar giradas 90° / 180°";
        if ("angle".equals(id)) return "Aceitar giradas em qualquer ângulo";
        return "Agrupar em cadeia";
    }

    private static String help(String id) {
        if ("shape".equals(id)) return "Quanto do contorno coincide depois de ajustar escala, rotação e posição. Evita juntar imagens com partes a mais ou a menos.";
        if ("color".equals(id)) return "Quanto da área comum (sem a borda) tem a mesma cor. Pega regiões recoloridas.";
        if ("detail".equals(id)) return "Compara as linhas e contornos dentro da imagem.";
        if ("palette".equals(id)) return "Compara a mistura geral de cores das duas.";
        if ("stretch".equals(id)) return "Maior diferença aceita entre o zoom X e o zoom Y (4,0× = a cópia pode ficar 4 vezes mais baixa que larga).";
        if ("enlarge".equals(id)) return "Recusa quando a sprite que fica precisa ser ampliada acima disto (perde qualidade). Desligado aceita qualquer ampliação.";
        if ("mirror".equals(id)) return "Cópias com Flip X ou Flip Y.";
        if ("turn90".equals(id)) return "Cópias giradas de 90° ou 180°.";
        if ("angle".equals(id)) return "Cópias giradas em qualquer ângulo (aproximado). O valor é a nota mínima das células.";
        return "Ligado: uma sprite entra no grupo se casar com qualquer membro, mesmo sem casar com a maior (pode juntar imagens diferentes). Desligado: todas precisam casar com a maior.";
    }

    private static String valueText(DedupOptions.Crit c) {
        if ("stretch".equals(c.id)) return (c.value / 10) + "," + (c.value % 10) + "×";
        return c.value + "%";
    }

    private void options() {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Critérios de detecção", 16, TEXT, true);
        ti.setPadding(dp(14), 0, dp(14), dp(2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Cada critério pode ser ligado ou desligado e ter a sua tolerância. Uma sprite só entra no grupo se passar em todos os ligados. "
                + "A barra \"Semelhança mínima\" continua valendo para a nota geral das células.", 11, DIM, false);
        hint.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(hint);
        final LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final Runnable[] fill = new Runnable[1];
        fill[0] = new Runnable() {
            @Override public void run() {
                body.removeAllViews();
                for (final DedupOptions.Crit c : opt.all()) {
                    LinearLayout card = new LinearLayout(a);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(12), dp(8), dp(12), dp(8));
                    card.setBackgroundColor(CARD);
                    LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
                    clp.setMargins(dp(8), dp(4), dp(8), dp(4));
                    LinearLayout row = new LinearLayout(a);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    final CheckBox cb = new I18nCheckBox(a);
                    cb.setText(name(c.id));
                    cb.setTextColor(TEXT);
                    cb.setTextSize(14);
                    cb.setChecked(c.on);
                    row.addView(cb, new LinearLayout.LayoutParams(0, -2, 1f));
                    final TextView val = SpriteListScreen.text(a, c.hasValue ? valueText(c) : "", 13, ACCENT, true);
                    row.addView(val);
                    card.addView(row);
                    card.addView(SpriteListScreen.text(a, help(c.id), 11, DIM, false));
                    final SeekBar bar = new SeekBar(a);
                    if (c.hasValue) {
                        bar.setMax(c.max - c.min);
                        bar.setProgress(c.value - c.min);
                        bar.setEnabled(c.on);
                        bar.setPadding(dp(6), dp(6), dp(6), dp(2));
                        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (fromUser) { c.set(c.min + p); val.setText(valueText(c)); } }
                            @Override public void onStartTrackingTouch(SeekBar s) { }
                            @Override public void onStopTrackingTouch(SeekBar s) { rebuild(); }
                        });
                        card.addView(bar);
                    }
                    cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override public void onCheckedChanged(CompoundButton b, boolean checked) { c.on = checked; if (c.hasValue) bar.setEnabled(checked); rebuild(); }
                    });
                    body.addView(card, clp);
                }
            }
        };
        fill[0].run();
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(12), dp(8), dp(12), dp(12));
        foot.addView(SpriteListScreen.button(a, "REDEFINIR", new View.OnClickListener() {
            @Override public void onClick(View v) { opt.reset(); fill[0].run(); rebuild(); }
        }));
        foot.addView(SpriteListScreen.button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }), SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        d.show();
    }
}
