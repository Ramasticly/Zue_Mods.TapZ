package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tela de "Remover Sprites repetidas": grupos com MARCAR TUDO e COMPARAR, barra de semelhanca, OPCOES (criterios), CANCELAR e REMOVER MARCADAS com confirmacao.
 * A logica (grupos, marcas, criterios) esta em {@link DedupAnalysis}, {@link DedupMarks} e {@link DedupOptions} (testadas sem Android); aqui so a tela.
 */
final class DedupScreen {
    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, WARN = 0xFFFFB454, RED = 0xFFFF6B6B;
    private static final int RED_BG = 0xFF4A1F24, GREEN_BG = 0xFF1F4A2B;

    private final Activity a;
    private final CharAssets ca;
    private final SpriteLib lib;
    private final List<SpriteDedup.Sig> sigs;
    private final DedupAnalysis an;
    private final Runnable applied;
    private final DedupOptions opt = new DedupOptions();
    private final int[] minPct = {90};
    private List<SpriteDedup.Group> groups = new ArrayList<SpriteDedup.Group>();
    private DedupMarks marks = new DedupMarks(groups);
    private final Map<Integer, CheckBox> boxes = new HashMap<Integer, CheckBox>();
    private final Map<SpriteDedup.Group, TextView> markButtons = new HashMap<SpriteDedup.Group, TextView>();
    private final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
    private boolean syncing;
    private int token;
    private Dialog dialog;
    private TextView tol, sum, ok;
    private SeekBar sb;
    private LinearLayout list;

    private DedupScreen(Activity a, CharAssets ca, SpriteLib lib, List<SpriteDedup.Sig> sigs, DedupAnalysis an, Runnable applied) {
        this.a = a; this.ca = ca; this.lib = lib; this.sigs = sigs; this.an = an; this.applied = applied;
    }

    static void show(Activity a, CharAssets ca, SpriteLib lib, List<SpriteDedup.Sig> sigs, DedupAnalysis an, Runnable applied) {
        new DedupScreen(a, ca, lib, sigs, an, applied).build();
    }

    private int dp(int v) { return SpriteListScreen.dp(a, v); }

    /** Botao colorido (mesmo formato do SpriteListScreen.button). */
    private TextView colored(String s, int fill, int stroke, int textColor, View.OnClickListener c) {
        TextView t = SpriteListScreen.button(a, s, c);
        t.setTextColor(textColor);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(1), stroke);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        return t;
    }

    // ---- tela principal ----

    private void build() {
        dialog = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(12), 0, 0);
        dialog.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Remover Sprites repetidas", 16, TEXT, true);
        ti.setPadding(dp(14), 0, dp(14), dp(2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Sprites iguais ou parecidas formam um grupo: também as espelhadas, giradas (90° ou qualquer ângulo, aproximado ~), em outra escala ou achatadas "
                + "(zoom X diferente de Y). Marque as que quer REMOVER: os frames do DAC passam a usar a que fica, com Flip, zoom, rotação e posição ajustados para o desenho ficar igual. "
                + "Em cada grupo precisa ficar ao menos uma.", 11, DIM, false);
        hint.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(hint);
        LinearLayout tolRow = new LinearLayout(a);
        tolRow.setOrientation(LinearLayout.HORIZONTAL);
        tolRow.setGravity(Gravity.CENTER_VERTICAL);
        tolRow.setPadding(dp(14), 0, dp(14), 0);
        tol = SpriteListScreen.text(a, "", 14, ACCENT, true);
        tolRow.addView(tol, new LinearLayout.LayoutParams(0, -2, 1f));
        tolRow.addView(SpriteListScreen.button(a, "OPÇÕES", new View.OnClickListener() { @Override public void onClick(View v) { options(); } }));
        root.addView(tolRow);
        sb = new SeekBar(a);
        sb.setMax(50);
        sb.setProgress(40);
        sb.setPadding(dp(18), dp(6), dp(18), dp(6));
        root.addView(sb);
        sum = SpriteListScreen.text(a, "", 12, TEXT, false);
        sum.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(sum);
        list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { tol.setText("Semelhança mínima: " + (50 + p) + "%"); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { rebuild(); }
        });
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(12), dp(8), dp(12), dp(12));
        foot.addView(colored("CANCELAR", RED_BG, RED, RED, new View.OnClickListener() { @Override public void onClick(View v) { dialog.dismiss(); } }));
        ok = colored("REMOVER MARCADAS", GREEN_BG, OK, OK, new View.OnClickListener() { @Override public void onClick(View v) { confirm(); } });
        foot.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        dialog.show();
        rebuild();
    }

    /** Refaz os grupos (so filtra a tabela; fora da tela por precaucao) e a lista. */
    private void rebuild() {
        minPct[0] = 50 + sb.getProgress();
        tol.setText("Semelhança mínima: " + minPct[0] + "%" + (minPct[0] == 100 ? "  (só idênticas)" : ""));
        sum.setText("Comparando sprites...");
        ok.setEnabled(false);
        ok.setAlpha(0.4f);
        final int pct = minPct[0], mine = ++token;
        final DedupOptions o = opt.copy();
        new Thread(new Runnable() {
            @Override public void run() {
                final List<SpriteDedup.Group> gs = an.groups(sigs, pct, o);
                a.runOnUiThread(new Runnable() { @Override public void run() { if (mine == token) populate(gs); } });
            }
        }).start();
    }

    private void populate(List<SpriteDedup.Group> gs) {
        groups = gs;
        marks = new DedupMarks(groups);
        boxes.clear();
        markButtons.clear();
        list.removeAllViews();
        int gi = 0;
        for (final SpriteDedup.Group g : groups) {
            gi++;
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(8), dp(12), dp(8));
            card.setBackgroundColor(CARD);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
            clp.setMargins(dp(8), dp(4), dp(8), dp(4));
            LinearLayout head = new LinearLayout(a);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = SpriteListScreen.text(a, "Grupo " + gi + " · SPR_" + g.rep() + " (a maior)", 13, ACCENT, true);
            head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
            final TextView markBtn = SpriteListScreen.button(a, "MARCAR TUDO", null);
            markBtn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (marks.allMarked(g)) marks.unmarkAll(g); else marks.markAll(g);
                    refreshGroup(g);
                    counts();
                }
            });
            markButtons.put(g, markBtn);
            head.addView(markBtn);
            head.addView(SpriteListScreen.button(a, "COMPARAR", new View.OnClickListener() {
                @Override public void onClick(View v) { compare(g, g.members.size() > 1 ? g.members.get(1).index : g.rep()); }
            }), SpriteListScreen.lpm(a, 6));
            card.addView(head);
            for (final SpriteDedup.Member m : g.members) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(4), 0, dp(4));
                row.addView(thumb(m.index), new LinearLayout.LayoutParams(dp(56), dp(56)));
                SpriteDedup.Sig sg = an.byIndex.get(Integer.valueOf(m.index));
                TextView t = new I18nTextView(a);
                t.setTextSize(12);
                t.setTextColor(m.toRep == null ? OK : TEXT);
                t.setPadding(dp(10), 0, dp(6), 0);
                t.setText("SPR_" + m.index + "  (" + (sg == null ? 0 : sg.w) + "×" + (sg == null ? 0 : sg.h) + ")\n"
                        + (m.toRep == null ? "a maior do grupo" : relation(m.toRep) + " · " + m.toRep.score + "%" + (m.toRep.approx ? "~" : "") + zoomNote(m.toRep) + metricsNote(m.toRep)));
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                final CheckBox cb = new I18nCheckBox(a);
                cb.setText("remover");
                cb.setTextColor(TEXT);
                cb.setTextSize(12);
                boxes.put(Integer.valueOf(m.index), cb);
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                        if (syncing) return;
                        if (!marks.set(g, m.index, checked)) {
                            SpriteListScreen.toast(a, "Precisa ficar ao menos uma sprite em cada grupo");
                        }
                        refreshGroup(g);
                        counts();
                    }
                });
                row.addView(cb);
                card.addView(row);
            }
            list.addView(card, clp);
            refreshGroup(g);
        }
        counts();
    }

    /** Alinha as caixas e o texto do botao do grupo com as marcas. */
    private void refreshGroup(SpriteDedup.Group g) {
        syncing = true;
        for (SpriteDedup.Member m : g.members) {
            CheckBox cb = boxes.get(Integer.valueOf(m.index));
            if (cb != null) cb.setChecked(marks.isMarked(m.index));
        }
        syncing = false;
        TextView b = markButtons.get(g);
        if (b != null) b.setText(marks.allMarked(g) ? "DESMARCAR TUDO" : "MARCAR TUDO");
    }

    private void refreshAll() {
        for (SpriteDedup.Group g : groups) refreshGroup(g);
        counts();
    }

    private void counts() {
        int n = marks.totalMarked();
        String warn = an.complete ? "" : "  ⚠ análise incompleta (" + an.unverified + " par(es) sem conferência)";
        sum.setText((groups.isEmpty() ? "Nenhum grupo de sprites repetidas com esta semelhança." : groups.size() + " grupo(s); " + n + " sprite(s) marcada(s) para remover de " + sigs.size() + ".") + warn);
        ok.setEnabled(n > 0);
        ok.setAlpha(n > 0 ? 1f : 0.4f);
    }

    private static String relation(SpriteDedup.Match m) {
        if (m.g < 0) return "girada " + Math.round(m.rotDeg) + "°" + (m.mirror ? " e espelhada" : "") + " (aproximado)";
        switch (m.g) {
            case 0: return "igual (ou só em outra escala)";
            case 1: return "espelhada na horizontal (Flip X)";
            case 2: return "espelhada na vertical (Flip Y)";
            case 3: return "girada 180°";
            default: return "girada 90° (ou espelhada na diagonal)";
        }
    }

    /** Linha extra com o zoom que a sprite que fica vai ter (quando a escala ou o achatamento mudam). */
    private static String zoomNote(SpriteDedup.Match m) {
        long zx = Math.round(100 / m.sx), zy = Math.round(100 / m.sy);
        String t = "";
        if (Math.abs(zx - 100) > 2 || Math.abs(zy - 100) > 2) {
            t = Math.abs(zx - zy) > 2 ? "\nzoom " + zx + "% × " + zy + "% (achatada)" : "\nzoom " + zx + "%";
            if (m.up > 105) t += " — amplia, perde qualidade";
        }
        return t;
    }

    private static String metricsNote(SpriteDedup.Match m) {
        if (!m.verified) return "";
        return "\nforma " + Math.round(m.iou) + "% · cor " + Math.round(m.color) + "% · detalhes " + Math.round(m.detail) + "%";
    }

    private ImageView thumb(int idx) {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        Bitmap tb = thumbs.get(Integer.valueOf(idx));
        if (tb == null) {
            Bitmap full = lib.cut(idx);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(idx), tb);
            }
        }
        if (tb != null) iv.setImageBitmap(tb);
        return iv;
    }

    // ---- remover ----

    private void confirm() {
        final int n = marks.totalMarked(), gn = marks.groupsWithMarks();
        if (n == 0) return;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover sprites repetidas")
                .setMessage("Remover " + n + " sprite(s) de " + gn + " grupo(s)? Os Frames do DAC serão reescritos para usar a que fica, e as sprites seguintes serão renumeradas. "
                        + "Antes é feita uma cópia de segurança do DAC, do CNV e dos grupos de GIF.")
                .setNegativeButton("VOLTAR", null)
                .setPositiveButton("SIM, REMOVER", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { dialog.dismiss(); apply(); }
                }).show();
    }

    private void apply() {
        final BusyDialog busy = BusyDialog.show(a, "Removendo sprites repetidas");
        busy.set("Reescrevendo os frames...", 0, 0);
        final DedupOptions o = opt.copy();
        final int pct = minPct[0];
        new Thread(new Runnable() {
            @Override public void run() {
                String out;
                try {
                    // backup antes de mexer: DAC, CNV e grupos de GIF (texto)
                    int copied = 0;
                    for (String n : new String[]{"000.dac.txt", "000.cnv.txt", SpriteGroups.FILE}) if (SpriteOptimize.backup(ca.dir, new File(ca.dir, n))) copied++;
                    List<SpriteDedup.Choice> choices = new ArrayList<SpriteDedup.Choice>();
                    for (SpriteDedup.Group g : groups) {
                        List<SpriteDedup.Sig> kept = new ArrayList<SpriteDedup.Sig>();
                        for (SpriteDedup.Member m : g.members) if (!marks.isMarked(m.index)) kept.add(an.byIndex.get(Integer.valueOf(m.index)));
                        for (SpriteDedup.Member m : g.members) {
                            if (!marks.isMarked(m.index)) continue;
                            SpriteDedup.Choice c = an.choose(an.byIndex.get(Integer.valueOf(m.index)), kept, pct, o);
                            if (c != null) choices.add(c);
                        }
                    }
                    SpriteDedup.Result res = SpriteDedup.apply(ca.dac, choices);
                    java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>(res.changedAnos);
                    if (!res.removedSprites.isEmpty()) {
                        int[] map = lib.removeShift(res.removedSprites);
                        changed.addAll(SpriteRenumber.remapDac(ca.dac, map));
                    }
                    String saved = SpriteMassDialogs.persist(ca, changed);
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(res.removedSprites.size()).append(" sprite(s) removida(s); ").append(res.framesRewritten).append(" frame(s) reescrito(s) em ").append(res.changedAnos.size()).append(" ANO(s).\n");
                    sb2.append("As sprites seguintes foram renumeradas.\n");
                    if (!res.skipped.isEmpty()) sb2.append("Ficaram (algum frame não tem como ficar igual): SPR_").append(res.skipped).append('\n');
                    sb2.append("\nCópia dos arquivos anteriores: ").append(SpriteOptimize.backupDir(ca.dir).getPath()).append(copied == 0 ? " (já havia cópia; a original foi mantida)" : "").append(saved.isEmpty() ? "" : "\n" + SpriteMassDialogs.lastPersist);
                    out = sb2.toString();
                } catch (Throwable t) {
                    out = "Erro ao remover sprites repetidas: " + t;
                }
                busy.dismiss();
                final String text = out;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        applied.run();
                        TextView tv = SpriteListScreen.text(a, text, 13, TEXT, false);
                        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
                        ScrollView s = new ScrollView(a);
                        s.addView(tv);
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Sprites repetidas").setView(s).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }

    // ---- comparar ----

    private int cmpToken;

    /** Tela lado a lado: a que fica (desenhada com os ajustes RAZ para parecer a removida) | a removida; caixa grande marca a removida; < > percorrem o grupo. */
    private void compare(final SpriteDedup.Group g, int start) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(8), dp(12), dp(8), dp(8));
        d.setContentView(root);
        final TextView title = SpriteListScreen.text(a, "", 15, TEXT, true);
        title.setPadding(dp(6), 0, dp(6), dp(4));
        root.addView(title);
        final CheckBox big = new I18nCheckBox(a);
        big.setTextColor(TEXT);
        big.setTextSize(20);
        big.setScaleX(1.1f);
        big.setScaleY(1.1f);
        big.setPadding(dp(6), dp(8), dp(6), dp(8));
        root.addView(big);
        LinearLayout mid = new LinearLayout(a);
        mid.setOrientation(LinearLayout.HORIZONTAL);
        mid.setGravity(Gravity.CENTER_VERTICAL);
        final TextView prev = SpriteListScreen.button(a, "<", null), next = SpriteListScreen.button(a, ">", null);
        prev.setTextSize(24);
        next.setTextSize(24);
        mid.addView(prev, new LinearLayout.LayoutParams(dp(44), dp(96)));
        LinearLayout pair = new LinearLayout(a);
        pair.setOrientation(LinearLayout.HORIZONTAL);
        final LinearLayout left = new LinearLayout(a), right = new LinearLayout(a);
        left.setOrientation(LinearLayout.VERTICAL);
        right.setOrientation(LinearLayout.VERTICAL);
        final ImageView leftImg = new ImageView(a), rightImg = new ImageView(a);
        for (ImageView iv : new ImageView[]{leftImg, rightImg}) { iv.setScaleType(ImageView.ScaleType.FIT_CENTER); iv.setBackgroundColor(0xFF0D0F13); }
        final TextView leftCap = SpriteListScreen.text(a, "", 11, DIM, false), rightCap = SpriteListScreen.text(a, "", 11, DIM, false);
        left.addView(leftImg, new LinearLayout.LayoutParams(-1, 0, 1f));
        left.addView(leftCap);
        right.addView(rightImg, new LinearLayout.LayoutParams(-1, 0, 1f));
        right.addView(rightCap);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -1, 1f);
        half.setMargins(dp(3), 0, dp(3), 0);
        pair.addView(left, half);
        pair.addView(right, half);
        mid.addView(pair, new LinearLayout.LayoutParams(0, -1, 1f));
        mid.addView(next, new LinearLayout.LayoutParams(dp(44), dp(96)));
        root.addView(mid, new LinearLayout.LayoutParams(-1, 0, 1f));
        final TextView info = SpriteListScreen.text(a, "", 12, TEXT, false);
        info.setPadding(dp(6), dp(6), dp(6), dp(6));
        root.addView(info);
        root.addView(SpriteListScreen.button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        final int[] cur = {start};
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = new Runnable() {
            @Override public void run() {
                final int rIdx = cur[0];
                final SpriteDedup.Sig r = an.byIndex.get(Integer.valueOf(rIdx));
                title.setText("Comparar · SPR_" + g.rep() + " (a maior)");
                big.setOnCheckedChangeListener(null);
                big.setText("Remover SPR_" + rIdx);
                big.setChecked(marks.isMarked(rIdx));
                big.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                        if (!marks.set(g, rIdx, checked)) SpriteListScreen.toast(a, "Precisa ficar ao menos uma sprite em cada grupo");
                        refreshAll();
                        refresh[0].run();
                    }
                });
                List<SpriteDedup.Sig> kept = new ArrayList<SpriteDedup.Sig>();
                for (SpriteDedup.Member m : g.members) if (m.index != rIdx && !marks.isMarked(m.index)) kept.add(an.byIndex.get(Integer.valueOf(m.index)));
                final SpriteDedup.Choice c = r == null ? null : an.choose(r, kept, minPct[0], opt);
                leftImg.setImageBitmap(null);
                rightImg.setImageBitmap(null);
                rightCap.setText("SPR_" + rIdx + (marks.isMarked(rIdx) ? " (será removida)" : " (fica)"));
                if (c == null) {
                    leftCap.setText("nenhuma sprite que fica serve no lugar");
                    info.setText("");
                    return;
                }
                final SpriteDedup.Match mt = c.match;
                leftCap.setText("SPR_" + c.kept.index + " (fica, ajustada)");
                info.setText(relation(mt) + " · " + mt.score + "%" + (mt.approx ? "~" : "") + zoomNote(mt).replace('\n', ' ') + metricsNote(mt).replace('\n', ' '));
                final int mine = ++cmpToken;
                new Thread(new Runnable() {
                    @Override public void run() {
                        Bitmap rb = lib.cut(rIdx), kb = lib.cut(c.kept.index);
                        if (rb == null || kb == null) return;
                        int[] kpx = new int[kb.getWidth() * kb.getHeight()];
                        kb.getPixels(kpx, 0, kb.getWidth(), 0, 0, kb.getWidth(), kb.getHeight());
                        double[] gen = SpriteVerify.quantized(mt.map(), c.removed.w, c.removed.h, c.kept.w, c.kept.h);      // o que o DAC vai desenhar
                        if (gen == null) gen = mt.map();
                        int[] shown = SpriteVerify.renderRect(kpx, kb.getWidth(), kb.getHeight(), gen, rb.getWidth(), rb.getHeight());
                        final Bitmap lb = Bitmap.createBitmap(shown, rb.getWidth(), rb.getHeight(), Bitmap.Config.ARGB_8888);
                        final Bitmap rr = rb;
                        kb.recycle();
                        a.runOnUiThread(new Runnable() { @Override public void run() { if (mine == cmpToken) { leftImg.setImageBitmap(lb); rightImg.setImageBitmap(rr); } } });
                    }
                }).start();
            }
        };
        prev.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cur[0] = marks.step(g, cur[0], -1); refresh[0].run(); } });
        next.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cur[0] = marks.step(g, cur[0], 1); refresh[0].run(); } });
        d.show();
        refresh[0].run();
    }

    // ---- opcoes ----

    private static String name(String id) {
        if ("shape".equals(id)) return "Forma (silhueta)";
        if ("color".equals(id)) return "Cor dos pixels";
        if ("detail".equals(id)) return "Detalhes (bordas internas)";
        if ("palette".equals(id)) return "Paleta de cores";
        if ("stretch".equals(id)) return "Achatamento máximo";
        if ("enlarge".equals(id)) return "Ampliação máxima da que fica";
        if ("mirror".equals(id)) return "Aceitar espelhadas";
        if ("turn90".equals(id)) return "Aceitar giradas 90° / 180°";
        if ("angle".equals(id)) return "Aceitar giradas em qualquer ângulo";
        return "Agrupar em cadeia";
    }

    private static String help(String id) {
        if ("shape".equals(id)) return "Quanto do contorno coincide depois de ajustar escala, rotação e posição. Evita juntar imagens com partes a mais ou a menos.";
        if ("color".equals(id)) return "Quanto da área comum (sem a borda) tem a mesma cor. Pega regiões recoloridas.";
        if ("detail".equals(id)) return "Compara as linhas e contornos dentro da imagem.";
        if ("palette".equals(id)) return "Compara a mistura geral de cores das duas.";
        if ("stretch".equals(id)) return "Maior diferença aceita entre o zoom X e o zoom Y (4,0× = a cópia pode ficar 4 vezes mais baixa que larga).";
        if ("enlarge".equals(id)) return "Recusa quando a sprite que fica precisa ser ampliada acima disto (perde qualidade). Desligado aceita qualquer ampliação.";
        if ("mirror".equals(id)) return "Cópias com Flip X ou Flip Y.";
        if ("turn90".equals(id)) return "Cópias giradas de 90° ou 180°.";
        if ("angle".equals(id)) return "Cópias giradas em qualquer ângulo (aproximado). O valor é a nota mínima das células.";
        return "Ligado: uma sprite entra no grupo se casar com qualquer membro, mesmo sem casar com a maior (pode juntar imagens diferentes). Desligado: todas precisam casar com a maior.";
    }

    private static String valueText(DedupOptions.Crit c) {
        if ("stretch".equals(c.id)) return (c.value / 10) + "," + (c.value % 10) + "×";
        return c.value + "%";
    }

    private void options() {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Critérios de detecção", 16, TEXT, true);
        ti.setPadding(dp(14), 0, dp(14), dp(2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Cada critério pode ser ligado ou desligado e ter a sua tolerância. Uma sprite só entra no grupo se passar em todos os ligados. "
                + "A barra \"Semelhança mínima\" continua valendo para a nota geral das células.", 11, DIM, false);
        hint.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(hint);
        final LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final Runnable[] fill = new Runnable[1];
        fill[0] = new Runnable() {
            @Override public void run() {
                body.removeAllViews();
                for (final DedupOptions.Crit c : opt.all()) {
                    LinearLayout card = new LinearLayout(a);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(12), dp(8), dp(12), dp(8));
                    card.setBackgroundColor(CARD);
                    LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
                    clp.setMargins(dp(8), dp(4), dp(8), dp(4));
                    LinearLayout row = new LinearLayout(a);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    final CheckBox cb = new I18nCheckBox(a);
                    cb.setText(name(c.id));
                    cb.setTextColor(TEXT);
                    cb.setTextSize(14);
                    cb.setChecked(c.on);
                    row.addView(cb, new LinearLayout.LayoutParams(0, -2, 1f));
                    final TextView val = SpriteListScreen.text(a, c.hasValue ? valueText(c) : "", 13, ACCENT, true);
                    row.addView(val);
                    card.addView(row);
                    card.addView(SpriteListScreen.text(a, help(c.id), 11, DIM, false));
                    final SeekBar bar = new SeekBar(a);
                    if (c.hasValue) {
                        bar.setMax(c.max - c.min);
                        bar.setProgress(c.value - c.min);
                        bar.setEnabled(c.on);
                        bar.setPadding(dp(6), dp(6), dp(6), dp(2));
                        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (fromUser) { c.set(c.min + p); val.setText(valueText(c)); } }
                            @Override public void onStartTrackingTouch(SeekBar s) { }
                            @Override public void onStopTrackingTouch(SeekBar s) { rebuild(); }
                        });
                        card.addView(bar);
                    }
                    cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override public void onCheckedChanged(CompoundButton b, boolean checked) { c.on = checked; if (c.hasValue) bar.setEnabled(checked); rebuild(); }
                    });
                    body.addView(card, clp);
                }
            }
        };
        fill[0].run();
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(12), dp(8), dp(12), dp(12));
        foot.addView(SpriteListScreen.button(a, "REDEFINIR", new View.OnClickListener() {
            @Override public void onClick(View v) { opt.reset(); fill[0].run(); rebuild(); }
        }));
        foot.addView(SpriteListScreen.button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }), SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        d.show();
    }
}
