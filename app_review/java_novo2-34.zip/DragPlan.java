package com.zue.attackeditor;

import java.util.List;

/** Contas do arrastar de sprites na lista (puras): qual linha esta sob o dedo SEM contar a arrastada, a unidade alvo (sprite, GIF) e quem sobe/desce. */
final class DragPlan {
    private DragPlan() { }

    /** Em que sprites/GIFs a lista esta dividida: -1 se a sprite nao esta em GIF. */
    interface Groups {
        int firstOf(int sprite);
        int lastOf(int sprite);
    }

    /**
     * Linha cujo intervalo [top, bottom) contem {@code y}, ignorando a linha {@code skip} (a arrastada, que tem transformacao e nao pode ser alvo de si mesma).
     * Fora de todas as linhas: a mais proxima (acima da primeira = a primeira; abaixo da ultima = a ultima). -1 se so existe a arrastada.
     */
    static int hit(int[] tops, int[] bottoms, int skip, float y) {
        int best = -1;
        float bestDist = Float.MAX_VALUE;
        for (int i = 0; i < tops.length; i++) {
            if (i == skip) continue;
            if (y >= tops[i] && y < bottoms[i]) return i;
            float d = y < tops[i] ? tops[i] - y : y - bottoms[i] + 1;
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return best;
    }

    /** Posicoes {inicio, fim} (na lista de linhas) da unidade que contem {@code pos}: a linha so, o GIF encolhido, ou o GIF aberto inteiro (cabecalho + quadros). */
    static int[] unit(List<int[]> rows, int pos, Groups g) {
        int[] r = rows.get(pos);
        if (r[0] == 1) return new int[]{pos, pos};
        int first, last;
        if (r[0] == 2) { first = r[1]; last = g.lastOf(first); }
        else {
            first = g.firstOf(r[1]);
            last = g.lastOf(r[1]);
            if (first < 0) return new int[]{pos, pos};
        }
        int s = pos, e = pos;
        for (int i = 0; i < rows.size(); i++) {
            int[] q = rows.get(i);
            boolean in = (q[0] == 2 && q[1] == first) || (q[0] == 0 && q[1] >= first && q[1] <= last);
            if (!in) continue;
            if (i < s) s = i;
            if (i > e) e = i;
        }
        return new int[]{s, e};
    }

    /** Posicao antes da qual a linha arrastada (de {@code p0}) cai se for solta sobre {@code pos}: depois da unidade se desce, antes se sobe. */
    static int insertionPos(List<int[]> rows, int pos, int p0, Groups g) {
        int[] u = unit(rows, pos, g);
        return pos > p0 ? u[1] + 1 : u[0];
    }

    /**
     * Modelo com DOIS slots: a linha {@code p0} deixa um buraco (slot vermelho, o lugar de origem) e as vizinhas NAO o preenchem; o slot azul abre antes de
     * {@code insPos} empurrando linhas para baixo. Devolve {lo, hi, +1} das linhas que descem 1 altura ({@code hi == Integer.MAX_VALUE} = ate o fim da lista) ou
     * {0, -1, 0} se a insercao cola na origem (nao ha azul: soltar assim nao muda nada).
     */
    static int[] pushed(int p0, int insPos) { return pushed(p0, 1, insPos); }

    /** Como {@link #pushed(int, int)} para um BLOCO de {@code n} linhas a partir de {@code p0} (marcadas seguidas): a insercao colada no bloco nao muda nada. */
    static int[] pushed(int p0, int n, int insPos) {
        if (insPos > p0 + n) return new int[]{insPos, Integer.MAX_VALUE, 1};
        if (insPos < p0) return new int[]{insPos, p0 - 1, 1};
        return new int[]{0, -1, 0};
    }

    /** O slot azul aparece? (a insercao nao cola na origem). */
    static boolean blueAt(int p0, int insPos) { return blueAt(p0, 1, insPos); }

    static boolean blueAt(int p0, int n, int insPos) { return insPos > p0 + n || insPos < p0; }

    /** Quem se mexe quando a linha {@code p0} vai para antes de {@code insPos}: {lo, hi, dir} (dir -1 = sobem, +1 = descem, 0 = ninguem). */
    static int[] shifted(int p0, int insPos) {
        if (insPos > p0 + 1) return new int[]{p0 + 1, insPos - 1, -1};
        if (insPos < p0) return new int[]{insPos, p0 - 1, 1};
        return new int[]{0, -1, 0};
    }
}
