package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Alerta com a lista de erros: texto selecionavel e botao COPIAR (como o registro de erro do app), para mandar o motivo exato. */
final class ErrorListDialog {
    private ErrorListDialog() { }

    static String join(List<String> lines) {
        StringBuilder b = new StringBuilder();
        for (String s : lines) b.append(s).append('\n');
        return b.toString().trim();
    }

    static void show(final Activity a, String title, List<String> lines) {
        final String text = join(lines);
        TextView tv = new I18nTextView(a).noTranslate();       // motivos de recorte: dado (ja traduzido na origem)
        tv.setText(text);
        tv.setTextColor(0xFFE6E8EC);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setTextIsSelectable(true);
        int p = (int) (14 * a.getResources().getDisplayMetrics().density);
        tv.setPadding(p, p / 2, p, p / 2);
        ScrollView sv = new ScrollView(a);
        sv.addView(tv);
        AlertDialog ad = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title)
                .setView(sv)
                .setNeutralButton("COPIAR", null)
                .setPositiveButton("FECHAR", null)
                .create();
        ad.show();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(p);
        ad.getWindow().setBackgroundDrawable(bg);
        // COPIAR nao fecha o alerta: o usuario copia e continua lendo
        ad.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener(new android.view.View.OnClickListener() {
            @Override public void onClick(android.view.View v) {
                ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("erros de recorte", text));
                I18nUi.toast(a, "Copiado", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
    }
}
