package com.zue.attackeditor;

import com.zue.gd.util.PacExtractor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Ponte entre o app e os extratores do compilador (copiados sem alteracao em {@code com/zue/gd/util}). Extrai o {@code nome.pac} para a pasta {@code nome/} de
 * assets, como o jogo faz. Se a pasta ja existe (so faltam alguns TXT), extrai numa pasta temporaria e copia so os TXT que faltam: nada que o usuario ja
 * editou (TXT, PNG, WAV) e sobrescrito. Public porque a camada de compatibilidade (com.zue.gd.util.BinBuilder) chama {@link #buildHdatBlock}.
 */
public final class ExtractorBridge {
    private ExtractorBridge() { }

    /** Usado pelo BinBuilder de compatibilidade: bytes do HDAT que o app consegue compilar do texto (o resto cai no $RAW do extrator). */
    public static byte[] buildHdatBlock(String block) throws IOException {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\$HDAT_(\\d+)").matcher(block);
        if (!m.find()) throw new IOException("bloco sem $HDAT_n");
        int n = Integer.parseInt(m.group(1));
        byte[] all = BinTxt.compile("BIN_CNV_ {$COUNT: " + (n + 1) + ",\n" + block + "\n}");
        return HdatTable.parse(all).bytes(n);
    }

    /** Progresso: (nome do segmento, indice, total). */
    interface Progress { void on(String pack, String segment, int index, int total); }

    /** Extrai o pack do item. Devolve uma frase com o que foi feito; IOException/Exception se falhar. */
    static String extract(File root, PackCheck.Item it, final Progress pr) throws Exception {
        if (it.pac == null) throw new IOException(it.name + ": sem " + it.name + ".pac em " + root.getPath());
        PacExtractor.ProgressCallback cb = pr == null ? null : new PacExtractor.ProgressCallback() {
            @Override public void onSegmentStart(String pacName, String fileName, int index, int total) { pr.on(pacName, fileName, index, total); }
            @Override public void onSegmentExtracted(String pacName, String fileName, int index, int total) { }
        };
        boolean dirExists = it.dir != null && it.dir.isDirectory();
        if (!dirExists) {
            PacExtractor.extract(root.getPath(), it.pac.getName(), cb);               // igual ao jogo: assets/nome/
            return it.name + ": extraido de " + it.pac.getName();
        }
        File tmp = new File(new File(root.getParentFile(), Saver.TBRE), "tmp/extract_" + it.name + "_" + System.currentTimeMillis());
        if (!tmp.mkdirs()) throw new IOException("nao consegui criar " + tmp.getPath());
        try {
            File copy = new File(tmp, it.pac.getName());
            copy(it.pac, copy);
            PacExtractor.extract(tmp.getPath(), copy.getName(), cb);
            File out = new File(tmp, it.pac.getName().substring(0, it.pac.getName().length() - 4));
            int n = 0;
            StringBuilder what = new StringBuilder();
            for (String k : kinds(it)) {
                if (TxtFiles.find(it.dir, k) != null) continue;
                File src = TxtFiles.find(out, k);
                if (src == null) continue;
                copy(src, new File(it.dir, src.getName()));
                what.append(what.length() > 0 ? ", " : "").append(src.getName());
                n++;
            }
            if (n == 0) throw new IOException(it.name + ": o " + it.pac.getName() + " nao tem os TXT que faltam");
            return it.name + ": copiado " + what + " de " + it.pac.getName();
        } finally {
            deleteTree(tmp);
        }
    }

    private static String[] kinds(PackCheck.Item it) {
        if (it.name.equals("gamedata")) return new String[] {"dac"};
        if (it.name.startsWith("char") && !it.name.startsWith("charf")) return new String[] {"dac", "bin", "cnv"};
        return new String[] {"dac", "cnv"};
    }

    static void copy(File a, File b) throws IOException {
        if (b.getParentFile() != null) b.getParentFile().mkdirs();
        InputStream in = new FileInputStream(a);
        try {
            OutputStream o = new FileOutputStream(b);
            try {
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            } finally { o.close(); }
        } finally { in.close(); }
    }

    static void deleteTree(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File c : k) deleteTree(c);
        f.delete();
    }
}
