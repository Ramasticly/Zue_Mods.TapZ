package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Navegador de pastas do proprio app (o app tem acesso a todos os arquivos, entao nao usa o seletor do sistema):
 * mostra pastas e PNGs com miniatura; um ou varios arquivos podem ser marcados.
 */
final class FilePicker {
    private FilePicker() { }

    interface Listener { void onPicked(List<File> files); }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, SEL = 0xFF21402C, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A;
    private static File last;
    static final int IMAGES = 0, AUDIO = 1, IMAGES_CNV = 2;
    private static int mode = IMAGES;
    private static CnvListener cnvL;

    /** IMAGES_CNV: tocar num .cnv (ou .cnv.txt) nao marca o arquivo, abre a escolha de sprites daquele pac. */
    interface CnvListener { void onCnv(File cnv); }

    static void show(final Activity a, final String title, final boolean multi, final Listener l) { show(a, title, multi, IMAGES, l); }

    /** {@code kind}: IMAGES (PNG etc.) ou AUDIO (wav, mp3, ogg, m4a...). */
    static void show(final Activity a, final String title, final boolean multi, int kind, final Listener l) { show(a, title, multi, kind, l, null); }

    /** Como acima; em IMAGES_CNV, {@code cl} recebe o .cnv tocado. */
    static void show(final Activity a, final String title, final boolean multi, int kind, final Listener l, CnvListener cl) {
        mode = kind;
        cnvL = cl;
        stopPreview();
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface x) { stopPreview(); }
        });
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        d.setContentView(root);
        // na raiz do celular ao abrir o app; nas proximas aberturas da mesma execucao, na ultima pasta usada
        File start = last != null && last.isDirectory() ? last : root();
        final ArrayList<File> chosen = new ArrayList<File>();
        browse(a, d, root, title, multi, l, start, chosen);
        // voltar do celular sobe uma pasta; so na raiz fecha o seletor
        d.setOnKeyListener(new android.content.DialogInterface.OnKeyListener() {
            @Override public boolean onKey(android.content.DialogInterface x, int code, android.view.KeyEvent ev) {
                if (code != android.view.KeyEvent.KEYCODE_BACK) return false;
                if (ev.getAction() != android.view.KeyEvent.ACTION_UP) return true;
                File cur = last;
                File top = root();
                File up = cur == null ? null : cur.getParentFile();
                if (cur != null && up != null && !cur.equals(top) && up.isDirectory()) {
                    browse(a, d, root, title, multi, l, up, chosen);
                } else d.dismiss();
                return true;
            }
        });
        d.show();
    }

    /** Toda pasta menos a raiz tem como primeiro item a linha "...↑" que sobe um nivel. */
    static boolean hasUpRow(File dir, File root) { return dir != null && dir.getParentFile() != null && !dir.equals(root); }

    private static File root() {
        File r = new File("/storage/emulated/0");
        return r.isDirectory() ? r : android.os.Environment.getExternalStorageDirectory();
    }

    private static void browse(final Activity a, final Dialog d, final LinearLayout root, final String title, final boolean multi,
                               final Listener l, final File dir, final ArrayList<File> chosen) {
        last = dir;
        stopPreview();
        root.removeAllViews();
        root.setPadding(0, dp(a, 12), 0, 0);
        TextView ti = text(a, title, 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 8));
        root.addView(ti);
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        bar.addView(button(a, "PRINCIPAL", new View.OnClickListener() {
            @Override public void onClick(View v) { browse(a, d, root, title, multi, l, root(), chosen); }
        }));
        bar.addView(button(a, "SUBIR", new View.OnClickListener() {
            @Override public void onClick(View v) {
                File p = dir.getParentFile();
                if (p != null) browse(a, d, root, title, multi, l, p, chosen);
            }
        }), lpm(a, 6));
        String[] quick = {"Download", "Pictures", "DCIM", "Documents"};
        for (final String q : quick) {
            final File f = new File("/storage/emulated/0/" + q);
            if (f.isDirectory()) {
                TextView b = button(a, q, new View.OnClickListener() {
                    @Override public void onClick(View v) { browse(a, d, root, title, multi, l, f, chosen); }
                });
                bar.addView(b, lpm(a, 6));
            }
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(bar);
        root.addView(hs);

        TextView path = text(a, dir.getPath(), 12, ACCENT, false);
        path.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 4));
        root.addView(path);

        File[] fs = dir.listFiles();
        final ArrayList<File> items = new ArrayList<File>();
        if (fs != null) {
            Arrays.sort(fs, new Comparator<File>() {
                @Override public int compare(File x, File y) {
                    if (x.isDirectory() != y.isDirectory()) return x.isDirectory() ? -1 : 1;
                    return x.getName().compareToIgnoreCase(y.getName());
                }
            });
            for (File f : fs) if (!f.getName().startsWith(".") && (f.isDirectory() || accept(f))) items.add(f);
        }
        TextView inf = text(a, fs == null ? "pasta ilegivel (permissao de arquivos?)" : items.size() + (mode == AUDIO ? " pasta(s)/audio(s)" : mode == IMAGES_CNV ? " pasta(s)/imagem(ns)/CNV" : " pasta(s)/imagem(ns)"), 11, DIM, false);
        inf.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        root.addView(inf);

        final boolean upRow = hasUpRow(dir, root());
        final int off = upRow ? 1 : 0;
        final Handler ui = new Handler(Looper.getMainLooper());
        final Map<String, Bitmap> thumbs = new HashMap<String, Bitmap>();
        final HashSet<String> loading = new HashSet<String>();
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return items.size() + off; }
            @Override public Object getItem(int i) { return upRow && i == 0 ? dir.getParentFile() : items.get(i - off); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                if (upRow && i == 0) {
                    LinearLayout up = new LinearLayout(a);
                    up.setOrientation(LinearLayout.HORIZONTAL);
                    up.setGravity(Gravity.CENTER_VERTICAL);
                    up.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8));
                    TextView ut = new I18nTextView(a).noTranslate();
                    ut.setTextSize(14);
                    ut.setText("...\u2191");
                    ut.setTextColor(ACCENT);
                    ut.setTypeface(Typeface.DEFAULT_BOLD);
                    ut.setPadding(dp(a, 4), dp(a, 8), 0, dp(a, 8));
                    up.addView(ut, new LinearLayout.LayoutParams(0, -2, 1f));
                    return up;
                }
                final File f = items.get(i - off);
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8));
                boolean on = chosen.contains(f);
                if (on) row.setBackgroundColor(SEL);
                TextView t = new I18nTextView(a).noTranslate();      // nome de arquivo: dado, nao traduzir
                t.setTextSize(14);
                if (f.isDirectory()) {
                    // pasta: so o nome
                    t.setText(f.getName());
                    t.setTextColor(TEXT);
                    t.setTypeface(Typeface.DEFAULT_BOLD);
                    t.setPadding(dp(a, 4), dp(a, 8), 0, dp(a, 8));
                } else {
                    t.setPadding(dp(a, 12), 0, 0, 0);
                    t.setText((on ? "\u2713  " : "") + f.getName() + "\n" + size(f.length()));
                    t.setTextColor(on ? OK : accept(f) ? TEXT : DIM);
                    final String key = f.getPath();
                    Bitmap tb = isImage(f) ? thumbs.get(key) : null;
                    if (isImage(f)) {
                        ImageView iv = new ImageView(a);
                        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        iv.setBackgroundColor(0xFF0D0F13);
                        row.addView(iv, new LinearLayout.LayoutParams(dp(a, 52), dp(a, 52)));
                        if (tb != null) iv.setImageBitmap(tb);
                        else if (loading.add(key)) {
                            new Thread(new Runnable() {
                                @Override public void run() {
                                    final Bitmap b = thumb(f);
                                    ui.post(new Runnable() { @Override public void run() { if (b != null) thumbs.put(key, b); ((BaseAdapter) lv.getAdapter()).notifyDataSetChanged(); } });
                                }
                            }).start();
                        }
                    } else {
                        if (isAudio(f)) row.addView(playButton(a, f, lv), new LinearLayout.LayoutParams(dp(a, 52), dp(a, 52)));
                        else row.addView(cube(a, f), new LinearLayout.LayoutParams(dp(a, 52), dp(a, 52)));
                    }
                }
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                return row;
            }
        };
        lv.setAdapter(ad);
        final Runnable[] refreshStrip = new Runnable[1];
        final TextView ok = button(a, label(multi, chosen.size()), new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (chosen.isEmpty()) return;
                d.dismiss();
                l.onPicked(new ArrayList<File>(chosen));
            }
        });
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (upRow && pos == 0) { browse(a, d, root, title, multi, l, dir.getParentFile(), multi ? chosen : new ArrayList<File>()); return; }
                File f = items.get(pos - off);
                if (f.isDirectory()) { browse(a, d, root, title, multi, l, f, multi ? chosen : new ArrayList<File>()); return; }
                if (!accept(f)) return;
                if (mode == IMAGES_CNV && SpriteImportPlan.isCnvName(f.getName())) {      // outro pac: abre a escolha das sprites dele
                    d.dismiss();
                    if (cnvL != null) cnvL.onCnv(f);
                    return;
                }
                if (chosen.contains(f)) chosen.remove(f);
                else { if (!multi) chosen.clear(); chosen.add(f); }
                ok.setText(label(multi, chosen.size()));
                ad.notifyDataSetChanged();
                refreshStrip[0].run();
            }
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        // faixa na base com o que ja foi marcado (miniatura ou nome) e um x para tirar da selecao
        final android.widget.HorizontalScrollView stripScroll = new android.widget.HorizontalScrollView(a);
        stripScroll.setHorizontalScrollBarEnabled(false);
        stripScroll.setBackgroundColor(CARD);
        final LinearLayout strip = new LinearLayout(a);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8));
        stripScroll.addView(strip);
        refreshStrip[0] = new Runnable() {
            @Override public void run() {
                strip.removeAllViews();
                stripScroll.setVisibility(chosen.isEmpty() ? View.GONE : View.VISIBLE);
                for (final File f : new ArrayList<File>(chosen)) {
                    android.widget.FrameLayout cell = new android.widget.FrameLayout(a);
                    View body;
                    if (mode == AUDIO) {
                        TextView nm = text(a, f.getName(), 12, TEXT, false);
                        nm.setSingleLine(true);
                        nm.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                        nm.setGravity(Gravity.CENTER_VERTICAL);
                        nm.setPadding(dp(a, 10), 0, dp(a, 26), 0);
                        GradientDrawable g = new GradientDrawable();
                        g.setColor(SEL);
                        g.setCornerRadius(dp(a, 8));
                        nm.setBackground(g);
                        cell.addView(nm, new android.widget.FrameLayout.LayoutParams(dp(a, 150), dp(a, 40)));
                        body = nm;
                    } else {
                        final ImageView iv = new ImageView(a);
                        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        iv.setBackgroundColor(0xFF0D0F13);
                        final String key = f.getPath();
                        Bitmap tb = thumbs.get(key);
                        if (tb != null) iv.setImageBitmap(tb);
                        else new Thread(new Runnable() {
                            @Override public void run() {
                                final Bitmap b = thumb(f);
                                ui.post(new Runnable() { @Override public void run() { if (b != null) { thumbs.put(key, b); iv.setImageBitmap(b); } } });
                            }
                        }).start();
                        cell.addView(iv, new android.widget.FrameLayout.LayoutParams(dp(a, 56), dp(a, 56)));
                        body = iv;
                    }
                    TextView x = text(a, "\u2715", 12, 0xFFFFFFFF, true);
                    x.setGravity(Gravity.CENTER);
                    GradientDrawable xg = new GradientDrawable();
                    xg.setShape(GradientDrawable.OVAL);
                    xg.setColor(0xFFD04848);
                    x.setBackground(xg);
                    x.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            chosen.remove(f);
                            ok.setText(label(multi, chosen.size()));
                            ad.notifyDataSetChanged();
                            refreshStrip[0].run();
                        }
                    });
                    cell.addView(x, new android.widget.FrameLayout.LayoutParams(dp(a, 24), dp(a, 24), Gravity.TOP | Gravity.END));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                    lp.setMargins(0, 0, dp(a, 8), 0);
                    strip.addView(cell, lp);
                }
            }
        };
        root.addView(stripScroll, new LinearLayout.LayoutParams(-1, -2));
        refreshStrip[0].run();
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 12));
        foot.addView(button(a, "CANCELAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        foot.addView(ok, lpm(a, 8));
        root.addView(foot);
    }

    /** Icone de arquivo que nao e imagem: quadrado "cubico" com a extensao escrita. */
    // ---- previa de audio na lista (play/stop no lugar do "WAV") ----

    private static android.media.MediaPlayer prev;
    private static String prevKey;

    static void stopPreview() {
        if (prev != null) { try { prev.stop(); } catch (Exception ignored) { } try { prev.release(); } catch (Exception ignored) { } }
        prev = null;
        prevKey = null;
    }

    private static View playButton(final Activity a, final File f, final ListView lv) {
        final String key = f.getPath();
        boolean playing = key.equals(prevKey);
        TextView b = text(a, playing ? "\u25A0" : "\u25B6", 22, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(ACCENT);
        b.setBackground(g);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean same = key.equals(prevKey);
                stopPreview();
                if (!same) {
                    try {
                        final android.media.MediaPlayer p = new android.media.MediaPlayer();
                        prev = p;
                        prevKey = key;
                        p.setDataSource(f.getAbsolutePath());
                        p.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                            @Override public void onPrepared(android.media.MediaPlayer m) { if (prev == m) m.start(); }
                        });
                        p.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                            @Override public void onCompletion(android.media.MediaPlayer m) {
                                if (prev == m) { stopPreview(); ((BaseAdapter) lv.getAdapter()).notifyDataSetChanged(); }
                            }
                        });
                        p.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                            @Override public boolean onError(android.media.MediaPlayer m, int w, int x) {
                                if (prev == m) { stopPreview(); ((BaseAdapter) lv.getAdapter()).notifyDataSetChanged(); }
                                return true;
                            }
                        });
                        p.prepareAsync();
                    } catch (Exception e) { stopPreview(); }
                }
                ((BaseAdapter) lv.getAdapter()).notifyDataSetChanged();
            }
        });
        return b;
    }

    private static View cube(Activity a, File f) {
        String n = f.getName();
        int dot = n.lastIndexOf('.');
        String ext = dot >= 0 && dot < n.length() - 1 ? n.substring(dot + 1).toUpperCase(Locale.US) : "?";
        if (ext.length() > 4) ext = ext.substring(0, 4);
        TextView t = text(a, ext, ext.length() > 3 ? 11 : 13, TEXT, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3A4562, 0xFF232A3D});
        g.setStroke(dp(a, 1), 0xFF55608A);
        g.setCornerRadius(dp(a, 6));
        t.setBackground(g);
        return t;
    }

    private static String label(boolean multi, int n) { if (mode == AUDIO) return n == 0 ? "USAR AUDIO" : "USAR ESTE AUDIO"; return multi ? "USAR " + n + " IMAGEM(NS)" : (n == 0 ? "USAR IMAGEM" : "USAR A IMAGEM"); }

    private static final String[] AUDIO_EXT = {".wav", ".mp3", ".ogg", ".oga", ".m4a", ".aac", ".flac", ".3gp", ".amr", ".opus", ".mp4"};

    static boolean isAudio(File f) {
        String n = f.getName().toLowerCase(Locale.US);
        if (!f.isFile()) return false;
        for (String e : AUDIO_EXT) if (n.endsWith(e)) return true;
        return false;
    }

    private static boolean accept(File f) {
        if (mode == AUDIO) return isAudio(f);
        if (mode == IMAGES_CNV) return isImage(f) || (f.isFile() && SpriteImportPlan.isCnvName(f.getName()));
        return isImage(f);
    }

    static boolean isImage(File f) {
        String n = f.getName().toLowerCase(Locale.US);
        return f.isFile() && ImageImport.isSupportedName(n);
    }

    private static Bitmap thumb(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            int s = 1;
            while (o.outWidth / (s * 2) >= 128 && o.outHeight / (s * 2) >= 128) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            o.inScaled = false;
            return BitmapFactory.decodeFile(f.getPath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.0f KB", b / 1024.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    private static int dp(Activity a, int v) { return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f); }

    private static LinearLayout.LayoutParams lpm(Activity a, int left) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(a, left), 0, 0, 0);
        return p;
    }

    private static TextView text(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static TextView button(Activity a, String s, View.OnClickListener c) {
        TextView t = text(a, s, 12, TEXT, true);
        t.setPadding(dp(a, 14), dp(a, 9), dp(a, 14), dp(a, 9));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setStroke(1, LINE);
        g.setCornerRadius(dp(a, 8));
        t.setBackground(g);
        t.setOnClickListener(c);
        return t;
    }
}
