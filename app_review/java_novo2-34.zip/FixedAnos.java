package com.zue.attackeditor;

/**
 * ANOs fixos do jogo, iguais em todos os personagens (o TCBManajer chama {@code _SetAct} com esses numeros). Nomes curtos para o (i) da grade.
 * Os nomes vem do md que usa cada ANO (secao 15.1 da ajuda para IA); os que o jogo usa sem um papel claro nao tem nome aqui. Java puro.
 */
final class FixedAnos {
    private FixedAnos() { }

    /** Pouso padrao: o jogo toca o ANO 13 quando o golpe nao define POUSO. */
    static final int STANDARD_LANDING = 13;

    static String name(int ano) {
        switch (ano) {
            case 0: return "Parado (idle)";
            case 1: return "Voando parado";
            case 2: case 3: return "Esquiva rápida";
            case 4: return "Defesa";
            case 6: case 7: return "Dash no chão";
            case 8: case 9: return "Dash no ar";
            case 13: return "Animação de pouso padrão";
            case 14: return "Intro";
            case 18: return "Andar para a frente";
            case 19: return "Recuo";
            case 22: return "Reação de dano";
            case 24: return "Caído / levantando";
            case 29: return "Ataque normal A (vindo de corrida)";
            case 30: return "Ataque normal A (1º golpe, em pé)";
            case 31: return "Ataque normal A + frente (em pé)";
            case 32: return "Ataque normal A (2º golpe do combo)";
            case 33: return "Ataque normal A (3º golpe do combo)";
            case 34: return "Ataque normal A (pulando)";
            case 35: return "Ataque normal A + frente (pulando)";
            case 36: return "Ataque normal A + baixo (em pé)";
            case 37: return "Ataque normal A + trás (em pé)";
            case 38: return "Ataque normal A + baixo (pulando)";
            case 39: return "Ataque normal A + trás (pulando)";
            case 42: return "Repetição do disparo (especial dos golpes 0/3/6)";
            case 84: return "Carga de ki (início)";
            case 85: return "Carga de ki (contínua)";
            case 87: return "Teleporte (some)";
            case 88: return "Teleporte (aparece)";
            case 89: return "Queda depois de um ataque no ar";
            default: return null;
        }
    }

    /** O ANO e um dos ataques normais do botao A (29 a 39)? Eles nao passam pelo HDAT 4. */
    static boolean isNormalAttack(int ano) { return ano >= 29 && ano <= 39; }

    /** Os ANOs 30 e 32 abrem a janela de combo (wOptFlag 512): o proximo A troca para 32 / 33 (ou 31 / 36 / 37 com direcao). */
    static boolean hasComboWindow(int ano) { return ano == 30 || ano == 32; }
}
