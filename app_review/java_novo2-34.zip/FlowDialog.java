package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * "Ver fluxo": grafico de ramificacoes do golpe. ANO inicial -> SEQ chao / SEQ ar -> END chao / END ar. Cada no e uma miniatura que toca
 * ate o frame da transicao, trava no ultimo, espera 1 s e recomeca. Os slots de SEQ e END ficam sempre la (mesmo vazios) para poderem
 * ser definidos; a ramificacao so passa por slot preenchido. Tocar num no abre a versao grande com "ir para ANO" e "trocar ANO".
 */
final class FlowDialog {
    private static final int F_INIT = 0, F_SEQ_C = 1, F_SEQ_A = 2, F_SEQ_BOTH = 3, F_END_C = 4, F_END_A = 5, F_END_BOTH = 6, F_AO = 7;

    private static final class Flow {
        int init, seqC, seqA, endC, endA, ao;
        /** Onde o projetil e lancado: 0 ANO inicial, 1 alguma SEQ, 2 alguma END, -1 nenhum ANO do golpe lanca projetil. */
        int projLevel = -1;
        boolean projSeqC, projSeqA, projEndC, projEndA;
        final Map<Integer, Integer> stop = new HashMap<Integer, Integer>();     // ANO -> frame da primeira transicao (-1 = sem)
    }

    private static final class Slot {
        int field, level, col;            // col: 0 chao, 1 ar, 2 centro
        String label;
        int ano;
        boolean disabled, merged, isolated;
    }

    private static final class Link {
        final float x1, y1, x2, y2;
        final boolean dashed, arrow;
        Link(float x1, float y1, float x2, float y2, boolean dashed, boolean arrow) { this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; this.dashed = dashed; this.arrow = arrow; }
    }

    private final Activity a;
    private final AttackView view;
    private final Navigator nav;
    private final Runnable onChanged;
    private final float d;
    private Dialog screen;
    private FrameLayout graph;
    private Flow flow;

    private FlowDialog(Activity a, AttackView view, Navigator nav, Runnable onChanged) {
        this.a = a; this.view = view; this.nav = nav; this.onChanged = onChanged;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    /** Calcula o fluxo em segundo plano (com loading) e abre o grafico. */
    static void show(final Activity a, final AttackView view, final Navigator nav, final Runnable onChanged) {
        final AttackData ad = view.attackData();
        if (ad == null || ad.move == null || ad.move.generic) { I18nUi.toast(a, "Este ataque não tem fluxo de golpe (HDAT 4).", Toast.LENGTH_SHORT).show(); return; }
        final FlowDialog fd = new FlowDialog(a, view, nav, onChanged);
        fd.refresh(true);
    }

    /** Recalcula (pesado, em segundo plano) e (re)desenha. */
    private void refresh(final boolean first) {
        final AttackData ad = view.attackData();
        final BusyDialog busy = BusyDialog.show(a, "Calculando o fluxo do golpe");
        busy.set("Simulando as ANOs...", 0, 0);
        new Thread(new Runnable() {
            @Override public void run() {
                Flow f = null;
                try { f = compute(view, ad); } catch (Throwable t) { /* aviso abaixo */ }
                busy.dismiss();
                final Flow ff = f;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (ff == null) { I18nUi.toast(a, "Não consegui calcular o fluxo.", Toast.LENGTH_SHORT).show(); return; }
                        flow = ff;
                        if (first) open();
                        render();
                    }
                });
            }
        }).start();
    }

    /** A ANO tem algum frame com hitbox flag 0 (lancamento de projetil)? */
    private static boolean launches(Dac dac, int ano) {
        if (dac == null || ano <= 0) return false;
        Ano an = dac.getAno(ano);
        if (an == null || !an.present) return false;
        for (Ano.Mpt m : an.mpts) {
            if (m.hits == null) continue;
            for (Ano.Hit h : m.hits) if (h.flag == 0) return true;
        }
        return false;
    }

    private static Flow compute(AttackView view, AttackData ad) {
        CharData.Move mv = ad.move;
        Flow f = new Flow();
        f.init = mv.animInicial > 0 ? mv.animInicial : view.currentAnoIndex();
        f.seqC = mv.animSeqChao; f.seqA = mv.animSeqAr; f.endC = mv.animEndChao; f.endA = mv.animEndAr;
        f.ao = mv.animAoAcertar;
        com.zue.attackeditor.Dac dac = view.packDac(2);
        f.projSeqC = launches(dac, f.seqC); f.projSeqA = launches(dac, f.seqA);
        f.projEndC = launches(dac, f.endC); f.projEndA = launches(dac, f.endA);
        if (launches(dac, f.init)) f.projLevel = 0;
        else if (f.projSeqC || f.projSeqA) f.projLevel = 1;
        else if (f.projEndC || f.projEndA) f.projLevel = 2;
        int[] anos = {f.init, f.seqC, f.seqA, f.ao};
        for (int ano : anos) {
            if (ano <= 0 || f.stop.containsKey(Integer.valueOf(ano))) continue;
            int best = -1;
            for (BattleSim.HitEvent e : view.probeHits(ano)) {
                if (e.kind > SeqMark.HIT || e.ano != ano || e.blocked) continue;
                if (best < 0 || e.pat < best) best = e.pat;
            }
            f.stop.put(Integer.valueOf(ano), Integer.valueOf(best));
        }
        return f;
    }

    // ------------------------------------------------------------------ ajudas de interface

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout header(String title, View.OnClickListener close) {
        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv(title, 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(close);
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        return h;
    }

    private void open() {
        screen = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        screen.setContentView(root);
        root.addView(header("Fluxo do golpe", new View.OnClickListener() { public void onClick(View v) { screen.dismiss(); } }));
        TextView hint = tv("Toque numa miniatura para ampliar, ir para a ANO ou trocá-la. Slots vazios (tracejados) podem ser definidos. "
                + "Seta tracejada: o slot está vazio e o fluxo desvia para o outro; no jogo, um slot vazio simplesmente não troca de ANO. "
                + "SEQ_PROJETIL (AO ACERTAR no Bin) é a sequência do projétil: fica logo depois da ANO que lança o projétil; sem projétil no golpe (ou sem ela definida) fica isolada.", 11, LayoutManager.DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(8));
        root.addView(hint);
        ScrollView sv = new ScrollView(a);
        graph = new FrameLayout(a);
        sv.addView(graph, new ViewGroup.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(button("VOLTAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { screen.dismiss(); } }));
        screen.show();
    }

    // ------------------------------------------------------------------ grafico

    /** Desenha as ligacoes (atras dos cartoes). */
    private final class Links extends View {
        final List<Link> list = new ArrayList<Link>();
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Links() { super(a); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); }
        @Override protected void onDraw(Canvas c) {
            for (Link l : list) {
                p.setStyle(Paint.Style.STROKE);
                p.setColor(l.dashed ? LayoutManager.ACCENT : 0xFF5A6275);
                p.setPathEffect(l.dashed ? new android.graphics.DashPathEffect(new float[]{dp(6), dp(5)}, 0) : null);
                c.drawLine(l.x1, l.y1, l.x2, l.y2, p);
                if (l.arrow) {
                    p.setPathEffect(null);
                    p.setStyle(Paint.Style.FILL);
                    double ang = Math.atan2(l.y2 - l.y1, l.x2 - l.x1);
                    float s = dp(7);
                    Path t = new Path();
                    t.moveTo(l.x2, l.y2);
                    t.lineTo((float) (l.x2 - s * Math.cos(ang - 0.5)), (float) (l.y2 - s * Math.sin(ang - 0.5)));
                    t.lineTo((float) (l.x2 - s * Math.cos(ang + 0.5)), (float) (l.y2 - s * Math.sin(ang + 0.5)));
                    t.close();
                    c.drawPath(t, p);
                }
            }
        }
    }

    private void render() {
        graph.removeAllViews();
        final Flow f = flow;
        int wpx = a.getResources().getDisplayMetrics().widthPixels - dp(20);
        int gap = dp(12), cw = (wpx - 3 * gap) / 2, ch = dp(158), vgap = dp(34), top = dp(6);
        int[] colX = {gap, 2 * gap + cw, (wpx - cw) / 2};
        Links links = new Links();
        graph.addView(links, new FrameLayout.LayoutParams(wpx, top + 4 * ch + 3 * vgap + dp(10)));

        boolean merged = f.seqC > 0 && f.seqC == f.seqA;
        boolean endMerged = merged && f.endC > 0 && f.endC == f.endA;
        // AO ACERTAR (sequencia de projetil): so entra na ramificacao se existe no Bin e algum ANO do golpe lanca projetil
        boolean linked = f.ao > 0 && f.projLevel >= 0;
        int rowSeq = 1 + (linked && f.projLevel == 0 ? 1 : 0);
        int rowEnd = rowSeq + 1 + (linked && f.projLevel == 1 ? 1 : 0);
        int rowAo = !linked ? 3 : f.projLevel == 0 ? 1 : f.projLevel == 1 ? rowSeq + 1 : rowEnd + 1;
        List<Slot> slots = new ArrayList<Slot>();
        slots.add(slot(F_INIT, 0, 2, "ANIM INICIAL", f.init, false));
        if (merged) slots.add(slot(F_SEQ_BOTH, rowSeq, 2, "SEQ CHÃO E AR", f.seqC, false));
        else {
            slots.add(slot(F_SEQ_C, rowSeq, 0, "SEQ CHÃO", f.seqC, false));
            slots.add(slot(F_SEQ_A, rowSeq, 1, "SEQ AR", f.seqA, false));
        }
        if (endMerged) slots.add(slot(F_END_BOTH, rowEnd, 2, "END CHÃO E AR", f.endC, false));
        else {
            slots.add(slot(F_END_C, rowEnd, 0, "END CHÃO", f.endC, f.seqC <= 0));
            slots.add(slot(F_END_A, rowEnd, 1, "END AR", f.endA, f.seqA <= 0));
        }
        Slot aoSlot = slot(F_AO, rowAo, 2, "SEQ_PROJETIL", f.ao, false);
        aoSlot.isolated = !linked;
        slots.add(aoSlot);

        for (Slot s : slots) graph.addView(card(s, cw, ch), pos(colX[s.col], top + s.level * (ch + vgap), cw, ch));

        float cxMid = colX[2] + cw / 2f;
        float bInit = top + ch;                                      // base do cartao inicial
        // inicial -> (AO) -> SEQ
        float seqTop = top + rowSeq * (ch + vgap);
        float parentY = bInit;
        float parentX = cxMid;
        if (linked && f.projLevel == 0) {
            float aoTop = top + rowAo * (ch + vgap);
            links.list.add(new Link(cxMid, bInit, cxMid, aoTop, false, true));
            parentY = aoTop + ch;
        }
        for (Slot s : slots) {
            if (s.field >= F_SEQ_C && s.field <= F_SEQ_BOTH) {
                float cx = colX[s.col] + cw / 2f;
                links.list.add(new Link(parentX, parentY, cx, seqTop, s.ano <= 0, true));
            } else if (s.field >= F_END_C && s.field <= F_END_BOTH) {
                float cx = colX[s.col] + cw / 2f;
                float px = merged ? cxMid : cx;
                float endTop = top + rowEnd * (ch + vgap);
                float from = top + rowSeq * (ch + vgap) + ch;
                links.list.add(new Link(px, from, cx, endTop, s.ano <= 0 || s.disabled, true));
            }
        }
        // projetil lancado numa SEQ ou END: a seta sai do cartao que lanca e vai para a SEQ_PROJETIL
        if (linked && f.projLevel >= 1) {
            float aoTop = top + rowAo * (ch + vgap);
            for (Slot s : slots) {
                boolean from;
                if (f.projLevel == 1) from = (s.field == F_SEQ_BOTH && (f.projSeqC || f.projSeqA)) || (s.field == F_SEQ_C && f.projSeqC) || (s.field == F_SEQ_A && f.projSeqA);
                else from = (s.field == F_END_BOTH && (f.projEndC || f.projEndA)) || (s.field == F_END_C && f.projEndC) || (s.field == F_END_A && f.projEndA);
                if (!from) continue;
                links.list.add(new Link(colX[s.col] + cw / 2f, top + s.level * (ch + vgap) + ch, cxMid, aoTop, false, true));
            }
        }
        // desvios: slot vazio -> o outro (na SEQ: um define e o outro nao; na END com SEQ unica: um End so)
        if (!merged && (f.seqC > 0) != (f.seqA > 0)) {
            boolean emptyIsC = f.seqC <= 0;
            float y = top + rowSeq * (ch + vgap) + ch / 2f;
            links.list.add(emptyIsC ? new Link(colX[0] + cw, y, colX[1], y, true, true) : new Link(colX[1], y, colX[0] + cw, y, true, true));
        }
        if (merged && !endMerged && (f.endC > 0) != (f.endA > 0)) {
            boolean emptyIsC = f.endC <= 0;
            float y = top + rowEnd * (ch + vgap) + ch / 2f;
            links.list.add(emptyIsC ? new Link(colX[0] + cw, y, colX[1], y, true, true) : new Link(colX[1], y, colX[0] + cw, y, true, true));
        }
        links.invalidate();
    }

    private Slot slot(int field, int level, int col, String label, int ano, boolean disabled) {
        Slot s = new Slot();
        s.field = field; s.level = level; s.col = col; s.label = label; s.ano = ano; s.disabled = disabled;
        return s;
    }

    private FrameLayout.LayoutParams pos(int x, int y, int w, int h) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
        lp.leftMargin = x;
        lp.topMargin = y;
        return lp;
    }

    private View card(final Slot s, int cw, int ch) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL);
        g.setCornerRadius(dp(10));
        boolean empty = s.ano <= 0;
        if (empty || s.isolated) g.setStroke(dp(2), s.field == F_AO ? TimelineView.C_HIT : 0xFF5A6275, dp(6), dp(4));
        else if (s.field == F_AO) g.setStroke(dp(2), TimelineView.C_HIT);
        else g.setStroke(dp(2), s.field == F_INIT ? LayoutManager.ACCENT : (s.field >= F_SEQ_C && s.field <= F_SEQ_BOTH) ? TimelineView.C_SEQ : TimelineView.C_END);
        c.setBackground(g);
        if (s.disabled) c.setAlpha(0.45f);
        TextView t = tv(s.label, 11, LayoutManager.TEXT, true);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        int side = dp(84);
        if (empty) {
            String et = s.disabled ? "defina a SEQ antes" : s.field == F_AO ? (flow.projLevel < 0 ? "isolado\nexige um projétil\nem algum ANO do golpe" : "isolado\n+ definir") : "vazio\n+ definir";
            TextView e = tv(et, 11, LayoutManager.DIM, false);
            e.setGravity(Gravity.CENTER);
            c.addView(e, new LinearLayout.LayoutParams(side, side));
        } else {
            AnimPreview pv = thumb(s.ano, side);
            c.addView(pv, new LinearLayout.LayoutParams(side, side));
        }
        Integer sp = flow.stop.get(Integer.valueOf(s.ano));
        String sub = empty ? "" : "ANO " + s.ano + (sp != null && sp >= 0 && s.field <= F_SEQ_BOTH ? "  ·  frame " + (sp + 1) : "")
                + (s.field == F_AO && s.isolated ? "  ·  sem projétil" : "");
        TextView st = tv(sub, 10, LayoutManager.DIM, false);
        st.setGravity(Gravity.CENTER);
        st.setSingleLine(true);
        c.addView(st);
        c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { expand(s); } });
        return c;
    }

    private AnimPreview thumb(int ano, int side) {
        AnimPreview pv = new AnimPreview(a);
        pv.set(view.packDac(2), view.packSprites(2), ano);
        Integer sp = flow.stop.get(Integer.valueOf(ano));
        pv.setPlayUntil(sp == null ? -1 : sp);
        pv.setAutoReplay(true);
        return pv;
    }

    // ------------------------------------------------------------------ no ampliado

    private void expand(final Slot s) {
        if (s.disabled) { I18nUi.toast(a, "Defina antes a SEQ correspondente.", Toast.LENGTH_SHORT).show(); return; }
        final Dialog big = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        big.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        final boolean empty = s.ano <= 0;
        box.addView(header(s.label + (empty ? "  ·  vazio" : "  ·  ANO " + s.ano), new View.OnClickListener() { public void onClick(View v) { big.dismiss(); } }));
        int side = Math.min(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.8f), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.40f));
        if (!empty) {
            final AnimPreview pv = thumb(s.ano, side);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(side, side);
            pl.gravity = Gravity.CENTER_HORIZONTAL;
            pl.setMargins(0, dp(8), 0, dp(4));
            pv.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pv.replay(); } });
            pv.setOpponent(view.opponentDac(), view.opponentSprites());
            box.addView(pv, pl);
            box.addView(AnimPreview.switchBar(a, pv));
            Integer sp = flow.stop.get(Integer.valueOf(s.ano));
            TextView hint = tv(s.field == F_AO ? "Entra quando o primeiro acerto de cada projétil conecta; a SEQ vem logo em seguida, a não ser que o primeiro frame desta ANO tenha uma hitbox flag 38. Toque para ver de novo." : sp != null && sp >= 0 ? "Toca até o frame " + (sp + 1) + ", onde ocorre a transição, e trava. Toque para ver de novo." : "Toque na prévia para ver de novo.", 11, LayoutManager.DIM, false);
            hint.setGravity(Gravity.CENTER);
            box.addView(hint);
            LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(-1, -2);
            b1.setMargins(0, dp(8), 0, 0);
            box.addView(button("IR PARA ANO " + s.ano, LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) {
                big.dismiss();
                if (screen != null) screen.dismiss();
                if (nav != null) nav.openAno(s.ano, false);
            } }), b1);
        } else {
            TextView e = tv("Este slot está vazio: nenhuma ANO definida.", 13, LayoutManager.DIM, false);
            e.setPadding(0, dp(14), 0, dp(10));
            box.addView(e);
        }
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.setMargins(0, dp(8), 0, 0);
        if (s.field == F_SEQ_BOTH || s.field == F_END_BOTH) {
            final boolean seq = s.field == F_SEQ_BOTH;
            String[] names = seq ? new String[]{"Mudar Seq Chão", "Mudar Seq Ar"} : new String[]{"Mudar End Chão", "Mudar End Ar"};
            final int[] fields = seq ? new int[]{F_SEQ_C, F_SEQ_A} : new int[]{F_END_C, F_END_A};
            final String[] labels = seq ? new String[]{"SEQ CHÃO", "SEQ AR"} : new String[]{"END CHÃO", "END AR"};
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < 2; i++) {
                final int k = i;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                lp.setMargins(i == 0 ? 0 : dp(4), 0, i == 0 ? dp(4) : 0, 0);
                row.addView(button(names[i], LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
                    big.dismiss();
                    pickAno(slot(fields[k], s.level, k, labels[k], s.ano, false));
                } }), lp);
            }
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
            rl.setMargins(0, dp(8), 0, 0);
            box.addView(row, rl);
        } else {
            box.addView(button(empty ? "DEFINIR ANO" : "TROCAR ANO", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
                big.dismiss();
                pickAno(s);
            } }), b2);
        }
        if (!empty && s.field != F_INIT) {
            LinearLayout.LayoutParams b3 = new LinearLayout.LayoutParams(-1, -2);
            b3.setMargins(0, dp(8), 0, 0);
            box.addView(button("LIMPAR SLOT", LayoutManager.WARN, new View.OnClickListener() { public void onClick(View v) { big.dismiss(); apply(s, 0); } }), b3);
        }
        big.setContentView(box);
        big.show();
        if (big.getWindow() != null) {
            big.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            big.getWindow().setLayout(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.94f), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private void pickAno(final Slot s) {
        if (s.field == F_AO && flow.projLevel < 0) {
            I18nUi.toast(a, "A SEQ_PROJETIL (AO ACERTAR) exige um projétil: adicione antes um projétil (hitbox flag 0) em um dos ANOs do golpe.", Toast.LENGTH_LONG).show();
            return;
        }
        AnoPicker.show(a, view.packDac(2), view.packSprites(2), false, s.ano, (s.ano > 0 ? "Trocar ANO · " : "Definir ANO · ") + s.label, s.field != F_INIT, view.opponentDac(), view.opponentSprites(), new AnoPicker.Listener() {
            @Override public void onPick(int ano) { apply(s, ano); }
        });
    }

    /** Grava no golpe (HDAT 4) e recalcula o grafico. */
    private void apply(final Slot s, final int ano) {
        final Flow f = flow;
        if (ano > 0) {
            if ((s.field == F_SEQ_C || s.field == F_SEQ_A || s.field == F_SEQ_BOTH) && ano == f.init) { I18nUi.toast(a, "A SEQ não pode apontar para a ANO inicial.", Toast.LENGTH_SHORT).show(); return; }
            if (s.field == F_END_BOTH && ano == f.seqC || s.field == F_END_C && ano == f.seqC || s.field == F_END_A && ano == f.seqA) { I18nUi.toast(a, "A END não pode apontar para a própria SEQ.", Toast.LENGTH_SHORT).show(); return; }
        }
        view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) {
            switch (s.field) {
                case F_INIT: if (ano > 0) mv.animInicial = ano; break;
                case F_SEQ_C: mv.animSeqChao = ano; break;
                case F_SEQ_A: mv.animSeqAr = ano; break;
                case F_SEQ_BOTH: mv.animSeqChao = ano; mv.animSeqAr = ano; break;
                case F_AO: mv.animAoAcertar = ano; break;
                case F_END_C: mv.animEndChao = ano; break;
                case F_END_BOTH: mv.animEndChao = ano; mv.animEndAr = ano; break;
                default: mv.animEndAr = ano; break;
            }
        } });
        if (onChanged != null) onChanged.run();
        refresh(false);
    }
}
