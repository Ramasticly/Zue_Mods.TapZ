package com.zue.attackeditor;

import java.util.List;

/** Escolhas da recarga das pastas (botao ↻): qual item da lista nova corresponde ao que estava selecionado. Java puro. */
final class FolderReload {
    private FolderReload() { }

    /** Indice de {@code previous} na lista nova; se a pasta sumiu (ou nao havia selecao) o primeiro; lista vazia = -1. */
    static int resolve(List<String> names, String previous) {
        if (names == null || names.isEmpty()) return -1;
        int i = previous == null ? -1 : names.indexOf(previous);
        return i >= 0 ? i : 0;
    }

    /** A pasta anterior ainda existe na lista nova? */
    static boolean kept(List<String> names, String previous) {
        return names != null && previous != null && names.contains(previous);
    }

    /** Indice de golpe/ANO limitado ao tamanho novo (-1 se nao ha nada). */
    static int clamp(int index, int size) {
        if (size <= 0) return -1;
        return index < 0 ? 0 : Math.min(index, size - 1);
    }
}
