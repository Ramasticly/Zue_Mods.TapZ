package com.zue.attackeditor;

import java.util.TreeSet;

/**
 * Copiar, excluir e colar Frames de uma ANO (tela "Ver Frames" do menu do ANO). Java puro. Os Frames copiados ficam numa area de transferencia estatica ({@link #current})
 * que vale entre ANOs do mesmo personagem ({@code owner}).
 */
final class FrameClip {
    /** Frames copiados (copias profundas, na ordem em que estavam na ANO). */
    final Ano.Mpt[] frames;
    /** Quem copiou (o personagem): a cola so vale para o mesmo. */
    final Object owner;
    final int fromAno;

    private FrameClip(Ano.Mpt[] frames, Object owner, int fromAno) { this.frames = frames; this.owner = owner; this.fromAno = fromAno; }

    /** Area de transferencia compartilhada (null = vazia). */
    static FrameClip current;

    /** Indices validos, sem repeticao e em ordem crescente. */
    static int[] normalize(Ano.Mpt[] mp, int[] sel) {
        TreeSet<Integer> t = new TreeSet<Integer>();
        if (mp != null && sel != null) for (int i : sel) if (i >= 0 && i < mp.length) t.add(Integer.valueOf(i));
        int[] r = new int[t.size()];
        int k = 0;
        for (Integer i : t) r[k++] = i.intValue();
        return r;
    }

    /** Copia dos Frames {@code sel}; null se nao ha nenhum valido. */
    static FrameClip copy(Ano.Mpt[] mp, int[] sel, Object owner, int fromAno) {
        int[] s = normalize(mp, sel);
        if (s.length == 0) return null;
        Ano.Mpt[] f = new Ano.Mpt[s.length];
        for (int k = 0; k < s.length; k++) f[k] = mp[s[k]].copy();
        return new FrameClip(f, owner, fromAno);
    }

    /** Lista sem os Frames {@code sel}; null se nao ha o que apagar ou se apagaria a ANO inteira (tem de sobrar pelo menos um Frame). */
    static Ano.Mpt[] delete(Ano.Mpt[] mp, int[] sel) {
        int[] s = normalize(mp, sel);
        if (s.length == 0 || s.length >= mp.length) return null;
        boolean[] del = new boolean[mp.length];
        for (int i : s) del[i] = true;
        Ano.Mpt[] out = new Ano.Mpt[mp.length - s.length];
        for (int k = 0, o = 0; k < mp.length; k++) if (!del[k]) out[o++] = mp[k];
        return out;
    }

    /**
     * Lista com copias novas dos Frames do clip inseridas na posicao {@code pos} (0 = antes do primeiro, mp.length = depois do ultimo). Frame sem TIME fica parado para
     * sempre, entao quem deixa de ser o ultimo ganha o tempo que a timeline mostra ({@link FrameOps#timed}). Devolve a mesma lista se nao deu.
     */
    static Ano.Mpt[] paste(Ano.Mpt[] mp, int pos, FrameClip c) {
        if (mp == null || mp.length == 0 || c == null || c.frames.length == 0) return mp;
        int p = Math.max(0, Math.min(mp.length, pos));
        Ano.Mpt[] out = new Ano.Mpt[mp.length + c.frames.length];
        System.arraycopy(mp, 0, out, 0, p);
        for (int k = 0; k < c.frames.length; k++) out[p + k] = c.frames[k].copy();
        System.arraycopy(mp, p, out, p + c.frames.length, mp.length - p);
        for (int k = 0; k < out.length - 1; k++) out[k] = FrameOps.timed(out[k]);
        return out;
    }
}
