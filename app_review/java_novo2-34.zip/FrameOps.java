package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Operacoes de edicao sobre a lista de MPTs, no estilo de editor de video (dividir, aparar, mover, duplicar).
 * Tudo devolve arrays novos (nunca altera o original) para o desfazer ser trivial.
 */
final class FrameOps {
    private FrameOps() { }

    static final int IMG = 0, HIT = 1, SOM = 2, MOV = 3, OPT = 4, RAZ = 5, FLG = 6, LNK = 7;

    /** Duracao mostrada/usada na linha do tempo (frame sem tempo conta 3 ticks). */
    static int span(Ano.Mpt m) {
        int d = m.hasTime ? m.time : 0;
        return d > 0 ? d : 3;
    }

    /** O indice e de um frame que existe? Todo indice que vem da tela (selecao, ponteiro) passa por aqui: -1 = nenhum frame. */
    static boolean ok(Ano.Mpt[] m, int i) { return m != null && i >= 0 && i < m.length; }

    static int[] starts(Ano.Mpt[] m) {
        int[] s = new int[m.length];
        int acc = 0;
        for (int i = 0; i < m.length; i++) { s[i] = acc; acc += span(m[i]); }
        return s;
    }

    static int total(Ano.Mpt[] m) {
        int acc = 0;
        for (int i = 0; i < m.length; i++) acc += span(m[i]);
        return acc;
    }

    /** Frame que contem o tick, ou -1. */
    static int frameAt(Ano.Mpt[] m, int tick) {
        int acc = 0;
        for (int i = 0; i < m.length; i++) {
            int e = acc + span(m[i]);
            if (tick >= acc && tick < e) return i;
            acc = e;
        }
        return -1;
    }

    // ---- propriedades "keyframe" ----

    static boolean has(int track, Ano.Mpt m) {
        switch (track) {
            case SOM: return (m.flags & 8) != 0;
            case MOV: return (m.flags & 4) != 0;
            case OPT: return (m.flags & 0x40) != 0;
            case RAZ: return (m.flags & 0x80) != 0;
            case FLG: return (m.flags & 2) != 0;
            default: return false;
        }
    }

    static void clear(int track, Ano.Mpt m) {
        switch (track) {
            case SOM: m.flags &= ~8; m.se = -1; break;
            case MOV: m.flags &= ~4; m.moveMask = 0; m.speedX = m.speedY = m.accelX = m.accelY = 0; break;
            case OPT: m.flags &= ~0x40; m.optFlag = 0; for (int i = 0; i < 4; i++) m.optData[i] = 0; break;
            case RAZ: m.flags &= ~0x80; m.rot = 0; m.alphaRaw = 0; m.xZoom = 100; m.yZoom = 100; break;
            case FLG: m.flags &= ~2; m.wActFlag = 0; break;
            default: break;
        }
        m.normalize();
    }

    static void defaults(int track, Ano.Mpt m) {
        switch (track) {
            case SOM: m.flags |= 8; m.se = 0; break;
            case MOV: m.flags |= 4; m.moveMask = 1; m.speedX = 0; break;
            case OPT: m.flags |= 0x40; m.optFlag = 0; for (int i = 0; i < 4; i++) m.optData[i] = 0; break;
            case RAZ: m.flags |= 0x80; m.rot = 0; m.alphaRaw = 0; m.xZoom = 100; m.yZoom = 100; break;
            case FLG: m.flags |= 2; m.wActFlag = 0; break;
            default: break;
        }
        m.normalize();
    }

    static void copyProp(int track, Ano.Mpt src, Ano.Mpt dst) {
        switch (track) {
            case SOM: dst.flags |= 8; dst.se = src.se; break;
            case MOV: dst.flags |= 4; dst.moveMask = src.moveMask; dst.speedX = src.speedX; dst.speedY = src.speedY;
                dst.accelX = src.accelX; dst.accelY = src.accelY; break;
            case OPT: dst.flags |= 0x40; dst.optFlag = src.optFlag; for (int i = 0; i < 4; i++) dst.optData[i] = src.optData[i]; break;
            case RAZ: dst.flags |= 0x80; dst.rot = src.rot; dst.alphaRaw = src.alphaRaw; dst.xZoom = src.xZoom; dst.yZoom = src.yZoom; break;
            case FLG: dst.flags |= 2; dst.wActFlag = src.wActFlag; break;
            default: break;
        }
        dst.normalize();
    }

    // ---- dividir / duplicar / apagar ----

    static final class Split {
        Ano.Mpt[] mpts;
        int index;      // frame que comeca exatamente no tick
        boolean changed;
    }

    /** Garante um limite de frame em {@code tick}. null se o tick esta fora ou o frame nao pode ser dividido. */
    static Split splitAt(Ano.Mpt[] m, int tick) {
        int[] st = starts(m);
        int i = frameAt(m, tick);
        if (i < 0) return null;
        Split r = new Split();
        if (st[i] == tick) { r.mpts = m; r.index = i; return r; }
        int dur = m[i].hasTime ? m[i].time : 0;
        int k = tick - st[i];
        if (dur < 2 || k < 1 || k >= dur) return null;
        Ano.Mpt a = m[i].copy(), b = m[i].copy();
        a.flags |= 0x20; b.flags |= 0x20;
        a.time = k; b.time = dur - k;
        boolean mv = (m[i].flags & 4) != 0;
        // eventos de um tick so (som, OPT) ficam na primeira metade
        b.flags &= ~(8 | 0x40);
        b.se = -1; b.optFlag = 0;
        for (int q = 0; q < 4; q++) b.optData[q] = 0;
        // projetil, cutscene, dano em si e teleportes disparam uma vez por frame: a segunda metade nao repete
        if ((b.flags & 0x10) != 0 && b.hits != null) {
            java.util.ArrayList<Ano.Hit> keep = new java.util.ArrayList<Ano.Hit>();
            for (Ano.Hit h : b.hits) if (!oneShot(h.flag)) keep.add(h);
            if (keep.size() != b.hits.length) {
                b.hits = keep.toArray(new Ano.Hit[keep.size()]);
                if (b.hits.length == 0) b.flags &= ~0x10;
            }
        }
        // fim/repeticao so valem no fim do frame original
        a.wActFlag &= ~3;
        if (mv) {
            // a velocidade continua (flag 64) e a aceleracao e reaplicada
            b.flags |= 2;
            b.wActFlag |= 64;
            b.moveMask &= 12;
            b.speedX = b.speedY = 0;
            if (b.moveMask == 0) b.flags &= ~4;
        }
        a.normalize();
        b.normalize();
        Ano.Mpt[] out = new Ano.Mpt[m.length + 1];
        System.arraycopy(m, 0, out, 0, i);
        out[i] = a;
        out[i + 1] = b;
        System.arraycopy(m, i + 1, out, i + 2, m.length - i - 1);
        r.mpts = out;
        r.index = i + 1;
        r.changed = true;
        return r;
    }

    // ---- loop do ANO ----

    private static boolean loopBit(Ano.Mpt m) { return (m.flags & 2) != 0 && (m.wActFlag & ObjModel.LOOP) != 0; }

    /**
     * O loop e do ANO, nao de um frame: se estava ligado no ultimo frame de {@code before}, depois de uma edicao
     * (apagar, adicionar, duplicar, dividir...) ele fica so no ultimo frame de {@code after}. Quem desliga o loop e o usuario
     * (ObjModel.setLoop), que nao passa por aqui. O bit 2 (fim) acompanha. Devolve {@code after} se nada muda.
     */
    static Ano.Mpt[] normalizeLoop(Ano.Mpt[] before, Ano.Mpt[] after) {
        if (before == null || after == null || before.length == 0 || after.length == 0) return after;
        Ano.Mpt oldLast = before[before.length - 1];
        if (!loopBit(oldLast)) return after;
        int last = after.length - 1;
        boolean ok = loopBit(after[last]);
        for (int i = 0; i < last && ok; i++) if (loopBit(after[i])) ok = false;
        if (ok) return after;
        Ano.Mpt[] out = after.clone();
        int bits = ObjModel.LOOP | (oldLast.wActFlag & 2);
        for (int i = 0; i < out.length; i++) {
            if (i == last || !loopBit(out[i])) continue;
            Ano.Mpt c = out[i].copy();
            c.wActFlag &= ~bits;
            if (c.wActFlag == 0) c.flags &= ~2;
            c.normalize();
            out[i] = c;
        }
        Ano.Mpt c = out[last].copy();
        c.flags |= 2;
        c.wActFlag |= bits;
        c.normalize();
        out[last] = c;
        return out;
    }

    /** Onde o ponteiro fica ao clicar num clipe [t0, t1): dentro dele, onde esta; antes, no inicio; depois, no ultimo tick do clipe. */
    static int clipTarget(int tick, int t0, int t1) {
        if (t1 <= t0) return t0;
        if (tick < t0) return t0;
        if (tick >= t1) return t1 - 1;
        return tick;
    }

    /** Hits que disparam uma unica vez ao entrar no frame (projetil, cutscene, dano em si, teleportes). */
    static boolean oneShot(int flag) { return flag == 0 || flag == 20 || flag == 32 || flag == 39 || flag == 40; }

    /** Duplica so o sprite: imagem, tempo, deslocamento e estilo. Hits, efeitos, som, velocidade e opcoes nao vao junto. */
    static Ano.Mpt[] duplicate(Ano.Mpt[] m, int i) {
        if (!ok(m, i)) return m;
        Ano.Mpt[] out = new Ano.Mpt[m.length + 1];
        System.arraycopy(m, 0, out, 0, i + 1);
        out[i] = timed(m[i]);
        Ano.Mpt c = m[i].copy();
        if (i < m.length - 1) { c.flags |= 0x20; c.time = out[i].time; }      // no meio da ANO a copia nao pode travar a animacao
        // a copia nao repete som, fim, hits (hitbox, hurtbox, efeitos, acoes), velocidade nem opcoes
        c.flags &= ~8; c.se = -1;
        c.wActFlag &= ~3;
        c.hits = Ano.NO_HITS;
        c.flags &= ~0x10;
        clear(MOV, c);
        clear(OPT, c);
        c.normalize();
        out[i + 1] = c;
        System.arraycopy(m, i + 1, out, i + 2, m.length - i - 1);
        return out;
    }

    /**
     * Frame sem TIME fica parado para sempre no jogo: nada depois dele e alcancado (nem o ponteiro da timeline chega la).
     * Ao colocar um sprite depois dele, o frame passa a durar o que a timeline mostra (3 ticks) e o sprite novo vira o que segura.
     */
    static Ano.Mpt timed(Ano.Mpt m) {
        if (m.hasTime && m.time > 0) return m;
        Ano.Mpt c = m.copy();
        c.flags |= 0x20;
        c.time = span(m);
        c.normalize();
        return c;
    }

    static Ano.Mpt[] delete(Ano.Mpt[] m, int i) {
        if (!ok(m, i) || m.length <= 1) return null;
        Ano.Mpt[] out = new Ano.Mpt[m.length - 1];
        for (int k = 0, o = 0; k < m.length; k++) if (k != i) out[o++] = m[k];
        return out;
    }

    static Ano.Mpt[] move(Ano.Mpt[] m, int i, int j) {
        if (!ok(m, i) || j < 0 || j >= m.length || i == j) return null;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt x = out[i];
        if (j > i) System.arraycopy(out, i + 1, out, i, j - i); else System.arraycopy(out, j, out, j + 1, i - j);
        out[j] = x;
        return out;
    }

    static Ano.Mpt[] setDuration(Ano.Mpt[] m, int i, int dur) {
        if (!ok(m, i)) return m;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt c = m[i].copy();
        c.flags |= 0x20;
        c.time = Math.max(1, Math.min(255, dur));
        c.normalize();
        out[i] = c;
        return out;
    }

    // ---- keyframes ----

    /** Cria (ou reaproveita) um keyframe no tick: divide o frame se preciso. */
    static Split addKey(Ano.Mpt[] m, int track, int tick) {
        Split s = splitAt(m, tick);
        if (s == null) return null;
        Ano.Mpt[] out = s.mpts == m ? m.clone() : s.mpts;
        if (!has(track, out[s.index])) {
            Ano.Mpt c = out[s.index].copy();
            defaults(track, c);
            out[s.index] = c;
            s.changed = true;
        }
        s.mpts = out;
        return s;
    }

    static Ano.Mpt[] moveKey(Ano.Mpt[] m, int track, int from, int to) {
        if (from == to || to < 0 || to >= m.length || from < 0 || from >= m.length) return null;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt d = m[to].copy();
        copyProp(track, m[from], d);
        out[to] = d;
        Ano.Mpt s = m[from].copy();
        clear(track, s);
        out[from] = s;
        return out;
    }

    static Ano.Mpt[] clearKey(Ano.Mpt[] m, int track, int i) {
        if (!ok(m, i)) return m;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt c = m[i].copy();
        clear(track, c);
        out[i] = c;
        return out;
    }

    // ---- trechos de velocidade e de estilo (barra que cobre varios frames) ----

    /** Frame que so continua a velocidade do anterior (manter velocidade, com ou sem aceleracao repetida). */
    static boolean isMoveCont(Ano.Mpt m) {
        return (m.flags & 2) != 0 && (m.wActFlag & 64) != 0 && ((m.flags & 4) == 0 || (m.moveMask & 3) == 0);
    }

    /** Frame que inicia um trecho de velocidade (tem velocidade propria). */
    static boolean isMoveHead(Ano.Mpt m) { return (m.flags & 4) != 0 && !isMoveCont(m); }

    /** Frame de inicio do trecho que contem {@code f}, ou -1. */
    static int moveHeadOf(Ano.Mpt[] m, int f) {
        if (f < 0 || f >= m.length) return -1;
        if (isMoveHead(m[f])) return f;
        if (!isMoveCont(m[f])) return -1;
        int k = f - 1;
        while (k >= 0 && isMoveCont(m[k])) k--;
        return k >= 0 && isMoveHead(m[k]) ? k : -1;
    }

    /** Eixos que o trecho de velocidade da cabeca {@code head} usa: bit 0 = X (speed/accel X), bit 1 = Y. */
    static int moveAxes(Ano.Mpt[] m, int head) {
        if (head < 0 || head >= m.length || (m[head].flags & 4) == 0) return 0;
        int mk = m[head].moveMask;
        return ((mk & 5) != 0 ? 1 : 0) | ((mk & 10) != 0 ? 2 : 0);
    }

    /** Velocidade nova no eixo (0 = X, 1 = Y) para uma celula vazia da faixa daquele eixo. */
    static void defaultsMove(Ano.Mpt m, int axis) {
        m.flags |= 4;
        m.moveMask = axis == 0 ? 1 : 2;
        m.speedX = 0;
        m.speedY = 0;
        m.accelX = 0;
        m.accelY = 0;
        m.normalize();
    }

    static int moveRunEnd(Ano.Mpt[] m, int head) {
        if (!ok(m, head)) return head;
        int j = head;
        while (j + 1 < m.length && isMoveCont(m[j + 1])) j++;
        return j;
    }

    /** Proximo frame (depois de head) que inicia outra velocidade, ou m.length. */
    static int nextMoveHead(Ano.Mpt[] m, int head) {
        if (!ok(m, head)) return m == null ? 0 : m.length;
        for (int j = head + 1; j < m.length; j++) if (isMoveHead(m[j])) return j;
        return m.length;
    }

    /** Trecho de velocidade do frame {@code head} passa a terminar em {@code newLast} (estende ou encolhe; nunca passa de outra velocidade). */
    static Ano.Mpt[] setMoveRun(Ano.Mpt[] m, int head, int newLast) {
        if (!ok(m, head)) return m;
        newLast = Math.max(head, Math.min(newLast, nextMoveHead(m, head) - 1));
        int oldLast = moveRunEnd(m, head);
        Ano.Mpt[] out = m.clone();
        Ano.Mpt h = m[head];
        boolean accel = (h.flags & 4) != 0 && (h.moveMask & 12) != 0;
        for (int f = head + 1; f <= Math.max(newLast, oldLast); f++) {
            Ano.Mpt c = m[f].copy();
            if (f <= newLast) {
                c.flags |= 2;
                c.wActFlag |= 64;
                if (accel) {
                    c.flags |= 4;
                    c.moveMask = h.moveMask & 12;
                    c.speedX = c.speedY = 0;
                    c.accelX = h.accelX;
                    c.accelY = h.accelY;
                } else if ((c.flags & 4) != 0) {
                    c.flags &= ~4;
                    c.moveMask = 0;
                }
            } else {
                c.wActFlag &= ~64;
                if ((c.flags & 4) != 0 && (c.moveMask & 3) == 0) { c.flags &= ~4; c.moveMask = 0; c.accelX = c.accelY = 0; }
                if (c.wActFlag == 0) c.flags &= ~2;
            }
            c.normalize();
            out[f] = c;
        }
        return out;
    }

    /**
     * DIVIDIR um trecho de velocidade no tick: o frame e cortado no tick (se preciso) e o frame do corte vira a CABECA de um novo
     * trecho, com a velocidade que o movimento ja tem ali (speed inicial + accel x ticks), em inteiros 16.16. Fisicamente nada muda.
     * null: tick fora de um trecho de velocidade, ou exatamente no inicio dele (nao ha o que dividir).
     */
    static Split splitMove(Ano.Mpt[] m, int tick) {
        int f = frameAt(m, tick);
        if (f < 0) return null;
        int head = moveHeadOf(m, f);
        if (head < 0) return null;
        int[] st = starts(m);
        if (f == head && st[f] == tick) return null;
        Split s = splitAt(m, tick);
        if (s == null) return null;
        Ano.Mpt[] out = s.mpts == m ? m.clone() : s.mpts;
        int k = s.index;
        if (isMoveHead(out[k])) return null;
        double[] v = FrameTools.startSpeed(out, k);
        Ano.Mpt h = out[head];
        Ano.Mpt c = out[k].copy();
        boolean x = (h.flags & 4) != 0 && (h.moveMask & 1) != 0 || v[0] != 0, y = (h.flags & 4) != 0 && (h.moveMask & 2) != 0 || v[1] != 0;
        if (!x && !y) x = true;
        c.flags |= 4 | 2;
        c.wActFlag |= 64;
        if (x) { c.moveMask |= 1; c.speedX = (int) Math.round(v[0] * FrameTools.ONE); }
        if (y) { c.moveMask |= 2; c.speedY = (int) Math.round(v[1] * FrameTools.ONE); }
        c.normalize();
        out[k] = c;
        s.mpts = out;
        s.index = k;
        s.changed = true;
        return s;
    }

    /** Assinatura do estilo (espelhar, manter velocidade, transformacao) do frame; 0 = sem estilo. */
    static long styleSig(Ano.Mpt m) {
        long s = 0;
        if ((m.flags & 2) != 0) s |= (m.wActFlag & (16 | 32 | 64));
        if ((m.flags & 0x80) != 0) s |= 1024L | ((long) (m.rot & 0xFFF) << 12) | ((long) (m.alphaRaw & 0xFF) << 24)
                | ((long) (m.xZoom & 0xFFF) << 32) | ((long) (m.yZoom & 0xFFF) << 44);
        return s;
    }

    static int styleRunStart(Ano.Mpt[] m, int f) {
        if (!ok(m, f)) return f;
        long s = styleSig(m[f]);
        int k = f;
        while (k > 0 && s != 0 && styleSig(m[k - 1]) == s) k--;
        return k;
    }

    static int styleRunEnd(Ano.Mpt[] m, int f) {
        if (!ok(m, f)) return f;
        long s = styleSig(m[f]);
        int k = f;
        while (k + 1 < m.length && s != 0 && styleSig(m[k + 1]) == s) k++;
        return k;
    }

    /** Estilo do trecho que comeca em {@code first} passa a terminar em {@code newLast}. */
    static Ano.Mpt[] setStyleRun(Ano.Mpt[] m, int first, int newLast) {
        if (!ok(m, first)) return m;
        int oldLast = styleRunEnd(m, first);
        newLast = Math.max(first, Math.min(m.length - 1, newLast));
        Ano.Mpt src = m[first];
        Ano.Mpt[] out = m.clone();
        for (int f = first + 1; f <= Math.max(newLast, oldLast); f++) {
            Ano.Mpt c = m[f].copy();
            if (f <= newLast) {
                if ((src.flags & 2) != 0) {
                    c.flags |= 2;
                    c.wActFlag = (c.wActFlag & ~(16 | 32 | 64)) | (src.wActFlag & (16 | 32 | 64));
                }
                if ((src.flags & 0x80) != 0) copyProp(RAZ, src, c);
            } else {
                c.wActFlag &= ~(16 | 32 | 64);
                if (c.wActFlag == 0) c.flags &= ~2;
                clear(RAZ, c);
            }
            c.normalize();
            out[f] = c;
        }
        return out;
    }

    // ---- hitboxes: um "clipe" e uma sequencia de frames com o mesmo hit (mesma posicao na lista) ----

    static final class Run {
        int lane, f0, f1;
    }

    static List<Run> hitRuns(Ano.Mpt[] m) {
        int maxLane = 0;
        for (int i = 0; i < m.length; i++) if ((m[i].flags & 0x10) != 0) maxLane = Math.max(maxLane, m[i].hits.length);
        List<Run> out = new ArrayList<Run>();
        for (int lane = 0; lane < maxLane; lane++) {
            Run cur = null;
            for (int i = 0; i < m.length; i++) {
                boolean on = (m[i].flags & 0x10) != 0 && m[i].hits.length > lane;
                if (on && cur != null && m[i - 1].hits[lane].flag == m[i].hits[lane].flag) { cur.f1 = i; continue; }
                cur = null;
                if (on) { cur = new Run(); cur.lane = lane; cur.f0 = i; cur.f1 = i; out.add(cur); }
            }
        }
        return out;
    }

    static int runAt(List<Run> runs, int lane, int frame) {
        for (int i = 0; i < runs.size(); i++) {
            Run r = runs.get(i);
            if (r.lane == lane && frame >= r.f0 && frame <= r.f1) return i;
        }
        return -1;
    }

    private static Ano.Hit copyHit(Ano.Hit o) {
        Ano.Hit h = new Ano.Hit();
        h.flag = o.flag; h.x = o.x; h.y = o.y; h.width = o.width; h.height = o.height;
        return h;
    }

    static Ano.Hit defaultHit() {
        Ano.Hit h = new Ano.Hit();
        h.flag = 1; h.x = -16; h.y = -16; h.width = 32; h.height = 32;
        return h;
    }

    /** Estende/encolhe o clipe para [nf0, nf1] (frames). Frames novos recebem uma copia do hit do clipe. */
    static Ano.Mpt[] setRunRange(Ano.Mpt[] m, Run r, int nf0, int nf1) {
        nf0 = Math.max(0, Math.min(m.length - 1, nf0));
        nf1 = Math.max(nf0, Math.min(m.length - 1, nf1));
        Ano.Hit proto = copyHit(m[r.f0].hits[r.lane]);
        Ano.Mpt[] out = m.clone();
        int lo = Math.min(r.f0, nf0), hi = Math.max(r.f1, nf1);
        for (int f = lo; f <= hi; f++) {
            boolean was = f >= r.f0 && f <= r.f1, will = f >= nf0 && f <= nf1;
            if (was == will) continue;
            Ano.Mpt c = m[f].copy();
            if (will) {
                Ano.Hit[] h = new Ano.Hit[c.hits.length + 1];
                int at = Math.min(r.lane, c.hits.length);
                System.arraycopy(c.hits, 0, h, 0, at);
                h[at] = copyHit(proto);
                System.arraycopy(c.hits, at, h, at + 1, c.hits.length - at);
                c.hits = h;
                c.flags |= 0x10;
            } else if (c.hits.length > r.lane) {
                Ano.Hit[] h = new Ano.Hit[c.hits.length - 1];
                for (int k = 0, o = 0; k < c.hits.length; k++) if (k != r.lane) h[o++] = c.hits[k];
                c.hits = h;
                if (h.length == 0) c.flags &= ~0x10;
            }
            c.normalize();
            out[f] = c;
        }
        return out;
    }

    static Ano.Mpt[] deleteRun(Ano.Mpt[] m, Run r) {
        Ano.Mpt[] out = m.clone();
        for (int f = r.f0; f <= r.f1; f++) {
            Ano.Mpt c = m[f].copy();
            if (c.hits.length > r.lane) {
                Ano.Hit[] h = new Ano.Hit[c.hits.length - 1];
                for (int k = 0, o = 0; k < c.hits.length; k++) if (k != r.lane) h[o++] = c.hits[k];
                c.hits = h;
                if (h.length == 0) c.flags &= ~0x10;
            }
            c.normalize();
            out[f] = c;
        }
        return out;
    }

    /** Novo hit na posicao do tick (o frame que o contem): copia o ultimo hit do frame ou do anterior. */
    static Ano.Mpt[] addHit(Ano.Mpt[] m, int frame) {
        if (!ok(m, frame)) return m;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt c = m[frame].copy();
        Ano.Hit proto = null;
        if (c.hits.length > 0) proto = copyHit(c.hits[c.hits.length - 1]);
        else if (frame > 0 && m[frame - 1].hits.length > 0) proto = copyHit(m[frame - 1].hits[m[frame - 1].hits.length - 1]);
        if (proto == null) proto = defaultHit();
        Ano.Hit[] h = new Ano.Hit[c.hits.length + 1];
        System.arraycopy(c.hits, 0, h, 0, c.hits.length);
        h[c.hits.length] = proto;
        c.hits = h;
        c.flags |= 0x10;
        c.normalize();
        out[frame] = c;
        return out;
    }

    // ---- ALL: aplicar as coisas de um frame em outros ----

    static final int A_POS = 1, A_HIT = 2, A_HURT = 4, A_ANIM = 8, A_SOUND = 16, A_FLIP = 32, A_ZOOM = 64, A_ROT = 128,
            A_ALPHA = 256, A_ACTION = 512, A_STYLE = 1024, A_MOVE = 2048, A_TIME = 4096, A_IMAGE = 16384;
    static final int A_DEFAULT = A_POS | A_HIT | A_HURT | A_ANIM | A_SOUND | A_FLIP | A_ZOOM | A_ROT | A_ALPHA;
    static final int A_ALL = A_POS | A_HIT | A_HURT | A_ANIM | A_SOUND | A_FLIP | A_ZOOM | A_ROT | A_ALPHA | A_ACTION | A_STYLE | A_MOVE | A_TIME | A_IMAGE;

    private static boolean selected(int mask, int kind) {
        switch (kind) {
            case ObjModel.HITBOX: return (mask & A_HIT) != 0;
            case ObjModel.HURTBOX: return (mask & A_HURT) != 0;
            case ObjModel.PROJ: case ObjModel.EFFECT: return (mask & A_ANIM) != 0;
            default: return (mask & A_ACTION) != 0;
        }
    }

    /** Frames-alvo: mode 0 = proximos n, 1 = n anteriores, 2 = todos os outros. Devolve {de, ate} (vazio: de > ate). */
    static int[] targetRange(int len, int src, int mode, int n) {
        if (mode == 0) return new int[]{src + 1, Math.min(len - 1, src + Math.max(1, n))};
        if (mode == 1) return new int[]{Math.max(0, src - Math.max(1, n)), src - 1};
        return new int[]{0, len - 1};
    }

    /** Copia do frame {@code src} as coisas marcadas em {@code mask} para os frames de {@code from} a {@code to} (menos o proprio src). */
    static Ano.Mpt[] applyAll(Ano.Mpt[] m, int src, int from, int to, int mask) {
        if (!ok(m, src)) return m;               // sem frame de origem (selecao nao e um sprite): nada a copiar
        Ano.Mpt[] out = m.clone();
        Ano.Mpt s = m[src];
        for (int t = Math.max(0, from); t <= Math.min(m.length - 1, to); t++) {
            if (t == src) continue;
            out[t] = applyTo(s, m[t], mask);
        }
        return out;
    }

    /** Frames que usam a mesma imagem (sprite) do frame {@code src}, menos o proprio (src = -1: nenhum excluido). */
    static int countSprite(Ano.Mpt[] m, int src, int image) {
        int n = 0;
        for (int t = 0; t < m.length; t++) if (t != src && m[t].image == image) n++;
        return n;
    }

    /** Copia as coisas marcadas de {@code s} em todos os frames com a mesma sprite (menos {@code src}, se >= 0). */
    static Ano.Mpt[] applySprite(Ano.Mpt[] m, int src, Ano.Mpt s, int mask) {
        if (s == null) return m;
        Ano.Mpt[] out = m.clone();
        for (int t = 0; t < m.length; t++) {
            if (t == src || m[t].image != s.image) continue;
            out[t] = applyTo(s, m[t], mask);
        }
        return out;
    }

    /** Copia as coisas marcadas de {@code s} sobre {@code t} e devolve o frame novo. */
    static Ano.Mpt applyTo(Ano.Mpt s, Ano.Mpt t0, int mask) {
        {
            Ano.Mpt c = t0.copy();
            if ((mask & A_POS) != 0) {
                if ((s.flags & 1) != 0) { c.flags |= 1; c.midX = s.midX; c.midY = s.midY; }
                else { c.flags &= ~1; c.midX = 0; c.midY = 0; }
            }
            if ((mask & (A_HIT | A_HURT | A_ANIM | A_ACTION)) != 0) {
                ArrayList<Ano.Hit> keep = new ArrayList<Ano.Hit>();
                if ((c.flags & 0x10) != 0) for (Ano.Hit h : c.hits) if (!selected(mask, ObjModel.kindOf(h.flag))) keep.add(h);
                if ((s.flags & 0x10) != 0) for (Ano.Hit h : s.hits) if (selected(mask, ObjModel.kindOf(h.flag))) keep.add(copyHit(h));
                c.hits = keep.toArray(new Ano.Hit[0]);
                if (c.hits.length > 0) c.flags |= 0x10; else { c.flags &= ~0x10; c.hits = Ano.NO_HITS; }
            }
            if ((mask & A_SOUND) != 0) { if ((s.flags & 8) != 0) copyProp(SOM, s, c); else clear(SOM, c); }
            int wMask = ((mask & A_FLIP) != 0 ? ObjModel.FLIP_H | ObjModel.FLIP_V : 0) | ((mask & A_STYLE) != 0 ? ~(ObjModel.FLIP_H | ObjModel.FLIP_V | 3) : 0);
            if (wMask != 0) {
                int sw = (s.flags & 2) != 0 ? s.wActFlag : 0;
                c.wActFlag = (c.wActFlag & ~wMask) | (sw & wMask);
                if (c.wActFlag != 0) c.flags |= 2; else c.flags &= ~2;
            }
            if ((mask & (A_ZOOM | A_ROT | A_ALPHA)) != 0) {
                boolean sr = (s.flags & 0x80) != 0, cr = (c.flags & 0x80) != 0;
                int rot = cr ? c.rot : 0, al = cr ? c.alphaRaw : 0, zx = cr ? c.xZoom : 100, zy = cr ? c.yZoom : 100;
                if ((mask & A_ROT) != 0) rot = sr ? s.rot : 0;
                if ((mask & A_ALPHA) != 0) al = sr ? s.alphaRaw : 0;
                if ((mask & A_ZOOM) != 0) { zx = sr ? s.xZoom : 100; zy = sr ? s.yZoom : 100; }
                if (rot == 0 && al == 0 && zx == 100 && zy == 100) { c.flags &= ~0x80; c.rot = 0; c.alphaRaw = 0; c.xZoom = 100; c.yZoom = 100; }
                else { c.flags |= 0x80; c.rot = rot; c.alphaRaw = al; c.xZoom = zx; c.yZoom = zy; }
            }
            if ((mask & A_MOVE) != 0) { if ((s.flags & 4) != 0) copyProp(MOV, s, c); else clear(MOV, c); }
            if ((mask & A_TIME) != 0) { if ((s.flags & 0x20) != 0) { c.flags |= 0x20; c.time = s.time; } else c.flags &= ~0x20; }
            if ((mask & A_IMAGE) != 0) c.image = s.image;
            c.normalize();
            return c;
        }
    }

    /** Insere depois de {@code after} um sprite por imagem (copia so o visual do frame: sem hits, som, velocidade nem opcoes). */
    static Ano.Mpt[] insertSprites(Ano.Mpt[] m, int after, int[] images, int[] ticks) {
        if (!ok(m, after) || images == null || ticks == null || images.length == 0 || ticks.length < images.length) return m;
        int n = images.length;
        Ano.Mpt[] out = new Ano.Mpt[m.length + n];
        System.arraycopy(m, 0, out, 0, after + 1);
        out[after] = timed(m[after]);
        Ano.Mpt base = m[after].copy();
        base.flags &= ~8; base.se = -1;
        base.wActFlag &= ~3;
        if (base.wActFlag == 0) base.flags &= ~2;
        base.hits = Ano.NO_HITS;
        base.flags &= ~0x10;
        clear(MOV, base);
        clear(OPT, base);
        for (int k = 0; k < n; k++) {
            Ano.Mpt c = base.copy();
            c.image = images[k];
            c.flags |= 0x20;
            c.time = Math.max(1, Math.min(255, ticks[k]));
            c.normalize();
            out[after + 1 + k] = c;
        }
        System.arraycopy(m, after + 1, out, after + 1 + n, m.length - after - 1);
        return out;
    }
}
