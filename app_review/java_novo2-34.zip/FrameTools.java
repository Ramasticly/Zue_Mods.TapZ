package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Regras puras (sem Android) das paginas Tempo / Movimento / Som da gaveta de sprite.
 * Velocidade como o jogo: ao carregar um frame, sem o bit 64 (manter velocidade) speed = 0; accel = 0 sempre; depois cada campo do MOVE
 * ATRIBUI (substitui) o valor. A cada tick com tempo > 0: x += speed, depois speed += accel. Logo a velocidade que o proximo frame recebe
 * e (speed inicial + accel * ticks) do anterior: conta como SPEED, nao como accel, e e substituida se o frame tem speed proprio.
 */
final class FrameTools {
    private FrameTools() { }

    static final double ONE = 65536.0;

    /** Ticks que o frame realmente anda (sem TIME o jogo nao avanca nem soma accel). */
    static int ticks(Ano.Mpt m) { return m.hasTime ? Math.max(0, m.time) : 0; }

    /** O frame {@code f} carrega o bit 64 (manter velocidade do anterior)? */
    static boolean keeps(Ano.Mpt[] m, int f) {
        return f > 0 && f < m.length && (m[f].flags & 2) != 0 && (m[f].wActFlag & 64) != 0;
    }

    private static boolean has(Ano.Mpt m, int bit) { return (m.flags & 4) != 0 && (m.moveMask & bit) != 0; }

    /** Velocidade (px/tick) no inicio do frame, ja com a substituicao do speed proprio. */
    static double[] startSpeed(Ano.Mpt[] m, int f) {
        double[] v = keeps(m, f) ? endSpeed(m, f - 1) : new double[]{0, 0};
        if (has(m[f], 1)) v[0] = m[f].speedX / ONE;
        if (has(m[f], 2)) v[1] = m[f].speedY / ONE;
        return v;
    }

    /** Velocidade no fim do frame (a que o proximo frame recebe se mantiver). */
    static double[] endSpeed(Ano.Mpt[] m, int f) {
        double[] v = startSpeed(m, f);
        int t = ticks(m[f]);
        if (has(m[f], 4)) v[0] += m[f].accelX / ONE * t;
        if (has(m[f], 8)) v[1] += m[f].accelY / ONE * t;
        return v;
    }

    /** Velocidade recebida do frame anterior (0,0 se o frame nao mantem). */
    static double[] received(Ano.Mpt[] m, int f) {
        return keeps(m, f) ? endSpeed(m, f - 1) : new double[]{0, 0};
    }

    /** Deslocamento total {dx, dy} em px e ticks, dos frames head..last. */
    static double[] totalPixels(Ano.Mpt[] m, int head, int last) {
        double x = 0, y = 0;
        int ticks = 0;
        for (int f = head; f <= last && f < m.length; f++) {
            double[] v = startSpeed(m, f);
            double ax = has(m[f], 4) ? m[f].accelX / ONE : 0, ay = has(m[f], 8) ? m[f].accelY / ONE : 0;
            int t = ticks(m[f]);
            for (int k = 0; k < t; k++) { x += v[0]; y += v[1]; v[0] += ax; v[1] += ay; }
            ticks += t;
        }
        return new double[]{x, y, ticks};
    }

    /** O frame tem speed proprio (x ou y)? */
    static boolean ownSpeed(Ano.Mpt m) { return (m.flags & 4) != 0 && (m.moveMask & 3) != 0; }

    /** Aceleracao so aparece se o frame ja tem speed normal (proprio e diferente de 0) ou ja tinha accel. */
    static boolean showAccel(Ano.Mpt m) {
        boolean speed = ownSpeed(m) && ((has(m, 1) && m.speedX != 0) || (has(m, 2) && m.speedY != 0));
        return speed || (m.flags & 4) != 0 && (m.moveMask & 12) != 0;
    }

    /** Liga (on) ou apaga o campo de speed do eixo (0 = x, 1 = y), em px/tick absolutos. */
    static Ano.Mpt setSpeed(Ano.Mpt cur, int axis, double pxPerTick, boolean on) {
        Ano.Mpt c = cur.copy();
        int bit = axis == 0 ? 1 : 2;
        int raw = (int) Math.round(pxPerTick * ONE);
        if (on) {
            c.flags |= 4;
            c.moveMask |= bit;
            if (axis == 0) c.speedX = raw; else c.speedY = raw;
        } else {
            c.moveMask &= ~bit;
            if (axis == 0) c.speedX = 0; else c.speedY = 0;
            if (c.moveMask == 0) c.flags &= ~4;
        }
        c.normalize();
        return c;
    }

    /** Aceleracao (px/tick^2) do eixo; 0 apaga o campo. */
    static Ano.Mpt setAccel(Ano.Mpt cur, int axis, double v) {
        Ano.Mpt c = cur.copy();
        int bit = axis == 0 ? 4 : 8;
        int raw = (int) Math.round(v * ONE);
        if (raw != 0) {
            c.flags |= 4;
            c.moveMask |= bit;
            if (axis == 0) c.accelX = raw; else c.accelY = raw;
        } else {
            c.moveMask &= ~bit;
            if (axis == 0) c.accelX = 0; else c.accelY = 0;
            if (c.moveMask == 0) c.flags &= ~4;
        }
        c.normalize();
        return c;
    }

    /** Tempo 0 = sem o campo TIME (o frame fica travado). */
    static Ano.Mpt setTime(Ano.Mpt cur, int ticks) {
        Ano.Mpt c = cur.copy();
        if (ticks <= 0) { c.flags &= ~0x20; c.time = 0; }
        else { c.flags |= 0x20; c.time = Math.min(255, ticks); }
        c.normalize();
        return c;
    }

    /** O frame seguinte mantem a velocidade deste? */
    static boolean keepsNext(Ano.Mpt[] m, int f) { return keeps(m, f + 1); }

    /**
     * Liga/desliga "manter velocidade" deste frame para o seguinte. Desligar corta o trecho aqui: os frames depois dele que
     * dependiam do trecho tambem perdem o bit 64. Devolve null se nao ha frame seguinte (ligar) ou nada a fazer.
     */
    static Ano.Mpt[] setKeepNext(Ano.Mpt[] m, int f, boolean on) {
        if (f < 0 || f >= m.length) return null;
        int head = FrameOps.moveHeadOf(m, f);
        if (on) {
            if (f + 1 >= m.length) return null;
            if (head >= 0) return FrameOps.setMoveRun(m, head, f + 1);
            Ano.Mpt[] out = m.clone();
            Ano.Mpt c = m[f + 1].copy();
            c.flags |= 2;
            c.wActFlag |= 64;
            c.normalize();
            out[f + 1] = c;
            return out;
        }
        if (head >= 0) return FrameOps.setMoveRun(m, head, f);
        if (!keeps(m, f + 1)) return null;
        Ano.Mpt[] out = m.clone();
        Ano.Mpt c = m[f + 1].copy();
        c.wActFlag &= ~64;
        if (c.wActFlag == 0) c.flags &= ~2;
        c.normalize();
        out[f + 1] = c;
        return out;
    }

    /** Desliga o bit 64 do frame {@code f} e de todo o trecho depois dele (botao "Remover" da velocidade recebida). */
    static Ano.Mpt[] removeReceived(Ano.Mpt[] m, int f) {
        if (!keeps(m, f)) return null;
        Ano.Mpt[] out = m.clone();
        for (int k = f; k < m.length && keeps(m, k); k++) {
            Ano.Mpt c = m[k].copy();
            c.wActFlag &= ~64;
            if (c.wActFlag == 0) c.flags &= ~2;
            if ((c.flags & 4) != 0 && (c.moveMask & 3) == 0) { c.flags &= ~4; c.moveMask = 0; c.accelX = c.accelY = 0; }
            c.normalize();
            out[k] = c;
        }
        return out;
    }

    /** Move o inicio do trecho de velocidade para outro frame mantendo a quantidade de frames; null se nao cabe ou bate em outra velocidade. */
    static Ano.Mpt[] moveRunTo(Ano.Mpt[] m, int head, int newHead) {
        if (head < 0 || head >= m.length || newHead < 0 || newHead >= m.length || !FrameOps.isMoveHead(m[head])) return null;
        if (newHead == head) return m;
        int n = FrameOps.moveRunEnd(m, head) - head + 1;
        Ano.Mpt src = m[head].copy();
        Ano.Mpt[] out = FrameOps.setMoveRun(m, head, head);
        Ano.Mpt h0 = out[head].copy();
        FrameOps.clear(FrameOps.MOV, h0);
        out[head] = h0;
        int last = Math.min(out.length - 1, newHead + n - 1);
        for (int f = newHead; f <= last; f++) if (FrameOps.isMoveHead(out[f])) return null;
        Ano.Mpt t = out[newHead].copy();
        FrameOps.copyProp(FrameOps.MOV, src, t);
        t.wActFlag &= ~64;
        if (t.wActFlag == 0) t.flags &= ~2;
        t.normalize();
        out[newHead] = t;
        return FrameOps.setMoveRun(out, newHead, last);
    }

    // ---- sons: ids validos 0 -> 79 (globais) -> 80..99 (personagem) -> 100..255 (globais novos) ----

    static List<Integer> soundIds(int seMax, int wavCount) { return SoundIds.frameIds(seMax, wavCount); }

    /** Proximo id valido na direcao dir (+1/-1); se o atual nao e valido, vai para o mais proximo na direcao; nas pontas fica. */
    static int stepSound(int cur, int dir, int seMax, int wavCount) {
        List<Integer> l = soundIds(seMax, wavCount);
        int idx = l.indexOf(Integer.valueOf(cur));
        if (idx < 0) {
            if (dir > 0) { for (Integer v : l) if (v.intValue() > cur) return v.intValue(); return l.get(l.size() - 1).intValue(); }
            for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).intValue() < cur) return l.get(i).intValue();
            return l.get(0).intValue();
        }
        return l.get(Math.max(0, Math.min(l.size() - 1, idx + (dir > 0 ? 1 : -1)))).intValue();
    }

    /** O frame e inicio de trecho de velocidade (tem speed proprio, mesmo mantendo a do anterior)? */
    static boolean moveRunHeadOk(Ano.Mpt[] m, int f) { return FrameOps.isMoveHead(m[f]); }

    /** "N.Ns" (ticks a 60 por segundo, uma casa). */
    static String seconds(int ticks) {
        return String.format(java.util.Locale.US, "%.1fs", ticks / 60.0);
    }

    /** px/tick com ate 2 casas, sem zeros sobrando. */
    static String px(double v) {
        String s = String.format(java.util.Locale.US, "%.2f", v);
        while (s.contains(".") && (s.endsWith("0") || s.endsWith("."))) s = s.substring(0, s.length() - 1);
        return s.equals("-0") ? "0" : s;
    }
}
