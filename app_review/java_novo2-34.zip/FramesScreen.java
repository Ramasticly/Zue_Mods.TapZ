package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

/**
 * "Ver Frames" do menu do ANO: lista os Frames da ANO atual. Tocar num Frame o seleciona (varios); COPIAR leva os selecionados para a area de transferencia
 * ({@link FrameClip#current}), EXCLUIR apaga, e COLAR mostra um "Colar aqui" entre cada item da lista (e nas pontas). As contas ficam em {@link FrameClip}; aqui so tela.
 */
final class FramesScreen {
    private FramesScreen() { }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, HI = 0xFF21402C, RED = 0xFFFF6B6B;

    /** Aplica a nova lista de Frames na ANO atual (com desfazer); {@code focus} = Frame para onde o ponteiro vai. */
    interface Applier { void apply(Ano.Mpt[] mp, int focus); }

    static void show(final Activity a, final AttackView view, final CharAssets ca, final Applier applier) {
        final Ano start = view.currentAno();
        if (start == null || start.mpts == null || start.mpts.length == 0) { SpriteListScreen.toast(a, "A ANO não tem Frames."); return; }
        final int anoIndex = start.index;
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        final TextView ti = SpriteListScreen.text(a, "ANO " + anoIndex + " — Frames", 16, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        final TextView sub = SpriteListScreen.text(a, "", 11, DIM, false);
        sub.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 8));
        root.addView(sub);

        final SpriteLib lib = ca.lib();
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final TreeSet<Integer> sel = new TreeSet<Integer>();
        final boolean[] pasting = {false};
        final ArrayList<int[]> rows = new ArrayList<int[]>();      // {0, frame} ou {1, posicao do "Colar aqui"}
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final Runnable[] refresh = {null};

        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return rows.size(); }
            @Override public Object getItem(int i) { return rows.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                int type = rows.get(pos)[0], i = rows.get(pos)[1];
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 6));
                if (type == 1) {
                    row.setGravity(Gravity.CENTER);
                    row.setBackgroundColor(0xFF1B2A44);
                    TextView t = SpriteListScreen.text(a, "COLAR AQUI", 14, ACCENT, true);
                    t.setPadding(0, SpriteListScreen.dp(a, 10), 0, SpriteListScreen.dp(a, 10));
                    row.addView(t);
                    return row;
                }
                Ano cur = view.currentAno();
                Ano.Mpt m = cur.mpts[i];
                boolean on = sel.contains(Integer.valueOf(i));
                if (on) row.setBackgroundColor(HI);
                ImageView iv = new ImageView(a);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setBackgroundColor(0xFF0D0F13);
                Bitmap tb = m.image >= 0 ? thumb(lib, thumbs, m.image) : null;
                if (tb != null) iv.setImageBitmap(tb);
                row.addView(iv, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 48), SpriteListScreen.dp(a, 48)));
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setTextColor(on ? OK : TEXT);
                t.setPadding(SpriteListScreen.dp(a, 12), 0, 0, 0);
                t.setText("Frame " + i + "\n" + (m.image >= 0 ? "SPR_" + m.image : "(sem imagem)") + "  ·  " + (m.hasTime ? m.time + " ticks" : "sem time (fica parado)")
                        + (m.hits.length > 0 ? "  ·  " + m.hits.length + " caixa(s)" : ""));
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                TextView mark = SpriteListScreen.text(a, on ? "✓" : "", 18, OK, true);
                mark.setGravity(Gravity.CENTER);
                row.addView(mark, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 30), -2));
                return row;
            }
        };
        lv.setAdapter(ad);

        // barra de baixo
        final LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 10));
        bar.setBackgroundColor(CARD);
        final TextView copyBtn = SpriteListScreen.button(a, "COPIAR", new View.OnClickListener() { @Override public void onClick(View v) {
            Ano cur = view.currentAno();
            int[] s = toArray(sel);
            FrameClip c = FrameClip.copy(cur.mpts, s, ca, cur.index);
            if (c == null) { SpriteListScreen.toast(a, "Toque nos Frames para selecionar."); return; }
            FrameClip.current = c;
            I18nUi.toast(a, c.frames.length + " Frame(s) copiado(s)", android.widget.Toast.LENGTH_SHORT).show();
            refresh[0].run();
        } });
        final TextView delBtn = SpriteListScreen.button(a, "EXCLUIR", new View.OnClickListener() { @Override public void onClick(View v) {
            final Ano cur = view.currentAno();
            final int[] s = FrameClip.normalize(cur.mpts, toArray(sel));
            if (s.length == 0) { SpriteListScreen.toast(a, "Toque nos Frames para selecionar."); return; }
            if (s.length >= cur.mpts.length) { SpriteListScreen.toast(a, "A ANO precisa ficar com pelo menos 1 Frame."); return; }
            new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Excluir Frames")
                    .setMessage("Excluir " + s.length + " Frame(s) da ANO " + cur.index + "? Dá para desfazer.")
                    .setNegativeButton("CANCELAR", null)
                    .setPositiveButton("EXCLUIR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dlg, int w) {
                        Ano.Mpt[] out = FrameClip.delete(cur.mpts, s);
                        if (out == null) return;
                        sel.clear();
                        applier.apply(out, Math.max(0, Math.min(out.length - 1, s[0])));
                        refresh[0].run();
                    } }).show();
        } });
        delBtn.setTextColor(RED);
        final TextView pasteBtn = SpriteListScreen.button(a, "COLAR", new View.OnClickListener() { @Override public void onClick(View v) {
            if (pasting[0]) { pasting[0] = false; refresh[0].run(); return; }
            if (FrameClip.current == null || FrameClip.current.owner != ca) { SpriteListScreen.toast(a, "Nada copiado deste personagem."); return; }
            pasting[0] = true;
            sel.clear();
            refresh[0].run();
        } });
        final TextView closeBtn = SpriteListScreen.button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } });
        bar.addView(copyBtn);
        bar.addView(delBtn, SpriteListScreen.lpm(a, 8));
        bar.addView(pasteBtn, SpriteListScreen.lpm(a, 8));
        bar.addView(closeBtn, SpriteListScreen.lpm(a, 8));

        refresh[0] = new Runnable() { @Override public void run() {
            Ano cur = view.currentAno();
            rows.clear();
            if (cur != null && cur.mpts != null) {
                int n = cur.mpts.length;
                if (pasting[0]) { for (int k = 0; k < n; k++) { rows.add(new int[]{1, k}); rows.add(new int[]{0, k}); } rows.add(new int[]{1, n}); }
                else for (int k = 0; k < n; k++) rows.add(new int[]{0, k});
                java.util.Iterator<Integer> it = sel.iterator();
                while (it.hasNext()) if (it.next().intValue() >= n) it.remove();
            }
            int n = cur == null || cur.mpts == null ? 0 : cur.mpts.length;
            FrameClip cl = FrameClip.current;
            boolean canPaste = cl != null && cl.owner == ca;
            sub.setText(pasting[0] ? "Toque em COLAR AQUI no lugar onde os " + (cl == null ? 0 : cl.frames.length) + " Frame(s) copiado(s) devem entrar"
                    : n + " Frame(s)  ·  toque para selecionar (vários)" + (canPaste ? "  ·  " + cl.frames.length + " copiado(s)" : ""));
            copyBtn.setText(sel.isEmpty() ? "COPIAR" : "COPIAR " + sel.size());
            delBtn.setText(sel.isEmpty() ? "EXCLUIR" : "EXCLUIR " + sel.size());
            copyBtn.setAlpha(sel.isEmpty() || pasting[0] ? 0.4f : 1f);
            delBtn.setAlpha(sel.isEmpty() || pasting[0] ? 0.4f : 1f);
            pasteBtn.setText(pasting[0] ? "CANCELAR" : "COLAR");
            pasteBtn.setAlpha(canPaste || pasting[0] ? 1f : 0.4f);
            ad.notifyDataSetChanged();
        } };

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                int type = rows.get(pos)[0], i = rows.get(pos)[1];
                if (type == 1) {
                    Ano cur = view.currentAno();
                    FrameClip cl = FrameClip.current;
                    Ano.Mpt[] out = FrameClip.paste(cur.mpts, i, cl);
                    pasting[0] = false;
                    if (out != cur.mpts) {
                        applier.apply(out, i);
                        I18nUi.toast(a, cl.frames.length + " Frame(s) colado(s)", android.widget.Toast.LENGTH_SHORT).show();
                    }
                    refresh[0].run();
                    return;
                }
                if (pasting[0]) return;
                if (!sel.remove(Integer.valueOf(i))) sel.add(Integer.valueOf(i));
                refresh[0].run();
            }
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(bar);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
            }
        });
        refresh[0].run();
        d.show();
    }

    private static int[] toArray(TreeSet<Integer> s) {
        int[] r = new int[s.size()];
        int k = 0;
        for (Integer i : s) r[k++] = i.intValue();
        return r;
    }

    private static Bitmap thumb(SpriteLib lib, Map<Integer, Bitmap> thumbs, int i) {
        Bitmap tb = thumbs.get(Integer.valueOf(i));
        if (tb == null && lib.has(i)) {
            Bitmap full = lib.cut(i);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(i), tb);
            }
        }
        return tb;
    }
}
