package com.zue.attackeditor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

/**
 * Tabelas do gamedata (assets/gamedata/...): por enquanto so as reacoes de dano do chao (HDAT 10-39).
 * Os valores sao lidos da pasta a cada carga, porque quem usa o editor pode alterar o gamedata.
 * Como o nome do chunk dentro da pasta nao e fixo, o arquivo certo e descoberto pelo conteudo.
 */
public final class GameData {
    public static final int FIRST_REACTION_HDAT = 10;
    public static final int REACTION_COUNT = 30;

    private final ReactionTable[] reactions = new ReactionTable[REACTION_COUNT];
    public final String sourceName;
    private byte[] h5 = new byte[0];
    private byte[] h2 = new byte[0];
    private int cols2;

    private GameData(HdatTable t, String sourceName) {
        this.sourceName = sourceName;
        if (t.size() > 5) h5 = t.bytes(5);
        if (t.size() > 2) { h2 = t.bytes(2); cols2 = t.cols(2); }
        for (int i = 0; i < REACTION_COUNT; i++) {
            int h = FIRST_REACTION_HDAT + i;
            reactions[i] = new ReactionTable(t.bytes(h), t.rows(h));
        }
    }

    /**
     * Escala de dano por combo (HDAT 5, segunda linha, 14 valores s16 em %). idx = min(combo,15)-2 (combo>=2) ou o proprio combo.
     * Sem a tabela devolve 100 (sem escala).
     */
    public int comboScale(int idx) {
        int rowBytes = h5.length / 2;               // 2 linhas (HDAT 5): a segunda e a que o DamageChange le
        int p = rowBytes + idx * 2;
        if (rowBytes <= 0 || idx < 0 || p + 1 >= h5.length) return 100;
        return (short) (((h5[p + 1] & 255) << 8) | (h5[p] & 255));
    }

    /**
     * HDAT 2 (IA, md 685): linha 1 = distancia PERTO, linha 2 = MEDIA; coluna 0 = alvo no chao, coluna 1 = alvo no ar.
     * -1 se a tabela nao existe.
     */
    public int cpuDist(int row, boolean air) {
        int p = row * cols2 + (air ? 1 : 0);
        return (cols2 <= 0 || p < 0 || p >= h2.length) ? -1 : (h2[p] & 255);
    }

    /** Tabela de reacao {@code type} (0..29) ou null. */
    public ReactionTable reaction(int type) {
        return (type >= 0 && type < REACTION_COUNT) ? reactions[type] : null;
    }

    /**
     * Procura o gamedata so em TXT: o {@code *.dac.txt} (formato BIN_CNV_ por dentro, como o compilador trata a pasta gamedata) de qualquer nome em
     * assets/gamedata/ (pasta com qualquer caixa, tambem em subpastas como SYSTEM/gamedata), ou em arquivos gamedata*.dac.txt de assets/. Sem eles, procura
     * qualquer *.dac.txt / *.bin.txt de formato BIN_CNV_ nas outras pastas (fora das de personagem). O binario nunca e lido.
     */
    public static GameData load(File assetsRoot) throws IOException {
        File[] top = assetsRoot.listFiles();
        if (top == null) throw new IOException("pasta de assets ilegivel: " + assetsRoot + " (permissao de armazenamento?)");
        java.util.ArrayList<File> dirs = new java.util.ArrayList<File>();
        java.util.ArrayList<File> cands = candidates(assetsRoot, top, dirs, true);
        StringBuilder why = new StringBuilder();
        for (File f : cands) {
            try {
                String text = TxtFiles.read(f);
                if (!BinTxt.isBin(text)) { why.append(f.getName()).append(": nao e BIN_CNV_; "); continue; }
                return fromTxt(text, f.getName());
            } catch (IOException e) {
                why.append(f.getName()).append(": ").append(e.getMessage()).append("; ");
            } catch (RuntimeException e) {
                why.append(f.getName()).append(": ").append(e).append("; ");
            }
        }
        if (cands.isEmpty()) throw new TxtFiles.Missing(dirs.isEmpty() ? new File(assetsRoot, "gamedata") : dirs.get(0), "dac");
        throw new IOException("nenhum *.dac.txt de gamedata valido em " + assetsRoot.getPath() + " (" + why.toString().trim() + ")");
    }

    /** Os TXT candidatos a gamedata (na ordem de preferencia); {@code dirs} recebe as pastas gamedata achadas. */
    private static java.util.ArrayList<File> candidates(File assetsRoot, File[] top, java.util.ArrayList<File> dirs, boolean fallback) {
        java.util.ArrayList<File> cands = new java.util.ArrayList<File>();
        findGamedataDirs(assetsRoot, dirs, 0);
        for (File d : dirs) addTxt(d, cands);
        for (File f : top) {
            String n = f.getName().toLowerCase(java.util.Locale.US);
            if (f.isFile() && n.startsWith("gamedata") && (TxtFiles.isKind(n, "dac") || TxtFiles.isKind(n, "bin"))) cands.add(f);
        }
        if (fallback && cands.isEmpty()) {
            for (File f : top) if (f.isDirectory() && !f.getName().toLowerCase(java.util.Locale.US).startsWith("char")) addTxt(f, cands);
        }
        return cands;
    }

    /** Ha o TXT de gamedata (pasta gamedata ou gamedata*.dac.txt) em {@code assetsRoot}? (para o aviso de PACs que faltam; sem o palpite de outras pastas) */
    static boolean hasTxt(File assetsRoot) {
        File[] top = assetsRoot == null ? null : assetsRoot.listFiles();
        return top != null && !candidates(assetsRoot, top, new java.util.ArrayList<File>(), false).isEmpty();
    }

    private static void findGamedataDirs(File dir, java.util.List<File> out, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            if (!f.isDirectory()) continue;
            String n = f.getName().toLowerCase(java.util.Locale.US);
            if (n.equals("gamedata")) out.add(f);
            else if (depth < 2 && !n.startsWith("char") && !n.startsWith("#")) findGamedataDirs(f, out, depth + 1);
        }
    }

    /** O *.dac.txt e o *.bin.txt da pasta, de qualquer nome (so um por tipo). */
    private static void addTxt(File dir, java.util.List<File> out) {
        File d = TxtFiles.find(dir, "dac");
        if (d != null) out.add(d);
        File b = TxtFiles.find(dir, "bin");
        if (b != null) out.add(b);
    }

    /** Gamedata lida do TXT (formato BIN_CNV_ do {@code *.dac.txt} da pasta gamedata): os bytes de HDAT sao montados na memoria ({@link BinTxt}). */
    public static GameData fromTxt(String text, String name) throws IOException {
        HdatTable t = HdatTable.parse(BinTxt.compile(text));
        if (t.size() <= FIRST_REACTION_HDAT + 2) throw new IOException("so " + t.size() + " HDATs");
        int len = t.length(FIRST_REACTION_HDAT);
        if (len <= 0 || len % ReactionTable.STRIDE != 0) throw new IOException("HDAT 10 com " + len + " bytes");
        return new GameData(t, name);
    }

    /** Para testes: monta direto de um arquivo ja lido. */
    public static GameData fromBytes(byte[] data, String name) throws IOException {
        return new GameData(HdatTable.parse(data), name);
    }

    static byte[] readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            byte[] b = new byte[(int) f.length()];
            int p = 0, n;
            while (p < b.length && (n = in.read(b, p, b.length - p)) > 0) p += n;
            if (p != b.length) throw new IOException("leitura incompleta: " + f.getName());
            return b;
        } finally {
            in.close();
        }
    }
}
