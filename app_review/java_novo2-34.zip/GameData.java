package com.zue.attackeditor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

/**
 * Tabelas do gamedata (assets/gamedata/...): por enquanto so as reacoes de dano do chao (HDAT 10-39).
 * Os valores sao lidos da pasta a cada carga, porque quem usa o editor pode alterar o gamedata.
 * Como o nome do chunk dentro da pasta nao e fixo, o arquivo certo e descoberto pelo conteudo.
 */
public final class GameData {
    public static final int FIRST_REACTION_HDAT = 10;
    public static final int REACTION_COUNT = 30;

    private final ReactionTable[] reactions = new ReactionTable[REACTION_COUNT];
    public final String sourceName;
    private byte[] h5 = new byte[0];
    private byte[] h2 = new byte[0];
    private int cols2;

    private GameData(HdatTable t, String sourceName) {
        this.sourceName = sourceName;
        if (t.size() > 5) h5 = t.bytes(5);
        if (t.size() > 2) { h2 = t.bytes(2); cols2 = t.cols(2); }
        for (int i = 0; i < REACTION_COUNT; i++) {
            int h = FIRST_REACTION_HDAT + i;
            reactions[i] = new ReactionTable(t.bytes(h), t.rows(h));
        }
    }

    /**
     * Escala de dano por combo (HDAT 5, segunda linha, 14 valores s16 em %). idx = min(combo,15)-2 (combo>=2) ou o proprio combo.
     * Sem a tabela devolve 100 (sem escala).
     */
    public int comboScale(int idx) {
        int rowBytes = h5.length / 2;               // 2 linhas (HDAT 5): a segunda e a que o DamageChange le
        int p = rowBytes + idx * 2;
        if (rowBytes <= 0 || idx < 0 || p + 1 >= h5.length) return 100;
        return (short) (((h5[p + 1] & 255) << 8) | (h5[p] & 255));
    }

    /**
     * HDAT 2 (IA, md 685): linha 1 = distancia PERTO, linha 2 = MEDIA; coluna 0 = alvo no chao, coluna 1 = alvo no ar.
     * -1 se a tabela nao existe.
     */
    public int cpuDist(int row, boolean air) {
        int p = row * cols2 + (air ? 1 : 0);
        return (cols2 <= 0 || p < 0 || p >= h2.length) ? -1 : (h2[p] & 255);
    }

    /** Tabela de reacao {@code type} (0..29) ou null. */
    public ReactionTable reaction(int type) {
        return (type >= 0 && type < REACTION_COUNT) ? reactions[type] : null;
    }

    /** Procura o gamedata em assets/gamedata/ (pasta com qualquer caixa), em arquivos gamedata* de assets/ ou em subpastas. */
    public static GameData load(File assetsRoot) throws IOException {
        File[] top = assetsRoot.listFiles();
        if (top == null) throw new IOException("pasta de assets ilegivel: " + assetsRoot + " (permissao de armazenamento?)");
        java.util.ArrayList<File> cands = new java.util.ArrayList<File>();
        File dir = null;
        for (File f : top) if (f.isDirectory() && f.getName().equalsIgnoreCase("gamedata")) dir = f;
        if (dir != null) addFiles(dir, cands, true);
        for (File f : top) if (f.isFile() && f.getName().toLowerCase().startsWith("gamedata")) cands.add(f);
        if (cands.isEmpty()) {
            for (File f : top) if (f.isDirectory() && !f.getName().toLowerCase().startsWith("char")) addFiles(f, cands, false);
        }
        Collections.sort(cands, new Comparator<File>() {
            @Override public int compare(File a, File b) {
                int ga = a.getName().toLowerCase().startsWith("gamedata") ? 0 : 1, gb = b.getName().toLowerCase().startsWith("gamedata") ? 0 : 1;
                return ga != gb ? ga - gb : a.getName().compareTo(b.getName());
            }
        });
        StringBuilder why = new StringBuilder();
        for (File f : cands) {
            HdatTable t;
            try {
                t = HdatTable.tryParse(readAll(f));
            } catch (IOException e) {
                why.append(f.getName()).append(": ilegivel; ");
                continue;
            }
            if (t == null) { why.append(f.getName()).append(": nao e HDAT; "); continue; }
            if (t.size() <= FIRST_REACTION_HDAT + 2) { why.append(f.getName()).append(": so ").append(t.size()).append(" HDATs; "); continue; }
            int len = t.length(FIRST_REACTION_HDAT);
            if (len <= 0 || len % ReactionTable.STRIDE != 0) { why.append(f.getName()).append(": HDAT 10 com ").append(len).append(" bytes; "); continue; }
            return new GameData(t, f.getName());
        }
        throw new IOException("nenhum arquivo de gamedata valido em " + assetsRoot.getPath() + " ("
                + (cands.isEmpty() ? "nenhum arquivo candidato" : why.toString().trim()) + ")");
    }

    private static void addFiles(File dir, java.util.List<File> out, boolean any) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) { if (any) addFiles(f, out, true); continue; }
            if (!skip(f.getName().toLowerCase()) && f.length() > 0 && f.length() < 8L * 1024 * 1024) out.add(f);
        }
    }

    /** Para testes: monta direto de um arquivo ja lido. */
    public static GameData fromBytes(byte[] data, String name) throws IOException {
        return new GameData(HdatTable.parse(data), name);
    }

    private static boolean skip(String n) {
        return n.endsWith(".png") || n.endsWith(".ogg") || n.endsWith(".wav") || n.endsWith(".txt")
                || n.endsWith(".act") || n.endsWith(".json") || n.endsWith(".zip") || n.endsWith(".bak");
    }

    static byte[] readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            byte[] b = new byte[(int) f.length()];
            int p = 0, n;
            while (p < b.length && (n = in.read(b, p, b.length - p)) > 0) p += n;
            if (p != b.length) throw new IOException("leitura incompleta: " + f.getName());
            return b;
        } finally {
            in.close();
        }
    }
}
