package com.zue.attackeditor;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Assinatura (nome, tamanho, data) dos arquivos de onde sai a game data (Java puro). Ao voltar para o app so se relê a game data se a
 * assinatura mudou: o golpe aberto, o ponteiro e o play/pausa ficam como estavam.
 */
final class GameDataSignature {
    private GameDataSignature() { }

    static String of(File root) {
        List<String> parts = new ArrayList<String>();
        File[] top = root == null ? null : root.listFiles();
        if (top == null) return "";
        boolean found = false;
        for (File f : top) {
            if (f.isDirectory() && f.getName().equalsIgnoreCase("gamedata")) { collect(f, parts, 0); found = true; }
            else if (f.isFile() && f.getName().toLowerCase().startsWith("gamedata")) { add(f, parts); found = true; }
        }
        if (!found) for (File f : top) if (f.isDirectory() && !f.getName().toLowerCase().startsWith("char")) collect(f, parts, 2);
        Collections.sort(parts);
        StringBuilder b = new StringBuilder();
        for (String p : parts) b.append(p).append(';');
        return b.toString();
    }

    private static void collect(File dir, List<String> out, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) { if (depth < 3) collect(f, out, depth + 1); }
            else add(f, out);
        }
    }

    private static void add(File f, List<String> out) { out.add(f.getPath() + "|" + f.length() + "|" + f.lastModified()); }

    /** Precisa reler? (assinatura vazia = nada lido ainda ou pasta ilegivel: nao mexe) */
    static boolean changed(String before, String now) { return before != null && before.length() > 0 && now != null && !before.equals(now); }
}
