package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Limites do jogo que o editor deixaria passar: o simulador aceita, mas no jogo a ANO estoura um array (ArrayIndexOutOfBounds dentro do
 * Run() do TCBManajer fecha o jogo) ou e ignorada. Java puro, sem Android.
 */
final class GameRules {
    private GameRules() { }

    /** Maximos do jogo (ObjReq.hit = int[50], ObjReq.lnk = ObjReq[13], MPT e time em 1 byte). */
    static final int MAX_HITS = 10, MAX_LINKS = 13, MAX_MPTS = 255, MAX_TIME = 255, MAX_OPT1 = 249;

    static final class Issue {
        final int ano, mpt;
        /** true = o jogo fecha ou le lixo; false = o jogo ignora o campo. */
        final boolean fatal;
        final String text;

        Issue(int ano, int mpt, boolean fatal, String text) {
            this.ano = ano;
            this.mpt = mpt;
            this.fatal = fatal;
            this.text = text;
        }

        @Override public String toString() { return "ANO " + ano + (mpt >= 0 ? " MPT " + mpt : "") + ": " + text; }
    }

    /** cnvEntries <= 0 desliga a checagem de imagem. */
    static List<Issue> check(Dac dac, java.util.Collection<Integer> anos, int cnvEntries) {
        List<Issue> out = new ArrayList<Issue>();
        if (dac == null) return out;
        boolean[] isLink = new boolean[dac.size()];
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (int k = 0; k < a.links.length; k++) {
                int t = a.links[k].getAno();
                if (t >= 0 && t < isLink.length) isLink[t] = true;
            }
        }
        if (anos == null) {
            for (int i = 0; i < dac.size(); i++) checkAno(dac, dac.getAno(i), isLink, cnvEntries, out);
        } else {
            for (Integer i : anos) if (i.intValue() >= 0 && i.intValue() < dac.size()) checkAno(dac, dac.getAno(i.intValue()), isLink, cnvEntries, out);
        }
        return out;
    }

    private static void checkAno(Dac dac, Ano a, boolean[] isLink, int cnvEntries, List<Issue> out) {
        if (a == null || !a.present) return;
        int ix = a.index;
        if (a.mpts.length > MAX_MPTS)
            out.add(new Issue(ix, -1, true, a.mpts.length + " frames: o DAC guarda a quantidade em 1 byte (maximo " + MAX_MPTS + ")"));
        if (a.links.length > MAX_LINKS)
            out.add(new Issue(ix, -1, true, a.links.length + " links: o jogo so tem " + MAX_LINKS + " (lnk[13]) e fecha ao criar o excedente"));
        for (int p = 0; p < a.mpts.length; p++) {
            Ano.Mpt m = a.mpts[p];
            if (m.hits.length > MAX_HITS)
                out.add(new Issue(ix, p, true, m.hits.length + " caixas no frame: o jogo guarda no maximo " + MAX_HITS + " (hit[50]) e fecha ao ler o excedente"));
            if (m.hasTime && m.time > MAX_TIME)
                out.add(new Issue(ix, p, true, "tempo " + m.time + ": o campo e 1 byte (maximo " + MAX_TIME + ")"));
            if (cnvEntries > 0 && m.image >= cnvEntries)
                out.add(new Issue(ix, p, false, "imagem " + m.image + " nao existe no CNV (" + cnvEntries + " entradas): o frame fica sem desenho"));
            if (m.hasOpt && m.optData[1] > MAX_OPT1 && hasHitbox(m))
                out.add(new Issue(ix, p, true, "OPT 1 = " + m.optData[1] + " com hitbox: o grupo " + (m.optData[1] / 50) + " nao existe (maximo " + MAX_OPT1 + ")"));
            if (m.hasOpt && m.optData[2] != 0 && m.time > 0) {
                // _Hokan: o "proximo" do ultimo frame e o frame 0. So le lixo quando o frame seguinte tem caixas E rotacao/alfa/zoom (campo 128),
                // porque o laco que pula as caixas usa o iHitNum do frame ATUAL; o OPT (64) so avanca o ponteiro, sem ler nada.
                Ano.Mpt n = a.mpts[(p + 1) % a.mpts.length];
                if (n.hasRaz && n.hits.length > 0 && n.hits.length != m.hits.length)
                    out.add(new Issue(ix, p, true, "interpolacao: o jogo le o frame seguinte pulando " + m.hits.length + " caixa(s) (as do frame ATUAL) em vez de " + n.hits.length
                            + "; a rotacao/alfa/zoom do alvo saem errados"));
            }
        }
    }

    /** Flag de hitbox que cria animacao/efeito: projetil (0), tremor (3-5), poeira (10-17), cutscene (20), zoom (30/31), teleporte (39/40), charf/auras (41-125). */
    private static boolean spawnsAnimation(int f) {
        return f == 0 || (f >= 3 && f <= 5) || (f >= 10 && f <= 17) || f == 20 || f == 30 || f == 31 || f == 39 || f == 40 || (f >= 41 && f <= 125);
    }

    /** O ANO, usado como link, tem links proprios ou algo que cria animacao/efeito (hit flags, poeira do OPT)? O jogo so le isso na raiz. */
    private static boolean hasIgnoredExtras(Ano c) {
        if (c.links.length > 0) return true;
        for (int p = 0; p < c.mpts.length; p++) {
            Ano.Mpt m = c.mpts[p];
            if (m.hasOpt && (m.optFlag & 0xF000) != 0) return true;
            for (int h = 0; h < m.hits.length; h++) if (spawnsAnimation(m.hits[h].flag)) return true;
        }
        return false;
    }

    /** ANOs (de {@code anos}; null = todos) que tem algum link com links proprios ou animacoes/efeitos: no jogo esses nao aparecem. */
    static List<Integer> nestedLinkParents(Dac dac, java.util.Collection<Integer> anos) {
        List<Integer> out = new ArrayList<Integer>();
        if (dac == null) return out;
        java.util.TreeSet<Integer> ids = new java.util.TreeSet<Integer>();
        if (anos == null) for (int i = 0; i < dac.size(); i++) ids.add(Integer.valueOf(i)); else ids.addAll(anos);
        for (Integer id : ids) {
            Ano a = id.intValue() >= 0 && id.intValue() < dac.size() ? dac.getAno(id.intValue()) : null;
            if (a == null || !a.present) continue;
            for (int k = 0; k < a.links.length; k++) {
                Ano c = dac.getAno(a.links[k].getAno());
                if (c != null && c.present && c != a && hasIgnoredExtras(c)) { out.add(id); break; }
            }
        }
        return out;
    }

    /** Linha para a lista de avisos; "" se nao ha o que avisar. */
    static String nestedLinksNote(Dac dac, java.util.Collection<Integer> anos) {
        List<Integer> p = nestedLinkParents(dac, anos);
        if (p.isEmpty()) return "";
        StringBuilder b = new StringBuilder(p.size() == 1 ? "O ANO " : "Os ANOs ");
        for (int i = 0; i < p.size(); i++) {
            if (i > 0) b.append(i == p.size() - 1 ? " e " : ", ");
            b.append(p.get(i));
        }
        return b.append(p.size() == 1 ? " tem" : " t\u00eam").append(" links que t\u00eam outros links ou anima\u00e7\u00f5es/efeitos; esses n\u00e3o aparecem (o jogo s\u00f3 l\u00ea a raiz): o link mostra apenas as sprites do link.").toString();
    }

    private static boolean hasHitbox(Ano.Mpt m) {
        for (int i = 0; i < m.hits.length; i++) if (m.hits[i].flag == 2) return true;
        return false;
    }

    /** Todas as linhas (fatais primeiro), uma por problema: o aviso expandido mostra isto em vez do "+N" do resumo. */
    static String details(List<Issue> issues) {
        if (issues == null || issues.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (int pass = 0; pass < 2; pass++)
            for (Issue i : issues) if (i.fatal == (pass == 0)) b.append(b.length() > 0 ? "\n" : "").append(i.fatal ? "O JOGO FECHA/ERRA: " : "Aviso do jogo: ").append(i);
        return b.toString();
    }

    /** Uma linha para a barra de avisos; "" se tudo certo. */
    static String summary(List<Issue> issues) {
        if (issues == null || issues.isEmpty()) return "";
        int fatal = 0;
        for (Issue i : issues) if (i.fatal) fatal++;
        Issue first = issues.get(0);
        for (Issue i : issues) if (i.fatal) { first = i; break; }
        return (fatal > 0 ? "O JOGO FECHA/ERRA: " : "Aviso do jogo: ") + first + (issues.size() > 1 ? " (+" + (issues.size() - 1) + ")" : "");
    }
}
