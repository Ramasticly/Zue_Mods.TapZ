package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Limites do jogo que o editor deixaria passar: o simulador aceita, mas no jogo a ANO estoura um array (ArrayIndexOutOfBounds dentro do
 * Run() do TCBManajer fecha o jogo) ou e ignorada. Java puro, sem Android.
 */
final class GameRules {
    private GameRules() { }

    /** Maximos do jogo (ObjReq.hit = int[50], ObjReq.lnk = ObjReq[13], MPT e time em 1 byte). */
    static final int MAX_HITS = 10, MAX_LINKS = 13, MAX_MPTS = 255, MAX_TIME = 255, MAX_OPT1 = 249;

    static final class Issue {
        final int ano, mpt;
        /** true = o jogo fecha ou le lixo; false = o jogo ignora o campo. */
        final boolean fatal;
        final String text;

        Issue(int ano, int mpt, boolean fatal, String text) {
            this.ano = ano;
            this.mpt = mpt;
            this.fatal = fatal;
            this.text = text;
        }

        @Override public String toString() { return "ANO " + ano + (mpt >= 0 ? " MPT " + mpt : "") + ": " + text; }
    }

    /** cnvEntries <= 0 desliga a checagem de imagem. */
    static List<Issue> check(Dac dac, java.util.Collection<Integer> anos, int cnvEntries) {
        List<Issue> out = new ArrayList<Issue>();
        if (dac == null) return out;
        boolean[] isLink = new boolean[dac.size()];
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            for (int k = 0; k < a.links.length; k++) {
                int t = a.links[k].getAno();
                if (t >= 0 && t < isLink.length) isLink[t] = true;
            }
        }
        if (anos == null) {
            for (int i = 0; i < dac.size(); i++) checkAno(dac, dac.getAno(i), isLink, cnvEntries, out);
        } else {
            for (Integer i : anos) if (i.intValue() >= 0 && i.intValue() < dac.size()) checkAno(dac, dac.getAno(i.intValue()), isLink, cnvEntries, out);
        }
        return out;
    }

    private static void checkAno(Dac dac, Ano a, boolean[] isLink, int cnvEntries, List<Issue> out) {
        if (a == null || !a.present) return;
        int ix = a.index;
        if (a.mpts.length > MAX_MPTS)
            out.add(new Issue(ix, -1, true, a.mpts.length + " frames: o DAC guarda a quantidade em 1 byte (maximo " + MAX_MPTS + ")"));
        if (a.links.length > MAX_LINKS)
            out.add(new Issue(ix, -1, true, a.links.length + " links: o jogo so tem " + MAX_LINKS + " (lnk[13]) e fecha ao criar o excedente"));
        if (isLink[ix] && a.links.length > 0)
            out.add(new Issue(ix, -1, false, "e link de outra ANO e tem links proprios: o jogo so tem 1 nivel de links (os links desta ANO nao nascem)"));
        boolean linkHits = false;
        for (int p = 0; p < a.mpts.length; p++) {
            Ano.Mpt m = a.mpts[p];
            if (m.hits.length > MAX_HITS)
                out.add(new Issue(ix, p, true, m.hits.length + " caixas no frame: o jogo guarda no maximo " + MAX_HITS + " (hit[50]) e fecha ao ler o excedente"));
            if (m.hasTime && m.time > MAX_TIME)
                out.add(new Issue(ix, p, true, "tempo " + m.time + ": o campo e 1 byte (maximo " + MAX_TIME + ")"));
            if (cnvEntries > 0 && m.image >= cnvEntries)
                out.add(new Issue(ix, p, false, "imagem " + m.image + " nao existe no CNV (" + cnvEntries + " entradas): o frame fica sem desenho"));
            if (m.hasOpt && m.optData[1] > MAX_OPT1 && hasHitbox(m))
                out.add(new Issue(ix, p, true, "OPT 1 = " + m.optData[1] + " com hitbox: o grupo " + (m.optData[1] / 50) + " nao existe (maximo " + MAX_OPT1 + ")"));
            if (m.hits.length > 0) linkHits |= isLink[ix];
            if (m.hasOpt && m.optData[2] != 0 && m.time > 0 && p + 1 < a.mpts.length) {
                Ano.Mpt n = a.mpts[p + 1];
                if (n.hits.length != m.hits.length && (n.hasRaz || n.hasOpt))
                    out.add(new Issue(ix, p, true, "interpolacao: o jogo le o frame seguinte pulando " + m.hits.length + " caixa(s) (as do frame ATUAL) em vez de " + n.hits.length
                            + "; a rotacao/alfa/zoom do alvo saem errados"));
            }
        }
        if (linkHits)
            out.add(new Issue(ix, -1, false, "e link de outra ANO e tem caixas (hit/hurt/flags): so as da ANO raiz valem, as do link sao ignoradas"));
    }

    private static boolean hasHitbox(Ano.Mpt m) {
        for (int i = 0; i < m.hits.length; i++) if (m.hits[i].flag == 2) return true;
        return false;
    }

    /** Uma linha para a barra de avisos; "" se tudo certo. */
    static String summary(List<Issue> issues) {
        if (issues == null || issues.isEmpty()) return "";
        int fatal = 0;
        for (Issue i : issues) if (i.fatal) fatal++;
        Issue first = issues.get(0);
        for (Issue i : issues) if (i.fatal) { first = i; break; }
        return (fatal > 0 ? "O JOGO FECHA/ERRA: " : "Aviso do jogo: ") + first + (issues.size() > 1 ? " (+" + (issues.size() - 1) + ")" : "");
    }
}
