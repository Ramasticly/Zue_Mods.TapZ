package com.zue.attackeditor;

/**
 * A tela do jogo num celular (Java puro), como o renderizador do jogo a monta (AndroidGLRender.InitScreen e DrawExec do TCBManajer):
 * <ul>
 * <li>a area de desenho tem {@code scalW = largura * 320 / altura} x 320 pontos do jogo, centrada no ponto (240, 160) da tela de 480 x 320;</li>
 * <li>todo objeto cuja prioridade de desenho esta na FAIXA DA CAMERA (do objeto-camera ate 299) passa pela matriz
 * {@code x' = 240 + (x - 240) * fGS * W/100 + T}, com {@code fGS = scalW / 480} mesmo sem zoom: fica esticado para a largura do celular e cortado em cima e embaixo;</li>
 * <li>fora da faixa (cutscene na Frente = 400, HUD, o efeito 328 e, na trava dos especiais, o que fica atras dos lutadores) o desenho e 1:1: 480 x 320 no meio,
 * com faixas nas laterais num celular largo.</li>
 * </ul>
 * O objeto-camera fica na prioridade 9; na trava dos especiais (e quando um lutador esta nas ANOs 61, 62, 51 ou 260) fica na menor chave dos lutadores menos 3 (md 31).
 */
final class GameScreen {
    static final int CAMERA_END = 299;
    static final int CAMERA_NORMAL = 9;

    /** Largura da area de desenho em pontos do jogo (altura sempre 320). */
    final int scalW;
    /** fScreenGameScale: quanto a faixa da camera e esticada sem zoom. */
    final float fGS;

    private GameScreen(int scalW) {
        this.scalW = Math.max(1, scalW);
        this.fGS = this.scalW / 480f;
    }

    /** Tela de um aparelho de {@code w} x {@code h} pixels (o jogo roda deitado: o lado maior e a largura). */
    static GameScreen of(int w, int h) {
        int big = Math.max(w, h), small = Math.max(1, Math.min(w, h));
        return new GameScreen(Math.round(big * 320f / small));
    }

    /** Tela de 480 x 320 sem esticar (3:2). */
    static GameScreen plain() { return new GameScreen(480); }

    float visLeft() { return 240f - scalW / 2f; }
    float visRight() { return 240f + scalW / 2f; }

    /** Inicio da faixa da camera (md 31): 9, ou a menor chave dos lutadores menos 3 na trava dos especiais / nas ANOs 61, 62, 51 e 260. */
    static int cameraStart(boolean specialLock, int atkKey, int oppKey, int anoAtk, int anoOpp) {
        boolean low = specialLock || isLowAno(anoAtk) || isLowAno(anoOpp);
        return low ? Math.min(atkKey, oppKey) - 3 : CAMERA_NORMAL;
    }

    private static boolean isLowAno(int a) { return a == 61 || a == 62 || a == 51 || a == 260; }

    /** O objeto de chave {@code key} passa pela matriz da camera? */
    static boolean inCamera(int key, int start) { return key >= start && key < CAMERA_END; }

    /**
     * Matriz {sx, sy, tx, ty} (x' = sx * x + tx) em coordenadas da tela do jogo (0..480 x 0..320) para um objeto de chave {@code key}.
     * {@code zoomW} = zoom da camera em % (100 sem zoom); {@code cx, cy} = centro do zoom na tela (240, 160 sem zoom).
     */
    float[] matrix(int key, int start, float zoomW, float cx, float cy) {
        if (!inCamera(key, start)) return new float[] {1f, 1f, 0f, 0f};
        float z = zoomW / 100f, s = fGS * z;
        return new float[] {s, s, 240f - 240f * s + (240f - cx) * z, 160f - 160f * s + (160f - cy) * z};
    }
}
