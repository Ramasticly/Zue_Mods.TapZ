package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;

/**
 * Desenho "igual ao jogo" do modo CENTRO: TELA: a tela deste aparelho ({@link GameScreen}) e, por camada, a matriz da camera do jogo
 * (lutadores, efeitos e cutscene Meio esticados e com zoom; Frente e o que escapa da camera 1:1). So tela.
 */
final class GameScreenDraw {
    private GameScreenDraw() { }

    /** Chave de um lutador comum: usada para o que nao e objeto do jogo (bordas, caixas do corpo, SPEEDLINE). */
    static final int FIGHTER_KEY = 150;

    private static GameScreen cached;

    /** A tela do jogo neste aparelho (tamanho real da tela, deitado). */
    static GameScreen forContext(Context c) {
        if (cached != null) return cached;
        int w, h;
        try {
            android.view.WindowManager wm = (android.view.WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            android.util.DisplayMetrics m = new android.util.DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(m);
            w = m.widthPixels; h = m.heightPixels;
        } catch (Throwable e) {
            w = c.getResources().getDisplayMetrics().widthPixels; h = c.getResources().getDisplayMetrics().heightPixels;
        }
        cached = GameScreen.of(w, h);
        return cached;
    }

    /** {scale, originX, originY}: enquadra a area de desenho do jogo (scalW x 320, centrada em 240, 160) na view. */
    static float[] fit(GameScreen gs, int viewW, int viewH) {
        float s = Math.min(viewW / (float) gs.scalW, viewH / 320f);
        return new float[] {s, viewW / 2f - 240f * s, viewH / 2f - 160f * s};
    }

    /** Aplica (depois de um save) a matriz de um objeto de chave {@code key}: o canvas, ja em coordenadas da tela do jogo, passa a receber coordenadas do mundo. */
    static void apply(Canvas c, BattleSim sim, GameScreen gs, int key) {
        float[] m = sim.gameXform(gs, key);
        c.translate(m[2], m[3]);
        c.scale(m[0], m[1]);
    }

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Contornos: a tela do celular (onde a camera desenha) e o 480 x 320 do meio (onde ficam a Frente e a HUD); aviso de tela cheia. {@code u} = 1 px da view. */
    static void frames(Canvas c, GameScreen gs, float u, boolean fullScreen) {
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(1.5f * u);
        P.setPathEffect(null);
        P.setColor(0xCCFFFFFF);
        c.drawRect(gs.visLeft(), 0f, gs.visRight(), 320f, P);
        if (gs.scalW != 480) {
            P.setColor(0x88FFD84C);
            P.setPathEffect(new DashPathEffect(new float[] {6f * u, 4f * u}, 0));
            c.drawRect(0f, 0f, 480f, 320f, P);
            P.setPathEffect(null);
        }
        P.setStyle(Paint.Style.FILL);
        P.setTextSize(10f * u);
        P.setColor(0xCCFFD84C);
        if (gs.scalW != 480) I18nUi.drawText(c, I18n.tr("480 x 320: Frente e HUD (1:1)"), 4f * u, 318f - 2f * u, P);
        if (fullScreen) {
            P.setColor(0xFFFF9A3C);
            P.setTextSize(11f * u);
            I18nUi.drawText(c, I18n.tr("TELA CHEIA: no jogo o cenário some"), gs.visLeft() + 4f * u, 14f * u, P);
        }
    }
}
