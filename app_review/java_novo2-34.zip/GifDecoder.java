package com.zue.attackeditor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Decodificador de GIF (87a/89a) em Java puro: devolve cada quadro cru (so a area do quadro), com descarte e atraso. */
final class GifDecoder {
    static final class Frame {
        int x, y, w, h;
        int disposal;         // 0/1 = deixa, 2 = fundo, 3 = anterior
        int delayMs;
        int[] argb;           // w*h; alfa 0 onde o indice e transparente
    }

    int width, height;
    final List<Frame> frames = new ArrayList<Frame>();

    private byte[] d;
    private int p;

    static boolean isGif(byte[] b) {
        return b != null && b.length > 10 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8';
    }

    static GifDecoder decode(byte[] data, int maxFrames) throws IOException {
        if (!isGif(data)) throw new IOException("nao e GIF");
        GifDecoder g = new GifDecoder();
        g.d = data;
        g.run(maxFrames);
        return g;
    }

    private int u8() throws IOException {
        if (p >= d.length) throw new IOException("GIF cortado");
        return d[p++] & 255;
    }

    private int u16() throws IOException { int a = u8(); return a | (u8() << 8); }

    private void run(int maxFrames) throws IOException {
        p = 6;
        width = u16();
        height = u16();
        int packed = u8();
        u8();
        u8();
        int[] gct = null;
        if ((packed & 0x80) != 0) gct = palette(1 << ((packed & 7) + 1));
        int disposal = 0, delay = 0, trans = -1;
        while (p < d.length) {
            int b = u8();
            if (b == 0x3B) break;
            if (b == 0x21) {
                int label = u8();
                if (label == 0xF9) {
                    int sz = u8();
                    int pk = u8();
                    delay = u16() * 10;
                    int ti = u8();
                    disposal = (pk >> 2) & 7;
                    trans = (pk & 1) != 0 ? ti : -1;
                    p += Math.max(0, sz - 4);
                    skipBlocks();
                } else skipBlocks();
            } else if (b == 0x2C) {
                Frame f = new Frame();
                f.x = u16(); f.y = u16(); f.w = u16(); f.h = u16();
                int ip = u8();
                int[] pal = gct;
                if ((ip & 0x80) != 0) pal = palette(1 << ((ip & 7) + 1));
                boolean interlace = (ip & 0x40) != 0;
                int minCode = u8();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                for (int n = u8(); n > 0; n = u8()) {
                    if (p + n > d.length) throw new IOException("GIF cortado");
                    bo.write(d, p, n);
                    p += n;
                }
                if (f.w <= 0 || f.h <= 0 || (long) f.w * f.h > 16000000L) throw new IOException("quadro de GIF invalido");
                byte[] idx = lzw(bo.toByteArray(), minCode, f.w * f.h);
                f.argb = new int[f.w * f.h];
                for (int row = 0; row < f.h; row++) {
                    int src = interlace ? interlacedRow(row, f.h) : row;
                    for (int x = 0; x < f.w; x++) {
                        int ci = idx[row * f.w + x] & 255;
                        int dst = src * f.w + x;
                        if (ci == trans || pal == null || ci >= pal.length) f.argb[dst] = 0;
                        else f.argb[dst] = pal[ci];
                    }
                }
                f.disposal = disposal;
                f.delayMs = delay;
                frames.add(f);
                ImageImport.report("Lendo quadros do GIF", frames.size(), 0);
                disposal = 0; delay = 0; trans = -1;
                if (frames.size() >= maxFrames) break;
            } else {
                throw new IOException("bloco de GIF desconhecido");
            }
        }
        if (frames.isEmpty()) throw new IOException("GIF sem quadros");
        if (width <= 0 || height <= 0) { width = frames.get(0).w; height = frames.get(0).h; }
    }

    private int[] palette(int n) throws IOException {
        int[] pal = new int[n];
        for (int i = 0; i < n; i++) pal[i] = 0xFF000000 | (u8() << 16) | (u8() << 8) | u8();
        return pal;
    }

    private void skipBlocks() throws IOException {
        for (int n = u8(); n > 0; n = u8()) p += n;
    }

    /** Linha de saida (na imagem final) da linha {@code i} do fluxo entrelacado. */
    private static int interlacedRow(int i, int h) {
        int pass1 = (h + 7) / 8, pass2 = (h + 3) / 8, pass3 = (h + 1) / 4;
        if (i < pass1) return i * 8;
        i -= pass1;
        if (i < pass2) return 4 + i * 8;
        i -= pass2;
        if (i < pass3) return 2 + i * 4;
        i -= pass3;
        return 1 + i * 2;
    }

    private static byte[] lzw(byte[] in, int minCode, int outLen) throws IOException {
        byte[] out = new byte[outLen];
        if (minCode < 1 || minCode > 11) throw new IOException("LZW invalido");
        int clear = 1 << minCode, end = clear + 1, next = clear + 2, size = minCode + 1, mask = (1 << size) - 1;
        short[] prefix = new short[4096];
        byte[] suffix = new byte[4096];
        byte[] stack = new byte[4097];
        for (int i = 0; i < clear; i++) suffix[i] = (byte) i;
        int bits = 0, datum = 0, pos = 0, o = 0, old = -1, first = 0;
        while (o < outLen) {
            while (bits < size) {
                if (pos >= in.length) return out;           // dados acabaram: o resto fica 0
                datum |= (in[pos++] & 255) << bits;
                bits += 8;
            }
            int code = datum & mask;
            datum >>>= size;
            bits -= size;
            if (code == clear) { size = minCode + 1; mask = (1 << size) - 1; next = clear + 2; old = -1; continue; }
            if (code == end) break;
            if (old == -1) {
                if (code >= 4096) throw new IOException("LZW invalido");
                out[o++] = suffix[code];
                old = code; first = code;
                continue;
            }
            int in2 = code, sp = 0;
            if (code >= next) { stack[sp++] = (byte) first; in2 = old; }
            while (in2 >= clear) {
                if (sp >= 4096) throw new IOException("LZW invalido");
                stack[sp++] = suffix[in2];
                in2 = prefix[in2];
            }
            first = suffix[in2] & 255;
            stack[sp++] = (byte) first;
            if (next < 4096) {
                prefix[next] = (short) old;
                suffix[next] = (byte) first;
                next++;
                if ((next & mask) == 0 && next < 4096) { size++; mask = (1 << size) - 1; }
            }
            old = code;
            while (sp > 0 && o < outLen) out[o++] = stack[--sp];
        }
        return out;
    }
}
