package com.zue.attackeditor;

/**
 * "Otimizar GIF": acha quadros iguais ou parecidos (em qualquer ponto da animacao, nao so vizinhos) para reaproveitar uma so sprite.
 * Cada quadro vira uma assinatura reduzida (ate 128 px) + um hash dos pixels reais (100% = identico de verdade).
 */
final class GifOptimizer {
    private GifOptimizer() { }

    static final int MIN_PCT = 50;
    private static final int TOL = 12;          // diferenca por canal a partir da qual o pixel conta como diferente
    private static final int SIDE = 128;

    static final class Sig {
        int w, h, rw, rh, hash;
        int[] px;
    }

    static final class Analysis {
        int n;
        int[] sprite;          // sprite de cada quadro (-1 = vazio)
        boolean[] valid;
        int[][] score;         // score[i][j]: 0..100 (100 = identico), simetrico
        int[] first;           // primeiro quadro que usa a mesma sprite (preenchido sob demanda por ensureFirst)
    }

    static Sig sig(int[] full, int w, int h) {
        Sig s = new Sig();
        s.w = w; s.h = h;
        int hs = 17;
        for (int i = 0; i < full.length; i++) {
            int p = full[i];
            if ((p >>> 24) == 0) p = 0;                       // RGB escondido pela transparencia nao conta
            hs = hs * 31 + p;
        }
        s.hash = hs * 31 + w * 7 + h;
        int k = Math.max(1, (Math.max(w, h) + SIDE - 1) / SIDE);
        s.rw = (w + k - 1) / k; s.rh = (h + k - 1) / k;
        s.px = new int[s.rw * s.rh];
        for (int y = 0; y < s.rh; y++) {
            for (int x = 0; x < s.rw; x++) {
                long a = 0, r = 0, g = 0, b = 0;
                int c = 0;
                for (int yy = y * k; yy < Math.min(h, y * k + k); yy++) {
                    for (int xx = x * k; xx < Math.min(w, x * k + k); xx++) {
                        int p = full[yy * w + xx];
                        a += p >>> 24; r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255;
                        c++;
                    }
                }
                s.px[y * s.rw + x] = c == 0 ? 0 : ((int) (a / c) << 24) | ((int) (r / c) << 16) | ((int) (g / c) << 8) | (int) (b / c);
            }
        }
        return s;
    }

    /** 0..100: porcentagem de pixels iguais; 100 so se os pixels reais forem identicos; 0 = tamanho diferente ou menos que MIN_PCT. */
    static int score(Sig a, Sig b) {
        if (a.w != b.w || a.h != b.h) return 0;
        if (a.hash == b.hash) return 100;
        int n = a.px.length, limit = n - n * MIN_PCT / 100, bad = 0;
        for (int i = 0; i < n; i++) {
            int p = a.px[i], q = b.px[i];
            if (p == q) continue;
            int pa = p >>> 24, qa = q >>> 24;
            if (pa == 0 && qa == 0) continue;
            int d = Math.abs(pa - qa);
            d = Math.max(d, Math.abs(((p >> 16) & 255) - ((q >> 16) & 255)));
            d = Math.max(d, Math.abs(((p >> 8) & 255) - ((q >> 8) & 255)));
            d = Math.max(d, Math.abs((p & 255) - (q & 255)));
            if (d > TOL && ++bad > limit) return 0;
        }
        return Math.min(99, (int) Math.floor(100.0 * (n - bad) / n));
    }

    /**
     * repr[k] = quadro que representa o quadro k (k se ele fica; outro quadro anterior se for reaproveitado; -1 se vazio).
     * Cada quadro e comparado so com os que ficaram, e vai para o mais parecido que atinja minPct.
     */
    static int[] match(Analysis an, int minPct) {
        int[] repr = new int[an.n];
        ensureFirst(an);
        for (int k = 0; k < an.n; k++) {
            if (!an.valid[k]) { repr[k] = -1; continue; }
            if (an.first[k] != k) { repr[k] = repr[an.first[k]]; continue; }    // mesma sprite de um quadro anterior: segue a decisao dele
            int best = k, bs = -1;
            for (int j = 0; j < k; j++) {
                if (!an.valid[j] || repr[j] != j) continue;
                int sc = an.score[j][k];
                if (sc >= minPct && sc > bs) { bs = sc; best = j; }
            }
            repr[k] = best;
        }
        return repr;
    }

    /** Preenche {@code an.first} (primeiro quadro valido que usa a mesma sprite) se ainda nao foi; seguro chamar varias vezes, em qualquer ordem. */
    static void ensureFirst(Analysis an) {
        if (an.first != null && an.first.length == an.n) return;
        an.first = new int[an.n];
        for (int k = 0; k < an.n; k++) {
            an.first[k] = k;
            for (int j = 0; j < k; j++) if (an.valid[j] && an.sprite[j] == an.sprite[k]) { an.first[k] = j; break; }
        }
    }

    /** Sprites distintas (com imagem) usadas pelos quadros. */
    static int distinctSprites(Analysis an) {
        ensureFirst(an);
        int n = 0;
        for (int k = 0; k < an.n; k++) if (an.valid[k] && an.first[k] == k) n++;
        return n;
    }

    /** Quantas sprites deixam de ser usadas (cada sprite conta uma vez, mesmo usada em varios quadros). */
    static int removedCount(Analysis an, int[] repr) {
        ensureFirst(an);
        int n = 0;
        for (int k = 0; k < repr.length; k++) if (repr[k] >= 0 && an.first[k] == k && repr[k] != k) n++;
        return n;
    }

    /**
     * Sprites do GIF que saem no APLICAR: todas as VAZIAS (as que o reaproveitamento acabou de liberar e as que ja eram vazias).
     * {@code hasPixels[k]} = a sprite {@code first + k} ainda tem desenho depois do reaproveitamento. Em ordem.
     */
    static java.util.TreeSet<Integer> toDelete(int first, int count, boolean[] hasPixels) {
        java.util.TreeSet<Integer> out = new java.util.TreeSet<Integer>();
        for (int k = 0; k < count; k++) if (k >= hasPixels.length || !hasPixels[k]) out.add(Integer.valueOf(first + k));
        return out;
    }
}
