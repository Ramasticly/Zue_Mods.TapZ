package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

/** Toca em laco uma lista de imagens com os atrasos de um GIF (Antes/Depois do Otimizar GIF). Quadro sem imagem (sprite vazia) fica em branco pelo tempo dele. */
final class GifPlayView extends View {
    private Bitmap[] frames = new Bitmap[0];
    private int[] delays = new int[0];
    private long start = SystemClock.uptimeMillis();
    private final Paint p = new Paint();
    private final RectF dst = new RectF();

    GifPlayView(Context c) {
        super(c);
        setBackgroundColor(0xFF0D0F13);
        p.setFilterBitmap(false);
    }

    /** Troca os quadros (os bitmaps pertencem a quem chama; a view so desenha). */
    void set(Bitmap[] f, int[] d) {
        frames = f == null ? new Bitmap[0] : f;
        delays = d == null ? new int[0] : d;
        start = SystemClock.uptimeMillis();
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int i = GifTiming.frameAt(delays, SystemClock.uptimeMillis() - start);
        if (i >= 0 && i < frames.length && frames[i] != null && !frames[i].isRecycled()) {
            Bitmap b = frames[i];
            float s = Math.min(getWidth() / (float) b.getWidth(), getHeight() / (float) b.getHeight());
            float w = b.getWidth() * s, h = b.getHeight() * s;
            dst.set((getWidth() - w) / 2f, (getHeight() - h) / 2f, (getWidth() + w) / 2f, (getHeight() + h) / 2f);
            c.drawBitmap(b, null, dst, p);
        }
        if (frames.length > 1) postInvalidateOnAnimation();
    }
}
