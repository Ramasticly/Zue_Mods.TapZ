package com.zue.attackeditor;

/** Qual quadro de um GIF aparece num instante (puro): atrasos por quadro, em laco. */
final class GifTiming {
    private GifTiming() { }

    static long total(int[] delays) {
        long t = 0;
        for (int d : delays) t += Math.max(1, d);
        return t;
    }

    /** Indice do quadro em {@code ms} desde o inicio (-1 se nao ha quadros). */
    static int frameAt(int[] delays, long ms) {
        if (delays == null || delays.length == 0) return -1;
        long t = Math.max(0L, ms) % total(delays);
        for (int i = 0; i < delays.length; i++) {
            t -= Math.max(1, delays[i]);
            if (t < 0) return i;
        }
        return delays.length - 1;
    }
}
