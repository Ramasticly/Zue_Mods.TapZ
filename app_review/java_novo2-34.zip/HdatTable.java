package com.zue.attackeditor;

import java.io.IOException;

/**
 * Cabecalho "BIN_CNV" usado por gamedata e pelo 000.bin dos personagens (mesmo formato do BinExtractor):
 * u16 quantidade; depois, por HDAT, 8 bytes: u32 offset, u16 colunas, u16 linhas. Little-endian.
 */
public final class HdatTable {
    private final byte[] data;
    private final int[] off;
    private final int[] cols;
    private final int[] rows;
    private final int count;

    private HdatTable(byte[] data, int[] off, int[] cols, int[] rows, int count) {
        this.data = data;
        this.off = off;
        this.cols = cols;
        this.rows = rows;
        this.count = count;
    }

    public static HdatTable parse(byte[] d) throws IOException {
        if (d == null || d.length < 2) throw new IOException("arquivo HDAT vazio");
        int count = (d[0] & 255) | ((d[1] & 255) << 8);
        if (count <= 0 || 2 + count * 8 > d.length) throw new IOException("cabecalho HDAT invalido");
        int[] off = new int[count + 1];
        int[] cols = new int[count];
        int[] rows = new int[count];
        for (int i = 0; i < count; i++) {
            int p = 2 + i * 8;
            off[i] = (d[p] & 255) | ((d[p + 1] & 255) << 8) | ((d[p + 2] & 255) << 16) | ((d[p + 3] & 255) << 24);
            cols[i] = (d[p + 4] & 255) | ((d[p + 5] & 255) << 8);
            rows[i] = (d[p + 6] & 255) | ((d[p + 7] & 255) << 8);
        }
        off[count] = d.length;
        for (int i = 0; i < count; i++) {
            if (off[i] < 0 || off[i] > d.length || off[i] > off[i + 1])
                throw new IOException("offset do HDAT " + i + " fora do arquivo");
        }
        return new HdatTable(d, off, cols, rows, count);
    }

    /** null quando os bytes nao tem cara de HDAT (usado para descobrir arquivos). */
    public static HdatTable tryParse(byte[] d) {
        try {
            return parse(d);
        } catch (IOException e) {
            return null;
        }
    }

    public int size() { return count; }
    public int cols(int i) { return i >= 0 && i < count ? cols[i] : 0; }
    public int rows(int i) { return i >= 0 && i < count ? rows[i] : 0; }
    public int start(int i) { return off[i]; }
    public int length(int i) { return i >= 0 && i < count ? off[i + 1] - off[i] : 0; }

    /** Copia dos bytes do HDAT i (vazio se nao existir). */
    public byte[] bytes(int i) {
        if (i < 0 || i >= count) return new byte[0];
        byte[] b = new byte[off[i + 1] - off[i]];
        System.arraycopy(data, off[i], b, 0, b.length);
        return b;
    }
}
