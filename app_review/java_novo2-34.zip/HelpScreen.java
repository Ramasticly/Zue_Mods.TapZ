package com.zue.attackeditor;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Tela cheia da ajuda: lista de capitulos (titulo + resumo), cada um abre o texto dele; a busca por palavra mostra as secoes de qualquer capitulo.
 * O botao voltar do aparelho volta da secao para a lista antes de fechar.
 */
final class HelpScreen {
    private final Context c;
    private final float d;
    private final Runnable resetToolbar;
    private Dialog dlg;
    private LinearLayout body;
    private ScrollView sv;
    private EditText search;
    private TextView backBtn, titleView;
    private HelpText.Chapter open;

    HelpScreen(Context c, Runnable resetToolbar) {
        this.c = c;
        this.resetToolbar = resetToolbar;
        this.d = c.getResources().getDisplayMetrics().density;
    }

    private int dp(int v) { return Math.round(v * d); }

    void show() {
        dlg = new Dialog(c, android.R.style.Theme_DeviceDefault_NoActionBar) {
            @Override public void onBackPressed() {
                if (open != null || search.getText().length() > 0) { search.setText(""); open = null; render(); } else super.onBackPressed();
            }
        };
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(26), dp(10), dp(8));

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        backBtn = btn("◀", false, new View.OnClickListener() { public void onClick(View v) { search.setText(""); open = null; render(); } });
        head.addView(backBtn);
        titleView = new TextView(c);
        titleView.setTextColor(LayoutManager.TEXT);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        titleView.setPadding(dp(6), 0, 0, 0);
        head.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(btn("Ajuda de IA", false, new View.OnClickListener() { public void onClick(View v) { aiHelp(); } }));
        head.addView(btn("FECHAR", true, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }));
        root.addView(head);

        search = new EditText(c);
        search.setHint("Buscar na ajuda (ex.: speed, SEQ, reação, bit 64)");
        search.setHintTextColor(LayoutManager.DIM);
        search.setTextColor(LayoutManager.TEXT);
        search.setSingleLine(true);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int n) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int n) { }
            @Override public void afterTextChanged(Editable e) { if (e.length() > 0) open = null; render(); }
        });
        root.addView(search, new LinearLayout.LayoutParams(-1, -2));

        sv = new ScrollView(c);
        body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(4), dp(2), dp(24));
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        dlg.setContentView(root);
        dlg.show();
        render();
    }

    private void render() {
        body.removeAllViews();
        String q = search.getText().toString();
        if (q.trim().length() > 0) { renderSearch(q); sv.scrollTo(0, 0); return; }
        if (open != null) { renderChapter(open); sv.scrollTo(0, 0); return; }
        titleView.setText("Ajuda");
        backBtn.setVisibility(View.GONE);
        TextView intro = text("Toque num capítulo para ler. Use a busca para achar uma palavra em qualquer capítulo.", LayoutManager.DIM, 12, false);
        intro.setPadding(dp(4), dp(8), dp(4), dp(8));
        body.addView(intro);
        LinearLayout ai = new LinearLayout(c);
        ai.setOrientation(LinearLayout.VERTICAL);
        ai.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable ag = new GradientDrawable();
        ag.setColor(LayoutManager.PANEL);
        ag.setCornerRadius(dp(10));
        ag.setStroke(dp(1), LayoutManager.ACCENT);
        ai.setBackground(ag);
        ai.addView(text("Ajuda de IA", LayoutManager.ACCENT, 15, true));
        ai.addView(text("Cria o arquivo " + AiHelp.FILE_NAME + " em Download/ e abre o compartilhar. Envie-o a uma IA e faça perguntas sobre como criar ataques, onde salvar, como testar…", LayoutManager.DIM, 12, false));
        ai.setClickable(true);
        ai.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { aiHelp(); } });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.setMargins(0, dp(3), 0, dp(8));
        body.addView(ai, alp);
        for (final HelpText.Chapter ch : HelpText.chapters()) {
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            GradientDrawable g = new GradientDrawable();
            g.setColor(LayoutManager.PANEL);
            g.setCornerRadius(dp(10));
            card.setBackground(g);
            card.addView(text(ch.title, LayoutManager.TEXT, 15, true));
            card.addView(text(ch.summary, LayoutManager.DIM, 12, false));
            card.setClickable(true);
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { open = ch; render(); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(3), 0, dp(3));
            body.addView(card, lp);
        }
    }

    private void aiHelp() {
        if (c instanceof android.app.Activity) AiHelpShare.run((android.app.Activity) c);
        else android.widget.Toast.makeText(c, "Disponível só dentro do app", android.widget.Toast.LENGTH_SHORT).show();
    }

    private void renderChapter(HelpText.Chapter ch) {
        titleView.setText(ch.title);
        backBtn.setVisibility(View.VISIBLE);
        TextView sum = text(ch.summary, LayoutManager.DIM, 12, false);
        sum.setPadding(dp(4), dp(6), dp(4), dp(8));
        body.addView(sum);
        if (HelpText.CH_MENU.equals(ch.id) && resetToolbar != null) {
            body.addView(btn("RESTAURAR ORDEM DOS BOTÕES", false, new View.OnClickListener() { public void onClick(View v) {
                resetToolbar.run();
                android.widget.Toast.makeText(c, "Ordem padrao restaurada", android.widget.Toast.LENGTH_SHORT).show();
            } }));
        }
        for (HelpText.Section s : ch.sections) section(s, null, false, "");
    }

    private void renderSearch(String q) {
        titleView.setText("Busca");
        backBtn.setVisibility(View.VISIBLE);
        java.util.List<HelpText.Hit> hits = HelpText.search(q);
        TextView n = text(hits.isEmpty() ? "Nada encontrado para \"" + q.trim() + "\"." : hits.size() + (hits.size() == 1 ? " resultado" : " resultados") + " (aceita erros de digitação e palavras parecidas)", LayoutManager.DIM, 12, false);
        n.setPadding(dp(4), dp(6), dp(4), dp(6));
        body.addView(n);
        boolean tabsHeader = false, textsHeader = false;
        for (HelpText.Hit h : hits) {
            if (h.tab && !tabsHeader) { tabsHeader = true; body.addView(band("ABAS E MENUS")); }
            if (!h.tab && !textsHeader) { textsHeader = true; body.addView(band("TEXTOS")); }
            LinearLayout card = section(h.section, h.chapter.title, h.tab && h == hits.get(0), h.snippet);
            if (!h.tab && h.snippet.length() > 0) {
                final HelpText.Chapter ch = h.chapter;
                card.setClickable(true);
                card.addView(text("Toque para abrir o capítulo", LayoutManager.DIM, 10, false));
                card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { search.setText(""); open = ch; render(); } });
            }
        }
    }

    private TextView band(String s) {
        TextView t = text(s, LayoutManager.ACCENT, 11, true);
        t.setPadding(dp(4), dp(10), dp(4), dp(2));
        return t;
    }

    private LinearLayout section(HelpText.Section s, String chapterTitle, boolean best, String snippet) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        if (best) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(LayoutManager.PANEL);
            g.setCornerRadius(dp(10));
            g.setStroke(dp(2), LayoutManager.ACCENT);
            box.setBackground(g);
            box.addView(text("MELHOR RESULTADO", LayoutManager.ACCENT, 10, true));
        }
        if (chapterTitle != null) box.addView(text(chapterTitle, LayoutManager.ACCENT, 11, true));
        box.addView(text(s.title, LayoutManager.TEXT, 15, true));
        // na busca, os textos mostram so o trecho que bateu; as abas e a leitura do capitulo mostram tudo
        boolean excerpt = chapterTitle != null && !s.tab && snippet != null && snippet.length() > 0;
        TextView b = text(excerpt ? snippet : s.body, 0xFFC4C9D4, 13, false);
        b.setLineSpacing(0f, 1.15f);
        box.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(2));
        body.addView(box, lp);
        return box;
    }

    private TextView text(String s, int color, int sp, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(2), dp(2), dp(2), dp(2));
        return t;
    }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(4), dp(2), dp(4));
        t.setLayoutParams(p);
        return t;
    }
}
