package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Texto do menu AJUDA: o que cada botao do menu superior e da tela faz, visto pela utilidade em editar e executar um golpe.
 * Java puro (testado sem Android). Os ids dos botoes do menu superior sao os de {@link ToolbarOrder}.
 */
final class HelpText {
    private HelpText() { }

    static final class Section {
        /** id de {@link ToolbarOrder} se a secao descreve um botao do menu superior; null nas demais. */
        final String button;
        final String title, body;
        /** Aba / menu / tela de edicao (botao do menu superior, pagina da sprite, menu da hitbox...): vai antes dos textos na busca. */
        final boolean tab;
        /** Palavras relacionadas (sinonimos), as mais importantes primeiro. Vazio nas secoes que nao sao abas. */
        final String tags;
        String[] tokTitle, tokTags, tokBody;

        Section(String button, String title, String body) {
            this.button = button;
            this.title = title;
            this.body = body;
            String t = Tags.BY_TITLE.get(title);
            this.tags = t == null ? "" : t;
            this.tab = t != null;
        }
    }

    /** Tags das abas, por titulo da secao. A ordem importa: a primeira palavra pesa mais na busca. */
    private static final class Tags {
        static final java.util.Map<String, String> BY_TITLE = new java.util.HashMap<String, String>();
        private static void t(String title, String tags) { BY_TITLE.put(title, tags); }
        static {
            t("SALVAR", "salvar gravar save backup pasta runtime exportar copia transplante outro personagem txt");
            t("CHAR", "personagem char lutador atacante oponente pos distancia altura fly voar corpo hdat 3 ancora");
            t("SPRITES", "sprites sprite imagem recorte cnv png folha adicionar substituir remover");
            t("SONS", "sons som audio wav ogg global se_ cortar volume tom velocidade silenciar substituir mutar");
            t("LINKS", "links link filho aura efeito sincronia animacao ligada pai");
            t("GOLPE SET", "golpe set atk_flags agarrao agarrar projetil 3 tiro triplo atravessar flags opcoes");
            t("SPEEDLINE", "speedline trajetoria ponto linha verde arrastar preset zerar remover");
            t("HITBOX", "hitbox hurtbox caixa caixas ataque dano alcance vermelha azul amarela desenho");
            t("TEMPO", "tempo normal estendido ataque reproducao simulacao");
            t("CENTRO", "centro camera zoom enquadrar tela char");
            t("POUSO", "pouso chao queda cair aterrissar gravidade seq end");
            t("TRANSIÇÃO", "transicao trava travada travar sequencia seq fluxo trocar ano");
            t("VIRAR", "virar flip espelhar lado inverter espelhamento");
            t("HIDE-EFF", "hide esconder efeitos aura cena projeteis bobj");
            t("FR-PREVIEW", "frame preview ghost transparencia anterior proximo prev next alinhar");
            t("TELA", "tela grade sons cenas cutscene travar box amarela fr-preview opcoes");
            t("Menu da sprite (gaveta)", "sprite menu gaveta imagem tempo som movimento efeitos copiar grade");
            t("Imagem", "imagem sprite posicao zoom rotacao alpha thumb link x y");
            t("Tempo", "tempo duracao ticks segundos time frame remover frame");
            t("Som", "som audio sfx wav efeito sonoro id tocar");
            t("Movimento", "speed velocidade dash accel aceleracao mover andar correr deslocar deslocamento pixels recuo pulo salto queda gravidade manter bit 64 px");
            t("Efeitos", "efeitos flip espelhar interpolacao suavizar rotacao alpha zoom");
            t("Copiar", "copiar colar aplicar frames todos proximos duplicar");
            t("Hitbox / Hurtbox", "hitbox hurtbox caixa caixas ataque dano alcance inicio duracao coordenadas largura altura");
            t("Dano e reação", "dano reacao hit acertar knockback empurrao opt 1 hitstun grupo");
            t("Transição no menu da hitbox", "transicao seq end sequencia destino bloquear flag 38 ano destino");
            t("GOLPE SET (ATK_FLAGS)", "golpe set atk_flags agarrao projetil 3 tiro triplo atravessar destruir hitbox oponente flags opcoes");
            t("DADOS / EDITAR", "dados editar texto hdat 4 ano frame links lapis painel");
            t("Tela do projétil", "projetil tiro bala fireball ano inicio duracao posicao velocidade perseguicao sequencia");
            t("Ramificação do projétil", "ramificacao projetil arvore ramo sub-projetil reacao caminho");
            t("TRANSIÇÃO travada e VER FLUXO", "transicao travada fluxo sequencia seq ver fluxo");
            t("Escolher reação e slots vazios", "reacao slot vazio slots escolher importar copiar personagem game data 14 33");
            t("Editor de reações", "reacao reacoes editor timeline passo passos speed velocidade voz efeitos parede seq dividir knockback empurrao hitstun duracao ano oponente");
            t("Barra de ferramentas da reação", "dividir duplicar excluir apagar mais adicionar reacao passo speed voz parede seq total desfazer ferramentas cortar");
            t("Faixas da timeline", "timeline faixas faixa sprite hitbox speed som estilo");
            t("＋ e #", "adicionar mais novo criar numero");
            t("DIVIDIR / DUPLICAR / EXCLUIR / DESFAZER", "dividir duplicar excluir apagar remover desfazer undo cortar");
            t("Recarregar pastas (↻)", "recarregar reload atualizar pastas personagem apagar adicionar nova pasta reiniciar refresh");
            t("Ajuda de IA (TBRHelp.md)", "ia ai inteligencia artificial chatgpt gemini claude arquivo markdown md download compartilhar ajuda perguntas tbrhelp prompt");
            t("Altura da gaveta: Y e T", "altura gaveta alca y t timeline tamanho");
            t("Onde salvar", "salvar pasta separada runtime backup caminho tap battle tbre chars");
            t("Salvar em outro personagem", "transplante transplantar outro personagem salvar golpe substituir hdat 4");
        }
    }

    /** Dica de como mexer na propria barra (vai no topo da ajuda). */
    static final String REORDER_TIP =
            "ORDEM DOS BOTÕES: segure um botão do menu superior e arraste para frente ou para trás para mudar a ordem; "
            + "perto da borda a barra rola sozinha. O primeiro botão fica fixo no início da linha (hoje, por padrão, o SALVAR): "
            + "solte qualquer botão em cima dele para ele virar o fixo. A ordem fica salva no aparelho. "
            + "RESTAURAR ORDEM volta ao padrão.";

    /** Menu superior, na ordem de fabrica. */
    static List<Section> toolbar() {
        List<Section> s = new ArrayList<Section>();
        s.add(new Section(ToolbarOrder.SAVE, "SALVAR",
                "Grava as edições em .txt: o golpe atual (HDAT 4 + os ANOs dele), só o ANO atual, todos os golpes, todos os ANOs ou tudo. "
                + "Dá para salvar numa pasta separada ou sobrescrever os .txt do Runtime (Tap Battle/assets/charNN/). A pasta separada (Tap Battle/TBRE/Chars/charNN/) é uma cópia COMPLETA do personagem (DAC, BIN, CNV, folhas, sons) com a mesma gravação do Runtime aplicada nela: fica pronta para usar, e o original não muda; se a pasta já existe o app pergunta se une (mantém o que já está lá e aplica por cima), deleta e copia de novo ou usa outro nome. "
                + "Em \"Salvar golpe atual\" há ainda \"Salvar em outro personagem (Runtime)\": escolhe o personagem (pastas char de assets), depois o golpe a substituir (os golpes 0, 3 e 6 só substituem o 0, 3 e 6; os demais, qualquer um fora esses três) e grava direto no Runtime dele, com cópia dos .txt dele em Tap Battle/TBRE/Backups/: o golpe do HDAT 4 é trocado, os ANOs entram no fim do DAC (renumerados), as sprites usadas entram no fim do CNV e das folhas, e as reações do personagem usadas vão para um slot livre. Sons do personagem (id 80+) e hitbox flags 20 e 41-125 não vão junto. "
                + "Ao salvar, o app confere os limites do jogo (hitboxes por frame, links, tempo...) e avisa o que faria o jogo fechar."
                + " Ao salvar em outro personagem o app faz por etapas: 1) pergunta se quer salvar as Sprites também (NÃO: os ANOs são copiados com IMG -1 e o CNV/as folhas do destino não mudam); 2) para cada reação do golpe: se o destino já tem uma igual, só o OPT 1 passa a usar ela; senão usa uma tabela de reação vazia dele; se não houver, abre a tela de escolha, com a prévia da reação a copiar em cima e a grade das reações do destino embaixo — tocar numa abre SUBSTITUIR (escreve por cima dela) e USAR ESSA (o golpe passa a usar a que já existe, sem gravar nada); 3) confirma e grava."));
        s.add(new Section(ToolbarOrder.CHAR, "CHAR",
                "Escolhe o ATACANTE e o OPONENTE (cada um com os próprios dados e sprites). POS ajusta a distância entre eles e a altura de cada um "
                + "arrastando na tela (as linhas são as posições do jogo: perto, médio, longe) e tem o FLY, que deixa o atacante voando em vez de cair. "
                + "CHAR OBJ mostra a caixa do corpo (HDAT 3) e as âncoras dos sprites, hurtboxes, hitboxes, efeitos e projéteis, e permite mudar o tamanho do corpo. "
                + "Use para testar o golpe contra outros lutadores e em outras alturas: a altura relativa decide qual ANO de projétil nasce (normal, de baixo ou de cima)."
                + " A escolha de atacante e oponente é uma grade escura (3 colunas) em que cada charNN toca a ANO 76 dele (a ANO 0 se não tiver) e o atual vem destacado. Na linha OPONENTE: charNN | DEF, a caixa DEF (desligada por padrão) faz o oponente defender, para testar o golpe sendo defendido: sem dano nem reação, ele fica em guarda (ANO 4, ou 81 no ar) e é empurrado (13, decaindo 2 por tick), com o hitstop do OPT 1, o efeito de defesa (ANO 2) e o SE 8 nos grupos 0 a 3; só perde 2 de vida se o ANO do golpe for 40 ou mais e o dano não for 0. Hitbox com a flag 26 (inimigo não defende) e agarrões não são defendidos, e o golpe defendido também confirma o hit (ANIM_SEQ/ANIM_END acontecem)."));
        s.add(new Section(ToolbarOrder.SPRITES, "SPRITES",
                "Lista os sprites (SPR_0, SPR_1...) do personagem atacante, já recortados pelo CNV; as folhas ficam intactas no disco. "
                + "Serve para adicionar, substituir e remover sprites, mudar o recorte e o índice, e para escolher qual sprite entra num frame do golpe."));
        s.add(new Section(ToolbarOrder.SOUNDS, "SONS",
                "Gerencia os sons, sem escolher nenhum para um frame (para escolher, use a página Som do menu do sprite). Lista os sons do personagem (WAV da pasta dele, ids 80+) e os sons comuns do jogo (OGG se_, ids 1 a 79 e 100 a 255). "
                + "O + adiciona um som: do personagem (WAV) ou global (OGG, que vira o próximo se_ livre). Tocar um item abre as opções: ouvir, cortar, mais (volume, tom, velocidade), substituir e excluir (o arquivo vira silêncio e continua na pasta, porque o jogo carrega os se_ em sequência)."));
        s.add(new Section(ToolbarOrder.LINKS, "LINKS",
                "Mostra e edita os links do ANO atual: objetos filhos (efeitos, partes do corpo, auras) que o jogo cria junto com a animação e que seguem o pai. "
                + "O jogo aceita no máximo 13 por ANO e só 1 nível: link de link não nasce, e hitboxes/flags/animações dentro de um link não valem (o link mostra só as sprites dele). Animações disparadas por flag (efeito de hit, projétil, aura, cutscene) são raízes e mostram os próprios links. Ao abrir com a prévia num ANO que tem links, a lista rola para o primeiro e a seta ▶ vai para o próximo."));
        s.add(new Section(ToolbarOrder.MOVE, "GOLPE SET",
                "Opções do golpe (ATK_FLAGS do HDAT 4): agarrão (ao fim do ANO inicial ou só durante o hit), projétil nascendo no oponente ou embaixo dele, "
                + "lançar 3 projéteis (usa ANO, ANO+1 e ANO+2), projétil que só explode no chão, hitbox que destrói as do oponente e atravessar o oponente. "
                + "Só vale para o ANO inicial de um golpe. Define como o golpe é executado no jogo, não como ele é desenhado."
                + " Nos golpes 9 a 12 (os que o jogo trava com a câmera em zoom de 200%), há também \"Compensar o zoom da trava\": liga o 1º tick do golpe com o sprite do atacante em 50% (parece do tamanho normal sob o zoom) e volta à escala original no frame seguinte, dividindo o frame 0 se precisar; o tempo total não muda, e o oponente, o cenário e os efeitos continuam ampliados."));
        s.add(new Section(ToolbarOrder.HITBOX, "HITBOX",
                "Liga e desliga o desenho das caixas na preview: vermelha = hitbox (onde o golpe acerta), azul = hurtbox (onde o personagem leva dano) "
                + "e amarela = as demais caixas de flag. Ligado ajuda a posicionar o alcance; desligado deixa ver só a arte."));
        s.add(new Section(ToolbarOrder.SPEEDLINE, "SPEEDLINE",
                "Liga e desliga (no menu TELA) o desenho do movimento do Frame atual sobre a prévia: um ponto verde onde o Frame começa (com o número dele) e uma seta até onde ele termina, seguindo o caminho real (curva quando há aceleração ou a altura muda de sentido). Se o movimento continua no próximo Frame, a seta termina em ponta; se o movimento para (último Frame do movimento, ou o próximo começa com speed 0), a seta termina num ponto. Ao passar de Frame, o ponto e a seta vão para o início e o fim do novo Frame; o marcador amarelo anda pelo Frame durante os ticks. Arrastar a ponta da seta muda só a speed do Frame atual para ele chegar ali (o tempo nunca muda). Tocar no ponto (ou na ponta) abre o menu: REMOVER SPEED (o Frame perde a speed própria e continua com a do anterior; no primeiro Frame do movimento, ou num movimento de um Frame só, tira a speed toda, com aviso e confirmação), ZERAR SPEED (zera de verdade: sem manter e sem speed), ACELERAÇÃO (o Frame atual acelera ou desacelera até a velocidade do próximo: prévia da velocidade, accel x/y, velocidade do movimento em %) e, logo abaixo, os presets (começar devagar, desacelerar até parar...), que se aplicam ao movimento inteiro mantendo o deslocamento total."));
        s.add(new Section(ToolbarOrder.TIME, "TEMPO",
                "Muda como o tempo corre na simulação. NORMAL: o golpe roda como no jogo e a preview termina quando tudo acaba. "
                + "ESTENDIDO: o atacante fica parado no último frame quando o ANO acaba, para você ver projéteis e a reação do oponente até o fim. "
                + "ATAQUE: como estendido, mas a reprodução para sozinha no pouso (a barra continua livre)."));
        s.add(new Section(ToolbarOrder.CENTER, "CENTRO",
                "Câmera da preview. NORMAL: livre; você arrasta e dá zoom com os dedos, e o mapa inteiro fica enquadrado ao centralizar. "
                + "TELA: segue o recorte que o jogo realmente mostra (480x320, com a rolagem, o zoom e o tremor da câmera do jogo). "
                + "CHAR: enquadra os dois lutadores com zoom automático, bom para golpes de longe ou de ar."));
        s.add(new Section(ToolbarOrder.LAND, "POUSO",
                "ON: o atacante cai e pousa como no jogo, e a troca de ANO de pouso/queda acontece (SEQ e END de ar/chão). "
                + "OFF: só zera a velocidade no chão e segue no mesmo ANO. Desligue para editar um ANO sem a queda interferir."));
        s.add(new Section(ToolbarOrder.LOCK, "TRANSIÇÃO",
                "LIVRE: o fluxo do golpe acontece (SEQ, fim, pouso, queda trocam de ANO sozinhos). "
                + "TRAVADA: congela as trocas a partir do frame atual, para você editar um ANO sem a simulação sair dele. Travar desliga o POUSO; destravar devolve o estado anterior."));
        s.add(new Section(ToolbarOrder.FLIP, "VIRAR",
                "Vira o lado da luta: o atacante passa a olhar para o outro lado e o oponente fica do lado oposto. "
                + "Útil para conferir espelhamentos, ANO espelhado, projéteis indo para trás e efeitos com flip."));
        s.add(new Section(ToolbarOrder.HIDE, "HIDE-EFF",
                "Esconde efeitos, auras, cenas (bobj) e projéteis e deixa só atacante e oponente. Serve para ver o que é do personagem e o que é do efeito."));
        s.add(new Section(ToolbarOrder.GHOST, "FR-PREVIEW",
                "Frame preview: desenha o frame anterior (PREV) ou o próximo (NEXT) em transparência por cima do atual, para alinhar sprites e hitboxes entre frames. No menu TELA a linha FR-PREVIEW tem uma caixa que liga e desliga; tocar no nome abre as opções (FR-PREVIEW SET): próximo frame ou frame anterior, transparência, projéteis, efeitos e aplicar também ao Frame atual."));
        s.add(new Section(ToolbarOrder.SCREEN, "TELA",
                "Opções do que aparece na preview: grade, sons, cenas (cutscenes da flag 20), travar (modo cinemático do jogo), box amarela de todos os sprites, SPEEDLINE (uma caixa que liga o ponto e a seta do movimento do Frame atual) e FR-PREVIEW (caixa que liga e desliga; tocar no nome abre as opções). Desligar cenas ou sons ajuda a editar sem distração; o jogo sempre os executa. POSE liga/desliga o ANO 0 (o personagem parado) desenhado por baixo, na mesma âncora do golpe, para comparar a altura e o tamanho do golpe com a pose parada."));
        return s;
    }

    // ---- capitulos ----

    /** Um capitulo da tela de ajuda: titulo, resumo de uma linha e as secoes (texto) dele. */
    static final class Chapter {
        final String id, title, summary;
        final List<Section> sections = new ArrayList<Section>();

        Chapter(String id, String title, String summary) {
            this.id = id;
            this.title = title;
            this.summary = summary;
        }

        Chapter add(String title, String body) {
            sections.add(new Section(null, title, body));
            return this;
        }
    }

    /** id do capitulo do menu superior (as secoes dele sao as de {@link #toolbar()}). */
    static final String CH_MENU = "menu";

    private static List<Chapter> chapters;

    static synchronized List<Chapter> chapters() {
        if (chapters != null) return chapters;
        List<Chapter> c = new ArrayList<Chapter>();

        Chapter inicio = new Chapter("inicio", "Primeiros passos", "Como o editor funciona, o fluxo de edição e os termos que aparecem em todo lugar.");
        inicio.add("Como o editor funciona",
                "O app lê os arquivos do jogo (a pasta assets: DAC com as animações, BIN com os dados dos golpes, CNV com os recortes das sprites) e simula a luta inteira na preview: atacante, oponente, projéteis, efeitos, câmera, zoom, tremor e cutscenes, "
                + "do mesmo jeito que o jogo faz. Em cima fica o menu superior; no meio, a preview; embaixo, a timeline do ANO atual e a barra de tempo. Tocar em qualquer item da timeline abre o menu de edição daquele item numa gaveta por cima da tela, e a preview atualiza ao vivo enquanto você mexe.");
        inicio.add("Fluxo básico de edição",
                "1) Escolha o personagem (CHAR) e o golpe (ou o ANO, no modo ANO). 2) Toque em TOCAR ou arraste a barra de tempo para ver o golpe. 3) Toque num item da timeline (sprite, hitbox, projétil, som, velocidade...) para abrir o menu dele. "
                + "4) Ajuste: as mudanças aparecem na preview na hora. 5) APLICAR mantém o que você fez e fecha a gaveta; ✕ fecha primeiro a página aberta e, se a gaveta já está na grade, descarta o que não foi aplicado (a mensagem avisa). "
                + "6) DESFAZER volta a última edição. 7) SALVAR grava (veja o capítulo Salvar e backups).");
        inicio.add("Barra de título",
                "No topo: \"Attack Editor by Zue Mods\" (tocar em Zue Mods abre o canal no YouTube) e, à direita, três botões: ↻ (recarrega as pastas), o de idioma (PT / EN / ES) e o AJUDA, que abre esta tela.");
        inicio.add("Idioma da interface",
                "O botão PT / EN / ES (ao lado do AJUDA e também no topo desta tela) troca o idioma do app na hora: PT é o português, EN o inglês e ES o espanhol latino. Traduz botões, menus, avisos, esta ajuda e a busca (dá para buscar em qualquer um dos três). Nada se perde: as telas abertas são retraduzidas no lugar e a escolha fica salva no aparelho. "
                + "Termos sem idioma (DAC, BIN, CNV, ANO, MPT, HDAT, OPT, SEQ, END e os nomes dos campos) não mudam, e os arquivos e os dados do golpe também não. O TBRHelp.md é o mesmo em qualquer idioma; só a mensagem que acompanha o arquivo no compartilhar muda. Textos que o app monta na hora e ainda não têm tradução aparecem em português.");
        inicio.add("Recarregar pastas (↻)",
                "O botão ↻ (na barra de título, ao lado do idioma e do AJUDA) faz o app reler as pastas que ele usa, sem reiniciar: os personagens (charNN), os efeitos, as cenas (bobj) e os sons. Use quando você apagar, adicionar ou renomear uma pasta de personagem, ou trocar os .txt de um personagem. Antes de recarregar, o app avisa que as edições não salvas serão perdidas (SALVAR primeiro, se precisar). Depois de recarregar, o app volta ao mesmo personagem, oponente e golpe/ANO se eles ainda existirem; se a pasta do personagem sumiu, abre o primeiro da lista.");
        inicio.add("MODO: GOLPES / ANO",
                "GOLPES lista os golpes do personagem (cada um com seus ANOs, projéteis e reações). ANO lista os ANOs soltos, para abrir e editar uma animação isolada, sem o golpe em volta. "
                + "Ao tocar no seletor ao lado, escolhe-se o golpe ou o ANO. No modo ANO a tela do projétil e o GOLPE SET continuam disponíveis para o golpe que é dono do ANO."
                + " No seletor do modo ANO, logo abaixo de ABRIR LISTA, o botão CRIAR ANO cria a ANO seguinte à última (número da última + 1) com um frame sem imagem (IMG −1) de 6 ticks e já a abre para editar; uma ANO vazia aberta começa com esse mesmo conteúdo.");
        inicio.add("Barra de tempo e transporte",
                "A barra mostra o tick da simulação (e o frame/total). INÍCIO volta ao tick 0, -1 e +1 andam um tick (para conferir frame a frame), PAUSAR/TOCAR reproduz, e o botão de velocidade alterna a velocidade da reprodução. "
                + "O jogo roda a 60 ticks por segundo.");
        inicio.add("Ajuda de IA (TBRHelp.md)",
                "O botão Ajuda de IA (no topo desta tela) cria o arquivo TBRHelp.md na pasta Download do aparelho e abre o compartilhar do Android. O arquivo é um manual escrito para IAs (em inglês, com a instrução de responder no seu idioma): explica o app, os arquivos (DAC, BIN, CNV e seus .txt), os formatos, os limites do jogo, receitas de ataque, como testar e salvar, e o formato em que a IA deve entregar o resultado. Como usar: toque em Ajuda de IA, escolha o app de IA (ChatGPT, Gemini, Claude…) para enviar o arquivo e depois pergunte. Se for uma dúvida sobre o app (“como faço…?”), a IA ensina pelas funções do app, passo a passo. Se você pedir para ela criar ou alterar um ataque, ela vai pedir o 000.dac.txt, 000.bin.txt e 000.cnv.txt do personagem (SALVAR > pasta separada > Tap Battle/TBRE/Chars/charNN/) e devolver os .txt modificados. Coloque os .txt na pasta do personagem (guarde antes uma cópia dos originais), toque em ↻ para recarregar as pastas e teste. Precisa do acesso a todos os arquivos, o mesmo que o app já usa.");
        inicio.add("Termos que aparecem em todo lugar",
                "ANO: uma animação (lista de frames). MPT / frame / sprite: um quadro da animação (imagem, tempo, posição, velocidade, caixas...). Tick: 1/60 s. HDAT 4: a tabela de golpes (um golpe = campos como ANIM_INICIAL, projéteis, SEQ). "
                + "Hit / box: hitbox (flag 2, ataque), hurtbox (flag 1, corpo) e as demais flags de ação. Link: animação ligada a outra, que nasce junto e segue o pai. OPT: bloco opcional do frame (dano, reação...). "
                + "Oponente / defensor: quem recebe o golpe. CNV: tabela que recorta cada sprite de uma folha PNG.");
        c.add(inicio);

        Chapter menu = new Chapter(CH_MENU, "Menu superior", "Os 16 botões da fileira de cima, o que cada um faz e como reordená-los.");
        menu.sections.add(new Section(null, "Ordem dos botões", REORDER_TIP));
        menu.sections.addAll(toolbar());
        c.add(menu);

        Chapter tl = new Chapter("timeline", "Timeline e ferramentas", "As faixas, o ＋ e o #, DIVIDIR/DUPLICAR/EXCLUIR, arrastar duração e a altura da gaveta (Y e T).");
        tl.add("Faixas da timeline",
                "A timeline mostra, por frame: SPRITES (as imagens), e abaixo as faixas de hitbox (vermelha), hurtbox (verde), projétil, efeito, ação especial, SOM (azul), VELOCIDADE X e VELOCIDADE Y (uma faixa por eixo; o menu continua o mesmo), ESTILO (espelhar/transformar), animações ligadas (links) e transições (SEQ/END). "
                + "Só aparecem faixas com uso: sem som, velocidade ou estilo no ANO, a faixa some. Itens iguais em frames diferentes dividem a mesma faixa; itens iguais no mesmo frame (duas hitboxes iguais, duas transições) ficam em faixas diferentes. "
                + "Tocar no nome da faixa de sprites abre ou recolhe o resumo."
                + " A faixa \"efeito img\" mostra só o que está na página Efeitos da sprite (Flip X/Y, manter velocidade e interpolação). Cada faixa tem traços verticais, da cor dela mais escuros, nas divisas dos ticks (somem quando o zoom afasta demais). O ponteiro vai até o fim da timeline (o fim do último tick).");
        tl.add("＋ e #",
                "O ＋ adiciona no ponteiro um sprite, hitbox, hurtbox, projétil, efeito, som, velocidade, animação ligada ou uma ação especial (tremer cenário, cutscene, zoom de câmera, teleportar até o oponente, puxar oponente, curar vida...). O # escolhe o que a timeline mostra (liga e desliga cada categoria; MOSTRAR TUDO). Nas ações especiais há também TELEPORTAR ATRÁS DO OPONENTE: o PERSONAGEM vai até a posição do oponente (flag 39), vira o sprite (Flip X) e a speed X do frame o leva para o outro lado, na distância escolhida (padrão 60 px); o oponente não é movido. Os três contam como um item só, de um Frame só — apagá-lo apaga o Flip X e a speed junto. O jogo separa os dois corpos quando se sobrepõem e empurra o oponente: ligue \"Personagens se atravessam\" em GOLPE SET para ele ficar parado. Itens antigos (flag Puxar oponente com x negativo) continuam abrindo, com aviso de formato antigo. O ＋ do fim da faixa de sprites abre um menu: CAMADA (− N +: maior = a ANO aparece mais em cima, menor = mais embaixo; grava o $PRIO invertido) e ADICIONAR SPRITE (cria a sprite depois do ponteiro e abre a página Imagem para escolher a imagem e a posição)."
                + " O ＋ azul (ADICIONAR > sprite) põe o sprite novo na frente do Frame atual se o ponteiro está no meio dele, e antes do Frame se o ponteiro está na divisa entre Frames ou no início dele; no fim da timeline ele entra depois do último Frame.");
        tl.add("DIVIDIR / DUPLICAR / EXCLUIR / DESFAZER",
                "Editam o item selecionado na timeline: DIVIDIR corta o sprite sob o ponteiro em dois (o resultado visual continua igual) ou, com um objeto selecionado, separa o objeto na divisa de frames mais próxima do ponteiro (o objeto pertence ao frame, então nunca corta no meio dele) e o ponteiro vai para essa divisa, ou, com um trecho de VELOCIDADE selecionado, começa um segundo trecho no ponteiro (a velocidade segue a mesma); "
                + "DUPLICAR copia o sprite ou o objeto para o frame seguinte; EXCLUIR remove o sprite, objeto ou link selecionado; DESFAZER volta a última edição."
                + " DESFAZER (↶) e REFAZER (↷) têm dois níveis: com um menu de edição aberto, valem só para aquele menu (cada campo ou botão alterado é um passo, do primeiro ao original e de volta); ao APLICAR, o menu inteiro vira um único passo — o DESFAZER da barra desfaz o menu todo de uma vez e o REFAZER repõe tudo. Uma mudança nova depois de desfazer apaga o refazer.");
        tl.add("Arrastar, ponteiro e zoom",
                "O ponteiro fica no centro e a timeline anda por baixo: arrastar na horizontal move o tempo (a preview acompanha); arrastar na vertical rola as faixas; beliscar dá zoom. Para mudar a duração de um sprite, objeto ou trecho, "
                + "puxe a borda dele; as mudanças de posição e tamanho de uma box só acontecem entre sprites. Objetos que passam por vários frames iguais são um só objeto (\"frames conectados\"): mudar um muda todos; use DIVIDIR para separar."
                + " Tocar num clipe (sprite, objeto, velocidade, som…) só o seleciona se o ponteiro já está dentro dele; se o ponteiro estava antes, vai ao início do clipe, e se estava depois, vai ao último tick. O LOOP é do ANO: continua ligado no último frame mesmo quando você adiciona, duplica ou exclui sprites, e só desliga quando você o desliga."
                + " Com uma Hitbox que acerta, o jogo congela o atacante por um número fixo de ticks (hitstop: normalmente 10; metade em reações do grupo 3 e nenhum no grupo 4; o hitspark não é esperado: ele toca em paralelo na velocidade normal). Ao avançar tick pelo botão, o número do tick trava e um aviso amarelo diz por quantos ticks o Frame fica parado; quando o tick é liberado o aviso some. Os ticks da timeline são só os dos Frames: o hitstop (ticks que só a simulação tem) não ocupa lugar nela, então arrastar ou tocar na timeline vai direto ao tick de animação pedido; a barra de progresso e a reprodução seguem os ticks da simulação."
                + " A Hitbox é a exceção: é sempre uma por Frame (o hit se repete a cada Frame), então cada Frame tem a sua hitbox, o seu dano e a sua reação."
                + " Nos especiais com travamento cinematográfico (golpes 9 a 12), o botão de tick mostra o mesmo tipo de aviso amarelo (\"Trava cinemática: tudo fica congelado por mais N ticks\") com o botão PULAR, que passa pela trava de uma vez e libera o tick. A câmera segue o jogo: zoom de 200% em 4 ticks centrado no dono do especial (40 px para o lado de fora e 48 px acima dos pés) e, quando a trava acaba, volta a 100% em 12 ticks."
                + " Com o botão de tick, o número do tick trava durante o hitstop e a trava cinemática e, ao liberar, a contagem continua no tick seguinte ao travado: os ticks parados não contam, só os dos Frames.");
        tl.add("Altura da gaveta: Y e T",
                "A gaveta abre sempre na altura padrão: por cima da tela, subindo até a base da prévia. Arraste a borda (a alça) para subir ou descer à vontade, até por cima da prévia; isso vale só para aquela abertura. "
                + "Y (na borda, à direita) grava a altura atual como a nova altura padrão. T põe a timeline acima do menu: a prévia diminui na proporção, o menu só sobe até a metade da tela, o menu superior some e a timeline mostra de 6 a 2 faixas conforme o menu sobe; "
                + "tocar em T de novo volta ao normal. O modo T só vale com a gaveta aberta e nunca fica salvo: o app sempre abre com ele desligado.");
        c.add(tl);

        Chapter sp = new Chapter("sprite", "Menus de edição da sprite", "A grade Imagem, Tempo, Som, Movimento, Efeitos e Copiar, página por página.");
        sp.add("Menu da sprite (gaveta)",
                "Tocar numa sprite da timeline abre uma grade de botões: Imagem, Tempo, Som, Movimento, Efeitos e Copiar. Cada um abre uma página dentro da gaveta (a preview continua visível; ◀ volta à grade). "
                + "Tocar num item de velocidade, som ou estilo da timeline abre direto a página dele."
                + " No alto da grade há a faixa do Frame: DUPLICAR (copia só o sprite: imagem, tempo, deslocamento e estilo), ◀ e ▶ (movem o Frame para trás ou para frente) e EXCLUIR (apaga o Frame inteiro, com confirmação; dá para desfazer). Os botões da grade são pequenos (ícone e nome lado a lado).");
        sp.add("Imagem",
                "Thumb da sprite e − N + (segure para percorrer; tocar no número abre a grade de sprites). Depois posição (x e y do centro), zoom (com a caixa \"unir X e Y\"), rotação e alpha. "
                + "\"Mover links junto\" soma o mesmo deslocamento no bx/by de todos os links do ANO; \"Editar posição do Link\" abre uma tela com a animação principal de base para ajustar sprite, tempo e posição do link. REMOVER IMAGEM deixa o frame sem imagem.");
        sp.add("Tempo",
                "Ticks do frame (60 ticks = 1 s) e a duração em segundos. Tempo 0 é o mesmo que desativar o campo TIME: o frame fica travado e nunca avança sozinho. REMOVER FRAME apaga o frame (o ANO precisa de ao menos um).");
        sp.add("Som",
                "O som do frame no estilo da lista de sons (tocar/pausar, trocar, cortar...). − e + andam só pelos ids que existem: 0 até o último som comum do jogo, e depois os áudios do personagem a partir do 80. ESCOLHER abre a lista; REMOVER ÁUDIO tira o som do frame.");
        sp.add("Movimento",
                "Duas seções, SPEED X e SPEED Y, como Hitbox e Hurtbox: cada eixo tem a própria velocidade, aceleração, velocidade recebida, total de pixels e REMOVER SPEED (que tira só a speed daquele eixo). A velocidade vale em px por tick (veja o capítulo Speed e aceleração). Num frame que recebe velocidade do anterior o campo fica zerado e soma à recebida, que aparece em amarelo com o botão Remover (zera só o eixo). A aceleração do eixo só aparece quando ele já tem speed. O que é do trecho inteiro aparece nas duas seções e uma atualiza a outra: frame inicial e duração do trecho de movimento e MANTER VELOCIDADE (passa a velocidade deste frame ao próximo).");
        sp.add("Efeitos",
                "Liga e desliga Flip X e Flip Y e a Interpolação: o frame com a marca suaviza (posição do centro, rotação, alpha e zoom) até chegar no PRÓXIMO frame; o frame de antes não interpola para ele, e num frame sem tempo não faz efeito. No último frame o próximo dá a volta para o frame 1 (o jogo faz isso mesmo sem LOOP) e o app avisa.");
        sp.add("Copiar",
                "Aplica as coisas deste frame em outros frames. Primeiro escolha os frames atingidos: próximos N, N anteriores, todos do ANO, esta sprite no ANO ou esta sprite em todos os ANOs (o app diz quantos frames vai atingir); depois marque o que copiar (imagem, tempo, som, velocidade, estilo, caixas...) e aplique.");
        c.add(sp);

        Chapter bx = new Chapter("box", "Menus de box", "Hitbox e hurtbox: início, duração, prévia, coordenadas, dano, reação e transição.");
        bx.add("Hitbox / Hurtbox",
                "Tocar numa box da timeline abre, de cima para baixo: o interruptor Hurtbox | Hitbox; FRAME DE INÍCIO (move a box inteira mantendo a duração; se cair em cima de outra box igual ela ganha uma faixa própria) e DURAÇÃO; "
                + "a prévia parada do frame atual, mostrando só a box que você edita (hurtbox sem a hitbox e vice-versa); x, y, largura e altura; e remover a box. "
                + "Ao mover o ponteiro, o menu só muda se o novo frame tem esta box; se não tem, fica como está."
                + " Na hurtbox há ainda dois botões: \"Aplicar a todas as Hurtboxes (neste ANO)\" e \"(todos os ANOs)\", que copiam a posição e o tamanho desta hurtbox para todas as outras (o desfazer volta tudo de uma vez; para gravar os outros ANOs use SALVAR > todos os ANOs).");
        bx.add("Dano e reação",
                "Só na hitbox: DANO e REAÇÃO (com prévia e botões ◀ ▶ para trocar, ESCOLHER na grade, EDITAR REAÇÃO). São do sprite (frame) sob o ponteiro, não da box em si, e acompanham a hitbox quando você muda o frame de início ou a duração (cada frame leva o seu par). "
                + "Veja o capítulo Reações."
                + " O botão efeito/som abre uma grade com prévia dos 5 jeitos de efeito, som, empurrão e hitstop (normal, som alternativo, forte, leve, sem efeito): cada cartão mostra a reação atual com o efeito daquele grupo, tocar num cartão o seleciona e toca o som dele, o atual vem destacado, e VOLTAR descarta ou APLICAR grava (a reação não muda).");
        bx.add("Transição no menu da hitbox",
                "Também só na hitbox: a transição atual do ANO (SEQ ou END), MUDAR ANO DESTINO e, se o golpe tem SEQ, BLOQUEAR SEQUÊNCIA neste hit (flag 38). Veja o capítulo Sequências e transições.");
        c.add(bx);

        Chapter mv = new Chapter("golpe", "Golpe e HDAT 4", "GOLPE SET, os campos do HDAT 4 e o painel DADOS / EDITAR.");
        mv.add("O que é um golpe",
                "Cada golpe é uma linha da tabela HDAT 4: ANIM_INICIAL (o ANO que começa o golpe), os ANOs de projétil (normal, abaixo, acima, global, ao acertar, chão, sub-projétil), a sequência (SEQ e END de chão e de ar, SEQ_PROJETIL), pouso ao errar e ao acertar, o oponente agarrado, perseguição e repetições, mais as opções do GOLPE SET. "
                + "Todos os campos de ANO aceitam números de 16 bits, então ANOs acima de 255 são normais.");
        mv.add("GOLPE SET (ATK_FLAGS)",
                "As opções do golpe: agarrão (ao fim do ANO inicial ou só durante o hit), projétil nascendo no oponente ou embaixo dele, lançar 3 projéteis (usa o ANO, ANO+1 e ANO+2), projétil que só explode no chão, hitbox que destrói as do oponente (o oponente entra na reação do byte 13 do HDAT 3) e atravessar o oponente. "
                + "Só vale para o ANO inicial de um golpe e define como o golpe é executado, não como ele é desenhado."
                + " O agarrão aparece na faixa de transições da timeline (AGARRAR → ANO inicial + 1, no fim do ANO inicial) e como o objeto \"Tentar agarrão\" (janela 512); nos dois menus há a distância do agarrão (HDAT 3 do personagem, vale para todos os golpes dele).");
        mv.add("DADOS / EDITAR",
                "Painel recolhido com os dados em texto: abas GOLPE (HDAT 4), ANO e FRAME no modo golpes, e ANO, FRAME e LINKS no modo ANO. O lápis abre o editor em texto para mudar o valor direto.");
        c.add(mv);

        Chapter pj = new Chapter("projetil", "Projéteis e ramificação", "A tela do projétil, a árvore de ramificação, tiro triplo, perseguição e o limite de 8.");
        pj.add("Tela do projétil",
                "Tocar num hit de projétil (flag 0) abre, de cima para baixo: INÍCIO E DURAÇÃO; RAMIFICAÇÃO DO PROJÉTIL; ANO do projétil (− N +; tocar no número abre a grade de animações; ✎ EDITAR ANIMAÇÃO); POSIÇÃO E VELOCIDADE (x, y e a velocidade inicial do projétil); "
                + "PERSEGUIÇÃO (liga/desliga, velocidade de giro e repetições) e SEQUÊNCIA (SEQ_PROJETIL). A mesma tela abre no modo ANO e edita o golpe do HDAT 4 que é dono do ANO.");
        pj.add("Ramificação do projétil",
                "A árvore mostra o caminho completo do projétil: ANIM_INICIAL → projétil (+ANO+1/+2 com 3 projéteis) → reações (ao acertar, chão, abaixo, acima, global) → sub-projétil. É onde você escolhe cada uma dessas animações. "
                + "O projétil é escolhido pela altura do atacante em relação ao oponente: NORMAL perto da mesma altura, ABAIXO quando o atacante está bem mais baixo que o oponente (≥ 51 px) e ACIMA quando está bem mais alto (≥ 37 px). POS ajusta a altura.");
        pj.add("Posição e velocidade",
                "O projétil principal nasce em x do atacante + x do hit; se cair atrás do atacante, o jogo o lança a 480 px à frente (por isso o x mínimo é 0). Com as flags de nascer no oponente (32/64) o x/y do hit é ignorado. "
                + "Se o projétil ficar abaixo do chão o jogo o puxa para o chão a cada tick. A velocidade que a tela mostra é a velocidade horizontal inicial do primeiro sprite do ANO do projétil.");
        pj.add("Perseguição e repetições",
                "Persegue o oponente: o projétil vira na direção dele com a velocidade de giro indicada. Repetições (MAX_REPETICOES) fazem o projétil se repetir e usam a mesma janela 512 do frame que o agarrão, então o agarrão fica indisponível.");
        pj.add("Limite de 8 projéteis",
                "O jogo só mantém 8 projéteis vivos ao mesmo tempo (BulletNum < 8), contando os sub-projéteis. Um hit de projétil (flag 0) que acontece com 8 já na tela não cria nada, sem aviso: se um projétil \"não sai\" num golpe que lança vários, confira se os anteriores já sumiram. "
                + "O editor também não avisa isso na tela; os outros motivos de projétil que não nasce (ANO vazio, campo do HDAT 4 vazio, golpe que errou, transição travada...) continuam avisando.");
        c.add(pj);

        Chapter sq = new Chapter("sequencia", "Sequências e transições", "SEQ, END, SEQ_PROJETIL, bloquear sequência (flag 38), pouso e queda, TRANSIÇÃO travada e VER FLUXO.");
        sq.add("SEQ e END",
                "SEQ (ANIM_SEQ_CHAO / ANIM_SEQ_AR) é o ANO para onde o golpe vai quando um hit conecta no ANO onde ela está definida; chão e ar são definidos separadamente (o jogo escolhe pela posição do atacante). "
                + "END (ANIM_END_CHAO / ANIM_END_AR) só existe dentro do ANO de destino da SEQ: dispara num novo hit enquanto o atacante está nessa ANO. A ANO de END não tem transição própria. "
                + "No menu da hitbox: + TRANSIÇÃO / MUDAR ANO DESTINO. Se você define só chão ou só ar, o app pergunta se usa a mesma no outro. A transição não pode apontar para a própria ANO.");
        sq.add("SEQ_PROJETIL (ANIM_AO_ACERTAR)",
                "Quando o primeiro acerto de cada projétil conecta, o atacante troca para este ANO (vale para o golpe todo). A SEQ vem logo depois, a não ser que o primeiro frame deste ANO tenha uma hitbox flag 38. Fica no fim da tela do projétil e aceita qualquer ANO do DAC.");
        sq.add("Bloquear sequência (flag 38)",
                "Uma hitbox com a flag 38 no hit impede a SEQ de disparar quando ele conecta. O menu da hitbox oferece BLOQUEAR SEQUÊNCIA só quando o golpe tem SEQ.");
        sq.add("Pouso e queda",
                "O pouso troca de ANO quando o atacante toca o chão: POUSO_ERRAR e POUSO_ACERTAR do HDAT 4. O botão POUSO do menu superior liga/desliga isso na preview; com ele desligado a velocidade só zera no chão e o golpe segue no mesmo ANO."
                + " Ao abrir sozinho um ANO de projétil ou de efeito (EDITAR ANIMAÇÃO / EDITAR EFEITO) ele não é tratado como o personagem: não pousa (ANO 13), não cai (ANO 89) e não tem sombra. No chão, o projétil troca para PROJETIL_COLISAO_CHAO (ou SUBPROJETIL_COLISAO_CHAO) se houver, senão continua; o efeito ignora o chão.");
        sq.add("TRANSIÇÃO travada e VER FLUXO",
                "O botão TRANSIÇÃO (só em golpes com sequência) trava as trocas de ANO a partir do frame atual, para editar um ANO sem a simulação sair dele; com a trava, a SEQ não é vista. VER FLUXO mostra o caminho completo do golpe (ANIM_INICIAL → SEQ → END → pouso...) e deixa editar cada passo.");
        c.add(sq);

        Chapter rc = new Chapter("reacao", "Reações", "O que é uma reação (OPT 1), grupos, tabelas do jogo e do personagem, slots vazios e o editor estilo timeline.");
        rc.add("O que é uma reação",
                "Quando um hit acerta, o OPT 1 do frame diz como o oponente reage. O valor é GRUPO × 50 + NÚMERO: o número 0 a 29 é uma reação do jogo (tabela fixa da game data) e 30 a 49 é uma reação do personagem (20 slots, HDAT 14 a 33, editáveis). "
                + "O grupo (0 a 4) escolhe o efeito, o som e o empurrão: 0 normal (efeito 0, som 3, empurra); 1 som alternativo (efeito 0, som 4, empurra); 2 forte (efeito 1, som 6, empurra); 3 leve (meio hitstop, sem empurrar); 4 sem efeito, som nem hitstop.");
        rc.add("Cada reação é uma lista de passos",
                "Um passo é uma linha da tabela: a animação do oponente (ANO; negativo = espelhado), a duração no chão e no ar (ticks), velocidade e aceleração no chão e no ar, a próxima reação (COMP), o efeito de parede e a voz. "
                + "Os passos tocam em ordem; o jogo usa os valores de chão enquanto o oponente está no chão e os de ar quando está no ar. Velocidade −1 mantém a do passo anterior e −2 reduz pela metade; 255 na duração do ar significa \"até pousar\" (limite de 255 ticks).");
        rc.add("Escolher reação e slots vazios",
                "A tela \"Escolher reação\" mostra a prévia de cada reação do jogo e do personagem. Os slots do personagem vazios aparecem como \"＋ vazio\": tocar oferece copiar de uma reação do personagem, copiar da game data, importar de outro personagem (lê o 000.bin dele) ou criar em branco. Em todas as listas a reação toca em laço como ficaria no slot (⏸ PAUSAR / ▶ TOCAR, ou toque na prévia) e USAR escolhe. "
                + "A reação nova entra no slot (dá para desfazer) e o hit passa a usá-la. Ao salvar, o bloco do slot é criado no 000.bin.txt se faltar (precisa existir o $HDAT_14+n no arquivo; se não existir o app avisa)."
                + " Tocar numa reação só a destaca (contorno azul) e toca a prévia dela, com voz e som: só a destacada toca. CONFIRMAR grava a reação escolhida no hit; VOLTAR fecha sem alterar nada. Na tela \"Efeito, som e empurrão\" também só o grupo destacado toca. Ao voltar para o app depois de usar outro, o golpe, o ponteiro e o play/pausa ficam como estavam (só a game data é relida, se mudou).");
        rc.add("Editor de reações",
                "EDITAR REAÇÃO (do personagem) ou VER REAÇÃO (do jogo, só leitura) abre uma tela com o mesmo layout da tela principal: no topo o cabeçalho (CHÃO | AR escolhe o cenário simulado: oponente no chão, ou a 60 px do chão), "
                + "a prévia quadrada do oponente recebendo a reação, abaixo (numa área que rola) a barra de tempo, os botões DIVIDIR · DUPLICAR · EXCLUIR · DESFAZER e a timeline, e na base o transporte (INICIO, −1, TOCAR, +1, velocidade). "
                + "A edição é na própria timeline; a gaveta de edição sobe por cima (arraste a alça para mudar a altura; Y grava a altura padrão) e só abre ao tocar num passo ou num item. "
                + "Timeline: a faixa PASSOS tem um clipe amarelo por passo (miniatura do ANO do oponente, ⇄ se espelhado, duração; as reações seguintes aparecem em cinza; ARRASTE a barra escura da borda direita para mudar a duração do cenário atual). "
                + "Tocar em PASSOS (ou no cabeçalho dela) abre e fecha as faixas: SPEED em blocos, como no ANO (um bloco por velocidade própria, cobrindo os passos seguintes que a mantêm com −1; ARRASTE a borda direita do bloco para estender ou encurtar), "
                + "VOZ (♪), EFEITOS (parede), SEQ (próxima reação) e CURVA (x e y em px/tick, só leitura). Fechada, cada faixa com dados vira uma linha fina de resumo. A aba # escolhe quais faixas aparecem; arrastar na vertical rola as faixas. "
                + "Tocar num passo abre a grade de páginas (ANIMAÇÃO, TEMPO, SPEED, VOZ, EFEITOS, SEQ, TOTAL); tocar num item de faixa abre a página dele direto, e numa célula vazia (＋) abre para adicionar. ◀ volta à grade, ✕ fecha. "
                + "Digitar no campo vale na hora, e segurar − ou + muda continuamente. Tudo vem da simulação do jogo, a mesma da prévia."
                + " A câmera da prévia segue o oponente (acompanha o voo e sobe o cenário para o corpo não sair da área) e, ao tocar (não ao arrastar a barra de tempo), toca a voz do passo e os sons da reação; as prévias pequenas das grades ficam mudas.");
        rc.add("Barra de ferramentas da reação",
                "A aba ＋ (colada na borda da timeline) cria no passo selecionado: passo novo (depois dele), speed, voz, efeito de parede ou próxima reação (SEQ); também move o passo (◀ ▶) e mostra o total (Σ). "
                + "DIVIDIR parte o passo onde está o ponteiro em dois: a duração é repartida, o 2º passo mantém a velocidade (com aceleração, já parte da velocidade em que o 1º terminou) "
                + "e a voz fica só no 1º. ATENÇÃO: cada passo reinicia a animação do oponente, então o ANO recomeça no 2º passo. DUPLICAR copia o passo; EXCLUIR apaga o item selecionado (o passo, o bloco SPEED, a voz, a parede ou a SEQ); "
                + "DESFAZER volta a última edição. Em reação do jogo só vale olhar.");
        rc.add("Parede e próxima reação",
                "EFEITOS (parede): com 2 ou 3, se o oponente encosta na parede durante o passo a reação recomeça na reação indicada em SEQ; com 0 a parede não muda nada. SEQ (próxima reação): depois dos passos entra a reação indicada (1 a 29 do jogo, 30 a 49 do personagem); 0 = nenhuma, e o oponente se levanta ou cai conforme a altura.");
        c.add(rc);

        Chapter sa = new Chapter("speed", "Speed e aceleração", "A diferença entre speed e accel, Manter velocidade (bit 64) e a velocidade recebida.");
        sa.add("Speed x Accel (velocidade e aceleração)",
                "SPEED é uma velocidade constante: o objeto anda essa quantidade de pixels a cada tick, sempre igual. Ex.: speed 50 por 5 ticks = 250 px. "
                + "ACCEL é uma velocidade de aceleração: a cada tick ela soma o valor dela na velocidade atual (o objeto anda com a velocidade que tem e só depois soma). "
                + "Ex.: accel 50 por 5 ticks, partindo do repouso, anda 0, 50, 100, 150 e 200 = 500 px e termina com velocidade 250. "
                + "A accel só vale no frame em que está escrita; a velocidade que ela acumulou só passa para o frame seguinte se ele tiver Manter velocidade, senão volta a 0. "
                + "Para continuar acelerando (ou frear) no frame seguinte, escreva a accel de novo nele. Accel sozinha, sem speed e sem velocidade recebida, é uma aceleração a partir do repouso (queda, arrancada) e não equivale a uma speed.");
        sa.add("Manter velocidade (bit 64) e velocidade recebida",
                "Ao carregar um frame, o jogo zera a velocidade, a não ser que o frame tenha o bit 64 (Manter velocidade): aí ele começa com a velocidade em que o frame anterior terminou (a speed dele mais a accel × ticks). "
                + "Essa velocidade recebida conta como speed, não como accel; se o frame tem speed própria, ela substitui a recebida; a accel nunca é herdada. É por isso que um salto é escrito em vários frames: o primeiro com speed e accel, e os seguintes com Manter velocidade e a accel de novo (ex.: YSPEED −16 e YACCEL 1; depois só YACCEL 0,8, e só YACCEL 1).");
        sa.add("Detalhes que pegam",
                "Um frame sem TIME (tempo 0) não avança nem soma accel. Links e frames sincronizados com o pai (flags 0x2000/0x8000) não andam sozinhos: seguem a posição do pai. "
                + "No editor, o total de pixels do menu Movimento já considera a velocidade recebida e a aceleração.");
        c.add(sa);

        Chapter lk = new Chapter("links", "Links e animações por flag", "Animações ligadas (links), o limite de 1 nível e as animações disparadas por flag.");
        lk.add("Links (animações ligadas)",
                "Um link é outro ANO que nasce junto com o ANO e segue o pai (efeitos, partes do corpo, auras). O jogo aceita no máximo 13 por ANO e só 1 nível: link de link não nasce, e hitboxes, flags e animações dentro de um link não valem (o link mostra só as sprites dele). "
                + "O botão LINKS lista os links do ANO atual; com a preview num ANO que tem links, a lista rola para o primeiro e a seta ▶ vai para o próximo.");
        lk.add("Animações por flag",
                "Hitboxes com flags especiais criam animações: projétil (0), tremor (3 a 5), poeira (10 a 17), cutscene (20), zoom de câmera (30/31), teleporte (39/40) e animações do personagem (41 a 125). Essas animações são raízes: mostram os próprios links. "
                + "O aviso \"Os ANOs N, N e N têm links que têm outros links ou animações/efeitos\" na lista de avisos diz quais links o jogo ignora."
                + " A poeira/fumaça (ação \"Poeira / fumaça\", tipos 1 a 15) é desenhada na prévia como no jogo: nasce uma por frame, fica parada no mundo na posição do personagem, usa a ANO +80 quando ele está virado, no máximo 6 ao mesmo tempo (a sétima apaga a mais antiga). Tipos 1 a 5 vêm da pasta bobj do cenário, 6 a 15 do effect; o menu da ação mostra a prévia animada de cada tipo e de onde ela vem. Na faixa dos efeitos o clipe diz de onde vem a arte: effect N, charf N ou char N (N = ANO do pacote)."
                + " Cutscenes (flag 20): o 3º valor da hitbox é o evento da tabela HDAT 13 do personagem. O botão EDITAR EVENTOS da gaveta da flag 20 (e CHAR > CUTSCENES) abre o editor: lista de eventos, prévia da animação virado para a direita e para a esquerda, ALVO (effect.pac, char do player ou bobj), ANIM_ID e ANIM_FLIP (com ESCOLHER), DURAÇÃO, Z_LAYER, CAM_MODE, TRAVAR_VIT e FLAG, o texto de como o jogo lê o evento ao vivo, e NOVO / DUPLICAR / ZERAR / EXCLUIR (só o último evento pode sair) / USAR NESTE HIT / desfazer. Ao salvar, o app grava as linhas $EVT_nn no $ROTEIRO_CUTSCENE do $HDAT_13 do 000.bin.txt, mantendo os comentários e corrigindo $ROW e $SZ.");
        lk.add("Sincronia do link",
                "Cada link tem posição base (bx, by) e flags: sincronizar MPT (acompanha o frame do pai), sincronizar XY (acompanha a posição do pai) e \"não copiar a posição ao nascer\". O menu Imagem tem \"mover links junto\" e \"Editar posição do Link\".");
        c.add(lk);

        Chapter sn = new Chapter("sons", "Sons, sprites e CNV", "Ids de som, a lista de sprites e como as imagens são recortadas.");
        sn.add("Sons",
                "Os sons do frame (SE) usam ids: de 0 até o último som comum do jogo, e a partir do 80 os áudios do personagem (arquivos NNN.wav da pasta dele). A lista de sons deixa tocar, trocar, cortar (áudios com mais de 20 s sugerem cortar), ajustar o volume e remover (o som vira silêncio e os usos são retirados dos ANOs)."
                + " O id do SE vai de 0 a 255 (valores acima de 127 só valem no TCBManajer com o patch do byte sem sinal): 1 a 79 = sons comuns se_00 a se_78, 80 a 99 = áudios do personagem e 100 a 255 = sons comuns novos (se_99 a se_254; o arquivo é se_NNN.ogg a partir do 100). O + da lista também adiciona um SOM GLOBAL (OGG, precisa do Android 10 ou mais novo): ele vira o próximo se_; depois do se_78 o primeiro novo é o se_100 e o app cria arquivos silenciosos se_79 a se_99 para não deixar buraco. Os sons comuns têm as mesmas ferramentas dos WAV (ouvir, cortar, ajustar, substituir e silenciar — nunca se apaga um se_). O .ogg gravado usa o codec Opus.");
        sn.add("Sprites e CNV",
                "O botão SPRITES lista as sprites do personagem (SPR_0, SPR_1...), já recortadas: dá para adicionar, substituir, remover, trocar de lugar, mudar o recorte e importar imagens (PNG, JPG, BMP e GIF/APNG/WebP animados viram várias sprites seguidas). "
                + "As folhas (NNN.png) ficam intactas no disco; quem recorta é o CNV (000.cnv.txt, uma linha $SPR_n com folha, x, y, largura e altura em pixels). Sprite nova procura espaço livre nas folhas e só cria folha nova se não couber."
                + " Em + ADICIONAR, ao tocar num arquivo .cnv (ou .cnv.txt) de outra pasta — efeito, charf, bobj ou outro personagem — o app lê o CNV e recorta as folhas PNG que estão na mesma pasta (sem alterar nada lá) e abre uma lista com as sprites dele: marque quais adicionar ou use TODAS. Sprites de pacs de escala 1 entram ampliadas 2x para manter o tamanho na tela, e recortes repetidos entram uma vez só."
                + " O arquivo .cnv de outro pac pode ser texto (CNV_TXT_ { $SPR_n:{...} }) com as coordenadas originais, sem a multiplicação por 2 do personagem — o recorte multiplica —, ou o .cnv.txt, que já tem as coordenadas finais (×2 no personagem); o app lê os dois (e o binário, se não houver texto)."
                + " Em Substituir imagem também dá para tocar num .cnv e escolher uma só sprite dele para pôr no lugar. VOLTAR, na escolha das sprites de um CNV, leva de volta à pasta onde estava o arquivo. Nos seletores de arquivos (sprites e sons), a primeira linha “...↑” de qualquer pasta (menos a raiz) sobe um nível."
                + " A folha de um recorte ($src) é o ÍNDICE dela na lista dos PNG da pasta, em ordem de nome, e não o número do arquivo: com 017.png, 018.cnv e 019.png, o $src 18 é a 019.png."
                + " Quando um recorte falha (folha que não existe, PNG ilegível, recorte fora da folha...), o app abre um alerta com o motivo exato de cada sprite, com o texto selecionável e o botão COPIAR; o mesmo motivo aparece em vermelho na lista de sprites e no seletor de sprites de outro CNV."
                + " Remover uma ou várias sprites RENUMERA as seguintes (se sai a SPR_0, a 1 vira 0, a 2 vira 1...): o CNV, os grupos de GIF e todos os frames do DAC acompanham, e as ANOs alteradas são gravadas no 000.dac.txt. Com a caixa \"Excluir Frames com essa Sprite\" os frames que usavam a sprite saem; sem ela ficam sem imagem (IMG -1)."
                + " O botão OTIMIZAR, ao lado de + ADICIONAR, abre duas funções. REMOVER SPRITES REPETIDAS acha sprites iguais ou parecidas (também espelhadas, giradas 90° ou em outra escala), mostra a prévia de cada grupo e uma barra de semelhança mínima; você marca quais remover (em cada grupo precisa ficar ao menos uma) e os frames do DAC passam a usar a que fica, com Flip, zoom, rotação e posição ajustados para o desenho ficar igual; depois as sprites são renumeradas. OTIMIZAR PNGs converte as folhas para 8 bits com paleta (até 256 cores por folha) para diminuir o tamanho, copiando os originais antes para Backups/PreOptim/charNN/.");
        c.add(sn);

        Chapter sv = new Chapter("salvar", "Salvar e backups", "Pasta separada, Runtime, salvar em outro personagem e onde ficam as cópias de segurança.");
        sv.add("O que o SALVAR grava",
                "Os binários originais (000.dac / 000.bin / 000.cnv) nunca são tocados: o app grava nos .txt legíveis (000.dac.txt, 000.bin.txt, 000.cnv.txt). Dá para salvar o golpe atual (HDAT 4 + ANOs + as reações que ele usa), só o ANO atual, todos os golpes, todos os ANOs ou tudo. Ao salvar o app confere os limites do jogo e avisa o que faria o jogo fechar.");
        sv.add("Onde salvar",
                "Pasta separada (Tap Battle/TBRE/Chars/charNN/): copia o personagem inteiro (DAC, BIN, CNV, folhas, sons) e aplica a mesma gravação do Runtime na cópia, pronta para usar; o original não muda. Se a pasta já existe o app pergunta se une (mantém o que já está lá e aplica por cima), deleta e copia de novo ou usa outro nome. "
                + "Runtime (Tap Battle/assets/charNN/): sobrescreve os .txt do próprio personagem. Salvar em outro personagem (Runtime) só aparece em \"Salvar golpe atual\".");
        sv.add("Salvar em outro personagem",
                "Escolhe o personagem (pastas char de assets), depois o golpe a substituir (os golpes 0, 3 e 6 só substituem o 0, 3 e 6; os demais, qualquer um fora esses três) e grava direto no Runtime dele: o golpe do HDAT 4 é trocado, os ANOs entram no fim do DAC (renumerados), as sprites usadas entram no fim do CNV e das folhas, e as reações do personagem usadas vão para um slot (preferem um vazio). "
                + "Sons do personagem (id 80+) e hitbox flags 20 e 41-125 não vão junto. Recarregue o personagem destino depois.");
        sv.add("Backups",
                "As cópias de segurança ficam em Tap Battle/TBRE/Backups/AAAAMMDD_HHMMSS_charNN_transplante/ (os três .txt do destino como estavam antes de salvar em outro personagem).");
        c.add(sv);

        Chapter av = new Chapter("avisos", "Avisos e limites", "Os avisos da tela, as cores, o que fecha o jogo e os limites do jogo.");
        av.add("Avisos na tela",
                "Os avisos sobre a preview têm cor: vermelho quando o jogo fecharia ou erraria, âmbar quando o editor vê algo que o jogo trata diferente. Mostram o primeiro e \"(+N)\"; tocar expande e lista todos. OCULTAR esconde aquele aviso; alguns têm um botão que leva ao ajuste (POS, DESATIVAR). "
                + "Avisos: transição travada com sequência, pouso antecipado, projétil que não nasce (ANO vazio, campo do HDAT 4 vazio, golpe que errou...), e as regras do jogo abaixo. A barra de aviso acima da preview junta os avisos de carga (DAC, gamedata, effect, charf, sprites).");
        av.add("Limites do jogo",
                "Por ANO: no máximo 255 frames, 13 links e tempo de 255 ticks por frame (campo de 1 byte). Por frame: no máximo 10 caixas (hitboxes, hurtboxes e flags de ação; o jogo guarda 50 números, 5 por caixa). OPT 1 de reação com hitbox precisa apontar para um grupo que exista. "
                + "Interpolação (rotação/alpha/zoom) lê o frame seguinte e pode dar valores errados se o seguinte tem mais caixas. Imagem que não existe no CNV deixa o frame sem desenho. Os campos do HDAT 4 aceitam números de 16 bits; as tabelas de reação usam 1 byte por campo (ANO −127 a 127, voz 0 a 127).");
        c.add(av);

        chapters = c;
        return c;
    }

    /** Resto da tela (tudo que nao e botao do menu superior), na ordem dos capitulos. */
    static List<Section> screen() {
        List<Section> s = new ArrayList<Section>();
        for (Chapter ch : chapters()) if (!CH_MENU.equals(ch.id)) s.addAll(ch.sections);
        return s;
    }

    /** Todas as secoes: menu superior, depois a tela. */
    static List<Section> all() {
        List<Section> s = toolbar();
        s.addAll(screen());
        return s;
    }

    static Section forButton(String id) {
        for (Section s : toolbar()) if (s.button != null && s.button.equals(id)) return s;
        return null;
    }

    // ---- busca ----

    static final class Hit {
        final Chapter chapter;
        final Section section;
        /** true = aba / menu (faixa "ABAS E MENUS"); false = texto dentro de um capitulo. */
        final boolean tab;
        final int score;
        /** Trecho do texto onde a busca bateu (so nos textos); vazio nas abas. */
        final String snippet;

        Hit(Chapter chapter, Section section, boolean tab, int score, String snippet) {
            this.chapter = chapter;
            this.section = section;
            this.tab = tab;
            this.score = score;
            this.snippet = snippet;
        }
    }

    /** Minusculas e sem acentos, caractere por caractere (o tamanho nao muda, para os trechos do texto original baterem). */
    static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch < 128) { b.append(Character.toLowerCase(ch)); continue; }
            String n = java.text.Normalizer.normalize(String.valueOf(ch), java.text.Normalizer.Form.NFD);
            char base = n.isEmpty() ? ch : n.charAt(0);
            b.append(Character.toLowerCase(base));
        }
        return b.toString();
    }

    private static final java.util.regex.Pattern WORD = java.util.regex.Pattern.compile("[a-z0-9_]+");

    private static String[] tokens(String normText) {
        List<String> l = new ArrayList<String>();
        java.util.regex.Matcher m = WORD.matcher(normText);
        while (m.find()) l.add(m.group());
        return l.toArray(new String[0]);
    }

    /** Grupos de palavras relacionadas: quem busca uma acha as outras (com peso menor). Tudo normalizado. */
    private static final String[][] SYNONYMS = {
        {"speed", "velocidade", "dash", "mover", "movimento", "andar", "correr", "deslocar", "deslocamento", "pixels", "px", "avanco", "recuo", "impulso", "pulo", "salto", "velocity", "walk", "run", "displacement", "recoil", "jump", "leap", "caminar", "desplazar", "desplazamiento", "pixeles", "retroceso", "velocidad"},
        {"accel", "aceleracao", "acelerar", "gravidade", "queda", "freio", "frear", "desacelerar", "acceleration", "accelerate", "brake", "gravity", "fall", "aceleracion", "gravedad", "caida", "freno", "frenar"},
        {"hitbox", "hurtbox", "caixa", "caixas", "ataque", "dano", "alcance", "colisao", "box", "damage", "reach", "collision", "cajas", "ataque", "dano", "alcance", "colision"},
        {"reacao", "reacoes", "knockback", "empurrao", "empurrar", "hitstun", "stun", "atordoamento", "lancamento", "reaction", "reactions", "pushback", "launch", "reacciones", "empuje", "aturdimiento", "lanzamiento"},
        {"sequencia", "seq", "combo", "transicao", "cancel", "cancelar", "encadear", "encadeamento", "fluxo", "sequence", "chain", "transition", "flow", "secuencia", "encadenar", "transicion", "flujo"},
        {"projetil", "projeteis", "tiro", "bala", "fireball", "bullet", "ramificacao", "ramo", "arvore", "perseguicao", "projectile", "projectiles", "shot", "branching", "tree", "homing", "proyectil", "proyectiles", "disparo", "ramificacion", "arbol", "persecucion"},
        {"som", "audio", "sfx", "wav", "voz", "musica", "sons", "sound", "voice", "music", "sonido", "sonidos", "voz"},
        {"salvar", "save", "gravar", "backup", "copia", "exportar", "runtime", "pasta", "write", "copy", "export", "folder", "escribir", "respaldo", "copia", "carpeta"},
        {"imagem", "sprite", "sprites", "recorte", "cnv", "png", "folha", "thumb", "image", "crop", "sheet", "imagen", "recorte", "hoja", "miniatura"},
        {"tempo", "duracao", "ticks", "tick", "frames", "frame", "time", "duration", "tiempo", "duracion"},
        {"camera", "zoom", "tela", "tremor", "shake", "cutscene", "cena", "cenas", "camara", "screen", "scene", "scenes", "pantalla", "temblor", "escena", "escenas"},
        {"link", "links", "filho", "aura", "sincronia", "child", "sync", "hijo"},
        {"limite", "limites", "maximo", "aviso", "avisos", "erro", "crash", "alerta", "limit", "limits", "maximum", "warning", "warnings", "alert", "limite", "limites", "maximo", "aviso", "avisos"},
        {"pouso", "chao", "aterrissar", "cair", "landing", "floor", "ground", "aterrizaje", "suelo", "piso", "caer"},
        {"flip", "virar", "espelhar", "espelhado", "inverter", "rotacao", "mirror", "invert", "rotation", "voltear", "espejar", "invertir", "rotacion"},
    };

    /** Tolerancia de erro por tamanho da palavra buscada: ate 3 letras so exata, 4 a 6 uma troca, 7 ou mais duas. */
    private static int maxDist(int len) { return len <= 3 ? 0 : len <= 6 ? 1 : 2; }

    /** Distancia de edicao com transposicao (Damerau-Levenshtein "optimal string alignment"). */
    static int distance(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] d = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++) d[i][0] = i;
        for (int j = 0; j <= m; j++) d[0][j] = j;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                int v = Math.min(Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1), d[i - 1][j - 1] + cost);
                if (i > 1 && j > 1 && a.charAt(i - 1) == b.charAt(j - 2) && a.charAt(i - 2) == b.charAt(j - 1)) v = Math.min(v, d[i - 2][j - 2] + 1);
                d[i][j] = v;
            }
        }
        return d[n][m];
    }

    /** Quanto a palavra buscada {@code w} bate com o termo {@code t} (0 = nao bate; 100 = igual). */
    static int match(String w, String t) {
        if (w.equals(t)) return 100;
        int lw = w.length(), lt = t.length();
        if (lw >= 3 && t.startsWith(w)) return 85;
        if (lw == 2 && t.startsWith(w) && lt <= 4) return 60;
        if (lw >= 4 && t.contains(w)) return 55;
        int md = maxDist(lw);
        if (md > 0 && Math.abs(lw - lt) <= md) {
            int dd = distance(w, t);
            if (dd <= md) return 75 - 5 * dd;
        }
        if (lw >= 5 && lt > lw && distance(w, t.substring(0, lw)) <= 1) return 60;
        return 0;
    }

    /** Palavras da consulta com as relacionadas: [palavra, peso%]. A propria palavra pesa 100; as parentes, 70. */
    private static List<Object[]> expand(String w) {
        List<Object[]> out = new ArrayList<Object[]>();
        out.add(new Object[] { w, 100 });
        for (String[] g : SYNONYMS) {
            boolean in = false;
            for (String m : g) if (match(w, m) >= 75 || w.equals(m)) { in = true; break; }
            if (!in) continue;
            for (String m : g) if (!m.equals(w)) out.add(new Object[] { m, 70 });
        }
        return out;
    }

    /** O texto em PT, EN e ES, um depois do outro (so o PT se nao ha traducao). */
    static String allLangs(String pt) {
        if (pt == null || pt.isEmpty()) return "";
        StringBuilder b = new StringBuilder(pt);
        String en = I18n.trTo(pt, I18n.EN), es = I18n.trTo(pt, I18n.ES);
        if (!en.equals(pt)) b.append(' ').append(en);
        if (!es.equals(pt) && !es.equals(en)) b.append(' ').append(es);
        return b.toString();
    }

    private static void prepare(Section s) {
        if (s.tokBody != null) return;
        // a busca vale nos tres idiomas: os termos do texto em PT, EN e ES entram juntos
        s.tokTitle = tokens(norm(allLangs(s.title)));
        s.tokTags = tokens(norm(allLangs(s.tags)));
        s.tokBody = tokens(norm(allLangs(s.body)));
    }

    /** Melhor nota da palavra (com parentes) nos termos; {@code posWeight}: a primeira posicao pesa mais (tags). */
    private static int best(List<Object[]> variants, String[] terms, boolean posWeight) {
        int best = 0;
        for (Object[] v : variants) {
            String w = (String) v[0];
            int pct = (Integer) v[1];
            for (int i = 0; i < terms.length; i++) {
                int m = match(w, terms[i]);
                if (m == 0) continue;
                int sc = m * pct / 100 - (posWeight ? Math.min(i, 20) : 0);
                if (sc > best) best = sc;
            }
        }
        return best;
    }

    /** Pesquisa: tolera erros de digitacao e acha palavras relacionadas; todas as palavras da consulta precisam bater. Abas e menus vem antes dos textos; cada faixa fica da melhor para a pior. */
    static List<Hit> search(String query) {
        List<Hit> tabs = new ArrayList<Hit>(), texts = new ArrayList<Hit>();
        String q = norm(query).trim();
        if (q.isEmpty()) return tabs;
        String[] words = tokens(q);
        if (words.length == 0) return tabs;
        List<List<Object[]>> vars = new ArrayList<List<Object[]>>();
        for (String w : words) vars.add(expand(w));
        for (Chapter ch : chapters()) {
            String[] chTitle = tokens(norm(allLangs(ch.title)));
            for (Section sec : ch.sections) {
                prepare(sec);
                boolean allHead = true, allAny = true;
                int sHead = 0, sAny = 0;
                for (List<Object[]> v : vars) {
                    int title = best(v, sec.tokTitle, false);
                    int tag = sec.tab ? best(v, sec.tokTags, true) : 0;
                    int head = Math.max(title + (sec.tab ? 25 : 10), tag + 15);
                    if (title == 0 && tag == 0) head = 0;
                    int chap = best(v, chTitle, false) / 2;
                    int body = best(v, sec.tokBody, false) * 4 / 10;
                    int inHead = Math.max(head, chap);
                    if (inHead == 0) allHead = false;
                    int any = Math.max(inHead, body);
                    if (any == 0) { allAny = false; break; }
                    sHead += inHead;
                    sAny += any;
                }
                if (!allAny) continue;
                if (sec.tab && allHead) tabs.add(new Hit(ch, sec, true, sHead, ""));
                else texts.add(new Hit(ch, sec, false, sAny, snippet(sec, vars)));
            }
        }
        sortHits(tabs);
        sortHits(texts);
        List<Hit> out = new ArrayList<Hit>(tabs);
        out.addAll(texts);
        return out;
    }

    private static void sortHits(List<Hit> l) {
        // estavel: empates ficam na ordem dos capitulos
        java.util.Collections.sort(l, new java.util.Comparator<Hit>() {
            @Override public int compare(Hit a, Hit b) { return b.score - a.score; }
        });
    }

    /** Trecho do texto em volta da melhor palavra que bateu; vazio se o titulo ja basta. */
    private static String snippet(Section sec, List<List<Object[]>> vars) {
        String body = I18n.tr(sec.body);
        String nb = norm(body);
        java.util.regex.Matcher m = WORD.matcher(nb);
        int bestPos = -1, bestSc = 0;
        while (m.find()) {
            for (List<Object[]> v : vars) for (Object[] x : v) {
                int sc = match((String) x[0], m.group()) * (Integer) x[1] / 100;
                if (sc > bestSc) { bestSc = sc; bestPos = m.start(); }
            }
        }
        if (bestPos < 0) {
            // bateu so nos termos de outro idioma: mostra o comeco do texto no idioma atual
            if (body.length() <= 160) return body;
            int z0 = 160;
            while (z0 > 80 && body.charAt(z0) != ' ') z0--;
            return body.substring(0, z0).trim() + " …";
        }
        int a = Math.max(0, bestPos - 50), z = Math.min(body.length(), bestPos + 110);
        while (a > 0 && a < bestPos && body.charAt(a - 1) != ' ') a++;
        while (z < body.length() && z > bestPos && body.charAt(z) != ' ') z--;
        return (a > 0 ? "… " : "") + body.substring(a, z).trim() + (z < body.length() ? " …" : "");
    }
}
