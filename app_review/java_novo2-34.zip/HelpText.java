package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Texto do menu AJUDA: o que cada botao do menu superior e da tela faz, visto pela utilidade em editar e executar um golpe.
 * Java puro (testado sem Android). Os ids dos botoes do menu superior sao os de {@link ToolbarOrder}.
 */
final class HelpText {
    private HelpText() { }

    static final class Section {
        /** id de {@link ToolbarOrder} se a secao descreve um botao do menu superior; null nas demais. */
        final String button;
        final String title, body;

        Section(String button, String title, String body) {
            this.button = button;
            this.title = title;
            this.body = body;
        }
    }

    /** Dica de como mexer na propria barra (vai no topo da ajuda). */
    static final String REORDER_TIP =
            "ORDEM DOS BOTÕES: segure um botão do menu superior e arraste para frente ou para trás para mudar a ordem; "
            + "perto da borda a barra rola sozinha. O primeiro botão fica fixo no início da linha (hoje, por padrão, o SALVAR): "
            + "solte qualquer botão em cima dele para ele virar o fixo. A ordem fica salva no aparelho. "
            + "RESTAURAR ORDEM volta ao padrão.";

    /** Menu superior, na ordem de fabrica. */
    static List<Section> toolbar() {
        List<Section> s = new ArrayList<Section>();
        s.add(new Section(ToolbarOrder.SAVE, "SALVAR",
                "Grava as edições em .txt: o golpe atual (HDAT 4 + os ANOs dele), só o ANO atual, todos os golpes, todos os ANOs ou tudo. "
                + "Dá para salvar numa pasta separada (Tap Battle/TBRE/Chars/charNN/, não mexe no original) ou sobrescrever os .txt do Runtime (Tap Battle/assets/charNN/). "
                + "Em \"Salvar golpe atual\" há ainda \"Salvar em outro personagem (Runtime)\": escolhe o personagem (pastas char de assets), depois o golpe a substituir (os golpes 0, 3 e 6 só substituem o 0, 3 e 6; os demais, qualquer um fora esses três) e grava direto no Runtime dele, com cópia dos .txt dele em Tap Battle/TBRE/Backups/: o golpe do HDAT 4 é trocado, os ANOs entram no fim do DAC (renumerados), as sprites usadas entram no fim do CNV e das folhas, e as reações do personagem usadas vão para um slot livre. Sons do personagem (id 80+) e hitbox flags 20 e 41-125 não vão junto. "
                + "Ao salvar, o app confere os limites do jogo (hitboxes por frame, links, tempo...) e avisa o que faria o jogo fechar."));
        s.add(new Section(ToolbarOrder.CHAR, "CHAR",
                "Escolhe o ATACANTE e o OPONENTE (cada um com os próprios dados e sprites). POS ajusta a distância entre eles e a altura de cada um "
                + "arrastando na tela (as linhas são as posições do jogo: perto, médio, longe) e tem o FLY, que deixa o atacante voando em vez de cair. "
                + "CHAR OBJ mostra a caixa do corpo (HDAT 3) e as âncoras dos sprites, hurtboxes, hitboxes, efeitos e projéteis, e permite mudar o tamanho do corpo. "
                + "Use para testar o golpe contra outros lutadores e em outras alturas: a altura relativa decide qual ANO de projétil nasce (normal, de baixo ou de cima)."));
        s.add(new Section(ToolbarOrder.SPRITES, "SPRITES",
                "Lista os sprites (SPR_0, SPR_1...) do personagem atacante, já recortados pelo CNV; as folhas ficam intactas no disco. "
                + "Serve para adicionar, substituir e remover sprites, mudar o recorte e o índice, e para escolher qual sprite entra num frame do golpe."));
        s.add(new Section(ToolbarOrder.LINKS, "LINKS",
                "Mostra e edita os links do ANO atual: objetos filhos (efeitos, partes do corpo, auras) que o jogo cria junto com a animação e que seguem o pai. "
                + "O jogo aceita no máximo 13 por ANO e só 1 nível: link de link não nasce, e hitboxes/flags/animações dentro de um link não valem (o link mostra só as sprites dele). Animações disparadas por flag (efeito de hit, projétil, aura, cutscene) são raízes e mostram os próprios links. Ao abrir com a prévia num ANO que tem links, a lista rola para o primeiro e a seta ▶ vai para o próximo."));
        s.add(new Section(ToolbarOrder.MOVE, "GOLPE SET",
                "Opções do golpe (ATK_FLAGS do HDAT 4): agarrão (ao fim do ANO inicial ou só durante o hit), projétil nascendo no oponente ou embaixo dele, "
                + "lançar 3 projéteis (usa ANO, ANO+1 e ANO+2), projétil que só explode no chão, hitbox que destrói as do oponente e atravessar o oponente. "
                + "Só vale para o ANO inicial de um golpe. Define como o golpe é executado no jogo, não como ele é desenhado."));
        s.add(new Section(ToolbarOrder.HITBOX, "HITBOX",
                "Liga e desliga o desenho das caixas na preview: vermelha = hitbox (onde o golpe acerta), azul = hurtbox (onde o personagem leva dano) "
                + "e amarela = as demais caixas de flag. Ligado ajuda a posicionar o alcance; desligado deixa ver só a arte."));
        s.add(new Section(ToolbarOrder.TIME, "TEMPO",
                "Muda como o tempo corre na simulação. NORMAL: o golpe roda como no jogo e a preview termina quando tudo acaba. "
                + "ESTENDIDO: o atacante fica parado no último frame quando o ANO acaba, para você ver projéteis e a reação do oponente até o fim. "
                + "ATAQUE: como estendido, mas a reprodução para sozinha no pouso (a barra continua livre)."));
        s.add(new Section(ToolbarOrder.CENTER, "CENTRO",
                "Câmera da preview. NORMAL: livre; você arrasta e dá zoom com os dedos, e o mapa inteiro fica enquadrado ao centralizar. "
                + "TELA: segue o recorte que o jogo realmente mostra (480x320, com a rolagem, o zoom e o tremor da câmera do jogo). "
                + "CHAR: enquadra os dois lutadores com zoom automático, bom para golpes de longe ou de ar."));
        s.add(new Section(ToolbarOrder.LAND, "POUSO",
                "ON: o atacante cai e pousa como no jogo, e a troca de ANO de pouso/queda acontece (SEQ e END de ar/chão). "
                + "OFF: só zera a velocidade no chão e segue no mesmo ANO. Desligue para editar um ANO sem a queda interferir."));
        s.add(new Section(ToolbarOrder.LOCK, "TRANSIÇÃO",
                "LIVRE: o fluxo do golpe acontece (SEQ, fim, pouso, queda trocam de ANO sozinhos). "
                + "TRAVADA: congela as trocas a partir do frame atual, para você editar um ANO sem a simulação sair dele. Travar desliga o POUSO; destravar devolve o estado anterior."));
        s.add(new Section(ToolbarOrder.FLIP, "VIRAR",
                "Vira o lado da luta: o atacante passa a olhar para o outro lado e o oponente fica do lado oposto. "
                + "Útil para conferir espelhamentos, ANO espelhado, projéteis indo para trás e efeitos com flip."));
        s.add(new Section(ToolbarOrder.HIDE, "HIDE-EFF",
                "Esconde efeitos, auras, cenas (bobj) e projéteis e deixa só atacante e oponente. Serve para ver o que é do personagem e o que é do efeito."));
        s.add(new Section(ToolbarOrder.GHOST, "FR-PREVIEW",
                "Frame preview: desenha o frame anterior (PREV) ou o próximo (NEXT) em transparência por cima do atual, para alinhar sprites e hitboxes entre frames. "
                + "Em TELA > FR-PREVIEW SET dá para ajustar a transparência e incluir projéteis e efeitos."));
        s.add(new Section(ToolbarOrder.SCREEN, "TELA",
                "Opções do que aparece na preview: grade, sons, cenas (cutscenes da flag 20), travar (modo cinemático do jogo), box amarela de todos os sprites e FR-PREVIEW SET. "
                + "Desligar cenas ou sons ajuda a editar sem distração; o jogo sempre os executa."));
        return s;
    }

    /** Resto da tela (nao e botao do menu superior). */
    static List<Section> screen() {
        List<Section> s = new ArrayList<Section>();
        s.add(new Section(null, "Barra de título",
                "No topo: \"Attack Editor by Zue Mods\" (tocar em Zue Mods abre o canal no YouTube) e o botão AJUDA, à direita, que abre este texto e tem o botão RESTAURAR ORDEM "
                + "para devolver os botões do menu superior à ordem padrão."));
        s.add(new Section(null, "MODO: GOLPES / ANO",
                "GOLPES lista os golpes do personagem (cada um com seus ANOs, projéteis e reações). ANO lista os ANOs soltos, para abrir e editar uma animação isolada, "
                + "sem o golpe em volta. Ao tocar no seletor ao lado, escolhe-se o golpe ou o ANO."));
        s.add(new Section(null, "Barra de tempo e transporte",
                "A barra mostra o tick da simulação (e o frame/total). INÍCIO volta ao tick 0, -1 e +1 andam um tick (para conferir frame a frame), "
                + "PAUSAR/PLAY reproduz, e o botão de velocidade alterna a velocidade da reprodução. "
                + "A preview roda a batalha inteira: atacante, oponente, projéteis, efeitos, câmera, zoom, tremor e cutscenes, como o jogo."));
        s.add(new Section(null, "DIVIDIR / DUPLICAR / EXCLUIR / DESFAZER",
                "Editam o item selecionado na timeline: DIVIDIR corta o sprite sob o ponteiro em dois (o resultado visual continua igual) ou, com um objeto "
                + "selecionado, separa o objeto na divisa de frames mais próxima; DUPLICAR copia o sprite ou o objeto para o frame seguinte; "
                + "EXCLUIR remove o sprite, objeto ou link selecionado; DESFAZER volta a última edição."));
        s.add(new Section(null, "Timeline  ＋  e  #",
                "A timeline mostra, por frame, os sprites, hitboxes, hurtboxes, projéteis, efeitos, sons e velocidades do ANO. Toque num item para editar nas ferramentas abaixo. "
                + "O ＋ adiciona no ponteiro um sprite, hitbox, hurtbox, projétil, efeito, som, velocidade, animação ligada ou uma ação especial "
                + "(tremer cenário, cutscene, zoom de câmera, teleportar até o oponente, puxar oponente, curar vida...). "
                + "O # escolhe o que a timeline mostra. Só aparecem faixas com uso (sem som, velocidade ou estilo no ANO, a faixa some). "
                + "Itens iguais em frames diferentes dividem a mesma faixa; itens iguais no mesmo frame (duas hitboxes iguais, duas transições) ficam em faixas diferentes."));
        s.add(new Section(null, "Menu da sprite (gaveta)",
                "Tocar numa sprite da timeline abre uma grade de botões: Imagem, Tempo, Som, Movimento, Efeitos e Copiar. Cada um abre uma página dentro da gaveta (a prévia continua visível; ◀ volta à grade). "
                + "IMAGEM: thumb, − N + (segure; tocar no número abre a grade de sprites), posição, zoom (unir X e Y), rotação, alpha, \"mover links junto\", \"Editar posição do Link\" e Remover imagem. "
                + "TEMPO: ticks do frame (0 = frame travado, sem TIME), duração em segundos e Remover Frame. "
                + "SOM: o som do frame no estilo da lista de sons, − e + só pelos ids que existem, Escolher e Remover Áudio. "
                + "MOVIMENTO: velocidade x/y; num frame que recebe a velocidade do anterior os campos ficam zerados e somam à recebida (aparece em amarelo, com Remover); aceleração só aparece com speed; frame inicial e duração do trecho, Manter velocidade (passa a velocidade deste frame ao próximo), total de pixels e Remover speed. "
                + "EFEITOS: Flip X/Y e Interpolação. COPIAR: aplica as coisas do frame em outros frames. "
                + "Tocar num item de velocidade, som ou estilo da timeline abre direto a página dele. Os itens de caixas (hitbox/hurtbox), efeitos de hit e links da timeline continuam com as ferramentas de antes."));
        s.add(new Section(null, "Menu de Hitbox / Hurtbox",
                "Tocar numa box da timeline abre, de cima para baixo: o interruptor Hurtbox | Hitbox; FRAME DE INÍCIO (move a box inteira mantendo a duração; se cair em cima de outra box igual ela ganha uma faixa própria) e DURAÇÃO; "
                + "a prévia parada do frame atual mostrando só a box que você edita (hurtbox sem a hitbox e vice-versa); x, y, largura e altura; remover a box. Ao mover o ponteiro, o menu só muda se o novo frame tem esta box; se não tem, fica como está. Só para hitbox: DANO e REAÇÃO (com prévia e botões para trocar; são do sprite sob o ponteiro e acompanham a hitbox quando você muda o frame de início ou a duração) "
                + "e TRANSIÇÃO: a transição atual (SEQ/END), mudar o ANO destino e, se o golpe tem SEQ, bloquear a sequência neste hit. "
                + "Na timeline, a faixa da hitbox é vermelha e a de som é azul."));
        s.add(new Section(null, "Speed x Accel (velocidade e aceleração)",
                "SPEED é uma velocidade constante: o objeto anda essa quantidade de pixels a cada tick, sempre igual. Ex.: speed 50 por 5 ticks = 250 px. "
                + "ACCEL é uma velocidade de aceleração: a cada tick ela soma o valor dela na velocidade atual (o objeto anda com a velocidade que tem e só depois soma). "
                + "Ex.: accel 50 por 5 ticks, partindo do repouso, anda 0, 50, 100, 150 e 200 = 500 px e termina com velocidade 250. "
                + "A accel só vale no frame em que está escrita; a velocidade que ela acumulou só passa para o frame seguinte se ele tiver Manter velocidade, senão volta a 0. "
                + "Para continuar acelerando (ou frear) no frame seguinte, escreva a accel de novo nele. Accel sozinha, sem speed e sem velocidade recebida, é uma aceleração a partir do repouso (queda, arrancada) e não equivale a uma speed."));
        s.add(new Section(null, "Tela do projétil",
                "Tocar num hit de projétil (flag 0) abre, de cima para baixo: início e duração; RAMIFICAÇÃO DO PROJÉTIL (a árvore com ao acertar, chão, abaixo, acima, global e sub-projétil); ANO do projétil (− N +, toque no número para a grade); "
                + "posição e velocidade; perseguição (e repetições); e a sequência SEQ_PROJETIL. A mesma tela abre no modo ANO e edita o golpe do HDAT 4 que é dono do ANO."));
        s.add(new Section(null, "Editor de reações",
                "No menu da hitbox, EDITAR REAÇÃO (do personagem) ou VER REAÇÃO (do jogo, só leitura) abre uma tela no estilo da timeline: no topo a prévia do oponente recebendo a reação "
                + "(TOCAR, −1, +1, ⏮), no meio a timeline e embaixo as abas do passo selecionado. CHÃO | AR escolhe o cenário simulado: o jogo usa a duração e a velocidade de chão enquanto o oponente está no chão e as de ar quando está no ar. "
                + "A timeline mostra PASSOS (miniatura do ANO do oponente, ⇄ se espelhado, duração; as reações seguintes aparecem em cinza), VELOC. (curva de x e y em px/tick), VALORES (velocidade e aceleração da tabela; = mantém, ½ metade), VOZ e FLUXO (próxima reação e parede). "
                + "Arraste a timeline para mover o ponteiro (a prévia acompanha), belisque para dar zoom, toque num passo para selecioná-lo; tocar a prévia/arrastar também troca o passo da aba. "
                + "Abas: ANIMAÇÃO (ANO do oponente e espelhar), TEMPO (duração de chão e de ar; 255 no ar = até pousar), MOVIMENTO (velocidade e aceleração do cenário; = mantém e ½; copiar para o outro cenário), FLUXO (próxima reação, parede, voz) e TOTAL (deslocamento). "
                + "＋ PASSO, DUPLICAR, ◀ ▶ (mover), ✕ REMOVER e DESFAZER editam os passos. Tudo vem da simulação do jogo, a mesma da prévia."));
        s.add(new Section(null, "Slots de reação do personagem",
                "O personagem tem 20 slots de reação (HDAT 14 a 33, que no hit valem de 30 a 49). Na tela \"Escolher reação\" os slots vazios aparecem como \"＋ vazio\". "
                + "Tocar num deles oferece: copiar de uma reação do personagem, copiar da game data (as reações globais 0 a 29), importar de outro personagem (lê o 000.bin dele, com miniaturas dos ANOs) ou criar em branco (1 passo). "
                + "A reação nova é criada no slot (dá para desfazer) e o hit passa a usá-la; depois é só ajustar nos passos. Ao salvar, o bloco do slot é criado no 000.bin.txt se faltar "
                + "(precisa existir o $HDAT_14+n no arquivo; se não existir o app avisa). Ao salvar o golpe em outro personagem, as reações usadas preferem um slot vazio do destino."));
        s.add(new Section(null, "Limite de 8 projéteis",
                "O jogo só mantém 8 projéteis vivos ao mesmo tempo (BulletNum < 8), contando os sub-projéteis. Um hit de projétil (flag 0) que acontece com 8 já na tela "
                + "não cria nada, sem aviso: se um projétil \"não sai\" num golpe que lança vários, confira se os anteriores já sumiram. "
                + "O editor também não avisa isso na tela; os outros motivos de projétil que não nasce (ANO vazio, campo do HDAT 4 vazio, golpe que errou, transição travada...) continuam avisando."));
        s.add(new Section(null, "Altura da gaveta: Y e T",
                "A gaveta abre sempre na altura padrão: por cima da tela, subindo até a base da prévia. Arraste a borda (a alça) para subir ou descer à vontade, até por cima da prévia; "
                + "isso vale só para aquela abertura. Y (na borda, à direita) grava a altura atual como a nova altura padrão. "
                + "T põe a timeline acima do menu: a prévia diminui na proporção, o menu só sobe até a metade da tela e o menu superior some para liberar espaço; tocar em T de novo volta ao modo normal. O modo T só vale com a gaveta aberta: ao fechar a gaveta o menu superior, a rolagem e a timeline voltam ao lugar. "
                + "Cada modo guarda a própria altura padrão (o Y salva só a altura); o modo T nunca fica salvo: o app sempre abre com ele desligado."));
        s.add(new Section(null, "DADOS / EDITAR",
                "Painel recolhido com os dados do DAC em texto: abas GOLPE (HDAT 4), ANO e FRAME no modo golpes, e ANO, FRAME e LINKS no modo ANO. "
                + "O lápis abre o editor em texto para mudar o valor direto."));
        s.add(new Section(null, "Avisos na tela",
                "A barra de aviso fica amarela quando o editor vê algo que o jogo trata diferente (limites estourados, animação que cai antes do fim, "
                + "projétil que não nasce) e vermelha quando o jogo fecharia ou erraria. Toque no aviso para ler inteiro; alguns têm um botão que leva direto ao ajuste (POS)."));
        return s;
    }

    /** Todas as secoes: menu superior, depois a tela. */
    static List<Section> all() {
        List<Section> s = toolbar();
        s.addAll(screen());
        return s;
    }

    static Section forButton(String id) {
        for (Section s : toolbar()) if (s.button != null && s.button.equals(id)) return s;
        return null;
    }
}
