package com.zue.attackeditor;

/**
 * Estado do aviso de hitstop ao avancar tick pelo botao (Java puro). O acerto congela o atacante por N ticks (o jogo grava um contador fixo,
 * nao espera o hitspark): enquanto isso o contador de tick mostrado fica travado e um aviso diz quantos ticks faltam. Quando o tick e
 * liberado o aviso some. Timeline, barra de progresso e reproducao nao usam isto.
 */
final class HitstopNotice {
    private int left;
    private int locked = -1;

    /** Depois de um passo do botao: {@code tick} = tick da simulacao agora, {@code hsLeft} = ticks de hitstop do atacante que ainda faltam. */
    void afterStep(int tick, int hsLeft) {
        if (hsLeft > 0) {
            if (left == 0) locked = tick;          // entrou no congelamento: o numero do tick fica neste
            left = hsLeft;
        } else {
            left = 0;
            locked = -1;
        }
    }

    void clear() { left = 0; locked = -1; }

    boolean active() { return left > 0; }
    int left() { return left; }

    /** Tick a mostrar: o travado durante o hitstop, o real no resto. */
    int shownTick(int realTick) { return active() ? locked : realTick; }

    /** Texto do aviso amarelo. */
    String text() {
        return "Hitstop: o acerto congela o Frame por mais " + left + (left == 1 ? " tick" : " ticks")
                + " (o hitspark continua tocando). O tick libera depois disso.";
    }
}
