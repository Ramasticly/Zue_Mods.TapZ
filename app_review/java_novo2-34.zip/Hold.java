package com.zue.attackeditor;

import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

/** Botao de passo (- / +): um toque faz um passo; segurando, repete cada vez mais rapido. */
final class Hold {
    private Hold() { }

    static void attach(final View v, final Runnable step) {
        final Handler h = new Handler(Looper.getMainLooper());
        final int[] n = {0};
        final Runnable rep = new Runnable() {
            @Override public void run() {
                if (!v.isAttachedToWindow()) return;      // a view foi reconstruida: o ACTION_UP nao chegara
                step.run();
                n[0]++;
                h.postDelayed(this, n[0] < 6 ? 120 : n[0] < 18 ? 65 : 30);
            }
        };
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setPressed(true);
                        if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(true);
                        step.run();
                        n[0] = 0;
                        h.postDelayed(rep, 420);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        h.removeCallbacks(rep);
                        view.setPressed(false);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }
}
