package com.zue.attackeditor;

import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

/** Botao de passo (- / +): um toque faz um passo; segurando, repete cada vez mais rapido. */
final class Hold {
    private Hold() { }

    /** Quantos passos cada repeticao vale quando o botao fica pressionado: 1x no comeco, depois pula mais numeros (5x, 10x, 25x). {@code repeat} 0 = o toque. */
    static int multiplier(int repeat) { return repeat < 6 ? 1 : repeat < 14 ? 5 : repeat < 24 ? 10 : 25; }

    /** Passo que sabe quantas repeticoes ja houve (0 = o primeiro toque). */
    interface Rep { void step(int repeat); }

    static void attach(final View v, final Runnable step) {
        attachRep(v, new Rep() { @Override public void step(int repeat) { step.run(); } });
    }

    /** Como {@link #attach(View, Runnable)}, mas entrega o numero da repeticao (para acelerar o passo com {@link #multiplier}). */
    static void attach(final View v, final Rep step) { attachRep(v, step); }

    private static void attachRep(final View v, final Rep step) {
        final Handler h = new Handler(Looper.getMainLooper());
        final int[] n = {0};
        final Runnable rep = new Runnable() {
            @Override public void run() {
                if (!v.isAttachedToWindow()) return;      // a view foi reconstruida: o ACTION_UP nao chegara
                step.step(n[0] + 1);
                n[0]++;
                h.postDelayed(this, n[0] < 6 ? 120 : n[0] < 18 ? 65 : 30);
            }
        };
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        view.setPressed(true);
                        if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(true);
                        step.step(0);
                        n[0] = 0;
                        h.postDelayed(rep, 420);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        h.removeCallbacks(rep);
                        view.setPressed(false);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }
}
