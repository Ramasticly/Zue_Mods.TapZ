package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Idioma da interface (PT padrao, EN, ES latino). O codigo e os dados internos ficam em portugues; so o que vai para a tela passa por {@link #tr}.
 * Resolucao, nesta ordem: 1) texto exato do catalogo; 2) modelo com {0}, {1}... (ex.: "Salvando em {0}") casado com o texto ja montado;
 * 3) troca de fragmentos do catalogo por limite de palavra (maior primeiro), para textos concatenados. Sem traducao, devolve o proprio texto.
 * Termos neutros (DAC, CNV, ANO, MPT, HDAT, OPT, SEQ, END) ficam iguais nas tres colunas do catalogo. Java puro.
 */
final class I18n {
    private I18n() { }

    static final int PT = 0, EN = 1, ES = 2;
    static final String[] CODES = {"PT", "EN", "ES"};

    private static int lang = PT;

    static int lang() { return lang; }

    static String code() { return CODES[lang]; }

    static void set(int l) {
        int n = (l < 0 || l > 2) ? PT : l;
        if (n == lang) return;
        lang = n;
        cache.clear();
    }

    /** Proximo idioma da volta PT -> EN -> ES -> PT; devolve o novo. */
    static int next() {
        set((lang + 1) % 3);
        return lang;
    }

    static int fromCode(String c) {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equalsIgnoreCase(c)) return i;
        return PT;
    }

    // ---- catalogo ----

    private static boolean loaded;
    private static final Map<String, String[]> exact = new HashMap<String, String[]>();
    private static final List<Tpl> templates = new ArrayList<Tpl>();
    private static final List<String[]> fragments = new ArrayList<String[]>();

    private static final class Tpl {
        final Pattern re;
        final String[] to;
        final int groups;

        Tpl(Pattern re, String[] to, int groups) {
            this.re = re;
            this.to = to;
            this.groups = groups;
        }
    }

    private static final Pattern PLACE = Pattern.compile("\\{(\\d)\\}");

    /** Todas as entradas {pt, en, es} do catalogo (varios blocos em I18nCatalog*). */
    static List<String[]> entries() {
        if (testEntries != null) return testEntries;
        List<String[]> all = new ArrayList<String[]>();
        for (String[][] block : I18nCatalog.blocks()) for (String[] e : block) all.add(e);
        return all;
    }

    private static synchronized void load() {
        if (loaded) return;
        loaded = true;
        for (String[] e : entries()) {
            if (e.length < 3 || e[0].length() == 0) continue;
            if (PLACE.matcher(e[0]).find()) templates.add(template(e));
            else {
                exact.put(e[0], e);
                if (e[0].length() >= 3 && !(e[0].equals(e[1]) && e[0].equals(e[2]))) fragments.add(e);
            }
        }
        java.util.Collections.sort(fragments, new java.util.Comparator<String[]>() {
            @Override public int compare(String[] a, String[] b) { return b[0].length() - a[0].length(); }
        });
        java.util.Collections.sort(templates, new java.util.Comparator<Tpl>() {
            @Override public int compare(Tpl a, Tpl b) { return b.re.pattern().length() - a.re.pattern().length(); }
        });
    }

    private static Tpl template(String[] e) {
        StringBuilder re = new StringBuilder("^");
        Matcher m = PLACE.matcher(e[0]);
        int last = 0, groups = 0;
        while (m.find()) {
            re.append(Pattern.quote(e[0].substring(last, m.start())));
            re.append("(.*?)");
            last = m.end();
            groups++;
        }
        re.append(Pattern.quote(e[0].substring(last))).append('$');
        return new Tpl(Pattern.compile(re.toString(), Pattern.DOTALL), e, groups);
    }

    private static final Map<String, String> cache = new LinkedHashMap<String, String>(256, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) { return size() > 2048; }
    };

    static boolean hasLetters(String s) {
        for (int i = 0; i < s.length(); i++) if (Character.isLetter(s.charAt(i))) return true;
        return false;
    }

    /** Traduz um texto de interface para o idioma atual (PT = devolve igual). */
    static synchronized String tr(String s) {
        if (lang == PT || s == null || s.length() == 0 || !hasLetters(s)) return s;
        String hit = cache.get(s);
        if (hit != null) return hit;
        String out = translate(s, lang, 0);
        cache.put(s, out);
        return out;
    }

    /** Como {@link #tr} para um idioma explicito (testes e geradores). */
    static synchronized String trTo(String s, int l) {
        int old = lang;
        try {
            if (l == PT || s == null) return s;
            return translate(s, l, 0);
        } finally { lang = old; }
    }

    private static String translate(String s, int l, int depth) {
        load();
        if (!hasLetters(s)) return s;
        String[] e = exact.get(s);
        if (e != null) return e[l];
        String t = s.trim();
        if (t.length() != s.length() && t.length() > 0) {            // mesmo texto com espacos nas pontas
            String[] e2 = exact.get(t);
            if (e2 != null) return s.substring(0, s.indexOf(t.charAt(0))) + e2[l] + s.substring(s.lastIndexOf(t.charAt(t.length() - 1)) + 1);
        }
        for (Tpl tp : templates) {
            Matcher m = tp.re.matcher(s);
            if (!m.matches()) continue;
            String res = tp.to[l];
            for (int g = 0; g < tp.groups; g++) {
                String part = m.group(g + 1);
                if (depth < 2 && hasLetters(part)) part = translate(part, l, depth + 1);
                res = res.replace("{" + g + "}", part);
            }
            return res;
        }
        return fragmentsOf(s, l);
    }

    private static boolean isWord(char c) { return Character.isLetterOrDigit(c) || c == '_' || c == '$'; }

    private static String fragmentsOf(String s, int l) {
        StringBuilder cur = new StringBuilder(s);
        List<String> marks = new ArrayList<String>();
        boolean any = false;
        for (String[] f : fragments) {
            String key = f[0];
            int from = 0;
            while (true) {
                int at = cur.indexOf(key, from);
                if (at < 0) break;
                int end = at + key.length();
                boolean okL = !isWord(key.charAt(0)) || at == 0 || !isWord(cur.charAt(at - 1));
                boolean okR = !isWord(key.charAt(key.length() - 1)) || end >= cur.length() || !isWord(cur.charAt(end));
                if (!okL || !okR) { from = at + 1; continue; }
                String mark = "" + marks.size() + "";
                marks.add(f[l]);
                cur.replace(at, end, mark);
                from = at + mark.length();
                any = true;
            }
        }
        if (!any) return s;
        String r = cur.toString();
        for (int i = marks.size() - 1; i >= 0; i--) r = r.replace("" + i + "", marks.get(i));
        return r;
    }

    private static List<String[]> testEntries;

    /** So para testes: usa estas entradas no lugar do catalogo (null = catalogo real) e relê tudo. */
    static synchronized void useEntries(List<String[]> e) {
        testEntries = e;
        reset();
    }

    /** So para testes: forca a releitura do catalogo. */
    static synchronized void reset() {
        loaded = false;
        exact.clear();
        templates.clear();
        fragments.clear();
        cache.clear();
    }
}
