package com.zue.attackeditor;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

/** AlertDialog.Builder que traduz titulo, mensagem, botoes e itens ({@link I18n#tr}); o resto e igual. */
final class I18nBuilder extends AlertDialog.Builder {
    I18nBuilder(Context c) { super(c); }

    I18nBuilder(Context c, int theme) { super(c, theme); }

    private static CharSequence t(CharSequence s) { return s == null || I18n.lang() == I18n.PT ? s : I18n.tr(s.toString()); }

    private static CharSequence[] t(CharSequence[] a) {
        if (a == null || I18n.lang() == I18n.PT) return a;
        CharSequence[] o = new CharSequence[a.length];
        for (int i = 0; i < a.length; i++) o[i] = t(a[i]);
        return o;
    }

    @Override public AlertDialog.Builder setTitle(CharSequence title) { return super.setTitle(t(title)); }

    @Override public AlertDialog.Builder setMessage(CharSequence message) { return super.setMessage(t(message)); }

    @Override public AlertDialog.Builder setPositiveButton(CharSequence text, DialogInterface.OnClickListener l) { return super.setPositiveButton(t(text), l); }

    @Override public AlertDialog.Builder setNegativeButton(CharSequence text, DialogInterface.OnClickListener l) { return super.setNegativeButton(t(text), l); }

    @Override public AlertDialog.Builder setNeutralButton(CharSequence text, DialogInterface.OnClickListener l) { return super.setNeutralButton(t(text), l); }

    @Override public AlertDialog.Builder setItems(CharSequence[] items, DialogInterface.OnClickListener l) { return super.setItems(t(items), l); }

    @Override public AlertDialog.Builder setMultiChoiceItems(CharSequence[] items, boolean[] checked, DialogInterface.OnMultiChoiceClickListener l) {
        return super.setMultiChoiceItems(t(items), checked, l);
    }

    @Override public AlertDialog.Builder setSingleChoiceItems(CharSequence[] items, int checked, DialogInterface.OnClickListener l) {
        return super.setSingleChoiceItems(t(items), checked, l);
    }
}
