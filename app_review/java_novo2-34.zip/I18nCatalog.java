package com.zue.attackeditor;

/** Catalogo de traducao da interface: blocos de entradas {pt, en, es} (gerados de i18n_src/*.tsv). */
final class I18nCatalog {
    private I18nCatalog() { }

    static String[][][] blocks() {
        return new String[][][] { I18nCatalog0.E };
    }
}
