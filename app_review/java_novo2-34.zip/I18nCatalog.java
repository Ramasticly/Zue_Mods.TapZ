package com.zue.attackeditor;

/** Catalogo de traducao da interface: blocos de entradas {pt, en, es}. */
final class I18nCatalog {
    private I18nCatalog() { }

    static String[][][] blocks() {
        return new String[][][] { I18nCatalog0.E, I18nCatalog1.E, I18nCatalog2.E, I18nCatalog3.E, I18nCatalog4.E };
    }
}
