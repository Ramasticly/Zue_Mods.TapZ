package com.zue.attackeditor;

/** Bloco 0 do catalogo (inicial). */
final class I18nCatalog0 {
    private I18nCatalog0() { }

    static final String[][] E = {
        {"AJUDA", "HELP", "AYUDA"},
        {"Ajuda de IA", "AI help", "Ayuda de IA"},
        {"FECHAR", "CLOSE", "CERRAR"},
        {"Salvando em {0}", "Saving to {0}", "Guardando en {0}"},
    };
}
