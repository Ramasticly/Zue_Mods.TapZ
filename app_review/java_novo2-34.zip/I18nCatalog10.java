package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 10 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog10 {
    private I18nCatalog10() { }

    static final String[][] E = {
        {"CONTINUAR EDITANDO", "KEEP EDITING", "SEGUIR EDITANDO"},
        {"Descartar as mudanças?", "Discard the changes?", "¿Descartar los cambios?"},
        {"FECHAR EDIÇÃO", "CLOSE EDITING", "CERRAR EDICIÓN"},
        {"Os ANOs editados mudam em todo lugar que os usa. O ↶ do app desfaz; o SALVAR do app grava no arquivo.", "The edited ANOs change everywhere they are used. The app ↶ undoes it; the app SAVE writes it to the file.", "Los ANOs editados cambian en todo lugar que los usa. El ↶ de la app lo deshace; el GUARDAR de la app lo graba en el archivo."},
        {"Os ajustes de zoom/posição só valem no PAC do personagem: foram descartados", "Zoom/position adjustments only apply to the character PAC: they were discarded", "Los ajustes de zoom/posición solo valen en el PAC del personaje: se descartaron"},
        {"Os campos mostram o frame que está na prévia e acompanham os frames. Mudar um valor soma a mesma diferença em todos os frames do ANO (os links não mudam); com «Aplicar apenas nesse Frame» só o frame da prévia muda.", "The fields show the frame in the preview and follow the frames. Changing a value adds the same difference to every frame of the ANO (links do not change); with «Apply only to this Frame» only the preview frame changes.", "Los campos muestran el frame que está en la vista previa y siguen los frames. Cambiar un valor suma la misma diferencia en todos los frames del ANO (los links no cambian); con «Aplicar solo en este Frame» solo cambia el frame de la vista previa."},
        {"PAC das duas animações:", "PAC of both animations:", "PAC de las dos animaciones:"},
        {"antes:", "before:", "antes:"},
        {"em todos os frames", "in every frame", "en todos los frames"},
        {"virado para a frente", "facing forward", "mirando hacia delante"},
        {"virado para trás", "facing backward", "mirando hacia atrás"},
        {"zoom/posição diferentes por frame", "zoom/position different per frame", "zoom/posición distintos por frame"},
        {"⚠ Só a ANIM_FLIP_ID foi editada: confira se a ANIM_ID (virado para a frente) precisa do mesmo ajuste.", "⚠ Only ANIM_FLIP_ID was edited: check whether ANIM_ID (facing forward) needs the same adjustment.", "⚠ Solo se editó la ANIM_FLIP_ID: revisa si la ANIM_ID (mirando hacia delante) necesita el mismo ajuste."},
        {"⚠ Só a ANIM_ID foi editada: confira se a ANIM_FLIP_ID (virado para trás) precisa do mesmo ajuste.", "⚠ Only ANIM_ID was edited: check whether ANIM_FLIP_ID (facing backward) needs the same adjustment.", "⚠ Solo se editó la ANIM_ID: revisa si la ANIM_FLIP_ID (mirando hacia atrás) necesita el mismo ajuste."},
        {"Agarrado no", "Grabbed in", "Agarrado en"},
        {"Animação da flag", "Animation of flag", "Animación de la flag"},
        {"Campo do", "Field of", "Campo del"},
        {"Cutscene do evento", "Cutscene of event", "Cutscene del evento"},
        {"Link do ANO", "Link of ANO", "Link del ANO"},
        {"Projétil do", "Projectile of", "Proyectil del"},
        {"virado", "flipped", "volteado"},
        {"Nenhum uso: nenhum link, flag de animação, cutscene, projétil ou campo de golpe usa este ANO.", "No uses: no link, animation flag, cutscene, projectile or move field uses this ANO.", "Ningún uso: ningún link, flag de animación, cutscene, proyectil o campo de golpe usa este ANO."},
        {"ORIGEM", "ORIGIN", "ORIGEN"},
        {"Toque num uso para editar este ANO no contexto dele: a prévia toca o ANO/golpe que o usa (só para ver) e a timeline edita este ANO, começando no tick em que ele aparece.", "Tap a use to edit this ANO in its context: the preview plays the ANO/move that uses it (only to watch) and the timeline edits this ANO, starting at the tick where it appears.", "Toca un uso para editar este ANO en su contexto: la vista previa reproduce el ANO/golpe que lo usa (solo para ver) y la timeline edita este ANO, empezando en el tick en que aparece."},
        {"USOS DO ANO", "USES OF ANO", "USOS DEL ANO"},
        {"EDITAR NOS USOS", "EDIT IN USES", "EDITAR EN LOS USOS"},
        {"EDITAR NOS USOS: a prévia toca", "EDIT IN USES: the preview plays", "EDITAR EN LOS USOS: la vista previa reproduce"},
        {"F-GHOST, POSE e SPEEDLINE ficam desligados aqui.", "F-GHOST, POSE and SPEEDLINE are off here.", "F-GHOST, POSE y SPEEDLINE quedan apagados aquí."},
        {"O ANO não aparece nesta simulação (com a distância/altura atuais): a timeline fica no frame 0.", "The ANO does not appear in this simulation (with the current distance/height): the timeline stays on frame 0.", "El ANO no aparece en esta simulación (con la distancia/altura actuales): la timeline queda en el frame 0."},
        {"VOLTAR PARA ANO", "BACK TO ANO", "VOLVER AL ANO"},
        {"a timeline edita o ANO", "the timeline edits ANO", "la timeline edita el ANO"},
        {"Sem o golpe: câmera parada (sem zoom nem rolagem). Com zoom (flag 30/31) ou na trava dos especiais, Fundo e Meio são ampliados junto com o cenário; Frente não. Veja com o CHAR ligado.", "Without the move: the camera is still (no zoom or scrolling). With zoom (flag 30/31) or in the special-move lock, Back and Middle are enlarged together with the stage; Front is not. See it with CHAR on.", "Sin el golpe: cámara quieta (sin zoom ni desplazamiento). Con zoom (flag 30/31) o en el bloqueo de los especiales, Fondo y Medio se amplían junto con el escenario; Frente no. Míralo con el CHAR activado."},
        {"nenhum frame no ponteiro", "no frame at the pointer", "ningún frame en el puntero"},
    };
}
