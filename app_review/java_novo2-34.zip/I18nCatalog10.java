package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 10 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog10 {
    private I18nCatalog10() { }

    static final String[][] E = {
        {"CONTINUAR EDITANDO", "KEEP EDITING", "SEGUIR EDITANDO"},
        {"Descartar as mudanças?", "Discard the changes?", "¿Descartar los cambios?"},
        {"FECHAR EDIÇÃO", "CLOSE EDITING", "CERRAR EDICIÓN"},
        {"Os ANOs editados mudam em todo lugar que os usa. O ↶ do app desfaz; o SALVAR do app grava no arquivo.", "The edited ANOs change everywhere they are used. The app ↶ undoes it; the app SAVE writes it to the file.", "Los ANOs editados cambian en todo lugar que los usa. El ↶ de la app lo deshace; el GUARDAR de la app lo graba en el archivo."},
        {"Os ajustes de zoom/posição só valem no PAC do personagem: foram descartados", "Zoom/position adjustments only apply to the character PAC: they were discarded", "Los ajustes de zoom/posición solo valen en el PAC del personaje: se descartaron"},
        {"Os campos mostram o frame que está na prévia e acompanham os frames. Mudar um valor soma a mesma diferença em todos os frames do ANO (os links não mudam); com «Aplicar apenas nesse Frame» só o frame da prévia muda.", "The fields show the frame in the preview and follow the frames. Changing a value adds the same difference to every frame of the ANO (links do not change); with «Apply only to this Frame» only the preview frame changes.", "Los campos muestran el frame que está en la vista previa y siguen los frames. Cambiar un valor suma la misma diferencia en todos los frames del ANO (los links no cambian); con «Aplicar solo en este Frame» solo cambia el frame de la vista previa."},
        {"PAC das duas animações:", "PAC of both animations:", "PAC de las dos animaciones:"},
        {"antes:", "before:", "antes:"},
        {"em todos os frames", "in every frame", "en todos los frames"},
        {"virado para a frente", "facing forward", "mirando hacia delante"},
        {"virado para trás", "facing backward", "mirando hacia atrás"},
        {"zoom/posição diferentes por frame", "zoom/position different per frame", "zoom/posición distintos por frame"},
        {"⚠ Só a ANIM_FLIP_ID foi editada: confira se a ANIM_ID (virado para a frente) precisa do mesmo ajuste.", "⚠ Only ANIM_FLIP_ID was edited: check whether ANIM_ID (facing forward) needs the same adjustment.", "⚠ Solo se editó la ANIM_FLIP_ID: revisa si la ANIM_ID (mirando hacia delante) necesita el mismo ajuste."},
        {"⚠ Só a ANIM_ID foi editada: confira se a ANIM_FLIP_ID (virado para trás) precisa do mesmo ajuste.", "⚠ Only ANIM_ID was edited: check whether ANIM_FLIP_ID (facing backward) needs the same adjustment.", "⚠ Solo se editó la ANIM_ID: revisa si la ANIM_FLIP_ID (mirando hacia atrás) necesita el mismo ajuste."},
    };
}
