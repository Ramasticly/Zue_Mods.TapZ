package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 5 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog5 {
    private I18nCatalog5() { }

    static final String[][] E = {
        {"{0} criado em Download/. Não achei app para compartilhar: {1}", "{0} created in Download/. I could not find an app to share with: {1}", "{0} creado en Download/. No encontré una app para compartir: {1}"},
        {"Não foi possível criar o {0} em Download/: {1}\n\nConfira se o app tem \"Acesso a todos os arquivos\" (Configurações do Android > Apps > Attack Editor > Permissões).", "Could not create {0} in Download/: {1}\n\nCheck that the app has \"All files access\" (Android Settings > Apps > Attack Editor > Permissions).", "No se pudo crear {0} en Download/: {1}\n\nRevisa que la app tenga \"Acceso a todos los archivos\" (Ajustes de Android > Apps > Attack Editor > Permisos)."},
        {"Recarregar as pastas?", "Reload the folders?", "¿Recargar las carpetas?"},
        {"Relê os personagens, efeitos, cenas e sons de assets, sem reiniciar o app. Edições não salvas serão perdidas.", "Rereads the characters, effects, scenes and sounds from assets, without restarting the app. Unsaved edits will be lost.", "Vuelve a leer los personajes, efectos, escenas y sonidos de assets, sin reiniciar la app. Las ediciones no guardadas se perderán."},
        {"RECARREGAR", "RELOAD", "RECARGAR"},
        {"A pasta {0} não existe mais; abrindo {1}", "The folder {0} no longer exists; opening {1}", "La carpeta {0} ya no existe; abriendo {1}"},
        {"Pastas recarregadas: {0} personagens", "Folders reloaded: {0} characters", "Carpetas recargadas: {0} personajes"},
        {"vel", "spd", "vel"},
        {"acel", "accel", "acel"},
    };
}
