package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 5 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog5 {
    private I18nCatalog5() { }

    static final String[][] E = {
        {"{0} criado em Download/. Não achei app para compartilhar: {1}", "{0} created in Download/. I could not find an app to share with: {1}", "{0} creado en Download/. No encontré una app para compartir: {1}"},
        {"Não foi possível criar o {0} em Download/: {1}\n\nConfira se o app tem \"Acesso a todos os arquivos\" (Configurações do Android > Apps > Attack Editor > Permissões).", "Could not create {0} in Download/: {1}\n\nCheck that the app has \"All files access\" (Android Settings > Apps > Attack Editor > Permissions).", "No se pudo crear {0} en Download/: {1}\n\nRevisa que la app tenga \"Acceso a todos los archivos\" (Ajustes de Android > Apps > Attack Editor > Permisos)."},
        {"Recarregar as pastas?", "Reload the folders?", "¿Recargar las carpetas?"},
        {"Relê os personagens, efeitos, cenas e sons de assets, sem reiniciar o app. Edições não salvas serão perdidas.", "Rereads the characters, effects, scenes and sounds from assets, without restarting the app. Unsaved edits will be lost.", "Vuelve a leer los personajes, efectos, escenas y sonidos de assets, sin reiniciar la app. Las ediciones no guardadas se perderán."},
        {"RECARREGAR", "RELOAD", "RECARGAR"},
        {"A pasta {0} não existe mais; abrindo {1}", "The folder {0} no longer exists; opening {1}", "La carpeta {0} ya no existe; abriendo {1}"},
        {"Pastas recarregadas: {0} personagens", "Folders reloaded: {0} characters", "Carpetas recargadas: {0} personajes"},
        {"vel", "spd", "vel"},
        {"acel", "accel", "acel"},
        {"Velocidade X", "Speed X", "Velocidad X"},
        {"Velocidade Y", "Speed Y", "Velocidad Y"},
        {"+ velocidade X", "+ speed X", "+ velocidad X"},
        {"+ velocidade Y", "+ speed Y", "+ velocidad Y"},
        {"o ponteiro esta fora de um trecho de velocidade", "the pointer is outside a speed block", "el puntero está fuera de un tramo de velocidad"},
        {"o ponteiro esta no inicio do trecho de velocidade: mova o ponteiro para dentro dele", "the pointer is at the start of the speed block: move the pointer inside it", "el puntero está al inicio del tramo de velocidad: muévelo hacia dentro"},
        {"nao da para dividir a velocidade aqui", "cannot split the speed here", "no se puede dividir la velocidad aquí"},
        {"o ponteiro esta fora do objeto", "the pointer is outside the object", "el puntero está fuera del objeto"},
        {"o ponteiro esta no inicio do objeto: mova o ponteiro para dentro dele", "the pointer is at the start of the object: move the pointer inside it", "el puntero está al inicio del objeto: muévelo hacia dentro"},
        {"esta acao dispara uma vez por frame: divida na divisa de um frame", "this action fires once per frame: split at a frame boundary", "esta acción se dispara una vez por frame: divide en el límite de un frame"},
    };
}
