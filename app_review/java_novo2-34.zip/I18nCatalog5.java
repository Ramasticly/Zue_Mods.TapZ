package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 5 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog5 {
    private I18nCatalog5() { }

    static final String[][] E = {
        {"{0} criado em Download/. Não achei app para compartilhar: {1}", "{0} created in Download/. I could not find an app to share with: {1}", "{0} creado en Download/. No encontré una app para compartir: {1}"},
        {"Não foi possível criar o {0} em Download/: {1}\n\nConfira se o app tem \"Acesso a todos os arquivos\" (Configurações do Android > Apps > Attack Editor > Permissões).", "Could not create {0} in Download/: {1}\n\nCheck that the app has \"All files access\" (Android Settings > Apps > Attack Editor > Permissions).", "No se pudo crear {0} en Download/: {1}\n\nRevisa que la app tenga \"Acceso a todos los archivos\" (Ajustes de Android > Apps > Attack Editor > Permisos)."},
        {"Recarregar as pastas?", "Reload the folders?", "¿Recargar las carpetas?"},
        {"Relê os personagens, efeitos, cenas e sons de assets, sem reiniciar o app. Edições não salvas serão perdidas.", "Rereads the characters, effects, scenes and sounds from assets, without restarting the app. Unsaved edits will be lost.", "Vuelve a leer los personajes, efectos, escenas y sonidos de assets, sin reiniciar la app. Las ediciones no guardadas se perderán."},
        {"RECARREGAR", "RELOAD", "RECARGAR"},
        {"A pasta {0} não existe mais; abrindo {1}", "The folder {0} no longer exists; opening {1}", "La carpeta {0} ya no existe; abriendo {1}"},
        {"Pastas recarregadas: {0} personagens", "Folders reloaded: {0} characters", "Carpetas recargadas: {0} personajes"},
        {"vel", "spd", "vel"},
        {"acel", "accel", "acel"},
        {"Velocidade X", "Speed X", "Velocidad X"},
        {"Velocidade Y", "Speed Y", "Velocidad Y"},
        {"+ velocidade X", "+ speed X", "+ velocidad X"},
        {"+ velocidade Y", "+ speed Y", "+ velocidad Y"},
        {"o ponteiro esta fora de um trecho de velocidade", "the pointer is outside a speed block", "el puntero está fuera de un tramo de velocidad"},
        {"o ponteiro esta no inicio do trecho de velocidade: mova o ponteiro para dentro dele", "the pointer is at the start of the speed block: move the pointer inside it", "el puntero está al inicio del tramo de velocidad: muévelo hacia dentro"},
        {"nao da para dividir a velocidade aqui", "cannot split the speed here", "no se puede dividir la velocidad aquí"},
        {"o ponteiro esta fora do objeto", "the pointer is outside the object", "el puntero está fuera del objeto"},
        {"o ponteiro esta no inicio do objeto: mova o ponteiro para dentro dele", "the pointer is at the start of the object: move the pointer inside it", "el puntero está al inicio del objeto: muévelo hacia dentro"},
        {"esta acao dispara uma vez por frame: divida na divisa de um frame", "this action fires once per frame: split at a frame boundary", "esta acción se dispara una vez por frame: divide en el límite de un frame"},
        {"AGARRAR", "GRAB", "AGARRAR"},
        {"TENTAR AGARRAO", "TRY GRAB", "INTENTAR AGARRE"},
        {"Distância do agarrão (px)", "Grab distance (px)", "Distancia del agarre (px)"},
        {"Agarrão (flag 8 ou 128 do GOLPE SET): no fim do ANO inicial — ou no 1º frame com a janela 512 (\"Tentar agarrão\") — o atacante vai para o lado do oponente e segue para o ANO {0} (ANIM_INICIAL + 1). A distância vem do HDAT 3 do personagem e vale para todos os golpes dele.", "Grab (flag 8 or 128 of MOVE SET): at the end of the initial ANO — or at the first frame with the 512 window (\"Try grab\") — the attacker goes next to the opponent and continues to ANO {0} (ANIM_INICIAL + 1). The distance comes from the character's HDAT 3 and applies to all of its moves.", "Agarre (flag 8 o 128 del GOLPE SET): al final del ANO inicial — o en el primer frame con la ventana 512 (\"Intentar agarre\") — el atacante va al lado del oponente y sigue al ANO {0} (ANIM_INICIAL + 1). La distancia viene del HDAT 3 del personaje y vale para todos sus golpes."},
        {"✎ EDITAR ANO {0}", "✎ EDIT ANO {0}", "✎ EDITAR ANO {0}"},
        {"Aplicar a todas as Hurtboxes (neste ANO)", "Apply to all Hurtboxes (in this ANO)", "Aplicar a todas las Hurtboxes (en este ANO)"},
        {"Aplicar a todas as Hurtboxes (todos os ANOs)", "Apply to all Hurtboxes (all ANOs)", "Aplicar a todas las Hurtboxes (todos los ANOs)"},
        {"Copia a posição e o tamanho desta hurtbox para todas as outras hurtboxes do ANO (ou de todos os ANOs do personagem). Desfazer volta tudo de uma vez.", "Copies this hurtbox's position and size to all the other hurtboxes of the ANO (or of all the character's ANOs). Undo reverts everything at once.", "Copia la posición y el tamaño de esta hurtbox a todas las demás hurtboxes del ANO (o de todos los ANOs del personaje). Deshacer revierte todo de una vez."},
        {"Todas as hurtboxes deste ANO ja estao assim", "All hurtboxes of this ANO are already like this", "Todas las hurtboxes de este ANO ya están así"},
        {"Todas as hurtboxes de todos os ANOs ja estao assim", "All hurtboxes of all ANOs are already like this", "Todas las hurtboxes de todos los ANOs ya están así"},
        {"{0} frame(s) alterado(s) neste ANO", "{0} frame(s) changed in this ANO", "{0} frame(s) cambiado(s) en este ANO"},
        {"Aplicar a todos os ANOs?", "Apply to all ANOs?", "¿Aplicar a todos los ANOs?"},
        {"A posição e o tamanho desta hurtbox vão para as hurtboxes de {0} frame(s) em {1} ANO(s). Desfazer volta tudo de uma vez. Depois use SALVAR > todos os ANOs (ou tudo) para gravar.", "This hurtbox's position and size go to the hurtboxes of {0} frame(s) in {1} ANO(s). Undo reverts everything at once. Then use SAVE > all ANOs (or everything) to write them.", "La posición y el tamaño de esta hurtbox van a las hurtboxes de {0} frame(s) en {1} ANO(s). Deshacer revierte todo de una vez. Después usa GUARDAR > todos los ANOs (o todo) para grabar."},
    };
}
