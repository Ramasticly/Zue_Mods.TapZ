package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 6 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog6 {
    private I18nCatalog6() { }

    static final String[][] E = {
        {", reduzida", ", reduced", ", reducida"},
        {", sem perda", ", lossless", ", sin pérdida"},
        {": erro ", ": error ", ": error "},
        {": já é pequena (", ": already small (", ": ya es pequeña ("},
        {": não consegui ler\n", ": could not read it\n", ": no pude leerla\n"},
        {"Analisando sprites", "Analyzing sprites", "Analizando sprites"},
        {"As sprites seguintes foram renumeradas.\n", "The following sprites were renumbered.\n", "Los sprites siguientes fueron renumerados.\n"},
        {"Converte as ", "Converts the ", "Convierte las "},
        {"Erro ao remover sprites repetidas: ", "Error removing repeated sprites: ", "Error al quitar sprites repetidos: "},
        {"Ficaram (algum frame não tem como ficar igual): SPR_", "Kept (some frame cannot look the same): SPR_", "Se quedaron (algún frame no puede quedar igual): SPR_"},
        {"Folhas com mais de 256 cores perdem um pouco de cor.\n\nAntes de gravar, os PNG originais são copiados para\nBackups/PreOptim/", "Sheets with more than 256 colors lose a little color.\n\nBefore writing, the original PNGs are copied to\nBackups/PreOptim/", "Las hojas con más de 256 colores pierden un poco de color.\n\nAntes de grabar, los PNG originales se copian en\nBackups/PreOptim/"},
        {"Lendo sprites", "Reading sprites", "Leyendo sprites"},
        {"Nenhum grupo de sprites repetidas com esta semelhança.", "No group of repeated sprites with this similarity.", "Ningún grupo de sprites repetidos con esta semejanza."},
        {"Nenhuma folha PNG nesta pasta", "No PNG sheet in this folder", "Ninguna hoja PNG en esta carpeta"},
        {"Otimizando PNGs", "Optimizing PNGs", "Optimizando PNG"},
        {"Otimizar", "Optimize", "Optimizar"},
        {"Otimizar PNGs", "Optimize PNGs", "Optimizar PNG"},
        {"Otimizar PNGs (8 bits)", "Optimize PNGs (8 bits)", "Optimizar PNG (8 bits)"},
        {"PNGs otimizados", "PNGs optimized", "PNG optimizados"},
        {"Precisa ficar ao menos uma sprite em cada grupo", "At least one sprite must stay in each group", "Debe quedar al menos un sprite en cada grupo"},
        {"REMOVER MARCADAS", "REMOVE MARKED", "QUITAR MARCADAS"},
        {"Reescrevendo os frames...", "Rewriting the frames...", "Reescribiendo los frames..."},
        {"Removendo sprites repetidas", "Removing repeated sprites", "Quitando sprites repetidos"},
        {"Remover Sprites repetidas", "Remove repeated Sprites", "Quitar Sprites repetidos"},
        {"Sprites iguais ou parecidas (também espelhadas, giradas 90° ou em outra escala) formam um grupo. Marque as que quer REMOVER: os frames do DAC ", "Equal or similar sprites (also mirrored, rotated 90° or at another scale) form a group. Mark the ones you want to REMOVE: the DAC frames ", "Los sprites iguales o parecidos (también reflejados, girados 90° o en otra escala) forman un grupo. Marca los que quieres QUITAR: los frames del DAC "},
        {"passam a usar a que fica, com Flip, zoom, rotação e posição ajustados para o desenho ficar igual. Em cada grupo precisa ficar ao menos uma.", "start using the one that stays, with Flip, zoom, rotation and position adjusted so the drawing looks the same. At least one must stay in each group.", "pasan a usar el que se queda, con Flip, zoom, rotación y posición ajustados para que el dibujo quede igual. En cada grupo debe quedar al menos uno."},
        {"Sprites repetidas", "Repeated sprites", "Sprites repetidos"},
        {"a maior do grupo", "the largest in the group", "la mayor del grupo"},
        {"conferência falhou (tamanho)", "check failed (size)", "la comprobación falló (tamaño)"},
        {"espelhada na horizontal (Flip X)", "mirrored horizontally (Flip X)", "reflejada en horizontal (Flip X)"},
        {"espelhada na vertical (Flip Y)", "mirrored vertically (Flip Y)", "reflejada en vertical (Flip Y)"},
        {"girada 180°", "rotated 180°", "girada 180°"},
        {"girada 90° (ou espelhada na diagonal)", "rotated 90° (or mirrored on the diagonal)", "girada 90° (o reflejada en la diagonal)"},
        {"igual (ou só em outra escala)", "equal (or only at another scale)", "igual (o solo en otra escala)"},
    };
}
