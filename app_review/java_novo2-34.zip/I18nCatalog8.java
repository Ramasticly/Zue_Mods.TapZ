package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 8 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog8 {
    private I18nCatalog8() { }

    static final String[][] E = {
        {"Antes é feita uma cópia de segurança do DAC, do CNV e dos grupos de GIF.", "Before that, a backup of the DAC, the CNV and the GIF groups is made.", "Antes se hace una copia de seguridad del DAC, del CNV y de los grupos de GIF."},
        {"SIM, REMOVER", "YES, REMOVE", "SÍ, QUITAR"},
        {"Comparar · SPR_", "Compare · SPR_", "Comparar · SPR_"},
        {" (será removida)", " (will be removed)", " (se quitará)"},
        {" (fica)", " (stays)", " (se queda)"},
        {"nenhuma sprite que fica serve no lugar", "no sprite that stays works in its place", "ningún sprite que se queda sirve en su lugar"},
        {" (fica, ajustada)", " (stays, adjusted)", " (se queda, ajustada)"},
        {"Forma (silhueta)", "Shape (silhouette)", "Forma (silueta)"},
        {"Cor dos pixels", "Pixel color", "Color de los píxeles"},
        {"Detalhes (bordas internas)", "Details (inner edges)", "Detalles (bordes internos)"},
        {"Paleta de cores", "Color palette", "Paleta de colores"},
        {"Achatamento máximo", "Maximum flattening", "Aplastamiento máximo"},
        {"Ampliação máxima da que fica", "Maximum enlargement of the one that stays", "Ampliación máxima del que se queda"},
        {"Aceitar espelhadas", "Accept mirrored", "Aceptar espejados"},
        {"Aceitar giradas 90° / 180°", "Accept rotated 90° / 180°", "Aceptar girados 90° / 180°"},
        {"Aceitar giradas em qualquer ângulo", "Accept rotated by any angle", "Aceptar girados en cualquier ángulo"},
        {"Agrupar em cadeia", "Group in a chain", "Agrupar en cadena"},
        {"Quanto do contorno coincide depois de ajustar escala, rotação e posição. Evita juntar imagens com partes a mais ou a menos.", "How much of the outline matches after adjusting scale, rotation and position. Avoids joining images with extra or missing parts.", "Cuánto del contorno coincide tras ajustar escala, rotación y posición. Evita juntar imágenes con partes de más o de menos."},
        {"Quanto da área comum (sem a borda) tem a mesma cor. Pega regiões recoloridas.", "How much of the common area (without the edge) has the same color. Catches recolored regions.", "Cuánto del área común (sin el borde) tiene el mismo color. Detecta regiones recoloreadas."},
        {"Compara as linhas e contornos dentro da imagem.", "Compares the lines and outlines inside the image.", "Compara las líneas y contornos dentro de la imagen."},
        {"Compara a mistura geral de cores das duas.", "Compares the overall mix of colors of the two.", "Compara la mezcla general de colores de los dos."},
        {"Maior diferença aceita entre o zoom X e o zoom Y (4,0× = a cópia pode ficar 4 vezes mais baixa que larga).", "Largest difference accepted between zoom X and zoom Y (4.0× = the copy can be 4 times lower than wide).", "Mayor diferencia aceptada entre el zoom X y el zoom Y (4,0× = la copia puede quedar 4 veces más baja que ancha)."},
        {"Recusa quando a sprite que fica precisa ser ampliada acima disto (perde qualidade). Desligado aceita qualquer ampliação.", "Refuses when the sprite that stays must be enlarged above this (loses quality). Off accepts any enlargement.", "Rechaza cuando el sprite que se queda debe ampliarse por encima de esto (pierde calidad). Desactivado acepta cualquier ampliación."},
        {"Cópias com Flip X ou Flip Y.", "Copies with Flip X or Flip Y.", "Copias con Flip X o Flip Y."},
        {"Cópias giradas de 90° ou 180°.", "Copies rotated by 90° or 180°.", "Copias giradas 90° o 180°."},
        {"Cópias giradas em qualquer ângulo (aproximado). O valor é a nota mínima das células.", "Copies rotated by any angle (approximate). The value is the minimum cell score.", "Copias giradas en cualquier ángulo (aproximado). El valor es la nota mínima de las celdas."},
        {"Ligado: uma sprite entra no grupo se casar com qualquer membro, mesmo sem casar com a maior (pode juntar imagens diferentes). Desligado: todas precisam casar com a maior.", "On: a sprite joins the group if it matches any member, even without matching the largest (it can join different images). Off: all must match the largest.", "Activado: un sprite entra en el grupo si coincide con cualquier miembro, aunque no coincida con el mayor (puede juntar imágenes distintas). Desactivado: todos deben coincidir con el mayor."},
        {"Critérios de detecção", "Detection criteria", "Criterios de detección"},
        {"Cada critério pode ser ligado ou desligado e ter a sua tolerância. Uma sprite só entra no grupo se passar em todos os ligados. ", "Each criterion can be switched on or off and has its own tolerance. A sprite only joins a group if it passes all the ones that are on. ", "Cada criterio se puede activar o desactivar y tiene su tolerancia. Un sprite solo entra en el grupo si pasa todos los activados. "},
        {"A barra \"Semelhança mínima\" continua valendo para a nota geral das células.", "The \"Minimum similarity\" bar still applies to the overall cell score.", "La barra \"Semejanza mínima\" sigue valiendo para la nota general de las celdas."},
        {"REDEFINIR", "RESET", "REDEFINIR"},
        {"Comparando sprites", "Comparing sprites", "Comparando sprites"},
        {"Conferindo pixels", "Checking pixels", "Comprobando píxeles"},
    };
}
