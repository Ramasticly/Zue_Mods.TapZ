package com.zue.attackeditor;

/** Catalogo de traducao da interface, bloco 9 (gerado de i18n_src/*.py; nao editar a mao). */
final class I18nCatalog9 {
    private I18nCatalog9() { }

    static final String[][] E = {
        {"POSIÇÃO (MID)", "POSITION (MID)", "POSICIÓN (MID)"},
        {"Vale para todos os Frames adicionados agora, e só para eles. O time é o do rodapé da lista.", "Applies to all the Frames added now, and only to them. The time is the one at the bottom of the list.", "Vale para todos los Frames agregados ahora, y solo para ellos. El time es el del pie de la lista."},
        {"CENTRAR", "CENTER", "CENTRAR"},
        {"DEFINIR", "DEFINE", "DEFINIR"},
        {"REESCALAR", "RESCALE", "REESCALAR"},
        {"Adicionar sprites — toque para marcar (1, 2, 3… = ordem) — ", "Add sprites — tap to mark (1, 2, 3… = order) — ", "Agregar sprites — toca para marcar (1, 2, 3… = orden) — "},
        {"CENTRAR: põe a sprite centrada (pés no chão), sem mudar o tamanho (usa o zoom do padrão).", "CENTER: places the sprite centered (feet on the ground) without changing its size (uses the default zoom).", "CENTRAR: pone el sprite centrado (pies en el suelo) sin cambiar el tamaño (usa el zoom del estándar)."},
        {"DEFINIR: você escolhe posição, RAZ, Hitbox e Hurtbox, só para os Frames adicionados.", "DEFINE: you choose position, RAZ, Hitbox and Hurtbox, only for the Frames added.", "DEFINIR: tú eliges posición, RAZ, Hitbox y Hurtbox, solo para los Frames agregados."},
        {"DEFINIR…", "DEFINE…", "DEFINIR…"},
        {"MODO: ", "MODE: ", "MODO: "},
        {"PADRÃO: usa o padrão do Editar Frame de cada sprite.", "DEFAULT: uses each sprite's Edit Frame default.", "ESTÁNDAR: usa el estándar de Editar Frame de cada sprite."},
        {"REESCALAR: muda o zoom para a altura da 1ª sprite do Parado e centra.", "RESCALE: changes the zoom to the height of the first Idle sprite and centers.", "REESCALAR: cambia el zoom a la altura del 1.er sprite del Parado y centra."},
        {"sem a 1a sprite do Parado (ANO 0): usei CENTRAR, sem mudar o tamanho", "no first Idle sprite (ANO 0): used CENTER, without changing the size", "sin el 1.er sprite del Parado (ANO 0): usé CENTRAR, sin cambiar el tamaño"},
        {"Este Frame não tem sprite com desenho.", "This Frame has no sprite with a drawing.", "Este Frame no tiene sprite con dibujo."},
        {"Faz só neste Frame o que o REESCALAR da lista de Sprites faz: muda o zoom para a altura da 1ª sprite do Parado (ANO 0, frame 1) e põe o MID com os pés no chão, ", "Does only in this Frame what RESCALE in the Sprites list does: changes the zoom to the height of the first Idle sprite (ANO 0, frame 1) and puts the MID with the feet on the ground, ", "Hace solo en este Frame lo que hace REESCALAR en la lista de Sprites: cambia el zoom a la altura del 1.er sprite del Parado (ANO 0, frame 1) y pone el MID con los pies en el suelo, "},
        {"centrada. Rotação, alpha e flips ficam. Não muda o padrão da sprite nem os outros Frames.", "centered. Rotation, alpha and flips stay. It does not change the sprite default or the other Frames.", "centrado. Rotación, alfa y flips se mantienen. No cambia el estándar del sprite ni los otros Frames."},
        {"REESCALAR ESTE FRAME", "RESCALE THIS FRAME", "REESCALAR ESTE FRAME"},
        {"Frame reescalado (zoom ", "Frame rescaled (zoom ", "Frame reescalado (zoom "},
    };
}
