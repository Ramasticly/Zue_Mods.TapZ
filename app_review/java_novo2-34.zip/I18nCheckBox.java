package com.zue.attackeditor;

import android.content.Context;
import android.text.Spanned;
import android.widget.CheckBox;

/** CheckBox que traduz o rotulo (ver {@link I18nTextView}). */
class I18nCheckBox extends CheckBox {
    private CharSequence src;

    I18nCheckBox(Context c) { super(c); }

    private CharSequence tr(CharSequence t) {
        if (t == null || t instanceof Spanned || I18n.lang() == I18n.PT) return t;
        return I18n.tr(t.toString());
    }

    @Override public void setText(CharSequence text, BufferType type) {
        src = text;
        super.setText(tr(text), type);
    }

    @Override public CharSequence getText() { return src != null && !(src instanceof Spanned) ? src : super.getText(); }

    void retranslate() {
        if (src != null && !(src instanceof Spanned)) super.setText(tr(src), BufferType.NORMAL);
    }
}
