package com.zue.attackeditor;

import android.content.Context;
import android.widget.EditText;

/** EditText cujo texto digitado nunca e traduzido (dicas: use {@code setHint(I18n.tr(...))}). */
class I18nEditText extends EditText {
    I18nEditText(Context c) { super(c); }
}
