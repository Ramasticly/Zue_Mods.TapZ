package com.zue.attackeditor;

/** Catalogo dos textos da AJUDA: blocos de entradas {pt, en, es}. */
final class I18nHelpCatalog {
    private I18nHelpCatalog() { }

    static String[][][] blocks() {
        return new String[][][] { I18nHelpCatalog0.E, I18nHelpCatalog1.E, I18nHelpCatalog2.E, I18nHelpCatalog3.E, I18nHelpCatalog4.E, I18nHelpCatalog5.E, I18nHelpCatalog6.E, I18nHelpCatalog7.E, I18nHelpCatalog8.E };
    }
}
