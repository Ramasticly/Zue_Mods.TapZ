package com.zue.attackeditor;

/** Textos da AJUDA em EN/ES, bloco 9 (gerado de i18n_src/h00*.py; nao editar a mao). So busca exata, nao entra nos fragmentos. */
final class I18nHelpCatalog9 {
    private I18nHelpCatalog9() { }

    static final String[][] E = {
        {"Limites do jogo",
         "Game limits",
         "Límites del juego"},
        {"Por ANO: no máximo 255 frames, 13 links e tempo de 255 ticks por frame (campo de 1 byte). Por frame: no máximo 10 caixas (hitboxes, hurtboxes e flags de ação; o jogo guarda 50 números, 5 por caixa). OPT 1 de reação com hitbox precisa apontar para um grupo que exista. Interpolação (rotação/alpha/zoom) lê o frame seguinte e pode dar valores errados se o seguinte tem mais caixas. Imagem que não existe no CNV deixa o frame sem desenho. Os campos do HDAT 4 aceitam números de 16 bits; as tabelas de reação usam 1 byte por campo (ANO −127 a 127, voz 0 a 127).",
         "Per ANO: at most 255 frames, 13 links and 255 ticks of time per frame (1-byte field). Per frame: at most 10 boxes (hitboxes, hurtboxes and action flags; the game stores 50 numbers, 5 per box). A reaction OPT 1 with a hitbox must point to a group that exists. Interpolation (rotation/alpha/zoom) reads the next frame and can give wrong values if the next one has more boxes. An image that does not exist in the CNV leaves the frame with no drawing. The HDAT 4 fields accept 16-bit numbers; the reaction tables use 1 byte per field (ANO −127 to 127, voice 0 to 127).",
         "Por ANO: como máximo 255 frames, 13 links y tiempo de 255 ticks por frame (campo de 1 byte). Por frame: como máximo 10 cajas (hitboxes, hurtboxes y flags de acción; el juego guarda 50 números, 5 por caja). El OPT 1 de reacción con hitbox debe apuntar a un grupo que exista. La interpolación (rotación/alpha/zoom) lee el frame siguiente y puede dar valores incorrectos si el siguiente tiene más cajas. Una imagen que no existe en el CNV deja el frame sin dibujo. Los campos del HDAT 4 aceptan números de 16 bits; las tablas de reacción usan 1 byte por campo (ANO −127 a 127, voz 0 a 127)."},
    };
}
