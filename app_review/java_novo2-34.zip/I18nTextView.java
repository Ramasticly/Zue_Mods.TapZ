package com.zue.attackeditor;

import android.content.Context;
import android.text.Spanned;
import android.widget.TextView;

/**
 * TextView que traduz o que o app escreve nele ({@link I18n#tr}). Guarda o texto original (em portugues) para retraduzir ao trocar o idioma
 * e para que {@code getText()} continue devolvendo o original (a logica do app nao enxerga a traducao). Textos com spans nao sao traduzidos.
 */
class I18nTextView extends TextView {
    private CharSequence src;
    private boolean noTr;

    I18nTextView(Context c) { super(c); }

    /** Desliga a traducao deste campo (dados, texto do usuario, nomes). */
    I18nTextView noTranslate() {
        noTr = true;
        return this;
    }

    private CharSequence tr(CharSequence t) {
        if (noTr || t == null || t instanceof Spanned || I18n.lang() == I18n.PT) return t;
        return I18n.tr(t.toString());
    }

    @Override public void setText(CharSequence text, BufferType type) {
        src = text;
        super.setText(tr(text), type);
    }

    @Override public CharSequence getText() {
        return src != null && !noTr && !(src instanceof Spanned) ? src : super.getText();
    }

    /** Reaplica o idioma atual ao texto e a dica. */
    void retranslate() {
        if (noTr) return;
        if (src != null && !(src instanceof Spanned)) super.setText(tr(src), BufferType.NORMAL);
    }
}
