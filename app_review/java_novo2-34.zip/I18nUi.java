package com.zue.attackeditor;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

/** Parte Android do idioma: preferencia salva, toasts traduzidos e retraducao das telas abertas. */
final class I18nUi {
    private I18nUi() { }

    private static final String PREFS = "lang", KEY = "code";

    /** Carrega o idioma salvo (chamar antes de montar a interface). */
    static void init(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            I18n.set(I18n.fromCode(p.getString(KEY, "PT")));
        } catch (Exception ignored) { }
    }

    static void save(Context c) {
        try { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, I18n.code()).apply(); } catch (Exception ignored) { }
    }

    private static final java.util.Map<TextView, Boolean> LANG_LABELS = new java.util.WeakHashMap<TextView, Boolean>();

    /** Registra um botao de idioma: o rotulo (PT/EN/ES) acompanha a troca, de onde ela vier. */
    static void registerLang(TextView t) {
        if (t instanceof I18nTextView) ((I18nTextView) t).noTranslate();
        t.setText(I18n.code());
        LANG_LABELS.put(t, Boolean.TRUE);
    }

    /** Proximo idioma (PT, EN, ES): grava a escolha, atualiza os botoes de idioma e retraduz a tela da activity. */
    static void cycle(Context c) {
        I18n.next();
        save(c);
        for (TextView t : new java.util.ArrayList<TextView>(LANG_LABELS.keySet())) t.setText(I18n.code());
        if (c instanceof Activity) retranslate((Activity) c);
    }

    /** Substitui Toast.makeText: o texto passa por {@link I18n#tr}. */
    static Toast toast(Context c, CharSequence text, int duration) {
        return Toast.makeText(c, text == null || I18n.lang() == I18n.PT ? text : I18n.tr(text.toString()), duration);
    }

    /** Substitui Canvas.drawText nos desenhos proprios: o texto passa por {@link I18n#tr}. */
    static void drawText(android.graphics.Canvas c, String text, float x, float y, android.graphics.Paint p) {
        c.drawText(I18n.lang() == I18n.PT || text == null ? text : I18n.tr(text), x, y, p);
    }

    /** Reaplica o idioma atual a todos os textos da arvore de views. */
    static void retranslate(View v) {
        if (v == null) return;
        v.invalidate();         // views desenhadas a mao (timelines, previas) repintam com o idioma novo
        if (v instanceof I18nTextView) ((I18nTextView) v).retranslate();
        else if (v instanceof I18nCheckBox) ((I18nCheckBox) v).retranslate();
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) retranslate(g.getChildAt(i));
        }
    }

    static void retranslate(Activity a) { retranslate(a.getWindow().getDecorView()); }
}
