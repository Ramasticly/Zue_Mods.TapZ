package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Icones simples da grade da sprite, desenhados em Canvas (sem imagens): imagem, relogio, alto-falante, setas, brilho, copia. */
final class IconView extends View {
    static final int IMAGE = 0, CLOCK = 1, SOUND = 2, MOVE = 3, FX = 4, COPY = 5;

    private final int kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();

    IconView(Context c, int kind, int color) {
        super(c);
        this.kind = kind;
        p.setColor(color);
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), s = Math.min(w, h), u = s / 10f;
        float ox = (w - s) / 2f, oy = (h - s) / 2f;
        cv.translate(ox, oy);
        p.setStrokeWidth(u * 0.8f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        switch (kind) {
            case IMAGE:
                p.setStyle(Paint.Style.STROKE);
                r.set(1 * u, 1.5f * u, 9 * u, 8.5f * u);
                cv.drawRoundRect(r, u, u, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(3.4f * u, 4f * u, 0.9f * u, p);
                path.reset();
                path.moveTo(1.8f * u, 8f * u); path.lineTo(4.5f * u, 5.2f * u); path.lineTo(6.2f * u, 7f * u);
                path.lineTo(7.2f * u, 6f * u); path.lineTo(8.4f * u, 8f * u); path.close();
                cv.drawPath(path, p);
                break;
            case CLOCK:
                p.setStyle(Paint.Style.STROKE);
                cv.drawCircle(5 * u, 5 * u, 4 * u, p);
                cv.drawLine(5 * u, 5 * u, 5 * u, 2.6f * u, p);
                cv.drawLine(5 * u, 5 * u, 6.8f * u, 5.9f * u, p);
                break;
            case SOUND:
                p.setStyle(Paint.Style.FILL);
                path.reset();
                path.moveTo(1 * u, 3.8f * u); path.lineTo(3.2f * u, 3.8f * u); path.lineTo(5.6f * u, 1.6f * u);
                path.lineTo(5.6f * u, 8.4f * u); path.lineTo(3.2f * u, 6.2f * u); path.lineTo(1 * u, 6.2f * u); path.close();
                cv.drawPath(path, p);
                p.setStyle(Paint.Style.STROKE);
                r.set(4.4f * u, 3.2f * u, 7.4f * u, 6.8f * u);
                cv.drawArc(r, -50, 100, false, p);
                r.set(3.6f * u, 1.8f * u, 8.8f * u, 8.2f * u);
                cv.drawArc(r, -50, 100, false, p);
                break;
            case MOVE:
                p.setStyle(Paint.Style.STROKE);
                cv.drawLine(1 * u, 5 * u, 9 * u, 5 * u, p);
                cv.drawLine(5 * u, 1 * u, 5 * u, 9 * u, p);
                arrow(cv, 9 * u, 5 * u, -1, 0, u);
                arrow(cv, 1 * u, 5 * u, 1, 0, u);
                arrow(cv, 5 * u, 1 * u, 0, 1, u);
                arrow(cv, 5 * u, 9 * u, 0, -1, u);
                break;
            case FX:
                p.setStyle(Paint.Style.FILL);
                star(cv, 4.2f * u, 5.8f * u, 3.6f * u, u);
                star(cv, 7.8f * u, 2.6f * u, 1.7f * u, u);
                break;
            default:
                p.setStyle(Paint.Style.STROKE);
                r.set(1 * u, 3 * u, 6.2f * u, 9 * u);
                cv.drawRoundRect(r, u * 0.8f, u * 0.8f, p);
                r.set(3.8f * u, 1 * u, 9 * u, 7 * u);
                cv.drawRoundRect(r, u * 0.8f, u * 0.8f, p);
                break;
        }
    }

    /** Ponta de seta em (x, y) apontando para o lado oposto de (dx, dy). */
    private void arrow(Canvas cv, float x, float y, int dx, int dy, float u) {
        float k = 1.5f * u;
        cv.drawLine(x, y, x + dx * k + dy * k, y + dy * k + dx * k, p);
        cv.drawLine(x, y, x + dx * k - dy * k, y + dy * k - dx * k, p);
    }

    private void star(Canvas cv, float cx, float cy, float R, float u) {
        float in = R * 0.28f;
        path.reset();
        path.moveTo(cx, cy - R); path.lineTo(cx + in, cy - in); path.lineTo(cx + R, cy); path.lineTo(cx + in, cy + in);
        path.lineTo(cx, cy + R); path.lineTo(cx - in, cy + in); path.lineTo(cx - R, cy); path.lineTo(cx - in, cy - in); path.close();
        cv.drawPath(path, p);
    }
}
