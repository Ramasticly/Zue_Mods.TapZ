package com.zue.attackeditor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.CRC32;

/**
 * Abre qualquer imagem aceita pela lista de sprites e entrega como bitmaps prontos para virar PNG:
 * PNG entra como esta; JPG/BMP/WebP/etc. sao convertidos (com aviso); GIF, WebP e APNG animados viram um bitmap por quadro.
 */
final class ImageImport {
    private ImageImport() { }

    static final int MAX_FRAMES = 200;
    private static final long MAX_BYTES = 150L << 20;
    private static boolean truncated;

    /** Progresso da leitura (chamado na thread que esta lendo; total = 0 quando ainda nao se sabe). */
    interface Prog { void on(String what, int done, int total); }
    static volatile Prog prog;

    static void report(String what, int done, int total) {
        Prog p = prog;
        if (p != null) p.on(what, done, total);
    }
    private static final ArrayList<Integer> lastDelays = new ArrayList<Integer>();

    private static boolean full(int frames, int w, int h) {
        if ((long) frames * w * h * 4 > MAX_BYTES) { truncated = true; return true; }
        return false;
    }

    static final class Loaded {
        File file;
        String kind;                 // PNG, JPG, GIF, ...
        final List<Bitmap> frames = new ArrayList<Bitmap>();
        int[] delays;                // atraso de cada quadro em ms (imagem animada)
        String notice;               // null = nada a avisar (PNG comum)
        boolean animated() { return frames.size() > 1; }
    }

    static boolean isSupportedName(String lowerName) {
        return lowerName.endsWith(".png") || lowerName.endsWith(".apng") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg")
                || lowerName.endsWith(".webp") || lowerName.endsWith(".gif") || lowerName.endsWith(".bmp")
                || lowerName.endsWith(".heic") || lowerName.endsWith(".heif") || lowerName.endsWith(".avif");
    }

    static Loaded load(File f) throws IOException {
        Loaded r = load0(f);
        r.delays = new int[r.frames.size()];
        for (int i = 0; i < r.delays.length; i++) r.delays[i] = i < lastDelays.size() ? lastDelays.get(i).intValue() : 100;
        if ((truncated || r.frames.size() >= MAX_FRAMES) && r.animated())
            r.notice = (r.notice == null ? "" : r.notice + " ") + "Limitado a " + r.frames.size() + " quadros (limite de memoria/quantidade).";
        return r;
    }

    private static Loaded load0(File f) throws IOException {
        byte[] d = GameData.readAll(f);
        Loaded r = new Loaded();
        r.file = f;
        truncated = false;
        lastDelays.clear();
        if (GifDecoder.isGif(d)) {
            r.kind = "GIF";
            GifDecoder g = GifDecoder.decode(d, MAX_FRAMES);
            composeGif(g, r.frames);
            r.notice = r.animated()
                    ? "GIF animado: " + r.frames.size() + " quadros viram " + r.frames.size() + " sprites em sequencia. Transparencia de GIF e de 1 bit (sem bordas suaves)."
                    : "GIF convertido para PNG. Transparencia de GIF e de 1 bit (sem bordas suaves).";
            return r;
        }
        if (isPng(d)) {
            List<Bitmap> ap = apng(d);
            if (ap != null && ap.size() > 1) {
                r.kind = "APNG";
                r.frames.addAll(ap);
                r.notice = "PNG animado (APNG): " + ap.size() + " quadros viram " + ap.size() + " sprites em sequencia.";
                return r;
            }
            r.kind = "PNG";
            r.frames.add(decode(d));
            return r;
        }
        if (isWebp(d)) {
            List<Bitmap> wf = animatedWebp(d);
            if (wf != null && wf.size() > 1) {
                r.kind = "WebP";
                r.frames.addAll(wf);
                r.notice = "WebP animado: " + wf.size() + " quadros viram " + wf.size() + " sprites em sequencia.";
                return r;
            }
            r.kind = "WebP";
            r.frames.add(decode(d));
            r.notice = "WebP convertido para PNG.";
            return r;
        }
        String n = f.getName().toLowerCase(Locale.US);
        if (d.length > 3 && (d[0] & 255) == 0xFF && (d[1] & 255) == 0xD8) {
            r.kind = "JPG";
            r.notice = "JPG convertido para PNG. JPG nao tem transparencia: o fundo continua como parte da imagem e a compressao pode deixar ruido nas bordas.";
        } else if (d.length > 2 && d[0] == 'B' && d[1] == 'M') {
            r.kind = "BMP";
            r.notice = "BMP convertido para PNG. BMP normalmente nao tem transparencia.";
        } else {
            r.kind = n.substring(n.lastIndexOf('.') + 1).toUpperCase(Locale.US);
            r.notice = r.kind + " convertido para PNG (se o formato nao tem transparencia, o fundo continua na imagem).";
        }
        r.frames.add(decode(d));
        return r;
    }

    private static Bitmap decode(byte[] d) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap b = BitmapFactory.decodeByteArray(d, 0, d.length, o);
        if (b == null) throw new IOException("formato nao suportado neste aparelho");
        if (b.getConfig() != Bitmap.Config.ARGB_8888) { Bitmap c = b.copy(Bitmap.Config.ARGB_8888, false); b.recycle(); b = c; }
        return b;
    }

    // ---- composicao de quadros (descarte + mistura) ----

    private static final class Comp {
        final int w, h;
        final Bitmap canvasBmp;
        final Canvas cv;
        final Paint over = new Paint(), src = new Paint(), clr = new Paint();
        Rect lastRect;
        int lastDispose;           // 0 nada, 1 fundo, 2 anterior
        Bitmap backup;

        Comp(int w, int h) {
            this.w = w; this.h = h;
            canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            cv = new Canvas(canvasBmp);
            src.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
            clr.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        }

        /** Desenha o quadro em (x,y); devolve copia do canvas inteiro. */
        Bitmap add(Bitmap frame, int x, int y, boolean blendOver, int dispose) {
            if (lastRect != null) {
                if (lastDispose == 1) cv.drawRect(lastRect, clr);
                else if (lastDispose == 2 && backup != null) { cv.drawBitmap(backup, 0, 0, src); }
            }
            if (backup != null) { backup.recycle(); backup = null; }
            if (dispose == 2) backup = canvasBmp.copy(Bitmap.Config.ARGB_8888, false);
            cv.drawBitmap(frame, x, y, blendOver ? over : src);
            lastRect = new Rect(x, y, x + frame.getWidth(), y + frame.getHeight());
            lastDispose = dispose;
            return canvasBmp.copy(Bitmap.Config.ARGB_8888, false);
        }

        void done() { if (backup != null) backup.recycle(); canvasBmp.recycle(); }
    }

    private static void composeGif(GifDecoder g, List<Bitmap> out) {
        Comp c = new Comp(g.width, g.height);
        try {
            for (GifDecoder.Frame f : g.frames) {
                if (full(out.size(), g.width, g.height)) break;
                Bitmap fb = Bitmap.createBitmap(f.argb, f.w, f.h, Bitmap.Config.ARGB_8888);
                out.add(c.add(fb, f.x, f.y, true, f.disposal == 2 ? 1 : f.disposal == 3 ? 2 : 0));
                lastDelays.add(Integer.valueOf(f.delayMs));
                fb.recycle();
                report("Montando quadros", out.size(), g.frames.size());
            }
        } finally { c.done(); }
    }

    // ---- PNG animado ----

    private static boolean isPng(byte[] d) {
        return d.length > 8 && (d[0] & 255) == 0x89 && d[1] == 'P' && d[2] == 'N' && d[3] == 'G';
    }

    private static int be32(byte[] d, int p) { return ((d[p] & 255) << 24) | ((d[p + 1] & 255) << 16) | ((d[p + 2] & 255) << 8) | (d[p + 3] & 255); }

    private static String tag(byte[] d, int p) { return new String(d, p, 4, java.nio.charset.Charset.forName("ISO-8859-1")); }

    private static void chunk(ByteArrayOutputStream o, String type, byte[] data, int off, int len) {
        byte[] hdr = new byte[8];
        hdr[0] = (byte) (len >> 24); hdr[1] = (byte) (len >> 16); hdr[2] = (byte) (len >> 8); hdr[3] = (byte) len;
        for (int i = 0; i < 4; i++) hdr[4 + i] = (byte) type.charAt(i);
        o.write(hdr, 0, 8);
        o.write(data, off, len);
        CRC32 crc = new CRC32();
        crc.update(hdr, 4, 4);
        crc.update(data, off, len);
        long v = crc.getValue();
        o.write((int) (v >> 24)); o.write((int) (v >> 16)); o.write((int) (v >> 8)); o.write((int) v);
    }

    /** Quadros de um APNG (ou null se nao for animado). */
    private static List<Bitmap> apng(byte[] d) throws IOException {
        int p = 8, W = 0, H = 0;
        boolean anim = false;
        ArrayList<int[]> fc = new ArrayList<int[]>();             // {x,y,w,h,dispose,blend}
        ArrayList<ByteArrayOutputStream> idat = new ArrayList<ByteArrayOutputStream>();
        ByteArrayOutputStream pre = new ByteArrayOutputStream();   // chunks entre IHDR e IDAT (PLTE, tRNS...)
        int cur = -1;
        boolean defaultIsFrame = false, seenIdat = false;
        byte[] ihdr = null;
        while (p + 8 <= d.length) {
            int len = be32(d, p);
            String t = tag(d, p + 4);
            int dp = p + 8;
            if (len < 0 || dp + len + 4 > d.length) break;
            if (t.equals("IHDR")) { ihdr = java.util.Arrays.copyOfRange(d, dp, dp + len); W = be32(d, dp); H = be32(d, dp + 4); }
            else if (t.equals("acTL")) anim = true;
            else if (t.equals("fcTL")) {
                int dn = ((d[dp + 20] & 255) << 8) | (d[dp + 21] & 255), dd = ((d[dp + 22] & 255) << 8) | (d[dp + 23] & 255);
                fc.add(new int[]{be32(d, dp + 12), be32(d, dp + 16), be32(d, dp + 4), be32(d, dp + 8), d[dp + 24] & 255, d[dp + 25] & 255, dd == 0 ? dn * 10 : dn * 1000 / dd});
                idat.add(new ByteArrayOutputStream());
                cur = fc.size() - 1;
                if (!seenIdat) defaultIsFrame = true;
            } else if (t.equals("IDAT")) {
                seenIdat = true;
                if (defaultIsFrame && cur == 0) idat.get(0).write(d, dp, len);
            } else if (t.equals("fdAT") && cur >= 0) idat.get(cur).write(d, dp + 4, len - 4);
            else if (t.equals("PLTE") || t.equals("tRNS") || t.equals("gAMA") || t.equals("sRGB") || t.equals("iCCP") || t.equals("cHRM")) {
                if (!seenIdat) chunk(pre, t, d, dp, len);
            } else if (t.equals("IEND")) break;
            p = dp + len + 4;
        }
        if (!anim || fc.size() < 2 || ihdr == null) return null;
        Comp c = new Comp(W, H);
        ArrayList<Bitmap> out = new ArrayList<Bitmap>();
        try {
            for (int i = 0; i < fc.size() && i < MAX_FRAMES; i++) {
                if (full(out.size(), W, H)) break;
                int[] f = fc.get(i);
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                o.write(new byte[]{(byte) 0x89, 'P', 'N', 'G', 13, 10, 26, 10}, 0, 8);
                byte[] ih = ihdr.clone();
                ih[0] = (byte) (f[2] >> 24); ih[1] = (byte) (f[2] >> 16); ih[2] = (byte) (f[2] >> 8); ih[3] = (byte) f[2];
                ih[4] = (byte) (f[3] >> 24); ih[5] = (byte) (f[3] >> 16); ih[6] = (byte) (f[3] >> 8); ih[7] = (byte) f[3];
                chunk(o, "IHDR", ih, 0, ih.length);
                byte[] pb = pre.toByteArray();
                o.write(pb, 0, pb.length);
                byte[] id = idat.get(i).toByteArray();
                chunk(o, "IDAT", id, 0, id.length);
                chunk(o, "IEND", new byte[0], 0, 0);
                Bitmap fb = decode(o.toByteArray());
                out.add(c.add(fb, f[0], f[1], f[5] == 1, f[4] == 1 ? 1 : f[4] == 2 ? 2 : 0));
                lastDelays.add(Integer.valueOf(f[6]));
                fb.recycle();
            }
        } finally { c.done(); }
        return out;
    }

    // ---- WebP animado ----

    private static boolean isWebp(byte[] d) {
        return d.length > 12 && d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' && d[8] == 'W' && d[9] == 'E' && d[10] == 'B' && d[11] == 'P';
    }

    private static int le24(byte[] d, int p) { return (d[p] & 255) | ((d[p + 1] & 255) << 8) | ((d[p + 2] & 255) << 16); }

    private static int le32(byte[] d, int p) { return le24(d, p) | ((d[p + 3] & 255) << 24); }

    private static void le32(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >> 8); o.write(v >> 16); o.write(v >> 24); }

    private static void riffChunk(ByteArrayOutputStream o, String t, byte[] d, int off, int len) {
        for (int i = 0; i < 4; i++) o.write(t.charAt(i));
        le32(o, len);
        o.write(d, off, len);
        if ((len & 1) != 0) o.write(0);
    }

    /** Quadros de um WebP animado (ou null se nao for animado). */
    private static List<Bitmap> animatedWebp(byte[] d) throws IOException {
        int p = 12, W = 0, H = 0;
        boolean anim = false;
        ArrayList<int[]> anmf = new ArrayList<int[]>();      // {dataOff, dataLen, x, y, w, h, blendOver(1)/no(0), dispose}
        while (p + 8 <= d.length) {
            String t = tag(d, p);
            int len = le32(d, p + 4), dp = p + 8;
            if (len < 0 || dp + len > d.length) break;
            if (t.equals("VP8X") && len >= 10) { anim = (d[dp] & 2) != 0; W = le24(d, dp + 4) + 1; H = le24(d, dp + 7) + 1; }
            else if (t.equals("ANMF") && len >= 16) {
                int fl = d[dp + 15] & 255;
                anmf.add(new int[]{dp + 16, len - 16, le24(d, dp) * 2, le24(d, dp + 3) * 2, le24(d, dp + 6) + 1, le24(d, dp + 9) + 1, (fl & 2) == 0 ? 1 : 0, fl & 1, le24(d, dp + 12)});
            }
            p = dp + len + (len & 1);
        }
        if (!anim || anmf.size() < 2) return null;
        Comp c = new Comp(W, H);
        ArrayList<Bitmap> out = new ArrayList<Bitmap>();
        try {
            for (int i = 0; i < anmf.size() && i < MAX_FRAMES; i++) {
                if (full(out.size(), W, H)) break;
                int[] f = anmf.get(i);
                // sub-chunks do quadro: ALPH? + VP8/VP8L
                int q = f[0], end = f[0] + f[1];
                int alph = -1, alphLen = 0, img = -1, imgLen = 0;
                String imgTag = null;
                while (q + 8 <= end) {
                    String t = tag(d, q);
                    int len = le32(d, q + 4);
                    if (t.equals("ALPH")) { alph = q + 8; alphLen = len; }
                    else if (t.equals("VP8 ") || t.equals("VP8L")) { img = q + 8; imgLen = len; imgTag = t; }
                    q += 8 + len + (len & 1);
                }
                if (img < 0) throw new IOException("quadro de WebP sem imagem");
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                body.write('W'); body.write('E'); body.write('B'); body.write('P');
                if (alph >= 0) {
                    byte[] vx = new byte[10];
                    vx[0] = 0x10;
                    vx[4] = (byte) (f[4] - 1); vx[5] = (byte) ((f[4] - 1) >> 8); vx[6] = (byte) ((f[4] - 1) >> 16);
                    vx[7] = (byte) (f[5] - 1); vx[8] = (byte) ((f[5] - 1) >> 8); vx[9] = (byte) ((f[5] - 1) >> 16);
                    riffChunk(body, "VP8X", vx, 0, 10);
                    riffChunk(body, "ALPH", d, alph, alphLen);
                }
                riffChunk(body, imgTag, d, img, imgLen);
                byte[] b = body.toByteArray();
                ByteArrayOutputStream file = new ByteArrayOutputStream();
                file.write('R'); file.write('I'); file.write('F'); file.write('F');
                le32(file, b.length);
                file.write(b, 0, b.length);
                Bitmap fb = decode(file.toByteArray());
                out.add(c.add(fb, f[2], f[3], f[6] == 1, f[7] == 1 ? 1 : 0));
                lastDelays.add(Integer.valueOf(f[8]));
                fb.recycle();
            }
        } finally { c.done(); }
        return out;
    }
}
