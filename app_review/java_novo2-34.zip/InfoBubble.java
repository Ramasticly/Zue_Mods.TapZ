package com.zue.attackeditor;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/**
 * Botao (i) e caixa de texto dos cartoes de reacao: as linhas de {@link ReactionWallInfo} saem coloridas como na grade de ANOs (azul = regra fixa do jogo,
 * verde = dado da tabela). So tela; o texto vem pronto do nucleo puro.
 */
final class InfoBubble {
    private InfoBubble() { }

    static final int CODE_BLUE = 0xFF6CB4FF, GREEN = 0xFF3DDC84;

    /** Poe o (i) no canto superior direito de {@code box} (um FrameLayout com a miniatura); tocar nele nao seleciona o cartao. */
    static void attach(final Activity a, FrameLayout box, View.OnClickListener l) {
        TextView info = new TextView(a);
        info.setText("ⓘ");
        info.setTextSize(16);
        info.setTypeface(Typeface.DEFAULT_BOLD);
        info.setTextColor(LayoutManager.ACCENT);
        info.setGravity(Gravity.CENTER);
        info.setBackgroundColor(0x99000000);
        info.setOnClickListener(l);
        int s = SpriteListScreen.dp(a, 26);
        box.addView(info, new FrameLayout.LayoutParams(s, s, Gravity.TOP | Gravity.END));
    }

    /** Caixa com as linhas coloridas (traduzidas linha a linha: texto com cor nao passa pelo TextView traduzido). */
    static void show(Activity a, String title, List<AttackInfo.Line> lines) {
        android.text.SpannableStringBuilder sp = new android.text.SpannableStringBuilder();
        for (int k = 0; k < lines.size(); k++) {
            AttackInfo.Line ln = lines.get(k);
            String tx = I18n.lang() == I18n.PT ? ln.text : I18n.tr(ln.text);
            int st = sp.length();
            sp.append(tx);
            int col = ln.src == AttackInfo.CODE ? CODE_BLUE : ln.src == AttackInfo.BIN ? GREEN : LayoutManager.TEXT;
            sp.setSpan(new android.text.style.ForegroundColorSpan(col), st, sp.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (k + 1 < lines.size()) sp.append("\n\n");
        }
        TextView t = new TextView(a);
        t.setText(sp);
        t.setTextSize(13);
        t.setTextColor(LayoutManager.TEXT);
        int p = SpriteListScreen.dp(a, 16);
        t.setPadding(p, p / 2, p, p / 2);
        ScrollView sv = new ScrollView(a);
        sv.addView(t);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(title).setView(sv).setNegativeButton("FECHAR", null).show();
    }

    /** O (i) de uma reacao: titulo "Jogo n"/"Personagem n" e as regras de parede/pouso dela. */
    static void showReaction(Activity a, int value, ReactionTable t, ReactionWallInfo.Lookup lk) {
        boolean charSrc = value >= 30;
        show(a, (charSrc ? I18n.tr("Personagem ") + (value - 30) : I18n.tr("Jogo ") + value) + " · " + I18n.tr("parede e pouso"), ReactionWallInfo.lines(t, charSrc, value, lk));
    }
}
