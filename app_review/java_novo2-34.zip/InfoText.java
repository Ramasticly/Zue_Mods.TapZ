package com.zue.attackeditor;

/** Textos das abas de informacao: o proprio formato texto do DAC / HDAT 4 (ver {@link DacText}). */
final class InfoText {
    private InfoText() { }

    /** Marca da linha do frame atual na aba ANO (so na exibicao). */
    static final char MARK = '»';

    static String move(AttackData d) {
        return DacText.move(d.move, d.moveIndex);
    }

    static String ano(AttackSim.Obj r) {
        if (r == null) return "sem ANO";
        return DacText.ano(r.ano, r.pat >= 0 && r.pat < r.mpts.length ? r.pat : -1);
    }

    static String frame(AttackSim.Obj r) {
        if (r == null) return "sem ANO";
        if (r.pat < 0 || r.pat >= r.mpts.length) return "fora dos frames (pat " + r.pat + "/" + r.mpts.length + ")";
        return DacText.mpt(r.mpts[r.pat], r.pat, "");
    }

    static String links(AttackSim.Obj r) {
        if (r == null) return "sem ANO";
        if (r.ano.links.length == 0) return "$LNKS:{\n},    // ANO " + r.ano.index + " sem links";
        return DacText.links(r.ano.links, "");
    }
}
