package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Interpolacao que nao trunca. O jogo (e {@link AttackSim}, _Hokan) calcula o passo de cada campo como {@code (destino - atual) / time} em inteiros:
 * posicao e zoom em escala 128, rotacao e alpha SEM escala. Se a divisao deixa resto o frame nao chega exatamente no destino (e com |delta| &lt; time
 * rotacao e alpha ficam parados: parece que a interpolacao nao funcionou). Aqui: detectar quais campos truncam e propor pequenas mudancas (no tempo do frame
 * que interpola e nos valores do frame de DESTINO) em que nada trunca. Java puro.
 */
final class InterpFix {
    private InterpFix() { }

    // grupos (o que o usuario enxerga)
    static final int G_TIME = 1, G_POS = 2, G_ROT = 4, G_ZOOM = 8, G_ALPHA = 16;
    // campos
    static final int F_X = 1, F_Y = 2, F_ROT = 4, F_ZX = 8, F_ZY = 16, F_ALPHA = 32;
    private static final int[] SCALE = {128, 128, 1, 128, 128, 1};          // F_X, F_Y, F_ROT, F_ZX, F_ZY, F_ALPHA
    static final int MAX_TIME = 255;

    /** Valores de um frame que entram na interpolacao (o que o jogo lê). */
    static final class Pt {
        int time, midX, midY, rot, zx = 100, zy = 100, alpha = 255;
        Pt copy() { Pt p = new Pt(); p.time = time; p.midX = midX; p.midY = midY; p.rot = rot; p.zx = zx; p.zy = zy; p.alpha = alpha; return p; }
        int get(int f) { switch (f) { case F_X: return midX; case F_Y: return midY; case F_ROT: return rot; case F_ZX: return zx; case F_ZY: return zy; default: return alpha; } }
        void set(int f, int v) { switch (f) { case F_X: midX = v; break; case F_Y: midY = v; break; case F_ROT: rot = v; break; case F_ZX: zx = v; break; case F_ZY: zy = v; break; default: alpha = v; } }
    }

    /** Le o frame como o jogo (sem MID = 0,0; sem RAZ = rot 0, zoom 100, alpha 255). */
    static Pt read(Ano.Mpt m) {
        Pt p = new Pt();
        p.time = m.hasTime ? m.time : 0;
        if (m.hasMid) { p.midX = m.midX; p.midY = m.midY; }
        if (m.hasRaz) { p.rot = m.rot; p.zx = m.xZoom; p.zy = m.yZoom; p.alpha = 255 - (m.alphaRaw & 255); }
        return p;
    }

    private static int index(int f) { int i = 0; while ((1 << i) != f) i++; return i; }

    /** Campos cujo passo trunca com {@code time} ticks (resto da divisao diferente de zero). */
    static int truncating(Pt cur, Pt next, int time) {
        if (time <= 0) return 0;
        int mask = 0;
        for (int f = F_X; f <= F_ALPHA; f <<= 1) {
            long d = (long) (next.get(f) - cur.get(f)) * SCALE[index(f)];
            if (d % time != 0) mask |= f;
        }
        return mask;
    }

    static int groupsOf(int fields) {
        int g = 0;
        if ((fields & (F_X | F_Y)) != 0) g |= G_POS;
        if ((fields & F_ROT) != 0) g |= G_ROT;
        if ((fields & (F_ZX | F_ZY)) != 0) g |= G_ZOOM;
        if ((fields & F_ALPHA) != 0) g |= G_ALPHA;
        return g;
    }

    private static int gcd(int a, int b) { return b == 0 ? Math.abs(a) : gcd(b, a % b); }

    /** Menor passo (em unidades do campo) que um delta precisa ser multiplo para nao truncar com {@code time}. */
    private static int unit(int f, int time) { return time / gcd(time, SCALE[index(f)]); }

    private static int floorMul(int d, int m) { return Math.floorDiv(d, m) * m; }
    private static int ceilMul(int d, int m) { return -Math.floorDiv(-d, m) * m; }

    /** Uma proposta: novo tempo do frame que interpola + novos valores do frame de destino. */
    static final class Variation {
        int time;
        final Pt dest;
        int changedGroups;          // G_* alterados
        double cost;                // soma das mudancas (desempate)
        final List<String> tags = new ArrayList<String>();
        Variation(int time, Pt dest) { this.time = time; this.dest = dest; }
    }

    private static double weight(int f) { return f == F_ZX || f == F_ZY ? 1.0 : f == F_ALPHA ? 0.5 : f == F_ROT ? 1.0 : 1.0; }

    /** Valores do destino (um campo) para nao truncar com {@code time}: o multiplo mais proximo (near) e o vizinho do outro lado (other). */
    private static int[] neighbours(Pt cur, Pt next, int f, int time) {
        int m = unit(f, time), d = next.get(f) - cur.get(f);
        int lo = floorMul(d, m), hi = ceilMul(d, m);
        if (lo == hi) { lo = d - m; hi = d; }            // (nao deveria acontecer: ja divide)
        boolean nearLow = (d - lo) <= (hi - d);
        int near = cur.get(f) + (nearLow ? lo : hi), other = cur.get(f) + (nearLow ? hi : lo);
        return new int[]{near, other};
    }

    private static boolean valid(Pt p) { return p.zx >= 0 && p.zy >= 0 && p.alpha >= 0 && p.alpha <= 255; }

    /**
     * Variacoes sem truncar, da MINIMA (menos grupos alterados, menor custo) para as outras. Vazio se nada trunca. Se so um grupo trunca, so ha variacoes desse
     * grupo (o tempo e os outros valores ficam).
     */
    static List<Variation> variations(Pt cur, Pt next) {
        List<Variation> out = new ArrayList<Variation>();
        int t0 = cur.time;
        int tr = truncating(cur, next, t0);
        if (tr == 0) return out;
        int groups = groupsOf(tr);
        Set<String> seen = new HashSet<String>();
        List<Integer> times = new ArrayList<Integer>();
        times.add(Integer.valueOf(t0));
        if (Integer.bitCount(groups) >= 2) {
            // outros tempos que resolvem tudo sem mexer em valores, e vizinhos para combinar com ajustes
            for (int dt = 1; dt <= MAX_TIME; dt++) for (int s = -1; s <= 1; s += 2) {
                int t = t0 + s * dt;
                if (t < 1 || t > MAX_TIME) continue;
                times.add(Integer.valueOf(t));
                if (times.size() > 9) { dt = MAX_TIME; break; }
            }
        }
        for (Integer tt : times) {
            int t = tt.intValue();
            int fields = truncating(cur, next, t);
            // opcoes por GRUPO que trunca nesse tempo: 0 = mais proximo, 1 = o outro lado
            List<Integer> gl = new ArrayList<Integer>();
            for (int g = G_POS; g <= G_ALPHA; g <<= 1) if ((groupsOf(fields) & g) != 0) gl.add(Integer.valueOf(g));
            int combos = 1 << gl.size();
            for (int c = 0; c < combos; c++) {
                Pt d = next.copy();
                boolean ok = true;
                for (int gi = 0; gi < gl.size(); gi++) {
                    int g = gl.get(gi).intValue();
                    int pick = (c >> gi) & 1;
                    for (int f = F_X; f <= F_ALPHA; f <<= 1) {
                        if ((fields & f) == 0 || (groupsOf(f) & g) == 0) continue;
                        int[] nb = neighbours(cur, next, f, t);
                        d.set(f, nb[pick]);
                    }
                }
                if (!valid(d) || truncating(cur, d, t) != 0) ok = false;
                if (!ok) continue;
                if (t == t0 && c == 0 && gl.isEmpty()) continue;        // nada a mudar
                Variation v = new Variation(t, d);
                for (int f = F_X; f <= F_ALPHA; f <<= 1) {
                    if (d.get(f) != next.get(f)) { v.changedGroups |= groupsOf(f); v.cost += Math.abs(d.get(f) - next.get(f)) * weight(f); }
                }
                if (t != t0) { v.changedGroups |= G_TIME; v.cost += Math.abs(t - t0); }
                if (v.changedGroups == 0) continue;
                // com um unico grupo truncando, so variacoes desse grupo (sem mexer no tempo)
                if (Integer.bitCount(groups) == 1 && t != t0) continue;
                String key = v.time + ":" + d.midX + "," + d.midY + "," + d.rot + "," + d.zx + "," + d.zy + "," + d.alpha;
                if (!seen.add(key)) continue;
                out.add(v);
            }
        }
        if (Integer.bitCount(groups) == 1) {
            // mais opcoes do mesmo campo: um multiplo alem de cada lado
            List<Variation> extra = new ArrayList<Variation>();
            for (Variation v : new ArrayList<Variation>(out)) {
                for (int s = -1; s <= 1; s += 2) {
                    Pt d = v.dest.copy();
                    boolean any = false;
                    for (int f = F_X; f <= F_ALPHA; f <<= 1) {
                        if ((tr & f) == 0) continue;
                        d.set(f, d.get(f) + s * unit(f, t0));
                        any = true;
                    }
                    if (!any || !valid(d) || truncating(cur, d, t0) != 0) continue;
                    Variation w = new Variation(t0, d);
                    for (int f = F_X; f <= F_ALPHA; f <<= 1) if (d.get(f) != next.get(f)) { w.changedGroups |= groupsOf(f); w.cost += Math.abs(d.get(f) - next.get(f)) * weight(f); }
                    String key = w.time + ":" + d.midX + "," + d.midY + "," + d.rot + "," + d.zx + "," + d.zy + "," + d.alpha;
                    if (w.changedGroups != 0 && seen.add(key)) extra.add(w);
                }
            }
            out.addAll(extra);
        }
        Collections.sort(out, new Comparator<Variation>() {
            @Override public int compare(Variation a, Variation b) {
                int ga = Integer.bitCount(a.changedGroups), gb = Integer.bitCount(b.changedGroups);
                if (ga != gb) return ga - gb;
                return Double.compare(a.cost, b.cost);
            }
        });
        while (out.size() > 12) out.remove(out.size() - 1);
        // tags: o que ficou igual entre o que podia mudar (tempo e os grupos que truncavam)
        int relevant = G_TIME | groups;
        for (Variation v : out) {
            int keep = relevant & ~v.changedGroups;
            if ((keep & G_TIME) != 0) v.tags.add("Mantém tempo igual");
            if ((keep & G_POS) != 0) v.tags.add("Mantém posição igual");
            if ((keep & G_ROT) != 0) v.tags.add("Mantém rotação igual");
            if ((keep & G_ZOOM) != 0) v.tags.add("Mantém zoom igual");
            if ((keep & G_ALPHA) != 0) v.tags.add("Mantém alpha igual");
        }
        return out;
    }

    /** Resumo "campo, de, para" das mudancas da variacao: {rotulo, de, para} (rotulo: time, Rot, Zoom, Posição, Alpha). */
    static List<String[]> changes(Pt cur, Pt next, Variation v) {
        List<String[]> out = new ArrayList<String[]>();
        if (v.time != cur.time) out.add(new String[]{"time", String.valueOf(cur.time), String.valueOf(v.time)});
        Pt d = v.dest;
        if (d.midX != next.midX || d.midY != next.midY) out.add(new String[]{"Posição", next.midX + ", " + next.midY, d.midX + ", " + d.midY});
        if (d.rot != next.rot) out.add(new String[]{"Rot", String.valueOf(next.rot), String.valueOf(d.rot)});
        if (d.zx != next.zx || d.zy != next.zy) {
            boolean same = next.zx == next.zy && d.zx == d.zy;
            out.add(new String[]{"Zoom", same ? String.valueOf(next.zx) : next.zx + ", " + next.zy, same ? String.valueOf(d.zx) : d.zx + ", " + d.zy});
        }
        if (d.alpha != next.alpha) out.add(new String[]{"Alpha", String.valueOf(next.alpha), String.valueOf(d.alpha)});
        return out;
    }

    /** Aplica a variacao: tempo do frame {@code idx} e valores do frame de destino (o seguinte; no ultimo, o frame 0). Devolve copia da lista. */
    static Ano.Mpt[] apply(Ano.Mpt[] mp, int idx, Variation v) {
        if (mp == null || idx < 0 || idx >= mp.length) return mp;
        Ano.Mpt[] out = mp.clone();
        int ni = idx + 1 >= mp.length ? 0 : idx + 1;
        Ano.Mpt c = out[idx].copy();
        if (v.time != (c.hasTime ? c.time : 0)) { c.flags |= 0x20; c.time = Math.max(1, Math.min(MAX_TIME, v.time)); c.normalize(); }
        out[idx] = c;
        Ano.Mpt n = out[ni] == c ? c : out[ni].copy();
        SpriteDefaults.Def d = SpriteDefaults.read(n);
        d.midX = v.dest.midX; d.midY = v.dest.midY; d.rot = v.dest.rot; d.zx = v.dest.zx; d.zy = v.dest.zy;
        d.alpha = (n.alphaRaw & ~255) | (255 - v.dest.alpha);
        n = SpriteDefaults.write(n, d);
        out[ni] = n;
        return out;
    }
}
