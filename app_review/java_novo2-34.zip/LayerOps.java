package com.zue.attackeditor;

/**
 * CAMADA da ANO (Java puro). No jogo o {@code iActPrio} (byte com sinal, $PRIO) MAIOR fica mais ATRAS (ordem de desenho = prio - iActPrio),
 * entao o app mostra a camada ao contrario: camada maior = mais em cima; grava $PRIO = -camada.
 */
final class LayerOps {
    private LayerOps() { }

    static final int MIN = -127, MAX = 128;       // $PRIO vai de -128 a 127  =>  camada de -127 a 128

    /** Camada mostrada: maior = mais em cima. */
    static int layerOf(Ano a) { return a == null ? 0 : -a.priority; }

    static int clamp(int layer) { return Math.max(MIN, Math.min(MAX, layer)); }

    /** A mesma ANO com a camada pedida (camada 0 = sem $PRIO, como o jogo trata o padrao). */
    static Ano setLayer(Ano a, int layer) {
        int l = clamp(layer);
        int prio = -l;
        int flags = prio == 0 ? a.flags & ~4 : a.flags | 4;
        return new Ano(a.index, a.present, flags, prio, a.links, a.mpts);
    }
}
