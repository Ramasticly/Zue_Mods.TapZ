package com.zue.attackeditor;

import android.app.Activity;
import java.io.File;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * Monta toda a interface por codigo: seletores, preview, linha do tempo, controles e opcoes.
 * Nao conhece DAC/CNV; so conversa com {@link AttackView}.
 */
public final class LayoutManager {
    static final int BG = 0xFF14161B;
    static final int PANEL = 0xFF1E2128;
    static final int PANEL_HI = 0xFF2C313C;
    static final int ACCENT = 0xFF4C8DFF;
    static final int TEXT = 0xFFE6E8EC;
    static final int DIM = 0xFF8A90A0;
    static final int WARN = 0xFFFFB454;

    public final android.widget.FrameLayout root;
    public final Spinner characterSpinner;
    public final Spinner attackSpinner;
    /** Personagem oponente (defensor, ANO 0). */
    public final Spinner opponentSpinner;
    /** Alterna a lista entre golpes (HDAT 4) e todos os ANOs do personagem. */
    public final TextView listModeChip;
    /** Linha de estado do personagem (pasta, contagens). */
    public final TextView status;
    /** Linha estatica do golpe (ANIM_INICIAL, MPT, LINKS). */
    public final TextView info;
    public final AttackView attackView;

    private final TextView frameInfo;
    private final TextView[] infoTabs;
    private final TextView statusLine;
    private final TextView editBtn;
    private String lastKey = "";
    private String renderedTab = "";
    private int renderedAno = -2;
    private String tabKey = "ano";
    private boolean tabsAnoMode;
    private boolean tabsInit;
    private final TextView warning;
    private final TextView frameLabel;
    private final SeekBar seek;
    private final TextView btnPlay;
    private final float density;
    private final float[] speeds = {1f, 0.5f, 0.25f, 2f};
    private final String[] speedNames = {"1x", "0.5x", "0.25x", "2x"};
    private int speedIndex;

    /** Ícone cúbico (letra) com o texto embaixo, para o slider de opcoes. */
    private static final class Tile {
        LinearLayout box;
        TextView sq, lab;
    }

    /** Segura a preview em proporcao 1:1: lado = o menor entre largura e altura disponiveis, no topo e centralizada. */
    /**
     * Preview quadrada. O filho e sempre medido e desenhado no tamanho de referencia (o do modo normal); quando o espaco e menor
     * (modo T) o holder so reduz o filho por igual (escala da view inteira), entao camera, zoom e enquadramento ficam como estavam.
     */
    static final class SquareHolder extends android.widget.FrameLayout {
        private int ref = 1;
        SquareHolder(Context c) { super(c); }
        @Override protected void onMeasure(int ws, int hs) {
            int w = MeasureSpec.getSize(ws);
            int screenH = getResources().getDisplayMetrics().heightPixels;
            ref = Math.max(1, Math.min(w, (int) (screenH * 0.72f)));       // 1:1 preenchendo a largura (limitado em telas baixas)
            int side = ref;
            if (MeasureSpec.getMode(hs) == MeasureSpec.EXACTLY) side = Math.max(1, Math.min(ref, MeasureSpec.getSize(hs)));   // modo T: o espaco que sobra
            setMeasuredDimension(w, side);
            for (int i = 0; i < getChildCount(); i++)
                getChildAt(i).measure(MeasureSpec.makeMeasureSpec(ref, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ref, MeasureSpec.EXACTLY));
        }
        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l, side = b - t;
            int x = (w - ref) / 2;
            float k = Math.min(1f, side / (float) ref);
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                ch.layout(x, 0, x + ref, ref);
                ch.setPivotX(ref / 2f);
                ch.setPivotY(0f);
                ch.setScaleX(k);
                ch.setScaleY(k);
            }
        }
    }

    private interface Num { int get(); void set(int v); }
    private interface IntBool { void set(int id, boolean v); }

    /** Linha "titulo  [-10][-1] valor [+1][+10]" para o menu POS. */
    private View posRow(Activity a, String title, final Num n) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(a, title, 12, DIM), lp(-1, -2, 0, 0, 0, 3));
        LinearLayout row = row(a);
        final TextView val = mono(a, String.valueOf(n.get()), 18, TEXT);
        val.setGravity(Gravity.CENTER);
        int[] steps = {-10, -1, 0, 1, 10};
        for (int k = 0; k < steps.length; k++) {
            final int st = steps[k];
            if (st == 0) { row.addView(val, lpw(1.2f, 3, 0, 3, 0)); continue; }
            TextView b = button(a, (st > 0 ? "+" : "") + st, false);
            Hold.attach(b, new Runnable() {
                @Override public void run() { n.set(n.get() + st); val.setText(String.valueOf(n.get())); }
            });
            row.addView(b, lpw(1f, 2, 0, 2, 0));
        }
        col.addView(row);
        return col;
    }

    private boolean panelOpen;
    private TimelineView timelineRef;
    private final TextView[] undoBtns = new TextView[2];

    /** Esmaece ↶ ↷ da barra da timeline quando nao ha o que desfazer / refazer no escopo atual (menu aberto ou acoes aplicadas). */
    private void undoButtonsRefresh() {
        if (undoBtns[0] == null || attackView == null) return;
        undoBtns[0].setAlpha(attackView.canUndo() ? 1f : 0.35f);
        undoBtns[1].setAlpha(attackView.canRedo() ? 1f : 0.35f);
        if (toolsRef0 != null) toolsRef0.updateUndoButtons();
    }
    private TimelineTools toolsRef0;
    private TextView backBar;
    private Navigator navigator;

    private static final String[] ADD_BASIC = {"Sprite", "Hitbox (ataque)", "Hurtbox (corpo)", "Projetil", "Efeito / animacao", "Som", "Velocidade", "Animacao ligada"};
    private static final int[] ADD_BASIC_CODE = {0, 1, 2, 3, 4, 6, 7, 8};
    private static final int[] ADD_BASIC_COLOR = {0xFFE5C100, 0xFFE5484D, 0xFF3DDC84, 0xFFFF9A3C, 0xFFB07CFF, 0xFF3D8BFF, 0xFF3DDC84, 0xFF2EC4C4};

    /** Popup flutuante com tudo que a timeline sabe criar; cria no ponteiro. */
    private void showAddPopup(Activity a, View anchor, final TimelineOps ops) {
        final android.widget.PopupWindow[] pw = new android.widget.PopupWindow[1];
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(8), dp(8), dp(8));
        TextView hd = text(a, "Adicionar no ponteiro", 11, DIM);
        col.addView(hd, lp(-2, -2, 4, 0, 0, 4));
        for (int i = 0; i < ADD_BASIC.length; i++) {
            final int code = ADD_BASIC_CODE[i];
            col.addView(addItem(a, ADD_BASIC[i], ADD_BASIC_COLOR[i], new View.OnClickListener() {
                @Override public void onClick(View v) { pw[0].dismiss(); ops.add(code); }
            }));
        }
        col.addView(text(a, "Acoes especiais", 11, DIM), lp(-2, -2, 4, 8, 0, 4));
        AttackData addData = attackView == null ? null : attackView.attackData();
        int[] addFlags = ObjModel.actionFlagsFor(addData == null ? null : addData.move, addData == null ? -1 : addData.moveIndex, ops.frameOfPlayhead());
        for (int i = 0; i < addFlags.length; i++) {
            final int fl = addFlags[i];
            col.addView(addItem(a, ObjModel.actionName(fl), 0xFFB8C0CC, new View.OnClickListener() {
                @Override public void onClick(View v) { pw[0].dismiss(); ops.addObject(fl); }
            }));
        }
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(col);
        setBg(sv, roundRect(0xFF1B2029, 12, 1, 0xFF3A4150));
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(dp(230), sw - dp(24));
        int h = Math.min(dp(380), Math.max(dp(160), loc[1] + dp(44) - dp(16)));
        pw[0] = new android.widget.PopupWindow(sv, w, h, true);
        pw[0].setOutsideTouchable(true);
        pw[0].setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        pw[0].showAtLocation(anchor, Gravity.NO_GRAVITY, sw - w - dp(8), Math.max(dp(8), loc[1] + dp(44) - h));
    }

    /** Menu do + do fim da timeline: CAMADA (− N +) e Adicionar Sprite. */
    private void showEndMenu(Activity a, View anchor, final TimelineOps ops) {
        final android.widget.PopupWindow[] pw = new android.widget.PopupWindow[1];
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(8), dp(8), dp(8));
        col.addView(text(a, "Timeline", 11, DIM), lp(-2, -2, 4, 0, 0, 4));
        // CAMADA: quanto maior, mais em cima
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lw = new LinearLayout.LayoutParams(0, -2, 1f);
        lw.setMargins(dp(8), 0, dp(8), 0);
        row.addView(text(a, "CAMADA", 14, TEXT), lw);
        final TextView val = text(a, String.valueOf(ops.layer()), 15, TEXT);
        val.setGravity(Gravity.CENTER);
        TextView minus = Stepper.sideButton(a, "\u2212"), plus = Stepper.sideButton(a, "+");
        minus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { val.setText(String.valueOf(ops.setLayer(ops.layer() - 1))); } });
        plus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { val.setText(String.valueOf(ops.setLayer(ops.layer() + 1))); } });
        row.addView(minus, lp(dp(40), dp(40), 0, 0, 0, 0));
        row.addView(val, lp(dp(48), -2, 0, 0, 0, 0));
        row.addView(plus, lp(dp(40), dp(40), 0, 0, 0, 0));
        col.addView(row);
        col.addView(text(a, "Maior = a ANO aparece mais em cima; menor = mais embaixo.", 10, DIM), lp(-2, -2, 8, 0, 4, 4));
        col.addView(addItem(a, "Adicionar Sprite", 0xFFE5C100, new View.OnClickListener() {
            @Override public void onClick(View v) { pw[0].dismiss(); ops.addSpriteEditing(); }
        }));
        setBg(col, roundRect(0xFF1B2029, 12, 1, 0xFF3A4150));
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(dp(260), sw - dp(24));
        pw[0] = new android.widget.PopupWindow(col, w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true);
        pw[0].setOutsideTouchable(true);
        pw[0].setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        pw[0].showAtLocation(anchor, Gravity.NO_GRAVITY, Math.max(dp(8), loc[0] + dp(8)), Math.max(dp(8), loc[1] - dp(150)));
    }

    /** Caixinhas do que a timeline mostra (tudo marcado por padrao). */
    private void showFilter(Activity a, final TimelineView tl) {
        final boolean[] on = new boolean[TimelineView.FILTER_NAMES.length];
        for (int i = 0; i < on.length; i++) on[i] = tl.isShown(i);
        final android.app.AlertDialog dlg = new I18nBuilder(a).setTitle("Mostrar na timeline")
                .setMultiChoiceItems(TimelineView.FILTER_NAMES, on, new android.content.DialogInterface.OnMultiChoiceClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which, boolean checked) { tl.setShown(which, checked); }
                })
                .setNeutralButton("MOSTRAR TUDO", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { tl.showAll(); }
                })
                .setPositiveButton("OK", null).create();
        dlg.show();
    }

    private TextView addItem(Context c, String label, int color, View.OnClickListener l) {
        TextView t = text(c, "\u25CF  " + label, 14, TEXT);
        t.setPadding(dp(8), dp(10), dp(8), dp(10));
        t.setClickable(true);
        setBg(t, stateBg(0x00000000, PANEL_HI));
        android.text.SpannableString sp = new android.text.SpannableString(I18n.tr(t.getText().toString()));
        sp.setSpan(new android.text.style.ForegroundColorSpan(color), 0, 1, 0);
        t.setText(sp);
        t.setOnClickListener(l);
        return t;
    }

    /** Liga a navegacao para o editor de animacao paralelo (feita pela MainActivity). */
    private TextView handleRef;

    /** Fecha a gaveta de edicao (mantem o que ja foi feito); usado ao trocar de golpe/ANO. */
    public void closeSheet() {
        if (timelineRef != null) timelineRef.clearSelection();
        if (toolsRef0 != null && toolsRef0.sheetOpen()) toolsRef0.hideSheet();
    }

    /** Botao voltar do aparelho: fecha uma camada por vez. true = tratou; false = pode sair. */
    public boolean handleBack() {
        if (toolsRef0 != null && toolsRef0.sheetOpen()) { toolsRef0.cancelSheet(); return true; }
        if (panelOpen && handleRef != null) { handleRef.performClick(); return true; }
        if (timelineRef != null && timelineRef.isExpanded()) { timelineRef.setExpanded(false); return true; }
        if (backBar != null && backBar.getVisibility() == View.VISIBLE && navigator != null) { navigator.back(); return true; }
        return false;
    }

    private Runnable flowChanged;
    private Activity flowAct;

    /** Fluxo editavel do golpe carregado (botao FLUXO da grade de golpes, "+ > SEQ" e a faixa de transicoes). */
    public void openFlow() {
        if (flowAct != null) FlowDialog.show(flowAct, attackView, navigator, flowChanged);
    }

    public void setNavigator(Navigator n) {
        navigator = n;
        if (toolsRef0 != null) toolsRef0.nav = n;
    }

    /** Mostra/esconde a barra "voltar ao golpe" (texto null esconde). */
    public void setBackBar(String text) {
        if (backBar == null) return;
        backBar.setVisibility(text == null ? View.GONE : View.VISIBLE);
        if (text != null) backBar.setText(text);
    }
    private TextView modeLabel;
    private LinearLayout topSlot;

    private Tile tile(Context c, String letter, String label) {
        Tile t = new Tile();
        t.box = new LinearLayout(c);
        t.box.setOrientation(LinearLayout.VERTICAL);
        t.box.setGravity(Gravity.CENTER_HORIZONTAL);
        t.sq = new I18nTextView(c);
        t.sq.setText(letter);
        t.sq.setGravity(Gravity.CENTER);
        t.sq.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        t.sq.setTypeface(Typeface.DEFAULT_BOLD);
        t.sq.setTextColor(TEXT);
        t.sq.setClickable(true);
        setBg(t.sq, stateBg(PANEL, PANEL_HI));
        t.box.addView(t.sq, new LinearLayout.LayoutParams(dp(52), dp(52)));
        t.lab = text(c, label, 10, DIM);
        t.lab.setGravity(Gravity.CENTER);
        t.lab.setSingleLine(true);
        t.lab.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.box.addView(t.lab, lp(dp(60), -2, 0, 3, 0, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.setMargins(dp(4), 0, dp(4), 0);
        t.box.setLayoutParams(bp);
        return t;
    }

    public LayoutManager(final Activity a) {
        density = a.getResources().getDisplayMetrics().density;
        a.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        final AttackView view = new AttackView(a);
        final ExtSeekBar sb = new ExtSeekBar(a);
        final TextView play = button(a, "PAUSAR", true);
        final TextView speed = button(a, speedNames[0], false);
        final TextView label = mono(a, "0/0", 12, TEXT);

        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setBackgroundColor(BG);
        int pad = dp(10);
        r.setPadding(pad, pad, pad, pad);
        applyInsets(r, pad);

        // ---- barra de titulo: nome do app (Zue Mods abre o canal) e AJUDA a direita
        LinearLayout titleBar = row(a);
        TextView tName = text(a, "Attack Editor by ", 14, TEXT);
        tName.setTypeface(Typeface.DEFAULT_BOLD);
        TextView tZue = text(a, "Zue Mods", 14, 0xFF4C8DFF);
        tZue.setTypeface(Typeface.DEFAULT_BOLD);
        tZue.setPadding(0, dp(8), dp(8), dp(8));
        tZue.setClickable(true);
        tZue.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openLink(a, "https://www.youtube.com/@zuemods/videos"); }
        });
        titleBar.addView(tName);
        titleBar.addView(tZue);
        View titleGap = new View(a);
        titleBar.addView(titleGap, new LinearLayout.LayoutParams(0, 1, 1f));
        // ↻: recarrega as pastas que o app le (personagens, efeitos, cenas, sons) sem reiniciar
        final TextView bReload = button(a, "\u21BB", false);
        if (bReload instanceof I18nTextView) ((I18nTextView) bReload).noTranslate();
        bReload.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        bReload.setPadding(dp(12), dp(5), dp(12), dp(5));
        bReload.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (onReload != null) onReload.run(); } });
        titleBar.addView(bReload, lp(-2, -2, 0, 0, 6, 0));
        // idioma: PT -> EN -> ES; troca na hora e retraduz a tela (nada e recriado, as edicoes ficam)
        final TextView bLang = button(a, I18n.code(), false);
        bLang.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        bLang.setPadding(dp(12), dp(7), dp(12), dp(7));
        I18nUi.registerLang(bLang);
        bLang.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { I18nUi.cycle(a); } });
        titleBar.addView(bLang, lp(-2, -2, 0, 0, 6, 0));
        final TextView bHelp = button(a, "AJUDA", false);
        bHelp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        bHelp.setPadding(dp(14), dp(7), dp(14), dp(7));
        titleBar.addView(bHelp, lp(-2, -2, 0, 0, 0, 0));
        r.addView(titleBar, lp(-1, -2, 0, 0, 0, 4));

        // ---- topo: estado, titulo do golpe, aviso e espaco reservado para opcoes futuras
        backBar = button(a, "", true);
        backBar.setVisibility(View.GONE);
        backBar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (navigator != null) navigator.back(); }
        });
        r.addView(backBar, lp(-1, -2, 0, 0, 0, 4));

        // ---- menu superior: personagens, posicao, tela, hitbox, grade, centrar, virar; modo e lista
        final Spinner cs = spinner(a);
        final HeaderSpinner as = headerSpinner(a);
        attackHeaderSpinner = as;
        final Spinner os = spinner(a);
        LinearLayout hidden = new LinearLayout(a);
        hidden.setVisibility(View.INVISIBLE);
        hidden.addView(cs, new LinearLayout.LayoutParams(dp(1), dp(1)));
        hidden.addView(os, new LinearLayout.LayoutParams(dp(1), dp(1)));
        r.addView(hidden, new LinearLayout.LayoutParams(dp(1), dp(1)));
        final TextView bChar = button(a, "CHAR", false);
        final TextView bOpt = button(a, "GOLPE SET", false);
        final TextView bScr = button(a, "TELA", false);
        final TextView bHit = button(a, "HITBOX", false);
        final TextView bGrid = button(a, "GRADE", false);
        final TextView bCtr = button(a, "CENTRO: NORMAL", false);
        final TextView bFlip = button(a, "VIRAR", false);
        final TextView bLock = button(a, "TRANSICAO: LIVRE", false);
        final TextView bLand = button(a, BattleSim.landingOn ? "POUSO: ON" : "POUSO: OFF", false);
        final TextView bTime = button(a, "TEMPO: NORMAL", false);
        final TextView bHide = button(a, "HIDE-EFF", false);
        final TextView bSave = button(a, "SALVAR", false);
        final TextView bSpr = button(a, "SPRITES", false);
        final TextView bSnd = button(a, "SONS", false);
        final TextView bLinks = button(a, "LINKS", false);
        lockBtnRef = bLock;
        // ordem editavel: segurar e arrastar. O 1o botao fica no slot fixo (fora da rolagem); soltar qualquer botao nele troca o fixo.
        java.util.LinkedHashMap<String, TextView> tbMap = new java.util.LinkedHashMap<String, TextView>();
        tbMap.put(ToolbarOrder.SAVE, bSave);
        tbMap.put(ToolbarOrder.CHAR, bChar);
        tbMap.put(ToolbarOrder.SPRITES, bSpr);
        tbMap.put(ToolbarOrder.SOUNDS, bSnd);
        tbMap.put(ToolbarOrder.LINKS, bLinks);
        tbMap.put(ToolbarOrder.MOVE, bOpt);
        tbMap.put(ToolbarOrder.HITBOX, bHit);
        tbMap.put(ToolbarOrder.TIME, bTime);
        tbMap.put(ToolbarOrder.CENTER, bCtr);
        tbMap.put(ToolbarOrder.LAND, bLand);
        tbMap.put(ToolbarOrder.LOCK, bLock);
        tbMap.put(ToolbarOrder.FLIP, bFlip);
        tbMap.put(ToolbarOrder.HIDE, bHide);
        tbMap.put(ToolbarOrder.SCREEN, bScr);
        android.widget.HorizontalScrollView tbs = new android.widget.HorizontalScrollView(a);
        tbs.setHorizontalScrollBarEnabled(false);
        LinearLayout trow = row(a);
        tbs.addView(trow);
        for (TextView tb : tbMap.values()) {
            tb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tb.setPadding(dp(14), dp(9), dp(14), dp(9));
        }
        LinearLayout pinned = row(a);
        // menu superior inteiro num grupo: o modo T so mexe na visibilidade do grupo (nada de estado por view)
        final LinearLayout topGroup = new LinearLayout(a);
        topGroup.setOrientation(LinearLayout.VERTICAL);
        LinearLayout topRow = row(a);
        topRow.addView(pinned, lp(-2, -2, 0, 0, 5, 0));
        topRow.addView(tbs, new LinearLayout.LayoutParams(0, -2, 1f));
        topGroup.addView(topRow, lp(-1, -2, 0, 0, 0, 5));
        toolbar = new ReorderBar(a, pinned, tbs, trow, tbMap);
        LinearLayout mrow = row(a);
        final TextView modeBtn = button(a, "MODO: GOLPES", false);
        modeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        modeBtn.setPadding(dp(12), dp(9), dp(12), dp(9));
        mrow.addView(modeBtn, lp(-2, -2, 0, 0, 6, 0));
        mrow.addView(as, new LinearLayout.LayoutParams(0, dp(42), 1f));
        topGroup.addView(mrow, lp(-1, -2, 0, 0, 0, 4));
        TextView st = text(a, "", 12, DIM);
        st.setSingleLine(true);
        st.setEllipsize(android.text.TextUtils.TruncateAt.END);
        st.setVisibility(View.GONE);
        topGroup.addView(st, lp(-1, -2, 0, 0, 0, 2));
        TextView in = mono(a, "", 12, 0xFF6AA1FF);
        in.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        in.setSingleLine(true);
        in.setEllipsize(android.text.TextUtils.TruncateAt.END);
        in.setVisibility(View.GONE);
        topGroup.addView(in, lp(-1, -2, 0, 0, 0, 2));
        TextView wr = text(a, "", 12, WARN);
        wr.setSingleLine(true);
        wr.setEllipsize(android.text.TextUtils.TruncateAt.END);
        wr.setVisibility(View.INVISIBLE);
        wr.setClickable(true);
        wr.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            warnExpanded = !warnExpanded;
            showWarning();
        } });
        topGroup.addView(wr, lp(-1, -2, 0, 0, 0, 4));
        r.addView(topGroup, new LinearLayout.LayoutParams(-1, -2));


        // ---- preview no centro
        setBg(view, roundRect(0xFF0D0F13, 10, 0, 0));
        SquareHolder holder = new SquareHolder(a);
        holder.addView(view, new android.widget.FrameLayout.LayoutParams(-1, -1));
        r.addView(holder, new LinearLayout.LayoutParams(-1, -2));
        // tudo abaixo da preview desliza
        final android.widget.ScrollView scroll = new SafeScrollView(a);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        final LinearLayout sc = new LinearLayout(a);
        sc.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(sc, new ViewGroup.LayoutParams(-1, -2));
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // ---- linha do tempo e transporte
        LinearLayout timeline = row(a);
        timeline.addView(sb, new LinearLayout.LayoutParams(0, -2, 1f));
        timeline.addView(label, lp(-2, -2, 8, 0, 0, 0));
        sc.addView(timeline, lp(-1, -2, 0, 4, 0, 4));
        LinearLayout bar = row(a);
        final TextView bSplit = button(a, "\u2702 DIVIDIR", false);
        final TextView bDup = button(a, "DUPLICAR", false);
        final TextView bDel = button(a, "\u2715 EXCLUIR", false);
        // desfazer e refazer ocupam o lugar do antigo DESFAZER: duas setas de larguras iguais que somam a mesma largura
        final TextView bUndo = button(a, "\u21B6", false);
        final TextView bRedo = button(a, "\u21B7", false);
        TextView[] bs = {bSplit, bDup, bDel};
        for (int q = 0; q < bs.length; q++) {
            bs[q].setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            bs[q].setPadding(dp(2), dp(7), dp(2), dp(7));
            bar.addView(bs[q], lpw(1f, q == 0 ? 0 : 3, 0, 3, 0));
        }
        LinearLayout undoPair = new LinearLayout(a);
        undoPair.setOrientation(LinearLayout.HORIZONTAL);
        TextView[] arrows = {bUndo, bRedo};
        for (int q = 0; q < 2; q++) {
            arrows[q].setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
            arrows[q].setPadding(dp(2), dp(5), dp(2), dp(5));
            undoPair.addView(arrows[q], lpw(1f, q == 0 ? 0 : 2, 0, 0, 0));
        }
        bar.addView(undoPair, lpw(1f, 0, 0, 0, 0));
        sc.addView(bar, lp(-1, -2, 0, 0, 0, 4));
        final TimelineView tl = new TimelineView(a);
        scroll.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r2, int b, int ol, int ot, int or2, int ob) {
                int h = b - t;
                if (h > 0) tl.setMaxHeightPx(Math.max(h - (int) (60 * v.getResources().getDisplayMetrics().density), (int) (120 * v.getResources().getDisplayMetrics().density)));
            }
        });
        final android.widget.FrameLayout tlBox = new android.widget.FrameLayout(a);
        tlBox.addView(tl, new android.widget.FrameLayout.LayoutParams(-1, -2));
        final TextView plus = new I18nTextView(a);
        plus.setText("\uFF0B");
        plus.setGravity(Gravity.CENTER);
        plus.setTextColor(Color.WHITE);
        plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        plus.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable tab = new GradientDrawable();
        tab.setColor(ACCENT);
        float rr = dp(14);
        tab.setCornerRadii(new float[]{rr, rr, 0, 0, 0, 0, rr, rr});     // aba colada na borda direita
        setBg(plus, tab);
        plus.setClickable(true);
        android.widget.FrameLayout.LayoutParams plp2 = new android.widget.FrameLayout.LayoutParams(dp(30), dp(44), Gravity.END | Gravity.TOP);
        plp2.setMargins(0, dp(4), 0, 0);
        tlBox.addView(plus, plp2);
        tlBox.setMinimumHeight(dp(104));
        final TextView filt = new I18nTextView(a);
        filt.setText("#");
        filt.setGravity(Gravity.CENTER);
        filt.setTextColor(Color.WHITE);
        filt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        filt.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable tab2 = new GradientDrawable();
        tab2.setColor(0xFF3A4150);
        tab2.setCornerRadii(new float[]{rr, rr, 0, 0, 0, 0, rr, rr});
        setBg(filt, tab2);
        filt.setClickable(true);
        android.widget.FrameLayout.LayoutParams flp = new android.widget.FrameLayout.LayoutParams(dp(30), dp(44), Gravity.END | Gravity.TOP);
        flp.setMargins(0, dp(52), 0, 0);
        tlBox.addView(filt, flp);
        filt.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showFilter(a, tl); } });
        sc.addView(tlBox, lp(-1, -2, 0, 0, 0, 6));

        LinearLayout transport = row(a);
        TextView bReset = button(a, "INICIO", false);
        TextView bBack = button(a, "-1", false);
        TextView bFwd = button(a, "+1", false);
        transport.addView(bReset, lpw(1f, 0, 0, 4, 0));
        transport.addView(bBack, lpw(1f, 4, 0, 4, 0));
        transport.addView(play, lpw(1.4f, 4, 0, 4, 0));
        transport.addView(bFwd, lpw(1f, 4, 0, 4, 0));
        transport.addView(speed, lpw(1f, 4, 0, 0, 0));
        // fixo na base da tela: continua visivel com as ferramentas abertas
        r.addView(transport, lp(-1, -2, 0, 4, 0, 2));

        // ---- dados do DAC (recolhido por padrao)
        final TextView handle = button(a, "\u25B2  DADOS / EDITAR", false);
        handle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        handle.setPadding(dp(4), dp(6), dp(4), dp(6));
        sc.addView(handle, lp(-1, -2, 0, 0, 0, 0));

        final LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setVisibility(View.GONE);
        TextView st2 = mono(a, "", 11, DIM);
        st2.setLines(2);
        st2.setMaxLines(2);
        st2.setEllipsize(android.text.TextUtils.TruncateAt.END);
        panel.addView(st2, lp(-1, -2, 0, 6, 0, 4));
        final LinearLayout tabRow = row(a);
        final TextView[] tabs = new TextView[3];
        for (int t = 0; t < 3; t++) {
            tabs[t] = button(a, "", false);
            tabs[t].setPadding(dp(4), dp(7), dp(4), dp(7));
            tabs[t].setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            tabRow.addView(tabs[t], lpw(1f, t == 0 ? 0 : 3, 0, t == 2 ? 0 : 3, 0));
        }
        panel.addView(tabRow, lp(-1, -2, 0, 0, 0, 3));
        final TextView fi = mono(a, "", 11, TEXT);
        if (fi instanceof I18nTextView) ((I18nTextView) fi).noTranslate();   // painel DADOS: texto de dados, nao traduzir
        fi.setBackgroundColor(0xFF161A21);
        fi.setPadding(dp(8), dp(6), dp(8), dp(6));
        fi.setLines(8);                       // altura fixa: o texto rola, a preview nao muda de tamanho
        fi.setMaxLines(8);
        fi.setHorizontallyScrolling(true);
        fi.setMovementMethod(new android.text.method.ScrollingMovementMethod());
        android.widget.FrameLayout box = new android.widget.FrameLayout(a);
        box.addView(fi, new android.widget.FrameLayout.LayoutParams(-1, -2));
        final TextView pencil = new I18nTextView(a);
        pencil.setText("\u270E");
        pencil.setGravity(Gravity.CENTER);
        pencil.setTextColor(Color.WHITE);
        pencil.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        GradientDrawable oval = new GradientDrawable();
        oval.setShape(GradientDrawable.OVAL);
        oval.setColor(ACCENT);
        setBg(pencil, oval);
        pencil.setClickable(true);
        android.widget.FrameLayout.LayoutParams plp = new android.widget.FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM | Gravity.END);
        plp.setMargins(0, 0, dp(8), dp(8));
        box.addView(pencil, plp);
        panel.addView(box, lp(-1, -2, 0, 0, 0, 2));
        sc.addView(panel, lp(-1, -2, 0, 0, 0, 0));

        // ---- seletores (ficam fora da tela; os icones abrem listas que escolhem neles)

        // ---- slider horizontal de icones (letra + texto)
        final android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        final android.widget.HorizontalScrollView[] hsRef = new android.widget.HorizontalScrollView[1];
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout strip = new LinearLayout(a);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(strip, new ViewGroup.LayoutParams(-2, -2));
        final android.widget.FrameLayout bottom = new android.widget.FrameLayout(a);
        bottom.addView(hs, new android.widget.FrameLayout.LayoutParams(-1, -2));
        final TimelineTools[] toolsRef = new TimelineTools[1];
        final Runnable closeTools = new Runnable() {
            @Override public void run() {
                tl.clearSelection();
                toolsRef[0].hideSheet();
            }
        };
        final Runnable changed = new Runnable() {
            @Override public void run() {
                tl.setSeqMarks(view.sequenceMarks());
                tl.setState(view.currentAno(), view.currentPat(), view.currentElapsed(), view.isPlaying());
                if (panelOpen) { statusLine.setText(view.status()); refreshInfo(false); }
            }
        };
        flowChanged = changed;
        flowAct = a;
        final TimelineTools tools = new TimelineTools(a, view, tl, changed, closeTools);
        toolsRef0 = tools;
        toolsRef[0] = tools;
        hsRef[0] = hs;
        // gaveta entre a area que rola e a barra de controle (que continua na base)
        // gaveta flutuante (modo Y): fica por cima de tudo, ancorada acima da barra de controle
        final android.widget.FrameLayout frame = new android.widget.FrameLayout(a);
        final android.content.SharedPreferences sheetPrefs = a.getSharedPreferences("sheet", Context.MODE_PRIVATE);
        final boolean[] tMode = {false};
        final boolean[] tActive = {false};      // layout T aplicado agora (T ligado E gaveta aberta)
        final LinearLayout tlFixed = new LinearLayout(a);
        tlFixed.setOrientation(LinearLayout.VERTICAL);
        final View[] tlStack = {timeline, bar, tlBox};
        final Runnable placeSheet = new Runnable() { public void run() {
            ViewGroup.LayoutParams lpS = tools.root.getLayoutParams();
            if (lpS instanceof android.widget.FrameLayout.LayoutParams) {
                android.widget.FrameLayout.LayoutParams fp = (android.widget.FrameLayout.LayoutParams) lpS;
                int bm = Math.max(0, frame.getHeight() - transport.getTop());
                if (fp.bottomMargin != bm || fp.gravity != Gravity.BOTTOM) { fp.bottomMargin = bm; fp.gravity = Gravity.BOTTOM; tools.root.setLayoutParams(fp); }
            }
        } };
        transport.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r2, int b, int ol, int ot, int or2, int ob) { placeSheet.run(); }
        });
        // modo T: quanto mais o menu sobe, menos faixas da timeline ficam visiveis (6 -> 2); fora dele, sem limite
        final Runnable lanes = new Runnable() { public void run() {
            tl.setLaneLimit(tActive[0] ? TimelineView.lanesFor(tools.sheetFraction()) : 0);
        } };
        final Runnable applyMode = new Runnable() { public void run() {
            boolean t = tActive[0];
            ViewGroup oldParent = (ViewGroup) tools.root.getParent();
            if (oldParent != null) oldParent.removeView(tools.root);
            for (View v : tlStack) { ViewGroup pv = (ViewGroup) v.getParent(); if (pv != null) pv.removeView(v); }
            if (tlFixed.getParent() != null) ((ViewGroup) tlFixed.getParent()).removeView(tlFixed);
            tlFixed.removeAllViews();
            LinearLayout.LayoutParams hp = (LinearLayout.LayoutParams) holder.getLayoutParams();
            if (t) {
                for (View v : tlStack) tlFixed.addView(v);
                r.addView(tlFixed, r.indexOfChild(holder) + 1, new LinearLayout.LayoutParams(-1, -2));
                hp.height = 0; hp.weight = 1f;
                r.addView(tools.root, r.indexOfChild(transport), new LinearLayout.LayoutParams(-1, dp(240)));
                scroll.setVisibility(View.GONE);
                tl.setMaxHeightPx(0);
            } else {
                sc.addView(tlStack[0], 0, lp(-1, -2, 0, 4, 0, 4));
                sc.addView(tlStack[1], 1, lp(-1, -2, 0, 0, 0, 4));
                sc.addView(tlStack[2], 2, lp(-1, -2, 0, 0, 0, 6));
                hp.height = ViewGroup.LayoutParams.WRAP_CONTENT; hp.weight = 0f;
                frame.addView(tools.root, new android.widget.FrameLayout.LayoutParams(-1, dp(240), Gravity.BOTTOM));
                scroll.setVisibility(View.VISIBLE);
            }
            holder.setLayoutParams(hp);
            topGroup.setVisibility(t ? View.GONE : View.VISIBLE);
            lanes.run();
            frame.post(new Runnable() { public void run() { placeSheet.run(); tools.refit(); } });
        } };
        // o layout T so vale com T ligado e a gaveta aberta; fechada, tudo (menu superior, rolagem, timeline) volta ao normal
        final Runnable syncMode = new Runnable() { public void run() {
            boolean want = tMode[0] && tools.sheetOpen();
            tools.setTOn(tMode[0]);
            if (want != tActive[0]) { tActive[0] = want; applyMode.run(); }
            else lanes.run();
        } };
        tools.setOnSheetResize(syncMode);
        tools.setGeometry(new TimelineTools.Geo() {
            @Override public int maxH() {
                if (tMode[0]) return Math.max(dp(160), frame.getHeight() / 2);
                return Math.max(dp(160), transport.getTop() - r.getPaddingTop());
            }
            @Override public int defH() {
                int saved = sheetPrefs.getInt(tMode[0] ? "tH" : "yH", 0);
                if (saved > 0) return Math.min(saved, maxH());
                if (tMode[0]) return Math.min(maxH(), Math.max(dp(220), (int) (frame.getHeight() * 0.40f)));
                int toPreview = transport.getTop() - holder.getBottom();       // sobe ate a base da preview
                return Math.min(maxH(), toPreview > dp(120) ? toPreview : dp(240));
            }
        }, new Runnable() { public void run() {
            int h = tools.root.getHeight();
            if (h > 0) {
                sheetPrefs.edit().putInt(tMode[0] ? "tH" : "yH", h).apply();
                I18nUi.toast(a, "Altura padrão do menu salva", android.widget.Toast.LENGTH_SHORT).show();
            }
        } }, new Runnable() { public void run() { tMode[0] = !tMode[0]; syncMode.run(); } });
        // o modo T nunca e salvo: o app sempre abre com ele desligado (nao afeta o menu superior)
        frame.post(new Runnable() { public void run() { placeSheet.run(); } });
        tools.setSheetHost(scroll, new Runnable() {
            @Override public void run() {
                tl.clearSelection();
                tools.hideSheet();
                I18nUi.toast(a, "Aplicado", android.widget.Toast.LENGTH_SHORT).show();
            }
        }, new Runnable() {
            @Override public void run() {
                tl.clearSelection();
                int n = tools.discardSession();
                if (n > 0) I18nUi.toast(a, "Alteracoes descartadas (use APLICAR para manter)", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        final TimelineOps[] endOps = new TimelineOps[1];
        final TimelineOps ops = new TimelineOps(view, tl, new TimelineOps.Host() {
            @Override public void show(int type, int index, int flag, int occ) {
                tl.select(type, index, flag, occ);
                if (type == TimelineView.T_SPRITE) tools.gridFirst();
                tools.show(type, index, flag, occ);
                tools.openSheet();
            }
            @Override public void closeTools() { closeTools.run(); }
            @Override public void cancelTools() {
                tl.clearSelection();
                if (!tools.sheetOpen()) return;
                int n = tools.discardSession();
                if (n > 0) I18nUi.toast(a, "Alteracoes descartadas (use APLICAR para manter)", android.widget.Toast.LENGTH_SHORT).show();
            }
            @Override public void toast(String msg) { I18nUi.toast(a, msg, android.widget.Toast.LENGTH_SHORT).show(); }
            @Override public void endMenu() { showEndMenu(a, tl, endOps[0]); }
            @Override public void openFlow() { LayoutManager.this.openFlow(); }
            @Override public void pickSprites(SpriteListScreen.MultiListener l) {
                AttackData ad = view.attackData();
                if (ad == null || ad.attacker == null) return;
                SpriteListScreen.showMulti(a, ad.attacker.dir.getName(), ad.attacker, new Runnable() {
                    @Override public void run() { view.refreshAfterExternalEdit(); tl.invalidate(); changed.run(); }
                }, l);
            }
            @Override public void openAnoMenu() {
                AttackData ad = view.attackData();
                if (ad == null || ad.attacker == null) return;
                AnoMenu.show(a, view, ad.attacker, endOps[0]);
            }
            @Override public void showImagePage(int index) {
                tl.select(TimelineView.T_SPRITE, index, -1, -1);
                tools.imageFirst();
                tools.show(TimelineView.T_SPRITE, index, -1, -1);
                tools.openSheet();
            }
            @Override public void choose(String title, String[] items, final TimelineOps.Pick pick) {
                new I18nBuilder(a).setTitle(title).setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { pick.on(which); }
                }).show();
            }
        });
        endOps[0] = ops;
        tl.setListener(ops);
        bSplit.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ops.split(); } });
        plus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showAddPopup(a, plus, ops); } });
        bDup.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ops.duplicateSelected(); } });
        bDel.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ops.deleteSelected(); } });
        // com um menu aberto, desfazer/refazer valem so para ele; sem menu, para as acoes e os menus ja aplicados (cada menu inteiro e um passo)
        bUndo.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            boolean inMenu = view.inUndoSession();
            if (view.undoEdit()) { if (inMenu) tools.refresh(); else closeTools.run(); undoButtonsRefresh(); }
            else I18nUi.toast(a, "nada para desfazer", android.widget.Toast.LENGTH_SHORT).show();
        } });
        bRedo.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            boolean inMenu = view.inUndoSession();
            if (view.redoEdit()) { if (inMenu) tools.refresh(); else closeTools.run(); undoButtonsRefresh(); }
            else I18nUi.toast(a, "nada para refazer", android.widget.Toast.LENGTH_SHORT).show();
        } });
        undoBtns[0] = bUndo;
        undoBtns[1] = bRedo;
        timelineRef = tl;
        sc.addView(bottom, lp(-1, -2, 0, 6, 0, 0));

        // ---- estados da preview (um so lugar: botoes dedicados e o menu TELA ficam sincronizados)
        final boolean[] on = {true, true, false, true, BattleSim.cutscenes, BattleSim.cinematic, BattleSim.extendTime, true, false};
        final int[] timeMode = {BattleSim.attackStop ? 2 : BattleSim.extendTime ? 1 : 0};
        final String[] onNames = {"Grade", "Hitboxes", "Links", "Sons", "Cenas (cutscenes)", "Travar (cinematico)", "Tempo estendido", "Borda da tela", "Virar atacante"};
        final TextView[] btnOf = {bGrid, bHit, null, null, null, null, bTime, null, bFlip};
        final IntBool apply = new IntBool() {
            @Override public void set(int id, boolean v) {
                on[id] = v;
                switch (id) {
                    case 0: view.setShowGrid(v); break;
                    case 1: view.setShowHits(v); break;
                    case 2: view.setShowLinks(v); break;
                    case 3: view.setSoundOn(v); break;
                    case 4: view.setCutscenes(v); break;
                    case 5: view.setCinematic(v); break;
                    case 6: break;     // tempo: setTimeMode (botao TEMPO)
                    case 7: break;     // borda da tela: sempre ativa (comportamento do jogo)
                    default: view.setFacingLeft(v); break;
                }
                if (btnOf[id] != null) setChecked(btnOf[id], v);
            }
        };
        for (int q = 0; q < on.length; q++) apply.set(q, on[q]);
        bGrid.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { apply.set(0, !on[0]); } });
        bHit.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { apply.set(1, !on[1]); } });
        bTime.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            timeMode[0] = (timeMode[0] + 1) % 3;
            view.setTimeMode(timeMode[0]);
            on[6] = timeMode[0] != 0;
            bTime.setText(timeMode[0] == 0 ? "TEMPO: NORMAL" : timeMode[0] == 1 ? "TEMPO: ESTENDIDO" : "TEMPO: ATAQUE");
            setChecked(bTime, timeMode[0] != 0);
        } });
        bHide.setOnClickListener(new View.OnClickListener() {
            boolean h;
            @Override public void onClick(View v) { h = !h; view.setHideEff(h); setChecked(bHide, h); }
        });
        bSave.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showSaveMenu(a, view); } });
        bHelp.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showHelp(a); } });
        toolbar.hintOnce();
        bLinks.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            LinkScreen.show(a, view, new Runnable() { @Override public void run() { if (timelineRef != null) timelineRef.invalidate(); } });
        } });
        bSpr.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showSpritePacks(a, view); } });
        bSnd.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            AttackData sd = view.attackData();
            if (sd == null || sd.attacker == null || sd.attacker.dir == null) { I18nUi.toast(a, "Carregue um personagem para gerenciar os sons", android.widget.Toast.LENGTH_SHORT).show(); return; }
            SoundDialog.show(a, view, sd.attacker.dir, -1, null);       // so gerenciar: sem "Usar este som"
        } });
        bFlip.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { apply.set(8, !on[8]); } });
        setChecked(bLand, BattleSim.landingOn);
        bLand.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !view.isLanding();
                view.setLanding(on);
                bLand.setText(on ? "POUSO: ON" : "POUSO: OFF");
                setChecked(bLand, on);
            }
        });
        bLock.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                lockTrans = !lockTrans;
                // travar desativa o POUSO (da pra ligar de novo); destravar devolve o estado anterior
                if (lockTrans) { landBeforeLock = view.isLanding(); BattleSim.landingOn = false; }
                else BattleSim.landingOn = landBeforeLock;
                bLand.setText(BattleSim.landingOn ? "POUSO: ON" : "POUSO: OFF");
                setChecked(bLand, BattleSim.landingOn);
                view.setLockTransitions(lockTrans);
                bLock.setText(lockTrans ? "TRANSICAO: TRAVADA" : "TRANSICAO: LIVRE");
                setChecked(bLock, lockTrans);
                if (!lockTrans) stopLockBlink();
            }
        });
        view.setLockOffRequest(new Runnable() { public void run() {
            if (!lockTrans) return;
            lockTrans = false;
            BattleSim.landingOn = landBeforeLock;
            bLand.setText(BattleSim.landingOn ? "POUSO: ON" : "POUSO: OFF");
            setChecked(bLand, BattleSim.landingOn);
            view.setLockTransitions(false);
            bLock.setText("TRANSICAO: LIVRE");
            setChecked(bLock, false);
            view.hideNotice();
        } });
        bCtr.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int m = (view.getCenterMode() + 1) % 3;
                view.setCenterMode(m);
                bCtr.setText(m == 0 ? "CENTRO: NORMAL" : m == 1 ? "CENTRO: TELA" : "CENTRO: CHAR");
                setChecked(bCtr, m != 0);
                if (m == 0) view.recenter();
            }
        });
        final boolean[] spriteBoxesOn = {false};
        bScr.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                // so o que nao tem botao dedicado: grade, sons, cenas, travar (links fica no CHAR OBJ)
                final int[] ids = {0, 3, 4, 5};
                String[] names = new String[ids.length];
                boolean[] checked = new boolean[ids.length];
                for (int k = 0; k < ids.length; k++) { names[k] = onNames[ids[k]]; checked[k] = on[ids[k]]; }
                LinearLayout tbox = new LinearLayout(a);
                tbox.setOrientation(LinearLayout.VERTICAL);
                tbox.setPadding(dp(16), dp(8), dp(16), dp(8));
                for (int k = 0; k < ids.length; k++) {
                    final int id = ids[k];
                    android.widget.CheckBox cb = new I18nCheckBox(a);
                    cb.setText(names[k]);
                    cb.setTextColor(TEXT);
                    cb.setChecked(checked[k]);
                    cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                        @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean isOn) { apply.set(id, isOn); }
                    });
                    tbox.addView(cb);
                }
                android.widget.CheckBox cbBox = new I18nCheckBox(a);
                cbBox.setText("Box dos sprites (amarela, bordas de todas as sprites)");
                cbBox.setTextColor(0xFFFFE04C);
                cbBox.setChecked(spriteBoxesOn[0]);
                cbBox.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean isOn) { spriteBoxesOn[0] = isOn; view.setSpriteBoxes(isOn); }
                });
                tbox.addView(cbBox);
                // SPEEDLINE: so a caixa (liga/desliga o ponto e a seta do Frame atual)
                android.widget.CheckBox cbSpl = new I18nCheckBox(a);
                cbSpl.setText("SPEEDLINE");
                cbSpl.setTextColor(0xFF3DDC84);
                cbSpl.setChecked(view.isSpeedLine());
                cbSpl.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean isOn) { view.setSpeedLine(isOn); }
                });
                tbox.addView(cbSpl, lp(-1, -2, 0, 8, 0, 0));
                // FR-PREVIEW | caixa: a caixa liga/desliga; tocar no corpo abre as opcoes (FR-PREVIEW SET)
                LinearLayout gRow = new LinearLayout(a);
                gRow.setGravity(Gravity.CENTER_VERTICAL);
                TextView bGs = button(a, "FR-PREVIEW", false);
                bGs.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View vv) { showGhostSet(a, view); }
                });
                final android.widget.CheckBox cbGhost = new I18nCheckBox(a);
                cbGhost.setChecked(view.getGhostMode() != 0);
                cbGhost.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean isOn) { view.setGhostMode(isOn ? ghostLast : 0); }
                });
                gRow.addView(bGs, new LinearLayout.LayoutParams(0, -2, 1f));
                gRow.addView(cbGhost, new LinearLayout.LayoutParams(-2, -2));
                tbox.addView(gRow, lp(-1, -2, 0, 8, 0, 0));
                // POSE: desenha o ANO 0 (parado) por baixo, na mesma ancora do golpe, para comparar altura e tamanho
                final TextView bPose = button(a, view.isPose() ? "POSE: ON" : "POSE: OFF", false);
                setChecked(bPose, view.isPose());
                bPose.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View vv) {
                        boolean now = !view.isPose();
                        view.setPose(now);
                        bPose.setText(now ? "POSE: ON" : "POSE: OFF");
                        setChecked(bPose, now);
                    }
                });
                tbox.addView(bPose, lp(-1, -2, 0, 8, 0, 0));
                android.widget.ScrollView tsv = new SafeScrollView(a);
                tsv.addView(tbox);
                new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Tela da preview")
                        .setView(tsv).setPositiveButton("OK", null).show();
            }
        });
        // ---- CHAR OBJ: box branca do objeto do jogador (HDAT 3) + ancoras + links
        final boolean[] objOn = {false};
        final boolean[] anch = {true, true, true, false, true};
        final boolean[] anchBox = {false};       // sprite, hurtbox, hitbox, efeitos/animacoes
        final Runnable applyObj = new Runnable() { @Override public void run() {
            view.setCharObj(objOn[0]);
            view.setAnchorBox(anchBox[0]);
            view.setAnchors(objOn[0] && anch[0], objOn[0] && anch[1], objOn[0] && anch[2], objOn[0] && anch[3], objOn[0] && anch[3], objOn[0] && anch[4]);
            view.setShowLinks(objOn[0] && on[2]);
        } };
        final Runnable showObjOptions = new Runnable() { @Override public void run() {
            LinearLayout ob = new LinearLayout(a);
            ob.setOrientation(LinearLayout.VERTICAL);
            ob.setPadding(dp(16), dp(8), dp(16), dp(8));
            android.widget.RadioGroup rg = new android.widget.RadioGroup(a);
            rg.setOrientation(LinearLayout.VERTICAL);
            android.widget.RadioButton rA = new android.widget.RadioButton(a), rB = new android.widget.RadioButton(a);
            rA.setText("Apenas Âncora"); rB.setText("Âncora e Box");
            rA.setTextColor(TEXT); rB.setTextColor(TEXT);
            rA.setId(7001); rB.setId(7002);
            rg.addView(rA); rg.addView(rB);
            rg.check(anchBox[0] ? rB.getId() : rA.getId());
            final int idB = rB.getId();
            rg.setOnCheckedChangeListener(new android.widget.RadioGroup.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(android.widget.RadioGroup g, int id) { anchBox[0] = id == idB; applyObj.run(); }
            });
            ob.addView(rg, lp(-1, -2, 0, 0, 0, 6));
            final String[] nm = {"Âncora dos sprites (amarelo)", "Âncora das hurtboxes (azul)", "Âncora das hitboxes (vermelho)", "Âncora dos efeitos/animações (cinza) e globais (roxo)", "Âncora dos projéteis (laranja)"};
            for (int k = 0; k < nm.length; k++) {
                final int kk = k;
                android.widget.CheckBox cb = new I18nCheckBox(a);
                if (k == 3) {
                    android.text.SpannableString sp = new android.text.SpannableString(nm[k]);
                    int g = nm[k].indexOf("cinza"), pu = nm[k].indexOf("roxo");
                    sp.setSpan(new android.text.style.ForegroundColorSpan(0xFFA0A4AC), 0, g + 6, 0);
                    sp.setSpan(new android.text.style.ForegroundColorSpan(0xFFB05CFF), g + 6, nm[k].length(), 0);
                    cb.setText(sp);
                } else cb.setText(nm[k]);
                cb.setTextColor(new int[]{0xFFFFE04C, 0xFF3C8CFF, 0xFFFF3C3C, 0xFFA0A4AC, 0xFFFF9A3C}[k]); cb.setChecked(anch[k]);
                cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean v) { anch[kk] = v; applyObj.run(); }
                });
                ob.addView(cb);
            }
            android.widget.CheckBox cl = new I18nCheckBox(a);
            cl.setText("Links (linhas e pontos entre objetos)"); cl.setTextColor(0xFF7CFFB2); cl.setChecked(on[2]);
            cl.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean v) { on[2] = v; applyObj.run(); }
            });
            ob.addView(cl);
            final AttackData ad = view.attackData();
            TextView t = mono(a, "Tamanho do corpo (HDAT 3 do atacante). A largura é sempre par: o .txt guarda a metade.", 11, DIM);
            ob.addView(t, lp(-1, -2, 0, 12, 0, 4));
            if (ad == null) { ob.addView(mono(a, "nada carregado", 12, DIM)); }
            else {
                final android.widget.EditText ew = new android.widget.EditText(a), eh = new android.widget.EditText(a);
                for (android.widget.EditText e : new android.widget.EditText[]{ew, eh}) {
                    e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                    e.setTextColor(TEXT); e.setSelectAllOnFocus(true);
                }
                ew.setText(String.valueOf(ad.attacker.data.bodyWidth()));
                eh.setText(String.valueOf(ad.attacker.data.bodyHeight()));
                LinearLayout r2 = new LinearLayout(a);
                LinearLayout c1 = new LinearLayout(a); c1.setOrientation(LinearLayout.VERTICAL);
                c1.addView(mono(a, "LARGURA", 10, DIM)); c1.addView(ew);
                LinearLayout c2 = new LinearLayout(a); c2.setOrientation(LinearLayout.VERTICAL);
                c2.addView(mono(a, "ALTURA", 10, DIM)); c2.addView(eh);
                r2.addView(c1, new LinearLayout.LayoutParams(0, -2, 1f));
                r2.addView(c2, new LinearLayout.LayoutParams(0, -2, 1f));
                ob.addView(r2);
                TextView ap = button(a, "APLICAR TAMANHO", false);
                ap.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) {
                    int w, h;
                    try { w = Integer.parseInt(ew.getText().toString().trim()); h = Integer.parseInt(eh.getText().toString().trim()); }
                    catch (NumberFormatException ex) { I18nUi.toast(a, "números inválidos", android.widget.Toast.LENGTH_SHORT).show(); return; }
                    ad.attacker.data.setBody(w, h);
                    view.refreshAfterExternalEdit();
                    ew.setText(String.valueOf(ad.attacker.data.bodyWidth()));
                    I18nUi.toast(a, "HDAT 3 alterado (salve para gravar no 000.bin.txt)", android.widget.Toast.LENGTH_SHORT).show();
                } });
                ob.addView(ap, lp(-1, -2, 0, 8, 0, 0));
            }
            android.widget.ScrollView osv = new SafeScrollView(a);
            osv.addView(ob);
            new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("CHAR OBJ")
                    .setView(osv).setPositiveButton("OK", null).show();
        } };
        bChar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                LinearLayout box = new LinearLayout(a);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(16), dp(8), dp(16), dp(8));
                final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
                TextView bA = button(a, "ATACANTE:  " + cs.getSelectedItem(), false);
                bA.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { dlg[0].dismiss(); openPicker(a, "Atacante", cs); } });
                TextView bO = button(a, "OPONENTE:  " + os.getSelectedItem(), false);
                bO.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { dlg[0].dismiss(); openPicker(a, "Oponente", os); } });
                LinearLayout oppRow = new LinearLayout(a);                 // OPONENTE: charNN | DEF (o oponente defende, desligado por padrao)
                oppRow.setGravity(Gravity.CENTER_VERTICAL);
                final android.widget.CheckBox cbDef = new I18nCheckBox(a);
                cbDef.setText("DEF");
                cbDef.setTextColor(TEXT);
                cbDef.setChecked(view.isDefend());
                cbDef.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean v) { view.setDefend(v); }
                });
                oppRow.addView(bO, new LinearLayout.LayoutParams(0, -2, 1f));
                oppRow.addView(cbDef, new LinearLayout.LayoutParams(-2, -2));
                TextView bP = button(a, "POS (posição / distância)", false);
                bP.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { dlg[0].dismiss(); showPosDialog(a); } });
                LinearLayout objRow = new LinearLayout(a);
                objRow.setGravity(Gravity.CENTER_VERTICAL);
                TextView bObj = button(a, "CHAR OBJ  (box branca + âncoras)", false);
                bObj.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { dlg[0].dismiss(); showObjOptions.run(); } });
                final android.widget.CheckBox cbObj = new I18nCheckBox(a);
                cbObj.setChecked(objOn[0]);
                cbObj.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean v) { objOn[0] = v; applyObj.run(); }
                });
                objRow.addView(bObj, new LinearLayout.LayoutParams(0, -2, 1f));
                objRow.addView(cbObj, new LinearLayout.LayoutParams(-2, -2));
                box.addView(objRow, lp(-1, -2, 0, 0, 0, 8));
                box.addView(bA, lp(-1, -2, 0, 0, 0, 8));
                box.addView(oppRow, lp(-1, -2, 0, 0, 0, 8));
                box.addView(bP, lp(-1, -2, 0, 0, 0, 8));
                TextView bCs = button(a, "CUTSCENES (HDAT 13)", false);
                bCs.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { dlg[0].dismiss(); CutsceneScreen.show(a, view, 0, null); } });
                box.addView(bCs, lp(-1, -2, 0, 0, 0, 0));
                dlg[0] = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Personagens").setView(box).setNegativeButton("FECHAR", null).create();
                dlg[0].show();
            }
        });
        view.setPosRequest(new Runnable() { public void run() { showPosDialog(a); } });
        bOpt.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMoveOptions(a); }
        });

        handleRef = handle;
        handle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                panelOpen = !panelOpen;
                if (!panelOpen) attackView.stopSounds();
                panel.setVisibility(panelOpen ? View.VISIBLE : View.GONE);
                handle.setText(panelOpen ? "\u25BC  FECHAR DADOS" : "\u25B2  DADOS / EDITAR");
                if (panelOpen) {
                    statusLine.setText(attackView.status());
                    updateTabs();
                    refreshInfo(true);
                }
            }
        });
        pencil.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openEditor(a); }
        });

        // ---- ligacoes (so mexem no AttackView)
        play.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { view.togglePlay(); }
        });
        bReset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { view.pause(); view.restart(); }
        });
        bBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { view.stepBack(); }
        });
        bFwd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { view.stepForward(); }
        });
        speed.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { nextSpeed(view, (TextView) v); }
        });
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) { view.pause(); view.seekTo(p); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) { view.pause(); }
            @Override public void onStopTrackingTouch(SeekBar s) { view.finishSeek(); }
        });
        view.setListener(new AttackView.Listener() {
            @Override public void onFrame(int frame, int length, boolean playing) {
                onFrameChanged(frame, length, playing);
            }
        });

        frame.addView(r, new android.widget.FrameLayout.LayoutParams(-1, -1));
        frame.addView(tools.root, new android.widget.FrameLayout.LayoutParams(-1, dp(240), Gravity.BOTTOM));
        root = frame;
        characterSpinner = cs;
        attackSpinner = as;
        opponentSpinner = os;
        listModeChip = modeBtn;
        status = st;
        info = in;
        frameInfo = fi;
        infoTabs = tabs;
        statusLine = st2;
        editBtn = pencil;
        warning = wr;
        frameLabel = label;
        seek = sb;
        btnPlay = play;
        attackView = view;
    }

    /** SPRITES: lista de sprites do personagem atacante atual. */
    private void showSpritePacks(final Activity a, final AttackView view) {
        final AttackData d = view.attackData();
        if (d == null) { I18nUi.toast(a, "nada carregado", android.widget.Toast.LENGTH_SHORT).show(); return; }
        view.pause();
        SpriteListScreen.show(a, d.attacker.dir.getName(), d.attacker, -1, null, new Runnable() {
            @Override public void run() { view.refreshAfterExternalEdit(); if (timelineRef != null) timelineRef.invalidate(); }
        });
    }

    /** Menu flutuante SALVAR: escolhe o que salvar e depois onde (pasta separada ou Runtime = .txt de origem). */
    /** Linha do menu superior com a ordem editavel (ReorderBar). */
    private ReorderBar toolbar;

    /** Abre o link no app do YouTube; sem ele, no navegador. */
    private static void openLink(Activity a, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setPackage("com.google.android.youtube");
            i.setData(Uri.parse(url));
            a.startActivity(i);
        } catch (Exception e) {
            try {
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse(url));
                a.startActivity(i2);
            } catch (Exception e2) {
                I18nUi.toast(a, "Nao foi possivel abrir o link", android.widget.Toast.LENGTH_SHORT).show();
            }
        }
    }

    /** AJUDA: o que cada botao do menu e da tela faz. */
    private void showHelp(final Activity a) {
        new HelpScreen(a, new Runnable() { @Override public void run() { toolbar.reset(); } }).show();
    }

    private void showSaveMenu(final Activity a, final AttackView view) {
        final AttackData d = view.attackData();
        if (d == null) { I18nUi.toast(a, "nada carregado", android.widget.Toast.LENGTH_SHORT).show(); return; }
        String[] items = {"Salvar golpe atual (HDAT 4 + ANOs)", "Salvar ANO atual", "Salvar todos os golpes", "Salvar todos os ANOs", "Salvar tudo"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Salvar (.txt)")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { askWhere(a, view, d, which); }
                }).setNegativeButton("FECHAR", null).show();
    }

    private void askWhere(final Activity a, final AttackView view, final AttackData d, final int which) {
        final File dir = d.attacker.dir;
        String[] items = which == 0
                ? new String[]{"Salvar em pasta separada\n(Tap Battle/" + Saver.TBRE + "/Chars/" + dir.getName() + "/)",
                        "Salvar no Runtime\n(Tap Battle/assets/" + dir.getName() + "/)",
                        "Salvar em outro personagem (Runtime)"}
                : new String[]{"Salvar em pasta separada\n(Tap Battle/" + Saver.TBRE + "/Chars/" + dir.getName() + "/)",
                        "Salvar no Runtime\n(Tap Battle/assets/" + dir.getName() + "/)"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Salvar onde?")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int where) {
                        if (where == 2) startTransplant(a, view, d); else doSave(a, view, d, which, where == 1);
                    }
                }).setNegativeButton("VOLTAR", null).show();
    }

    /** Chamado antes de gravar (ex.: desfaz o frame provisorio de uma ANO vazia que ninguem editou). */
    public Runnable beforeSave;

    /** Botao ↻ da barra de titulo: recarregar as pastas (a MainActivity confirma e refaz a leitura). */
    public Runnable onReload;

    private void doSave(final Activity a, AttackView view, final AttackData d, final int which, boolean runtime) {
        if (beforeSave != null) beforeSave.run();
        try {
            File dir = d.attacker.dir;
            Dac dac = d.attacker.dac;
            CharData cd = d.attacker.data;
            CharData.Move m = d.move;
            int idx = d.moveIndex;
            if ((which == 0) && m.generic) {
                CharData.Move own = cd.ownerOf(d.moveIndex);
                if (own == null || own.generic) { I18nUi.toast(a, "este ANO nao pertence a nenhum golpe: use Salvar ANO atual", android.widget.Toast.LENGTH_LONG).show(); return; }
                m = own;
                idx = java.util.Arrays.asList(cd.moves).indexOf(own);
            }
            Ano cur = view.currentAno();
            final int ai = cur != null ? cur.index : d.move.animInicial;
            final int mi = idx;
            if (runtime) {
                I18nUi.toast(a, "Salvo no Runtime: " + Saver.saveInto(dir, dac, cd, which, mi, ai), android.widget.Toast.LENGTH_LONG).show();
                return;
            }
            // pasta separada: copia completa do personagem em Tap Battle/TBRE/Chars/charNN e a mesma gravacao do Runtime nela
            final File dest = Saver.separateDir(dir, dir.getName());
            if (!dest.exists()) { runSeparateSave(a, d, which, mi, ai, dest, false); return; }
            askExistingCopy(a, d, which, mi, ai, dest);
        } catch (Exception e) {
            I18nUi.toast(a, "Erro ao salvar: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
        }
    }

    /** A pasta separada ja existe: unir (aplica por cima, sem sobrescrever o que ja esta la), deletar e copiar de novo, ou salvar com outro nome. */
    private void askExistingCopy(final Activity a, final AttackData d, final int which, final int mi, final int ai, final File dest) {
        final File dir = d.attacker.dir;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("A pasta já existe")
                .setMessage(dest.getPath() + "\n\nUNIR: mantém os arquivos que já estão lá, copia só o que falta e aplica este salvamento por cima (o que você salvou antes continua).\n"
                        + "DELETAR: apaga a pasta e copia o personagem de novo.\nOUTRO NOME: salva numa pasta nova.")
                .setPositiveButton("UNIR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { runSeparateSave(a, d, which, mi, ai, dest, true); }
                })
                .setNeutralButton("DELETAR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) {
                        try {
                            if (!Saver.isSeparateCopy(dest)) throw new java.io.IOException("so apago pastas dentro de TBRE/Chars");
                            Saver.deleteTree(dest);
                        } catch (Exception e) { I18nUi.toast(a, "Erro ao apagar: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show(); return; }
                        runSeparateSave(a, d, which, mi, ai, dest, false);
                    }
                })
                .setNegativeButton("OUTRO NOME", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { askNewName(a, d, which, mi, ai, Saver.freeName(dir, dir.getName())); }
                }).show();
    }

    private void askNewName(final Activity a, final AttackData d, final int which, final int mi, final int ai, String suggestion) {
        final android.widget.EditText et = new android.widget.EditText(a);
        et.setText(suggestion);
        et.setSingleLine(true);
        et.setSelectAllOnFocus(true);
        et.setTextColor(TEXT);
        LinearLayout box = new LinearLayout(a);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Nome da pasta em TBRE/Chars").setView(box)
                .setPositiveButton("SALVAR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) {
                        String name = et.getText().toString().trim().replaceAll("[^A-Za-z0-9_.\\- ]", "_");
                        if (name.isEmpty() || name.equals(".") || name.equals("..")) { I18nUi.toast(a, "Nome inválido", android.widget.Toast.LENGTH_SHORT).show(); return; }
                        File dest = Saver.separateDir(d.attacker.dir, name);
                        if (dest.exists()) askExistingCopy(a, d, which, mi, ai, dest); else runSeparateSave(a, d, which, mi, ai, dest, false);
                    }
                }).setNegativeButton("CANCELAR", null).show();
    }

    private void runSeparateSave(final Activity a, final AttackData d, final int which, final int mi, final int ai, final File dest, final boolean merge) {
        final BusyDialog bd = BusyDialog.show(a, "Salvando em " + dest.getName());
        bd.set("Copiando o personagem...", 0, 0);
        new Thread(new Runnable() { @Override public void run() {
            String out;
            try {
                Saver.copyChar(d.attacker.dir, dest, merge, new Saver.CopyProgress() {
                    @Override public void on(String file, int done, int total) { bd.set(file, done, total); }
                });
                bd.set("Aplicando as mudanças...", 0, 0);
                out = "Cópia completa pronta para o Runtime em:\n" + dest.getPath() + "/\n\n" + Saver.saveInto(dest, d.attacker.dac, d.attacker.data, which, mi, ai);
            } catch (Exception e) {
                out = "Erro ao salvar em " + dest.getPath() + ": " + e.getMessage();
            }
            final String text = out;
            bd.dismiss();
            a.runOnUiThread(new Runnable() { @Override public void run() {
                TextView tv = text(a, text, 13, TEXT);
                tv.setPadding(dp(16), dp(8), dp(16), dp(8));
                android.widget.ScrollView sv = new SafeScrollView(a);
                sv.addView(tv);
                new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Salvar em pasta separada").setView(sv).setPositiveButton("OK", null).show();
            } });
        } }).start();
    }

    // ---- salvar este golpe em outro personagem ----

    /** Escolhe o personagem de destino (as pastas charNN de assets, menos o atual), depois o golpe a substituir, e grava direto no Runtime dele. */
    private void startTransplant(final Activity a, final AttackView view, final AttackData d) {
        if (beforeSave != null) beforeSave.run();
        final CharData cd = d.attacker.data;
        CharData.Move m = d.move;
        int idx = d.moveIndex;
        if (m.generic) {
            CharData.Move own = cd.ownerOf(d.moveIndex);
            if (own == null || own.generic) { I18nUi.toast(a, "este ANO nao pertence a nenhum golpe: nao ha golpe para levar", android.widget.Toast.LENGTH_LONG).show(); return; }
            m = own;
            idx = java.util.Arrays.asList(cd.moves).indexOf(own);
        }
        final CharData.Move move = m;
        final int srcIdx = idx;
        File root = d.attacker.dir.getParentFile();
        File[] fs = root == null ? null : root.listFiles();
        final java.util.ArrayList<File> chars = new java.util.ArrayList<File>();
        if (fs != null) for (File f : fs) if (f.isDirectory() && f.getName().matches("char\\d{2}") && !f.equals(d.attacker.dir)) chars.add(f);
        java.util.Collections.sort(chars);
        if (chars.isEmpty()) { I18nUi.toast(a, "Nenhum outro personagem em " + (root == null ? "assets" : root.getPath()), android.widget.Toast.LENGTH_LONG).show(); return; }
        String[] names = new String[chars.size()];
        for (int i = 0; i < names.length; i++) names[i] = chars.get(i).getName();
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Levar o GOLPE_" + String.format(java.util.Locale.US, "%02d", srcIdx) + " para qual personagem?")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { openTransplantTarget(a, view, d, move, srcIdx, chars.get(which)); }
                }).setNegativeButton("VOLTAR", null).show();
    }

    private void openTransplantTarget(final Activity a, final AttackView view, final AttackData d, final CharData.Move move, final int srcIdx, final File dir) {
        final BusyDialog bd = BusyDialog.show(a, "Abrindo " + dir.getName());
        bd.set(dir.getName(), 0, 0);
        new Thread(new Runnable() { @Override public void run() {
            CharAssets t = null;
            String err = null;
            try { t = CharAssets.loadChar(dir); } catch (Exception e) { err = e.getMessage(); }
            final CharAssets tgt = t;
            final String error = err;
            bd.dismiss();
            a.runOnUiThread(new Runnable() { @Override public void run() {
                if (tgt == null) { I18nUi.toast(a, "Erro ao abrir " + dir.getName() + ": " + error, android.widget.Toast.LENGTH_LONG).show(); return; }
                pickTransplantMove(a, view, d, move, srcIdx, tgt);
            } });
        } }).start();
    }

    private void pickTransplantMove(final Activity a, final AttackView view, final AttackData d, final CharData.Move move, final int srcIdx, final CharAssets tgt) {
        final java.util.ArrayList<Integer> slots = new java.util.ArrayList<Integer>();
        java.util.ArrayList<String> labels = new java.util.ArrayList<String>();
        for (int i = 0; i < tgt.data.moves.length; i++) {
            if (!MoveTransplant.canReplace(srcIdx, i)) continue;
            slots.add(Integer.valueOf(i));
            labels.add(String.format(java.util.Locale.US, "GOLPE_%02d  (ANIM_INICIAL %d)", i, tgt.data.moves[i].animInicial));
        }
        if (slots.isEmpty()) { tgt.release(); I18nUi.toast(a, "Nenhum golpe do destino pode ser substituído por este", android.widget.Toast.LENGTH_LONG).show(); return; }
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Qual golpe de " + tgt.dir.getName() + " substituir?")
                .setItems(labels.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { confirmTransplant(a, d, move, srcIdx, tgt, slots.get(which).intValue()); }
                })
                .setNegativeButton("CANCELAR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int w) { tgt.release(); }
                })
                .setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                    @Override public void onCancel(android.content.DialogInterface dlg) { tgt.release(); }
                }).show();
    }

    /** Etapa 1: copiar tambem as sprites? Nao => os ANOs entram com IMG -1 e o CNV/as folhas do destino nao mudam. */
    private void confirmTransplant(final Activity a, final AttackData d, final CharData.Move move, final int srcIdx, final CharAssets tgt, final int dstIdx) {
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Salvar também as Sprites?")
                .setMessage("SIM: as sprites usadas pelo golpe entram no fim do CNV e nas folhas de " + tgt.dir.getName() + ".\n"
                        + "NÃO: só os ANOs são copiados, com IMG -1 (sem imagem); o CNV e as folhas do destino não mudam. Dá para escolher as imagens depois.")
                .setPositiveButton("SIM", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int w) { chooseTransplantReactions(a, d, move, srcIdx, tgt, dstIdx, true); }
                })
                .setNeutralButton("NÃO", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int w) { chooseTransplantReactions(a, d, move, srcIdx, tgt, dstIdx, false); }
                })
                .setNegativeButton("CANCELAR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int w) { tgt.release(); }
                })
                .setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                    @Override public void onCancel(android.content.DialogInterface dlg) { tgt.release(); }
                }).show();
    }

    /** Etapa 2: reacao igual no destino => so o OPT 1 muda; vaga vazia => grava; sem nenhuma das duas => tela para escolher SUBSTITUIR / USAR ESSA. */
    private void chooseTransplantReactions(final Activity a, final AttackData d, final CharData.Move move, final int srcIdx, final CharAssets tgt, final int dstIdx, final boolean withSprites) {
        java.util.Set<Integer> writable = null;
        File binTxt = new File(tgt.dir, "000.bin.txt");
        if (binTxt.isFile()) { try { writable = Saver.writableReactionSlots(Saver.readText(binTxt)); } catch (Exception ignored) { } }
        final java.util.ArrayList<Integer> ask = new java.util.ArrayList<Integer>(MoveTransplant.needsChoice(d.attacker.dac, d.attacker.data, move, tgt.dac, tgt.data, writable));
        final java.util.HashMap<Integer, MoveTransplant.Choice> choices = new java.util.HashMap<Integer, MoveTransplant.Choice>();
        nextReaction(a, d, move, srcIdx, tgt, dstIdx, withSprites, ask, 0, choices);
    }

    private void nextReaction(final Activity a, final AttackData d, final CharData.Move move, final int srcIdx, final CharAssets tgt, final int dstIdx, final boolean withSprites,
                              final java.util.ArrayList<Integer> ask, final int at, final java.util.HashMap<Integer, MoveTransplant.Choice> choices) {
        if (at >= ask.size()) { confirmTransplant2(a, d, move, srcIdx, tgt, dstIdx, withSprites, choices); return; }
        final Integer type = ask.get(at);
        ReactionReplaceScreen.show(a, d.attacker, type.intValue(), tgt, new ReactionReplaceScreen.Listener() {
            @Override public void onChoice(MoveTransplant.Choice choice) {
                choices.put(type, choice);
                nextReaction(a, d, move, srcIdx, tgt, dstIdx, withSprites, ask, at + 1, choices);
            }
            @Override public void onCancel() { tgt.release(); }
        });
    }

    private void confirmTransplant2(final Activity a, final AttackData d, final CharData.Move move, final int srcIdx, final CharAssets tgt, final int dstIdx,
                                    final boolean withSprites, final java.util.Map<Integer, MoveTransplant.Choice> choices) {
        int nAnos = MoveTransplant.anosToCopy(d.attacker.dac, move).size();
        String msg = "Vai substituir o GOLPE_" + String.format(java.util.Locale.US, "%02d", dstIdx) + " de " + tgt.dir.getName() + " pelo GOLPE_" + String.format(java.util.Locale.US, "%02d", srcIdx)
                + " de " + d.attacker.dir.getName() + ", gravando direto no Runtime de " + tgt.dir.getName() + ".\n\n"
                + "• HDAT 4: o golpe do destino é trocado pelo golpe daqui (com os ANOs renumerados).\n"
                + "• " + nAnos + " ANO(s) entram no fim do DAC do destino (a partir do ANO " + tgt.dac.size() + ").\n"
                + (withSprites ? "• As sprites usadas entram no fim do CNV do destino (e nas folhas dele).\n" : "• Sem sprites: os frames ficam com IMG -1 (o CNV e as folhas do destino não mudam).\n")
                + "• Reações do personagem que o golpe usa: iguais às do destino só mudam o OPT 1; senão vão para um slot vazio" + (choices.isEmpty() ? "" : "; " + choices.size() + " reação(ões) seguem a sua escolha (SUBSTITUIR / USAR ESSA)") + ".\n"
                + "• Sons do personagem (id 80 ou mais) e hitbox flags 20 e 41-125 NÃO vão junto.\n\n"
                + "Uma cópia dos .txt do destino fica em Tap Battle/" + Saver.TBRE + "/Backups/. O que está aqui na memória (mesmo sem salvar) é o que vai.";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Salvar em outro personagem").setMessage(msg)
                .setPositiveButton("SALVAR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int w) { runTransplant(a, d, move, srcIdx, tgt, dstIdx, withSprites, choices); }
                })
                .setNegativeButton("CANCELAR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int w) { tgt.release(); }
                })
                .setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                    @Override public void onCancel(android.content.DialogInterface dlg) { tgt.release(); }
                }).show();
    }

    private void runTransplant(final Activity a, final AttackData d, final CharData.Move move, final int srcIdx, final CharAssets tgt, final int dstIdx,
                               final boolean withSprites, final java.util.Map<Integer, MoveTransplant.Choice> choices) {
        final BusyDialog bd = BusyDialog.show(a, "Salvando em " + tgt.dir.getName());
        bd.set("Montando o golpe...", 0, 0);
        new Thread(new Runnable() { @Override public void run() {
            String out;
            try {
                final SpriteLib sl = d.attacker.lib(), dl = tgt.lib();
                MoveTransplant.Sprites spr = new MoveTransplant.Sprites() {
                    @Override public int add(int image) throws java.io.IOException {
                        android.graphics.Bitmap b = sl.cut(image);
                        return b == null ? -1 : dl.add(b);
                    }
                };
                java.util.Set<Integer> writable = null;
                File binTxt = new File(tgt.dir, "000.bin.txt");
                if (binTxt.isFile()) writable = Saver.writableReactionSlots(Saver.readText(binTxt));
                MoveTransplant.Plan p = MoveTransplant.build(d.attacker.dac, d.attacker.data, move, tgt.dac, tgt.data, withSprites ? spr : null, writable, choices);
                java.util.ArrayList<String> warns = new java.util.ArrayList<String>(p.warnings);
                bd.set("Gravando...", 0, 0);
                File bk = MoveTransplant.write(tgt.dir, p, dstIdx, warns, new MoveTransplant.Commit() {
                    @Override public void run() throws java.io.IOException { dl.commit(); }
                });
                StringBuilder sb = new StringBuilder("GOLPE_" + String.format(java.util.Locale.US, "%02d", dstIdx) + " de " + tgt.dir.getName() + " substituído pelo GOLPE_"
                        + String.format(java.util.Locale.US, "%02d", srcIdx) + ".\n\n");
                sb.append("• ").append(p.anos.size()).append(" ANO(s) novos: ").append(p.firstAno()).append(" a ").append(p.firstAno() + p.anos.size() - 1).append('\n');
                sb.append("• ").append(p.sprites).append(" sprite(s) novas no CNV e nas folhas\n");
                if (!p.reactionMap.isEmpty()) {
                    sb.append("• reações do personagem: ");
                    boolean first = true;
                    for (java.util.Map.Entry<Integer, Integer> e : p.reactionMap.entrySet()) { sb.append(first ? "" : ", ").append(e.getKey()).append(" → ").append(e.getValue()); first = false; }
                    sb.append('\n');
                }
                sb.append("• cópia dos .txt anteriores: ").append(bk.getPath()).append('\n');
                if (!warns.isEmpty()) { sb.append("\nAvisos:\n"); for (String w : warns) sb.append("• ").append(w).append('\n'); }
                sb.append("\nRecarregue o personagem ").append(tgt.dir.getName()).append(" (troque de personagem e volte) para ver o golpe novo na tela.");
                out = sb.toString();
            } catch (Exception e) {
                out = "Erro ao salvar em " + tgt.dir.getName() + ": " + e.getMessage() + "\n\nOs .txt do destino só são gravados no final; se o erro veio depois do backup, a cópia dos .txt anteriores está em Tap Battle/" + Saver.TBRE + "/Backups/.";
            } finally {
                tgt.release();
            }
            final String text = out;
            bd.dismiss();
            a.runOnUiThread(new Runnable() { @Override public void run() {
                TextView tv = text(a, text, 13, TEXT);
                tv.setPadding(dp(16), dp(8), dp(16), dp(8));
                android.widget.ScrollView sv = new SafeScrollView(a);
                sv.addView(tv);
                new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Salvar em outro personagem").setView(sv).setPositiveButton("OK", null).show();
            } });
        } }).start();
    }

    /** Barra de duracao: normal ate o fim do ANO; tom diferente no trecho excedente (so simulacao de fisica). */
    static final class ExtSeekBar extends SeekBar {
        private int anoEnd = Integer.MAX_VALUE;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        ExtSeekBar(android.content.Context c) { super(c); p.setColor(0xFFE0922B); }
        void setAnoEnd(int idx) { if (idx != anoEnd) { anoEnd = idx; invalidate(); } }
        @Override protected synchronized void onDraw(android.graphics.Canvas c) {
            super.onDraw(c);
            int max = getMax();
            if (max <= 0 || anoEnd >= max) return;
            float avail = getWidth() - getPaddingLeft() - getPaddingRight();
            float x0 = getPaddingLeft() + avail * Math.max(0, anoEnd) / max, x1 = getPaddingLeft() + avail;
            float cy = (getHeight() - getPaddingTop() - getPaddingBottom()) / 2f + getPaddingTop();
            float h = getResources().getDisplayMetrics().density * 1.5f;
            c.drawRoundRect(new android.graphics.RectF(x0, cy - h, x1, cy + h), h, h, p);
            android.graphics.drawable.Drawable t = getThumb();
            if (t != null) {                                   // thumb por cima do trecho colorido
                c.save();
                c.translate(getPaddingLeft() - getThumbOffset(), getPaddingTop());
                t.draw(c);
                c.restore();
            }
        }
    }

    /** Pasta dos personagens (charNN); definida pela MainActivity. */
    File assetsRoot;

    /** Escolha em grade com a previa animada (ANO 76) de cada personagem; seleciona no spinner (os spinners ficam fora da tela). */
    private void openPicker(Activity a, String title, final Spinner sp) {
        android.widget.SpinnerAdapter ad = sp.getAdapter();
        if (ad == null || ad.getCount() == 0) {
            I18nUi.toast(a, "lista vazia", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        List<File> dirs = new ArrayList<File>();
        for (int i = 0; i < ad.getCount(); i++) dirs.add(new File(assetsRoot, String.valueOf(ad.getItem(i))));
        CharPicker.show(a, title, dirs, sp.getSelectedItemPosition(), new CharPicker.Listener() {
            @Override public void onPick(int index) { sp.setSelection(index); }
        });
    }

    /** Dialogo com -10 / -1 / +1 / +10 que aplica na hora. */
    private void stepper(Activity a, String title, final Num n) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        final TextView val = mono(a, String.valueOf(n.get()), 22, TEXT);
        val.setGravity(Gravity.CENTER);
        box.addView(val, lp(-1, -2, 0, 0, 0, 8));
        LinearLayout row = row(a);
        int[] steps = {-10, -1, 1, 10};
        for (int k = 0; k < steps.length; k++) {
            final int st = steps[k];
            TextView b = button(a, (st > 0 ? "+" : "") + st, false);
            Hold.attach(b, new Runnable() {
                @Override public void run() {
                    n.set(n.get() + st);
                    val.setText(String.valueOf(n.get()));
                }
            });
            row.addView(b, lpw(1f, k == 0 ? 0 : 3, 0, k == 3 ? 0 : 3, 0));
        }
        box.addView(row, lp(-1, -2, 0, 0, 0, 0));
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title).setView(box).setPositiveButton("OK", null).show();
    }

    public void attach(Activity a) { a.setContentView(root); }

    // ---- API usada pela Activity ----

    /** Adaptador escuro para os spinners. */
    public ArrayAdapter<String> adapter(Context c, List<String> items) {
        return new DarkAdapter(c, items, null);
    }

    /** Adaptador com cor por item (lista de ANOs: vermelho = ataque, amarelo = projetil). */
    public ArrayAdapter<String> adapter(Context c, List<String> items, int[] colors) {
        return new DarkAdapter(c, items, colors);
    }

    public void setListModeChecked(boolean on) {
        setChecked(listModeChip, on);
        listModeChip.setText(on ? "MODO: ANO" : "MODO: GOLPES");
    }

    private String warnMsg = "";
    private boolean warnExpanded;

    private java.util.List<String> warnList = new java.util.ArrayList<String>();

    /** Aviso de uma linha; toque (seta) abre todas as linhas. */
    public void setWarning(String msg) {
        setWarnings(msg == null || msg.length() == 0 ? null : java.util.Collections.singletonList(msg));
    }

    /** Lista de avisos: recolhido mostra o primeiro e "(+N)"; ao tocar, mostra todos, um por linha. */
    public void setWarnings(java.util.List<String> msgs) {
        java.util.ArrayList<String> l = new java.util.ArrayList<String>();
        if (msgs != null) for (String m : msgs) if (m != null && m.trim().length() > 0) l.add(m.trim());
        String key = joinWarn(l);
        if (l.isEmpty()) warnExpanded = false;
        else if (!key.equals(warnMsg)) warnExpanded = false;
        warnList = l;
        warnMsg = key;
        showWarning();
    }

    private static String joinWarn(java.util.List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) b.append(b.length() > 0 ? "\n" : "").append(s);
        return b.toString();
    }

    private void showWarning() {
        if (warnList.isEmpty()) {
            warning.setText("");
            warning.setVisibility(View.GONE);
            return;
        }
        String arrow = warnExpanded ? "  \u25B4" : "  \u25BE";
        if (warnExpanded) {
            warning.setText(warnMsg + arrow);
            warning.setSingleLine(false);
            warning.setMaxLines(Integer.MAX_VALUE);
            warning.setEllipsize(null);
        } else {
            warning.setText(warnList.get(0) + (warnList.size() > 1 ? "  (+" + (warnList.size() - 1) + ")" : "") + arrow);
            warning.setSingleLine(true);
            warning.setEllipsize(android.text.TextUtils.TruncateAt.END);
        }
        warning.setVisibility(View.VISIBLE);
    }

    public void setError(String msg) {
        info.setText(msg);
    }

    // ---- interno ----

    // ---- POS: tela de previa onde se arrasta atacante e oponente; grades mostram as posicoes predefinidas do jogo ----
    private static final class PosPreview extends View {
        interface Done { void apply(int dist, int ha, int ho); }
        final GameData gd;
        final Done done;
        float ax, ox;           // posicao X no mundo (0..480)
        int ha, ho;             // alturas (px acima do chao)
        int drag = -1;          // 0 atacante, 1 oponente
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final float den;
        PosPreview(Activity a, GameData gd, int dist, int ha, int ho, Done done) {
            super(a);
            this.gd = gd; this.done = done; this.ha = ha; this.ho = ho;
            den = a.getResources().getDisplayMetrics().density;
            ax = 0; ox = dist;
            normalize();
        }
        /** Posicoes como o simulador aplica: oponente fixo no spawn do jogo (360 px da borda esquerda; 120 px se o atacante olha para a esquerda) e atacante a "distancia" dele. */
        private void normalize() {
            float dist = Math.abs(ox - ax);
            if (ax <= ox) { ox = 360f; ax = ox - dist; } else { ox = 120f; ax = ox + dist; }
            if (ax < 0) { ox -= ax; ax = 0; }
            if (ox < 0) { ax -= ox; ox = 0; }
            if (ax > 480) { ox -= ax - 480; ax = 480; }
            if (ox > 480) { ax -= ox - 480; ox = 480; }
        }
        private float pad() { return 18f * den; }
        private float sx() { return (getWidth() - 2 * pad()) / 480f; }
        private float gy() { return getHeight() - 42f * den; }
        private float sy() { return (gy() - 26f * den) / 200f; }
        private float wx(float x) { return pad() + x * sx(); }
        private float wy(float h) { return gy() - h * sy(); }
        private float bw() { return 16f * den; }
        private float bh() { return 38f * den; }
        private int band() { return ho > 0 ? 1 : 0; }     // coluna do gamedata: alvo (oponente) no ar

        @Override protected void onDraw(android.graphics.Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(0xFF1B2230);
            c.drawRect(0, 0, w, gy(), p);
            p.setColor(0xFF4A5568);
            c.drawRect(0, gy(), w, h, p);
            p.setTextSize(9f * den);
            // grade horizontal: alturas predefinidas
            p.setStrokeWidth(1f);
            for (int i = 0; i < 3; i++) {
                float y = wy(PosPresets.HEIGHTS[i]);
                p.setColor(0x66FFFFFF);
                c.drawLine(pad(), y, w - pad(), y, p);
                p.setColor(0xFFB8C2D6);
                p.setTextAlign(android.graphics.Paint.Align.LEFT);
                I18nUi.drawText(c, PosPresets.HEIGHT_NAMES[i], pad() + 2, y - 2, p);
            }
            // grade vertical: distancias predefinidas ao redor do personagem parado
            float ref = drag == 0 ? ox : drag == 1 ? ax : ax;
            for (int d = 0; d < 3; d++) {
                int px = PosPresets.distance(gd, band(), d);
                for (int sg = -1; sg <= 1; sg += 2) {
                    float x = ref + sg * px;
                    if (x < 0 || x > 480) continue;
                    p.setColor(0x55FFB020);
                    c.drawLine(wx(x), 0, wx(x), gy(), p);
                    if (sg > 0 || ref - px < 0) {
                        p.setColor(0xFFFFC857);
                        p.setTextAlign(android.graphics.Paint.Align.CENTER);
                        I18nUi.drawText(c, PosPresets.DIST_NAMES[d] + " " + px, wx(x), 10f * den, p);
                    }
                }
            }
            drawChar(c, ax, ha, 0xFF3D8BFF, drag == 0);
            drawChar(c, ox, ho, 0xFFE5484D, drag == 1);
            p.setColor(0xFFFFFFFF);
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            p.setTextSize(11f * den);
            p.setTextSize(10.5f * den);
            I18nUi.drawText(c, "distancia " + Math.round(Math.abs(ox - ax)) + " px   |   altura: atacante " + ha + "   oponente " + ho,
                    w / 2f, gy() + 15f * den, p);
            I18nUi.drawText(c, "posicao X: atacante " + Math.round(ax) + "   oponente " + Math.round(ox) + "   (px da borda esquerda da tela)",
                    w / 2f, gy() + 31f * den, p);
        }

        private void drawChar(android.graphics.Canvas c, float x, int hgt, int col, boolean on) {
            float cx = wx(x), by = wy(hgt);
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(col);
            c.drawRect(cx - bw() / 2, by - bh(), cx + bw() / 2, by, p);
            if (on) {
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setColor(0xFFFFFFFF);
                p.setStrokeWidth(2f * den);
                c.drawRect(cx - bw() / 2, by - bh(), cx + bw() / 2, by, p);
                p.setStyle(android.graphics.Paint.Style.FILL);
            }
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            float tx = e.getX(), ty = e.getY();
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN: {
                    float da = Math.abs(tx - wx(ax)) + Math.abs(ty - (wy(ha) - bh() / 2));
                    float dO = Math.abs(tx - wx(ox)) + Math.abs(ty - (wy(ho) - bh() / 2));
                    drag = da <= dO ? 0 : 1;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    move(tx, ty);
                    return true;
                }
                case android.view.MotionEvent.ACTION_MOVE:
                    move(tx, ty);
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    if (drag >= 0) {
                        drag = -1;
                        done.apply(Math.round(Math.abs(ox - ax)), ha, ho);
                        normalize();                      // mostra onde cada um fica de fato na simulacao
                        invalidate();
                    }
                    return true;
                default:
                    return true;
            }
        }

        private void move(float tx, float ty) {
            if (drag < 0) return;
            float snap = 10f * den;
            float x = (tx - pad()) / sx();
            x = Math.max(0f, Math.min(480f, x));
            int hgt = Math.round((gy() - (ty + bh() / 2)) / sy());
            hgt = Math.max(0, Math.min(200, hgt));
            for (int i = 0; i < 3; i++)
                if (Math.abs(wy(hgt) - wy(PosPresets.HEIGHTS[i])) <= snap) { hgt = PosPresets.HEIGHTS[i]; break; }
            float ref = drag == 0 ? ox : ax;
            for (int d = 0; d < 3; d++) {
                int px = PosPresets.distance(gd, band(), d);
                for (int sg = -1; sg <= 1; sg += 2) {
                    float cand = ref + sg * px;
                    if (cand >= 0 && cand <= 480 && Math.abs(wx(cand) - wx(x)) <= snap) { x = cand; }
                }
            }
            if (drag == 0) { ax = x; ha = hgt; } else { ox = x; ho = hgt; }
            invalidate();
        }
    }

    private void showPosDialog(final Activity a) {
        final AttackView view = attackView;
        final GameData gd = view.attackData() == null ? null : view.attackData().gameData;
        PosPreview prev = new PosPreview(a, gd, view.getDistance(), view.getAltitude(), view.getOppAltitude(),
                new PosPreview.Done() {
                    @Override public void apply(int dist, int ha, int ho) { view.setPositions(dist, ha, ho); }
                });
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        box.addView(prev, new LinearLayout.LayoutParams(-1, dp(300)));
        LinearLayout mapRow = new LinearLayout(a);
        final String[] mapNames = {"ESQ.", "MEIO", "DIR."};
        final TextView[] mapBtns = new TextView[3];
        for (int mi = 0; mi < 3; mi++) {
            final int mode = mi + 1;
            mapBtns[mi] = button(a, mapNames[mi], view.getMapPos() == mode);
            mapBtns[mi].setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                view.setMapPos(view.getMapPos() == mode ? 0 : mode);          // tocar de novo no ativo volta ao padrão
                for (int k = 0; k < 3; k++) {
                    boolean on = view.getMapPos() == k + 1;
                    mapBtns[k].setTextColor(on ? Color.WHITE : TEXT);
                    if (on) setBg(mapBtns[k], stateBg(ACCENT, 0xFF6AA1FF)); else setBg(mapBtns[k], stateBg(PANEL, PANEL_HI));
                }
            } });
            mapRow.addView(mapBtns[mi], new LinearLayout.LayoutParams(0, -2, 1f));
        }
        box.addView(mapRow, lp(-1, -2, 0, 6, 0, 0));
        box.addView(text(a, "ESQ. / MEIO / DIR.: leva os dois personagens para a borda esquerda, o meio ou a borda direita do mapa. Só o x muda: a distância entre eles e as alturas ficam como estão. Tocar de novo no botão ligado volta ao padrão.", 10, DIM), lp(-1, -2, 0, 2, 0, 0));
        final TextView fly = button(a, view.isFly() ? "FLY: LIGADO" : "FLY: DESLIGADO", view.isFly());
        fly.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            boolean on = !view.isFly();
            view.setFly(on);
            ((TextView) v).setText(on ? "FLY: LIGADO" : "FLY: DESLIGADO");
            ((TextView) v).setTextColor(on ? Color.WHITE : TEXT);
            if (on) setBg(v, stateBg(ACCENT, 0xFF6AA1FF)); else setBg(v, stateBg(PANEL, PANEL_HI));
        } });
        box.addView(fly, lp(-1, -2, 0, 6, 0, 0));
        box.addView(text(a, "Fly ligado: o personagem fica voando e não cai (nem pousa). Desligado: acima do chão ele cai e pousa; ao pousar volta ao início e pausa. Nos dois casos, acima do chão vale SEQ/END de ar (o jogo escolhe só pela altura).", 10, DIM), lp(-1, -2, 0, 4, 0, 0));
        String note = "Arraste o atacante (azul) e o oponente (vermelho). As linhas sao as posicoes do jogo e o personagem gruda nelas."
                + (PosPresets.fromGame(gd) ? " LONGE = medio + (medio - perto): o jogo so guarda perto e medio."
                : " gamedata (HDAT 2) nao carregado: usando 60/120 px como perto/medio.");
        box.addView(text(a, note, 10, DIM), lp(-1, -2, 0, 6, 0, 0));
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Posicao").setView(box).setPositiveButton("OK", null)
                .setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                    @Override public void onDismiss(android.content.DialogInterface x) { view.posDialogClosed(); }       // o editor de reacoes refaz a previa ao fechar
                }).show();
    }

    // ---- OPCOES DO GOLPE: checkboxes das flags do ATK_FLAGS (HDAT 4, byte 0)
    private int optMoveIndex;
    private static final int MF_GROUND_ONLY = 1, MF_NO_TRADE = 2, MF_TRIPLE = 4, MF_GRAB = 8, MF_GHOST = 16,
            MF_PROJ_OPP = 32, MF_PROJ_FLOOR = 64, MF_GRAB_HIT = 128;

    private void showMoveOptions(final Activity a) {
        final AttackView view = attackView;
        final AttackData d = view == null ? null : view.attackData();
        if (d == null || d.move == null || d.move.generic) {
            I18nUi.toast(a, "este ANO nao e ANIM_INICIAL de um golpe", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        view.pause();
        final CharData.Move mv = d.move;
        optMoveIndex = d.moveIndex;
        final boolean[] busy = {false};
        final java.util.ArrayList<Runnable> syncs = new java.util.ArrayList<Runnable>();
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        box.addView(text(a, "Agarrão", 13, ACCENT));
        addFlagBox(a, box, view, mv, busy, syncs, MF_GRAB, "Agarrão",
                "Quando ANIM_INICIAL termina, ou num frame com \"Tentar agarrão\", o personagem vai para o lado do oponente e segue para ANIM_INICIAL + 1. Funciona mesmo sem acertar: o agarrão sem hit não garante acerto.", MF_GRAB_HIT);
        if (!mv.hasSequence() || (mv.flags & MF_GRAB_HIT) != 0) {
        addFlagBox(a, box, view, mv, busy, syncs, MF_GRAB_HIT, "Agarrão apenas durante hit",
                "O agarrão acontece se o oponente está em reação de dor deste golpe e você usa \"Tentar agarrão\" (ou o ANO inicial termina). Só funciona nos golpes 0 a 12. Com as duas marcadas, vale esta.", 0);
        }
        if (mv.hasSequence() && (mv.flags & MF_GRAB_HIT) != 0)
            box.addView(text(a, "Este golpe tem sequência (SEQ/SEQ_PROJETIL): ela assume no acerto e o agarrão com hit não chega a acontecer. Desmarque a 128 ou use a ação Teleportar na SEQ.", 10, WARN), lp(-1, -2, 0, 2, 0, 0));
        final TextView repNote = text(a, "Este golpe usa repetição de projétil (MAX_REPETICOES > 0), que usa a mesma janela 512 do frame: o agarrão fica indisponível.", 10, WARN);
        box.addView(repNote, lp(-1, -2, 0, 4, 0, 0));
        syncs.add(new Runnable() { public void run() { repNote.setVisibility(mv.repeats(optMoveIndex) ? View.VISIBLE : View.GONE); } });
        final boolean hasProj = mv.hasProjectile();
        if (hasProj) {
        box.addView(text(a, "Projétil", 13, ACCENT), lp(-1, -2, 0, 12, 0, 0));
        addFlagBox(a, box, view, mv, busy, syncs, MF_PROJ_OPP, "Projétil nasce no oponente",
                "O projétil nasce na posição do oponente (X e altura dele). Ligar esta desliga a de baixo.", MF_PROJ_FLOOR);
        addFlagBox(a, box, view, mv, busy, syncs, MF_PROJ_FLOOR, "Projétil nasce embaixo do oponente",
                "O projétil nasce no X do oponente, preso no chão. Ligar esta desliga a de cima.", MF_PROJ_OPP);
        final TextView tripleNote = addFlagBox(a, box, view, mv, busy, syncs, MF_TRIPLE, "Lançar 3 projéteis",
                "", 0);
        syncs.add(new Runnable() { public void run() {
            int n = mv.projNormal;
            tripleNote.setText("Lança 3 objetos de uma vez com os ANOs do projétil em sequência: PROJETIL_ANIM_NORMAL = " + n
                    + " lança " + n + ", " + (n + 1) + " e " + (n + 2) + ". Mude o primeiro e os outros acompanham.");
        } });
        }
        box.addView(text(a, "Outros", 13, ACCENT), lp(-1, -2, 0, 12, 0, 0));
        if (hasProj) addFlagBox(a, box, view, mv, busy, syncs, MF_GROUND_ONLY, "Projétil não explode no inimigo (só no chão)",
                "O projétil acerta e causa dano normalmente, mas não troca para PROJETIL_ANIM_ACERTAR_GLOBAL enquanto está no ar: continua voando. Só troca (ou usa PROJETIL_COLISAO_CHAO) quando chega no chão.", 0);
        addFlagBox(a, box, view, mv, busy, syncs, MF_NO_TRADE, "Hitbox destrói as hitboxes do oponente",
                "Quando uma hitbox (flag 2) sua encosta numa hitbox (flag 2) do oponente, a dele é destruída: o golpe dele não registra e o oponente entra na reação " + CharData.reactionName(d.attacker.data.clashReaction()) + ", com efeito e som de choque, mas sem dano. O seu golpe conta como acerto. Só vale no choque de hitbox: hits na sua hurtbox ainda te acertam, e projéteis seguem a regra comum a todos os golpes. No código, o golpe com esta flag também não registra o acerto comum de corpo (hitbox x hurtbox); teste em jogo.", 0);
        addFlagBox(a, box, view, mv, busy, syncs, MF_GHOST, "Personagens se atravessam",
                "Enquanto o golpe está ativo, o jogo não separa os dois corpos quando estão perto do chão, então eles se atravessam. As hitboxes continuam normais.", 0);
        for (int i = 0; i < syncs.size(); i++) syncs.get(i).run();
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(box);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Opções do golpe").setView(sv).setPositiveButton("OK", null).show();
    }

    /** Checkbox de um bit do ATK_FLAGS; {@code excl} = bit que esta opcao desliga (0 = nenhum). Devolve o TextView da explicacao. */
    private TextView addFlagBox(final Activity a, LinearLayout box, final AttackView view, final CharData.Move mv,
                                final boolean[] busy, final java.util.ArrayList<Runnable> syncs, final int bit,
                                String label, String note, final int excl) {
        final android.widget.CheckBox cb = new I18nCheckBox(a);
        cb.setText(label);
        cb.setTextColor(TEXT);
        box.addView(cb, lp(-1, -2, 0, 4, 0, 0));
        final TextView nt = text(a, note, 10, DIM);
        nt.setPadding(dp(32), 0, 0, 0);
        box.addView(nt, lp(-1, -2, 0, 0, 0, 2));
        syncs.add(new Runnable() { public void run() {
            busy[0] = true;
            boolean on = (mv.flags & bit) != 0;
            // agarrao simples fica apagado quando a condicional esta ligada (a 128 prevalece)
            boolean repBlock = (bit == MF_GRAB || bit == MF_GRAB_HIT) && mv.repeats(optMoveIndex) && (mv.flags & bit) == 0;
            if (bit == MF_GRAB && (mv.flags & MF_GRAB_HIT) != 0) { on = false; cb.setEnabled(false); }
            else if (bit == MF_GRAB || bit == MF_GRAB_HIT) cb.setEnabled(!repBlock);
            cb.setChecked(on);
            busy[0] = false;
        } });
        cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, final boolean on) {
                if (busy[0]) return;
                view.editMove(new Runnable() { public void run() {
                    int f = mv.flags;
                    if (on) {
                        f |= bit;
                        if (excl != 0 && bit != MF_GRAB_HIT) f &= ~excl;
                        if (bit == MF_GRAB_HIT) f &= ~MF_GRAB;
                    } else {
                        f &= ~bit;
                    }
                    mv.flags = f;
                } });
                for (int i = 0; i < syncs.size(); i++) syncs.get(i).run();
            }
        });
        return nt;
    }

    /** F-GHOST SET: o que a previa mostra (alem do personagem) e a transparencia. */
    /** Ultimo modo escolhido do FR-PREVIEW (1 = proximo frame, 2 = frame anterior); a caixa do menu TELA liga com ele. */
    private int ghostLast = 1;

    private void showGhostSet(Activity a, final AttackView view) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        if (view.getGhostMode() != 0) ghostLast = view.getGhostMode();
        android.widget.RadioGroup gm = new android.widget.RadioGroup(a);
        gm.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.RadioButton rNext = new android.widget.RadioButton(a), rPrev = new android.widget.RadioButton(a);
        rNext.setText("Próximo frame"); rPrev.setText("Frame anterior");
        rNext.setTextColor(TEXT); rPrev.setTextColor(TEXT);
        rNext.setId(7101); rPrev.setId(7102);
        gm.addView(rNext); gm.addView(rPrev);
        gm.check(ghostLast == 2 ? 7102 : 7101);
        gm.setOnCheckedChangeListener(new android.widget.RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.RadioGroup g, int id) {
                ghostLast = id == 7102 ? 2 : 1;
                if (view.getGhostMode() != 0) view.setGhostMode(ghostLast);
            }
        });
        box.addView(gm, lp(-1, -2, 0, 0, 0, 6));
        android.widget.CheckBox cp = new I18nCheckBox(a);
        cp.setText("Mostrar projeteis");
        cp.setTextColor(TEXT);
        cp.setChecked(view.isGhostProj());
        cp.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { view.setGhostProj(on); }
        });
        box.addView(cp);
        android.widget.CheckBox ce = new I18nCheckBox(a);
        ce.setText("Mostrar efeitos (os mesmos do HIDE-EFF, menos projeteis)");
        ce.setTextColor(TEXT);
        ce.setChecked(view.isGhostFx());
        ce.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { view.setGhostFx(on); }
        });
        box.addView(ce);
        android.widget.CheckBox cc = new I18nCheckBox(a);
        cc.setText("Aplicar tambem ao Frame atual");
        cc.setTextColor(TEXT);
        cc.setChecked(view.isGhostCurrent());
        cc.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { view.setGhostCurrent(on); }
        });
        box.addView(cc);
        box.addView(text(a, "O HIDE-EFF continua valendo: ligado, a previa mostra so o personagem.", 10, DIM), lp(-1, -2, 0, 4, 0, 0));
        final TextView gl = text(a, "Transparencia: " + Math.round(view.getGhostAlpha() * 100f / 255f) + "%", 12, DIM);
        box.addView(gl, lp(-1, -2, 0, 12, 0, 2));
        SeekBar gs = new SeekBar(a);
        gs.setMax(100);
        gs.setProgress(Math.round(view.getGhostAlpha() * 100f / 255f));
        gs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s2, int p, boolean fromUser) {
                view.setGhostAlpha(Math.round(p * 255f / 100f));
                gl.setText("Transparencia: " + p + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar s2) { }
            @Override public void onStopTrackingTouch(SeekBar s2) { }
        });
        box.addView(gs);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("FR-PREVIEW SET").setView(box).setPositiveButton("OK", null).show();
    }

    private TextView lockBtnRef;

    private void onFrameChanged(int frame, int length, boolean playing) {
        if (lockBtnRef != null) {                  // TRANSICAO so aparece em golpe com sequencia (ou com a trava ligada, para poder soltar)
            int vis = (lockTrans || attackView.hasSequence()) ? View.VISIBLE : View.GONE;
            if (lockBtnRef.getVisibility() != vis) lockBtnRef.setVisibility(vis);
        }
        seek.setMax(Math.max(1, length - 1));
        if (seek instanceof ExtSeekBar) ((ExtSeekBar) seek).setAnoEnd(attackView.getAnoEnd() - 1);
        seek.setProgress(frame);
        frameLabel.setText((attackView.displayTick(frame) + 1) + "/" + length);
        btnPlay.setText(playing ? "PAUSAR" : "TOCAR");
        if (timelineRef != null) {
            timelineRef.setSprites(attackView.attackerSprites());
            timelineRef.setSeqMarks(attackView.sequenceMarks());
            timelineRef.setState(attackView.currentAno(), attackView.currentPat(), attackView.currentElapsed(), playing);
            if (toolsRef0 != null) toolsRef0.follow(attackView.currentPat(), playing);
        }
        if (panelOpen) {
            updateTabs();
            statusLine.setText(attackView.status());
            refreshInfo(false);
        }
        undoButtonsRefresh();
        String problem = attackView.spriteProblem();
        if (problem.length() > 0) {
            warning.setTextColor(WARN);
            setWarning(problem);
        }
    }


    // ---- aviso piscando: transicao travada + play ----
    private boolean lockTrans, blinking, blinkOn, landBeforeLock = true;
    private final Runnable blinkRun = new Runnable() {
        @Override public void run() {
            if (!blinking) return;
            blinkOn = !blinkOn;
            warning.setAlpha(blinkOn ? 1f : 0.2f);
            warning.postDelayed(this, 450);
        }
    };

    private void startLockBlink() {
        if (blinking) return;
        blinking = true;
        blinkOn = true;
        warning.setTextColor(0xFFFF3B30);
        warning.setTypeface(Typeface.DEFAULT_BOLD);
        setWarning("\u26A0 TRANSICAO TRAVADA - o fluxo original do golpe esta sendo alterado");
        warning.setAlpha(1f);
        warning.postDelayed(blinkRun, 450);
    }

    private void stopLockBlink() {
        if (!blinking) return;
        blinking = false;
        warning.removeCallbacks(blinkRun);
        warning.setAlpha(1f);
        warning.setTextColor(WARN);
        warning.setTypeface(Typeface.DEFAULT);
        setWarning(null);
    }

    private static final String[] KEYS_MOVE = {"move", "ano", "frame"};
    private static final String[] NAMES_MOVE = {"GOLPE", "ANO", "FRAME"};
    private static final String[] KEYS_ANO = {"ano", "frame", "links"};
    private static final String[] NAMES_ANO = {"ANO", "FRAME", "LINKS"};

    /** Rotula as abas conforme o modo (golpes: GOLPE/ANO/FRAME; anos: ANO/FRAME/LINKS) e marca a ativa. */
    private void updateTabs() {
        boolean ano = attackView.isAnoMode();
        final String[] keys = ano ? KEYS_ANO : KEYS_MOVE;
        String[] names = ano ? NAMES_ANO : NAMES_MOVE;
        if (!tabsInit || ano != tabsAnoMode) {
            tabsInit = true;
            tabsAnoMode = ano;
            boolean ok = false;
            for (int i = 0; i < 3; i++) if (keys[i].equals(tabKey)) ok = true;
            if (!ok) tabKey = keys[0];
            for (int i = 0; i < 3; i++) {
                final String k = keys[i];
                infoTabs[i].setText(names[i]);
                infoTabs[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        tabKey = k;
                        updateTabs();
                        refreshInfo(true);
                    }
                });
            }
        }
        for (int i = 0; i < 3; i++) {
            boolean on = keys[i].equals(tabKey);
            setBg(infoTabs[i], stateBg(on ? ACCENT : PANEL, on ? 0xFF6AA1FF : PANEL_HI));
            infoTabs[i].setTextColor(on ? Color.WHITE : TEXT);
        }
    }

    /** Remonta o texto da aba so quando ele mudou; preserva a rolagem e segue a linha do frame atual. */
    private void refreshInfo(boolean force) {
        String key = attackView.infoKey(tabKey);
        if (!force && key.equals(lastKey)) return;
        lastKey = key;
        int ano = attackView.currentAnoIndex();
        boolean same = renderedTab.equals(tabKey) && renderedAno == ano;
        final int keep = same ? frameInfo.getScrollY() : 0;
        renderedTab = tabKey;
        renderedAno = ano;
        frameInfo.setText(attackView.info(tabKey));
        frameInfo.scrollTo(0, keep);
        if ("ano".equals(tabKey)) {
            frameInfo.post(new Runnable() {
                @Override public void run() { followMark(); }
            });
        }
    }

    /** Rola so se a linha do frame atual saiu da area visivel. */
    private void followMark() {
        android.text.Layout lay = frameInfo.getLayout();
        if (lay == null) return;
        int off = frameInfo.getText().toString().indexOf(InfoText.MARK);
        if (off < 0) return;
        int line = lay.getLineForOffset(off);
        int top = lay.getLineTop(line), bottom = lay.getLineBottom(line);
        int viewH = frameInfo.getHeight() - frameInfo.getPaddingTop() - frameInfo.getPaddingBottom();
        int sy = frameInfo.getScrollY();
        if (top >= sy && bottom <= sy + viewH) return;
        int max = Math.max(0, lay.getHeight() - viewH);
        frameInfo.scrollTo(0, Math.max(0, Math.min(max, top - (bottom - top) * 2)));
    }

    /** Lapis: edita o bloco da aba atual em texto e aplica em runtime. */
    private void openEditor(final Activity a) {
        final String tab = tabKey;
        final String title = attackView.editTitle(tab);
        if (title == null) { I18nUi.toast(a, "nada para editar nesta aba", android.widget.Toast.LENGTH_SHORT).show(); return; }
        attackView.pause();
        final android.widget.EditText et = new android.widget.EditText(a);
        et.setTypeface(Typeface.MONOSPACE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        et.setTextColor(TEXT);
        et.setBackgroundColor(0xFF161A21);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setHorizontallyScrolling(true);
        et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        et.setMinLines(10);
        et.setPadding(dp(8), dp(8), dp(8), dp(8));
        et.setText(attackView.editText(tab));
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(et);
        android.app.AlertDialog.Builder b = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        b.setTitle("Editar " + title);
        b.setView(sv);
        b.setPositiveButton("APLICAR", null);
        b.setNegativeButton("CANCELAR", null);
        b.setNeutralButton("DESFAZER (" + attackView.undoCount() + ")", null);
        final android.app.AlertDialog dlg = b.create();
        dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        dlg.show();
        dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String err = attackView.applyEdit(tab, et.getText().toString());
                if (err != null) { et.setError(err); return; }
                dlg.dismiss();
                refreshInfo(true);
                I18nUi.toast(a, "aplicado", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        dlg.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (attackView.undoEdit()) {
                    dlg.dismiss();
                    refreshInfo(true);
                    I18nUi.toast(a, "edicao desfeita", android.widget.Toast.LENGTH_SHORT).show();
                } else {
                    I18nUi.toast(a, "nada para desfazer", android.widget.Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void nextSpeed(AttackView view, TextView label) {
        speedIndex = (speedIndex + 1) % speeds.length;
        view.setSpeed(speeds[speedIndex]);
        label.setText(speedNames[speedIndex]);
    }

    private interface Toggle { void set(boolean on); }

    private View.OnClickListener toggle(final TextView chip, final Toggle t) {
        return new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !Boolean.TRUE.equals(chip.getTag());
                setChecked(chip, on);
                t.set(on);
            }
        };
    }

    private void setChecked(TextView chip, boolean on) {
        chip.setTag(Boolean.valueOf(on));
        setBg(chip, stateBg(on ? ACCENT : PANEL, on ? 0xFF6AA1FF : PANEL_HI));
        chip.setTextColor(on ? Color.WHITE : TEXT);
    }

    private TextView button(Context c, String label, boolean primary) {
        TextView t = new I18nTextView(c);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(primary ? Color.WHITE : TEXT);
        t.setPadding(dp(4), dp(11), dp(4), dp(11));
        t.setClickable(true);
        if (primary) setBg(t, stateBg(ACCENT, 0xFF6AA1FF)); else setBg(t, stateBg(PANEL, PANEL_HI));
        return t;
    }

    private TextView text(Context c, String s, int sp, int color) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        return t;
    }

    private TextView mono(Context c, String s, int sp, int color) {
        TextView t = text(c, s, sp, color);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    private LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private HeaderSpinner attackHeaderSpinner;

    /** Tocar no botao de ANO/golpe abre a grade de escolha (os dois modos). */
    public void setAttackHeader(Runnable open) { if (attackHeaderSpinner != null) attackHeaderSpinner.header = open; }

    private HeaderSpinner headerSpinner(Context c) {
        HeaderSpinner s = new HeaderSpinner(c);
        setBg(s, roundRect(PANEL, 8, 0, 0));
        s.setPadding(dp(8), dp(2), dp(8), dp(2));
        return s;
    }

    /** Botao de escolha do ANO/golpe: parece o antigo spinner, mas tocar abre a grade (AttackGrid) em vez de uma lista. */
    private static final class HeaderSpinner extends Spinner {
        Runnable header;
        HeaderSpinner(Context c) { super(c); }

        @Override public boolean performClick() {
            if (header != null) { header.run(); return true; }
            return super.performClick();
        }
    }

    private Spinner spinner(Context c) {
        Spinner s = new Spinner(c);
        setBg(s, roundRect(PANEL, 8, 0, 0));
        s.setPadding(dp(8), dp(2), dp(8), dp(2));
        return s;
    }

    private StateListDrawable stateBg(int normal, int pressed) {
        StateListDrawable d = new StateListDrawable();
        d.addState(new int[] {android.R.attr.state_pressed}, roundRect(pressed, 8, 0, 0));
        d.addState(new int[] {}, roundRect(normal, 8, 0, 0));
        return d;
    }

    private GradientDrawable roundRect(int color, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    @SuppressWarnings("deprecation")
    private static void setBg(View v, android.graphics.drawable.Drawable d) {
        if (Build.VERSION.SDK_INT >= 16) v.setBackground(d); else v.setBackgroundDrawable(d);
    }

    private void applyInsets(final View v, final int basePad) {
        if (Build.VERSION.SDK_INT < 20) return;
        v.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View view, WindowInsets in) {
                view.setPadding(basePad + in.getSystemWindowInsetLeft(),
                        basePad + in.getSystemWindowInsetTop(),
                        basePad + in.getSystemWindowInsetRight(),
                        basePad + in.getSystemWindowInsetBottom());
                return in;
            }
        });
    }

    private int dp(int v) { return Math.round(v * density); }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private LinearLayout.LayoutParams lpw(float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    /** Spinner legivel no tema escuro, com seta no estado fechado. */
    private static final class DarkAdapter extends ArrayAdapter<String> {
        private final int[] colors;

        DarkAdapter(Context c, List<String> items, int[] colors) {
            super(c, android.R.layout.simple_spinner_item, items);
            this.colors = colors;
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            TextView t = (TextView) super.getView(position, convertView, parent);
            t.setTextColor(colorAt(position));
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            t.setSingleLine(true);
            t.setText(I18n.tr(getItem(position)) + "  \u25BE");
            return t;
        }

        @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
            TextView t = (TextView) super.getDropDownView(position, convertView, parent);
            t.setText(I18n.tr(getItem(position)));
            t.setTextColor(colorAt(position));
            t.setBackgroundColor(PANEL);
            return t;
        }

        private int colorAt(int i) {
            return colors != null && i >= 0 && i < colors.length ? colors[i] : TEXT;
        }
    }
}
