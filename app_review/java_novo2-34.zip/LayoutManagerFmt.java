package com.zue.attackeditor;

import java.util.Locale;

/** Formatacao numerica compartilhada pelas paginas da gaveta. */
final class LayoutManagerFmt {
    private LayoutManagerFmt() { }

    static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e9) return String.valueOf((long) v);
        String s = String.format(Locale.US, "%.3f", v);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
