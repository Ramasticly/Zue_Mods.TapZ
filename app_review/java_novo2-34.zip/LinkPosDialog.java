package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Editar posicao do Link: mostra a animacao principal (a ANO atual, com o link por cima) como base e controles do link escolhido:
 * posicao (bx/by do link), sprite, tempo e posicao (centro) do frame do link que acompanha o frame atual.
 */
final class LinkPosDialog {
    private final Activity a;
    private final AttackView view;
    private final int parent, pat;
    private final Runnable changed;
    private final float d;
    private Dialog dlg;
    private int link;
    private LinearLayout body;
    private AnimPreview pv;

    private LinkPosDialog(Activity a, AttackView view, int parent, int pat, Runnable changed) {
        this.a = a; this.view = view; this.parent = parent; this.pat = pat; this.changed = changed;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    static void show(Activity a, AttackView view, int parent, int pat, Runnable changed) {
        new LinkPosDialog(a, view, parent, pat, changed).open();
    }

    private int dp(int v) { return Math.round(v * d); }
    private Dac dac() { return view.packDac(2); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Ano pa() { return dac().getAno(parent); }

    private Ano childAno() {
        Ano p = pa();
        return p == null || link >= p.links.length ? null : dac().getAno(p.links[link].getAno());
    }

    /** Frame do link que acompanha o frame atual do pai (mesmo indice se sincroniza sprites; senao o primeiro). */
    private int childPat(Ano ch) {
        Ano p = pa();
        int want = p.links[link].syncMpt() ? pat : 0;
        return Math.max(0, Math.min(ch.mpts.length - 1, want));
    }

    private void open() {
        Ano p = pa();
        if (p == null || p.links.length == 0) return;
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("Editar posição do Link  ·  ANO " + parent, 16, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        pv = new AnimPreview(a);
        pv.setAutoReplay(true);
        AttackData ad = view.attackData();
        pv.set(dac(), view.packSprites(2), parent, false);
        int side = Math.min(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.9f), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.34f));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(side, side);
        pl.gravity = Gravity.CENTER_HORIZONTAL;
        pl.setMargins(0, dp(6), 0, dp(6));
        root.addView(pv, pl);
        ScrollView sv = new ScrollView(a);
        body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView close = tv("VOLTAR", 13, LayoutManager.DIM, true);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(10), dp(11), dp(10), dp(11));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        close.setBackground(g);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        root.addView(close);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface i) { if (changed != null) changed.run(); }
        });
        link = 0;
        dlg.show();
        render();
    }

    private void lab(String s) {
        TextView t = tv(s, 11, LayoutManager.DIM, false);
        t.setPadding(dp(6), dp(8), dp(6), 0);
        body.addView(t);
    }

    private void put(Stepper st) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(2), dp(4), dp(2));
        body.addView(st.view(), lp);
    }

    private void refreshPreview() {
        pv.set(dac(), view.packSprites(2), parent, false);
        pv.replay();
    }

    private void setBase(final Integer x, final Integer y) {
        Ano p = pa();
        Ano.Link[] n = p.links.clone();
        Ano.Link o = n[link];
        n[link] = new Ano.Link(x != null ? x : o.baseX, y != null ? y : o.baseY, o.flags);
        view.replaceAno(new Ano(p.index, true, p.flags, p.priority, n, p.mpts));
        refreshPreview();
    }

    private interface Mut { void apply(Ano.Mpt m); }

    private void editChild(Mut mu) {
        Ano ch = childAno();
        if (ch == null || ch.mpts.length == 0) return;
        int k = childPat(ch);
        Ano.Mpt[] mp = ch.mpts.clone();
        Ano.Mpt n = mp[k].copy();
        mu.apply(n);
        n.normalize();
        mp[k] = n;
        view.replaceAnoAt(new Ano(ch.index, true, ch.flags, ch.priority, ch.links, mp));
        refreshPreview();
    }

    private void render() {
        body.removeAllViews();
        final Ano p = pa();
        if (p.links.length > 1) {
            lab("link");
            put(new Stepper(a).range(1, p.links.length).step(1).hold(false).keyboard(new Stepper.OnValue() { public void on(double v) {
                link = (int) v - 1;
                render();
            } }).value(link + 1));
        }
        Ano.Link l = p.links[link];
        Ano ch = childAno();
        TextView info = tv("Link " + (link + 1) + " → ANO " + l.getAno() + (l.syncMpt() ? "  ·  acompanha o frame " + (pat + 1) + " do pai" : "  ·  anda no próprio relógio (usa o 1º frame)"), 12, LayoutManager.TEXT, true);
        info.setPadding(dp(6), dp(6), dp(6), 0);
        body.addView(info);
        lab("POSIÇÃO DO LINK (bx / by, todos os frames da ANO " + parent + ")");
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(r);
        r.addView(tv("bx", 12, LayoutManager.DIM, false));
        r.addView(new Stepper(a).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { setBase(Integer.valueOf((int) v), null); } }).value(l.baseX).view(), new LinearLayout.LayoutParams(-2, -2));
        r.addView(tv("by", 12, LayoutManager.DIM, false));
        r.addView(new Stepper(a).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { setBase(null, Integer.valueOf((int) v)); } }).value(l.baseY).view(), new LinearLayout.LayoutParams(-2, -2));
        if (ch == null || ch.mpts.length == 0) { lab("O ANO do link está vazio."); return; }
        Ano.Mpt m = ch.mpts[childPat(ch)];
        lab("FRAME " + (childPat(ch) + 1) + " DA ANO " + ch.index + " — SPRITE");
        AttackData ad = view.attackData();
        int maxImg = ad != null && ad.attacker.cnv != null ? Math.max(0, ad.attacker.cnv.size() - 1) : 9999;
        put(new Stepper(a).range(-1, maxImg).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editChild(new Mut() { public void apply(Ano.Mpt n) { n.image = (int) v; } });
        } }).value(m.image));
        lab("TEMPO (ticks; 0 = travado)");
        put(new Stepper(a).range(0, 255).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editChild(new Mut() { public void apply(Ano.Mpt n) {
                Ano.Mpt t = FrameTools.setTime(n, (int) v);
                n.flags = t.flags; n.time = t.time;
            } });
        } }).value(FrameTools.ticks(m)));
        lab("POSIÇÃO DA SPRITE DO LINK (centro x / y)");
        LinearLayout r2 = new LinearLayout(a);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(r2);
        r2.addView(tv("x", 12, LayoutManager.DIM, false));
        r2.addView(new Stepper(a).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editChild(new Mut() { public void apply(Ano.Mpt n) { if ((n.flags & 1) == 0) { n.flags |= 1; n.midY = 0; } n.midX = (int) v; } });
        } }).value(m.midX).view(), new LinearLayout.LayoutParams(-2, -2));
        r2.addView(tv("y", 12, LayoutManager.DIM, false));
        r2.addView(new Stepper(a).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editChild(new Mut() { public void apply(Ano.Mpt n) { if ((n.flags & 1) == 0) { n.flags |= 1; n.midX = 0; } n.midY = (int) v; } });
        } }).value(m.midY).view(), new LinearLayout.LayoutParams(-2, -2));
        TextView nt = tv("O link mostra só as sprites dele: links do link e animações/efeitos de flags dentro dele não aparecem no jogo.", 10, LayoutManager.DIM, false);
        nt.setPadding(dp(6), dp(8), dp(6), dp(8));
        body.addView(nt);
    }
}
