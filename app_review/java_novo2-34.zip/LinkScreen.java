package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * Links do personagem (DAC): lista em grade por ANO, detalhe do link (previa ampliada com hurtboxes/hitboxes, sincronizacoes,
 * posicao, excluir) e "Ver usos" (ANOs que usam o mesmo ANO como link, com a previa ja com os links).
 * Os links sao imutaveis no modelo: cada edicao cria a ANO nova e troca no DAC (com desfazer).
 */
final class LinkScreen {
    private static final int BG = 0xFF14161B, PANEL = 0xFF1E2128, PANEL_HI = 0xFF2C313C, ACCENT = 0xFF4C8DFF, TEXT = 0xFFE6E8EC, DIM = 0xFF8A90A0, WARN = 0xFFFFB454;

    private final Activity a;
    private final AttackView view;
    private final Runnable changed;
    private final float d;
    private Dialog main;
    private LinearLayout lastRoot;
    private LinearLayout box;
    private ScrollView listScroll;
    /** ANO que estava na previa ao abrir (se tem links): a lista rola para o 1o link e a seta vai passando pelos proximos. */
    private int focusAno = -1, focusK;
    private final List<LinearLayout> focusCards = new ArrayList<LinearLayout>();
    private final List<View> focusRows = new ArrayList<View>();
    private TextView nextBtn;

    private LinkScreen(Activity a, AttackView view, Runnable changed) {
        this.a = a; this.view = view; this.changed = changed;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    static void show(Activity a, AttackView view, Runnable changed) {
        if (view.packDac(2) == null) { I18nUi.toast(a, "nada carregado", android.widget.Toast.LENGTH_SHORT).show(); return; }
        view.pause();                       // a previa principal fica no frame em que estava, pausada
        LinkScreen s = new LinkScreen(a, view, changed);
        Ano cur = view.currentAno();
        if (cur != null && cur.present && cur.links.length > 0) s.focusAno = cur.index;
        s.open();
    }

    private int dp(int v) { return Math.round(v * d); }
    private Dac dac() { return view.packDac(2); }
    private SpriteCache sprites() { return view.packSprites(2); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 12, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable g = new GradientDrawable();
        g.setColor(PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private Dialog fullscreen(String title, final Runnable onClose) {
        final Dialog dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        dlg.setContentView(root);
        lastRoot = root;
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv(title, 16, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); if (onClose != null) onClose.run(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        return dlg;
    }

    // ------------------------------------------------------------------ lista

    private void open() {
        main = fullscreen("Links do personagem", null);
        LinearLayout root = lastRoot;
        TextView hint = tv("Cada ANO que cria links aparece com seus links (Link n → ANO). Toque num link para ver a prévia, mudar sincronização e posição, "
                + "excluir ou ver quem usa. Se a prévia está num ANO com links, a lista já rola para o primeiro e a seta ▶ passa para o próximo. "
                + "No jogo o link mostra só as sprites dele: links do link e animações/efeitos de flags dentro do link não aparecem.", 11, DIM, false);
        hint.setPadding(dp(2), dp(2), dp(2), dp(8));
        root.addView(hint);
        ScrollView sv = new ScrollView(a);
        box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        sv.addView(box, new ScrollView.LayoutParams(-1, -2));
        listScroll = sv;
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        nextBtn = button("\u25B6", ACCENT, new View.OnClickListener() { public void onClick(View v) { focusLink(focusK + 1); } });
        nextBtn.setVisibility(View.GONE);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, -2, 1f);
        nlp.setMargins(0, 0, dp(6), 0);
        bar.addView(nextBtn, nlp);
        bar.addView(button("VOLTAR", DIM, new View.OnClickListener() { public void onClick(View v) { main.dismiss(); } }), new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(bar);
        main.show();
        render();
        if (focusAno >= 0) focusLink(0);
    }

    private void render() {
        box.removeAllViews();
        focusCards.clear();
        focusRows.clear();
        Dac dac = dac();
        int total = 0;
        for (int i = 0; i < dac.size(); i++) {
            final Ano an = dac.getAno(i);
            if (an == null || !an.present || an.links.length == 0) continue;
            total += an.links.length;
            TextView hd = tv("ANO " + i, 14, ACCENT, true);
            hd.setPadding(dp(4), dp(14), 0, dp(4));
            box.addView(hd);
            LinearLayout row = null;
            for (int k = 0; k < an.links.length; k++) {
                if (k % 2 == 0) {
                    row = new LinearLayout(a);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    box.addView(row, new LinearLayout.LayoutParams(-1, -2));
                }
                LinearLayout cd = card(i, k);
                row.addView(cd, cardLp());
                if (i == focusAno) { focusCards.add(cd); focusRows.add(row); }
            }
            if (an.links.length % 2 == 1) row.addView(new View(a), cardLp());
        }
        if (total == 0) box.addView(tv("Este personagem não tem ANOs com links.", 13, DIM, false));
        if (focusAno >= 0 && nextBtn != null) focusLink(focusK);
    }

    /** Rola para o link {@code k} do ANO em foco (volta ao primeiro depois do ultimo), destaca o card e atualiza a seta. */
    private void focusLink(int k) {
        if (focusCards.isEmpty()) { if (nextBtn != null) nextBtn.setVisibility(View.GONE); return; }
        focusK = ((k % focusCards.size()) + focusCards.size()) % focusCards.size();
        for (int i = 0; i < focusCards.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(PANEL);
            g.setCornerRadius(dp(10));
            if (i == focusK) g.setStroke(dp(2), ACCENT);
            focusCards.get(i).setBackground(g);
        }
        nextBtn.setText("\u25B6  PR\u00d3XIMO LINK  (" + (focusK + 1) + "/" + focusCards.size() + " \u00b7 ANO " + focusAno + ")");
        nextBtn.setVisibility(View.VISIBLE);
        final View row = focusRows.get(focusK);
        listScroll.post(new Runnable() { public void run() { listScroll.smoothScrollTo(0, Math.max(0, row.getTop() - dp(40))); } });
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    private static String flagsText(Ano.Link l) {
        String s = (l.spawnPos() ? "SPAWN(0,0) " : "") + (l.syncXY() ? "XY " : "") + (l.syncMpt() ? "MPT" : "");
        return s.trim().isEmpty() ? "sem sincronização" : s.trim();
    }

    private LinearLayout card(final int anoIdx, final int k) {
        Ano.Link l = dac().getAno(anoIdx).links[k];
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(PANEL);
        g.setCornerRadius(dp(10));
        c.setBackground(g);
        AnimPreview pv = new AnimPreview(a);
        pv.setFirstFrameOnly(true);
        pv.set(dac(), sprites(), l.getAno());
        c.addView(pv, new LinearLayout.LayoutParams(-1, dp(96)));
        c.addView(tv("Link " + k + " · ANO " + l.getAno(), 13, TEXT, true));
        c.addView(tv(flagsText(l) + " · " + l.baseX + "," + l.baseY, 10, DIM, false));
        c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { detail(anoIdx, k); } });
        return c;
    }

    // ------------------------------------------------------------------ edicao

    private void commit(List<Ano> list, final Runnable after) {
        final BusyDialog busy = BusyDialog.show(a, "Atualizando links");
        busy.set("Recalculando a animação...", 0, 0);
        view.replaceAnosAsync(list, new Runnable() { public void run() {
            busy.dismiss();
            if (changed != null) changed.run();
            if (after != null) after.run();
        } });
    }

    private static Ano withLinks(Ano an, List<Ano.Link> ls) {
        int fl = ls.isEmpty() ? (an.flags & ~2) : (an.flags | 2);
        return new Ano(an.index, true, fl, an.priority, ls.toArray(new Ano.Link[0]), an.mpts);
    }

    private void replaceLink(int anoIdx, int k, Ano.Link nl, Runnable after) {
        Ano an = dac().getAno(anoIdx);
        ArrayList<Ano.Link> ls = new ArrayList<Ano.Link>();
        for (int i = 0; i < an.links.length; i++) ls.add(i == k ? nl : an.links[i]);
        ArrayList<Ano> out = new ArrayList<Ano>();
        out.add(withLinks(an, ls));
        commit(out, after);
    }

    /** Tira os links que apontam para {@code target}; se {@code onlyAno}/{@code onlyK} >= 0, so aquele link. */
    private void deleteLinks(int target, int onlyAno, int onlyK, Runnable after) {
        ArrayList<Ano> out = new ArrayList<Ano>();
        Dac dac = dac();
        for (int i = 0; i < dac.size(); i++) {
            Ano an = dac.getAno(i);
            if (an == null || !an.present || an.links.length == 0) continue;
            ArrayList<Ano.Link> ls = new ArrayList<Ano.Link>();
            boolean ch = false;
            for (int k = 0; k < an.links.length; k++) {
                boolean del = onlyAno >= 0 ? (i == onlyAno && k == onlyK) : an.links[k].getAno() == target;
                if (del) ch = true; else ls.add(an.links[k]);
            }
            if (ch) out.add(withLinks(an, ls));
        }
        if (out.isEmpty()) return;
        commit(out, after);
    }

    // ------------------------------------------------------------------ detalhe

    private void detail(final int anoIdx, final int k) {
        Ano an = dac().getAno(anoIdx);
        if (an == null || k >= an.links.length) return;
        final Ano.Link l = an.links[k];
        final Dialog dlg = fullscreen("ANO " + anoIdx + " · Link " + k + " → ANO " + l.getAno(), null);
        LinearLayout root = lastRoot;
        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // a previa NAO e independente: e o ANO pai tocando, com a sincronizacao (tempo dos frames e posicao) que o link tem
        final AnimPreview pv = new AnimPreview(a);
        pv.setShowHits(true);
        final boolean[] only = {true};
        final Runnable showPv = new Runnable() { public void run() {
            Ano p = dac().getAno(anoIdx);
            Dac shown = dac();
            if (only[0]) {
                Ano onlyOne = new Ano(p.index, true, p.flags, p.priority, new Ano.Link[]{p.links[k]}, p.mpts);
                shown = dac().copyWith(anoIdx, onlyOne);
            }
            pv.set(shown, sprites(), anoIdx);
        } };
        showPv.run();
        col.addView(pv, new LinearLayout.LayoutParams(-1, dp(260)));
        final TextView onlyBtn = button("MOSTRAR: SÓ ESTE LINK", ACCENT, null);
        onlyBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            only[0] = !only[0];
            onlyBtn.setText(only[0] ? "MOSTRAR: SÓ ESTE LINK" : "MOSTRAR: TODOS OS LINKS DA ANO");
            showPv.run();
        } });
        col.addView(onlyBtn);
        col.addView(tv("A prévia é a ANO " + anoIdx + " (pai) tocando, com hurtboxes e hitboxes. Com SYNC o link segue o tempo dos frames e a posição do pai; "
                + "para ele ficar solto, desligue a sincronização abaixo.", 11, DIM, false));

        TextView sh = tv("Sincronizações", 13, ACCENT, true);
        sh.setPadding(0, dp(14), 0, dp(4));
        col.addView(sh);
        LinearLayout tg = new LinearLayout(a);
        tg.addView(toggle("SPAWN_POS", l.spawnPos(), 0x1000, anoIdx, k, dlg), new LinearLayout.LayoutParams(0, -2, 1f));
        tg.addView(toggle("XY", l.syncXY(), 0x4000, anoIdx, k, dlg), new LinearLayout.LayoutParams(0, -2, 1f));
        tg.addView(toggle("MPT", l.syncMpt(), 0x8000, anoIdx, k, dlg), new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(tg);
        col.addView(tv("SPAWN_POS (ligado): o link NÃO herda a posição do pai ao nascer (no jogo ele começa em 0,0 da tela; desligado = nasce no pai, o normal) · XY: segue o pai todo tick · MPT: usa o mesmo frame do pai. Toque para ligar/desligar.", 11, DIM, false));

        TextView ph = tv("Posição (BX, BY)", 13, ACCENT, true);
        ph.setPadding(0, dp(14), 0, dp(4));
        col.addView(ph);
        final EditText bx = num(l.baseX), by = num(l.baseY);
        LinearLayout pr = new LinearLayout(a);
        pr.addView(labeled("BX", bx), new LinearLayout.LayoutParams(0, -2, 1f));
        pr.addView(labeled("BY", by), new LinearLayout.LayoutParams(0, -2, 1f));
        pr.addView(button("APLICAR", ACCENT, new View.OnClickListener() { public void onClick(View v) {
            Ano.Link nl = new Ano.Link(parse(bx, l.baseX), parse(by, l.baseY), l.flags);
            dlg.dismiss();
            replaceLink(anoIdx, k, nl, new Runnable() { public void run() { render(); detail(anoIdx, k); } });
        } }), new LinearLayout.LayoutParams(-2, -2));
        col.addView(pr);

        TextView ah = tv("Ações", 13, ACCENT, true);
        ah.setPadding(0, dp(14), 0, dp(4));
        col.addView(ah);
        col.addView(button("VER USOS (ANOs que usam a ANO " + l.getAno() + " como link)", TEXT, new View.OnClickListener() { public void onClick(View v) { uses(l.getAno()); } }));
        col.addView(space());
        col.addView(button("EXCLUIR ESTE LINK", WARN, new View.OnClickListener() { public void onClick(View v) {
            confirm("Excluir o Link " + k + " da ANO " + anoIdx + "?", new Runnable() { public void run() {
                dlg.dismiss();
                deleteLinks(l.getAno(), anoIdx, k, new Runnable() { public void run() { render(); } });
            } });
        } }));
        col.addView(space());
        final int cnt = count(l.getAno());
        col.addView(button("EXCLUIR TODOS OS LINKS COM A ANO " + l.getAno() + " (" + cnt + ")", WARN, new View.OnClickListener() { public void onClick(View v) {
            confirm("Excluir os " + cnt + " link(s) que apontam para a ANO " + l.getAno() + " em todas as ANOs?", new Runnable() { public void run() {
                dlg.dismiss();
                deleteLinks(l.getAno(), -1, -1, new Runnable() { public void run() { render(); } });
            } });
        } }));
        root.addView(button("VOLTAR", DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }));
        dlg.show();
    }

    private View space() { View v = new View(a); v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(6))); return v; }

    private int count(int target) {
        int n = 0;
        Dac dac = dac();
        for (int i = 0; i < dac.size(); i++) {
            Ano an = dac.getAno(i);
            if (an == null || !an.present) continue;
            for (Ano.Link l : an.links) if (l.getAno() == target) n++;
        }
        return n;
    }

    private View toggle(String name, boolean on, final int bit, final int anoIdx, final int k, final Dialog dlg) {
        View t = button(name + ": " + (on ? "SIM" : "NÃO"), on ? ACCENT : DIM, new View.OnClickListener() { public void onClick(View v) {
            Ano.Link l = dac().getAno(anoIdx).links[k];
            Ano.Link nl = new Ano.Link(l.baseX, l.baseY, l.flags ^ bit);
            dlg.dismiss();
            replaceLink(anoIdx, k, nl, new Runnable() { public void run() { render(); detail(anoIdx, k); } });
        } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private EditText num(int v) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(String.valueOf(v));
        e.setTextColor(TEXT);
        e.setSelectAllOnFocus(true);
        return e;
    }

    private LinearLayout labeled(String label, EditText e) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.addView(tv(label, 10, DIM, false));
        c.addView(e);
        return c;
    }

    private static int parse(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (NumberFormatException x) { return def; }
    }

    private void confirm(String msg, final Runnable yes) {
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Excluir link").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("EXCLUIR", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) { yes.run(); } }).show();
    }

    // ------------------------------------------------------------------ usos

    private void uses(final int target) {
        final Dialog dlg = fullscreen("Usos da ANO " + target + " como link", null);
        LinearLayout root = lastRoot;
        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        Dac dac = dac();
        int found = 0;
        for (int i = 0; i < dac.size(); i++) {
            final Ano an = dac.getAno(i);
            if (an == null || !an.present) continue;
            for (int k = 0; k < an.links.length; k++) {
                if (an.links[k].getAno() != target) continue;
                found++;
                final int fi = i, fk = k;
                LinearLayout c = new LinearLayout(a);
                c.setOrientation(LinearLayout.VERTICAL);
                c.setPadding(dp(8), dp(8), dp(8), dp(8));
                GradientDrawable g = new GradientDrawable();
                g.setColor(PANEL);
                g.setCornerRadius(dp(10));
                c.setBackground(g);
                AnimPreview pv = new AnimPreview(a);
                pv.setShowHits(true);
                pv.set(dac, sprites(), i);
                c.addView(pv, new LinearLayout.LayoutParams(-1, dp(180)));
                c.addView(tv("ANO " + i + " · Link " + k, 13, TEXT, true));
                c.addView(tv(flagsText(an.links[k]) + " · " + an.links[k].baseX + "," + an.links[k].baseY + "   (toque para abrir o link)", 10, DIM, false));
                c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { detail(fi, fk); } });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, dp(4), 0, dp(4));
                col.addView(c, lp);
            }
        }
        if (found == 0) col.addView(tv("Nenhuma ANO usa a ANO " + target + " como link.", 13, DIM, false));
        else col.addView(tv(found + " uso(s). A prévia mostra a ANO que cria o link, já com os links, hurtboxes e hitboxes.", 11, DIM, false), 0);
        root.addView(button("VOLTAR", DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }));
        dlg.show();
    }
}
