package com.zue.attackeditor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Activity fina: descobre charNN, carrega 000.cnv/000.dac/000.bin uma vez por personagem e alimenta o layout. */
public final class MainActivity extends Activity {
    private static final File ROOT = new File("/storage/emulated/0/Tap Battle/assets/");

    private LayoutManager ui;
    private final List<File> characters = new ArrayList<File>();

    // personagens carregados (atacante e oponente podem ser o mesmo objeto)
    private int loadedChar = -1;
    private int loadedOpp = -1;
    private int loadedAttack = -1;
    private CharAssets attacker;
    private CharAssets opponent;
    private CharAssets effects;
    private CharAssets charf;
    /** bobjNN do cenario: alvo das cutscenes da flag 20 com ALVO >= 2 (HDAT 13); null se nao houver pasta. */
    private CharAssets bobj;
    private GameData gameData;
    private SoundPlayer sound;
    private boolean anoMode;
    private final List<String> notes = new ArrayList<String>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestFiles();
        I18nUi.init(this);
        ui = new LayoutManager(this);
        ui.attach(this);
        sound = new SoundPlayer(ROOT);
        ui.attackView.setSoundPlayer(sound);
        wire();
        ui.setNavigator(new Navigator() {
            @Override public void openAno(int ano, boolean projectile) { openAnoEditor(ano, projectile); }
            @Override public void back() { closeAnoEditor(); }
        });
        loadCharacters();
    }

    @Override public void onBackPressed() {
        if (ui.handleBack()) { lastBack = 0; return; }
        long now = android.os.SystemClock.uptimeMillis();
        if (lastBack == 0 || now - lastBack > 2000) {
            lastBack = now;
            I18nUi.toast(this, "Toque novamente para sair", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        lastBack = 0;
        new I18nBuilder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Sair do app?")
                .setMessage("Edicoes nao salvas serao perdidas.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("SAIR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { finish(); }
                }).show();
    }

    private long lastBack;

    @Override protected void onResume() {
        super.onResume();
        // voltou da tela de permissao: tenta de novo se ainda nao achou nada
        if (characters.isEmpty()) loadCharacters();
        else if (attacker != null && loadedAttack >= 0) loadAttack(loadedAttack); // gamedata pode ter mudado
    }

    @Override protected void onPause() {
        ui.attackView.pause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (attacker != null) attacker.release();
        if (opponent != null && opponent != attacker) opponent.release();
        if (effects != null) effects.release();
        if (charf != null) charf.release();
        if (bobj != null) bobj.release();
        sound.release();
        super.onDestroy();
    }

    private void requestFiles() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) { }
        }
    }

    private void wire() {
        ui.characterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> p) { }
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos != loadedChar) loadCharacter(pos);
            }
        });
        ui.opponentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> p) { }
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos != loadedOpp) { loadOpponent(pos); if (loadedAttack >= 0) loadAttack(loadedAttack); }
            }
        });
        ui.listModeChip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                anoMode = !anoMode;
                inSub = false;
                ui.setBackBar(null);
                ui.setListModeChecked(anoMode);
                if (attacker != null) { loadedAttack = -1; fillList(); loadAttack(0); }
            }
        });
        ui.beforeSave = new Runnable() { @Override public void run() { dropPlaceholder(); } };
        ui.setAttackHeader(new Runnable() {
            @Override public void run() {
                if (!anoMode || attacker == null) return;
                AnoPicker.showAll(MainActivity.this, attacker.dac, attacker.sprites, Math.max(0, ui.attackSpinner.getSelectedItemPosition()),
                        "Escolher ANO", new AnoPicker.Listener() {
                    @Override public void onPick(int ano) { ui.attackSpinner.setSelection(ano); }
                });
            }
        });
        ui.attackSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> p) { }
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos != loadedAttack) loadAttack(pos);
            }
        });
    }

    // ---- editor de animacao paralelo: abre uma ANO sozinha e volta ao golpe ----
    private boolean inSub;
    private int retAttack = -1;
    private boolean retAnoMode;

    private boolean forceProjectile;

    private void openAnoEditor(int ano, boolean projectile) {
        if (attacker == null) return;
        Ano an = attacker.dac.getAno(ano);
        if (!inSub) {
            retAttack = loadedAttack;
            retAnoMode = anoMode;
        }
        inSub = true;
        forceProjectile = projectile;
        if (!anoMode) {
            anoMode = true;
            ui.setListModeChecked(true);
            fillList();
        }
        loadedAttack = -1;
        loadAttack(ano);
        ui.attackSpinner.setSelection(ano);
        ui.setBackBar("\u25C0 VOLTAR AO " + (retAnoMode ? "ANO " + retAttack : String.format(Locale.US, "GOLPE_%02d", retAttack)));
    }

    private void closeAnoEditor() {
        if (!inSub) return;
        inSub = false;
        forceProjectile = false;
        anoMode = retAnoMode;
        ui.setListModeChecked(anoMode);
        fillList();
        loadedAttack = -1;
        loadAttack(Math.max(0, retAttack));
        ui.attackSpinner.setSelection(Math.max(0, retAttack));
        ui.setBackBar(null);
    }

    private void loadCharacters() {
        characters.clear();
        File[] fs = ROOT.listFiles();
        if (fs != null) {
            for (File f : fs) if (f.isDirectory() && f.getName().matches("char\\d{2}")) characters.add(f);
        }
        Collections.sort(characters, new Comparator<File>() {
            @Override public int compare(File a, File b) { return a.getName().compareTo(b.getName()); }
        });
        ArrayList<String> names = new ArrayList<String>();
        for (File f : characters) names.add(f.getName());
        loadedChar = -1;
        loadedOpp = -1;
        loadedAttack = -1;
        ui.characterSpinner.setAdapter(ui.adapter(this, names));
        ui.opponentSpinner.setAdapter(ui.adapter(this, names));
        ui.status.setText("Assets: " + ROOT.getAbsolutePath() + "  |  personagens: " + characters.size());
        if (effects != null) { effects.release(); effects = null; }
        try {
            effects = CharAssets.loadEffect(ROOT);
            reportLoose(effects);
        } catch (Exception e) {
            notes.add("effect: " + e.getMessage());
        }
        loadBobj();
        if (!characters.isEmpty()) {
            loadOpponent(0);
            loadCharacter(0);
        }
    }

    /** Primeira pasta bobjNN de assets (o jogo carrega uma por fase: GetResName2 = "bobj" + numero com 2 digitos). */
    private void loadBobj() {
        if (bobj != null) { bobj.release(); bobj = null; }
        File[] fs = ROOT.listFiles();
        if (fs == null) return;
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            if (!f.isDirectory() || !f.getName().toLowerCase().startsWith("bobj")) continue;
            try {
                bobj = CharAssets.loadPack(f);
                reportLoose(bobj);
                return;
            } catch (Exception e) {
                notes.add(f.getName() + ": " + e.getMessage());
            }
        }
    }

    /** charfNN com o mesmo numero do charNN do atacante (hitbox flags 41-70). */
    private void loadCharf(CharAssets a) {
        if (charf != null) { charf.release(); charf = null; }
        charfNote = "";
        String n = a.dir.getName();
        File dir = new File(ROOT, "charf00" + n.substring(4));
        if (!dir.isDirectory()) dir = new File(ROOT, "charf" + n.substring(4));
        try {
            charf = CharAssets.loadPack(dir);
            reportLoose(charf);
        } catch (Exception e) {
            charfNote = dir.getName() + ": " + e.getMessage();
        }
    }
    private String charfNote = "";

    /** Avisa quando PNGs soltos da pasta viraram sprites novas (ou nao deu). */
    private void reportLoose(CharAssets a) {
        if (a == null) return;
        if (a.importedLoose > 0) {
            I18nUi.toast(this, a.dir.getName() + ": " + a.importedLoose + " PNG(s) solto(s) viraram sprites novas (os arquivos soltos foram apagados)", android.widget.Toast.LENGTH_LONG).show();
            a.importedLoose = 0;
        }
        if (a.importError != null) {
            notes.add(a.dir.getName() + ": sprites soltas nao importadas (" + a.importError + ")");
            a.importError = null;
        }
    }

    private CharAssets assetsFor(int ci) throws IOException {
        if (attacker != null && attacker.dir.equals(characters.get(ci))) return attacker;
        if (opponent != null && opponent.dir.equals(characters.get(ci))) return opponent;
        return CharAssets.loadChar(characters.get(ci));
    }

    private void loadCharacter(int ci) {
        if (ci < 0 || ci >= characters.size()) return;
        try {
            CharAssets a = assetsFor(ci);
            reportLoose(a);
            CharAssets old = attacker;
            attacker = a;
            inSub = false;
            ui.setBackBar(null);
            loadCharf(a);
            loadedChar = ci;
            loadedAttack = -1;
            if (old != null && old != a && old != opponent) old.release();

            CharData.Move[] mv = a.data.moves;
            fillList();

            String warn = a.dac.getWarnings().isEmpty() ? "" : "  |  avisos DAC: " + a.dac.getWarnings().size();
            ui.status.setText(a.dir.getName() + "  |  ANO=" + a.dac.size() + "  CNV=" + a.cnv.size()
                    + "  golpes=" + mv.length + "  wav=" + a.wavCount + warn);
            ui.setWarnings(a.dac.getWarnings());

            if (listSize() > 0) loadAttack(0);
            else ui.attackView.setData(null);
        } catch (Exception e) {
            ui.setError("Erro: " + e.getMessage());
        }
    }

    private static final int RED = 0xFFFF6B6B, YELLOW = 0xFFFFD84C, DIMC = 0xFF6F7585, NORMAL = 0xFFE6E8EC;

    private int listSize() {
        if (attacker == null) return 0;
        return anoMode ? attacker.dac.size() : attacker.data.moves.length;
    }

    /** Lista de golpes (HDAT 4) ou de todos os ANOs: vermelho = tem hitbox flag 2, amarelo = flag 0. */
    private void fillList() {
        ArrayList<String> labels = new ArrayList<String>();
        ui.setAttackHeaderOn(anoMode);
        if (!anoMode) {
            CharData.Move[] mv = attacker.data.moves;
            for (int i = 0; i < mv.length; i++) {
                Ano an = attacker.dac.getAno(mv[i].animInicial);
                String tag = (an == null || !an.present) ? " (vazio)" : "";
                labels.add(String.format(Locale.US, "GOLPE_%02d  ANO %d%s", i, mv[i].animInicial, tag));
            }
            ui.attackSpinner.setAdapter(ui.adapter(this, labels));
            return;
        }
        int[] kinds = attacker.anoKinds();
        int[] colors = new int[kinds.length];
        for (int i = 0; i < kinds.length; i++) {
            Ano an = attacker.dac.getAno(i);
            boolean empty = an == null || !an.present;
            String tag = empty ? "  (vazio)" : kinds[i] == CharAssets.KIND_ATTACK ? "  ataque"
                    : kinds[i] == CharAssets.KIND_PROJECTILE ? "  projetil" : "";
            labels.add(String.format(Locale.US, "ANO %d%s", i, tag));
            colors[i] = empty ? DIMC : kinds[i] == CharAssets.KIND_ATTACK ? RED
                    : kinds[i] == CharAssets.KIND_PROJECTILE ? YELLOW : NORMAL;
        }
        ui.attackSpinner.setAdapter(ui.adapter(this, labels, colors));
    }

    private void loadOpponent(int ci) {
        if (ci < 0 || ci >= characters.size()) return;
        try {
            CharAssets o = assetsFor(ci);
            reportLoose(o);
            CharAssets old = opponent;
            opponent = o;
            loadedOpp = ci;
            if (old != null && old != o && old != attacker) old.release();
        } catch (Exception e) {
            ui.setError("Erro no oponente: " + e.getMessage());
        }
    }

    // ANO vazia aberta no editor: recebe um frame provisorio (sem imagem) para ter onde editar; se sair sem mexer, volta a ficar vazia
    private Ano placeholder;
    private int placeholderIdx = -1;

    /** Desfaz o frame provisorio se ele continua intocado (a mesma instancia no DAC). */
    private void dropPlaceholder() {
        if (placeholder != null && attacker != null && attacker.dac.getAno(placeholderIdx) == placeholder)
            attacker.dac.setAno(placeholderIdx, new Ano(placeholderIdx, false, 0, 0, new Ano.Link[0], new Ano.Mpt[0]));
        placeholder = null;
        placeholderIdx = -1;
    }

    private void loadAttack(int i) {
        if (i != loadedAttack) ui.closeSheet();
        if (attacker == null || opponent == null || i < 0 || i >= listSize()) return;
        int target = anoMode ? i : attacker.data.moves[i].animInicial;
        if (placeholderIdx != target) dropPlaceholder();
        try {
            Ano probe = attacker.dac.getAno(target);
            boolean emptyAno = probe == null || !probe.present;
            if (emptyAno && target >= 0 && target < attacker.dac.size()) {
                Ano.Mpt f = new Ano.Mpt();
                f.hasTime = true; f.time = 10; f.flags = 0x20; f.image = -1;
                placeholder = new Ano(target, true, 0, 0, new Ano.Link[0], new Ano.Mpt[]{f});
                placeholderIdx = target;
                attacker.dac.setAno(target, placeholder);
            }
            CharData.Move m;
            if (anoMode) {
                m = CharData.genericFrom(i, attacker.data.ownerOf(i));
                m.projectile = (inSub && forceProjectile) || attacker.anoKinds()[i] == CharAssets.KIND_PROJECTILE;
            } else {
                m = attacker.data.moves[i];
            }
            Ano ano = attacker.dac.getAno(m.animInicial);
            if (ano == null || !ano.present) throw new IOException("ANO inexistente: " + m.animInicial);
            ArrayList<String> warns = new ArrayList<String>(notes);
            try {
                gameData = GameData.load(ROOT);
            } catch (Exception e) {
                gameData = null;
                warns.add("gamedata: " + e.getMessage() + " (reacoes do chao ficam sem tabela)");
            }
            if (anoMode && attacker.data.ownerOf(i) == null && attacker.anoKinds()[i] == CharAssets.KIND_PROJECTILE)
                warns.add("flag 0 sem projetil: nenhum golpe do HDAT 4 usa o ANO " + i);
            if (effects == null) warns.add("sem effect: golpes nao mostram efeito de hit");
            java.util.TreeSet<Integer> moveAnos = Saver.anosOfMove(attacker.dac, m, attacker.data);
            String rules = GameRules.details(GameRules.check(attacker.dac, moveAnos, attacker.cnv == null ? 0 : attacker.cnv.size()));
            if (!rules.isEmpty()) warns.addAll(0, java.util.Arrays.asList(rules.split("\n")));
            String nested = GameRules.nestedLinksNote(attacker.dac, moveAnos);
            if (!nested.isEmpty()) warns.add(nested);
            AttackData data = new AttackData(attacker, opponent, effects, gameData, i, m);
            data.charf = charf;
            data.bobj = bobj;
            if (charf == null) warns.add("sem " + charfNote + " (hitbox flags 41-70 sem animacao)");
            loadedAttack = i;
            ui.attackView.setData(data);
            ui.attackView.play();
            ui.info.setText(String.format(Locale.US, "%s \u00b7 ANIM %d \u00b7 MPT %d \u00b7 LINKS %d \u00b7 proj %d/%d/%d",
                    anoMode ? "ANO " + i : String.format(Locale.US, "GOLPE_%02d", i), m.animInicial, ano.mpts.length, ano.links.length, m.projNormal, m.projAbaixo, m.projAcima));
            if (placeholder != null && attacker.dac.getAno(placeholderIdx) == placeholder)
                warns.add(0, "ANO " + placeholderIdx + " vazia: frame provisório sem imagem. Se sair sem editar, ela volta a ficar vazia");
            ui.setWarnings(warns);
        } catch (Exception e) {
            ui.setError("Erro no golpe: " + e.getMessage());
        }
    }
}
