package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Celulas das faixas de velocidade da timeline principal: UMA por Frame e por tipo (speed e accel) em cada eixo, sem unir Frames que mantem a velocidade
 * (o Frame que mantem mostra o valor herdado com "="). Speed e accel do mesmo eixo no mesmo Frame ficam em linhas diferentes; em Frames diferentes dividem a linha.
 * Java puro.
 */
final class MoveCells {
    private MoveCells() { }

    static final int SPEED = 0, ACCEL = 1;

    static final class Cell {
        int frame, kind, line, start, end;
        boolean inherited;
        String text;
    }

    static final class Result {
        final List<Cell> cells = new ArrayList<Cell>();
        /** Linhas da faixa do eixo (1 ou 2). */
        int lines = 1;

        /** A celula que ocupa a linha {@code line} no Frame {@code frame}, ou null. */
        Cell at(int frame, int line) {
            for (Cell c : cells) if (c.frame == frame && c.line == line) return c;
            return null;
        }

        Cell find(int frame, int kind) {
            for (Cell c : cells) if (c.frame == frame && c.kind == kind) return c;
            return null;
        }
    }

    private static String fmt(double px) { return DacText.fix((int) Math.round(px * FrameTools.ONE)); }

    /** {@code startTick[f]} e {@code span[f]}: onde o Frame comeca na timeline e quantos ticks ele dura. */
    static Result build(Ano.Mpt[] m, int axis, int[] startTick, int[] span) {
        Result res = new Result();
        if (m == null) return res;
        String ax = axis == 1 ? "y" : "x";
        int speedBit = 1 << axis, accelBit = 4 << axis;
        for (int f = 0; f < m.length && f < startTick.length; f++) {
            boolean mv = (m[f].flags & 4) != 0;
            int s = startTick[f], e = s + Math.max(1, f < span.length ? span[f] : 1);
            if (mv && (m[f].moveMask & speedBit) != 0) {
                Cell c = new Cell();
                c.frame = f; c.kind = SPEED; c.start = s; c.end = e;
                c.text = ax + " " + fmt(axis == 1 ? m[f].speedY / FrameTools.ONE : m[f].speedX / FrameTools.ONE);
                res.cells.add(c);
            } else if (FrameTools.keeps(m, f)) {
                double v = FrameTools.startSpeed(m, f)[axis];
                if (Math.abs(v) > 1e-9) {
                    Cell c = new Cell();
                    c.frame = f; c.kind = SPEED; c.start = s; c.end = e; c.inherited = true;
                    c.text = ax + " =" + fmt(v);
                    res.cells.add(c);
                }
            }
            if (mv && (m[f].moveMask & accelBit) != 0) {
                Cell c = new Cell();
                c.frame = f; c.kind = ACCEL; c.start = s; c.end = e;
                c.text = "a" + ax + " " + fmt(axis == 1 ? m[f].accelY / FrameTools.ONE : m[f].accelX / FrameTools.ONE);
                res.cells.add(c);
            }
        }
        Collections.sort(res.cells, new Comparator<Cell>() {
            public int compare(Cell a, Cell b) { return a.start != b.start ? a.start - b.start : a.kind - b.kind; }
        });
        int[][] spans = new int[res.cells.size()][];
        for (int i = 0; i < spans.length; i++) spans[i] = new int[]{res.cells.get(i).start, res.cells.get(i).end};
        int[] line = ReactionLayout.stack(spans);
        for (int i = 0; i < line.length; i++) { res.cells.get(i).line = line[i]; res.lines = Math.max(res.lines, line[i] + 1); }
        return res;
    }
}
