package com.zue.attackeditor;

/**
 * TROCAR golpes: troca so as duas linhas do HDAT 4 (o Bin); os ANOs e as reacoes ficam onde estao, so o numero do golpe (e com ele o comando que o dispara)
 * muda. Java puro.
 */
final class MoveSwap {
    private MoveSwap() { }

    /** Os golpes {@code i} e {@code j} podem trocar: indices validos e diferentes, e a regra do jogo (0, 3 e 6 so entre si) vale nos dois sentidos. */
    static boolean canSwap(CharData data, int i, int j) {
        return data != null && i != j && i >= 0 && j >= 0 && i < data.moves.length && j < data.moves.length
                && MoveTransplant.canReplace(i, j) && MoveTransplant.canReplace(j, i);
    }

    /** Troca as 24 colunas das duas linhas. false se nao pode. */
    static boolean swap(CharData data, int i, int j) {
        if (!canSwap(data, i, j)) return false;
        CharData.Move old = data.moves[i].copy();
        data.moves[i].copyFrom(data.moves[j]);
        data.moves[j].copyFrom(old);
        return true;
    }
}
