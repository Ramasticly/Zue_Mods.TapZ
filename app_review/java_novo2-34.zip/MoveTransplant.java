package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * "Salvar este golpe em outro personagem": leva o golpe (HDAT 4) e tudo o que ele alcanca para outra pasta de personagem.
 * Os ANOs entram no fim do DAC do destino (renumerados), as imagens viram sprites novas no fim do CNV do destino e as tabelas de
 * reacao do personagem que o golpe usa vao para um slot livre (ou igual) do destino. O golpe do destino e substituido no HDAT 4.
 * Java puro, menos {@link Sprites} (quem corta/cola a imagem e a tela).
 */
final class MoveTransplant {
    private MoveTransplant() { }

    /** Maior ANO que um link guarda (12 bits). */
    static final int MAX_ANO = 0x0FFF;

    /** Poe a imagem {@code srcImage} da origem no CNV do destino e devolve o indice novo; -1 se a imagem nao tem desenho. */
    interface Sprites { int add(int srcImage) throws IOException; }

    static final class Plan {
        /** ANO da origem -> ANO novo no destino. */
        final TreeMap<Integer, Integer> anoMap = new TreeMap<Integer, Integer>();
        /** ANOs novos, prontos para entrar no fim do DAC do destino. */
        final List<Ano> anos = new ArrayList<Ano>();
        /** Golpe com os ANOs renumerados (vai para o HDAT 4 do destino). */
        CharData.Move move;
        /** Tipo de reacao na origem -> tipo no destino (so os que mudaram de lugar ou foram achados iguais). */
        final TreeMap<Integer, Integer> reactionMap = new TreeMap<Integer, Integer>();
        /** Slot do destino -> tabela da origem que precisa ser gravada nele. */
        final TreeMap<Integer, ReactionTable> reactionWrites = new TreeMap<Integer, ReactionTable>();
        final List<String> warnings = new ArrayList<String>();
        int sprites;
        int firstAno() { return anos.isEmpty() ? -1 : anos.get(0).index; }
    }

    // ---- o que copiar ----

    /**
     * ANOs que o golpe usa: os campos do HDAT 4 (+ ANO+1/+2 do tiro triplo e ANO+1 do agarrao) e os links deles. Nao entram os ANOs
     * "implicitos" (hitbox flag 71-125 aponta para o ANO 201+..., cutscene da flag 20): esses sao do personagem e ficam os do destino.
     */
    static TreeSet<Integer> anosToCopy(Dac dac, CharData.Move m) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        ArrayList<Integer> todo = new ArrayList<Integer>();
        for (int r : anoRefs(m)) if (r > 0) todo.add(Integer.valueOf(r));
        if ((m.flags & 4) != 0 && m.projNormal > 0) { todo.add(Integer.valueOf(m.projNormal + 1)); todo.add(Integer.valueOf(m.projNormal + 2)); }
        if ((m.flags & (8 | 128)) != 0 && m.animInicial > 0) todo.add(Integer.valueOf(m.animInicial + 1));
        while (!todo.isEmpty()) {
            int i = todo.remove(todo.size() - 1).intValue();
            if (i < 0 || i >= dac.size() || out.contains(Integer.valueOf(i))) continue;
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            out.add(Integer.valueOf(i));
            for (int k = 0; k < a.links.length; k++) todo.add(Integer.valueOf(a.links[k].getAno()));
        }
        return out;
    }

    private static int[] anoRefs(CharData.Move m) {
        return new int[]{m.animInicial, m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao,
                m.subId, m.subAoAcertar, m.subChao, m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr, m.animEndAr,
                m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado};
    }

    /** Quais golpes do destino o golpe {@code src} pode substituir: 0, 3 e 6 so substituem o proprio numero; os demais, qualquer um menos 0, 3 e 6. */
    static boolean canReplace(int src, int dst) {
        boolean sp = isSpecial(src), dp = isSpecial(dst);
        return sp || dp ? src == dst : true;
    }

    static boolean isSpecial(int move) { return move == 0 || move == 3 || move == 6; }

    // ---- plano ----

    /**
     * Monta o plano: renumera os ANOs (o primeiro vai para o fim do DAC do destino), manda as imagens para {@code spr}, escolhe os slots
     * de reacao do destino e devolve o golpe novo. Nao escreve nada.
     */
    static Plan build(Dac srcDac, CharData srcData, CharData.Move m, Dac dstDac, CharData dstData, Sprites spr) throws IOException {
        return build(srcDac, srcData, m, dstDac, dstData, spr, null);
    }

    /** {@code writable}: slots de reacao (0..19) do destino que o 000.bin.txt dele consegue receber ({@link Saver#writableReactionSlots}); null = todos. */
    static Plan build(Dac srcDac, CharData srcData, CharData.Move m, Dac dstDac, CharData dstData, Sprites spr, java.util.Set<Integer> writable) throws IOException {
        Plan p = new Plan();
        TreeSet<Integer> set = anosToCopy(srcDac, m);
        int base = dstDac.size();
        if (base + set.size() - 1 > MAX_ANO)
            throw new IOException("o DAC do destino ficaria com " + (base + set.size()) + " ANOs (maximo " + (MAX_ANO + 1) + ")");
        int k = 0;
        for (Integer s : set) p.anoMap.put(s, Integer.valueOf(base + k++));

        // reacoes do personagem que o golpe usa
        planReactions(srcDac, srcData, set, dstDac, dstData, p, writable);

        TreeMap<Integer, Integer> imgMap = new TreeMap<Integer, Integer>();
        int soundFrames = 0, charFlagFrames = 0, missingImages = 0, droppedLinks = 0;
        for (Integer s : set) {
            Ano a = srcDac.getAno(s.intValue());
            ArrayList<Ano.Link> links = new ArrayList<Ano.Link>();
            for (int i = 0; i < a.links.length; i++) {
                Integer to = p.anoMap.get(Integer.valueOf(a.links[i].getAno()));
                if (to == null) { droppedLinks++; continue; }
                links.add(new Ano.Link(a.links[i].baseX, a.links[i].baseY, (a.links[i].flags & ~0x0FFF) | to.intValue()));
            }
            Ano.Mpt[] mp = new Ano.Mpt[a.mpts.length];
            for (int q = 0; q < mp.length; q++) {
                Ano.Mpt c = a.mpts[q].copy();
                if (c.image >= 0) {
                    Integer ni = imgMap.get(Integer.valueOf(c.image));
                    if (ni == null) {
                        int added = spr.add(c.image);
                        if (added >= 0) p.sprites++;
                        ni = Integer.valueOf(added);
                        imgMap.put(Integer.valueOf(c.image), ni);
                    }
                    if (ni.intValue() < 0) missingImages++;
                    c.image = ni.intValue();
                }
                if ((c.flags & 0x40) != 0 && c.hits.length > 0) {
                    int v = c.optData[1];
                    int idx = v % 50;
                    if (v >= 0 && idx >= 30 && idx < 30 + CharData.REACTION_COUNT) {
                        Integer nt = p.reactionMap.get(Integer.valueOf(idx - 30));
                        if (nt != null) c.optData[1] = (v / 50) * 50 + 30 + nt.intValue();
                    }
                }
                if ((c.flags & 8) != 0 && c.se >= 80) soundFrames++;
                for (int h = 0; h < c.hits.length; h++) {
                    int f = c.hits[h].flag;
                    if (f == 20 || (f >= 41 && f <= 125)) { charFlagFrames++; break; }
                }
                c.normalize();
                mp[q] = c;
            }
            p.anos.add(new Ano(p.anoMap.get(s).intValue(), true, a.flags, a.priority, links.toArray(new Ano.Link[0]), mp));
        }

        CharData.Move nm = m.copy();
        nm.generic = false;
        nm.animInicial = mapRef(p, m.animInicial); nm.projNormal = mapRef(p, m.projNormal); nm.projAbaixo = mapRef(p, m.projAbaixo);
        nm.projAcima = mapRef(p, m.projAcima); nm.projGlobal = mapRef(p, m.projGlobal); nm.projAoAcertar = mapRef(p, m.projAoAcertar);
        nm.projChao = mapRef(p, m.projChao); nm.subId = mapRef(p, m.subId); nm.subAoAcertar = mapRef(p, m.subAoAcertar);
        nm.subChao = mapRef(p, m.subChao); nm.animAoAcertar = mapRef(p, m.animAoAcertar); nm.animSeqChao = mapRef(p, m.animSeqChao);
        nm.animEndChao = mapRef(p, m.animEndChao); nm.animSeqAr = mapRef(p, m.animSeqAr); nm.animEndAr = mapRef(p, m.animEndAr);
        nm.pousoErrar = mapRef(p, m.pousoErrar); nm.pousoAcertar = mapRef(p, m.pousoAcertar); nm.oponenteAgarrado = mapRef(p, m.oponenteAgarrado);
        p.move = nm;

        if (droppedLinks > 0) p.warnings.add(droppedLinks + " link(s) apontavam para ANO inexistente na origem e foram removidos.");
        if (missingImages > 0) p.warnings.add(missingImages + " frame(s) usavam imagem sem desenho na origem: ficaram sem imagem.");
        if (soundFrames > 0) p.warnings.add(soundFrames + " frame(s) tocam sons do personagem de origem (id 80 ou mais); os sons não foram copiados, então no destino tocam outro som ou nenhum.");
        if (charFlagFrames > 0) p.warnings.add(charFlagFrames + " frame(s) usam hitbox flags de animação do personagem (20 cutscene, 41-125 auras/charf): elas apontam para os dados do destino, não da origem.");
        return p;
    }

    private static int mapRef(Plan p, int v) {
        if (v <= 0) return v;
        Integer to = p.anoMap.get(Integer.valueOf(v));
        if (to == null) { p.warnings.add("O golpe apontava para o ANO " + v + ", que não existe na origem: o campo ficou 0."); return 0; }
        return to.intValue();
    }

    private static boolean present(ReactionTable t) { return t != null && t.rows > 0; }

    static boolean sameTable(ReactionTable a, ReactionTable b) {
        if (a == null || b == null || a.rows != b.rows) return false;
        for (int r = 0; r < a.rows; r++) for (int c = 0; c < ReactionTable.STRIDE; c++) if (a.u8(r, c) != b.u8(r, c)) return false;
        return true;
    }

    /**
     * Escolhe, para cada tabela de reacao que o golpe usa, o slot do destino: igual > slot VAZIO gravavel > slot cheio que nenhum ANO do destino usa >
     * o mesmo numero (sobrescreve, com aviso).
     */
    private static void planReactions(Dac srcDac, CharData srcData, TreeSet<Integer> set, Dac dstDac, CharData dstData, Plan p, java.util.Set<Integer> writable) {
        TreeSet<Integer> needed = Saver.reactionsUsed(srcDac, set);
        if (needed.isEmpty()) return;
        TreeSet<Integer> dstAnos = new TreeSet<Integer>();
        for (int i = 0; i < dstDac.size(); i++) { Ano a = dstDac.getAno(i); if (a != null && a.present) dstAnos.add(Integer.valueOf(i)); }
        TreeSet<Integer> dstUsed = Saver.reactionsUsed(dstDac, dstAnos);
        TreeSet<Integer> taken = new TreeSet<Integer>();
        for (Integer tObj : needed) {
            int t = tObj.intValue();
            ReactionTable st = srcData.reaction(t);
            if (!present(st)) { p.warnings.add("A reação do personagem " + t + " usada pelo golpe não existe na origem; ficou como estava."); continue; }
            int pick = -1;
            boolean identical = false;
            if (present(dstData.reaction(t)) && sameTable(st, dstData.reaction(t)) && !taken.contains(Integer.valueOf(t))) { pick = t; identical = true; }
            for (int s = 0; pick < 0 && s < CharData.REACTION_COUNT; s++)
                if (present(dstData.reaction(s)) && sameTable(st, dstData.reaction(s)) && !taken.contains(Integer.valueOf(s))) { pick = s; identical = true; }
            for (int s = 0; pick < 0 && s < CharData.REACTION_COUNT; s++) {                    // vazio gravavel
                int slot = (t + s) % CharData.REACTION_COUNT;
                if (!present(dstData.reaction(slot)) && !taken.contains(Integer.valueOf(slot)) && (writable == null || writable.contains(Integer.valueOf(slot)))) pick = slot;
            }
            for (int s = 0; pick < 0 && s < CharData.REACTION_COUNT; s++) {                    // cheio, mas nenhum ANO do destino usa
                int slot = (t + s) % CharData.REACTION_COUNT;
                if (present(dstData.reaction(slot)) && !dstUsed.contains(Integer.valueOf(slot)) && !taken.contains(Integer.valueOf(slot))) pick = slot;
            }
            if (pick < 0 && present(dstData.reaction(t)) && !taken.contains(Integer.valueOf(t))) {
                pick = t;
                p.warnings.add("Sem slot livre de reação no destino: a reação " + t + " do destino foi sobrescrita (outros golpes dele podem usá-la).");
            }
            if (pick < 0) { p.warnings.add("Sem slot de reação no destino para a reação " + t + " do golpe: ela continua apontando para o número original."); continue; }
            taken.add(Integer.valueOf(pick));
            p.reactionMap.put(tObj, Integer.valueOf(pick));
            if (!identical) p.reactionWrites.put(Integer.valueOf(pick), st);
        }
    }

    // ---- texto ----

    /** Poe os ANOs no fim do DAC_ACT_ { ... } do destino (antes da ultima chave). */
    static String appendAnos(String dacText, List<Ano> anos) throws IOException {
        int end = dacText.lastIndexOf('}');
        if (end < 0) throw new IOException("000.dac.txt sem a chave final do DAC_ACT_");
        StringBuilder sb = new StringBuilder(dacText.substring(0, end));
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n') sb.append('\n');
        for (Ano a : anos) sb.append(Saver.indent(DacText.ano(a, -1))).append('\n');
        return sb.append(dacText.substring(end)).toString();
    }

    /** O 000.bin.txt do destino com o golpe {@code dstMove} trocado e as tabelas de reacao gravadas. */
    static String patchBin(String binText, Plan p, int dstMove, List<String> warnings) throws IOException {
        boolean[] f = new boolean[1];
        String t = Saver.patchMove(binText, p.move, dstMove, f);
        if (!f[0]) throw new IOException("bloco $GOLPE_" + dstMove + " não achado no 000.bin.txt do destino");
        for (java.util.Map.Entry<Integer, ReactionTable> e : p.reactionWrites.entrySet()) {
            t = Saver.patchReaction(t, e.getValue(), e.getKey().intValue(), f);
            if (!f[0]) warnings.add("Bloco $REACAO_DANO_" + e.getKey() + " não achado no 000.bin.txt do destino: a reação não foi gravada.");
        }
        return t;
    }

    // ---- gravacao ----

    /**
     * Grava no Runtime do destino (000.dac.txt e 000.bin.txt; o CNV e as folhas sao gravados pelo {@code commit}, entre o backup e os .txt). Faz cópia dos dois .txt em
     * Tap Battle/TBRE/Backups/AAAAMMDD_HHMMSS_charNN_transplante/ antes de mexer. Devolve a pasta do backup.
     */
    interface Commit { void run() throws IOException; }

    /** {@code commit} grava as folhas e o CNV do destino (depois do backup e antes dos .txt, para o DAC nunca apontar para sprite que nao existe). */
    static File write(File dir, Plan p, int dstMove, List<String> warnings, Commit commit) throws IOException {
        File fd = new File(dir, "000.dac.txt"), fb = new File(dir, "000.bin.txt");
        if (!fd.isFile()) throw new IOException("000.dac.txt não encontrado em " + dir.getPath());
        if (!fb.isFile()) throw new IOException("000.bin.txt não encontrado em " + dir.getPath());
        String dt = appendAnos(Saver.readText(fd), p.anos);
        String bt = patchBin(Saver.readText(fb), p, dstMove, warnings);
        File bk = new File(Saver.backupsDir(dir), new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date()) + "_" + dir.getName() + "_transplante");
        bk.mkdirs();
        Saver.write(new File(bk, fd.getName()), Saver.readText(fd));
        Saver.write(new File(bk, fb.getName()), Saver.readText(fb));
        File fc = new File(dir, "000.cnv.txt");
        if (fc.isFile()) Saver.write(new File(bk, fc.getName()), Saver.readText(fc));
        if (commit != null) commit.run();
        Saver.write(fd, dt);
        Saver.write(fb, bt);
        return bk;
    }
}
