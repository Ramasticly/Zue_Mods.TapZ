package com.zue.attackeditor;

/** Navegacao entre o golpe e o editor de animacao paralelo (uma ANO aberta sozinha). */
public interface Navigator {
    /** Abre a ANO do DAC do atacante no modo ANO, com botao para voltar ao golpe. A origem (destaque em EDITAR NOS USOS) e o ANO aberto agora. */
    void openAno(int anoIndex, boolean projectile);
    /** Como openAno, mas o ANO e um efeito/aura (nao um personagem nem um projetil): nao pousa nem tem sombra. */
    void openEffect(int anoIndex);
    /** Como openAno/openEffect, com a origem dita por quem chama ({@code origin} = ANO de onde se veio; -1 = sem origem, nada fica destacado). */
    void openAnoFrom(int anoIndex, boolean projectile, boolean effect, int origin);
    /** EDITAR NOS USOS: grade dos usos do ANO aberto; tocar num abre o ANO no contexto daquele uso. */
    void openUses();
    void back();
}
