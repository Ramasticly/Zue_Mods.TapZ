package com.zue.attackeditor;

/** Navegacao entre o golpe e o editor de animacao paralelo (uma ANO aberta sozinha). */
public interface Navigator {
    /** Abre a ANO do DAC do atacante no modo ANO, com botao para voltar ao golpe. */
    void openAno(int anoIndex, boolean projectile);
    /** Como openAno, mas o ANO e um efeito/aura (nao um personagem nem um projetil): nao pousa nem tem sombra. */
    void openEffect(int anoIndex);
    void back();
}
