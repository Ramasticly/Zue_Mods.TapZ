package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

/**
 * Avisos no estilo dos da principal ({@link QuickNotice}: faixa colorida arredondada, texto branco, X para fechar e botoes de acao nos cantos de baixo),
 * empilhados no topo da previa da tela de reacao. Cada aviso e uma {@code QuickNotice}; X fecha so aquele ({@code onClose} recebe o texto).
 */
final class NoticeBar extends LinearLayout {
    interface OnClose { void closed(QuickNotice n); }

    private final float d;

    NoticeBar(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
    }

    private int dp(float v) { return Math.round(v * d); }

    private TextView button(String label, int bg) {
        TextView t = new I18nTextView(getContext());
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(6));
        t.setBackground(g);
        t.setClickable(true);
        return t;
    }

    /** Mostra os avisos (vazio = barra escondida). */
    void show(List<QuickNotice> list, final OnClose onClose) {
        removeAllViews();
        setVisibility(list == null || list.isEmpty() ? GONE : VISIBLE);
        if (list == null) return;
        for (final QuickNotice n : list) {
            final LinearLayout box = new LinearLayout(getContext());
            box.setOrientation(VERTICAL);
            box.setPadding(dp(10), dp(8), dp(10), dp(8));
            GradientDrawable g = new GradientDrawable();
            g.setColor(n.color);
            g.setCornerRadius(dp(8));
            box.setBackground(g);
            LinearLayout top = new LinearLayout(getContext());
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView tx = new I18nTextView(getContext());
            tx.setText(n.text);
            tx.setTextColor(Color.WHITE);
            tx.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            top.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView x = button("✕", n.buttonColor);
            x.setPadding(dp(8), dp(4), dp(8), dp(4));
            x.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                box.setVisibility(GONE);
                if (onClose != null) onClose.closed(n);
            } });
            LinearLayout.LayoutParams xl = new LinearLayout.LayoutParams(-2, -2);
            xl.leftMargin = dp(8);
            top.addView(x, xl);
            box.addView(top);
            if (!n.left.isEmpty() || !n.right.isEmpty()) {
                LinearLayout row = new LinearLayout(getContext());
                for (final QuickNotice.Action a : n.left) row.addView(action(a, box, n, onClose));
                View gap = new View(getContext());
                row.addView(gap, new LinearLayout.LayoutParams(0, 1, 1f));
                for (final QuickNotice.Action a : n.right) row.addView(action(a, box, n, onClose));
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
                rl.topMargin = dp(8);
                box.addView(row, rl);
            }
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
            bl.setMargins(dp(8), dp(4), dp(8), 0);
            addView(box, bl);
        }
    }

    private View action(final QuickNotice.Action a, final LinearLayout box, final QuickNotice n, final OnClose onClose) {
        TextView b = button(a.label, n.buttonColor);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            if (a.closes) { box.setVisibility(GONE); if (onClose != null) onClose.closed(n); }
            if (a.run != null) a.run.run();
        } });
        return b;
    }
}
