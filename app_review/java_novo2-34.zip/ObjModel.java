package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Modelo de "objetos" da timeline baseada em sprite.
 * Um objeto e um hit (flag) que se mantem por frames consecutivos: a identidade e (flag, ocorrencia da flag no frame).
 * Quando x/y/largura/altura mudam entre frames, o frame da mudanca e um keyframe.
 * Tudo devolve arrays novos.
 */
final class ObjModel {
    private ObjModel() { }

    static final int HITBOX = 0, HURTBOX = 1, PROJ = 2, EFFECT = 3, ACTION = 4;
    static final String[] KIND_NAMES = {"Hitbox", "Hurtbox", "Projetil", "Efeito", "Acao especial"};
    static final int[] KIND_COLORS = {0xFFE5484D, 0xFF3DDC84, 0xFFFF9A3C, 0xFFB07CFF, 0xFFB8C0CC};

    static int kindOf(int flag) {
        if (flag == 2) return HITBOX;
        if (flag == 1) return HURTBOX;
        if (flag == 0) return PROJ;
        if ((flag >= 10 && flag <= 17) || (flag >= 41 && flag <= 125)) return EFFECT;
        return ACTION;
    }

    /** Nome de uma acao especial (sem expor o numero da flag, salvo quando desconhecida). */
    static String actionName(int flag) {
        switch (flag) {
            case 3: return "Tremer cenario (leve)";
            case 4: return "Tremer cenario (medio)";
            case 5: return "Tremer cenario (forte)";
            case 20: return "Cutscene";
            case 26: return "Inimigo nao defende";
            case 27: return "Impedir cancelamento";
            case 28: return "Dano ignora ataque/defesa";
            case 30: return "Zoom de camera";
            case 31: return "Zoom de camera";
            case 32: return "Dano em si mesmo";
            case 33: return "Estado especial C (sem efeito)";
            case 34: return "Curar vida";
            case 37: return "Sem contagem de combo";
            case 38: return "Bloquear sequencia";
            case 39: return "Teleportar ate o oponente";
            case 40: return "Puxar oponente";
            case ACT_BEHIND: return "Teleportar atras do oponente";
            case VF_WINDOW: return windowName();
            case VF_SCENE: return "Esconder cenario";
            case VF_WALL: return "Impacto na parede";
            default:
                if (isDust(flag)) return "Poeira / fumaca";
                return "Acao desconhecida (" + flag + ")";
        }
    }

    /**
     * "Teleportar atras do oponente": item do menu "+" (pseudo-codigo, nunca vai para o arquivo). No arquivo e o hit flag 40 (Puxar oponente)
     * com x NEGATIVO mais o Flip X do sprite no mesmo frame; o app reconhece o par por essa combinacao ({@link #isBehindHit}).
     */
    static final int ACT_BEHIND = 1040, BEHIND_X = -120;
    /**
     * Formato atual do Teleportar atras: hit flag 39 (o PERSONAGEM vai ate a posicao do oponente) + Flip X + speed X propria POSITIVA no mesmo
     * frame: a velocidade e relativa a direcao do personagem (wObjFlag), que o Flip X do frame (wActFlag, so desenho) NAO inverte; entao o
     * personagem atravessa o oponente e para do outro lado, com o sprite virado para ele. Deslocamento total = speed X * ticks do frame; padrao {@link #BEHIND_DIST} px (o jogo usa 60 px no contra-ataque da guarda, md 912). O formato antigo
     * (flag 40 com x negativo, que puxava o OPONENTE para tras do personagem) continua reconhecido.
     */
    static final int BEHIND_DIST = 60;

    /** Acoes oferecidas ao adicionar (flag, nome). */
    static final int[] ACTION_FLAGS = {3, 4, 5, 20, 26, 27, 28, 30, 32, 34, 37, 38, 39, 40};

    /**
     * Flag VIRTUAL (acima de 255, nunca vai para o arquivo): janela 512 do frame (wOptFlag & 512).
     * Aparece na timeline como acao especial ("Tentar agarrao" / "Repetir projetil") e liga/desliga o bit do frame.
     */
    static final int VF_WINDOW = 512;
    /** Outras flags virtuais da wOptFlag: 1024 = esconder cenario, 2048 = impacto na parede, 4096+t (t = 1..15) = poeira/fumaca. */
    static final int VF_SCENE = 1024, VF_WALL = 2048, VF_DUST = 4096;

    static boolean isVirtual(int flag) { return flag >= 256; }
    static boolean isDust(int flag) { return flag > VF_DUST && flag <= VF_DUST + 15; }

    /** Tipo de poeira (0 = nenhuma) dos bits 12-15 de uma wOptFlag. */
    static int dustTypeOf(int optFlag) { return (optFlag >> 12) & 15; }

    /** Pacote da poeira/fumaca do tipo 1..15 (CheckOptFlag do jogo): 0 = bobj (tipos 1-5), 1 = effect.pac (6-15); -1 = tipo invalido. */
    static int dustPack(int type) { return type >= 1 && type <= 5 ? 0 : type >= 6 && type <= 15 ? 1 : -1; }

    /** ANO da poeira do tipo 1..15 (virada para a direita): 1-5 = bobj 10-14, 6-7 = effect 78-79, 8-15 = effect 70-77; -1 = invalido. */
    static int dustAno(int type) {
        if (type >= 1 && type <= 5) return type + 9;
        if (type == 6 || type == 7) return type + 72;
        if (type >= 8 && type <= 15) return type + 62;
        return -1;
    }

    /** Quando o objeto esta virado para a esquerda o jogo usa a ANO + 80. */
    static final int DUST_FLIP_ANO = 80;

    /** Seletor de poeira (bits 4096..32768 da wOptFlag), 0 = nenhuma. */
    static int dustOf(Ano.Mpt m) { return (m.flags & 0x40) != 0 ? (m.optFlag >> 12) & 15 : 0; }

    private static boolean vHas(Ano.Mpt m, int flag) {
        if (isDust(flag)) return dustOf(m) == flag - VF_DUST;
        return optFlagBit(m, flag);
    }

    private static Ano.Mpt vSet(Ano.Mpt m, int flag, boolean on) {
        if (isDust(flag)) {
            if (!on && dustOf(m) != flag - VF_DUST) return m;
            Ano.Mpt c = m.copy();
            c.optFlag &= ~0xF000;
            if (on) { c.flags |= 0x40; c.optFlag |= (flag - VF_DUST) << 12; }
            c.normalize();
            return c;
        }
        return setOptFlagBit(m, flag, on);
    }

    private static Ano.Hit vHit(int flag) {
        Ano.Hit h = new Ano.Hit();
        h.flag = flag;
        return h;
    }

    // ---- contexto das flags virtuais dependentes de estado
    private static int curAno = -1;
    private static java.util.Set<Integer> wallAnos = new java.util.HashSet<Integer>();
    static void setCurAno(int ano) { curAno = ano; }

    /** ANOs de reacao do gamedata com velocidade/aceleracao X: so nelas o impacto na parede faz sentido. */
    static void setGameContext(GameData gd) {
        java.util.Set<Integer> set = new java.util.HashSet<Integer>();
        if (gd != null) {
            for (int t = 0; t < GameData.REACTION_COUNT; t++) {
                ReactionTable rt = gd.reaction(t);
                if (rt == null) continue;
                for (int r = 0; r < rt.rows; r++) {
                    if (rt.s8(r, 3) != 0 || rt.s8(r, 5) != 0 || rt.s8(r, 7) != 0 || rt.s8(r, 9) != 0) set.add(Integer.valueOf(Math.abs(rt.s8(r, 2))));
                }
            }
        }
        wallAnos = set;
    }
    static boolean wallAllowed() { return wallAnos.contains(Integer.valueOf(curAno)); }
    static final int WIN_NONE = 0, WIN_GRAB = 1, WIN_REPEAT = 2, WIN_CONFLICT = 3, WIN_COMBO = 4;
    private static int windowUse = WIN_NONE;


    /** Para que a janela 512 serve neste golpe (quem usa: agarrao 8/128 ou repeticao do projetil 0/3/6). */
    static int windowUseOf(CharData.Move mv, int moveIndex) {
        if (FixedAnos.hasComboWindow(curAno)) return WIN_COMBO;            // ANOs 30 e 32: o jogo usa a janela 512 para continuar o combo do botao A (md 879)
        if (mv == null || mv.generic) return WIN_NONE;
        boolean rep = mv.repeats(moveIndex);
        if (mv.grabs() && rep) return WIN_CONFLICT;
        if (mv.grabWorks()) return WIN_GRAB;
        if ((moveIndex == 0 || moveIndex == 3 || moveIndex == 6) && mv.hasProjectile()) return WIN_REPEAT;
        return WIN_NONE;
    }

    /** Chamado quando o golpe muda: atualiza o nome da acao virtual. */
    static void setWindowContext(CharData.Move mv, int moveIndex) { windowUse = windowUseOf(mv, moveIndex); }

    /** Uso da janela 512 agora: a do golpe, ou a de combo se o ANO aberto e o 30 / 32. */
    private static int windowUseNow() { return FixedAnos.hasComboWindow(curAno) ? WIN_COMBO : windowUse; }

    static String windowName() {
        switch (windowUseNow()) {
            case WIN_GRAB: return "Tentar agarrão";
            case WIN_REPEAT: return "Repetir projétil";
            case WIN_CONFLICT: return "Janela 512 (conflito)";
            case WIN_COMBO: return "Janela de combo (A→A)";
            default: return "Janela de cancel (512)";
        }
    }

    /** Acoes do "+": as comuns e, se o golpe permite, a janela 512. */
    static int[] actionFlagsFor(CharData.Move mv, int moveIndex) { return actionFlagsFor(mv, moveIndex, null); }

    /**
     * Com o frame do ponteiro: se ele ja tem Teleportar atras, o Puxar oponente e o proprio Teleportar atras saem da lista
     * (a metade "puxar" pertence ao Teleportar atras); senao o Teleportar atras entra depois do Puxar oponente.
     */
    static int[] actionFlagsFor(CharData.Move mv, int moveIndex, Ano.Mpt frame) {
        int u = windowUseOf(mv, moveIndex);
        boolean behind = frame != null && hasBehind(frame);
        boolean legacy = false;                                            // formato antigo: a metade de puxar (flag 40) pertence ao Teleportar atras
        if (frame != null) for (Ano.Hit h : hitsOf(frame)) if (h.flag == 40 && isBehindHit(frame, h)) legacy = true;
        java.util.ArrayList<Integer> l = new java.util.ArrayList<Integer>();
        for (int i = 0; i < ACTION_FLAGS.length; i++) {
            int fl = ACTION_FLAGS[i];
            if (fl == 40 && legacy) continue;
            l.add(Integer.valueOf(fl));
            if (fl == 40 && !behind) l.add(Integer.valueOf(ACT_BEHIND));
        }
        l.add(Integer.valueOf(VF_SCENE));
        l.add(Integer.valueOf(VF_DUST + 1));
        if (wallAllowed()) l.add(Integer.valueOf(VF_WALL));
        if (u == WIN_GRAB || u == WIN_REPEAT || u == WIN_COMBO) l.add(Integer.valueOf(VF_WINDOW));
        int[] r = new int[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i).intValue();
        return r;
    }

    private static final Ano.Hit WINDOW_HIT = new Ano.Hit();
    static { WINDOW_HIT.flag = VF_WINDOW; }

    /** Hits reais do frame mais o hit virtual da janela 512 (se o bit estiver ligado). */
    static Ano.Hit[] allHits(Ano.Mpt m) {
        Ano.Hit[] real = hitsOf(m);
        if ((m.flags & 0x40) == 0 || (m.optFlag & (512 | 1024 | 2048 | 0xF000)) == 0) return real;
        java.util.ArrayList<Ano.Hit> extra = new java.util.ArrayList<Ano.Hit>();
        // fora de agarrao/repeticao a janela 512 nao aparece, e o impacto na parede so nos ANOs de reacao (os bits sao preservados)
        if (windowUseNow() != WIN_NONE && optFlagBit(m, 512)) extra.add(WINDOW_HIT);
        if (optFlagBit(m, VF_SCENE)) extra.add(vHit(VF_SCENE));
        if (optFlagBit(m, VF_WALL) && wallAllowed()) extra.add(vHit(VF_WALL));
        int dt = dustOf(m);
        if (dt != 0) extra.add(vHit(VF_DUST + dt));
        if (extra.isEmpty()) return real;
        Ano.Hit[] r = new Ano.Hit[real.length + extra.size()];
        System.arraycopy(real, 0, r, 0, real.length);
        for (int i = 0; i < extra.size(); i++) r[real.length + i] = extra.get(i);
        return r;
    }

    /** Efeitos disponiveis: faixa de flags e quantas ha em cada pacote. */
    static final int FX_GENERAL_FIRST = 10, FX_GENERAL_LAST = 17;
    static final int FX_CHARF_FIRST = 41, FX_CHARF_LAST = 70;
    static final int FX_CHAR_FIRST = 71, FX_CHAR_LAST = 125;

    /** 0 = effect.pac, 1 = charf, 2 = personagem. */
    static int fxPack(int flag) { return flag <= FX_GENERAL_LAST ? 0 : flag <= FX_CHARF_LAST ? 1 : 2; }
    static int fxAno(int flag) { return flag <= FX_GENERAL_LAST ? 50 + flag - 10 : flag <= FX_CHARF_LAST ? flag - 41 + 3 : 201 + flag - 71; }
    static int fxFlag(int pack, int ano) {
        if (pack == 0) return ano - 50 + 10;
        if (pack == 1) return ano - 3 + 41;
        return ano - 201 + 71;
    }
    /** Rotulo curto do efeito na timeline: "effect N" (effect.pac), "charf N" (charf) ou "char N" (personagem), com N = ANO do pacote. */
    static String fxLabel(int flag) {
        int pack = fxPack(flag);
        return (pack == 0 ? "effect " : pack == 1 ? "charf " : "char ") + fxAno(flag);
    }

    /** Nome do grupo: 0 = EFFECT, 1 = CHARF, 2 = do personagem (ANOs 201..208 sao auras). */
    static String fxPackName(int pack, int ano) {
        if (pack == 0) return "Efeitos gerais (EFFECT)";
        if (pack == 1) return "CHARF";
        return ano <= 208 ? "Auras do personagem" : "Efeitos do personagem";
    }

    static String name(int flag) {
        int k = kindOf(flag);
        if (k == ACTION) return actionName(flag);
        if (k == EFFECT) return "Efeito";
        return KIND_NAMES[k];
    }

    static final class Obj {
        int kind, flag, occ;
        /** Flag 40 que e a metade "puxar" de um Teleportar atras (ver {@link ObjModel#isBehindHit}). */
        boolean behind;
        int f0, f1;
        int[] keys;     // frames onde as coordenadas mudam (inclui f0)
        List<Integer> tmp;

        boolean isKey(int frame) {
            for (int k : keys) if (k == frame) return true;
            return false;
        }
        /** Keyframe vigente no frame (o maior key <= frame). */
        int keyFor(int frame) {
            int r = f0;
            for (int k : keys) if (k <= frame) r = k;
            return r;
        }
        /** Ultimo frame do segmento que comeca em {@code frame}. */
        int segEnd(int frame) {
            for (int k : keys) if (k > frame) return k - 1;
            return f1;
        }
        boolean contains(int frame) { return frame >= f0 && frame <= f1; }
    }

    static Ano.Hit[] hitsOf(Ano.Mpt m) { return (m.flags & 0x10) != 0 ? m.hits : Ano.NO_HITS; }

    /** O hit e a metade "puxar" de um Teleportar atras (flag 40, x < 0, e o frame tem Flip X)? */
    static boolean isBehindHit(Ano.Mpt m, Ano.Hit h) {
        if (h == null || !spriteBit(m, FLIP_H)) return false;
        if (h.flag == 40) return h.x < 0;                                            // formato antigo (puxava o oponente)
        return h.flag == 39 && FrameTools.hasSpeedX(m) && m.speedX > 0;              // formato atual: vai ate o oponente + Flip X + speed X positiva
    }

    /** Teleportar atras no formato atual (flag 39)? Ele ocupa um frame so. */
    static boolean isBehindNew(Obj o) { return o != null && o.behind && o.flag == 39; }

    /** Distancia (px) que o Teleportar atras do frame leva o personagem para tras do oponente. */
    static int behindDistance(Ano.Mpt m) {
        return (int) Math.round(m.speedX / FrameTools.ONE * Math.max(1, FrameTools.ticks(m)));
    }

    /** Muda a distancia do Teleportar atras do frame {@code f} (a speed X por tick = distancia / ticks do frame). */
    static Ano.Mpt[] setBehindDistance(Ano.Mpt[] m, int f, int dist) {
        if (!FrameOps.ok(m, f)) return m;
        Ano.Mpt[] out = m.clone();
        out[f] = FrameTools.setSpeed(m[f], 0, Math.max(1, dist) / (double) Math.max(1, FrameTools.ticks(m[f])), true);
        return out;
    }

    static boolean hasBehind(Ano.Mpt m) {
        for (Ano.Hit h : hitsOf(m)) if (isBehindHit(m, h)) return true;
        return false;
    }

    /** Nome mostrado do objeto (o Teleportar atras tem nome proprio). */
    static String nameOf(Obj o) { return o.behind ? actionName(ACT_BEHIND) : name(o.flag); }

    /** Chave da linha na timeline: o Teleportar atras nao divide linha com o Puxar oponente comum. */
    static int laneFlag(Obj o) { return o.behind ? ACT_BEHIND : o.flag; }

    /** Indice do hit (flag, occ) em m.hits, ou -1. */
    static int indexOf(Ano.Mpt m, int flag, int occ) {
        Ano.Hit[] h = hitsOf(m);
        int n = 0;
        for (int i = 0; i < h.length; i++) if (h[i].flag == flag) { if (n == occ) return i; n++; }
        return -1;
    }

    static Ano.Hit find(Ano.Mpt m, int flag, int occ) {
        if (isVirtual(flag)) return occ == 0 && vHas(m, flag) ? (flag == VF_WINDOW ? WINDOW_HIT : vHit(flag)) : null;
        int i = indexOf(m, flag, occ);
        return i < 0 ? null : m.hits[i];
    }

    static int count(Ano.Mpt m, int flag) {
        if (isVirtual(flag)) return vHas(m, flag) ? 1 : 0;
        int n = 0;
        for (Ano.Hit h : hitsOf(m)) if (h.flag == flag) n++;
        return n;
    }

    private static boolean same(Ano.Hit a, Ano.Hit b) {
        return a.x == b.x && a.y == b.y && a.width == b.width && a.height == b.height;
    }

    static List<Obj> objects(Ano.Mpt[] m) {
        Map<Integer, Obj> open = new HashMap<Integer, Obj>();
        List<Obj> all = new ArrayList<Obj>();
        for (int f = 0; f < m.length; f++) {
            Map<Integer, Integer> seen = new HashMap<Integer, Integer>();
            Map<Integer, Ano.Hit> cur = new HashMap<Integer, Ano.Hit>();
            boolean fb = hasBehind(m[f]);
            for (Ano.Hit h : allHits(m[f])) {
                Integer c = seen.get(h.flag);
                int occ = c == null ? 0 : c;
                seen.put(h.flag, occ + 1);
                if (fb && h.flag == 40 && !isBehindHit(m[f], h)) continue;      // Puxar oponente nao aparece onde ha Teleportar atras (a numeracao do occ segue a do arquivo)
                cur.put(h.flag * 256 + occ, h);
            }
            List<Integer> close = new ArrayList<Integer>();
            for (Integer k : open.keySet()) if (!cur.containsKey(k)) close.add(k);
            for (Integer k : close) open.remove(k);
            for (Map.Entry<Integer, Ano.Hit> e : cur.entrySet()) {
                int key = e.getKey();
                Obj o = open.get(key);
                Ano.Hit h = e.getValue();
                if (o != null) {                       // Hitbox: sempre um objeto por Frame (o hit se repete a cada Frame); demais: valores diferentes (ou divisao explicita) separam
                    Ano.Hit prev = find(m[f - 1], o.flag, o.occ);
                    if (o.kind == HITBOX || isBehindNew(o) || prev == null || !same(prev, h) || h.cut || o.behind != isBehindHit(m[f], h)) { open.remove(key); o = null; }
                }
                if (o == null) {
                    o = new Obj();
                    o.flag = key / 256;
                    o.occ = key % 256;
                    o.kind = kindOf(o.flag);
                    o.behind = isBehindHit(m[f], h);
                    o.f0 = f;
                    o.f1 = f;
                    all.add(o);
                    o.tmp = new ArrayList<Integer>();
                    o.tmp.add(f);
                    open.put(key, o);
                } else {
                    o.f1 = f;
                }
            }
        }
        for (Obj o : all) {
            o.keys = new int[o.tmp.size()];
            for (int i = 0; i < o.keys.length; i++) o.keys[i] = o.tmp.get(i);
            o.tmp = null;
        }
        Collections.sort(all, new Comparator<Obj>() {
            @Override public int compare(Obj a, Obj b) {
                if (a.kind != b.kind) return a.kind - b.kind;
                if (a.f0 != b.f0) return a.f0 - b.f0;
                if (a.behind != b.behind) return a.behind ? 1 : -1;
                if (a.flag != b.flag) return a.flag - b.flag;
                return a.occ - b.occ;
            }
        });
        return all;
    }

    /** Objeto (flag, occ) que contem o frame, ou null. */
    static Obj find(List<Obj> objs, int flag, int occ, int frame) {
        for (Obj o : objs) if (o.flag == flag && o.occ == occ && o.contains(frame)) return o;
        return null;
    }

    // ---- edicao ----

    private static Ano.Hit copyHit(Ano.Hit o) {
        Ano.Hit h = new Ano.Hit();
        h.flag = o.flag; h.x = o.x; h.y = o.y; h.width = o.width; h.height = o.height; h.cut = o.cut;
        return h;
    }

    static Ano.Hit defaultHit(int flag) {
        Ano.Hit h = new Ano.Hit();
        h.flag = flag;
        int k = kindOf(flag);
        if (k == HITBOX || k == HURTBOX) { h.x = -16; h.y = -32; h.width = 32; h.height = 32; }
        return h;
    }

    /**
     * Copia x/y/largura/altura para TODAS as caixas de {@code flag} (hurtbox = 1) de todos os frames. Frames sem a caixa, ou com ela ja igual,
     * ficam como estao (mesma instancia); o resto e copiado, sem mexer em {@code cut}. Devolve o mesmo array se nada muda.
     */
    static Ano.Mpt[] setAllCoords(Ano.Mpt[] m, int flag, int x, int y, int w, int h) {
        Ano.Mpt[] out = null;
        for (int i = 0; i < m.length; i++) {
            boolean change = false;
            for (Ano.Hit t : hitsOf(m[i])) if (t.flag == flag && (t.x != x || t.y != y || t.width != w || t.height != h)) change = true;
            if (!change) continue;
            if (out == null) out = m.clone();
            Ano.Mpt c = m[i].copy();
            for (Ano.Hit t : c.hits) if (t.flag == flag) { t.x = x; t.y = y; t.width = w; t.height = h; }
            out[i] = c;
        }
        return out == null ? m : out;
    }

    /** Quantos frames {@link #setAllCoords} muda. */
    static int countChanged(Ano.Mpt[] before, Ano.Mpt[] after) {
        int n = 0;
        for (int i = 0; i < before.length && i < after.length; i++) if (before[i] != after[i]) n++;
        return n;
    }

    /** Aplica x/y/w/h do objeto do {@code frame} ate o proximo keyframe. null = sem mudanca. */
    static Ano.Mpt[] setCoords(Ano.Mpt[] m, Obj o, int frame, int x, int y, int w, int h) {
        if (!o.contains(frame) || !FrameOps.ok(m, frame) || o.f1 >= m.length) return null;
        Ano.Mpt[] out = m.clone();
        int end = o.segEnd(frame);
        for (int f = frame; f <= end; f++) {
            Ano.Mpt c = m[f].copy();
            Ano.Hit t = find(c, o.flag, o.occ);
            if (t == null) continue;
            t.x = x; t.y = y; t.width = w; t.height = h;
            out[f] = c;
        }
        return out;
    }

    /** Aplica x/y/w/h do objeto aos frames [from, to]. null = sem mudanca. */
    static Ano.Mpt[] setCoordsRange(Ano.Mpt[] m, Obj o, int from, int to, int x, int y, int w, int h) {
        if (!o.contains(from) || !FrameOps.ok(m, from) || o.f1 >= m.length) return null;
        Ano.Mpt[] out = m.clone();
        for (int f = from; f <= Math.min(to, o.f1); f++) {
            Ano.Mpt c = m[f].copy();
            Ano.Hit t = find(c, o.flag, o.occ);
            if (t == null) continue;
            t.x = x; t.y = y; t.width = w; t.height = h;
            out[f] = c;
        }
        return out;
    }

    /** Remove o keyframe: o segmento passa a herdar as coordenadas do anterior. */
    static Ano.Mpt[] removeKey(Ano.Mpt[] m, Obj o, int frame) {
        if (frame <= o.f0 || !o.isKey(frame)) return null;
        Ano.Hit prev = find(m[frame - 1], o.flag, o.occ);
        return setCoords(m, o, frame, prev.x, prev.y, prev.width, prev.height);
    }

    private static Ano.Mpt removeHit(Ano.Mpt m, int flag, int occ) {
        if (isVirtual(flag)) return vSet(m, flag, false);
        int i = indexOf(m, flag, occ);
        if (i < 0) return m;
        Ano.Mpt c = m.copy();
        Ano.Hit[] h = new Ano.Hit[c.hits.length - 1];
        for (int k = 0, p = 0; k < c.hits.length; k++) if (k != i) h[p++] = c.hits[k];
        c.hits = h;
        if (h.length == 0) c.flags &= ~0x10;
        c.normalize();
        return c;
    }

    private static Ano.Mpt addHit(Ano.Mpt m, Ano.Hit h) {
        if (isVirtual(h.flag)) return vSet(m, h.flag, true);
        Ano.Mpt c = m.copy();
        Ano.Hit[] n = new Ano.Hit[(((m.flags & 0x10) != 0) ? c.hits.length : 0) + 1];
        int base = n.length - 1;
        if ((m.flags & 0x10) != 0) System.arraycopy(c.hits, 0, n, 0, base);
        n[base] = copyHit(h);
        c.hits = n;
        c.flags |= 0x10;
        c.normalize();
        return c;
    }

    /** O objeto aponta para frames que existem (um objeto de uma lista antiga pode sobrar depois de uma edicao)? */
    static boolean sane(Ano.Mpt[] m, Obj o) { return m != null && o != null && o.f0 >= 0 && o.f1 >= o.f0 && o.f1 < m.length; }

    /**
     * Divisa de frames onde DIVIDIR corta o objeto: o objeto pertence aos frames, entao nunca corta no meio de um frame.
     * Devolve o frame (de o.f0+1 a o.f1) cujo inicio esta mais perto do tick; empate fica com a divisa anterior.
     * -1 se o objeto tem um frame so (nao ha divisa dentro dele).
     */
    static int splitBoundary(int[] starts, Obj o, int tick) {
        if (starts == null || o == null || o.f1 <= o.f0 || o.f0 < 0 || o.f1 >= starts.length) return -1;
        int best = -1, bd = Integer.MAX_VALUE;
        for (int f = o.f0 + 1; f <= o.f1; f++) {
            int d = Math.abs(starts[f] - tick);
            if (d < bd) { bd = d; best = f; }
        }
        return best;
    }

    static Ano.Mpt[] remove(Ano.Mpt[] m, Obj o) {
        if (!sane(m, o)) return m;
        Ano.Mpt[] out = m.clone();
        for (int f = o.f0; f <= o.f1; f++) {
            out[f] = removeHit(m[f], o.flag, o.occ);
            if (o.behind) out[f] = setSpriteBit(out[f], FLIP_H, false);          // o Flip X pertence ao Teleportar atras: sai junto
            if (isBehindNew(o)) out[f] = FrameTools.setSpeed(out[f], 0, 0, false);      // e a speed X que o leva para tras
        }
        return out;
    }

    /** Teleportar atras no frame {@code frame} (um frame so; {@code last} e ignorado): hit flag 39 + Flip X + speed X de {@link #BEHIND_DIST} px (atravessa o oponente). */
    static Ano.Mpt[] addBehind(Ano.Mpt[] m, int frame, int last) { return addBehindDist(m, frame, BEHIND_DIST); }

    /** O mesmo com a distancia dada (px). Frame sem TIME ganha 1 tick (a speed so anda enquanto ha tempo). */
    static Ano.Mpt[] addBehindDist(Ano.Mpt[] m, int frame, int dist) {
        if (!FrameOps.ok(m, frame)) return m;
        Ano.Mpt c = m[frame].copy();
        if (FrameTools.ticks(c) <= 0) { c.hasTime = true; c.time = 1; c.flags |= 0x20; }
        c = setSpriteBit(addHit(c, defaultHit(39)), FLIP_H, true);
        c = FrameTools.setSpeed(c, 0, Math.max(1, dist) / (double) Math.max(1, FrameTools.ticks(c)), true);
        Ano.Mpt[] out = m.clone();
        out[frame] = c;
        return out;
    }

    /**
     * Muda o objeto para ocupar [nf0, nf1]; frames novos copiam o hit da borda. Hitbox: o dano e a reacao (OPT 0 e 1) tambem sao
     * copiados da borda para os frames novos (se o destino nao tem outra hitbox) e zerados nos frames que saem (se ficaram sem hitbox).
     */
    static Ano.Mpt[] trim(Ano.Mpt[] m, Obj o, int nf0, int nf1) {
        if (!sane(m, o)) return m;
        if (isBehindNew(o)) return m;                      // Teleportar atras e de um frame so (teleporte + deslocamento)
        nf0 = Math.max(0, Math.min(m.length - 1, nf0));
        nf1 = Math.max(nf0, Math.min(m.length - 1, nf1));
        boolean hitbox = o.kind == HITBOX;
        Ano.Mpt[] out = m.clone();
        int lo = Math.min(o.f0, nf0), hi = Math.max(o.f1, nf1);
        for (int f = lo; f <= hi; f++) {
            boolean was = o.contains(f), will = f >= nf0 && f <= nf1;
            if (was == will) continue;
            if (will) {
                Ano.Mpt ref = m[f < o.f0 ? o.f0 : o.f1];
                Ano.Hit proto = find(ref, o.flag, o.occ);
                boolean free = hitbox && !hasHitbox(m[f]);
                out[f] = addHit(m[f], proto);
                if (o.behind) out[f] = setSpriteBit(out[f], FLIP_H, true);
                if (free) out[f] = setOptField(setOptField(out[f], 0, optField(ref, 0)), 1, optField(ref, 1));
            } else {
                out[f] = removeHit(m[f], o.flag, o.occ);
                if (o.behind) out[f] = setSpriteBit(out[f], FLIP_H, false);
                if (hitbox && !hasHitbox(out[f])) out[f] = clearDamage(out[f]);
            }
        }
        return out;
    }

    /**
     * Move o objeto inteiro para comecar em {@code nf0}, mantendo a duracao e os valores de cada frame (limitado ao fim da ANO).
     * Hitbox: o dano e a reacao (OPT, campos 0 e 1) de cada frame acompanham a box.
     * Nao recusa colisao: se ja ha uma caixa com a mesma flag nos frames de destino, a movida vira a ocorrencia seguinte (outra faixa).
     */
    static Ano.Mpt[] move(Ano.Mpt[] m, Obj o, int nf0) {
        if (!sane(m, o)) return m;
        if (isBehindNew(o)) {                              // leva a distancia junto (a speed por tick depende dos ticks do frame de destino)
            int tgt = Math.max(0, Math.min(m.length - 1, nf0));
            if (tgt == o.f0) return m;
            int dist = behindDistance(m[o.f0]);
            return addBehindDist(remove(m, o), tgt, dist);
        }
        int n = o.f1 - o.f0 + 1;
        nf0 = Math.max(0, Math.min(m.length - n, nf0));
        if (nf0 == o.f0) return m;
        boolean hitbox = o.kind == HITBOX;
        Ano.Hit[] hits = new Ano.Hit[n];
        int[] dmg = new int[n], rea = new int[n];
        for (int k = 0; k < n; k++) {
            Ano.Hit h = find(m[o.f0 + k], o.flag, o.occ);
            hits[k] = h == null ? defaultHit(o.flag) : copyHit(h);
            dmg[k] = optField(m[o.f0 + k], 0);
            rea[k] = optField(m[o.f0 + k], 1);
        }
        Ano.Mpt[] out = m.clone();
        for (int f = o.f0; f <= o.f1; f++) {
            out[f] = removeHit(out[f], o.flag, o.occ);
            if (o.behind) out[f] = setSpriteBit(out[f], FLIP_H, false);
            if (hitbox && !hasHitbox(out[f])) out[f] = clearDamage(out[f]);       // dano e reacao saem junto com a hitbox
        }
        for (int k = 0; k < n; k++) {
            int f = nf0 + k;
            boolean free = hitbox && !hasHitbox(out[f]);       // destino sem outra hitbox: recebe o dano/reacao; com colisao mantem o dele
            out[f] = addHit(out[f], hits[k]);
            if (o.behind) out[f] = setSpriteBit(out[f], FLIP_H, true);
            if (free) out[f] = setOptField(setOptField(out[f], 0, dmg[k]), 1, rea[k]);
        }
        return out;
    }

    private static boolean hasHitbox(Ano.Mpt m) {
        for (Ano.Hit h : allHits(m)) if (kindOf(h.flag) == HITBOX) return true;
        return false;
    }

    /** Zera dano e reacao do frame; se o OPT fica vazio (sem flags nem dados), tira o bloco. */
    private static Ano.Mpt clearDamage(Ano.Mpt m) {
        if ((m.flags & 0x40) == 0) return m;
        Ano.Mpt c = m.copy();
        c.optData[0] = 0;
        c.optData[1] = 0;
        if (c.optFlag == 0 && c.optData[2] == 0 && c.optData[3] == 0) c.flags &= ~0x40;
        c.normalize();
        return c;
    }

    /** Depois de {@link #move}: a ocorrencia mais alta da flag que comeca em {@code f0} (a movida, ate numa colisao); null se nao ha. */
    static Obj locate(Ano.Mpt[] m, int flag, int f0) {
        Obj best = null;
        for (Obj o : objects(m)) if (o.flag == flag && o.f0 == f0 && (best == null || o.occ > best.occ)) best = o;
        return best;
    }

    /** Liga/desliga a flag (hit sem coordenadas, ex.: 38) em todos os frames [f0, f1]. */
    static Ano.Mpt[] setFlagRange(Ano.Mpt[] m, int f0, int f1, int flag, boolean on) {
        Ano.Mpt[] out = m.clone();
        for (int f = Math.max(0, f0); f <= Math.min(f1, m.length - 1); f++) {
            Ano.Mpt c = m[f];
            if (on) {
                if (count(c, flag) == 0) c = addHit(c, defaultHit(flag));
            } else {
                while (count(c, flag) > 0) c = removeHit(c, flag, 0);
            }
            out[f] = c;
        }
        return out;
    }

    /** true se TODOS os frames [f0, f1] tem a flag. */
    static boolean hasFlagRange(Ano.Mpt[] m, int f0, int f1, int flag) {
        for (int f = Math.max(0, f0); f <= Math.min(f1, m.length - 1); f++) if (count(m[f], flag) == 0) return false;
        return true;
    }

    /** Novo objeto no frame (e opcionalmente ate {@code last}). */
    static Ano.Mpt[] add(Ano.Mpt[] m, int frame, int last, Ano.Hit proto) {
        if (!FrameOps.ok(m, frame) || proto == null) return m;
        Ano.Mpt[] out = m.clone();
        for (int f = frame; f <= Math.min(last, m.length - 1); f++) out[f] = addHit(m[f], proto);
        return out;
    }

    /** Troca a flag (tipo/efeito) do objeto em toda a sua duracao. */
    static Ano.Mpt[] setFlag(Ano.Mpt[] m, Obj o, int newFlag) {
        if (!sane(m, o)) return m;
        Ano.Mpt[] out = m.clone();
        if (isVirtual(o.flag) || isVirtual(newFlag)) {
            for (int f = o.f0; f <= o.f1; f++) out[f] = addHit(removeHit(m[f], o.flag, o.occ), defaultHit(newFlag));
            return out;
        }
        for (int f = o.f0; f <= o.f1; f++) {
            Ano.Mpt c = m[f].copy();
            Ano.Hit t = find(c, o.flag, o.occ);
            if (t != null) t.flag = newFlag;
            if (o.behind) c = setSpriteBit(c, FLIP_H, false);
            if (isBehindNew(o)) c = FrameTools.setSpeed(c, 0, 0, false);
            out[f] = c;
        }
        return out;
    }

    // ---- campos de sprite ----

    /** Frame (base 1) para onde a interpolacao do frame {@code idx} (base 0) vai: o seguinte; no ultimo o jogo da a volta para o frame 1. */
    static int interpTarget(int length, int idx) { return idx + 1 >= length ? 1 : idx + 2; }

    static final int FLIP_H = 16, FLIP_V = 32, KEEP_SPEED = 64, LOOP = 1;

    static boolean loops(Ano.Mpt[] m) {
        for (Ano.Mpt x : m) if ((x.flags & 2) != 0 && (x.wActFlag & LOOP) != 0) return true;
        return false;
    }

    /** Liga/desliga o loop da ANO (marcado no ultimo frame; wActFlag 2 e preservado). */
    static Ano.Mpt[] setLoop(Ano.Mpt[] m, boolean on) {
        Ano.Mpt[] out = m.clone();
        for (int i = 0; i < m.length; i++) {
            if ((m[i].flags & 2) != 0 && (m[i].wActFlag & LOOP) != 0) {
                Ano.Mpt c = m[i].copy();
                c.wActFlag &= ~LOOP;
                if (c.wActFlag == 0) c.flags &= ~2;
                c.normalize();
                out[i] = c;
            }
        }
        if (on) {
            int last = m.length - 1;
            Ano.Mpt c = out[last].copy();
            c.flags |= 2;
            c.wActFlag |= LOOP;
            c.normalize();
            out[last] = c;
        }
        return out;
    }

    /** Liga/desliga um bit de wActFlag (16/32/64) do sprite. */
    static Ano.Mpt setSpriteBit(Ano.Mpt m, int bit, boolean on) {
        Ano.Mpt c = m.copy();
        if (on) { c.flags |= 2; c.wActFlag |= bit; }
        else { c.wActFlag &= ~bit; if (c.wActFlag == 0) c.flags &= ~2; }
        c.normalize();
        return c;
    }

    static boolean spriteBit(Ano.Mpt m, int bit) { return (m.flags & 2) != 0 && (m.wActFlag & bit) != 0; }

    /** Dano do sprite (OptData[0]) e tipo de reacao (OptData[1]). */
    static Ano.Mpt setOptField(Ano.Mpt m, int field, int value) {
        Ano.Mpt c = m.copy();
        c.flags |= 0x40;
        c.optData[field] = value & 255;
        c.normalize();
        return c;
    }

    static int optField(Ano.Mpt m, int field) { return (m.flags & 0x40) != 0 ? m.optData[field] : 0; }

    /** Bit da wOptFlag do frame (ex.: 512 = janela de repeticao/agarrao). */
    static boolean optFlagBit(Ano.Mpt m, int bit) { return (m.flags & 0x40) != 0 && (m.optFlag & bit) != 0; }

    static Ano.Mpt setOptFlagBit(Ano.Mpt m, int bit, boolean on) {
        Ano.Mpt c = m.copy();
        if (on) { c.flags |= 0x40; c.optFlag |= bit; } else { c.optFlag &= ~bit; }
        c.normalize();
        return c;
    }

    /** Texto curto de duracao: ticks e segundos. */
    /** Tempo no formato 0.Ns/N ticks (60 ticks = 1 s). */
    static String timeText(int ticks) {
        String x = String.format(java.util.Locale.US, "%.2f", ticks / 60.0);
        while (x.endsWith("0")) x = x.substring(0, x.length() - 1);
        if (x.endsWith(".")) x = x.substring(0, x.length() - 1);
        return x + "s/" + ticks + (ticks == 1 ? " tick" : " ticks");
    }

    static String seconds(int ticks) {
        double s = ticks / 60.0;
        String t = String.format(java.util.Locale.US, "%.2f", s);
        return t + "s";
    }
}
