package com.zue.attackeditor;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Build;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Grava um som global (se_NN.ogg) a partir de PCM: Opus dentro de um contentor Ogg, feito so com a API do Android
 * (MediaCodec "audio/opus" + MediaMuxer MUXER_OUTPUT_OGG, Android 10 / API 29 ou mais novo). O arquivo se chama .ogg mas o codec e Opus,
 * nao Vorbis: o SoundPool do Android le; o jogo precisa abrir o arquivo com o mesmo decodificador.
 */
final class OggEncode {
    private OggEncode() { }

    static final String MIME = "audio/opus";

    /** O aparelho tem codificador Opus e muxer OGG? */
    static boolean supported() {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            for (MediaCodecInfo i : new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos()) {
                if (!i.isEncoder()) continue;
                for (String t : i.getSupportedTypes()) if (MIME.equalsIgnoreCase(t)) return true;
            }
        } catch (Throwable t) { /* sem lista de codecs */ }
        return false;
    }

    /** Motivo de nao dar para gravar OGG neste aparelho. */
    static String why() {
        return Build.VERSION.SDK_INT < 29 ? "Precisa do Android 10 ou mais novo (o aparelho tem a API " + Build.VERSION.SDK_INT + ")."
                : "Este aparelho nao tem codificador Opus.";
    }

    /** WAV do jogo (22050 Hz, mono, 16 bits) -> {@code out}. */
    static void encodeWav(byte[] wav, File out) throws IOException {
        encode(OggPcm.to48k(AudioConvert.pcmOf(wav), AudioConvert.RATE), out);
    }

    /** Silencio curto (placeholder de preenchimento ou som "excluido"). */
    static void silence(File out) throws IOException { encode(OggPcm.silence(100), out); }

    /** PCM mono 16 bits a 48 kHz -> arquivo .ogg (Opus). Grava num temporario e troca no fim (o arquivo antigo so some se deu certo). */
    static void encode(short[] pcm48k, File out) throws IOException {
        if (!supported()) throw new IOException(why());
        short[] pcm = OggPcm.padTo20ms(pcm48k);
        File tmp = new File(out.getPath() + ".tmp");
        tmp.delete();
        MediaCodec codec = null;
        MediaMuxer muxer = null;
        boolean started = false;
        try {
            MediaFormat fmt = MediaFormat.createAudioFormat(MIME, OggPcm.RATE, 1);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 48000);
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 960 * 2 * 8);
            codec = MediaCodec.createEncoderByType(MIME);
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();
            muxer = new MediaMuxer(tmp.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG);
            int track = -1;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            ByteBuffer pcmBytes = ByteBuffer.allocate(pcm.length * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            for (short s : pcm) pcmBytes.putShort(s);
            pcmBytes.flip();
            boolean inDone = false, outDone = false;
            long sent = 0;
            int guard = 0;
            while (!outDone) {
                if (++guard > 200000) throw new IOException("o codificador nao terminou");
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        ib.clear();
                        int n = Math.min(ib.remaining(), pcmBytes.remaining());
                        long ptsUs = sent * 1000000L / (OggPcm.RATE * 2L);
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            byte[] chunk = new byte[n];
                            pcmBytes.get(chunk);
                            ib.put(chunk);
                            codec.queueInputBuffer(ii, 0, n, ptsUs, 0);
                            sent += n;
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.getOutputFormat());     // traz csd-0/1/2 (OpusHead, pre-skip, seek preroll)
                    muxer.start();
                    started = true;
                } else if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size > 0 && started) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        muxer.writeSampleData(track, ob, info);
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                }
            }
            if (!started) throw new IOException("o codificador nao produziu audio");
            muxer.stop();
            started = false;
        } catch (IOException e) {
            tmp.delete();
            throw e;
        } catch (Throwable t) {
            tmp.delete();
            throw new IOException("falha ao gravar OGG: " + (t.getMessage() == null ? t.toString() : t.getMessage()));
        } finally {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Throwable ignored) { }
            try { if (muxer != null) muxer.release(); } catch (Throwable ignored) { }
        }
        if (out.exists() && !out.delete()) { tmp.delete(); throw new IOException("nao consegui trocar " + out.getName()); }
        if (!tmp.renameTo(out)) { tmp.delete(); throw new IOException("nao consegui gravar " + out.getName()); }
    }
}
