package com.zue.attackeditor;

/** PCM para o codificador OGG (Opus so aceita 8/12/16/24/48 kHz): reamostragem linear e silencio. Java puro. */
final class OggPcm {
    private OggPcm() { }

    static final int RATE = 48000;

    /** Reamostra (mono, 16 bits) de {@code rate} para 48 kHz por interpolacao linear. */
    static short[] to48k(short[] in, int rate) {
        if (in == null || in.length == 0 || rate <= 0) return new short[0];
        if (rate == RATE) return in.clone();
        int n = (int) Math.max(1, Math.round(in.length * (double) RATE / rate));
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            double pos = i * (double) rate / RATE;
            int a = (int) pos;
            int b = Math.min(in.length - 1, a + 1);
            a = Math.min(in.length - 1, a);
            double f = pos - (int) pos;
            out[i] = (short) Math.round(in[a] * (1 - f) + in[b] * f);
        }
        return out;
    }

    /** Silencio de {@code ms} milissegundos a 48 kHz (no minimo 1 quadro de 20 ms). */
    static short[] silence(int ms) { return new short[Math.max(960, ms * RATE / 1000)]; }

    /** Arredonda para cima ate um multiplo de 20 ms (960 amostras): o Opus trabalha em quadros de 20 ms. */
    static short[] padTo20ms(short[] in) {
        int n = (in.length + 959) / 960 * 960;
        return n == in.length ? in : java.util.Arrays.copyOf(in, Math.max(960, n));
    }
}
