package com.zue.attackeditor;

/**
 * Decodifica o OPT 1 de um frame com hitbox (o mesmo valor que o jogo passa para DamageChange):
 * grupo = valor / 50 (efeito, som, hitstop, empurrao), indice = valor % 50 (qual reacao do defensor).
 * Indice 0-29 vem do gamedata (HDAT 10+i); 30-49 vem do char do atacante (HDAT 14+(i-30)).
 */
public final class Opt1 {
    /** HitEffectActNo do jogo: Ano do effect.pac; -1 = sem efeito (e sem som). */
    private static final int[] EFFECT_ANO = {0, 0, 1, 0, -1};
    /** HitSound do jogo: numero do se_NN. */
    private static final int[] HIT_SOUND = {3, 4, 6, 3, 7};

    public final int value;
    public final boolean valid;
    public final int group;
    public final int index;
    /** true = tabela do char do atacante. */
    public final boolean fromChar;
    /** Tipo dentro da tabela escolhida (0..29 no gamedata, 0..19 no char). */
    public final int type;
    public final int effectAno;
    /** -1 quando o jogo nao toca som de hit. */
    public final int sound;
    /** true so nos grupos 0-2: aplicam DamageMove (recuo). */
    public final boolean pushes;
    /** 0 = hitstop normal, 1 = metade (grupo 3), 2 = nenhum (grupo 4). */
    public final int hitstopMode;

    public Opt1(int value) {
        this.value = value;
        this.group = value / 50;
        this.index = value % 50;
        this.valid = value >= 0 && group < EFFECT_ANO.length;
        this.fromChar = index >= 30;
        this.type = fromChar ? index - 30 : index;
        this.effectAno = valid ? EFFECT_ANO[group] : -1;
        this.sound = (valid && effectAno != -1) ? HIT_SOUND[group] : -1;
        this.pushes = valid && group < 3;
        this.hitstopMode = !valid ? 2 : (group == 4 ? 2 : (group == 3 ? 1 : 0));
    }

    /** Hitstop em ticks, dado o PlayerHitStop do atacante (10 no jogo). */
    public int hitstopTicks(int base, boolean melee) {
        if (hitstopMode == 2) return 0;
        return (melee && hitstopMode == 1) ? base / 2 : base;
    }

    public String describe() {
        if (!valid) return "OPT1 " + value + ": fora da faixa (0-249)";
        return String.format(java.util.Locale.US,
                "OPT1 %d: reacao %s %d, efeito %s, som %s, hitstop %s",
                value, fromChar ? "char" : "gamedata", type,
                effectAno < 0 ? "nenhum" : "Ano " + effectAno,
                sound < 0 ? "nenhum" : "se_" + (sound < 10 ? "0" : "") + sound,
                hitstopMode == 2 ? "nenhum" : (hitstopMode == 1 ? "metade" : "normal"));
    }
}
