package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sprites de outro pac: ao tocar num .cnv no seletor de imagens, le a tabela e recorta as folhas PNG da mesma pasta (sem tocar nos arquivos
 * de origem) e deixa adicionar todas ou so as marcadas ao personagem. Escala 1 (efeito/charf/bobj) entra ampliada para manter o tamanho na tela.
 */
final class PacSpritePicker {
    private PacSpritePicker() { }

    /** Largura e altura de cada folha (PNG de indice $src) usada pelo CNV (so o cabecalho do PNG; {0,0} se nao existe). */
    private static int[][] sheetSizes(File dir, Cnv c) {
        int max = 0;
        for (int i = 0; i < c.size(); i++) { Cnv.Entry e = c.byImage(i); if (e != null && e.source > max) max = e.source; }
        int[][] out = new int[max + 1][2];
        for (int s = 0; s <= max; s++) {
            File f = SheetFiles.file(dir, s);       // $src = indice da folha na lista dos PNG
            if (f == null) continue;
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(f.getPath(), o);
            out[s][0] = Math.max(0, o.outWidth);
            out[s][1] = Math.max(0, o.outHeight);
        }
        return out;
    }

    private static final int BG = 0xFF14171C, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, OK = 0xFF7CE08A, HI = 0xFF21402C;

    /** {@code uiOnly}: atualiza a tela depois de gravar (o commit das folhas ja foi feito aqui). */
    static void show(final Activity a, File picked, final SpriteLib target, final Runnable uiOnly) { show(a, picked, target, uiOnly, 0, null, -1); }

    /**
     * {@code scaleMode}: 0 = pela pasta (charNN = escala 2), 1 ou 2 = o usuario escolheu a escala do pac.
     * {@code reopen}: o que fazer ao voltar (reabre o seletor de arquivos na pasta do CNV); null = so fecha.
     * {@code replaceIdx}: >= 0 = escolher UMA sprite do CNV para substituir a SPR_replaceIdx do personagem (em vez de adicionar varias).
     */
    static void show(final Activity a, final File picked, final SpriteLib target, final Runnable uiOnly, final int scaleMode, final Runnable reopen, final int replaceIdx) {
        final File cnvF = SpriteImportPlan.cnvOf(picked);
        final File dir = cnvF.getParentFile();
        if (SpriteImportPlan.sameFolder(dir, target.dir)) {
            SpriteListScreen.toast(a, "Esse CNV e do proprio personagem: escolha o CNV de outra pasta.");
            if (reopen != null) reopen.run();
            return;
        }
        final SpriteLib src;
        final List<SpriteImportPlan.Item> items;
        final boolean guessed;
        try {
            boolean ch = scaleMode == 0 ? SpriteImportPlan.isCharacterPac(dir) : scaleMode == 2;
            Cnv c = CharAssets.readCnv(cnvF, ch);
            boolean g = false;
            if (scaleMode == 0 && !ch && !CharAssets.KIND_TXT.equals(CharAssets.lastCnvKind) && SpriteImportPlan.guessScale(c, sheetSizes(dir, c)) == 2) {
                c = CharAssets.readCnv(cnvF, true);       // a pasta nao diz, mas os recortes so cabem nas folhas dobrados: e um pac de escala 2
                g = true;
            }
            guessed = g;
            src = new SpriteLib(dir, cnvF, c, c.scale());
            items = SpriteImportPlan.items(c);
        } catch (Throwable t) {
            SpriteListScreen.toast(a, "Nao abriu o CNV: " + t.getMessage());
            if (reopen != null) reopen.run();
            return;
        }
        if (items.isEmpty()) { src.release(); SpriteListScreen.toast(a, "Esse CNV nao tem sprites com desenho."); if (reopen != null) reopen.run(); return; }
        final int factor = SpriteImportPlan.factor(src.scale, target.scale);

        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Sprites de " + dir.getName() + "/" + cnvF.getName(), 16, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        int distinct = items.size();
        TextView hint = SpriteListScreen.text(a, distinct + " sprite(s) distintas  ·  escala " + src.scale + (factor > 1
                ? " → " + target.scale + ": entram ampliadas " + factor + "x para manter o tamanho na tela"
                : "  ·  entram sem mudar o tamanho")
                + (replaceIdx >= 0 ? ". Escolha a sprite que vai substituir SPR_" + replaceIdx + "." : ". Toque nas que quer adicionar."), 11, DIM, false);
        hint.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 8));
        root.addView(hint);
        final String kind = CharAssets.lastCnvKind;
        Cnv.Entry e0 = src.cnv.byImage(items.get(0).index);
        TextView diag = SpriteListScreen.text(a, "Lido de " + (CharAssets.KIND_TXT.equals(kind) ? cnvF.getName() + ".txt" : cnvF.getName()) + " ("
                + (CharAssets.KIND_TXT.equals(kind) ? "coordenadas finais, divididas por 2 no personagem"
                : CharAssets.KIND_TEXT.equals(kind) ? "texto, coordenadas originais" : "binario") + ")  ·  SPR_" + items.get(0).index + ": "
                + e0.x + "," + e0.y + " " + e0.width + "x" + e0.height + " \u2192 " + "recorte" + " " + (e0.x * src.scale) + "," + (e0.y * src.scale) + " "
                + (e0.width * src.scale) + "x" + (e0.height * src.scale)
                + (guessed ? "  ·  " + "escala 2 deduzida do tamanho das folhas" : ""), 10, DIM, false);
        diag.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        root.addView(diag);
        // recorte que nao funciona: motivo exato por sprite (linha vermelha), faixa com a contagem e alerta copiavel
        final String[] why = new String[items.size()];
        final java.util.ArrayList<String> problems = new java.util.ArrayList<String>();
        for (int k = 0; k < why.length; k++) {
            why[k] = src.cutProblem(items.get(k).index);
            if (why[k] != null) problems.add("SPR_" + items.get(k).index + ": " + why[k]);
        }
        final java.util.ArrayList<String> report = new java.util.ArrayList<String>();
        report.add(cnvF.getPath() + "  (" + (CharAssets.KIND_TXT.equals(kind) ? "cnv.txt" : CharAssets.KIND_TEXT.equals(kind) ? "cnv texto" : "cnv binario") + ", escala " + src.scale + ")");
        StringBuilder sheetNames = new StringBuilder();
        for (File sf : SheetFiles.list(dir)) sheetNames.append(sheetNames.length() > 0 ? " " : "").append(sf.getName());
        report.add("folhas PNG da pasta (indice = posicao): " + (sheetNames.length() == 0 ? "nenhuma" : sheetNames));
        report.addAll(problems);
        if (!problems.isEmpty()) {
            TextView bad = SpriteListScreen.text(a, problems.size() + " sprite(s) com problema de recorte \u2014 toque para ver", 11, 0xFFFF6B6B, true);
            bad.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
            bad.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ErrorListDialog.show(a, "Erro de recorte", report); } });
            root.addView(bad);
        }

        final boolean[] on = new boolean[items.size()];
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final TextView ok = SpriteListScreen.button(a, replaceIdx >= 0 ? "SUBSTITUIR" : "ADICIONAR 0", null);
        final Runnable upd = new Runnable() {
            @Override public void run() {
                int n = 0;
                for (boolean b : on) if (b) n++;
                if (replaceIdx < 0) ok.setText("ADICIONAR " + n);
            }
        };
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return items.size(); }
            @Override public Object getItem(int i) { return items.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                SpriteImportPlan.Item it = items.get(i);
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 6));
                if (on[i]) row.setBackgroundColor(HI);
                ImageView iv = new ImageView(a);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setBackgroundColor(0xFF0D0F13);
                Bitmap tb = thumb(src, thumbs, it.index);
                if (tb != null) iv.setImageBitmap(tb);
                row.addView(iv, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 60), SpriteListScreen.dp(a, 60)));
                TextView t = new I18nTextView(a).noTranslate();       // nome/numero de sprite: dado
                t.setTextSize(13);
                t.setPadding(SpriteListScreen.dp(a, 12), 0, 0, 0);
                t.setText((on[i] ? "✓  " : "") + SpriteImportPlan.describe(it) + (why[i] != null ? "\n\u26A0 " + why[i] : ""));
                t.setTextColor(why[i] != null ? 0xFFFF6B6B : on[i] ? OK : TEXT);
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                boolean now = !on[pos];
                if (replaceIdx >= 0) java.util.Arrays.fill(on, false);       // substituir: uma so
                on[pos] = now;
                ad.notifyDataSetChanged();
                upd.run();
            }
        });
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(SpriteListScreen.dp(a, 12), 0, SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8));
        if (replaceIdx < 0) bar.addView(SpriteListScreen.button(a, "TODAS", new View.OnClickListener() { @Override public void onClick(View v) { java.util.Arrays.fill(on, true); ad.notifyDataSetChanged(); upd.run(); } }));
        final int nextMode = scaleMode == 0 ? 1 : scaleMode == 1 ? 2 : 0;
        bar.addView(SpriteListScreen.button(a, scaleMode == 0 ? "ESCALA: AUTO (" + src.scale + ")" : "ESCALA: " + scaleMode, new View.OnClickListener() {
            @Override public void onClick(View v) { src.release(); d.dismiss(); show(a, picked, target, uiOnly, nextMode, reopen, replaceIdx); }
        }), SpriteListScreen.lpm(a, 8));
        if (replaceIdx < 0) bar.addView(SpriteListScreen.button(a, "NENHUMA", new View.OnClickListener() { @Override public void onClick(View v) { java.util.Arrays.fill(on, false); ad.notifyDataSetChanged(); upd.run(); } }), SpriteListScreen.lpm(a, 8));
        root.addView(bar);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 12));
        foot.addView(SpriteListScreen.button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.cancel(); } }));       // cancel = mesmo caminho do voltar do celular
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final java.util.ArrayList<Integer> chosen = new java.util.ArrayList<Integer>();
                for (int i = 0; i < on.length; i++) if (on[i]) chosen.add(Integer.valueOf(items.get(i).index));
                if (chosen.isEmpty()) { SpriteListScreen.toast(a, "marque pelo menos uma sprite"); return; }
                d.dismiss();
                if (replaceIdx >= 0) replaceWith(a, src, target, chosen.get(0).intValue(), replaceIdx, factor, uiOnly);
                else addAll(a, src, target, chosen, factor, uiOnly);
            }
        });
        foot.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        d.setOnCancelListener(new DialogInterface.OnCancelListener() {       // VOLTAR / voltar do celular: volta ao seletor de arquivos, na pasta do CNV
            @Override public void onCancel(DialogInterface x) { src.release(); if (reopen != null) reopen.run(); }
        });
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
            }
        });
        d.show();
    }

    private static Bitmap thumb(SpriteLib lib, Map<Integer, Bitmap> thumbs, int i) {
        Bitmap tb = thumbs.get(Integer.valueOf(i));
        if (tb == null && lib.has(i)) {
            Bitmap full = lib.cut(i);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(i), tb);
            }
        }
        return tb;
    }

    /** Substitui a SPR_{@code dstIdx} do personagem pela sprite {@code srcIdx} do CNV de outro pac (ampliada se a escala for menor). */
    private static void replaceWith(final Activity a, final SpriteLib src, final SpriteLib target, final int srcIdx, final int dstIdx, final int factor, final Runnable uiOnly) {
        final BusyDialog busy = BusyDialog.show(a, "Substituindo sprite");
        busy.set("SPR_" + srcIdx, 0, 0);
        new Thread(new Runnable() {
            @Override public void run() {
                String err = null;
                Bitmap b = null;
                try {
                    b = src.cut(srcIdx);
                    if (b == null) { String why = src.cutProblem(srcIdx); err = why != null ? why : "o recorte nao gerou imagem"; }
                    else {
                        if (factor > 1) {
                            Bitmap big = Bitmap.createScaledBitmap(b, b.getWidth() * factor, b.getHeight() * factor, false);
                            b.recycle();
                            b = big;
                        }
                        target.replace(dstIdx, b);
                        busy.set("Gravando as folhas de sprites...", 0, 0);
                        target.commit();
                    }
                } catch (Throwable t) {
                    err = t.getMessage() == null ? t.toString() : t.getMessage();
                } finally {
                    if (b != null && !b.isRecycled()) b.recycle();
                    src.release();
                }
                busy.dismiss();
                final String fe = err;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        uiOnly.run();
                        if (fe != null) {
                            java.util.ArrayList<String> l = new java.util.ArrayList<String>();
                            l.add("SPR_" + srcIdx + " -> SPR_" + dstIdx + ": " + fe);
                            ErrorListDialog.show(a, "Erro ao substituir a sprite", l);
                        } else SpriteListScreen.toast(a, "SPR_" + dstIdx + " substituida");
                    }
                });
            }
        }).start();
    }

    /** Recorta cada sprite marcada da origem, amplia se preciso e adiciona ao personagem; grava as folhas uma vez no fim. */
    private static void addAll(final Activity a, final SpriteLib src, final SpriteLib target, final List<Integer> chosen, final int factor, final Runnable uiOnly) {
        final BusyDialog busy = BusyDialog.show(a, "Adicionando sprites");
        final int first = target.count();
        new Thread(new Runnable() {
            @Override public void run() {
                int added = 0, bad = 0;
                final java.util.ArrayList<String> fails = new java.util.ArrayList<String>();
                final int total = chosen.size();
                for (int k = 0; k < total; k++) {
                    int idx = chosen.get(k).intValue();
                    busy.set("SPR_" + idx, k, total);
                    Bitmap b = null;
                    try {
                        b = src.cut(idx);
                        if (b == null) { bad++; String why = src.cutProblem(idx); fails.add("SPR_" + idx + ": " + (why != null ? why : "o recorte nao gerou imagem")); continue; }
                        if (factor > 1) {
                            Bitmap big = Bitmap.createScaledBitmap(b, b.getWidth() * factor, b.getHeight() * factor, false);   // sem suavizar: pixel art
                            b.recycle();
                            b = big;
                        }
                        target.add(b);
                        added++;
                    } catch (Throwable t) {
                        bad++;
                        fails.add("SPR_" + idx + ": " + (t.getMessage() != null ? t.getMessage() : t.toString()));
                    } finally {
                        if (b != null && !b.isRecycled()) b.recycle();
                    }
                }
                src.release();
                busy.set("Gravando as folhas de sprites...", 0, 0);
                try { target.commit(); } catch (Exception ex) { fails.add("gravar as folhas: " + (ex.getMessage() != null ? ex.getMessage() : ex.toString())); }
                busy.dismiss();
                final int fa = added, fb = bad;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        uiOnly.run();
                        SpriteListScreen.toast(a, fa + " sprite(s) adicionada(s)" + (fa > 0 ? " (SPR_" + first + " a SPR_" + (first + fa - 1) + ")" : "")
                                + (fb > 0 ? ", " + fb + " falharam" : "")
                                + (target.downscaled > 0 ? ". " + target.downscaled + " reduzida(s) para no maximo " + SpriteLib.MAX_SIDE + " px" : ""));
                        target.downscaled = 0;
                        if (!fails.isEmpty()) ErrorListDialog.show(a, "Erro ao adicionar sprites", fails);
                    }
                });
            }
        }).start();
    }
}
