package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Alerta dos PACs/TXT que faltam em assets, com CONTINUAR ASSIM e EXTRAIR (extrai os que tem {@code nome.pac} ao lado, com loading). So tela; a lista vem de
 * {@link PackCheck} e a extracao de {@link ExtractorBridge}.
 */
final class PackAlert {
    private PackAlert() { }

    /** Assinatura do ultimo alerta que o usuario dispensou com CONTINUAR ASSIM (para nao repetir o mesmo a cada volta ao app). */
    private static String dismissedSig = "";
    /** Ja ha um alerta (ou uma extracao) na tela: nunca abre outro por cima. */
    private static volatile boolean showing;

    static void forget() { dismissedSig = ""; }

    static boolean isShowing() { return showing; }

    /**
     * Confere {@code root}; sem nada faltando (ou o mesmo alerta ja dispensado, se {@code force} for false) chama {@code onContinue} direto.
     * CONTINUAR ASSIM chama {@code onContinue}; EXTRAIR extrai e depois chama {@code onExtracted}.
     */
    static void check(final Activity a, final File root, boolean force, final Runnable onContinue, final Runnable onExtracted) {
        final List<PackCheck.Item> items = PackCheck.scan(root);
        final String sig = PackCheck.signature(items);
        if (showing) return;                                   // o alerta que ja esta na tela cuida do que vem depois
        if (!PackAlertGate.shouldShow(items, sig, dismissedSig, showing, force)) { if (onContinue != null) onContinue.run(); return; }
        showing = true;
        final List<PackCheck.Item> can = PackCheck.extractable(items);
        TextView tv = new I18nTextView(a).noTranslate();
        tv.setText(ErrorListDialog.join(PackCheck.lines(items, true)));
        tv.setTextColor(0xFFE6E8EC);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setTextIsSelectable(true);
        int p = (int) (14 * a.getResources().getDisplayMetrics().density);
        tv.setPadding(p, p / 2, p, p / 2);
        ScrollView sv = new SafeScrollView(a);
        sv.addView(tv);
        AlertDialog.Builder b = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Faltam PACs ou arquivos TXT")
                .setView(sv)
                .setCancelable(false)
                .setNegativeButton("CONTINUAR ASSIM", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showing = false; dismissedSig = sig; if (onContinue != null) onContinue.run(); }
                });
        if (!can.isEmpty()) b.setPositiveButton("EXTRAIR", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int w) { extract(a, root, can, onExtracted != null ? onExtracted : onContinue); }   // showing so cai quando a extracao termina
        });
        b.show();
    }

    private static void extract(final Activity a, final File root, final List<PackCheck.Item> items, final Runnable done) {
        final BusyDialog bd = BusyDialog.show(a, "Extraindo os PACs");
        new Thread(new Runnable() { @Override public void run() {
            final List<String> report = new ArrayList<String>();
            boolean failed = false;
            for (int k = 0; k < items.size(); k++) {
                final PackCheck.Item it = PackCheck.scanOne(root, items.get(k).name);      // reconfere: pode ja ter sido extraido (ou o TXT apareceu)
                final int kk = k;
                if (it == null) { report.add(items.get(k).name + ": já estava completo"); continue; }
                try {
                    report.add(ExtractorBridge.extract(root, it, new ExtractorBridge.Progress() {
                        @Override public void on(String pack, String segment, int index, int total) {
                            bd.set(it.name + " (" + (kk + 1) + "/" + items.size() + ")  " + segment, index + 1, total);
                        }
                    }));
                } catch (Throwable e) {
                    failed = true;
                    report.add(it.name + ": ERRO " + e);
                }
            }
            final boolean bad = failed;
            bd.dismiss();
            a.runOnUiThread(new Runnable() { @Override public void run() {
                showing = false;
                dismissedSig = PackCheck.signature(PackCheck.scan(root));     // o que ainda falta (sem PAC) o usuario acabou de ver no relatorio: nao reabrir o alerta
                if (bad) ErrorListDialog.show(a, "Extração com erros", report);
                else I18nUi.toast(a, ErrorListDialog.join(report), android.widget.Toast.LENGTH_LONG).show();
                if (done != null) done.run();
            } });
        } }).start();
    }
}
