package com.zue.attackeditor;

import java.util.List;

/** Decide se o alerta de PACs que faltam deve aparecer (Java puro): nunca dois ao mesmo tempo, nem o mesmo que o usuario ja dispensou com CONTINUAR ASSIM. */
final class PackAlertGate {
    private PackAlertGate() { }

    static boolean shouldShow(List<PackCheck.Item> items, String sig, String dismissedSig, boolean showing, boolean force) {
        if (showing || items == null || items.isEmpty()) return false;
        return force || !sig.equals(dismissedSig);
    }
}
