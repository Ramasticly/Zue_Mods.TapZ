package com.zue.attackeditor;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Quais packs o app precisa e o que falta deles (Java puro). Necessarios: gamedata (*.dac.txt) e effect (*.dac.txt + *.cnv.txt) sempre; charNN (dac, bin, cnv),
 * charfNN e bobjNN (dac, cnv) quando a pasta ou o .pac existem. O jogo extrai {@code nome.pac} para a pasta {@code nome/} ao lado; aqui diz-se, de cada pack
 * incompleto, se o .pac existe para extrair. Com mais de um tipo de TXT faltando, vira uma linha so por pack.
 */
final class PackCheck {
    private PackCheck() { }

    static final class Item {
        final String name;                  // gamedata, effect, char01, charf01, bobj01
        final File dir;                     // pasta do pack (pode nao existir)
        final File pac;                     // .pac ao lado (null se nao existe)
        final List<String> missing = new ArrayList<String>();       // "*.dac.txt", ...
        Item(String name, File dir, File pac) { this.name = name; this.dir = dir; this.pac = pac; }
        boolean canExtract() { return pac != null; }
        /** Uma linha para o alerta (em portugues). */
        String line() { return line(false); }
        /** Uma linha para o alerta; {@code translate} passa os pedacos fixos por {@link I18n#tr}. */
        String line(boolean translate) {
            StringBuilder b = new StringBuilder(name).append(translate ? I18n.tr(" — falta ") : " — falta ");
            for (int i = 0; i < missing.size(); i++) b.append(i > 0 ? ", " : "").append(missing.get(i));
            if (pac != null) b.append(" (").append(pac.getName()).append(translate ? I18n.tr(" disponível para extrair)") : " disponível para extrair)");
            else b.append(translate ? I18n.tr(" (sem PAC para extrair)") : " (sem PAC para extrair)");
            return b.toString();
        }
    }

    static boolean isPackName(String n) { return n.matches("effect|gamedata|char\\d{2}|charf\\d+|bobj\\d+"); }

    private static String[] kindsOf(String name) {
        if (name.equals("gamedata")) return new String[] {"dac"};
        if (name.startsWith("char") && !name.startsWith("charf")) return new String[] {"dac", "bin", "cnv"};
        return new String[] {"dac", "cnv"};
    }

    /** Os packs de {@code root} (assets) com TXT faltando, em ordem de nome. */
    static List<Item> scan(File root) {
        List<Item> out = new ArrayList<Item>();
        File[] fs = root == null ? null : root.listFiles();
        if (fs == null) return out;
        TreeSet<String> names = new TreeSet<String>();
        names.add("gamedata");
        names.add("effect");
        for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.US);
            if (f.isFile() && n.endsWith(".pac")) n = n.substring(0, n.length() - 4);
            else if (!f.isDirectory()) continue;
            if (isPackName(n)) names.add(n);
        }
        for (String n : names) {
            Item it = check(root, fs, n);
            if (it != null) out.add(it);
        }
        return out;
    }

    /** O pack {@code name} agora: o item com o que ainda falta, ou null se esta completo (ou nao existe e nao e obrigatorio). Reconfere o disco. */
    static Item scanOne(File root, String name) {
        File[] fs = root == null ? null : root.listFiles();
        return fs == null ? null : check(root, fs, name.toLowerCase(Locale.US));
    }

    private static Item check(File root, File[] fs, String n) {
        File dir = null, pac = null;
        for (File f : fs) {
            String fn = f.getName().toLowerCase(Locale.US);
            if (f.isDirectory() && fn.equals(n)) dir = f;
            else if (f.isFile() && fn.equals(n + ".pac")) pac = f;
        }
        Item it = new Item(n, dir != null ? dir : new File(root, n), pac);
        if (n.equals("gamedata")) {
            if (!GameData.hasTxt(root)) it.missing.add("*.dac.txt");
        } else {
            for (String k : kindsOf(n)) if (dir == null || TxtFiles.find(dir, k) == null) it.missing.add("*." + k + ".txt");
        }
        if (it.missing.isEmpty()) return null;
        if (dir == null && pac == null && !n.equals("gamedata") && !n.equals("effect")) return null;      // nem pasta nem PAC e nao e obrigatorio: nada a avisar
        return it;
    }

    /** Assinatura dos problemas (para nao repetir o mesmo alerta). */
    static String signature(List<Item> items) {
        StringBuilder b = new StringBuilder();
        for (Item i : items) b.append(i.name).append(':').append(i.missing).append(i.pac != null ? "+" : "-").append(';');
        return b.toString();
    }

    /** Linhas do alerta. */
    static List<String> lines(List<Item> items, boolean translate) {
        List<String> l = new ArrayList<String>();
        for (Item i : items) l.add(i.line(translate));
        return l;
    }

    /** Os que tem .pac para extrair. */
    static List<Item> extractable(List<Item> items) {
        List<Item> l = new ArrayList<Item>();
        for (Item i : items) if (i.canExtract()) l.add(i);
        return Collections.unmodifiableList(l);
    }
}
