package com.zue.attackeditor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * PNG de 8 bits com paleta (ate 256 cores, alpha em tRNS). Imagem com 256 cores ou menos sai sem perda; com mais, quantizacao mediana-corte
 * (sem pontilhado, que estragaria sprite). Java puro: le as linhas por {@link Rows}, entao a folha inteira nao precisa estar na memoria como int[].
 */
final class Png8 {
    private Png8() { }

    /** Linhas de uma imagem ARGB. */
    interface Rows {
        int width();
        int height();
        /** Preenche {@code out[0..width)} com a linha {@code y} (ARGB nao premultiplicado). */
        void row(int y, int[] out) throws IOException;
    }

    static Rows of(final int[] px, final int w, final int h) {
        return new Rows() {
            @Override public int width() { return w; }
            @Override public int height() { return h; }
            @Override public void row(int y, int[] out) { System.arraycopy(px, y * w, out, 0, w); }
        };
    }

    private static int norm(int p) { return (p >>> 24) == 0 ? 0 : p; }

    /** Resultado: bytes do PNG e quantas cores a paleta tem; {@code lossless} = false se foi preciso reduzir as cores. */
    static final class Out {
        byte[] png;
        int colors;
        boolean lossless;
    }

    static Out encode(Rows src) throws IOException {
        int w = src.width(), h = src.height();
        int[] row = new int[w];
        // passo 1: cores exatas (ate 257) e histograma 5-5-5-4 bits
        HashMap<Integer, Integer> exact = new HashMap<Integer, Integer>();
        boolean tooMany = false;
        int[] cnt = new int[1 << 19];
        long[] sa = new long[1 << 19], sr = new long[1 << 19], sg = new long[1 << 19], sb = new long[1 << 19];
        for (int y = 0; y < h; y++) {
            src.row(y, row);
            for (int x = 0; x < w; x++) {
                int p = norm(row[x]);
                if (!tooMany) {
                    Integer k = Integer.valueOf(p);
                    if (!exact.containsKey(k)) { exact.put(k, Integer.valueOf(exact.size())); if (exact.size() > 256) tooMany = true; }
                }
                int b = bucket(p);
                cnt[b]++; sa[b] += p >>> 24; sr[b] += (p >> 16) & 255; sg[b] += (p >> 8) & 255; sb[b] += p & 255;
            }
        }
        int[] palette;
        boolean lossless = !tooMany;
        if (lossless) {
            palette = new int[exact.size()];
            for (java.util.Map.Entry<Integer, Integer> e : exact.entrySet()) palette[e.getValue().intValue()] = e.getKey().intValue();
        } else {
            palette = medianCut(cnt, sa, sr, sg, sb, 256);
        }
        // passo 2: indices
        int[] cache = lossless ? null : new int[1 << 19];
        if (cache != null) java.util.Arrays.fill(cache, -1);
        HashMap<Integer, Integer> idx = null;
        if (lossless) { idx = new HashMap<Integer, Integer>(); for (int i = 0; i < palette.length; i++) idx.put(Integer.valueOf(palette[i]), Integer.valueOf(i)); }
        Deflater def = new Deflater(9);
        ByteArrayOutputStream idat = new ByteArrayOutputStream();
        byte[] line = new byte[w + 1];
        byte[] buf = new byte[1 << 16];
        for (int y = 0; y < h; y++) {
            src.row(y, row);
            line[0] = 0;
            for (int x = 0; x < w; x++) {
                int p = norm(row[x]);
                int i;
                if (lossless) i = idx.get(Integer.valueOf(p)).intValue();
                else {
                    int b = bucket(p);
                    i = cache[b];
                    if (i < 0) { i = nearest(palette, p); cache[b] = i; }
                }
                line[x + 1] = (byte) i;
            }
            def.setInput(line, 0, w + 1);
            while (!def.needsInput()) { int n = def.deflate(buf); if (n > 0) idat.write(buf, 0, n); else break; }
        }
        def.finish();
        while (!def.finished()) { int n = def.deflate(buf); idat.write(buf, 0, n); }
        def.end();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{(byte) 0x89, 'P', 'N', 'G', 13, 10, 26, 10});
        byte[] ihdr = new byte[13];
        put32(ihdr, 0, w); put32(ihdr, 4, h);
        ihdr[8] = 8; ihdr[9] = 3;
        chunk(out, "IHDR", ihdr);
        byte[] plte = new byte[palette.length * 3];
        int lastAlpha = -1;
        for (int i = 0; i < palette.length; i++) {
            plte[i * 3] = (byte) (palette[i] >> 16); plte[i * 3 + 1] = (byte) (palette[i] >> 8); plte[i * 3 + 2] = (byte) palette[i];
            if ((palette[i] >>> 24) != 255) lastAlpha = i;
        }
        chunk(out, "PLTE", plte);
        if (lastAlpha >= 0) {
            byte[] trns = new byte[lastAlpha + 1];
            for (int i = 0; i <= lastAlpha; i++) trns[i] = (byte) (palette[i] >>> 24);
            chunk(out, "tRNS", trns);
        }
        chunk(out, "IDAT", idat.toByteArray());
        chunk(out, "IEND", new byte[0]);
        Out o = new Out();
        o.png = out.toByteArray(); o.colors = palette.length; o.lossless = lossless;
        return o;
    }

    private static int bucket(int p) {
        return ((p >>> 24) >> 4 << 15) | (((p >> 16) & 255) >> 3 << 10) | (((p >> 8) & 255) >> 3 << 5) | ((p & 255) >> 3);
    }

    private static int nearest(int[] pal, int p) {
        int best = 0;
        long bd = Long.MAX_VALUE;
        int pa = p >>> 24, pr = (p >> 16) & 255, pg = (p >> 8) & 255, pb = p & 255;
        for (int i = 0; i < pal.length; i++) {
            int q = pal[i];
            long da = (q >>> 24) - pa, dr = ((q >> 16) & 255) - pr, dg = ((q >> 8) & 255) - pg, db = (q & 255) - pb;
            long d = da * da * 3 + (pa == 0 && (q >>> 24) == 0 ? 0 : dr * dr + dg * dg + db * db);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    private static final class Box {
        final ArrayList<Integer> items = new ArrayList<Integer>();
        long total;
        int[] lo = new int[4], hi = new int[4];
    }

    private static int[] medianCut(int[] cnt, long[] sa, long[] sr, long[] sg, long[] sb, int max) {
        Box first = new Box();
        for (int b = 0; b < cnt.length; b++) if (cnt[b] > 0) { first.items.add(Integer.valueOf(b)); first.total += cnt[b]; }
        ArrayList<Box> boxes = new ArrayList<Box>();
        boxes.add(first);
        final int[][] chan = new int[cnt.length][];
        while (boxes.size() < max) {
            Box pick = null;
            int pc = -1;
            double ps = -1;
            for (Box bx : boxes) {
                if (bx.items.size() < 2) continue;
                int[] lo = {255, 255, 255, 255}, hi = {0, 0, 0, 0};
                for (Integer it : bx.items) {
                    int b = it.intValue();
                    int[] c = avg(b, cnt, sa, sr, sg, sb);
                    for (int k = 0; k < 4; k++) { lo[k] = Math.min(lo[k], c[k]); hi[k] = Math.max(hi[k], c[k]); }
                }
                for (int k = 0; k < 4; k++) {
                    double score = (hi[k] - lo[k]) * (k == 0 ? 1.5 : 1.0) * Math.sqrt((double) bx.total);
                    if (score > ps) { ps = score; pick = bx; pc = k; }
                }
            }
            if (pick == null || ps <= 0) break;
            final int ch = pc;
            final int[] fc = cnt;
            final long[] fa = sa, fr = sr, fg = sg, fb = sb;
            java.util.Collections.sort(pick.items, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer x, Integer y) { return avg(x.intValue(), fc, fa, fr, fg, fb)[ch] - avg(y.intValue(), fc, fa, fr, fg, fb)[ch]; }
            });
            long half = pick.total / 2, acc = 0;
            int cut = 1;
            for (int i = 0; i < pick.items.size() - 1; i++) { acc += cnt[pick.items.get(i).intValue()]; cut = i + 1; if (acc >= half) break; }
            Box b2 = new Box();
            for (int i = cut; i < pick.items.size(); i++) { b2.items.add(pick.items.get(i)); b2.total += cnt[pick.items.get(i).intValue()]; }
            while (pick.items.size() > cut) pick.items.remove(pick.items.size() - 1);
            pick.total -= b2.total;
            boxes.add(b2);
        }
        int[] pal = new int[boxes.size()];
        boolean hasClear = false;
        for (int i = 0; i < pal.length; i++) {
            long t = 0, a = 0, r = 0, g = 0, b = 0;
            for (Integer it : boxes.get(i).items) { int k = it.intValue(); t += cnt[k]; a += sa[k]; r += sr[k]; g += sg[k]; b += sb[k]; }
            pal[i] = t == 0 ? 0 : ((int) (a / t) << 24) | ((int) (r / t) << 16) | ((int) (g / t) << 8) | (int) (b / t);
            if ((pal[i] >>> 24) == 0) { pal[i] = 0; hasClear = true; }
        }
        return pal;
    }

    private static int[] avg(int b, int[] cnt, long[] sa, long[] sr, long[] sg, long[] sb) {
        long c = Math.max(1, cnt[b]);
        return new int[]{(int) (sa[b] / c), (int) (sr[b] / c), (int) (sg[b] / c), (int) (sb[b] / c)};
    }

    private static void put32(byte[] b, int o, int v) { b[o] = (byte) (v >> 24); b[o + 1] = (byte) (v >> 16); b[o + 2] = (byte) (v >> 8); b[o + 3] = (byte) v; }

    private static void chunk(ByteArrayOutputStream out, String type, byte[] data) throws IOException {
        byte[] len = new byte[4];
        put32(len, 0, data.length);
        out.write(len);
        byte[] t = type.getBytes("US-ASCII");
        out.write(t);
        out.write(data);
        CRC32 crc = new CRC32();
        crc.update(t);
        crc.update(data);
        byte[] c = new byte[4];
        put32(c, 0, (int) crc.getValue());
        out.write(c);
    }

    // ---- leitura (so PNG de 8 bits indexado, filtro 0: o que este codigo escreve; serve para conferir o arquivo antes de trocar o original) ----

    static final class Img {
        int w, h;
        int[] px;
    }

    static Img decode(byte[] png) throws IOException {
        int p = 8;
        int w = 0, h = 0;
        int[] pal = null;
        byte[] trns = new byte[0];
        ByteArrayOutputStream idat = new ByteArrayOutputStream();
        while (p + 8 <= png.length) {
            int len = ((png[p] & 255) << 24) | ((png[p + 1] & 255) << 16) | ((png[p + 2] & 255) << 8) | (png[p + 3] & 255);
            String type = new String(png, p + 4, 4, "US-ASCII");
            int d = p + 8;
            if (type.equals("IHDR")) {
                w = ((png[d] & 255) << 24) | ((png[d + 1] & 255) << 16) | ((png[d + 2] & 255) << 8) | (png[d + 3] & 255);
                h = ((png[d + 4] & 255) << 24) | ((png[d + 5] & 255) << 16) | ((png[d + 6] & 255) << 8) | (png[d + 7] & 255);
                if (png[d + 8] != 8 || png[d + 9] != 3) throw new IOException("nao e PNG indexado de 8 bits");
            } else if (type.equals("PLTE")) {
                pal = new int[len / 3];
                for (int i = 0; i < pal.length; i++) pal[i] = 0xFF000000 | ((png[d + i * 3] & 255) << 16) | ((png[d + i * 3 + 1] & 255) << 8) | (png[d + i * 3 + 2] & 255);
            } else if (type.equals("tRNS")) {
                trns = java.util.Arrays.copyOfRange(png, d, d + len);
            } else if (type.equals("IDAT")) {
                idat.write(png, d, len);
            }
            p = d + len + 4;
        }
        if (pal == null || w <= 0 || h <= 0) throw new IOException("PNG incompleto");
        for (int i = 0; i < trns.length && i < pal.length; i++) pal[i] = (pal[i] & 0xFFFFFF) | ((trns[i] & 255) << 24);
        byte[] raw = new byte[(w + 1) * h];
        Inflater inf = new Inflater();
        inf.setInput(idat.toByteArray());
        try {
            int n = 0;
            while (n < raw.length) { int k = inf.inflate(raw, n, raw.length - n); if (k <= 0) break; n += k; }
            if (n != raw.length) throw new IOException("dados do PNG incompletos");
        } catch (DataFormatException e) {
            throw new IOException("dados do PNG invalidos");
        } finally { inf.end(); }
        Img im = new Img();
        im.w = w; im.h = h; im.px = new int[w * h];
        for (int y = 0; y < h; y++) {
            if (raw[y * (w + 1)] != 0) throw new IOException("filtro de linha nao suportado");
            for (int x = 0; x < w; x++) im.px[y * w + x] = pal[raw[y * (w + 1) + 1 + x] & 255];
        }
        return im;
    }
}
