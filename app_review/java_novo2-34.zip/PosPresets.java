package com.zue.attackeditor;

/**
 * Posicoes predefinidas do jogo (IA da CPU, md 685 / 24336): distancia PERTO e MEDIA vem do gamedata (HDAT 2, linhas 1 e 2;
 * coluna 0 = alvo no chao, coluna 1 = alvo no ar) e alturas pela faixa do jogo (chao = y 240; voando baixo = abaixo de y 160,
 * voando alto = y <= 160, ou seja 80 px acima do chao). LONGE nao existe como valor no jogo (e "alem do medio"): aqui e
 * medio + (medio - perto).
 */
final class PosPresets {
    private PosPresets() { }

    static final String[] DIST_NAMES = {"PERTO", "MEDIO", "LONGE"};
    static final String[] HEIGHT_NAMES = {"CHAO", "VOANDO BAIXO", "VOANDO ALTO"};
    /** Altura (px acima do chao) usada em cada faixa; a fronteira baixo/alto do jogo e 80 px. */
    static final int[] HEIGHTS = {0, 40, 120};
    static final int FALLBACK_NEAR = 60, FALLBACK_MID = 120;

    /** Distancia em px para [faixa de altura][perto/medio/longe]; usa coluna "ar" quando nao esta no chao. */
    static int distance(GameData gd, int heightBand, int distBand) {
        boolean air = heightBand > 0;
        int near = gd == null ? -1 : gd.cpuDist(1, air);
        int mid = gd == null ? -1 : gd.cpuDist(2, air);
        if (near <= 0) near = FALLBACK_NEAR;
        if (mid <= near) mid = Math.max(near + 1, FALLBACK_MID);
        int d = distBand == 0 ? near : distBand == 1 ? mid : mid + (mid - near);
        return Math.max(0, Math.min(480, d));
    }

    static boolean fromGame(GameData gd) { return gd != null && gd.cpuDist(1, false) > 0 && gd.cpuDist(2, false) > 0; }
}
