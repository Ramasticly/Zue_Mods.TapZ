package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Copia de seguranca ANTES de OTIMIZAR: o personagem inteiro, bruto (DAC, CNV, Bin, .txt, audios, folhas PNG/GIF, subpastas, salvos/), em
 * Tap Battle/TBRE/Backups/PreOptim/AAAAMMDD_HHMMSS_charNN/. Uma copia por execucao; nunca sobrescreve outra (sufixo _2, _3...). Java puro.
 */
final class PreOptimBackup {
    private PreOptimBackup() { }

    /** Pasta (ainda nao criada) da copia de {@code when}; se ja existir, acrescenta _2, _3... */
    static File dirFor(File charDir, Date when) {
        File root = new File(Saver.backupsDir(charDir), "PreOptim");
        String base = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(when) + "_" + charDir.getName();
        File d = new File(root, base);
        for (int i = 2; d.exists(); i++) d = new File(root, base + "_" + i);
        return d;
    }

    /** Faz a copia bruta e devolve a pasta. Se falhar no meio, apaga o que copiou e relanca (nada fica pela metade). */
    static File run(File charDir, Date when, Saver.CopyProgress prog) throws IOException {
        if (charDir == null || !charDir.isDirectory()) throw new IOException("pasta do personagem não encontrada: " + charDir);
        File dst = dirFor(charDir, when);
        String a = charDir.getCanonicalPath(), b = dst.getCanonicalPath();
        if (b.equals(a) || b.startsWith(a + File.separator)) throw new IOException("a pasta de backup ficaria dentro do personagem");
        try {
            Saver.copyChar(charDir, dst, false, prog, true);
        } catch (IOException e) {
            try { Saver.deleteTree(dst); } catch (IOException ignored) { /* melhor esforco */ }
            throw e;
        } catch (RuntimeException e) {
            try { Saver.deleteTree(dst); } catch (IOException ignored) { /* melhor esforco */ }
            throw e;
        }
        return dst;
    }
}
