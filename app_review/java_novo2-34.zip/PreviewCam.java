package com.zue.attackeditor;

/** Camera livre de uma previa (origem na tela + escala): a mesma da previa principal. Java puro. */
final class PreviewCam {
    static final float MIN_SCALE = 0.5f, MAX_SCALE = 24f;
    /** Origem (ancora do personagem) na tela, em pixels, e pixels de tela por unidade logica. */
    float originX, originY, scale = 1f;
    /** Limites desta camera (a previa do Editar Frame baixa o minimo para caber sprites enormes). */
    float minScale = MIN_SCALE, maxScale = MAX_SCALE;

    /** Enquadramento inicial da previa principal ({@code AttackView.recenter}): centro na largura, 55% da altura, escala = densidade (minimo 1). */
    void recenter(float w, float h, float density) {
        originX = w * 0.5f;
        originY = h * 0.55f;
        scale = Math.max(1f, density);
    }

    /**
     * Enquadra a caixa ({@code x0,y0}-{@code x1,y1}, em unidades logicas) numa vista {@code w} x {@code h}: a escala faz a caixa caber com {@code margin} (fracao, ex.: 0,25)
     * de folga - diminui para sprites grandes e aumenta para pequenas, nos limites de {@link #MIN_SCALE}/{@link #MAX_SCALE} - e o centro da caixa vai para o centro da vista.
     */
    void fitBox(float w, float h, double x0, double y0, double x1, double y1, float margin) {
        double bw = Math.max(1.0, x1 - x0), bh = Math.max(1.0, y1 - y0);
        double k = Math.min(w / (bw * (1.0 + margin)), h / (bh * (1.0 + margin)));
        scale = (float) Math.max(minScale, Math.min(maxScale, k));
        originX = (float) (w * 0.5 - (x0 + x1) * 0.5 * scale);
        originY = (float) (h * 0.5 - (y0 + y1) * 0.5 * scale);
    }

    /** Arrastar com um dedo: soma o deslocamento a origem. */
    void pan(float dx, float dy) { originX += dx; originY += dy; }

    /** Pinca: multiplica a escala por {@code factor} (nos limites) mantendo parado o ponto ({@code fx}, {@code fy}) da tela. */
    void zoomAt(float fx, float fy, float factor) {
        float ns = Math.max(minScale, Math.min(maxScale, scale * factor));
        float k = ns / scale;
        originX = fx - (fx - originX) * k;
        originY = fy - (fy - originY) * k;
        scale = ns;
    }
}
