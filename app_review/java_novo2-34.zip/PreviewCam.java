package com.zue.attackeditor;

/** Camera livre de uma previa (origem na tela + escala): a mesma da previa principal. Java puro. */
final class PreviewCam {
    static final float MIN_SCALE = 0.5f, MAX_SCALE = 24f;
    /** Origem (ancora do personagem) na tela, em pixels, e pixels de tela por unidade logica. */
    float originX, originY, scale = 1f;

    /** Enquadramento inicial da previa principal ({@code AttackView.recenter}): centro na largura, 55% da altura, escala = densidade (minimo 1). */
    void recenter(float w, float h, float density) {
        originX = w * 0.5f;
        originY = h * 0.55f;
        scale = Math.max(1f, density);
    }

    /** Arrastar com um dedo: soma o deslocamento a origem. */
    void pan(float dx, float dy) { originX += dx; originY += dy; }

    /** Pinca: multiplica a escala por {@code factor} (nos limites) mantendo parado o ponto ({@code fx}, {@code fy}) da tela. */
    void zoomAt(float fx, float fy, float factor) {
        float ns = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale * factor));
        float k = ns / scale;
        originX = fx - (fx - originX) * k;
        originY = fy - (fy - originY) * k;
        scale = ns;
    }
}
