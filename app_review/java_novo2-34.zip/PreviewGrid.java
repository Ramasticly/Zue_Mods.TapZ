package com.zue.attackeditor;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Fundo das previas: grade, linha central (vertical na ancora) e chao (preenchimento + linha dos pes). Compartilhado pela previa principal e pela do Editar Frame. */
final class PreviewGrid {
    static final int GRID_STEP = 32;
    private static final Paint GRID = new Paint(), AXIS = new Paint(), GROUND_FILL = new Paint(), GROUND_LINE = new Paint();

    private PreviewGrid() { }

    static void draw(Canvas c, int w, int h, float originX, float originY, float scale, float density, boolean showGrid) { draw(c, w, h, originX, originY, scale, density, showGrid, true); }

    /** {@code showAxes} liga a linha central e o chao (preenchimento + linha dos pes); desligado, so a grade. */
    static void draw(Canvas c, int w, int h, float originX, float originY, float scale, float density, boolean showGrid, boolean showAxes) {
        if (showGrid) {
            GRID.setColor(0x14FFFFFF);
            GRID.setStrokeWidth(1f);
            float step = GRID_STEP * scale;
            if (step >= 8f) {
                float x0 = originX % step;
                if (x0 < 0) x0 += step;
                for (float x = x0; x < w; x += step) c.drawLine(x, 0, x, h, GRID);
                float y0 = originY % step;
                if (y0 < 0) y0 += step;
                for (float y = y0; y < h; y += step) c.drawLine(0, y, w, y, GRID);
            }
        }
        if (!showAxes) return;
        AXIS.setColor(0x55FFFFFF);
        AXIS.setStrokeWidth(Math.max(1f, density));
        c.drawLine(originX, 0, originX, h, AXIS);
        // chao: linha dos pes (y = 0)
        GROUND_FILL.setColor(0x1A8FB4FF);
        c.drawRect(0, originY, w, h, GROUND_FILL);
        GROUND_LINE.setColor(0xCC6AA1FF);
        GROUND_LINE.setStrokeWidth(Math.max(2f, density * 2f));
        c.drawLine(0, originY, w, originY, GROUND_LINE);
    }
}
