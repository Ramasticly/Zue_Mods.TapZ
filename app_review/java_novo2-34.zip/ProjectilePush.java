package com.zue.attackeditor;

import java.util.HashSet;
import java.util.Set;

/**
 * "Projetil empurra o oponente": copia a reacao da hitbox de um ANO de projetil para um slot do personagem e troca as velocidades pelas do projetil naquele frame, para o
 * oponente acompanhar a trajetoria. Escolha do slot (vazio, depois nao usado, depois a propria reacao com confirmacao) e conta das velocidades. Java puro.
 */
final class ProjectilePush {
    private ProjectilePush() { }

    static final int EMPTY = 0, UNUSED = 1, CURRENT = 2, NONE = 3;

    /** Onde gravar: {@code kind} (EMPTY / UNUSED / CURRENT = editar a atual, pede confirmacao / NONE = nao ha como) e o slot do personagem 0..19. */
    static final class Choice {
        final int kind, slot;
        Choice(int kind, int slot) { this.kind = kind; this.slot = slot; }
    }

    /**
     * Slots do personagem (0..19) em uso: citados por alguma hitbox de ANO presente (OPT 1 de 30 a 49), pela reacao de choque do personagem ou como "proxima reacao"
     * (COMP 30..49) de outra tabela.
     */
    static Set<Integer> used(Dac dac, CharData cd) {
        Set<Integer> out = new HashSet<Integer>();
        java.util.ArrayList<Integer> anos = new java.util.ArrayList<Integer>();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a != null && a.present) anos.add(Integer.valueOf(i));
        }
        out.addAll(Saver.reactionsUsed(dac, anos));
        int clash = cd.clashReaction();
        if (clash >= 30 && clash < 30 + CharData.REACTION_COUNT) out.add(Integer.valueOf(clash - 30));
        for (int t = 0; t < CharData.REACTION_COUNT; t++) {
            ReactionTable tb = cd.reaction(t);
            if (tb == null) continue;
            for (int r = 0; r < tb.rows; r++) {
                int comp = tb.u8(r, 11);
                if (comp >= 30 && comp < 30 + CharData.REACTION_COUNT) out.add(Integer.valueOf(comp - 30));
            }
        }
        return out;
    }

    /**
     * 1) o primeiro slot vazio; 2) o primeiro slot com tabela que nada usa; 3) a reacao atual ({@code currentIndex} = OPT 1 % 50, so se for do personagem, 30..49) editada
     * no lugar, depois de confirmar; 4) nada (a atual e do jogo e nao ha onde gravar).
     */
    static Choice chooseSlot(CharData cd, Set<Integer> used, int currentIndex) {
        java.util.List<Integer> empty = ReactionSlots.emptySlots(cd);
        if (!empty.isEmpty()) return new Choice(EMPTY, empty.get(0).intValue());
        for (int i = 0; i < CharData.REACTION_COUNT; i++) {
            if (i == currentIndex - 30) continue;
            if (!used.contains(Integer.valueOf(i))) return new Choice(UNUSED, i);
        }
        if (currentIndex >= 30 && currentIndex < 30 + CharData.REACTION_COUNT) return new Choice(CURRENT, currentIndex - 30);
        return new Choice(NONE, -1);
    }

    /**
     * Passo 0 passa a ter a velocidade (px/tick) e a aceleracao do projetil, no chao (colunas 3..6) e no ar (7..10); os demais passos mantem (-1). Unidade da tabela: 0,1 px.
     * Devolve true se algum valor passou de +-12,7 px/tick (limite do byte) e foi cortado.
     */
    static boolean apply(ReactionTable t, double vx, double vy, double ax, double ay) {
        if (t == null || t.rows <= 0) return false;
        boolean[] cut = {false};
        int[] v = {units(vx, cut), units(vy, cut), units(ax, cut), units(ay, cut)};
        for (int r = 0; r < t.rows; r++) {
            for (int k = 0; k < 4; k++) {
                int val = r == 0 ? v[k] : -1;
                t.set(r, 3 + k, val & 255);
                t.set(r, 7 + k, val & 255);
            }
        }
        return cut[0];
    }

    /** px/tick -> unidade da tabela (0,1 px), no intervalo do byte com sinal; -1 e -2 sao codigos ("mantem" e "metade"), entao o valor evita os dois. */
    static int units(double pxPerTick, boolean[] cut) {
        long u = Math.round(pxPerTick * 10.0);
        if (u > 127) { u = 127; cut[0] = true; }
        if (u < -128) { u = -128; cut[0] = true; }
        if (u == -1) u = 0;
        if (u == -2) u = -3;
        return (int) u;
    }

    /** O projetil esta parado neste frame (sem velocidade nem aceleracao)? Nao ha o que copiar. */
    static boolean still(double vx, double vy, double ax, double ay) {
        return Math.abs(vx) < 0.05 && Math.abs(vy) < 0.05 && Math.abs(ax) < 0.05 && Math.abs(ay) < 0.05;
    }
}
