package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Ramificacao do projetil (tela cheia): ANIM_INICIAL -> animacoes do projetil (normal/abaixo/acima, + ANO+1 e ANO+2 com 3 projeteis)
 * -> reacoes (ao acertar, chao, global) -> sub-projetil (flag 0 na ANO do projetil) e as reacoes dele.
 * Cada no tem previa animada, EDITAR (abre a ANO) e TROCAR (escolher outra ANO). Edita o golpe (HDAT 4) com desfazer.
 */
final class ProjectileTree {
    private final Activity a;
    private final AttackView view;
    private final Navigator nav;
    private final Runnable onChanged;
    private final float d;
    private Dialog screen;
    private LinearLayout box;

    // campos editaveis do golpe
    private static final int P_NORMAL = 0, P_ABAIXO = 1, P_ACIMA = 2, P_HIT = 3, P_CHAO = 4, P_GLOBAL = 5, P_SUB = 6, P_SUB_HIT = 7, P_SUB_CHAO = 8;

    private ProjectileTree(Activity a, AttackView view, Navigator nav, Runnable onChanged) {
        this.a = a; this.view = view; this.nav = nav; this.onChanged = onChanged;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    static void show(Activity a, AttackView view, Navigator nav, Runnable onChanged) {
        AttackData ad = view.attackData();
        if (ad == null || ad.move == null) { I18nUi.toast(a, "Sem dados de golpe (HDAT 4).", android.widget.Toast.LENGTH_SHORT).show(); return; }
        new ProjectileTree(a, view, nav, onChanged).open();
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 12, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private void open() {
        screen = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(12), dp(10), dp(10));
        screen.setContentView(root);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(tv("Ramificação do projétil", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = tv("✕", 20, LayoutManager.TEXT, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { screen.dismiss(); } });
        h.addView(x, new LinearLayout.LayoutParams(dp(44), dp(40)));
        root.addView(h);
        ScrollView sv = new SafeScrollView(a);
        box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        sv.addView(box, new ScrollView.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(button("VOLTAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { screen.dismiss(); } }));
        screen.show();
        render();
    }

    private CharData.Move mv() { AttackData ad = view.attackData(); return ad == null ? null : ad.move; }

    private int get(CharData.Move m, int f) {
        switch (f) {
            case P_NORMAL: return m.projNormal;
            case P_ABAIXO: return m.projAbaixo;
            case P_ACIMA: return m.projAcima;
            case P_HIT: return m.projAoAcertar;
            case P_CHAO: return m.projChao;
            case P_GLOBAL: return m.projGlobal;
            case P_SUB: return m.subId;
            case P_SUB_HIT: return m.subAoAcertar;
            default: return m.subChao;
        }
    }

    private static void put(CharData.Move m, int f, int v) {
        switch (f) {
            case P_NORMAL: m.projNormal = v; break;
            case P_ABAIXO: m.projAbaixo = v; break;
            case P_ACIMA: m.projAcima = v; break;
            case P_HIT: m.projAoAcertar = v; break;
            case P_CHAO: m.projChao = v; break;
            case P_GLOBAL: m.projGlobal = v; break;
            case P_SUB: m.subId = v; break;
            case P_SUB_HIT: m.subAoAcertar = v; break;
            default: m.subChao = v; break;
        }
    }

    /** A ANO tem hitbox flag 0 (lanca projetil / sub-projetil)? */
    private boolean launches(int ano) {
        Dac dac = view.packDac(2);
        if (dac == null || ano <= 0) return false;
        Ano an = dac.getAno(ano);
        if (an == null || !an.present) return false;
        for (Ano.Mpt m : an.mpts) {
            if (m.hits == null || (m.flags & 0x10) == 0) continue;
            for (Ano.Hit h : m.hits) if (h.flag == 0) return true;
        }
        return false;
    }

    private void indentBar(LinearLayout row, int level) {
        for (int i = 0; i < level; i++) {
            View v = new View(a);
            v.setBackgroundColor(i == level - 1 ? LayoutManager.ACCENT : LayoutManager.PANEL_HI);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(3), -1);
            lp.leftMargin = dp(i == 0 ? 6 : 14);
            row.addView(v, lp);
        }
    }

    private void section(int level, String title, String note) {
        LinearLayout row = new LinearLayout(a);
        indentBar(row, level);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(10), 0, dp(2));
        col.addView(tv(title, 12, LayoutManager.ACCENT, true));
        if (note != null) col.addView(tv(note, 11, LayoutManager.DIM, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    /** No com previa. {@code field} < 0: so leitura (ANO vem de {@code ano}). */
    private void node(int level, String title, final int field, int ano, String note, boolean enabled) {
        final CharData.Move m = mv();
        if (field >= 0) ano = get(m, field);
        final int fano = ano;
        LinearLayout row = new LinearLayout(a);
        indentBar(row, level);
        LinearLayout card = new LinearLayout(a);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL);
        g.setCornerRadius(dp(10));
        if (!enabled) g.setStroke(dp(1), LayoutManager.DIM);
        card.setBackground(g);
        Ano an = view.anoAt(ano);
        boolean ok = ano > 0 && an != null && an.present;
        if (ok) {
            AnimPreview pv = new AnimPreview(a);
            pv.set(view.packDac(2), view.packSprites(2), ano);
            card.addView(pv, new LinearLayout.LayoutParams(dp(76), dp(76)));
        } else {
            TextView empty = tv(ano > 0 ? "vazia" : "—", 12, LayoutManager.DIM, false);
            empty.setGravity(Gravity.CENTER);
            card.addView(empty, new LinearLayout.LayoutParams(dp(76), dp(76)));
        }
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), 0, 0, 0);
        col.addView(tv(title, 13, enabled ? LayoutManager.TEXT : LayoutManager.DIM, true));
        col.addView(tv(ano > 0 ? "ANO " + ano : "não definido", 12, ano > 0 ? LayoutManager.ACCENT : LayoutManager.DIM, false));
        if (note != null) col.addView(tv(note, 11, LayoutManager.DIM, false));
        LinearLayout btns = new LinearLayout(a);
        btns.setPadding(0, dp(6), 0, 0);
        if (ok) {
            btns.addView(button("EDITAR", LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
                screen.dismiss();
                if (nav != null) nav.openAno(fano, true);
            } }));
        }
        if (field >= 0) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = ok ? dp(6) : 0;
            btns.addView(button(ano > 0 ? "TROCAR" : "+ DEFINIR", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { choose(field); } }), lp);
        }
        col.addView(btns);
        card.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        clp.leftMargin = dp(8);
        clp.topMargin = dp(6);
        row.addView(card, clp);
        box.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void choose(final int field) {
        CharData.Move m = mv();
        Dac dac = view.packDac(2);
        if (dac == null || m == null) return;
        AnoPicker.show(a, dac, view.packSprites(2), false, get(m, field), "Escolher ANO", true, new AnoPicker.Listener() {
            public void onPick(final int ano) {
                view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mm) { put(mm, field, ano); } });
                onChanged.run();
                render();
            }
        });
    }

    private void render() {
        box.removeAllViews();
        CharData.Move m = mv();
        if (m == null) return;
        boolean three = (m.flags & 4) != 0;
        boolean noHit = (m.flags & 1) != 0;
        TextView info = tv("Flags do golpe (GOLPE SET): 3 projéteis " + (three ? "ATIVO" : "desligado") + " · projétil não explode no inimigo "
                + (noHit ? "ATIVO" : "desligado") + (((m.flags & 32) != 0) ? " · nasce na frente do oponente" : ((m.flags & 64) != 0) ? " · nasce embaixo do oponente" : "")
                + (m.homing == 0 ? " · persegue o oponente" : "") + ".", 11, LayoutManager.DIM, false);
        info.setPadding(dp(2), dp(2), dp(2), dp(8));
        box.addView(info);

        // raiz
        node(0, "ANIM_INICIAL", -1, m.animInicial, "Os frames com hitbox flag 0 lançam o projétil.", true);
        int[] lanch = {m.animSeqChao, m.animSeqAr, m.animEndChao, m.animEndAr};
        String[] ln = {"SEQ chão", "SEQ ar", "END chão", "END ar"};
        for (int i = 0; i < 4; i++) if (lanch[i] > 0 && launches(lanch[i])) node(0, "também lança em " + ln[i], -1, lanch[i], null, true);

        section(1, "Animação do projétil", "O jogo escolhe pela altura do oponente: " + (three ? "com 3 projéteis lança ANO, ANO+1 e ANO+2." : "um projétil por hitbox flag 0."));
        proj(P_NORMAL, "Projétil (altura normal)", m, three);
        proj(P_ABAIXO, "Projétil — atacante bem abaixo do oponente", m, three);
        proj(P_ACIMA, "Projétil — atacante bem acima do oponente", m, three);

        section(1, "Reações do projétil", "Prioridade: global > chão > ao acertar. Sem animação de impacto, acertar o oponente não remove o projétil.");
        node(2, "Explosão ao acertar", P_HIT, 0, noHit ? "Desativada pela flag 1: o projétil não reage ao acertar o inimigo, só ao chão." : "Toca quando o projétil conecta no oponente.", !noHit);
        node(2, "Ao tocar o chão", P_CHAO, 0, "Toca quando o projétil chega ao chão.", true);
        node(2, "Explosão global", P_GLOBAL, 0, "Tem prioridade: toca no acerto ou no chão (só quando o atacante não está em dano).", true);

        boolean anyLaunch = launches(m.projNormal) || launches(m.projAbaixo) || launches(m.projAcima)
                || launches(m.projAoAcertar) || launches(m.projChao) || launches(m.projGlobal);
        if (m.subId != 0 || anyLaunch) {
            section(1, "Sub-projétil", "Nasce de cada hitbox flag 0 dentro da ANO do projétil. As reações dele são separadas.");
            node(2, "Sub-projétil", P_SUB, 0, null, true);
            node(3, "Sub ao acertar", P_SUB_HIT, 0, null, true);
            node(3, "Sub no chão", P_SUB_CHAO, 0, null, true);
        }
    }

    private void proj(int field, String title, CharData.Move m, boolean three) {
        node(2, title, field, 0, null, true);
        int base = get(m, field);
        if (three && base > 0) {
            node(3, "2º projétil (ANO+1)", -1, base + 1, "Lançado junto, na mesma posição.", true);
            node(3, "3º projétil (ANO+2)", -1, base + 2, "Lançado junto, na mesma posição.", true);
        }
    }
}
