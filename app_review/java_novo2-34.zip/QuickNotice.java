package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Aviso rapido sobre a preview: texto + botoes de acao nos cantos de baixo (esquerda e direita).
 * Feito para crescer: qualquer aviso ou menu de acoes rapidas monta um QuickNotice e chama AttackView.showNotice.
 * Cores e duracao sao configuraveis (durationMs 0 = fica ate ser fechado).
 */
final class QuickNotice {
    static final class Action {
        final String label;
        final Runnable run;
        /** Fecha o aviso depois de executar a acao. */
        final boolean closes;
        Action(String label, boolean closes, Runnable run) { this.label = label; this.closes = closes; this.run = run; }
    }

    static final int RED = 0xF0C62828, RED_BTN = 0xFF7F1717;
    static final int AMBER = 0xF0B26A00, AMBER_BTN = 0xFF7A4A00;
    static final int BLUE = 0xF01F5FBF, BLUE_BTN = 0xFF123F85;

    final String text;
    int color = RED, buttonColor = RED_BTN;
    long durationMs = 2000;
    final List<Action> left = new ArrayList<Action>();
    final List<Action> right = new ArrayList<Action>();

    QuickNotice(String text) { this.text = text; }

    QuickNotice colors(int bg, int btn) { color = bg; buttonColor = btn; return this; }
    QuickNotice duration(long ms) { durationMs = ms; return this; }
    QuickNotice left(String label, Runnable run) { left.add(new Action(label, true, run)); return this; }
    QuickNotice right(String label, Runnable run) { right.add(new Action(label, true, run)); return this; }
    /** Botao que executa e deixa o aviso aberto. */
    QuickNotice rightKeep(String label, Runnable run) { right.add(new Action(label, false, run)); return this; }
}
