package com.zue.attackeditor;

/**
 * Camera da previa de reacao: segue o oponente (x) e sobe/desce o cenario quando ele voa, para o corpo nao sair da area.
 * O mundo mostrado tem {@link #VIEW_W} px de largura; o chao fica a {@link #GROUND_FRAC} da altura da previa.
 * Coordenadas do jogo: y negativo = acima do chao.
 */
final class ReactionCamera {
    static final float VIEW_W = 250f, GROUND_FRAC = 0.8f, BODY = 100f, MARGIN = 12f, EASE = 0.25f;

    /** Centro horizontal do mundo mostrado e deslocamento vertical (px do mundo; > 0 = cenario desce, camera sobe). */
    float x, y;
    private final float lead;
    private boolean placed;

    /** {@code lead}: deslocamento fixo do centro em relacao ao oponente (para mostrar um pouco do lado do atacante). */
    ReactionCamera(float lead) { this.lead = lead; }

    /** Alvo de x: o oponente (mais o {@code lead}). */
    static float targetX(float oppX, float lead) { return oppX + lead; }

    /** Alvo do deslocamento vertical: 0 enquanto o corpo cabe acima do chao, senao o quanto falta para ele caber. {@code viewH} em px do mundo. */
    static float targetY(float oppY, float viewH) {
        float above = GROUND_FRAC * viewH;
        return Math.max(0f, -oppY + BODY + MARGIN - above);
    }

    /** Um passo de suavizacao (para quando chega muito perto). */
    static float ease(float cur, float tgt) {
        float d = tgt - cur;
        return Math.abs(d) < 0.25f ? tgt : cur + d * EASE;
    }

    /** Camera livre (o usuario a arrastou com dois dedos): para de seguir o oponente ate {@link #setFree}(false). */
    private boolean free;

    boolean isFree() { return free; }

    void setFree(boolean on) { free = on; }

    /** Arrasto livre da camera: {@code dx, dy} em px do mundo (o conteudo acompanha o dedo). */
    void pan(float dx, float dy) {
        free = true;
        x -= dx;
        y += dy;
        placed = true;
    }

    /** Segue o oponente; {@code snap} vai direto ao alvo (primeiro quadro e busca na linha do tempo). */
    void follow(float oppX, float oppY, float viewH, boolean snap) {
        if (free && placed) return;
        float tx = targetX(oppX, lead), ty = targetY(oppY, viewH);
        if (snap || !placed) { x = tx; y = ty; placed = true; return; }
        x = ease(x, tx);
        y = ease(y, ty);
    }

    /** O corpo (de {@code oppY - BODY} ate {@code oppY}) esta dentro da area visivel? */
    boolean contains(float oppY, float viewH) {
        float top = -GROUND_FRAC * viewH - y;           // o cenario desce y: o que se ve em cima vai mais alto no mundo
        float bottom = (1f - GROUND_FRAC) * viewH - y;
        return oppY - BODY >= top && oppY <= bottom;
    }
}
