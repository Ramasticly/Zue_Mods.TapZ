package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/**
 * Seletor visual da "proxima reacao" (COMP, coluna 11): grade de cartoes (miniatura do 1o ANO do oponente, numero e resumo da tabela) em duas abas,
 * JOGO (1-29) e PERSONAGEM (30-49), mais "NENHUMA". Tocar num cartao escolhe e fecha.
 */
final class ReactionCompPicker {
    private ReactionCompPicker() { }

    interface Listener { void onPick(int value); }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, SEL = 0xFF1E3A66;

    static void show(final Activity a, final GameData gd, final CharData cd, final Dac opDac, final SpriteCache opSprites, final int current, final String title, final Listener l) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, title, 15, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Próxima reação: para onde o jogo vai ao pousar (ou ao bater na parede, se a parede está ligada). Toque numa ação especial ou numa reação para escolher; NENHUMA deixa o jogo terminar os passos e levantar ou cair.", 11, DIM, false);
        hint.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        root.addView(hint);
        // ações especiais no topo: não apontam para uma tabela, mudam o que o jogo faz ao pousar
        TextView spTitle = SpriteListScreen.text(a, "Ações especiais", 11, DIM, true);
        spTitle.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(spTitle);
        LinearLayout specials = new LinearLayout(a);
        specials.setPadding(SpriteListScreen.dp(a, 8), 0, SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 6));
        for (int k = 0; k < ReactionSlots.COMP_SPECIAL.length; k++) {
            final int v = ReactionSlots.COMP_SPECIAL[k];
            LinearLayout cd2 = new LinearLayout(a);
            cd2.setOrientation(LinearLayout.VERTICAL);
            cd2.setPadding(SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 6));
            GradientDrawable sg = new GradientDrawable();
            boolean on = v == 50 ? current >= 50 : current == v;
            sg.setColor(on ? SEL : CARD);
            sg.setCornerRadius(SpriteListScreen.dp(a, 8));
            if (on) sg.setStroke(SpriteListScreen.dp(a, 2), ACCENT);
            cd2.setBackground(sg);
            cd2.addView(SpriteListScreen.text(a, ReactionSlots.compTitle(v), 11, TEXT, true));
            cd2.addView(SpriteListScreen.text(a, ReactionSlots.compDetail(v), 9, DIM, false));
            cd2.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { d.dismiss(); l.onPick(v); } });
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -1, 1f);
            sl.setMargins(SpriteListScreen.dp(a, 3), 0, SpriteListScreen.dp(a, 3), 0);
            specials.addView(cd2, sl);
        }
        root.addView(specials);
        final LinearLayout tabs = new LinearLayout(a);
        tabs.setPadding(SpriteListScreen.dp(a, 12), 0, SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 4));
        root.addView(tabs);
        final LinearLayout grid = new LinearLayout(a);
        grid.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final int[] tab = {current > 0 ? ReactionSlots.compTab(current) : 0};
        final Runnable[] self = new Runnable[1];
        self[0] = new Runnable() {
            @Override public void run() {
                tabs.removeAllViews();
                String[] names = {"JOGO (1-29)", "PERSONAGEM (30-49)"};
                for (int k = 0; k < 2; k++) {
                    final int kk = k;
                    TextView b = SpriteListScreen.button(a, names[k] + (tab[0] == k ? "  ●" : ""), new View.OnClickListener() { @Override public void onClick(View v) { tab[0] = kk; self[0].run(); } });
                    tabs.addView(b, SpriteListScreen.lpm(a, k == 0 ? 0 : 8));
                }
                grid.removeAllViews();
                final List<ReactionSlots.Comp> list = ReactionSlots.compCandidates(gd, cd, tab[0]);
                if (list.isEmpty()) grid.addView(SpriteListScreen.text(a, "Nenhuma reação com passos nesta aba.", 12, DIM, false));
                for (int i = 0; i < list.size(); i += 3) {
                    LinearLayout row = new LinearLayout(a);
                    for (int k = 0; k < 3; k++) {
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                        lp.setMargins(SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4));
                        if (i + k >= list.size()) { row.addView(new View(a), lp); continue; }
                        final ReactionSlots.Comp cp = list.get(i + k);
                        View cardView = card(a, cp, opDac, opSprites, cp.value == current, gd, cd);
                        cardView.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); l.onPick(cp.value); } });
                        row.addView(cardView, lp);
                    }
                    grid.addView(row);
                }
            }
        };
        LinearLayout foot = new LinearLayout(a);
        foot.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 12));
        foot.addView(SpriteListScreen.button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        foot.addView(SpriteListScreen.button(a, "NENHUMA" + (current == 0 ? "  ●" : ""), new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); l.onPick(0); } }), SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        d.show();
        self[0].run();
    }

    private static View card(final Activity a, final ReactionSlots.Comp cp, Dac dac, SpriteCache sprites, boolean selected, final GameData gd, final CharData cd) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(selected ? SEL : CARD);
        g.setCornerRadius(SpriteListScreen.dp(a, 8));
        if (selected) g.setStroke(SpriteListScreen.dp(a, 2), ACCENT);
        c.setBackground(g);
        Ano ano = dac == null || cp.firstAno < 0 ? null : dac.getAno(cp.firstAno);
        android.widget.FrameLayout thumb = new android.widget.FrameLayout(a);
        if (ano != null && ano.present) {
            AnimPreview pv = new AnimPreview(a);
            pv.set(dac, sprites, cp.firstAno);
            thumb.addView(pv, new android.widget.FrameLayout.LayoutParams(SpriteListScreen.dp(a, 72), SpriteListScreen.dp(a, 72)));
        } else {
            TextView e = SpriteListScreen.text(a, "sem animação", 10, DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            thumb.addView(e, new android.widget.FrameLayout.LayoutParams(SpriteListScreen.dp(a, 72), SpriteListScreen.dp(a, 72)));
        }
        InfoBubble.attach(a, thumb, new View.OnClickListener() { @Override public void onClick(View v) {
            ReactionTable t = cp.charSrc ? (cd == null ? null : cd.reaction(cp.value - 30)) : (gd == null ? null : gd.reaction(cp.value));
            InfoBubble.showReaction(a, cp.value, t, new ReactionWallInfo.Lookup() {
                @Override public ReactionTable game(int type) { return gd == null ? null : gd.reaction(type); }
                @Override public ReactionTable chr(int index) { return cd == null ? null : cd.reaction(index); }
            });
        } });
        c.addView(thumb, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 72), SpriteListScreen.dp(a, 72)));
        TextView l = SpriteListScreen.text(a, (cp.charSrc ? "Personagem " + (cp.value - 30) : "Jogo " + cp.value) + "  (" + cp.value + ")", 11, TEXT, true);
        l.setGravity(Gravity.CENTER);
        c.addView(l);
        TextView s = SpriteListScreen.text(a, cp.summary, 9, DIM, false);
        s.setGravity(Gravity.CENTER);
        c.addView(s);
        return c;
    }
}
