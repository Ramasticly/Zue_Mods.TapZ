package com.zue.attackeditor;

/** Regras puras das edicoes da timeline de reacoes (arrastar a duracao de um passo). */
final class ReactionEdit {
    private ReactionEdit() { }

    /** Colunas da tabela: duracao no chao, duracao no ar. */
    static final int COL_DUR_GROUND = 0, COL_DUR_AIR = 1;
    /** 255 e o "ate pousar" (no ar) / limite do jogo: a alca de arrastar fica travada. */
    static final int OPEN = 255;
    static final int MIN_DUR = 1, MAX_DUR = 254;

    /** Coluna de duracao do cenario. */
    static int durColumn(boolean air) { return air ? COL_DUR_AIR : COL_DUR_GROUND; }

    /** O passo pode ter a duracao arrastada no cenario (existe e nao e o 255)? */
    static boolean canResize(ReactionTable t, int row, boolean air) {
        return t != null && row >= 0 && row < t.rows && t.u8(row, durColumn(air)) != OPEN;
    }

    /** Duracao nova (ticks) ao arrastar a borda do passo {@code dxPx} pixels com {@code pxPerTick}; limitada a 1..254. */
    static int dragged(int baseDur, float dxPx, float pxPerTick) {
        int delta = Math.round(dxPx / Math.max(0.01f, pxPerTick));
        return Math.max(MIN_DUR, Math.min(MAX_DUR, baseDur + delta));
    }

    /** {coluna, valor} a gravar para a duracao {@code ticks} (ja limitada) do passo no cenario; null se nao da. */
    static int[] resize(ReactionTable t, int row, boolean air, int ticks) {
        if (!canResize(t, row, air)) return null;
        int v = Math.max(MIN_DUR, Math.min(MAX_DUR, ticks));
        return new int[]{durColumn(air), v};
    }
}
