package com.zue.attackeditor;

/** Regras puras das edicoes da timeline de reacoes (arrastar a duracao de um passo). */
final class ReactionEdit {
    private ReactionEdit() { }

    /** Colunas da tabela: duracao no chao, duracao no ar. */
    static final int COL_DUR_GROUND = 0, COL_DUR_AIR = 1;
    /** 255 e o "ate pousar" (no ar) / limite do jogo: a alca de arrastar fica travada. */
    static final int OPEN = 255;
    static final int MIN_DUR = 1, MAX_DUR = 254;

    /** Coluna de duracao do cenario. */
    static int durColumn(boolean air) { return air ? COL_DUR_AIR : COL_DUR_GROUND; }

    /** O passo pode ter a duracao arrastada no cenario (existe e nao e o 255)? */
    static boolean canResize(ReactionTable t, int row, boolean air) {
        return t != null && row >= 0 && row < t.rows && t.u8(row, durColumn(air)) != OPEN;
    }

    /** Duracao nova (ticks) ao arrastar a borda do passo {@code dxPx} pixels com {@code pxPerTick}; limitada a 1..254. */
    static int dragged(int baseDur, float dxPx, float pxPerTick) {
        int delta = Math.round(dxPx / Math.max(0.01f, pxPerTick));
        return Math.max(MIN_DUR, Math.min(MAX_DUR, baseDur + delta));
    }

    /** {coluna, valor} a gravar para a duracao {@code ticks} (ja limitada) do passo no cenario; null se nao da. */
    static int[] resize(ReactionTable t, int row, boolean air, int ticks) {
        if (!canResize(t, row, air)) return null;
        int v = Math.max(MIN_DUR, Math.min(MAX_DUR, ticks));
        return new int[]{durColumn(air), v};
    }

    /**
     * DIVIDIR: parte o passo {@code row} em dois, a {@code k} ticks do inicio (no cenario atual). O 1o passo dura {@code k}, o 2o o resto (o 255 "ate pousar" fica no 2o);
     * a duracao do outro cenario e repartida na mesma proporcao. O 2o passo mantem (-1) a velocidade e a voz toca so no 1o; o ANO recomeca no 2o
     * (cada passo reinicia a animacao do oponente). Devolve false se {@code k} nao cabe no passo.
     */
    static boolean split(ReactionTable t, int row, boolean air, int k) {
        if (t == null || row < 0 || row >= t.rows) return false;
        int dc = durColumn(air), oc = durColumn(!air);
        int d = t.u8(row, dc), o = t.u8(row, oc);
        if (k < MIN_DUR || (d == OPEN ? k > MAX_DUR : k >= d)) return false;
        int oa = o, ob = o;
        if (o != OPEN) {
            double ratio = d == OPEN ? 0.5 : k / (double) d;
            oa = Math.max(MIN_DUR, Math.min(MAX_DUR, (int) Math.round(o * ratio)));
            ob = Math.max(MIN_DUR, Math.min(MAX_DUR, o - oa));
        }
        t.duplicateRow(row);
        t.set(row, dc, k);
        t.set(row + 1, dc, d == OPEN ? OPEN : d - k);
        t.set(row, oc, oa);
        t.set(row + 1, oc, ob);
        for (int c : new int[]{3, 4, 7, 8}) t.set(row + 1, c, -1);
        t.set(row + 1, 13, 0);
        return true;
    }

    /** Velocidade da simulacao (x/128 px por tick) em unidades da tabela (1 = 0,1 px por tick), presa a -128..127. */
    static int carryUnits(int fixed) { return Math.max(-128, Math.min(127, Math.round(fixed * 10f / 128f))); }

    /**
     * {@link #split} que preserva o movimento: com aceleracao no passo, o -1 do 2o passo manteria so a velocidade de partida (a aceleracao recomeca),
     * entao o 2o passo recebe a velocidade em que o 1o terminou ({@code endOfFirst}: o estado do tick {@code k-1} da simulacao, mais a aceleracao daquele tick). Sem aceleracao, igual a {@link #split}.
     */
    static boolean splitKeepingMotion(ReactionTable t, int row, boolean air, int k, BattleSim.DamageTick endOfFirst) {
        if (t == null || row < 0 || row >= t.rows) return false;
        int b = air ? 7 : 3;
        boolean accel = t.s8(row, b + 2) != 0 || t.s8(row, b + 3) != 0;
        if (!split(t, row, air, k)) return false;
        if (accel && endOfFirst != null) {
            // a velocidade mostrada no tick k-1 ainda nao inclui a aceleracao desse tick: o 2o passo ja parte com ela somada
            t.set(row + 1, b, Math.max(-128, Math.min(127, carryUnits(endOfFirst.xs) + Math.max(-127, t.s8(row, b + 2)))));
            t.set(row + 1, b + 1, Math.max(-128, Math.min(127, carryUnits(endOfFirst.ys) + Math.max(-127, t.s8(row, b + 3)))));
        }
        return true;
    }
}
