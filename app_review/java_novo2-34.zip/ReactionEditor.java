package com.zue.attackeditor;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Editor dos passos de uma reacao: cada passo (linha de 14 bytes da tabela) e um bloco com a animacao do oponente.
 * Tabelas do char do atacante sao editaveis; as do gamedata sao fixas (so visualizacao).
 */
final class ReactionEditor {
    private static final String[] COLS = {"duracao no chao", "duracao no ar (255 = ate cair)", "ANO do oponente (negativo = vira)",
            "chao: veloc. x", "chao: veloc. y", "chao: acel. x", "chao: acel. y",
            "ar: veloc. x", "ar: veloc. y", "ar: acel. x", "ar: acel. y",
            "proxima reacao (0 = nenhuma)", "parede", "voz"};
    private static final boolean[] SIGNED = {false, false, true, true, true, true, true, true, true, true, true, false, false, false};

    private final Context c;
    private final AttackView view;
    private final Runnable onChanged;
    private final boolean editable;
    private final int type;          // 0..29 gamedata ou 0..19 char
    private final float d;
    private Dialog dlg;
    private LinearLayout stripBox, fields;
    private ReactionPreview player;
    private int sel;

    ReactionEditor(Context c, AttackView view, int optIndex, Runnable onChanged) {
        this.c = c;
        this.view = view;
        this.onChanged = onChanged;
        this.editable = optIndex >= 30;
        this.type = optIndex >= 30 ? optIndex - 30 : optIndex;
        this.d = c.getResources().getDisplayMetrics().density;
    }

    private int dp(int v) { return Math.round(v * d); }

    private ReactionTable table() {
        if (editable) return view.charReaction(type);
        return view.gameReaction(type);
    }

    void show() {
        if (table() == null) return;
        dlg = new Dialog(c, android.R.style.Theme_DeviceDefault_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(30), dp(10), dp(10));
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView tt = new TextView(c);
        tt.setText(editable ? "Reacao do personagem " + type + "  ·  editavel" : "Reacao do jogo " + type + "  ·  fixa (so leitura)");
        tt.setTextColor(LayoutManager.TEXT);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        if (editable) head.addView(btn("DESFAZER", false, new View.OnClickListener() { public void onClick(View v) {
            if (view.undoEdit()) { sel = Math.min(sel, table().rows - 1); rebuild(); onChanged.run(); }
        } }));
        head.addView(btn("FECHAR", true, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }));
        root.addView(head);
        ScrollView sv = new ScrollView(c);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        sv.addView(col);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout top = new LinearLayout(c);
        top.setGravity(Gravity.CENTER_VERTICAL);
        player = new ReactionPreview(c, view);
        player.setValue(editable ? 30 + type : type);
        top.addView(player, new LinearLayout.LayoutParams(dp(150), dp(150)));
        LinearLayout side = new LinearLayout(c);
        side.setOrientation(LinearLayout.VERTICAL);
        side.addView(btn("↻ REPETIR", false, new View.OnClickListener() { public void onClick(View v) { player.replay(); } }));
        TextView hint = new TextView(c);
        hint.setText("A previa mostra o oponente recebendo esta reacao. Cada bloco abaixo e um passo (uma animacao do oponente).");
        hint.setTextColor(LayoutManager.DIM);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        hint.setPadding(dp(6), dp(4), dp(4), 0);
        side.addView(hint);
        top.addView(side, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(top);

        HorizontalScrollView hs = new HorizontalScrollView(c);
        stripBox = new LinearLayout(c);
        stripBox.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(stripBox);
        col.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        fields = new LinearLayout(c);
        fields.setOrientation(LinearLayout.VERTICAL);
        col.addView(fields);
        dlg.setContentView(root);
        dlg.show();
        sel = 0;
        rebuild();
    }

    private void rebuild() {
        final ReactionTable t = table();
        stripBox.removeAllViews();
        fields.removeAllViews();
        if (t == null) return;
        if (sel >= t.rows) sel = t.rows - 1;
        for (int r = 0; r < t.rows; r++) {
            final int row = r;
            int ano = t.s8(r, 2);
            int dur = t.u8(r, 0);
            LinearLayout blk = new LinearLayout(c);
            blk.setOrientation(LinearLayout.VERTICAL);
            blk.setGravity(Gravity.CENTER_HORIZONTAL);
            blk.setPadding(dp(3), dp(3), dp(3), dp(3));
            GradientDrawable g = new GradientDrawable();
            g.setColor(r == sel ? 0xFF1E3A66 : 0xFF1B2029);
            g.setCornerRadius(dp(6));
            blk.setBackground(g);
            AnimPreview pv = new AnimPreview(c);
            pv.set(view.opponentDac(), view.opponentSprites(), Math.abs(ano), ano < 0);
            blk.addView(pv, new LinearLayout.LayoutParams(dp(72), dp(72)));
            blk.addView(label("passo " + (r + 1), LayoutManager.TEXT, 10));
            blk.addView(label("ANO " + Math.abs(ano) + (ano < 0 ? " ⇄" : ""), LayoutManager.DIM, 10));
            blk.addView(label(dur == 255 ? "∞" : ObjModel.seconds(dur), LayoutManager.DIM, 10));
            blk.setClickable(true);
            blk.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sel = row; rebuild(); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Math.max(dp(84), Math.min(dp(160), dp(84) + dur * dp(1))), -2);
            lp.setMargins(dp(2), dp(4), dp(2), dp(4));
            stripBox.addView(blk, lp);
        }
        if (editable) {
            TextView add = btn("＋ passo", true, new View.OnClickListener() { public void onClick(View v) {
                final int after = sel;
                view.editReaction(type, new Runnable() { public void run() { t.insertRow(after); } });
                sel = after + 1;
                rebuild();
                player.replay();
                onChanged.run();
            } });
            stripBox.addView(add);
        }
        // campos do passo selecionado
        TextView h = label("Passo " + (sel + 1) + " de " + t.rows, LayoutManager.TEXT, 12);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(dp(4), dp(10), 0, dp(2));
        fields.addView(h);
        for (int k = 0; k < ReactionTable.STRIDE; k++) {
            int v = SIGNED[k] ? t.s8(sel, k) : t.u8(sel, k);
            fields.addView(field(k, v));
        }
        if (editable) {
            LinearLayout b = new LinearLayout(c);
            b.addView(btn("✕ remover este passo", false, new View.OnClickListener() { public void onClick(View v) {
                if (t.rows <= 1) return;
                final int at = sel;
                view.editReaction(type, new Runnable() { public void run() { t.removeRow(at); } });
                rebuild();
                player.replay();
                onChanged.run();
            } }));
            fields.addView(b);
        }
        TextView note = label("Velocidades em unidades do jogo (1 = 0,1 px por tick; -1 mantem, -2 reduz pela metade). A proxima reacao: 1-29 usa o gamedata, 30-49 usa as do personagem.", LayoutManager.DIM, 10);
        note.setPadding(dp(4), dp(8), dp(4), dp(24));
        fields.addView(note);
    }

    private TextView label(String s, int color, int sp) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private View field(final int col, int value) {
        LinearLayout l = new LinearLayout(c);
        l.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = new TextView(c);
        n.setText(COLS[col]);
        n.setTextColor(LayoutManager.DIM);
        n.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        l.addView(n, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!editable) {
            TextView v = new TextView(c);
            v.setText(String.valueOf(value));
            v.setTextColor(LayoutManager.TEXT);
            v.setTypeface(Typeface.MONOSPACE);
            l.addView(v, new LinearLayout.LayoutParams(dp(90), -2));
            return l;
        }
        final EditText et = new EditText(c);
        et.setText(String.valueOf(value));
        et.setTextColor(LayoutManager.TEXT);
        et.setTypeface(Typeface.MONOSPACE);
        et.setSingleLine(true);
        et.setGravity(Gravity.CENTER);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        final int[] cur = {value};
        final Runnable commit = new Runnable() { public void run() {
            int v;
            try { v = Integer.parseInt(et.getText().toString().trim()); } catch (NumberFormatException e) { et.setText(String.valueOf(cur[0])); return; }
            v = SIGNED[col] ? Math.max(-128, Math.min(127, v)) : Math.max(0, Math.min(255, v));
            if (v == cur[0]) return;
            cur[0] = v;
            apply(col, v);
        } };
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int a, android.view.KeyEvent k) { commit.run(); return false; } });
        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean has) { if (!has) commit.run(); } });
        View bm = btn("−", false, null);
        Hold.attach(bm, new Runnable() { public void run() { cur[0] -= 1; et.setText(String.valueOf(cur[0])); commit2(col, cur[0]); } });
        l.addView(bm);
        l.addView(et, new LinearLayout.LayoutParams(dp(70), -2));
        View bp = btn("+", false, null);
        Hold.attach(bp, new Runnable() { public void run() { cur[0] += 1; et.setText(String.valueOf(cur[0])); commit2(col, cur[0]); } });
        l.addView(bp);
        return l;
    }

    private void commit2(int col, int v) {
        v = SIGNED[col] ? Math.max(-128, Math.min(127, v)) : Math.max(0, Math.min(255, v));
        apply(col, v);
    }

    private void apply(final int col, final int v) {
        final ReactionTable t = table();
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.set(row, col, v); } });
        onChanged.run();
        if (col == 2 || col == 0 || col == 1) rebuild();
        player.replay();
    }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(p);
        return t;
    }
}
