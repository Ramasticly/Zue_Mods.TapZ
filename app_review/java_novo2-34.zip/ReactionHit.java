package com.zue.attackeditor;

/**
 * Previa da reacao no golpe real: acha o tick em que o hit que usa a reacao editada acontece. A previa e a timeline comecam um tick antes (o proximo
 * {@code step()} aplica o hit e roda o 1o tick da reacao), entao o tick 0 da timeline e o tick desse hit; com {@link BattleSim#setHoldAttackerAtHit} o atacante
 * fica no frame da hitbox. Java puro.
 */
final class ReactionHit {
    private ReactionHit() { }

    /** Limite de ticks ate o golpe acertar (um golpe longo com varios hits e a aproximacao cabem folgados). */
    static final int MAX_TICKS = 900;

    /** Ticks ate nada mais animar ({@link BattleSim#reactionQuiet}), no maximo {@code maxTicks}: o fim da previa quando o golpe nao acerta. */
    static int ticksUntilQuiet(BattleSim sim, int maxTicks) {
        for (int i = 1; i <= maxTicks; i++) {
            sim.step();
            if (sim.reactionQuiet()) return i;
        }
        return maxTicks;
    }

    /**
     * Anda {@code probe} ate entrar no estado de dano da reacao {@code type}/{@code charSrc}. Devolve quantos ticks devem ser andados num sim NOVO para ficar
     * logo ANTES do tick do hit (o proximo step aplica o hit), ou -1 se o golpe nao acerta assim em {@code maxTicks}. O probe fica no estado depois do hit.
     */
    static int ticksBeforeHit(BattleSim probe, int type, boolean charSrc, int maxTicks) {
        for (int i = 1; i <= maxTicks; i++) {
            probe.step();
            BattleSim.DamageTick t = probe.damageTick();
            if (t.active && t.type == type && t.charSrc == charSrc) return i - 1;
        }
        return -1;
    }
}
