package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Geometria da timeline de reacoes (em dp), a mesma da timeline principal: regua 14, faixa de clipes 40, resumo 10, linha 22, teto 188.
 * Java puro: o desenho e o toque da {@link ReactionTimelineView} usam as mesmas linhas, entao o que se ve e o que se toca nunca discordam.
 */
final class ReactionLayout {
    private ReactionLayout() { }

    /** Faixas: clipes (passos) e as que abrem sob demanda (SPEED X e SPEED Y separadas, como a Velocidade X / Y da timeline principal). */
    static final int L_CLIP = 0, L_SPEEDX = 1, L_SPEEDY = 2, L_VOZ = 3, L_EFEITOS = 4, L_SEQ = 5;
    static final int LANES = 6;
    /** Rotulos da coluna da esquerda, por faixa. */
    static final String[] NAMES = {"PASSOS", "SPEED X", "SPEED Y", "VOZ", "EFEITOS", "SEQ"};
    /** Filtro "#" (as faixas abaixo dos clipes): indice = faixa - 1. */
    static final String[] FILTER_NAMES = {"Speed X", "Speed Y", "Voz", "Efeitos (parede)", "Seq (próxima reação)"};

    static final float RULER = 14, CLIP = 40, SUMMARY = 10, ROW = 22, CAP = 188, PAD = 3;

    static final class Row {
        final int lane;
        final boolean summary;
        final float h;
        /** 0 = a primeira linha da faixa; 1, 2... = linhas extras quando ha itens sobrepostos na mesma faixa ("VOZ 2"). */
        int sub;
        float top;                // relativo ao topo da view, ja descontada a rolagem

        Row(int lane, boolean summary, float h) {
            this.lane = lane;
            this.summary = summary;
            this.h = h;
        }
    }

    /**
     * Linhas abaixo dos clipes. So aparece faixa COM dados ({@code has[faixa]}), como na timeline principal; para criar um elemento: aba ＋. Aberta: uma linha
     * (22) por faixa, mais uma por cada item sobreposto na mesma faixa ({@code count[faixa]} linhas, ver {@link #stack}); fechada: uma linha de resumo (10).
     * {@code show[i]}: faixa i+1 ligada no filtro.
     */
    static List<Row> body(boolean[] show, boolean expanded, boolean[] has, int[] count) {
        List<Row> out = new ArrayList<Row>();
        for (int lane = L_SPEEDX; lane <= L_SEQ; lane++) {
            if (!show[lane - 1] || !has[lane]) continue;
            if (!expanded) { out.add(new Row(lane, true, SUMMARY)); continue; }
            int n = count == null || lane >= count.length ? 1 : Math.max(1, count[lane]);
            for (int k = 0; k < n; k++) { Row r = new Row(lane, false, ROW); r.sub = k; out.add(r); }
        }
        return out;
    }

    static List<Row> body(boolean[] show, boolean expanded, boolean[] has) { return body(show, expanded, has, null); }

    /** Distribui itens {@code {inicio, fim}} (fim exclusivo, em ticks) em linhas da mesma faixa: itens que se sobrepoem vao para a linha de baixo. Devolve a linha de cada um. */
    static int[] stack(int[][] spans) {
        int[] line = new int[spans.length];
        java.util.ArrayList<Integer> ends = new java.util.ArrayList<Integer>();
        for (int i = 0; i < spans.length; i++) {
            int k = 0;
            while (k < ends.size() && ends.get(k).intValue() > spans[i][0]) k++;
            if (k == ends.size()) ends.add(Integer.valueOf(spans[i][1])); else ends.set(k, Integer.valueOf(spans[i][1]));
            line[i] = k;
        }
        return line;
    }

    static float bodyTop() { return RULER + CLIP; }

    static float contentH(List<Row> rows) {
        float h = 0;
        for (Row r : rows) h += r.h;
        return h;
    }

    /** Altura da view: regua + clipes + linhas, ate o teto {@code cap} (a view rola por dentro). */
    static float viewH(List<Row> rows, float cap) { return Math.min(cap, bodyTop() + contentH(rows) + PAD); }

    static float maxScroll(List<Row> rows, float viewH) { return Math.max(0, contentH(rows) - (viewH - bodyTop())); }

    static float clampScroll(List<Row> rows, float viewH, float scroll) { return Math.max(0, Math.min(maxScroll(rows, viewH), scroll)); }

    /** Poe o {@code top} de cada linha (rolagem em dp). */
    static void place(List<Row> rows, float scroll) {
        float y = bodyTop() - scroll;
        for (Row r : rows) {
            r.top = y;
            y += r.h;
        }
    }

    /** Faixa na altura {@code y} (dp): clipes, uma linha do corpo ou -1 (regua / fora). Linhas rolaram para baixo da regua nao contam. */
    static int laneAt(List<Row> rows, float y) {
        if (y < RULER) return -1;
        if (y < bodyTop()) return L_CLIP;
        for (Row r : rows) if (y >= r.top && y < r.top + r.h) return r.lane;
        return -1;
    }

    /** A linha do corpo na altura {@code y} (dp), com a sub-linha {@code sub}; null se nenhuma. */
    static Row rowAt(List<Row> rows, float y) {
        if (y < bodyTop()) return null;
        for (Row r : rows) if (y >= r.top && y < r.top + r.h) return r;
        return null;
    }

    /** O passo (indice na tabela) cujo trecho {@code [start, end)} contem {@code tick}; -1 se nenhum. {@code segs[i] = {start, end, row}}. */
    static int rowAtTick(int[][] segs, int tick) {
        for (int[] s : segs) if (tick >= s[0] && tick < s[1]) return s[2];
        return -1;
    }
}
