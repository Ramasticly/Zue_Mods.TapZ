package com.zue.attackeditor;

/** Estado da grade "Escolher reacao" (Java puro): qual cartao esta destacado, se mudou e qual toca som (so o destacado). */
final class ReactionPickState {
    final int group, initial;
    private int sel;

    /** {@code value} = OPT 1 atual do hit (grupo * 50 + indice da reacao). */
    ReactionPickState(int value) {
        group = Math.max(0, Math.min(4, value / 50));
        initial = value >= 0 ? value % 50 : 0;
        sel = initial;
    }

    void select(int index) { sel = index; }
    int selected() { return sel; }
    boolean audible(int index) { return index == sel; }
    boolean changed() { return sel != initial; }
    /** OPT 1 a gravar ao confirmar. */
    int result() { return group * 50 + sel; }
}
