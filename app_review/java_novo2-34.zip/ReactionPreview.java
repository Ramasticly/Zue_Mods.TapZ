package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
import java.util.List;

/** Miniplayer: o oponente recebe um OPT 1 (reacao) e a animacao toca em laco. Cria a simulacao so quando aparece. */
final class ReactionPreview extends View {
    private final AttackView av;
    private final AttackRenderer renderer = new AttackRenderer();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private BattleSim sim;
    private int value = -1;
    private long last;
    private double acc;
    private int age, idle;
    private int centerX;

    ReactionPreview(Context c, AttackView av) {
        super(c);
        this.av = av;
        p.setTextSize(10f * c.getResources().getDisplayMetrics().density);
        p.setTextAlign(Paint.Align.CENTER);
    }

    void setValue(int v) {
        value = v;
        sim = null;
        invalidate();
    }

    private int ovSlot = -1;
    private ReactionTable ovTable;
    private boolean paused;
    private float speed = 1f;

    /** Velocidade da reproducao (1 = normal). */
    void setSpeed(float s) { speed = s; }

    /** A previa toca {@code t} como se estivesse no slot {@code slot} do personagem (candidata a entrar num slot vazio). */
    void setOverride(int slot, ReactionTable t) {
        ovSlot = t == null ? -1 : slot;
        ovTable = t;
        sim = null;
        invalidate();
    }

    /** Pausa/retoma o laco automatico (modo nao controlado). */
    void setPaused(boolean p) { paused = p; if (!p) { last = 0; acc = 0; } invalidate(); }
    boolean isPaused() { return paused; }

    void replay() { sim = null; tick = 0; invalidate(); }

    // ---- modo controlado (editor de reacoes): o tick e o play vem de fora; nada de laco automatico ----
    /** Altura do oponente no cenario "ar" (px). */
    static final int AIR_HEIGHT = 60;
    private boolean controlled, air, playing;
    private int tick, target, maxTick = Integer.MAX_VALUE;
    private Runnable onTick;

    void setControlled(boolean on) { controlled = on; sim = null; tick = 0; invalidate(); }
    void setAir(boolean on) { if (air != on) { air = on; sim = null; tick = 0; invalidate(); } }
    void setMaxTick(int n) { maxTick = Math.max(0, n); }
    void setOnTick(Runnable r) { onTick = r; }
    boolean isPlaying() { return playing; }
    int tickNow() { return tick; }

    /** Mostra o estado depois de {@code t} ticks (para o play). */
    void seek(int t) { target = Math.max(0, Math.min(maxTick, t)); playing = false; invalidate(); }

    void play() {
        if (target >= maxTick) target = 0;
        playing = true;
        last = 0;
        acc = 0;
        invalidate();
    }

    void pause() { playing = false; }

    private void build() {
        int oldH = BattleSim.oppHeightPx;
        if (controlled && air) BattleSim.oppHeightPx = AIR_HEIGHT;
        else if (controlled) BattleSim.oppHeightPx = 0;
        try { sim = av.newReactionSim(); }
        finally { BattleSim.oppHeightPx = oldH; }
        tick = 0;
        age = 0;
        idle = 0;
        last = 0;
        acc = 0;
        if (sim == null) return;
        if (ovTable != null) sim.overrideCharReaction(ovSlot, ovTable);
        sim.forceHit(value);
        centerX = sim.opponentX() + (sim.attackerX() < sim.opponentX() ? 30 : -30);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D0F13);
        if (sim == null) build();
        if (sim == null) {
            p.setColor(0xFF4A505E);
            I18nUi.drawText(c, "sem dados", getWidth() / 2f, getHeight() / 2f, p);
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (last == 0) last = now;
        acc += (now - last) / (1000.0 / AttackSim.TICKS_PER_SECOND) * speed;
        last = now;
        int steps = 0;
        if (controlled) {
            if (playing) {
                while (acc >= 1 && target < maxTick) { acc -= 1; target++; }
                if (target >= maxTick) playing = false;
                if (onTick != null) onTick.run();
            } else acc = 0;
            if (target < tick) { build(); if (sim == null) return; }
            int guard = 0;
            while (tick < target && guard++ < 600) { sim.step(); tick++; }
            drawWorld(c);
            if (playing) postInvalidateOnAnimation();
            return;
        }
        if (paused) { acc = 0; drawWorld(c); return; }
        while (acc >= 1 && steps < 6) {
            acc -= 1;
            steps++;
            sim.step();
            age++;
            if (!sim.defenderInDamage()) idle++;
            if (idle > 30 || age > 420) { build(); break; }
        }
        drawWorld(c);
        postInvalidateOnAnimation();
    }

    private void drawWorld(Canvas c) {
        float s = getWidth() / 250f;
        c.save();
        c.translate(getWidth() / 2f - centerX * s, getHeight() * 0.8f);
        c.scale(s, s);
        p.setColor(0xFF2A3A55);
        c.drawRect(centerX - 400, 0, centerX + 400, 2 / s, p);
        List<BattleSim.Layer> ls = sim.layers();
        for (int i = 0; i < ls.size(); i++) {
            BattleSim.Layer l = ls.get(i);
            if (l.owner == BattleSim.OWNER_ATTACKER) continue;
            renderer.drawLayer(c, l, av.spritesForOwner(l.owner));
        }
        c.restore();
    }
}
