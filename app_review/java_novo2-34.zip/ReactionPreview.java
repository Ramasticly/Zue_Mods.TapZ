package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
import java.util.List;

/** Miniplayer: o oponente recebe um OPT 1 (reacao) e a animacao toca em laco. Cria a simulacao so quando aparece. */
final class ReactionPreview extends View {
    private final AttackView av;
    private final AttackRenderer renderer = new AttackRenderer();
    private final AttackRenderer.Options boxes = new AttackRenderer.Options();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private BattleSim sim;
    private int value = -1;
    private long last;
    private double acc;
    private int age, idle;
    private ReactionCamera cam = new ReactionCamera(0);
    private boolean sound, snapCam = true;

    ReactionPreview(Context c, AttackView av) {
        super(c);
        this.av = av;
        p.setTextSize(10f * c.getResources().getDisplayMetrics().density);
        p.setTextAlign(Paint.Align.CENTER);
    }

    void setValue(int v) {
        value = v;
        sim = null;
        invalidate();
    }

    private int ovSlot = -1;
    private ReactionTable ovTable;
    private boolean paused;
    private float speed = 1f;

    /** Liga o som da previa (voz e sons da reacao); as pequenas das grades ficam mudas. */
    void setSound(boolean on) { sound = on; }

    private void playSounds() {
        List<BattleSim.Snd> l = sim.drainSounds();
        if (sound && isShown() && !l.isEmpty()) av.playSounds(l);
    }

    /** Velocidade da reproducao (1 = normal). */
    void setSpeed(float s) { speed = s; }

    /** A previa toca {@code t} como se estivesse no slot {@code slot} do personagem (candidata a entrar num slot vazio). */
    void setOverride(int slot, ReactionTable t) {
        ovSlot = t == null ? -1 : slot;
        ovTable = t;
        sim = null;
        invalidate();
    }

    /** Pausa/retoma o laco automatico (modo nao controlado). */
    void setPaused(boolean p) { paused = p; if (!p) { last = 0; acc = 0; } invalidate(); }
    boolean isPaused() { return paused; }

    void replay() { sim = null; tick = 0; invalidate(); }

    // ---- modo controlado (editor de reacoes): o tick e o play vem de fora; nada de laco automatico ----
    /** Altura do oponente no cenario "ar" (px). */
    static final int AIR_HEIGHT = 60;
    private boolean controlled, air, playing;
    private int tick, target, maxTick = Integer.MAX_VALUE;
    private Runnable onTick;

    void setControlled(boolean on) { controlled = on; sim = null; tick = 0; invalidate(); }
    void setAir(boolean on) { if (air != on) { air = on; sim = null; tick = 0; invalidate(); } }

    /** Contexto do golpe real: o frame da hitbox ({@code ano}, {@code pat}) e a reacao editada. A previa recomeca do tick 0. */
    void setContext(int ano, int pat, int type, boolean charSrc) {
        ctxAno = ano; ctxPat = pat; hitType = type; hitChar = charSrc;
        rebuildNow();
    }
    private int ctxAno, ctxPat, hitType = -1;
    private boolean hitChar, hit;
    private int quiet;

    /** O golpe real acertou a reacao editada nesta posicao? (false = sem hit: atacante parado, oponente no idle) */
    boolean hit() { return hit; }
    /** Sem hit: ticks ate nada mais animar (o fim da previa). */
    int quietTicks() { return quiet; }
    /** A simulacao atual (null ate a 1a vez que desenha). */
    BattleSim sim() { return sim; }

    private void rebuildNow() { sim = null; tick = 0; invalidate(); }

    // camera igual a da principal: NORMAL (1 dedo arrasta, pinca da zoom), TELA e CHAR (automaticos)
    private int camMode = CameraModes.CHAR;
    private float originX, originY, scale = 1f;
    private boolean viewSet;
    private Runnable onCamMode;
    private float lastX, lastY;
    private android.view.ScaleGestureDetector scaler;
    private boolean scaling, panned;

    int cameraMode() { return camMode; }
    void setCameraMode(int m) { camMode = m; viewSet = false; invalidate(); }
    /** Chamado quando o usuario mexe na camera com os dedos (o modo vira NORMAL). */
    void setOnCameraMode(Runnable r) { onCamMode = r; }
    void setMaxTick(int n) { maxTick = Math.max(0, n); }
    void setOnTick(Runnable r) { onTick = r; }
    boolean isPlaying() { return playing; }
    int tickNow() { return tick; }

    /** Mostra o estado depois de {@code t} ticks (para o play). */
    void seek(int t) { target = Math.max(0, Math.min(maxTick, t)); playing = false; invalidate(); }

    void play() {
        if (target >= maxTick) target = 0;
        playing = true;
        last = 0;
        acc = 0;
        invalidate();
    }

    void pause() { playing = false; }

    private void build() {
        hit = false;
        quiet = 0;
        if (controlled && hitType >= 0) {
            AttackView.ReactionRun run = av.newReactionRun(ctxAno, ctxPat, hitType, hitChar);
            sim = run.sim;
            hit = run.hit;
            quiet = run.quietTicks;
        } else {
            int oldH = BattleSim.oppHeightPx;
            if (controlled && air) BattleSim.oppHeightPx = AIR_HEIGHT;
            else if (controlled) BattleSim.oppHeightPx = 0;
            try { sim = av.newReactionSim(); }
            finally { BattleSim.oppHeightPx = oldH; }
        }
        tick = 0;
        age = 0;
        idle = 0;
        last = 0;
        acc = 0;
        if (sim == null) return;
        if (ovTable != null) sim.overrideCharReaction(ovSlot, ovTable);
        if (!controlled) sim.forceHit(value);
        cam = new ReactionCamera(sim.attackerX() < sim.opponentX() ? 30 : -30);
        snapCam = true;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D0F13);
        if (sim == null) build();
        if (sim == null) {
            p.setColor(0xFF4A505E);
            I18nUi.drawText(c, "sem dados", getWidth() / 2f, getHeight() / 2f, p);
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (last == 0) last = now;
        acc += (now - last) / (1000.0 / AttackSim.TICKS_PER_SECOND) * speed;
        last = now;
        int steps = 0;
        if (controlled) {
            if (playing) {
                while (acc >= 1 && target < maxTick) { acc -= 1; target++; }
                if (target >= maxTick) playing = false;
                if (onTick != null) onTick.run();
            } else acc = 0;
            if (target < tick) { build(); if (sim == null) return; }
            int guard = 0;
            boolean snap = !playing;
            while (tick < target && guard++ < 600) {
                sim.step();
                tick++;
                if (playing) playSounds(); else sim.drainSounds();      // so toca andando; ao buscar na linha do tempo fica mudo
            }
            snapCam = snapCam || snap;
            drawWorld(c);
            if (playing) postInvalidateOnAnimation();
            return;
        }
        if (paused) { acc = 0; drawWorld(c); return; }
        while (acc >= 1 && steps < 6) {
            acc -= 1;
            steps++;
            sim.step();
            playSounds();
            age++;
            if (!sim.defenderInDamage()) idle++;
            if (idle > 30 || age > 420) { build(); break; }
        }
        drawWorld(c);
        postInvalidateOnAnimation();
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e) {
        if (!controlled || sim == null) return super.onTouchEvent(e);
        if (scaler == null) {
            scaler = new android.view.ScaleGestureDetector(getContext(), new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(android.view.ScaleGestureDetector g) {
                    float ns = Math.max(0.5f, Math.min(24f, scale * g.getScaleFactor()));
                    originX = g.getFocusX() - (g.getFocusX() - originX) * ns / scale;
                    originY = g.getFocusY() - (g.getFocusY() - originY) * ns / scale;
                    scale = ns;
                    toNormal();
                    invalidate();
                    return true;
                }
            });
        }
        scaler.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case android.view.MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                lastX = e.getX(); lastY = e.getY(); scaling = false; panned = false;
                return true;
            case android.view.MotionEvent.ACTION_POINTER_DOWN:
                scaling = true;
                return true;
            case android.view.MotionEvent.ACTION_MOVE:
                if (scaler.isInProgress() || e.getPointerCount() > 1) { scaling = true; lastX = e.getX(); lastY = e.getY(); return true; }
                if (!scaling) {
                    float dx = e.getX() - lastX, dy = e.getY() - lastY;
                    lastX = e.getX(); lastY = e.getY();
                    if (Math.abs(dx) + Math.abs(dy) > 0) { originX += dx; originY += dy; toNormal(); invalidate(); }
                }
                return true;
            case android.view.MotionEvent.ACTION_POINTER_UP:
                lastX = e.getX(e.getActionIndex() == 0 ? 1 : 0); lastY = e.getY(e.getActionIndex() == 0 ? 1 : 0);
                return true;
            default:
                return true;
        }
    }

    /** O usuario mexeu na camera: sai do modo automatico (TELA / CHAR) e fica no manual, como na principal. */
    private void toNormal() {
        if (camMode != CameraModes.NORMAL) { camMode = CameraModes.NORMAL; if (onCamMode != null) onCamMode.run(); }
        viewSet = true;
    }

    /** Enquadra o retangulo do mundo na view. */
    private void fit(float[] bd) {
        float s = Math.min(getWidth() / (bd[2] - bd[0]), getHeight() / (bd[3] - bd[1]));
        scale = Math.max(0.5f, Math.min(24f, s));
        originX = getWidth() * 0.5f - (bd[0] + bd[2]) * 0.5f * scale;
        originY = getHeight() * 0.5f - (bd[1] + bd[3]) * 0.5f * scale;
        viewSet = true;
    }

    /** Previa do golpe real: atacante e oponente, chao, bordas do mapa; a camera segue o modo (NORMAL / TELA / CHAR). */
    private void drawStage(Canvas c) {
        float[] bd = CameraModes.bounds(camMode, sim);
        if (bd != null) fit(bd);
        else if (!viewSet) fit(CameraModes.bounds(CameraModes.CHAR, sim));
        c.save();
        c.translate(originX, originY);
        c.scale(scale, scale);
        float u = 1f / scale;
        float left = -originX * u, right = (getWidth() - originX) * u;
        p.setStrokeWidth(1.5f * u);
        p.setColor(0xFF2A3A55);
        c.drawLine(left, 0, right, 0, p);                                  // chao
        List<BattleSim.Layer> ls = sim.layers();
        for (int i = 0; i < ls.size(); i++) {
            BattleSim.Layer l = ls.get(i);
            renderer.drawLayer(c, l, av.spritesForOwner(l.owner));
        }
        boxes.showHits = true;                                               // hitbox (vermelha) e hurtbox (azul) dos dois personagens, como na principal
        boxes.pixelScale = scale;
        for (int i = 0; i < ls.size(); i++) {
            BattleSim.Layer l = ls.get(i);
            if (l.firstOfSim) renderer.drawOverlay(c, l.sim, boxes, l.kind);
        }
        StageEdges.draw(c, sim, p, scale, -600f, 40f, true);                // retangulo da tela (azul), zoom (amarelo) e bordas do mapa (vermelho), sempre
        c.restore();
    }

    private void drawWorld(Canvas c) {
        if (controlled) { drawStage(c); return; }
        float s = getWidth() / ReactionCamera.VIEW_W;
        cam.follow(sim.opponentX(), sim.opponentY(), getHeight() / s, snapCam);
        snapCam = false;
        c.save();
        c.translate(getWidth() / 2f - cam.x * s, getHeight() * ReactionCamera.GROUND_FRAC + cam.y * s);
        c.scale(s, s);
        p.setColor(0xFF2A3A55);
        c.drawRect(cam.x - 400, 0, cam.x + 400, 2 / s, p);
        List<BattleSim.Layer> ls = sim.layers();
        for (int i = 0; i < ls.size(); i++) {
            BattleSim.Layer l = ls.get(i);
            if (l.owner == BattleSim.OWNER_ATTACKER) continue;
            renderer.drawLayer(c, l, av.spritesForOwner(l.owner));
        }
        c.restore();
    }
}
