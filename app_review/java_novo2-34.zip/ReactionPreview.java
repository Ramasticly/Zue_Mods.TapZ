package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
import java.util.List;

/** Miniplayer: o oponente recebe um OPT 1 (reacao) e a animacao toca em laco. Cria a simulacao so quando aparece. */
final class ReactionPreview extends View {
    private final AttackView av;
    private final AttackRenderer renderer = new AttackRenderer();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private BattleSim sim;
    private int value = -1;
    private long last;
    private double acc;
    private int age, idle;
    private int centerX;

    ReactionPreview(Context c, AttackView av) {
        super(c);
        this.av = av;
        p.setTextSize(10f * c.getResources().getDisplayMetrics().density);
        p.setTextAlign(Paint.Align.CENTER);
    }

    void setValue(int v) {
        value = v;
        sim = null;
        invalidate();
    }

    void replay() { sim = null; invalidate(); }

    private void build() {
        sim = av.newReactionSim();
        age = 0;
        idle = 0;
        last = 0;
        acc = 0;
        if (sim == null) return;
        sim.forceHit(value);
        centerX = sim.opponentX() + (sim.attackerX() < sim.opponentX() ? 30 : -30);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D0F13);
        if (sim == null) build();
        if (sim == null) {
            p.setColor(0xFF4A505E);
            c.drawText("sem dados", getWidth() / 2f, getHeight() / 2f, p);
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (last == 0) last = now;
        acc += (now - last) / (1000.0 / AttackSim.TICKS_PER_SECOND);
        last = now;
        int steps = 0;
        while (acc >= 1 && steps < 6) {
            acc -= 1;
            steps++;
            sim.step();
            age++;
            if (!sim.defenderInDamage()) idle++;
            if (idle > 30 || age > 420) { build(); break; }
        }
        float s = getWidth() / 250f;
        c.save();
        c.translate(getWidth() / 2f - centerX * s, getHeight() * 0.8f);
        c.scale(s, s);
        p.setColor(0xFF2A3A55);
        c.drawRect(centerX - 400, 0, centerX + 400, 2 / s, p);
        List<BattleSim.Layer> ls = sim.layers();
        for (int i = 0; i < ls.size(); i++) {
            BattleSim.Layer l = ls.get(i);
            if (l.owner == BattleSim.OWNER_ATTACKER) continue;
            renderer.drawLayer(c, l, av.spritesForOwner(l.owner));
        }
        c.restore();
        postInvalidateOnAnimation();
    }
}
