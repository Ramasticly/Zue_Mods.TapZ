package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
import java.util.List;

/** Miniplayer: o oponente recebe um OPT 1 (reacao) e a animacao toca em laco. Cria a simulacao so quando aparece. */
final class ReactionPreview extends View {
    private final AttackView av;
    private final AttackRenderer renderer = new AttackRenderer();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private BattleSim sim;
    private int value = -1;
    private long last;
    private double acc;
    private int age, idle;
    private ReactionCamera cam = new ReactionCamera(0);
    private boolean sound, snapCam = true;

    ReactionPreview(Context c, AttackView av) {
        super(c);
        this.av = av;
        p.setTextSize(10f * c.getResources().getDisplayMetrics().density);
        p.setTextAlign(Paint.Align.CENTER);
    }

    void setValue(int v) {
        value = v;
        sim = null;
        invalidate();
    }

    private int ovSlot = -1;
    private ReactionTable ovTable;
    private boolean paused;
    private float speed = 1f;

    /** Liga o som da previa (voz e sons da reacao); as pequenas das grades ficam mudas. */
    void setSound(boolean on) { sound = on; }

    private void playSounds() {
        List<BattleSim.Snd> l = sim.drainSounds();
        if (sound && isShown() && !l.isEmpty()) av.playSounds(l);
    }

    /** Velocidade da reproducao (1 = normal). */
    void setSpeed(float s) { speed = s; }

    /** A previa toca {@code t} como se estivesse no slot {@code slot} do personagem (candidata a entrar num slot vazio). */
    void setOverride(int slot, ReactionTable t) {
        ovSlot = t == null ? -1 : slot;
        ovTable = t;
        sim = null;
        invalidate();
    }

    /** Pausa/retoma o laco automatico (modo nao controlado). */
    void setPaused(boolean p) { paused = p; if (!p) { last = 0; acc = 0; } invalidate(); }
    boolean isPaused() { return paused; }

    void replay() { sim = null; tick = 0; invalidate(); }

    // ---- modo controlado (editor de reacoes): o tick e o play vem de fora; nada de laco automatico ----
    /** Altura do oponente no cenario "ar" (px). */
    static final int AIR_HEIGHT = 60;
    private boolean controlled, air, playing;
    private int tick, target, maxTick = Integer.MAX_VALUE;
    private Runnable onTick;

    void setControlled(boolean on) { controlled = on; sim = null; tick = 0; invalidate(); }
    void setAir(boolean on) { if (air != on) { air = on; sim = null; tick = 0; invalidate(); } }

    /** Onde o oponente esta e de que lado vem o golpe (modo controlado); null = padrao. A previa recomeca do tick 0. */
    void setSetup(ReactionSetup su) { setup = su == null ? null : su.copy(); sim = null; tick = 0; snapCam = true; invalidate(); }
    private ReactionSetup setup;

    /** O usuario arrastou o personagem: {@code dx} px do mundo (horizontal) e {@code dy} (vertical, + = para baixo); chamado ao soltar. */
    interface MoveListener { void onMoved(int dx, int dy); }
    private MoveListener moveListener;
    void setMoveListener(MoveListener l) { moveListener = l; }

    boolean isCameraFree() { return cam.isFree(); }
    void setCameraFree(boolean on) { cam.setFree(on); if (!on) snapCam = true; invalidate(); }
    private float dragDx, dragDy;
    private boolean dragging;
    private float lastX, lastY, downX, downY;
    private int lastPointers;
    void setMaxTick(int n) { maxTick = Math.max(0, n); }
    void setOnTick(Runnable r) { onTick = r; }
    boolean isPlaying() { return playing; }
    int tickNow() { return tick; }

    /** Mostra o estado depois de {@code t} ticks (para o play). */
    void seek(int t) { target = Math.max(0, Math.min(maxTick, t)); playing = false; invalidate(); }

    void play() {
        if (target >= maxTick) target = 0;
        playing = true;
        last = 0;
        acc = 0;
        invalidate();
    }

    void pause() { playing = false; }

    private void build() {
        if (controlled && setup != null) sim = av.newReactionSim(setup);
        else {
            int oldH = BattleSim.oppHeightPx;
            if (controlled && air) BattleSim.oppHeightPx = AIR_HEIGHT;
            else if (controlled) BattleSim.oppHeightPx = 0;
            try { sim = av.newReactionSim(); }
            finally { BattleSim.oppHeightPx = oldH; }
        }
        tick = 0;
        age = 0;
        idle = 0;
        last = 0;
        acc = 0;
        if (sim == null) return;
        if (ovTable != null) sim.overrideCharReaction(ovSlot, ovTable);
        sim.forceHit(value);
        boolean wasFree = cam.isFree();
        float cx = cam.x, cy = cam.y;
        cam = new ReactionCamera(sim.attackerX() < sim.opponentX() ? 30 : -30);
        if (wasFree) { cam.pan(0, 0); cam.x = cx; cam.y = cy; }          // camera livre continua onde o usuario a deixou
        snapCam = true;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0D0F13);
        if (sim == null) build();
        if (sim == null) {
            p.setColor(0xFF4A505E);
            I18nUi.drawText(c, "sem dados", getWidth() / 2f, getHeight() / 2f, p);
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (last == 0) last = now;
        acc += (now - last) / (1000.0 / AttackSim.TICKS_PER_SECOND) * speed;
        last = now;
        int steps = 0;
        if (controlled) {
            if (playing) {
                while (acc >= 1 && target < maxTick) { acc -= 1; target++; }
                if (target >= maxTick) playing = false;
                if (onTick != null) onTick.run();
            } else acc = 0;
            if (target < tick) { build(); if (sim == null) return; }
            int guard = 0;
            boolean snap = !playing;
            while (tick < target && guard++ < 600) {
                sim.step();
                tick++;
                if (playing) playSounds(); else sim.drainSounds();      // so toca andando; ao buscar na linha do tempo fica mudo
            }
            snapCam = snapCam || snap;
            drawWorld(c);
            if (playing) postInvalidateOnAnimation();
            return;
        }
        if (paused) { acc = 0; drawWorld(c); return; }
        while (acc >= 1 && steps < 6) {
            acc -= 1;
            steps++;
            sim.step();
            playSounds();
            age++;
            if (!sim.defenderInDamage()) idle++;
            if (idle > 30 || age > 420) { build(); break; }
        }
        drawWorld(c);
        postInvalidateOnAnimation();
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e) {
        if (!controlled || sim == null) return super.onTouchEvent(e);
        float s = getWidth() / ReactionCamera.VIEW_W;
        int n = e.getPointerCount();
        float cx = 0, cy = 0;
        for (int i = 0; i < n; i++) { cx += e.getX(i); cy += e.getY(i); }
        cx /= n; cy /= n;
        switch (e.getActionMasked()) {
            case android.view.MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                downX = cx; downY = cy; lastX = cx; lastY = cy; lastPointers = n;
                dragDx = 0; dragDy = 0; dragging = false;
                return true;
            case android.view.MotionEvent.ACTION_POINTER_DOWN:
            case android.view.MotionEvent.ACTION_POINTER_UP:
                lastX = cx; lastY = cy; lastPointers = n;       // o centro dos dedos muda: evita salto
                if (e.getActionMasked() == android.view.MotionEvent.ACTION_POINTER_UP) lastPointers = n - 1;
                return true;
            case android.view.MotionEvent.ACTION_MOVE: {
                float dx = (cx - lastX) / s, dy = (cy - lastY) / s;
                lastX = cx; lastY = cy;
                if (n >= 2) {                                    // dois dedos: camera livre
                    cam.pan(dx, dy);
                    invalidate();
                } else if (lastPointers <= 1) {                  // um dedo: arrasta o personagem (aplicado ao soltar)
                    if (Math.abs(cx - downX) > 6 * getResources().getDisplayMetrics().density || dragging) {
                        dragging = true;
                        dragDx += dx;
                        dragDy += dy;
                        invalidate();
                    }
                }
                return true;
            }
            case android.view.MotionEvent.ACTION_UP:
                if (dragging && moveListener != null) moveListener.onMoved(Math.round(dragDx), Math.round(dragDy));
                dragging = false;
                dragDx = 0; dragDy = 0;
                invalidate();
                return true;
            case android.view.MotionEvent.ACTION_CANCEL:
                dragging = false;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void drawWorld(Canvas c) {
        float s = getWidth() / ReactionCamera.VIEW_W;
        cam.follow(sim.opponentX(), sim.opponentY(), getHeight() / s, snapCam);
        snapCam = false;
        c.save();
        c.translate(getWidth() / 2f - cam.x * s, getHeight() * ReactionCamera.GROUND_FRAC + cam.y * s);
        c.scale(s, s);
        p.setColor(0xFF2A3A55);
        c.drawRect(cam.x - 400, 0, cam.x + 400, 2 / s, p);
        List<BattleSim.Layer> ls = sim.layers();
        for (int i = 0; i < ls.size(); i++) {
            BattleSim.Layer l = ls.get(i);
            if (l.owner == BattleSim.OWNER_ATTACKER) continue;
            renderer.drawLayer(c, l, av.spritesForOwner(l.owner));
        }
        if (dragging) {                                  // guia do arrasto: onde o personagem vai ficar ao soltar
            p.setColor(0xFFFFD84C);
            p.setStrokeWidth(2f);
            float gx = sim.opponentX() + dragDx;
            c.drawLine(gx, -400, gx, 40, p);
        }
        c.restore();
        if (dragging) {
            p.setColor(0xFFFFD84C);
            I18nUi.drawText(c, "solte para mover o oponente (x " + Math.round(sim.opponentX() + dragDx) + ")", getWidth() / 2f, 14 * getResources().getDisplayMetrics().density, p);
        }
    }
}
