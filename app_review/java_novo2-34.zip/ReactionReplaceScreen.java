package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * "Salvar em outro personagem": a reacao do golpe nao tem igual nem vaga no destino. Mostra, no alto, a reacao que vai ser copiada e, abaixo, a grade das
 * reacoes do destino; tocar numa abre SUBSTITUIR (escreve por cima) e USAR ESSA (o golpe copiado passa a usar a que ja existe, sem gravar nada).
 */
final class ReactionReplaceScreen {
    private ReactionReplaceScreen() { }

    interface Listener {
        void onChoice(MoveTransplant.Choice choice);
        void onCancel();
    }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, SEL = 0xFF1E3A66;

    /** ANO da primeira linha da reacao (coluna 2), ou -1. */
    static int firstAno(ReactionTable t) { return t == null || t.rows <= 0 ? -1 : t.u8(0, 2); }

    private static View card(Activity a, CharAssets owner, ReactionTable t, String title, boolean selected, int sizeDp) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(selected ? SEL : CARD);
        g.setCornerRadius(SpriteListScreen.dp(a, 8));
        if (selected) g.setStroke(SpriteListScreen.dp(a, 2), ACCENT);
        c.setBackground(g);
        int ano = firstAno(t);
        if (ano >= 0 && owner != null && owner.dac != null && owner.dac.getAno(ano) != null && owner.dac.getAno(ano).present) {
            AnimPreview pv = new AnimPreview(a);
            pv.set(owner.dac, owner.sprites, ano);
            c.addView(pv, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, sizeDp), SpriteListScreen.dp(a, sizeDp)));
        } else {
            TextView e = SpriteListScreen.text(a, "sem animação", 10, DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setBackgroundColor(0xFF0D0F13);
            c.addView(e, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, sizeDp), SpriteListScreen.dp(a, sizeDp)));
        }
        TextView l = SpriteListScreen.text(a, title, 11, TEXT, true);
        l.setGravity(Gravity.CENTER);
        c.addView(l);
        TextView s = SpriteListScreen.text(a, t.rows + (t.rows == 1 ? " passo" : " passos") + (ano >= 0 ? " · ANO " + ano : ""), 10, DIM, false);
        s.setGravity(Gravity.CENTER);
        c.addView(s);
        return c;
    }

    static void show(final Activity a, final CharAssets src, final int srcType, final CharAssets dst, final Listener l) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        final boolean[] decided = {false};
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface dlg) { if (!decided[0]) l.onCancel(); }
        });
        TextView ti = SpriteListScreen.text(a, "Reação " + srcType + " do golpe: sem igual nem vaga em " + dst.dir.getName(), 15, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Compare com as reações de " + dst.dir.getName() + " e toque numa. SUBSTITUIR escreve a reação do golpe por cima dela (outros golpes que a usam mudam). "
                + "USAR ESSA não grava nada: o golpe copiado passa a usar a reação que já existe.", 11, DIM, false);
        hint.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        root.addView(hint);
        // reacao que vai ser copiada
        TextView cap = SpriteListScreen.text(a, "Reação que vai ser copiada", 12, OK, true);
        cap.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(cap);
        ReactionTable st = src.data.reaction(srcType);
        LinearLayout.LayoutParams top = new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 150), -2);
        top.setMargins(SpriteListScreen.dp(a, 14), 0, 0, SpriteListScreen.dp(a, 6));
        root.addView(card(a, src, st, "Reação " + srcType + " (" + src.dir.getName() + ")", false, 96), top);
        // grade do destino
        TextView cap2 = SpriteListScreen.text(a, "Reações de " + dst.dir.getName(), 12, ACCENT, true);
        cap2.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(cap2);
        final LinearLayout grid = new LinearLayout(a);
        grid.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new SafeScrollView(a);
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final List<Integer> slots = new ArrayList<Integer>();
        for (int s = 0; s < CharData.REACTION_COUNT; s++) { ReactionTable t = dst.data.reaction(s); if (t != null && t.rows > 0) slots.add(Integer.valueOf(s)); }
        final int[] sel = {-1};
        final TextView replace = SpriteListScreen.button(a, "SUBSTITUIR", null);
        final TextView use = SpriteListScreen.button(a, "USAR ESSA", null);
        // a grade se reconstroi a cada toque (destaque da escolhida)
        final Runnable[] self = new Runnable[1];
        self[0] = new Runnable() {
            @Override public void run() {
                grid.removeAllViews();
                for (int i = 0; i < slots.size(); i += 3) {
                    LinearLayout row = new LinearLayout(a);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    for (int k = 0; k < 3; k++) {
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                        lp.setMargins(SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 4));
                        if (i + k >= slots.size()) { row.addView(new View(a), lp); continue; }
                        final int slot = slots.get(i + k).intValue();
                        View c = card(a, dst, dst.data.reaction(slot), "Reação " + slot, slot == sel[0], 72);
                        c.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                            sel[0] = slot;
                            replace.setEnabled(true); replace.setAlpha(1f);
                            use.setEnabled(true); use.setAlpha(1f);
                            self[0].run();
                        } });
                        row.addView(c, lp);
                    }
                    grid.addView(row);
                }
            }
        };
        replace.setEnabled(false); replace.setAlpha(0.4f);
        use.setEnabled(false); use.setAlpha(0.4f);
        replace.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            if (sel[0] < 0) return;
            decided[0] = true; d.dismiss(); l.onChoice(new MoveTransplant.Choice(true, sel[0]));
        } });
        use.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            if (sel[0] < 0) return;
            decided[0] = true; d.dismiss(); l.onChoice(new MoveTransplant.Choice(false, sel[0]));
        } });
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 12));
        foot.addView(SpriteListScreen.button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        foot.addView(replace, SpriteListScreen.lpm(a, 8));
        foot.addView(use, SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        d.show();
        self[0].run();
    }
}
