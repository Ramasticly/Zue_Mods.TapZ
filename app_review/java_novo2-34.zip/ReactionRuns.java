package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Faixa SPEED da timeline de reacoes em "corridas", como no ANO: um passo com velocidade propria (x ou y diferente de -1) abre uma corrida
 * e os passos seguintes que mantem (-1) x e y fazem parte dela. A corrida vai ate o proximo passo com velocidade propria (ou ao fim da tabela).
 * Linhas antes da primeira velocidade propria (todas -1) nao pertencem a corrida alguma. Java puro.
 */
final class ReactionRuns {
    private ReactionRuns() { }

    /** Coluna da velocidade x do cenario (a y e a seguinte): chao 3, ar 7. */
    static int col(boolean air) { return air ? 7 : 3; }

    /** O passo so mantem (-1) a velocidade x e y do anterior? */
    static boolean keeps(ReactionTable t, int row, boolean air) {
        int c = col(air);
        return t.s8(row, c) == -1 && t.s8(row, c + 1) == -1;
    }

    /** Corridas do cenario: {primeiro passo, fim exclusivo}, em ordem. */
    static List<int[]> runs(ReactionTable t, boolean air) {
        List<int[]> out = new ArrayList<int[]>();
        if (t == null) return out;
        int start = -1;
        for (int r = 0; r < t.rows; r++) {
            if (!keeps(t, r, air)) {
                if (start >= 0) out.add(new int[]{start, r});
                start = r;
            }
        }
        if (start >= 0) out.add(new int[]{start, t.rows});
        return out;
    }

    /** Indice (em {@link #runs}) da corrida que contem o passo, ou -1. */
    static int runOf(ReactionTable t, boolean air, int row) {
        List<int[]> rs = runs(t, air);
        for (int i = 0; i < rs.size(); i++) if (row >= rs.get(i)[0] && row < rs.get(i)[1]) return i;
        return -1;
    }

    private static void setSpeed(ReactionTable t, int row, boolean air, int x, int y) {
        t.set(row, col(air), x);
        t.set(row, col(air) + 1, y);
    }

    /**
     * Arrasta o fim (borda direita) da corrida {@code run} para o passo {@code newEnd} (exclusivo): a fronteira com a proxima corrida anda junto
     * (os passos que trocam de lado passam a manter ou a receber a velocidade da proxima; nada e apagado). Sem proxima corrida, encurtar abre uma
     * corrida nova de velocidade 0 (parado) onde o fim ficou; estender alem da tabela nao existe. Devolve true se mudou algo.
     */
    static boolean setRunEnd(ReactionTable t, boolean air, int run, int newEnd) {
        List<int[]> rs = runs(t, air);
        if (run < 0 || run >= rs.size()) return false;
        int[] r = rs.get(run);
        newEnd = Math.max(r[0] + 1, newEnd);
        if (run == rs.size() - 1) {
            if (newEnd >= r[1]) return false;
            setSpeed(t, newEnd, air, 0, 0);
            return true;
        }
        int[] n = rs.get(run + 1);
        newEnd = Math.min(n[1] - 1, newEnd);
        int e = r[1];
        if (newEnd == e) return false;
        int c = col(air);
        int sx = t.s8(e, c), sy = t.s8(e, c + 1);
        for (int row = Math.min(e, newEnd); row < n[1]; row++) {
            if (row == newEnd) setSpeed(t, row, air, sx, sy);
            else setSpeed(t, row, air, -1, -1);
        }
        return true;
    }

    /** Tira a velocidade propria do inicio da corrida (x e y = -1): ela passa a seguir a anterior (ou o repouso, se for a primeira). */
    static boolean removeRun(ReactionTable t, boolean air, int run) {
        List<int[]> rs = runs(t, air);
        if (run < 0 || run >= rs.size()) return false;
        setSpeed(t, rs.get(run)[0], air, -1, -1);
        return true;
    }

    /** O passo so mantinha a velocidade: passa a ter velocidade propria 0,0 (corrida nova). Devolve false se ja tinha. */
    static boolean startRun(ReactionTable t, boolean air, int row) {
        if (t == null || row < 0 || row >= t.rows || !keeps(t, row, air)) return false;
        setSpeed(t, row, air, 0, 0);
        return true;
    }
}
