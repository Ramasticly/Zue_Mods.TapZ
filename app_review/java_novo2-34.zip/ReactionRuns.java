package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Faixas SPEED X e SPEED Y da timeline de reacoes em "corridas", como no ANO: um passo com velocidade propria (valor diferente de -1) abre uma corrida
 * e os passos seguintes que mantem (-1) fazem parte dela. A corrida vai ate o proximo passo com velocidade propria (ou ao fim da tabela).
 * Linhas antes da primeira velocidade propria (todas -1) nao pertencem a corrida alguma. O jogo trata x e y de forma independente (cada um so muda
 * se o byte nao for -1), entao cada eixo tem as proprias corridas; {@code axis} -1 = os dois juntos (par x+y, uso antigo). Java puro.
 */
final class ReactionRuns {
    private ReactionRuns() { }

    static final int X = 0, Y = 1, BOTH = -1;

    /** Coluna da velocidade x do cenario (a y e a seguinte): chao 3, ar 7. */
    static int col(boolean air) { return air ? 7 : 3; }

    /** Coluna da velocidade do eixo (0 = x, 1 = y). */
    static int col(boolean air, int axis) { return col(air) + axis; }

    /** O passo so mantem (-1) a velocidade do eixo (ou dos dois) do anterior? */
    static boolean keeps(ReactionTable t, int row, boolean air, int axis) {
        int c = col(air);
        if (axis == BOTH) return t.s8(row, c) == -1 && t.s8(row, c + 1) == -1;
        return t.s8(row, c + axis) == -1;
    }

    static boolean keeps(ReactionTable t, int row, boolean air) { return keeps(t, row, air, BOTH); }

    /** Corridas do cenario e eixo: {primeiro passo, fim exclusivo}, em ordem. */
    static List<int[]> runs(ReactionTable t, boolean air, int axis) {
        List<int[]> out = new ArrayList<int[]>();
        if (t == null) return out;
        int start = -1;
        for (int r = 0; r < t.rows; r++) {
            if (!keeps(t, r, air, axis)) {
                if (start >= 0) out.add(new int[]{start, r});
                start = r;
            }
        }
        if (start >= 0) out.add(new int[]{start, t.rows});
        return out;
    }

    static List<int[]> runs(ReactionTable t, boolean air) { return runs(t, air, BOTH); }

    /** Indice (em {@link #runs}) da corrida que contem o passo, ou -1. */
    static int runOf(ReactionTable t, boolean air, int axis, int row) {
        List<int[]> rs = runs(t, air, axis);
        for (int i = 0; i < rs.size(); i++) if (row >= rs.get(i)[0] && row < rs.get(i)[1]) return i;
        return -1;
    }

    static int runOf(ReactionTable t, boolean air, int row) { return runOf(t, air, BOTH, row); }

    /** Poe a velocidade propria do passo: so o eixo pedido (com {@code axis} -1, x e y). */
    private static void setSpeed(ReactionTable t, int row, boolean air, int axis, int x, int y) {
        if (axis != Y) t.set(row, col(air), x);
        if (axis != X) t.set(row, col(air) + 1, axis == BOTH ? y : x);
    }

    /**
     * Arrasta o fim (borda direita) da corrida {@code run} para o passo {@code newEnd} (exclusivo): a fronteira com a proxima corrida anda junto
     * (os passos que trocam de lado passam a manter ou a receber a velocidade da proxima; nada e apagado). Sem proxima corrida, encurtar abre uma
     * corrida nova de velocidade 0 (parado) onde o fim ficou; estender alem da tabela nao existe. Devolve true se mudou algo.
     */
    static boolean setRunEnd(ReactionTable t, boolean air, int axis, int run, int newEnd) {
        List<int[]> rs = runs(t, air, axis);
        if (run < 0 || run >= rs.size()) return false;
        int[] r = rs.get(run);
        newEnd = Math.max(r[0] + 1, newEnd);
        if (run == rs.size() - 1) {
            if (newEnd >= r[1]) return false;
            setSpeed(t, newEnd, air, axis, 0, 0);
            return true;
        }
        int[] n = rs.get(run + 1);
        newEnd = Math.min(n[1] - 1, newEnd);
        int e = r[1];
        if (newEnd == e) return false;
        int c = col(air);
        int sx = t.s8(e, c), sy = t.s8(e, c + 1);
        for (int row = Math.min(e, newEnd); row < n[1]; row++) {
            if (row == newEnd) setSpeed(t, row, air, axis, sx, sy);
            else setSpeed(t, row, air, axis, -1, -1);
        }
        return true;
    }

    static boolean setRunEnd(ReactionTable t, boolean air, int run, int newEnd) { return setRunEnd(t, air, BOTH, run, newEnd); }

    /** Tira a velocidade propria do inicio da corrida: ela passa a seguir a anterior (ou o repouso, se for a primeira). */
    static boolean removeRun(ReactionTable t, boolean air, int axis, int run) {
        List<int[]> rs = runs(t, air, axis);
        if (run < 0 || run >= rs.size()) return false;
        setSpeed(t, rs.get(run)[0], air, axis, -1, -1);
        return true;
    }

    static boolean removeRun(ReactionTable t, boolean air, int run) { return removeRun(t, air, BOTH, run); }

    /** O passo so mantinha a velocidade: passa a ter velocidade propria 0 (corrida nova). Devolve false se ja tinha. */
    static boolean startRun(ReactionTable t, boolean air, int axis, int row) {
        if (t == null || row < 0 || row >= t.rows || !keeps(t, row, air, axis)) return false;
        setSpeed(t, row, air, axis, 0, 0);
        return true;
    }

    static boolean startRun(ReactionTable t, boolean air, int row) { return startRun(t, air, BOTH, row); }
}
