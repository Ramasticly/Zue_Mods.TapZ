package com.zue.attackeditor;

/**
 * Colunas de velocidade da tabela de reacao (cenario chao ou ar, eixo x ou y). Cada passo tem a sua propria velocidade: nao ha mais "corridas" que unem passos
 * que mantem (-1); o que a timeline mostra por passo vem de {@link ReactionSpeedCells}. Java puro.
 */
final class ReactionRuns {
    private ReactionRuns() { }

    static final int X = 0, Y = 1, BOTH = -1;

    /** Coluna da velocidade x do cenario (a y e a seguinte): chao 3, ar 7. */
    static int col(boolean air) { return air ? 7 : 3; }

    /** Coluna da velocidade do eixo (0 = x, 1 = y). */
    static int col(boolean air, int axis) { return col(air) + axis; }

    /** O passo so mantem (-1) a velocidade do eixo (ou dos dois) do anterior? */
    static boolean keeps(ReactionTable t, int row, boolean air, int axis) {
        int c = col(air);
        if (axis == BOTH) return t.s8(row, c) == -1 && t.s8(row, c + 1) == -1;
        return t.s8(row, c + axis) == -1;
    }

    static boolean keeps(ReactionTable t, int row, boolean air) { return keeps(t, row, air, BOTH); }
}
