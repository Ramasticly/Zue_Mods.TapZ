package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Editor de reacao (remake 3.1zzz) no layout da tela principal: menu superior (POS, CENTRO, TRANSICAO, CHAO|AR, FECHAR), previa quadrada de largura cheia
 * com o GOLPE REAL (atacante parado no fim do frame da hitbox, retangulo da tela sempre visivel) e avisos no estilo QuickNotice, a timeline mostra UMA reacao
 * por vez (troca sozinha quando a sequencia pula para outra, com chips na faixa SEQ de onde veio e para onde vai). A pagina SEQ junta PAREDE e COMP.
 * Antes: cabecalho, previa quadrada de largura cheia, abaixo (numa area que rola) a barra de tempo,
 * os botoes DIVIDIR / DUPLICAR / EXCLUIR / DESFAZER e a timeline (clipes + faixas sob demanda, abas ＋ e #), o transporte fixo na base e a gaveta
 * flutuante (grade de paginas, como a da sprite). A edicao e na propria timeline; a gaveta abre ao tocar num passo ou num item de faixa.
 * Os dados vem de {@link ReactionTrace} (a simulacao real). Cenario CHAO | AR escolhe qual duracao/velocidade a timeline simula e mostra.
 * Reacoes do personagem sao editaveis (desfazer pelo editor principal); as do jogo, so leitura.
 */
final class ReactionScreen {
    private static final String[] PAGES = {"ANIMAÇÃO", "TEMPO", "SPEED", "VOZ", "SEQ", "TOTAL"};
    private static final int P_GRID = -1, P_ANIM = 0, P_TIME = 1, P_SPEED = 2, P_VOICE = 3, P_SEQ = 4, P_TOTAL = 5, P_LINK = 6;
    private static final int C_BLUE = 0xFF4C8DFF, C_AMBER = 0xFFFFB454;
    private static final String[] SPEED_NAMES = {"1x", "0.5x", "0.25x", "2x"};
    private static final float[] SPEEDS = {1f, 0.5f, 0.25f, 2f};

    private final Context c;
    private final AttackView view;
    private final Runnable onChanged;
    private final int startOpt, ano, pat;     // reacao do golpe (OPT 1 0..49) e o frame da hitbox que a usa
    private boolean editable;                 // a reacao EM EXIBICAO e do personagem?
    private int type;                         // ... e o tipo dela (0..29 jogo ou 0..19 personagem)
    private final float d;

    private Dialog dlg;
    private ReactionPreview preview;
    private ReactionTimelineView tl;
    private ReactionSheet sheet;
    private LinearLayout pageBox, transport;
    private android.widget.FrameLayout frame;
    private LayoutManager.SquareHolder holder;
    private android.widget.SeekBar seek;
    private boolean seekFromCode;
    private TextView tickLabel, playBtn, speedBtn, btnGround, btnAir, title;
    private int speedIndex;
    private boolean drawerOpen;
    private int selLane = ReactionTimelineView.LANE_PASSOS;
    /** A cadeia inteira (todas as reacoes que o golpe tocou) e o trecho da reacao em exibicao (ticks recontados do 0). */
    private ReactionTrace full, trace;
    private java.util.List<ReactionTrace.Occ> occs = new java.util.ArrayList<ReactionTrace.Occ>();
    private int occ, gTick;
    private boolean air, hit, locked;
    private int quietTicks;
    private TextView btnCam, btnLock;
    private NoticeBar notices;
    private static final int N_HIT = 0, N_LOCK = 1, N_GAME = 2;
    private final java.util.HashSet<Integer> dismissed = new java.util.HashSet<Integer>();
    private final java.util.IdentityHashMap<QuickNotice, Integer> noticeKind = new java.util.IdentityHashMap<QuickNotice, Integer>();
    private int sel, page = P_GRID;
    /** Eixo da faixa SPEED aberta (0 = X, 1 = Y): a pagina SPEED destaca o bloco desse eixo. */
    private int speedAxis = ReactionRuns.X;

    /** {@code optIndex}: reacao do hit (0..29 jogo, 30..49 personagem); {@code ano}/{@code pat}: ANO e frame da hitbox que a usa (o atacante toca ate o fim dele). */
    ReactionScreen(Context c, AttackView view, int optIndex, int ano, int pat, Runnable onChanged) {
        this.c = c;
        this.view = view;
        this.onChanged = onChanged;
        this.startOpt = optIndex;
        this.ano = ano;
        this.pat = pat;
        this.editable = optIndex >= 30;
        this.type = optIndex >= 30 ? optIndex - 30 : optIndex;
        this.d = c.getResources().getDisplayMetrics().density;
    }

    private int dp(int v) { return Math.round(v * d); }

    private ReactionTable table() { return editable ? view.charReaction(type) : view.gameReaction(type); }

    private boolean startChar() { return startOpt >= 30; }
    private int startType() { return startOpt >= 30 ? startOpt - 30 : startOpt; }

    // ---- tela ----

    void show() {
        if (table() == null) return;
        view.pause();                       // a previa principal fica no frame em que estava, pausada
        dlg = new Dialog(c, android.R.style.Theme_DeviceDefault_NoActionBar) {
            @Override public void onBackPressed() { if (drawerOpen) sheetBack(); else super.onBackPressed(); }
        };
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        frame = new android.widget.FrameLayout(c);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(10), dp(26), dp(10), dp(10));
        frame.addView(root, new android.widget.FrameLayout.LayoutParams(-1, -1));

        // menu superior (como o da principal): POS fixo no inicio, CENTRO em 2o, TRANSICAO, CHAO | AR, FECHAR
        HorizontalScrollView menu = new HorizontalScrollView(c);
        menu.setHorizontalScrollBarEnabled(false);
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        menu.addView(head);
        head.addView(btn("POS", true, new View.OnClickListener() { public void onClick(View v) { openPos(); } }));
        btnCam = btn(CameraModes.label(CameraModes.CHAR), true, new View.OnClickListener() { public void onClick(View v) {
            preview.setCameraMode((preview.cameraMode() + 1) % 3);
            updateCamButton();
        } });
        head.addView(btnCam);
        btnLock = btn("TRANSIÇÃO: LIVRE", false, new View.OnClickListener() { public void onClick(View v) { setLocked(!locked); } });
        head.addView(btnLock);
        btnGround = btn("CHÃO", true, new View.OnClickListener() { public void onClick(View v) { setAir(false); } });
        btnAir = btn("AR", false, new View.OnClickListener() { public void onClick(View v) { setAir(true); } });
        head.addView(btnGround);
        head.addView(btnAir);
        head.addView(btn("FECHAR", true, new View.OnClickListener() { public void onClick(View v) { close(); } }));
        root.addView(menu, mlp(-1, -2, 0, 0, 0, 2));
        title = text("", LayoutManager.DIM, 10, false);
        root.addView(title, mlp(-1, -2, 2, 0, 0, 3));

        // previa quadrada de largura cheia (com os avisos por cima, no estilo do QuickNotice)
        preview = new ReactionPreview(c, view);
        preview.setControlled(true);
        preview.setSound(true);
        preview.setContext(ano, pat, startType(), startChar());
        preview.setOnTick(new Runnable() { public void run() { onPlayTick(); } });
        preview.setOnCameraMode(new Runnable() { public void run() { updateCamButton(); } });
        preview.setBackground(round(0xFF0D0F13, 10));
        holder = new LayoutManager.SquareHolder(c);
        holder.addView(preview, new android.widget.FrameLayout.LayoutParams(-1, -1));
        android.widget.FrameLayout previewBox = new android.widget.FrameLayout(c);
        previewBox.addView(holder, new android.widget.FrameLayout.LayoutParams(-1, -2));
        notices = new NoticeBar(c);
        notices.setVisibility(View.GONE);
        previewBox.addView(notices, new android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        root.addView(previewBox, new LinearLayout.LayoutParams(-1, -2));
        syncFromView();

        // tudo abaixo da previa desliza
        final ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout sc = new LinearLayout(c);
        sc.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(sc, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // barra de tempo + rotulo
        LinearLayout trow = new LinearLayout(c);
        trow.setGravity(Gravity.CENTER_VERTICAL);
        seek = new android.widget.SeekBar(c);
        seek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s2, int progress, boolean fromUser) { if (fromUser && !seekFromCode) goTo(progress); }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s2) { preview.pause(); stopPlayUi(); }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s2) { }
        });
        trow.addView(seek, new LinearLayout.LayoutParams(0, -2, 1f));
        tickLabel = new I18nTextView(c);
        tickLabel.setTextColor(LayoutManager.TEXT);
        tickLabel.setTypeface(Typeface.MONOSPACE);
        tickLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        trow.addView(tickLabel, mlp(-2, -2, 8, 0, 0, 0));
        sc.addView(trow, mlp(-1, -2, 0, 4, 0, 4));

        // DIVIDIR / DUPLICAR / EXCLUIR / DESFAZER (4 botoes iguais, como o da timeline do ANO)
        {
            LinearLayout bar = new LinearLayout(c);
            String[] names = {"\u2702 DIVIDIR", "DUPLICAR", "\u2715 EXCLUIR", "\u21B6 DESFAZER"};
            final Runnable[] acts = {new Runnable() { public void run() { if (guard()) splitAtPointer(); } }, new Runnable() { public void run() { if (guard()) dupRow(); } },
                    new Runnable() { public void run() { if (guard()) deleteSelected(); } }, new Runnable() { public void run() { undo(); } }};
            for (int q = 0; q < names.length; q++) {
                final Runnable act = acts[q];
                TextView b2 = mbtn(names[q], false);
                b2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                b2.setPadding(dp(2), dp(7), dp(2), dp(7));
                b2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { act.run(); } });
                bar.addView(b2, lpw(1f, q == 0 ? 0 : 3, 0, q == names.length - 1 ? 0 : 3, 0));
            }
            sc.addView(bar, mlp(-1, -2, 0, 0, 0, 4));
        }

        // timeline + abas ＋ e # coladas a direita
        tl = new ReactionTimelineView(c);
        tl.setOpponent(view.opponentDac(), view.opponentSprites());
        tl.setListener(new ReactionTimelineView.Listener() {
            @Override public void onSelectRow(int row) { selLane = ReactionTimelineView.LANE_PASSOS; tl.setSelectedLane(selLane); sel = row; tl.setSelected(row); openDrawer(P_GRID); }
            @Override public void onScrub(int tick) { gTick = base() + tick; preview.seek(gTick); followRow(tick); updateLabel(); stopPlayUi(); }
            @Override public void onResize(int row, int ticks) {
                int[] r = ReactionEdit.resize(table(), row, air, ticks);
                if (r == null) return;
                selectRow(row);
                setCell(r[0], r[1]);
            }
            @Override public void onOpenLane(int lane, int row) {
                ReactionTable t = table();
                boolean speedLane = lane == ReactionTimelineView.LANE_SPEEDX || lane == ReactionTimelineView.LANE_SPEEDY;
                if (speedLane) speedAxis = lane == ReactionTimelineView.LANE_SPEEDY ? ReactionRuns.Y : ReactionRuns.X;
                if (speedLane && t != null) {
                    int run = ReactionRuns.runOf(t, air, speedAxis, row);
                    if (run >= 0) row = ReactionRuns.runs(t, air, speedAxis).get(run)[0];
                }
                selLane = lane;
                tl.setSelectedLane(lane);
                sel = row;
                tl.setSelected(row);
                openDrawer(speedLane ? P_SPEED : lane == ReactionTimelineView.LANE_VOZ ? P_VOICE : P_SEQ);
            }
            @Override public void onResizeRun(final int axis, final int run, final int newEnd) {
                final ReactionTable t = table();
                if (t == null || !editable) return;
                java.util.List<int[]> rs = ReactionRuns.runs(t, air, axis);
                if (run < 0 || run >= rs.size()) return;
                speedAxis = axis;
                selLane = axis == ReactionRuns.Y ? ReactionTimelineView.LANE_SPEEDY : ReactionTimelineView.LANE_SPEEDX;
                tl.setSelectedLane(selLane);
                sel = rs.get(run)[0];
                view.editReaction(type, new Runnable() { public void run() { ReactionRuns.setRunEnd(t, air, axis, run, newEnd); } });
                refresh();
            }
        });
        scroll.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t2, int r2, int b, int ol, int ot, int or2, int ob) {
                int h = b - t2;
                if (h > 0) tl.setMaxHeightPx(Math.max(h - dp(60), dp(120)));
            }
        });
        android.widget.FrameLayout tlBox = new android.widget.FrameLayout(c);
        tlBox.addView(tl, new android.widget.FrameLayout.LayoutParams(-1, -2));
        tlBox.setMinimumHeight(dp(104));
        TextView plus = tab("\uFF0B", 22, LayoutManager.ACCENT, 4);
        plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { if (guard()) addMenu(v); } });
        tlBox.addView(plus, tabLp(4));
        TextView filt = tab("#", 20, 0xFF3A4150, 52);
        filt.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showFilter(); } });
        tlBox.addView(filt, tabLp(52));
        sc.addView(tlBox, mlp(-1, -2, 0, 0, 0, 6));

        // transporte fixo na base
        transport = new LinearLayout(c);
        transport.setGravity(Gravity.CENTER_VERTICAL);
        TextView bReset = mbtn("INICIO", false), bBack = mbtn("-1", false), bFwd = mbtn("+1", false);
        playBtn = mbtn("TOCAR", true);
        speedBtn = mbtn(SPEED_NAMES[0], false);
        bReset.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { goTo(0); } });
        bBack.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { goTo(gTick - 1); } });
        bFwd.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { goTo(gTick + 1); } });
        playBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { togglePlay(); } });
        speedBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            speedIndex = (speedIndex + 1) % SPEEDS.length;
            speedBtn.setText(SPEED_NAMES[speedIndex]);
            preview.setSpeed(SPEEDS[speedIndex]);
        } });
        transport.addView(bReset, lpw(1f, 0, 0, 4, 0));
        transport.addView(bBack, lpw(1f, 4, 0, 4, 0));
        transport.addView(playBtn, lpw(1.4f, 4, 0, 4, 0));
        transport.addView(bFwd, lpw(1f, 4, 0, 4, 0));
        transport.addView(speedBtn, lpw(1f, 4, 0, 0, 0));
        root.addView(transport, mlp(-1, -2, 0, 4, 0, 2));

        // gaveta flutuante, ancorada acima do transporte
        final android.content.SharedPreferences prefs = c.getSharedPreferences("sheet", Context.MODE_PRIVATE);
        sheet = new ReactionSheet(c, new ReactionSheet.Geo() {
            @Override public int maxH() { return Math.max(dp(160), transport.getTop() - dp(26)); }
            @Override public int defH() {
                int saved = prefs.getInt("ryH", 0);
                if (saved > 0) return Math.min(saved, maxH());
                int toPreview = transport.getTop() - holder.getBottom();     // sobe ate a base da previa
                return Math.min(maxH(), toPreview > dp(120) ? toPreview : dp(240));
            }
        }, new Runnable() { public void run() { undo(); } }, new Runnable() { public void run() { sheetBack(); } }, new Runnable() { public void run() { closeDrawer(); } }, new Runnable() { public void run() { closeDrawer(); } },
                new Runnable() { public void run() {
                    int h = sheet.root.getHeight();
                    if (h > 0) {
                        prefs.edit().putInt("ryH", h).apply();
                        I18nUi.toast(c, "Altura padrão do menu salva", android.widget.Toast.LENGTH_SHORT).show();
                    }
                } });
        pageBox = sheet.body;
        frame.addView(sheet.root, new android.widget.FrameLayout.LayoutParams(-1, dp(240), Gravity.BOTTOM));
        transport.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t2, int r2, int b, int ol, int ot, int or2, int ob) { placeSheet(); }
        });

        dlg.setContentView(frame);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface i) { preview.pause(); pageBox.removeCallbacks(lightRun); BattleSim.lockReaction = false; view.flushReactionEdit(); onChanged.run(); }
        });
        dlg.show();
        sel = 0;
        refresh();
    }

    private void placeSheet() {
        ViewGroup.LayoutParams lps = sheet.root.getLayoutParams();
        if (lps instanceof android.widget.FrameLayout.LayoutParams) {
            android.widget.FrameLayout.LayoutParams fp = (android.widget.FrameLayout.LayoutParams) lps;
            int bm = Math.max(0, frame.getHeight() - transport.getTop());
            if (fp.bottomMargin != bm || fp.gravity != Gravity.BOTTOM) { fp.bottomMargin = bm; fp.gravity = Gravity.BOTTOM; sheet.root.setLayoutParams(fp); }
        }
    }

    private void close() { if (dlg != null) dlg.dismiss(); }

    private void undo() {
        if (!editable) return;
        if (view.undoEdit()) { onChanged.run(); sel = Math.min(sel, Math.max(0, table().rows - 1)); refresh(); }
    }

    /** Filtro #: quais faixas aparecem abaixo dos clipes. */
    private void showFilter() {
        final boolean[] on = new boolean[ReactionLayout.FILTER_NAMES.length];
        for (int i = 0; i < on.length; i++) on[i] = tl.isShown(i);
        new I18nBuilder(c).setTitle("Mostrar na timeline")
                .setMultiChoiceItems(ReactionLayout.FILTER_NAMES, on, new android.content.DialogInterface.OnMultiChoiceClickListener() {
                    @Override public void onClick(android.content.DialogInterface dl, int which, boolean checked) { tl.setShown(which, checked); }
                })
                .setNeutralButton("MOSTRAR TUDO", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dl, int w) { tl.showAll(); }
                })
                .setPositiveButton("OK", null).create().show();
    }

    // ---- dados: simulacao, cenario, ponteiro ----

    /** Roda o golpe real ate o hit e a reacao toda (com a trava da transicao, se ligada). Sem hit: tabela teorica da reacao do golpe, so passos e duracoes. */
    private ReactionTrace recordTrace() {
        BattleSim.lockReaction = locked;
        AttackView.ReactionRun run = view.newReactionRun(ano, pat, startType(), startChar());
        hit = run.hit;
        quietTicks = run.quietTicks;
        if (run.hit) return ReactionTrace.recordPrimed(run.sim, 420);
        return ReactionTrace.theoretical(startChar() ? view.charReaction(startType()) : view.gameReaction(startType()), startChar(), startType(), air);
    }

    /** Ticks que a previa e a barra de tempo cobrem: a cadeia toda (hit) ou ate nada mais animar (sem hit). */
    private int maxTick() { return hit ? (full == null ? 0 : full.ticks.size()) : quietTicks; }

    /** Tick global em que a reacao em exibicao comeca (0 sem hit). */
    private int base() { return hit && occ >= 0 && occ < occs.size() ? occs.get(occ).start : 0; }

    private void updateCamButton() {
        int m = preview.cameraMode();
        btnCam.setText(CameraModes.label(m));
        styleToggle(btnCam, m != CameraModes.NORMAL);
    }

    /** A altura do oponente (e o cenario chao/ar) vem do POS da principal; chamado ao abrir e ao fechar o dialogo POS. */
    private void syncFromView() {
        air = BattleSim.oppHeightPx > 0;
        if (btnGround != null) { styleToggle(btnGround, !air); styleToggle(btnAir, air); }
    }

    private void openPos() {
        if (!view.openPosDialog(new Runnable() { public void run() { syncFromView(); refresh(); } }))
            I18nUi.toast(c, "Posição indisponível agora", android.widget.Toast.LENGTH_SHORT).show();
    }

    /** TRANSICAO: travada, a sequencia inteira (parede, COMP, quique, 255, fim da tabela) nao troca de reacao: a tabela toca ate o fim. */
    private void setLocked(boolean on) {
        locked = on;
        dismissed.remove(N_LOCK);
        styleToggle(btnLock, on);
        btnLock.setText(on ? "TRANSIÇÃO: TRAVADA" : "TRANSIÇÃO: LIVRE");
        refresh();
    }

    /** Edicao so vale para reacao do personagem; a do jogo mostra o aviso azul. */
    private boolean guard() {
        if (editable) return true;
        dismissed.remove(N_GAME);
        updateNotices();
        return false;
    }

    /** Avisos sobre a previa: golpe sem hit (vermelho), transicao travada (ambar), reacao do jogo (azul). */
    private void updateNotices() {
        java.util.List<QuickNotice> l = new java.util.ArrayList<QuickNotice>();
        if (!hit && !dismissed.contains(N_HIT)) {
            QuickNotice n = new QuickNotice("O golpe não acertou nesta posição: o atacante para no fim do frame do hit e o oponente fica parado. Mude a posição em POS.").duration(0);
            n.left("POS", new Runnable() { public void run() { openPos(); } });
            n.right("REPOSICIONAR", new Runnable() { public void run() { reposition(); } });
            noticeKind.put(n, N_HIT);
            l.add(n);
        }
        if (locked && !dismissed.contains(N_LOCK)) {
            QuickNotice n = new QuickNotice("Transição travada: a sequência inteira (parede, COMP, quique, 255 ticks e fim da tabela) não troca de reação; a reação toca até o fim.")
                    .colors(QuickNotice.AMBER, QuickNotice.AMBER_BTN).duration(0);
            n.right("DESTRAVAR", new Runnable() { public void run() { setLocked(false); } });
            noticeKind.put(n, N_LOCK);
            l.add(n);
        }
        if (!editable && !dismissed.contains(N_GAME)) {
            QuickNotice n = new QuickNotice("Reações do jogo não podem ser editadas: as sequências do jogo são fixas. Só as reações do personagem aceitam edição.")
                    .colors(QuickNotice.BLUE, QuickNotice.BLUE_BTN).duration(0);
            noticeKind.put(n, N_GAME);
            l.add(n);
        }
        notices.show(l, new NoticeBar.OnClose() { public void closed(QuickNotice n) {
            Integer k = noticeKind.get(n);
            if (k != null) dismissed.add(k);
        } });
    }

    /** REPOSICIONAR: acha a distancia e a altura do oponente em que a hitbox do atacante (parado no fim do frame) cai dentro da hurtbox dele. */
    private void reposition() {
        final int a = ano, p2 = pat;
        int[] r = RepositionHit.solve(new RepositionHit.SimFactory() {
            public BattleSim held(int dist, int oppH) { return view.newHeldSim(a, p2, dist, oppH); }
        }, view.getDistance(), BattleSim.oppHeightPx, view.isFacingLeft(), 4);
        if (r == null) {
            I18nUi.toast(c, "Não dá para encaixar a hitbox na hurtbox do oponente (limites de distância e altura). Ajuste em POS.", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        view.setPositions(r[0], view.getAltitude(), r[1]);
        syncFromView();
        refresh();
    }

    private String occName(ReactionTrace.Occ o) { return (o.charSrc ? "personagem " : "jogo ") + o.type; }

    /** Mostra a reacao da passagem {@code i}: timeline, chips da faixa SEQ, avisos e gaveta. Nao re-simula. */
    private void showOcc(int i) {
        occ = Math.max(0, Math.min(i, Math.max(0, occs.size() - 1)));
        boolean cs = startChar();
        int ty = startType();
        if (hit && occ < occs.size()) { cs = occs.get(occ).charSrc; ty = occs.get(occ).type; }
        editable = cs;
        type = ty;
        ReactionTable t = table();
        trace = hit && occ < occs.size() ? full.slice(occs.get(occ)) : full;
        if (t == null || trace == null) return;
        sel = Math.max(0, Math.min(sel, t.rows - 1));
        tl.setData(trace, t, editable, type, air);
        tl.setSelected(sel);
        String from = null, to = null;
        Runnable goF = null, goT = null;
        if (hit && occ < occs.size()) {
            final ReactionTrace.Occ o = occs.get(occ);
            if (o.from >= 0 && o.from < occs.size()) {
                final int fi = o.from;
                from = "← reação " + occName(occs.get(fi)) + ", passo " + (o.fromRow + 1) + " (" + ReactionTrace.shortReason(o.reason) + ")";
                goF = new Runnable() { public void run() { openLink(fi, true); } };
            }
            if (occ + 1 < occs.size()) {
                final int ni = occ + 1;
                ReactionTrace.Occ nx = occs.get(ni);
                to = "→ reação " + occName(nx) + " (" + ReactionTrace.shortReason(nx.reason) + ")";
                goT = new Runnable() { public void run() { openLink(ni, false); } };
            }
        }
        tl.setLinks(from, goF, to, goT);
        title.setText((editable ? "Reação do personagem " + type : "Reação do jogo " + type + "  ·  só leitura")
                + (hit ? "  ·  reação " + (occ + 1) + " de " + Math.max(1, occs.size()) + " da sequência" : "  ·  sem hit nesta posição"));
        updateNotices();
        buildPage();
    }

    /** Recalcula a simulacao e refaz timeline, previa e aba (depois de qualquer edicao ou troca de cenario). */
    private void refresh() {
        ReactionTable t0 = table();
        if (t0 == null) return;
        boolean curChar = editable;
        int curType = type;
        full = recordTrace();
        if (hit) dismissed.remove(N_HIT);
        occs = hit ? full.occurrences() : new java.util.ArrayList<ReactionTrace.Occ>();
        int keep = 0;
        boolean found = false;
        for (int i = 0; i < occs.size(); i++) {
            if (occs.get(i).charSrc == curChar && occs.get(i).type == curType) {
                if (!found || Math.abs(i - occ) < Math.abs(keep - occ)) keep = i;
                found = true;
            }
        }
        if (!found) keep = 0;
        preview.setContext(ano, pat, startType(), startChar());
        preview.setAir(air);
        gTick = Math.min(gTick, maxTick());
        preview.setMaxTick(maxTick());
        showOcc(keep);
        preview.seek(gTick);
        applyGlobal(gTick);
        updateLabel();
    }

    private void setAir(boolean on) {
        if (air == on) return;
        air = on;
        view.setOppHeight(on ? (BattleSim.oppHeightPx > 0 ? BattleSim.oppHeightPx : ReactionPreview.AIR_HEIGHT) : 0);
        styleToggle(btnGround, !air);
        styleToggle(btnAir, air);
        refresh();
    }

    /** Leva o ponteiro ao tick global {@code g}; se ele cai em outra reacao da cadeia, a timeline passa a mostrar a dela. */
    private void applyGlobal(int g) {
        if (hit && !occs.isEmpty()) {
            int oi = full.occIndexAt(g);
            if (oi >= 0 && oi != occ) showOcc(oi);
        }
        int local = g - base();
        tl.setPointer(Math.max(0, local));
        followRow(tl.pointerTick());
    }

    private void goTo(int tick) {
        int max = maxTick();
        gTick = Math.max(0, Math.min(max, tick));
        preview.seek(gTick);
        applyGlobal(gTick);
        updateLabel();
        stopPlayUi();
    }

    private void togglePlay() {
        if (preview.isPlaying()) { preview.pause(); stopPlayUi(); return; }
        if (gTick >= maxTick()) goTo(0);
        preview.play();
        playBtn.setText("PAUSAR");
    }

    private void stopPlayUi() { if (!preview.isPlaying()) playBtn.setText("TOCAR"); }

    private void onPlayTick() {
        gTick = preview.tickNow();
        applyGlobal(gTick);
        updateLabel();
        stopPlayUi();
    }

    private void updateLabel() {
        int n = maxTick();
        int tk = gTick;
        int[] dsp = hit && full != null ? full.displacement(tk) : new int[]{0, 0};
        tickLabel.setText(tk + "/" + n + "  Δ " + dsp[0] + "," + dsp[1]);
        seekFromCode = true;
        seek.setMax(Math.max(1, n));
        seek.setProgress(tk);
        seekFromCode = false;
    }

    /** O ponteiro entrou num passo da tabela: a aba passa a editar esse passo. */
    private void followRow(int tick) {
        ReactionTrace.Seg s = tl.segAt(tick);
        if (tl.isOwn(s) && s.row != sel) selectRow(s.row);
    }

    private void selectRow(int row) {
        if (row == sel) return;
        sel = row;
        tl.setSelected(row);
        buildPage();
    }

    // ---- gaveta ----

    /** Abre a gaveta na grade ({@code P_GRID}) ou direto numa pagina. */
    private void openDrawer(int pg) {
        page = pg;
        drawerOpen = true;
        if (!sheet.isOpen()) { sheet.show(); placeSheet(); }
        buildPage();
    }

    private void closeDrawer() {
        drawerOpen = false;
        page = P_GRID;
        sheet.hide();
        updaters.clear();
        pageBox.removeAllViews();
    }

    /** Voltar: fecha a pagina aberta (volta a grade); com a grade na tela, fecha a gaveta. */
    private void sheetBack() {
        if (!drawerOpen) return;
        if (page == P_LINK) closeDrawer();
        else if (page != P_GRID) { page = P_GRID; buildPage(); }
        else closeDrawer();
    }

    private void buildPage() {
        if (!drawerOpen) return;
        pageBox.removeAllViews();
        updaters.clear();
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        if (page == P_LINK) {
            if (linkOcc < 0 || linkOcc >= occs.size() || linkOcc == occ) { closeDrawer(); return; }     // a timeline já está nessa reação (ou a cadeia mudou)
            pageLink();
            return;
        }
        String head = (page == P_GRID ? "Passo " : PAGES[page] + "  ·  passo ") + (page == P_TOTAL ? "" : (sel + 1) + " de " + t.rows)
                + (editable ? "" : "  ·  só leitura") + "  ·  " + (air ? "AR" : "CHÃO");
        sheet.setTitle(head);
        switch (page) {
            case P_GRID: grid(); break;
            case P_ANIM: pageAnimation(t); break;
            case P_TIME: pageTime(t); break;
            case P_SPEED: pageMove(t); break;
            case P_VOICE: pageVoice(t); break;
            case P_SEQ: pageSeq(t); break;
            default: pageTotal(t); break;
        }
    }

    /** Passagem alvo do chip da faixa SEQ e se e o chip "veio de" (true) ou "vai para" (false). */
    private int linkOcc = -1;
    private boolean linkFrom;

    /** Tocar num chip da faixa SEQ so abre este menu; a timeline so troca de reacao em IR PARA SEQUENCIA. */
    private void openLink(int occIndex, boolean from) {
        linkOcc = occIndex;
        linkFrom = from;
        openDrawer(P_LINK);
        sheet.scrollToTop();
    }

    private void pageLink() {
        final ReactionTrace.Occ o = occs.get(linkOcc);
        final ReactionTrace.Occ cur = occs.get(occ);
        ReactionTable tb = o.charSrc ? view.charReaction(o.type) : view.gameReaction(o.type);
        sheet.setTitle((linkFrom ? "Veio de" : "Vai para") + "  ·  reação " + occName(o));
        pageBox.addView(text((linkFrom ? "Esta reação veio da reação " : "Depois desta reação o jogo salta para a reação ") + occName(o)
                + (linkFrom ? ", passo " + (cur.fromRow + 1) : "") + ": " + ReactionTrace.reasonText((linkFrom ? cur : o).reason, o.charSrc, o.type) + ".", LayoutManager.TEXT, 12, false));
        ReactionPreview rp = new ReactionPreview(c, view);
        rp.setValue(o.charSrc ? 30 + o.type : o.type);
        pageBox.addView(rp, mlp(dp(140), dp(140), 0, 6, 0, 6));
        pageBox.addView(text(tb == null ? "sem tabela" : ReactionSlots.summary(tb), LayoutManager.DIM, 11, false));
        if (!o.charSrc) pageBox.addView(text("Reação do jogo: só leitura. As sequências do jogo não podem ser editadas.", LayoutManager.DIM, 10, false));
        pageBox.addView(btn("IR PARA SEQUÊNCIA", true, new View.OnClickListener() { public void onClick(View v) {
            int target = linkFrom ? o.end - 1 : o.start;
            closeDrawer();
            goTo(target);
        } }), mlp(-1, -2, 0, 8, 0, 0));
        pageBox.addView(btn("FECHAR", false, new View.OnClickListener() { public void onClick(View v) { closeDrawer(); } }), mlp(-1, -2, 0, 4, 0, 0));
    }

    /** Grade de paginas (como a do menu da sprite): 3 por linha. */
    private void grid() {
        LinearLayout row = null;
        for (int i = 0; i < PAGES.length; i++) {
            if (i % 3 == 0) { row = new LinearLayout(c); pageBox.addView(row, mlp(-1, -2, 0, 3, 0, 0)); }
            final int pg = i;
            TextView b2 = mbtn(PAGES[i], false);
            b2.setPadding(dp(4), dp(14), dp(4), dp(14));
            b2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { page = pg; buildPage(); sheet.scrollToTop(); } });
            row.addView(b2, lpw(1f, i % 3 == 0 ? 0 : 3, 0, i % 3 == 2 ? 0 : 3, 0));
        }
        pageBox.addView(text("Toque numa página para editar o passo selecionado. Na timeline, toque num item de uma faixa para abrir a página dele direto.", LayoutManager.DIM, 10, false));
    }

    /** Atualiza, no lugar, os campos da pagina aberta (sem recria-los: o - / + segurado e o teclado continuam vivos). */
    private final java.util.ArrayList<Runnable> updaters = new java.util.ArrayList<Runnable>();

    private void upd(Runnable r) { updaters.add(r); r.run(); }

    private void runUpdaters() {
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        for (int i = 0; i < updaters.size(); i++) updaters.get(i).run();
    }

    private int cell(int col) {
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return 0;
        return SIGNED[col] ? t.s8(sel, col) : t.u8(sel, col);
    }

    private void pageAnimation(ReactionTable t) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final AnimPreview pv = new AnimPreview(c);
        row.addView(pv, new LinearLayout.LayoutParams(dp(96), dp(96)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), 0, 0, 0);
        label(col, "ANO do oponente");
        final Stepper st = new Stepper(c).range(0, 127).step(1);
        final TextView mir = btn("", false, new View.OnClickListener() { public void onClick(View v) {
            int cur = cell(2);
            if (cur != 0) setCell(2, -cur);
        } });
        final TextView ro = text("", LayoutManager.TEXT, 14, true);
        if (editable) {
            st.tap(new Runnable() { public void run() { pickAno(Math.abs(cell(2))); } })
                    .onChange(new Stepper.OnValue() { public void on(double v) { int cur = cell(2); setCell(2, cur < 0 && v > 0 ? -(int) v : (int) v); } });
            col.addView(st.view());
            col.addView(mir);
        } else {
            col.addView(ro);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        pageBox.addView(row);
        pageBox.addView(text("Animação do oponente (defensor) tocada neste passo. Negativo vira o oponente (⇄). Tocar no número abre a grade de animações.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() {
            int ano = cell(2);
            pv.set(view.opponentDac(), view.opponentSprites(), Math.abs(ano), ano < 0);
            if (editable) { st.value(Math.abs(ano)); mir.setText(ano < 0 ? "● espelhado (⇄)" : "○ espelhado (⇄)"); styleToggle(mir, ano < 0); }
            else ro.setText("ANO " + Math.abs(ano) + (ano < 0 ? "  ⇄ espelhado" : ""));
        } });
    }

    private void pickAno(int cur) {
        if (!(c instanceof Activity)) return;
        AnoPicker.show((Activity) c, view.opponentDac(), view.opponentSprites(), false, cur, "ANO do oponente", false, new AnoPicker.Listener() {
            @Override public void onPick(int ano) { int old = cell(2); setCell(2, old < 0 && ano > 0 ? -ano : ano); }
        });
    }

    private void pageTime(ReactionTable t) {
        pageBox.addView(field("Duração no chão (ticks)", 0, 0, 255));
        pageBox.addView(field("Duração no ar (ticks)", 1, 0, 255));
        final TextView until = btn("ATÉ POUSAR (255 no ar)", false, new View.OnClickListener() { public void onClick(View v) { setCell(1, 255); } });
        if (editable) pageBox.addView(until);
        pageBox.addView(text("Dica: na timeline, arraste a borda direita do passo (a barra amarela) para mudar a duração do cenário atual.", LayoutManager.DIM, 10, false));
        final TextView info = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(info);
        upd(new Runnable() { public void run() {
            int dc = cell(0), da = cell(1);
            styleToggle(until, da == 255);
            info.setText("Chão: " + secs(dc) + "  ·  Ar: " + (da == 255 ? "até pousar (limite de 255 ticks)" : secs(da))
                    + ". O jogo usa a duração de chão enquanto o oponente está no chão e a de ar quando está no ar (60 ticks = 1 s).");
        } });
    }

    private static String secs(int ticks) { return ticks + " ticks = " + String.format(java.util.Locale.US, "%.2f", ticks / 60.0) + "s"; }

    private void pageMove(ReactionTable t) {
        int b = air ? 7 : 3;
        String set = air ? "ar" : "chão";
        pageBox.addView(moveField("Velocidade x (" + set + ")", b));
        pageBox.addView(moveField("Velocidade y (" + set + ")", b + 1));
        pageBox.addView(moveField("Aceleração x (" + set + ")", b + 2));
        pageBox.addView(moveField("Aceleração y (" + set + ")", b + 3));
        if (editable) pageBox.addView(btn("COPIAR ESTES 4 PARA O CENÁRIO " + (air ? "CHÃO" : "AR"), false, new View.OnClickListener() { public void onClick(View v) {
            final int from = air ? 7 : 3, to = air ? 3 : 7;
            final ReactionTable tt = table();
            final int row = sel;
            view.editReaction(type, new Runnable() { public void run() { for (int k = 0; k < 4; k++) tt.set(row, to + k, tt.u8(row, from + k)); } });
            onChanged.run();
            refresh();
        } }));
        final TextView block = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(block);
        upd(new Runnable() { public void run() {
            ReactionTable tt = table();
            String eixo = speedAxis == ReactionRuns.Y ? "Y" : "X";
            int run = tt == null ? -1 : ReactionRuns.runOf(tt, air, speedAxis, sel);
            if (run < 0) block.setText("Este passo ainda não tem velocidade " + eixo.toLowerCase() + " própria (parte do repouso). Preencher um valor cria o bloco SPEED " + eixo + ".");
            else {
                int[] r = ReactionRuns.runs(tt, air, speedAxis).get(run);
                block.setText("Bloco SPEED " + eixo + ": passos " + (r[0] + 1) + " a " + r[1] + (r[1] - r[0] > 1 ? " (os seguintes mantêm esta velocidade; arraste a borda do bloco na timeline para mudar até onde vai)" : "") + ".");
            }
        } });
        pageBox.addView(text("Unidades do jogo: 1 = 0,1 px por tick (a velocidade x só vale para o lado: o oponente virado anda para trás). −1 mantém o valor do passo anterior e −2 reduz pela metade. "
                + "A aceleração soma na velocidade a cada tick, e quando a soma cruza o zero a velocidade para (atrito).", LayoutManager.DIM, 10, false));
    }

    private View moveField(final String name, final int col) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        final TextView lbl = text("", LayoutManager.DIM, 11, false);
        lbl.setPadding(dp(4), dp(8), dp(4), dp(1));
        box.addView(lbl);
        final Stepper st = new Stepper(c).range(-128, 127).step(1);
        final TextView keep = btn("= mantém", false, new View.OnClickListener() { public void onClick(View x) { setCell(col, -1); } });
        final TextView half = btn("½", false, new View.OnClickListener() { public void onClick(View x) { setCell(col, -2); } });
        if (editable) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER_VERTICAL);
            st.keyboard(new Stepper.OnValue() { public void on(double nv) { setCell(col, (int) nv); } }).live(true);
            row.addView(st.view());
            row.addView(keep);
            row.addView(half);
            box.addView(row);
        }
        upd(new Runnable() { public void run() {
            int v = cell(col);
            lbl.setText(name + "  =  " + (v == -1 ? "mantém" : v == -2 ? "metade" : v + (col == 3 || col == 4 || col == 7 || col == 8 ? "  (" + (v / 10.0) + " px/tick)" : "")));
            if (editable) { st.value(v); styleToggle(keep, v == -1); styleToggle(half, v == -2); }
        } });
        return box;
    }

    private void pageVoice(ReactionTable t) {
        pageBox.addView(field("Voz do passo (0 = sem voz)", 13, 0, 127));
        final TextView none = btn("SEM VOZ", false, new View.OnClickListener() { public void onClick(View v) { setCell(13, 0); } });
        if (editable) pageBox.addView(none);
        pageBox.addView(text("O som da voz toca no tick em que o passo começa. O jogo lê o byte com sinal, então só valem 1 a 127 (acima disso nunca toca). Na timeline aparece como ♪ na faixa VOZ.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() { styleToggle(none, cell(13) == 0); } });
    }

    private void pageSeq(ReactionTable t) {
        pageBox.addView(text("A sequência é feita de duas partes: a PAREDE (o que permite pular para outra reação) e a PRÓXIMA REAÇÃO (COMP). "
                + "Os passos tocam em ordem; cada um dura DUR chão ou DUR ar (conforme a altura do oponente), e 255 = até pousar. No fim da tabela: voando cai na reação 13 (ou 2 se for KO); no chão volta ao idle.",
                LayoutManager.DIM, 10, false));
        // 1) PAREDE no topo
        label(pageBox, "Parede (coluna WALL deste passo)");
        final TextView[] wq = new TextView[WallRules.MODES.length];
        LinearLayout w1 = new LinearLayout(c), w2 = new LinearLayout(c);
        for (int i = 0; i < wq.length; i++) {
            final int mode = WallRules.MODES[i];
            wq[i] = btn(WallRules.name(mode), false, new View.OnClickListener() { public void onClick(View v) { if (guard()) setCell(12, mode); } });
            wq[i].setLayoutParams(lpw(1f, 2, 2, 2, 2));
            (i < 2 ? w1 : w2).addView(wq[i]);
        }
        pageBox.addView(w1);
        pageBox.addView(w2);
        final TextView wInfo = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(wInfo);
        // 2) PROXIMA REACAO: previa, - N +, ESCOLHER
        label(pageBox, "Próxima reação (COMP)");
        android.widget.FrameLayout pvBox = new android.widget.FrameLayout(c);
        final ReactionPreview rp = new ReactionPreview(c, view);
        final AnimPreview ap = new AnimPreview(c);
        pvBox.addView(rp, new android.widget.FrameLayout.LayoutParams(-1, -1));
        pvBox.addView(ap, new android.widget.FrameLayout.LayoutParams(-1, -1));
        pageBox.addView(pvBox, mlp(dp(120), dp(120), 0, 4, 0, 4));
        final TextView compTitle = text("", LayoutManager.TEXT, 13, true);
        compTitle.setGravity(Gravity.CENTER);
        LinearLayout step = new LinearLayout(c);
        step.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus = btn("−", false, new View.OnClickListener() { public void onClick(View v) { if (guard()) stepComp(-1); } });
        TextView plus = btn("+", false, new View.OnClickListener() { public void onClick(View v) { if (guard()) stepComp(1); } });
        TextView pick = btn("ESCOLHER", true, new View.OnClickListener() { public void onClick(View v) {
            if (!guard()) return;
            ReactionCompPicker.show((Activity) c, view.gameDataObj(), view.attackerCharData(), view.opponentDac(), view.opponentSprites(), cell(11),
                    "Próxima reação do passo " + (sel + 1), new ReactionCompPicker.Listener() { public void onPick(int value) { setCell(11, value); } });
        } });
        step.addView(minus);
        step.addView(compTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        step.addView(plus);
        step.addView(pick);
        pageBox.addView(step);
        final TextView info = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(info);
        pageBox.addView(text("Como o jogo escolhe: o golpe aponta uma reação (OPT 1, valor % 50: 0-29 do jogo, 30-49 do personagem). Ao pousar, ou ao bater na parede (com parede 2 ou 3), "
                + "o jogo salta para a reação COMP do passo. Em TOTAL aparece o caminho percorrido, com o motivo de cada troca; a faixa SEQ da timeline mostra de onde a reação veio e para onde vai.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() {
            int w = WallRules.effective(cell(12));
            for (int i = 0; i < wq.length; i++) styleToggle(wq[i], WallRules.MODES[i] == w);
            wInfo.setText(WallRules.describe(cell(12), editable) + (locked ? " Transição travada: a parede não age na prévia." : ""));
            int comp = cell(11);
            compTitle.setText(comp == 0 ? "0 · Nenhuma" : ReactionSlots.compTitle(comp));
            info.setText(ReactionSlots.compDetail(comp) + (WallRules.triggers(cell(12)) && comp > 0 ? " Com a parede ligada, o COMP só entra ao bater na parede; o pouso vira quique (reação 12)." : "")
                    + (locked ? " Transição travada: o COMP não age na prévia." : ""));
            if (comp == 0) { rp.setVisibility(View.GONE); ap.setVisibility(View.GONE); }
            else if (comp == 11 || comp >= 50) {
                rp.setVisibility(View.GONE);
                ap.setVisibility(View.VISIBLE);
                ap.set(view.opponentDac(), view.opponentSprites(), comp == 11 ? 24 : 13, false);
            } else {
                ap.setVisibility(View.GONE);
                rp.setVisibility(View.VISIBLE);
                rp.setValue(comp);                      // 12 mostra o quique do jogo
            }
        } });
    }

    /** - / +: anda pela lista do seletor (nenhuma, ações especiais, reações do jogo e do personagem). */
    private void stepComp(int dir) {
        java.util.List<Integer> steps = ReactionSlots.compSteps(view.gameDataObj(), view.attackerCharData());
        int cur = cell(11);
        int key = cur >= 50 ? 50 : cur;
        int idx = steps.indexOf(Integer.valueOf(key));
        if (idx < 0) {                                  // valor sem tabela (ex.: reação vazia): vai para a vizinha mais próxima na direção pedida
            int best = dir > 0 ? steps.size() - 1 : 0;
            for (int i = 4; i < steps.size(); i++) {
                int v = steps.get(i).intValue();
                if (dir > 0 && v > key) { best = i; break; }
                if (dir < 0 && v < key) best = i;
            }
            setCell(11, steps.get(best).intValue());
            return;
        }
        int n = idx + dir;
        if (n < 0 || n >= steps.size()) return;
        setCell(11, steps.get(n).intValue());
    }

    private void pageTotal(ReactionTable t) {
        final TextView body = text("", LayoutManager.TEXT, 11, false);
        pageBox.addView(body);
        pageBox.addView(text("Tudo vem da simulação do jogo (a mesma da prévia): arrastar o ponteiro na timeline mostra o estado do oponente naquele tick.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() { body.setText(totalText()); } });
    }

    private String totalText() {
        if (!hit || full == null) return "O golpe não acertou nesta posição: não há deslocamento para mostrar. Mude a posição em POS.";
        StringBuilder sb = new StringBuilder();
        int n = full.ticks.size();
        int[] all = full.displacement(n);
        sb.append("Cenário ").append(air ? "AR (oponente a " + BattleSim.oppHeightPx + " px do chão)" : "CHÃO").append(": ").append(n).append(" ticks = ")
                .append(String.format(java.util.Locale.US, "%.2f", n / 60.0)).append("s, deslocamento total x ").append(all[0]).append(" px, y ").append(all[1]).append(" px")
                .append(full.ended ? "." : " (parou no limite de 420 ticks).").append(locked ? " Transição travada." : "").append("\n\n");
        for (ReactionTrace.Seg s : full.segments) {
            int[] a = full.displacement(s.start), bb = full.displacement(s.end);
            String why = s.reason == BattleSim.R_START ? "" : "  [" + ReactionTrace.reasonText(s.reason, s.charSrc, s.type) + "]";
            sb.append("reação ").append(s.charSrc ? "do personagem " : "do jogo ").append(s.type).append(" passo ").append(s.row + 1).append(why).append(": ticks ").append(s.start).append("–").append(s.end - 1)
                    .append(" (").append(s.length()).append("), Δx ").append(bb[0] - (s.start == 0 ? 0 : a[0])).append(" Δy ").append(bb[1] - (s.start == 0 ? 0 : a[1])).append(" px\n");
        }
        return sb.toString();
    }

    // ---- campos e edicao ----

    private View field(String name, final int col, int lo, int hi) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        label(box, name);
        if (editable) {
            final Stepper st = new Stepper(c).range(lo, hi).step(1);
            st.keyboard(new Stepper.OnValue() { public void on(double nv) { setCell(col, (int) nv); } }).live(true);
            box.addView(st.view());
            upd(new Runnable() { public void run() { st.value(cell(col)); } });
        } else {
            final TextView ro = text("", LayoutManager.TEXT, 14, true);
            box.addView(ro);
            upd(new Runnable() { public void run() { ro.setText(String.valueOf(cell(col))); } });
        }
        return box;
    }

    private static final boolean[] SIGNED = {false, false, true, true, true, true, true, true, true, true, true, false, false, false};

    /** Colunas de 1 byte: o jogo le o ANO e a voz com sinal, entao a voz acima de 127 nunca toca. */
    private static int limit(int col, int v) {
        if (col == 13) return Math.max(0, Math.min(127, v));
        return SIGNED[col] ? Math.max(-128, Math.min(127, v)) : Math.max(0, Math.min(255, v));
    }

    private boolean lightPending;
    private final Runnable lightRun = new Runnable() { public void run() { lightPending = false; refreshLight(); } };

    /** Grava uma celula no lugar: so atualiza os campos abertos agora; timeline, previa e simulacao seguem logo depois (no maximo a cada ~150 ms). Uma entrada de desfazer por celula. */
    private void setCell(final int col, int value) {
        if (!editable) return;
        final int v = limit(col, value);
        final ReactionTable t = table();
        final int row = sel;
        if (t == null || row < 0 || row >= t.rows) return;
        if (SIGNED[col] ? t.s8(row, col) == v : t.u8(row, col) == v) return;
        view.editReaction(type, "reacao:" + type + ":" + row + ":" + col, new Runnable() { public void run() { t.set(row, col, v); } });
        runUpdaters();
        if (!lightPending) { lightPending = true; pageBox.postDelayed(lightRun, 150); }
    }

    /** Recalcula simulacao, timeline e previa sem recriar a pagina aberta. */
    private void refreshLight() {
        ReactionTable t = table();
        if (t == null) return;
        sel = Math.max(0, Math.min(sel, t.rows - 1));
        full = recordTrace();
        occs = hit ? full.occurrences() : new java.util.ArrayList<ReactionTrace.Occ>();
        int keep = Math.min(occ, Math.max(0, occs.size() - 1));
        if (keep < occs.size() && (occs.get(keep).charSrc != editable || occs.get(keep).type != type)) {
            for (int i = 0; i < occs.size(); i++) if (occs.get(i).charSrc == editable && occs.get(i).type == type) { keep = i; break; }
        }
        occ = keep;
        trace = hit && occ < occs.size() ? full.slice(occs.get(occ)) : full;
        tl.setData(trace, t, editable, type, air);
        tl.setSelected(sel);
        preview.setContext(ano, pat, startType(), startChar());
        gTick = Math.min(gTick, maxTick());
        preview.setMaxTick(maxTick());
        preview.seek(gTick);
        tl.setPointer(Math.max(0, gTick - base()));
        updateLabel();
        runUpdaters();
        onChanged.run();
    }

    // ---- barra de ferramentas ----

    /** ＋: cria no passo selecionado (passo novo, ou abre a gaveta da faixa para preencher voz, parede, SEQ e speed). */
    private void addMenu(View anchor) {
        android.widget.PopupMenu m = new android.widget.PopupMenu(c, anchor);
        m.getMenu().add(0, 0, 0, "Passo novo (depois do selecionado)");
        m.getMenu().add(0, 1, 1, "Speed X neste passo");
        m.getMenu().add(0, 8, 8, "Speed Y neste passo");
        m.getMenu().add(0, 2, 2, "Voz neste passo");
        m.getMenu().add(0, 3, 3, "Efeito de parede neste passo");
        m.getMenu().add(0, 4, 4, "Próxima reação (SEQ) neste passo");
        m.getMenu().add(0, 5, 5, "Mover passo para trás ◀");
        m.getMenu().add(0, 6, 6, "Mover passo para frente ▶");
        m.getMenu().add(0, 7, 7, "Σ Total (deslocamento)");
        m.setOnMenuItemClickListener(new android.widget.PopupMenu.OnMenuItemClickListener() {
            @Override public boolean onMenuItemClick(android.view.MenuItem it) {
                int id = it.getItemId();
                if (id == 0) { addRow(); return true; }
                if (id == 5 || id == 6) { moveRow(id == 5 ? -1 : 1); return true; }
                if (id == 7) { openDrawer(P_TOTAL); return true; }
                final ReactionTable t = table();
                if (t == null || sel < 0 || sel >= t.rows) return true;
                if (id == 1 || id == 8) {
                    final int axis = id == 8 ? ReactionRuns.Y : ReactionRuns.X;
                    speedAxis = axis;
                    selLane = axis == ReactionRuns.Y ? ReactionTimelineView.LANE_SPEEDY : ReactionTimelineView.LANE_SPEEDX;
                    if (ReactionRuns.keeps(t, sel, air, axis)) {
                        view.editReaction(type, new Runnable() { public void run() { ReactionRuns.startRun(t, air, axis, sel); } });
                        refresh();
                    }
                }
                else {
                    selLane = id == 2 ? ReactionTimelineView.LANE_VOZ : id == 3 ? ReactionTimelineView.LANE_EFEITOS : ReactionTimelineView.LANE_SEQ;
                    // faixa sem dados nao aparece: o ＋ cria o elemento com um valor inicial (a faixa surge) e abre a pagina para ajustar
                    if (id == 2 && cell(13) == 0) setCell(13, 1);
                    if (id == 3 && cell(12) == 0) setCell(12, 2);
                    if (id == 4 && cell(11) == 0) {
                        tl.setSelectedLane(selLane);
                        ReactionCompPicker.show((Activity) c, view.gameDataObj(), view.attackerCharData(), view.opponentDac(), view.opponentSprites(), 0,
                                "Próxima reação do passo " + (sel + 1), new ReactionCompPicker.Listener() { public void onPick(int value) { if (value > 0) setCell(11, value); openDrawer(P_SEQ); } });
                        return true;
                    }
                }
                tl.setSelectedLane(selLane);
                openDrawer(id == 1 || id == 8 ? P_SPEED : id == 2 ? P_VOICE : P_SEQ);
                return true;
            }
        });
        m.show();
    }

    /** DIVIDIR: parte o passo onde esta o ponteiro em dois (o 2o mantem a velocidade; o ANO do oponente recomeca nele). */
    private void splitAtPointer() {
        final ReactionTable t = table();
        ReactionTrace.Seg sg = tl.segAt(tl.pointerTick());
        if (t == null || trace == null || !tl.isOwn(sg)) {
            I18nUi.toast(c, "Ponha o ponteiro dentro de um passo desta reação", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        final int row = sg.row, k = tl.pointerTick() - sg.start;
        final BattleSim.DamageTick endOfFirst = k >= 1 && sg.start + k - 1 < trace.ticks.size() ? trace.ticks.get(sg.start + k - 1) : null;
        final boolean[] ok = {false};
        // confere antes (a tabela so muda se couber): em uma copia
        ReactionTable probe = t.copy();
        if (!ReactionEdit.splitKeepingMotion(probe, row, air, k, endOfFirst)) {
            I18nUi.toast(c, "Ponha o ponteiro depois do 1º tick e antes do fim do passo para dividir", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        view.editReaction(type, new Runnable() { public void run() { ok[0] = ReactionEdit.splitKeepingMotion(t, row, air, k, endOfFirst); } });
        sel = row + 1;
        selLane = ReactionTimelineView.LANE_PASSOS;
        tl.setSelectedLane(selLane);
        onChanged.run();
        refresh();
        I18nUi.toast(c, "Passo dividido em " + k + " + " + (t.u8(row + 1, ReactionEdit.durColumn(air)) == 255 ? "até pousar" : String.valueOf(t.u8(row + 1, ReactionEdit.durColumn(air)))) + " ticks (a animação do oponente recomeça no 2º passo)", android.widget.Toast.LENGTH_LONG).show();
    }

    /** EXCLUIR: o item selecionado (passo, bloco SPEED, voz, parede ou SEQ do passo). */
    private void deleteSelected() {
        final ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        switch (selLane) {
            case ReactionTimelineView.LANE_SPEEDX:
            case ReactionTimelineView.LANE_SPEEDY: {
                final int axis = selLane == ReactionTimelineView.LANE_SPEEDY ? ReactionRuns.Y : ReactionRuns.X;
                final int run = ReactionRuns.runOf(t, air, axis, sel);
                if (run < 0) { I18nUi.toast(c, "Este passo não tem velocidade própria", android.widget.Toast.LENGTH_SHORT).show(); return; }
                view.editReaction(type, new Runnable() { public void run() { ReactionRuns.removeRun(t, air, axis, run); } });
                onChanged.run();
                refresh();
                return;
            }
            case ReactionTimelineView.LANE_VOZ: setCell(13, 0); return;
            case ReactionTimelineView.LANE_EFEITOS: setCell(12, 0); return;
            case ReactionTimelineView.LANE_SEQ: setCell(11, 0); return;
            default: delRow();
        }
    }

    private void addRow() {
        final ReactionTable t = table();
        final int after = sel;
        view.editReaction(type, new Runnable() { public void run() { t.insertRow(after); } });
        sel = after + 1;
        onChanged.run();
        refresh();
    }

    private void dupRow() {
        final ReactionTable t = table();
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.duplicateRow(row); } });
        sel = row + 1;
        onChanged.run();
        refresh();
    }

    private void delRow() {
        final ReactionTable t = table();
        if (t.rows <= 1) { I18nUi.toast(c, "A reação precisa de ao menos um passo", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.removeRow(row); } });
        onChanged.run();
        refresh();
    }

    private void moveRow(final int dir) {
        final ReactionTable t = table();
        final int from = sel, to = Math.max(0, Math.min(t.rows - 1, from + dir));
        if (to == from) return;
        view.editReaction(type, new Runnable() { public void run() { t.moveRow(from, to); } });
        sel = to;
        onChanged.run();
        refresh();
    }

    // ---- estilo da tela principal ----

    private LinearLayout.LayoutParams mlp(int w, int h, int l, int t2, int r, int b) {
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(w, h);
        p2.setMargins(dp(l), dp(t2), dp(r), dp(b));
        return p2;
    }

    private LinearLayout.LayoutParams lpw(float weight, int l, int t2, int r, int b) {
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, -2, weight);
        p2.setMargins(dp(l), dp(t2), dp(r), dp(b));
        return p2;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    /** Botao do estilo da tela principal (12 sp negrito, cantos 8, realce ao tocar). */
    private TextView mbtn(String label, boolean primary) {
        TextView t2 = new I18nTextView(c);
        t2.setText(label);
        t2.setGravity(Gravity.CENTER);
        t2.setSingleLine(true);
        t2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t2.setTypeface(Typeface.DEFAULT_BOLD);
        t2.setTextColor(primary ? Color.WHITE : LayoutManager.TEXT);
        t2.setPadding(dp(4), dp(11), dp(4), dp(11));
        t2.setClickable(true);
        android.graphics.drawable.StateListDrawable sl = new android.graphics.drawable.StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, round(primary ? 0xFF6AA1FF : LayoutManager.PANEL_HI, 8));
        sl.addState(new int[]{}, round(primary ? LayoutManager.ACCENT : LayoutManager.PANEL, 8));
        t2.setBackground(sl);
        return t2;
    }

    /** Aba colada na borda direita da timeline (＋ e #). */
    private TextView tab(String label, int sp, int color, int topDp) {
        TextView t2 = new I18nTextView(c);
        t2.setText(label);
        t2.setGravity(Gravity.CENTER);
        t2.setTextColor(Color.WHITE);
        t2.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t2.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        float rr = dp(14);
        g.setCornerRadii(new float[]{rr, rr, 0, 0, 0, 0, rr, rr});
        t2.setBackground(g);
        t2.setClickable(true);
        return t2;
    }

    private android.widget.FrameLayout.LayoutParams tabLp(int topDp) {
        android.widget.FrameLayout.LayoutParams p2 = new android.widget.FrameLayout.LayoutParams(dp(30), dp(44), Gravity.END | Gravity.TOP);
        p2.setMargins(0, dp(topDp), 0, 0);
        return p2;
    }

    // ---- widgets ----

    private TextView text(String s, int color, int sp, boolean bold) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        return t;
    }

    private void label(LinearLayout box, String s) {
        TextView t = text(s, LayoutManager.DIM, 11, false);
        t.setPadding(dp(4), dp(8), dp(4), dp(1));
        box.addView(t);
    }

    private void styleToggle(TextView t, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
    }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        styleToggle(t, on);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(p);
        return t;
    }
}
