package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Editor de reacao estilo timeline: previa da reacao (com play e ponteiro), timeline dos passos (ANO do oponente, duracao, velocidade...) e abas de edicao.
 * Os dados vem de {@link ReactionTrace} (a simulacao real). Cenario CHAO | AR escolhe qual duracao/velocidade a timeline simula e mostra.
 * Reacoes do personagem sao editaveis (desfazer pelo editor principal); as do jogo, so leitura.
 */
final class ReactionScreen {
    private static final String[] PAGES = {"ANIMAÇÃO", "TEMPO", "MOVIMENTO", "FLUXO", "TOTAL"};
    private static final int C_BLUE = 0xFF4C8DFF, C_AMBER = 0xFFFFB454;

    private final Context c;
    private final AttackView view;
    private final Runnable onChanged;
    private final boolean editable;
    private final int type;                 // 0..29 jogo ou 0..19 personagem
    private final int optValue;             // valor de OPT 1 que representa esta reacao (0..29 / 30..49)
    private final float d;

    private Dialog dlg;
    private ReactionPreview preview;
    private ReactionTimelineView tl;
    private LinearLayout pageBox, tabs;
    private TextView tickLabel, playBtn, btnGround, btnAir, title;
    private final java.util.ArrayList<TextView> tabViews = new java.util.ArrayList<TextView>();
    private ReactionTrace trace;
    private boolean air;
    private int sel, page;

    ReactionScreen(Context c, AttackView view, int optIndex, Runnable onChanged) {
        this.c = c;
        this.view = view;
        this.onChanged = onChanged;
        this.editable = optIndex >= 30;
        this.type = optIndex >= 30 ? optIndex - 30 : optIndex;
        this.optValue = optIndex;
        this.d = c.getResources().getDisplayMetrics().density;
    }

    private int dp(int v) { return Math.round(v * d); }

    private ReactionTable table() { return editable ? view.charReaction(type) : view.gameReaction(type); }

    // ---- tela ----

    void show() {
        if (table() == null) return;
        dlg = new Dialog(c, android.R.style.Theme_DeviceDefault_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(8), dp(26), dp(8), dp(6));

        // cabecalho
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        title = new TextView(c);
        title.setText(editable ? "Reação do personagem " + type : "Reação do jogo " + type + "  ·  só leitura");
        title.setTextColor(LayoutManager.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        btnGround = btn("CHÃO", true, new View.OnClickListener() { public void onClick(View v) { setAir(false); } });
        btnAir = btn("AR", false, new View.OnClickListener() { public void onClick(View v) { setAir(true); } });
        head.addView(btnGround);
        head.addView(btnAir);
        if (editable) head.addView(btn("DESFAZER", false, new View.OnClickListener() { public void onClick(View v) {
            if (view.undoEdit()) { onChanged.run(); sel = Math.min(sel, Math.max(0, table().rows - 1)); refresh(); }
        } }));
        head.addView(btn("FECHAR", true, new View.OnClickListener() { public void onClick(View v) { close(); } }));
        root.addView(head);

        // previa + transporte
        int side = Math.min(Math.round(c.getResources().getDisplayMetrics().widthPixels * 0.62f), Math.round(c.getResources().getDisplayMetrics().heightPixels * 0.27f));
        preview = new ReactionPreview(c, view);
        preview.setControlled(true);
        preview.setValue(optValue);
        preview.setOnTick(new Runnable() { public void run() { onPlayTick(); } });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(side, side);
        pl.gravity = Gravity.CENTER_HORIZONTAL;
        pl.setMargins(0, dp(4), 0, dp(2));
        root.addView(preview, pl);
        LinearLayout tr = new LinearLayout(c);
        tr.setGravity(Gravity.CENTER);
        tr.addView(btn("⏮", false, new View.OnClickListener() { public void onClick(View v) { goTo(0); } }));
        tr.addView(btn("−1", false, new View.OnClickListener() { public void onClick(View v) { goTo(tl.pointerTick() - 1); } }));
        playBtn = btn("▶ TOCAR", true, new View.OnClickListener() { public void onClick(View v) { togglePlay(); } });
        tr.addView(playBtn);
        tr.addView(btn("+1", false, new View.OnClickListener() { public void onClick(View v) { goTo(tl.pointerTick() + 1); } }));
        tickLabel = new TextView(c);
        tickLabel.setTextColor(LayoutManager.DIM);
        tickLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tickLabel.setPadding(dp(8), 0, 0, 0);
        tr.addView(tickLabel);
        root.addView(tr);

        // timeline
        tl = new ReactionTimelineView(c);
        tl.setOpponent(view.opponentDac(), view.opponentSprites());
        tl.setListener(new ReactionTimelineView.Listener() {
            @Override public void onSelectRow(int row) { selectRow(row); }
            @Override public void onScrub(int tick) { preview.seek(tick); followRow(tick); updateLabel(); stopPlayUi(); }
        });
        root.addView(tl, new LinearLayout.LayoutParams(-1, -2));

        // abas + pagina
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        tabs = new LinearLayout(c);
        for (int i = 0; i < PAGES.length; i++) {
            final int pi = i;
            TextView tv = btn(PAGES[i], i == 0, new View.OnClickListener() { public void onClick(View v) { page = pi; updateTabs(); buildPage(); } });
            tabViews.add(tv);
            tabs.addView(tv);
        }
        hs.addView(tabs);
        root.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(c);
        pageBox = new LinearLayout(c);
        pageBox.setOrientation(LinearLayout.VERTICAL);
        pageBox.setPadding(dp(4), dp(2), dp(4), dp(16));
        sv.addView(pageBox);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // barra de passos
        if (editable) {
            LinearLayout bar = new LinearLayout(c);
            bar.setGravity(Gravity.CENTER);
            bar.addView(btn("＋ PASSO", true, new View.OnClickListener() { public void onClick(View v) { addRow(); } }));
            bar.addView(btn("DUPLICAR", false, new View.OnClickListener() { public void onClick(View v) { dupRow(); } }));
            bar.addView(btn("◀", false, new View.OnClickListener() { public void onClick(View v) { moveRow(-1); } }));
            bar.addView(btn("▶", false, new View.OnClickListener() { public void onClick(View v) { moveRow(1); } }));
            bar.addView(btn("✕ REMOVER", false, new View.OnClickListener() { public void onClick(View v) { delRow(); } }));
            root.addView(bar);
        }
        dlg.setContentView(root);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface i) { preview.pause(); }
        });
        dlg.show();
        sel = 0;
        refresh();
    }

    private void close() { if (dlg != null) dlg.dismiss(); }

    // ---- dados: simulacao, cenario, ponteiro ----

    private ReactionTrace recordTrace() {
        int old = BattleSim.oppHeightPx;
        BattleSim.oppHeightPx = air ? ReactionPreview.AIR_HEIGHT : 0;
        BattleSim s;
        try { s = view.newReactionSim(); } finally { BattleSim.oppHeightPx = old; }
        return ReactionTrace.record(s, optValue, 420);
    }

    /** Recalcula a simulacao e refaz timeline, previa e aba (depois de qualquer edicao ou troca de cenario). */
    private void refresh() {
        ReactionTable t = table();
        if (t == null) return;
        sel = Math.max(0, Math.min(sel, t.rows - 1));
        trace = recordTrace();
        tl.setData(trace, t, editable, type, air);
        tl.setSelected(sel);
        preview.setAir(air);
        preview.setMaxTick(trace.ticks.size());
        preview.setValue(optValue);
        preview.seek(tl.pointerTick());
        updateLabel();
        buildPage();
    }

    private void setAir(boolean on) {
        if (air == on) return;
        air = on;
        styleToggle(btnGround, !air);
        styleToggle(btnAir, air);
        refresh();
    }

    private void goTo(int tick) {
        int max = trace == null ? 0 : trace.ticks.size();
        tick = Math.max(0, Math.min(max, tick));
        tl.setPointer(tick);
        preview.seek(tick);
        followRow(tick);
        updateLabel();
        stopPlayUi();
    }

    private void togglePlay() {
        if (preview.isPlaying()) { preview.pause(); stopPlayUi(); return; }
        if (tl.pointerTick() >= (trace == null ? 0 : trace.ticks.size())) { tl.setPointer(0); preview.seek(0); }
        preview.play();
        playBtn.setText("⏸ PAUSAR");
    }

    private void stopPlayUi() { if (!preview.isPlaying()) playBtn.setText("▶ TOCAR"); }

    private void onPlayTick() {
        tl.setPointer(preview.tickNow());
        followRow(preview.tickNow());
        updateLabel();
        stopPlayUi();
    }

    private void updateLabel() {
        int n = trace == null ? 0 : trace.ticks.size();
        int tk = tl.pointerTick();
        int[] dsp = trace == null ? new int[]{0, 0} : trace.displacement(tk);
        tickLabel.setText("t " + tk + "/" + n + " (" + String.format(java.util.Locale.US, "%.2f", tk / 60.0) + "s)  Δ " + dsp[0] + "," + dsp[1] + " px");
    }

    /** O ponteiro entrou num passo da tabela: a aba passa a editar esse passo. */
    private void followRow(int tick) {
        ReactionTrace.Seg s = tl.segAt(tick);
        if (tl.isOwn(s) && s.row != sel) selectRow(s.row);
    }

    private void selectRow(int row) {
        if (row == sel) return;
        sel = row;
        tl.setSelected(row);
        buildPage();
    }

    // ---- abas ----

    private void updateTabs() {
        for (int i = 0; i < tabViews.size(); i++) styleToggle(tabViews.get(i), i == page);
    }

    private void buildPage() {
        pageBox.removeAllViews();
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        TextView h = text("Passo " + (sel + 1) + " de " + t.rows + (editable ? "" : "  ·  só leitura") + "  ·  cenário " + (air ? "AR" : "CHÃO"), LayoutManager.TEXT, 12, true);
        h.setPadding(dp(4), dp(8), 0, dp(4));
        pageBox.addView(h);
        switch (page) {
            case 0: pageAnimation(t); break;
            case 1: pageTime(t); break;
            case 2: pageMove(t); break;
            case 3: pageFlow(t); break;
            default: pageTotal(t); break;
        }
    }

    private void pageAnimation(ReactionTable t) {
        final int ano = t.s8(sel, 2);
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        AnimPreview pv = new AnimPreview(c);
        pv.set(view.opponentDac(), view.opponentSprites(), Math.abs(ano), ano < 0);
        row.addView(pv, new LinearLayout.LayoutParams(dp(96), dp(96)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), 0, 0, 0);
        label(col, "ANO do oponente");
        if (editable) {
            col.addView(new Stepper(c).range(0, 127).step(1).tap(new Runnable() { public void run() { pickAno(Math.abs(ano)); } })
                    .onChange(new Stepper.OnValue() { public void on(double v) { setCell(2, ano < 0 && v > 0 ? -(int) v : (int) v); } }).value(Math.abs(ano)).view());
            col.addView(btn(ano < 0 ? "● espelhado (⇄)" : "○ espelhado (⇄)", ano < 0, new View.OnClickListener() { public void onClick(View v) {
                if (ano != 0) setCell(2, -ano);
            } }));
        } else {
            col.addView(text("ANO " + Math.abs(ano) + (ano < 0 ? "  ⇄ espelhado" : ""), LayoutManager.TEXT, 14, true));
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        pageBox.addView(row);
        pageBox.addView(text("Animação do oponente (defensor) tocada neste passo. Negativo vira o oponente (⇄). Tocar no número abre a grade de animações.", LayoutManager.DIM, 10, false));
    }

    private void pickAno(int cur) {
        if (!(c instanceof Activity)) return;
        AnoPicker.show((Activity) c, view.opponentDac(), view.opponentSprites(), false, cur, "ANO do oponente", false, new AnoPicker.Listener() {
            @Override public void onPick(int ano) { ReactionTable t = table(); int old = t == null ? 0 : t.s8(sel, 2); setCell(2, old < 0 && ano > 0 ? -ano : ano); }
        });
    }

    private void pageTime(ReactionTable t) {
        pageBox.addView(field("Duração no chão (ticks)", 0, 0, 255, t));
        pageBox.addView(field("Duração no ar (ticks)", 1, 0, 255, t));
        if (editable) pageBox.addView(btn("ATÉ POUSAR (255 no ar)", t.u8(sel, 1) == 255, new View.OnClickListener() { public void onClick(View v) { setCell(1, 255); } }));
        int dc = t.u8(sel, 0), da = t.u8(sel, 1);
        pageBox.addView(text("Chão: " + secs(dc) + "  ·  Ar: " + (da == 255 ? "até pousar (limite de 255 ticks)" : secs(da))
                + ". O jogo usa a duração de chão enquanto o oponente está no chão e a de ar quando está no ar (60 ticks = 1 s).", LayoutManager.DIM, 10, false));
    }

    private static String secs(int ticks) { return ticks + " ticks = " + String.format(java.util.Locale.US, "%.2f", ticks / 60.0) + "s"; }

    private void pageMove(ReactionTable t) {
        int b = air ? 7 : 3;
        String set = air ? "ar" : "chão";
        pageBox.addView(moveField("Velocidade x (" + set + ")", b, t));
        pageBox.addView(moveField("Velocidade y (" + set + ")", b + 1, t));
        pageBox.addView(moveField("Aceleração x (" + set + ")", b + 2, t));
        pageBox.addView(moveField("Aceleração y (" + set + ")", b + 3, t));
        if (editable) pageBox.addView(btn("COPIAR ESTES 4 PARA O CENÁRIO " + (air ? "CHÃO" : "AR"), false, new View.OnClickListener() { public void onClick(View v) {
            final int from = air ? 7 : 3, to = air ? 3 : 7;
            final ReactionTable tt = table();
            final int row = sel;
            view.editReaction(type, new Runnable() { public void run() { for (int k = 0; k < 4; k++) tt.set(row, to + k, tt.u8(row, from + k)); } });
            onChanged.run();
            refresh();
        } }));
        pageBox.addView(text("Unidades do jogo: 1 = 0,1 px por tick (a velocidade x só vale para o lado: o oponente virado anda para trás). −1 mantém o valor do passo anterior e −2 reduz pela metade. "
                + "A aceleração soma na velocidade a cada tick, e quando a soma cruza o zero a velocidade para (atrito).", LayoutManager.DIM, 10, false));
    }

    private View moveField(final String name, final int col, ReactionTable t) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int v = t.s8(sel, col);
        label(box, name + "  =  " + (v == -1 ? "mantém" : v == -2 ? "metade" : v + (col == 3 || col == 4 || col == 7 || col == 8 ? "  (" + (v / 10.0) + " px/tick)" : "")));
        if (!editable) return box;
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(new Stepper(c).range(-128, 127).step(1).keyboard(new Stepper.OnValue() { public void on(double nv) { setCell(col, (int) nv); } }).value(v).view());
        row.addView(btn("= mantém", v == -1, new View.OnClickListener() { public void onClick(View x) { setCell(col, -1); } }));
        row.addView(btn("½", v == -2, new View.OnClickListener() { public void onClick(View x) { setCell(col, -2); } }));
        box.addView(row);
        return box;
    }

    private void pageFlow(ReactionTable t) {
        pageBox.addView(field("Próxima reação (0 = nenhuma; 1-29 jogo; 30-49 personagem)", 11, 0, 49, t));
        int comp = t.u8(sel, 11);
        pageBox.addView(text(comp == 0 ? "Sem próxima reação: ao acabar os passos, o oponente se levanta ou cai conforme a altura." : "Depois destes passos entra a reação " + (comp >= 30 ? "do personagem " + (comp - 30) : "do jogo " + comp)
                + (comp == 11 ? " (11: pousar e levantar)." : "."), LayoutManager.DIM, 10, false));
        pageBox.addView(field("Parede (0 = nenhum efeito)", 12, 0, 255, t));
        pageBox.addView(text("2 ou 3: ao encostar na parede a reação recomeça na próxima reação. Outros valores seguem a regra do jogo.", LayoutManager.DIM, 10, false));
        pageBox.addView(field("Voz (0 = nenhuma; o jogo lê com sinal, então até 127)", 13, 0, 127, t));
    }

    private void pageTotal(ReactionTable t) {
        if (trace == null) return;
        StringBuilder sb = new StringBuilder();
        int n = trace.ticks.size();
        int[] all = trace.displacement(n);
        sb.append("Cenário ").append(air ? "AR (oponente a " + ReactionPreview.AIR_HEIGHT + " px do chão)" : "CHÃO").append(": ").append(n).append(" ticks = ")
                .append(String.format(java.util.Locale.US, "%.2f", n / 60.0)).append("s, deslocamento total x ").append(all[0]).append(" px, y ").append(all[1]).append(" px")
                .append(trace.ended ? "." : " (parou no limite de 420 ticks).").append("\n\n");
        int prevEnd = 0;
        for (ReactionTrace.Seg s : trace.segments) {
            int[] a = trace.displacement(s.start), bb = trace.displacement(s.end);
            boolean own = s.charSrc == editable && s.type == type;
            sb.append(own ? "passo " + (s.row + 1) : "→ reação " + (s.charSrc ? "do personagem " : "do jogo ") + s.type + " passo " + (s.row + 1)).append(": ticks ").append(s.start).append("–").append(s.end - 1)
                    .append(" (").append(s.length()).append("), Δx ").append(bb[0] - (s.start == 0 ? 0 : a[0])).append(" Δy ").append(bb[1] - (s.start == 0 ? 0 : a[1])).append(" px\n");
            prevEnd = s.end;
        }
        pageBox.addView(text(sb.toString(), LayoutManager.TEXT, 11, false));
        pageBox.addView(text("Tudo vem da simulação do jogo (a mesma da prévia): arrastar o ponteiro na timeline mostra o estado do oponente naquele tick.", LayoutManager.DIM, 10, false));
    }

    // ---- campos e edicao ----

    private View field(String name, final int col, int lo, int hi, ReactionTable t) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        label(box, name);
        int v = SIGNED[col] ? t.s8(sel, col) : t.u8(sel, col);
        if (editable) box.addView(new Stepper(c).range(lo, hi).step(1).keyboard(new Stepper.OnValue() { public void on(double nv) { setCell(col, (int) nv); } }).value(v).view());
        else box.addView(text(String.valueOf(v), LayoutManager.TEXT, 14, true));
        return box;
    }

    private static final boolean[] SIGNED = {false, false, true, true, true, true, true, true, true, true, true, false, false, false};

    /** Colunas de 1 byte: o jogo le o ANO e a voz com sinal, entao a voz acima de 127 nunca toca. */
    private static int limit(int col, int v) {
        if (col == 13) return Math.max(0, Math.min(127, v));
        return SIGNED[col] ? Math.max(-128, Math.min(127, v)) : Math.max(0, Math.min(255, v));
    }

    private void setCell(final int col, int value) {
        if (!editable) return;
        final int v = limit(col, value);
        final ReactionTable t = table();
        final int row = sel;
        if (t == null || row < 0 || row >= t.rows) return;
        view.editReaction(type, new Runnable() { public void run() { t.set(row, col, v); } });
        onChanged.run();
        refresh();
    }

    private void addRow() {
        final ReactionTable t = table();
        final int after = sel;
        view.editReaction(type, new Runnable() { public void run() { t.insertRow(after); } });
        sel = after + 1;
        onChanged.run();
        refresh();
    }

    private void dupRow() {
        final ReactionTable t = table();
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.duplicateRow(row); } });
        sel = row + 1;
        onChanged.run();
        refresh();
    }

    private void delRow() {
        final ReactionTable t = table();
        if (t.rows <= 1) { android.widget.Toast.makeText(c, "A reação precisa de ao menos um passo", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.removeRow(row); } });
        onChanged.run();
        refresh();
    }

    private void moveRow(final int dir) {
        final ReactionTable t = table();
        final int from = sel, to = Math.max(0, Math.min(t.rows - 1, from + dir));
        if (to == from) return;
        view.editReaction(type, new Runnable() { public void run() { t.moveRow(from, to); } });
        sel = to;
        onChanged.run();
        refresh();
    }

    // ---- widgets ----

    private TextView text(String s, int color, int sp, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        return t;
    }

    private void label(LinearLayout box, String s) {
        TextView t = text(s, LayoutManager.DIM, 11, false);
        t.setPadding(dp(4), dp(8), dp(4), dp(1));
        box.addView(t);
    }

    private void styleToggle(TextView t, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
    }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        styleToggle(t, on);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(p);
        return t;
    }
}
