package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Editor de reacao estilo timeline: previa da reacao (com play e ponteiro), timeline dos passos (ANO do oponente, duracao, velocidade...) e barra de ferramentas.
 * A edicao e na propria timeline (arrastar a borda de um passo ou de um bloco SPEED, DIVIDIR, DUPLICAR, EXCLUIR...); a gaveta de baixo so abre ao tocar num item.
 * Os dados vem de {@link ReactionTrace} (a simulacao real). Cenario CHAO | AR escolhe qual duracao/velocidade a timeline simula e mostra.
 * Reacoes do personagem sao editaveis (desfazer pelo editor principal); as do jogo, so leitura.
 */
final class ReactionScreen {
    private static final String[] PAGES = {"PASSO", "SPEED", "VOZ", "EFEITOS", "SEQ", "TOTAL"};
    private static final int P_STEP = 0, P_SPEED = 1, P_VOICE = 2, P_EFFECTS = 3, P_SEQ = 4, P_TOTAL = 5;
    private static final int C_BLUE = 0xFF4C8DFF, C_AMBER = 0xFFFFB454;

    private final Context c;
    private final AttackView view;
    private final Runnable onChanged;
    private final boolean editable;
    private final int type;                 // 0..29 jogo ou 0..19 personagem
    private final int optValue;             // valor de OPT 1 que representa esta reacao (0..29 / 30..49)
    private final float d;

    private Dialog dlg;
    private ReactionPreview preview;
    private ReactionTimelineView tl;
    private LinearLayout pageBox, drawer;
    private TextView tickLabel, playBtn, btnGround, btnAir, title, drawerTitle, hint;
    private boolean drawerOpen;
    private int selLane = ReactionTimelineView.LANE_PASSOS;
    private ReactionTrace trace;
    private boolean air;
    private int sel, page;

    ReactionScreen(Context c, AttackView view, int optIndex, Runnable onChanged) {
        this.c = c;
        this.view = view;
        this.onChanged = onChanged;
        this.editable = optIndex >= 30;
        this.type = optIndex >= 30 ? optIndex - 30 : optIndex;
        this.optValue = optIndex;
        this.d = c.getResources().getDisplayMetrics().density;
    }

    private int dp(int v) { return Math.round(v * d); }

    private ReactionTable table() { return editable ? view.charReaction(type) : view.gameReaction(type); }

    // ---- tela ----

    void show() {
        if (table() == null) return;
        dlg = new Dialog(c, android.R.style.Theme_DeviceDefault_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(LayoutManager.BG);
        root.setPadding(dp(8), dp(26), dp(8), dp(6));

        // cabecalho
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        title = new TextView(c);
        title.setText(editable ? "Reação do personagem " + type : "Reação do jogo " + type + "  ·  só leitura");
        title.setTextColor(LayoutManager.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        btnGround = btn("CHÃO", true, new View.OnClickListener() { public void onClick(View v) { setAir(false); } });
        btnAir = btn("AR", false, new View.OnClickListener() { public void onClick(View v) { setAir(true); } });
        head.addView(btnGround);
        head.addView(btnAir);
        if (editable) head.addView(btn("DESFAZER", false, new View.OnClickListener() { public void onClick(View v) {
            if (view.undoEdit()) { onChanged.run(); sel = Math.min(sel, Math.max(0, table().rows - 1)); refresh(); }
        } }));
        head.addView(btn("FECHAR", true, new View.OnClickListener() { public void onClick(View v) { close(); } }));
        root.addView(head);

        // previa + transporte
        int side = Math.min(Math.round(c.getResources().getDisplayMetrics().widthPixels * 0.62f), Math.round(c.getResources().getDisplayMetrics().heightPixels * 0.27f));
        preview = new ReactionPreview(c, view);
        preview.setControlled(true);
        preview.setValue(optValue);
        preview.setOnTick(new Runnable() { public void run() { onPlayTick(); } });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(side, side);
        pl.gravity = Gravity.CENTER_HORIZONTAL;
        pl.setMargins(0, dp(4), 0, dp(2));
        root.addView(preview, pl);
        LinearLayout tr = new LinearLayout(c);
        tr.setGravity(Gravity.CENTER);
        tr.addView(btn("⏮", false, new View.OnClickListener() { public void onClick(View v) { goTo(0); } }));
        tr.addView(btn("−1", false, new View.OnClickListener() { public void onClick(View v) { goTo(tl.pointerTick() - 1); } }));
        playBtn = btn("▶ TOCAR", true, new View.OnClickListener() { public void onClick(View v) { togglePlay(); } });
        tr.addView(playBtn);
        tr.addView(btn("+1", false, new View.OnClickListener() { public void onClick(View v) { goTo(tl.pointerTick() + 1); } }));
        tickLabel = new TextView(c);
        tickLabel.setTextColor(LayoutManager.DIM);
        tickLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tickLabel.setPadding(dp(8), 0, 0, 0);
        tr.addView(tickLabel);
        root.addView(tr);

        // timeline
        tl = new ReactionTimelineView(c);
        tl.setOpponent(view.opponentDac(), view.opponentSprites());
        tl.setListener(new ReactionTimelineView.Listener() {
            @Override public void onSelectRow(int row) { selLane = ReactionTimelineView.LANE_PASSOS; tl.setSelectedLane(selLane); sel = row; tl.setSelected(row); openDrawer(P_STEP); }
            @Override public void onScrub(int tick) { preview.seek(tick); followRow(tick); updateLabel(); stopPlayUi(); }
            @Override public void onResize(int row, int ticks) {
                int[] r = ReactionEdit.resize(table(), row, air, ticks);
                if (r == null) return;
                selectRow(row);
                setCell(r[0], r[1]);
            }
            @Override public void onOpenLane(int lane, int row) {
                ReactionTable t = table();
                if (lane == ReactionTimelineView.LANE_SPEED && t != null) {
                    int run = ReactionRuns.runOf(t, air, row);
                    if (run >= 0) row = ReactionRuns.runs(t, air).get(run)[0];
                }
                selLane = lane;
                tl.setSelectedLane(lane);
                sel = row;
                tl.setSelected(row);
                openDrawer(lane == ReactionTimelineView.LANE_SPEED ? P_SPEED : lane == ReactionTimelineView.LANE_VOZ ? P_VOICE : lane == ReactionTimelineView.LANE_EFEITOS ? P_EFFECTS : P_SEQ);
            }
            @Override public void onResizeRun(final int run, final int newEnd) {
                final ReactionTable t = table();
                if (t == null || !editable) return;
                java.util.List<int[]> rs = ReactionRuns.runs(t, air);
                if (run < 0 || run >= rs.size()) return;
                selLane = ReactionTimelineView.LANE_SPEED;
                tl.setSelectedLane(selLane);
                sel = rs.get(run)[0];
                view.editReaction(type, new Runnable() { public void run() { ReactionRuns.setRunEnd(t, air, run, newEnd); } });
                refresh();
            }
        });
        root.addView(tl, new LinearLayout.LayoutParams(-1, -2));

        // barra de ferramentas (como a da timeline do ANO)
        if (editable) {
            HorizontalScrollView hs = new HorizontalScrollView(c);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout bar = new LinearLayout(c);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            final TextView plus = btn("＋", true, null);
            plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { addMenu(plus); } });
            bar.addView(plus);
            bar.addView(btn("DIVIDIR", false, new View.OnClickListener() { public void onClick(View v) { splitAtPointer(); } }));
            bar.addView(btn("DUPLICAR", false, new View.OnClickListener() { public void onClick(View v) { dupRow(); } }));
            bar.addView(btn("EXCLUIR", false, new View.OnClickListener() { public void onClick(View v) { deleteSelected(); } }));
            bar.addView(btn("◀", false, new View.OnClickListener() { public void onClick(View v) { moveRow(-1); } }));
            bar.addView(btn("▶", false, new View.OnClickListener() { public void onClick(View v) { moveRow(1); } }));
            bar.addView(btn("Σ TOTAL", false, new View.OnClickListener() { public void onClick(View v) { openDrawer(P_TOTAL); } }));
            hs.addView(bar);
            root.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        } else {
            LinearLayout bar = new LinearLayout(c);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.addView(btn("Σ TOTAL", false, new View.OnClickListener() { public void onClick(View v) { openDrawer(P_TOTAL); } }));
            root.addView(bar);
        }

        // dica (gaveta fechada) e gaveta (so abre ao tocar num item)
        hint = text(editable
                ? "Toque num item da timeline para editar. Arraste a borda direita (amarela) de um passo para mudar a duração e a de um bloco SPEED para estender ou encurtar a velocidade. DIVIDIR parte o passo onde está o ponteiro."
                : "Reação do jogo (só leitura). Toque num item da timeline para ver os valores; o ponteiro mostra o estado do oponente tick a tick.", LayoutManager.DIM, 11, false);
        hint.setPadding(dp(8), dp(10), dp(8), dp(4));
        root.addView(hint, new LinearLayout.LayoutParams(-1, 0, 1f));
        drawer = new LinearLayout(c);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setVisibility(View.GONE);
        LinearLayout dh = new LinearLayout(c);
        dh.setGravity(Gravity.CENTER_VERTICAL);
        drawerTitle = text("", LayoutManager.ACCENT, 12, true);
        dh.addView(drawerTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        dh.addView(btn("✕", false, new View.OnClickListener() { public void onClick(View v) { closeDrawer(); } }));
        drawer.addView(dh);
        ScrollView sv = new ScrollView(c);
        pageBox = new LinearLayout(c);
        pageBox.setOrientation(LinearLayout.VERTICAL);
        pageBox.setPadding(dp(4), dp(2), dp(4), dp(16));
        sv.addView(pageBox);
        drawer.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(drawer, new LinearLayout.LayoutParams(-1, 0, 1f));
        dlg.setContentView(root);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface i) { preview.pause(); pageBox.removeCallbacks(lightRun); view.flushReactionEdit(); onChanged.run(); }
        });
        dlg.show();
        sel = 0;
        refresh();
    }

    private void close() { if (dlg != null) dlg.dismiss(); }

    // ---- dados: simulacao, cenario, ponteiro ----

    private ReactionTrace recordTrace() {
        int old = BattleSim.oppHeightPx;
        BattleSim.oppHeightPx = air ? ReactionPreview.AIR_HEIGHT : 0;
        BattleSim s;
        try { s = view.newReactionSim(); } finally { BattleSim.oppHeightPx = old; }
        return ReactionTrace.record(s, optValue, 420);
    }

    /** Recalcula a simulacao e refaz timeline, previa e aba (depois de qualquer edicao ou troca de cenario). */
    private void refresh() {
        ReactionTable t = table();
        if (t == null) return;
        sel = Math.max(0, Math.min(sel, t.rows - 1));
        trace = recordTrace();
        tl.setData(trace, t, editable, type, air);
        tl.setSelected(sel);
        preview.setAir(air);
        preview.setMaxTick(trace.ticks.size());
        preview.setValue(optValue);
        preview.seek(tl.pointerTick());
        updateLabel();
        buildPage();
    }

    private void setAir(boolean on) {
        if (air == on) return;
        air = on;
        styleToggle(btnGround, !air);
        styleToggle(btnAir, air);
        refresh();
    }

    private void goTo(int tick) {
        int max = trace == null ? 0 : trace.ticks.size();
        tick = Math.max(0, Math.min(max, tick));
        tl.setPointer(tick);
        preview.seek(tick);
        followRow(tick);
        updateLabel();
        stopPlayUi();
    }

    private void togglePlay() {
        if (preview.isPlaying()) { preview.pause(); stopPlayUi(); return; }
        if (tl.pointerTick() >= (trace == null ? 0 : trace.ticks.size())) { tl.setPointer(0); preview.seek(0); }
        preview.play();
        playBtn.setText("⏸ PAUSAR");
    }

    private void stopPlayUi() { if (!preview.isPlaying()) playBtn.setText("▶ TOCAR"); }

    private void onPlayTick() {
        tl.setPointer(preview.tickNow());
        followRow(preview.tickNow());
        updateLabel();
        stopPlayUi();
    }

    private void updateLabel() {
        int n = trace == null ? 0 : trace.ticks.size();
        int tk = tl.pointerTick();
        int[] dsp = trace == null ? new int[]{0, 0} : trace.displacement(tk);
        tickLabel.setText("t " + tk + "/" + n + " (" + String.format(java.util.Locale.US, "%.2f", tk / 60.0) + "s)  Δ " + dsp[0] + "," + dsp[1] + " px");
    }

    /** O ponteiro entrou num passo da tabela: a aba passa a editar esse passo. */
    private void followRow(int tick) {
        ReactionTrace.Seg s = tl.segAt(tick);
        if (tl.isOwn(s) && s.row != sel) selectRow(s.row);
    }

    private void selectRow(int row) {
        if (row == sel) return;
        sel = row;
        tl.setSelected(row);
        buildPage();
    }

    // ---- gaveta ----

    private void openDrawer(int pg) {
        page = pg;
        drawerOpen = true;
        drawer.setVisibility(View.VISIBLE);
        hint.setVisibility(View.GONE);
        buildPage();
    }

    private void closeDrawer() {
        drawerOpen = false;
        drawer.setVisibility(View.GONE);
        hint.setVisibility(View.VISIBLE);
        updaters.clear();
        pageBox.removeAllViews();
    }

    private void buildPage() {
        if (!drawerOpen) return;
        pageBox.removeAllViews();
        updaters.clear();
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        drawerTitle.setText(PAGES[page] + (page == P_TOTAL ? "" : "  ·  passo " + (sel + 1) + " de " + t.rows) + (editable ? "" : "  ·  só leitura") + "  ·  " + (air ? "AR" : "CHÃO"));
        switch (page) {
            case P_STEP: pageAnimation(t); pageTime(t); break;
            case P_SPEED: pageMove(t); break;
            case P_VOICE: pageVoice(t); break;
            case P_EFFECTS: pageEffects(t); break;
            case P_SEQ: pageSeq(t); break;
            default: pageTotal(t); break;
        }
    }

    /** Atualiza, no lugar, os campos da pagina aberta (sem recria-los: o - / + segurado e o teclado continuam vivos). */
    private final java.util.ArrayList<Runnable> updaters = new java.util.ArrayList<Runnable>();

    private void upd(Runnable r) { updaters.add(r); r.run(); }

    private void runUpdaters() {
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        for (int i = 0; i < updaters.size(); i++) updaters.get(i).run();
    }

    private int cell(int col) {
        ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return 0;
        return SIGNED[col] ? t.s8(sel, col) : t.u8(sel, col);
    }

    private void pageAnimation(ReactionTable t) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final AnimPreview pv = new AnimPreview(c);
        row.addView(pv, new LinearLayout.LayoutParams(dp(96), dp(96)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), 0, 0, 0);
        label(col, "ANO do oponente");
        final Stepper st = new Stepper(c).range(0, 127).step(1);
        final TextView mir = btn("", false, new View.OnClickListener() { public void onClick(View v) {
            int cur = cell(2);
            if (cur != 0) setCell(2, -cur);
        } });
        final TextView ro = text("", LayoutManager.TEXT, 14, true);
        if (editable) {
            st.tap(new Runnable() { public void run() { pickAno(Math.abs(cell(2))); } })
                    .onChange(new Stepper.OnValue() { public void on(double v) { int cur = cell(2); setCell(2, cur < 0 && v > 0 ? -(int) v : (int) v); } });
            col.addView(st.view());
            col.addView(mir);
        } else {
            col.addView(ro);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        pageBox.addView(row);
        pageBox.addView(text("Animação do oponente (defensor) tocada neste passo. Negativo vira o oponente (⇄). Tocar no número abre a grade de animações.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() {
            int ano = cell(2);
            pv.set(view.opponentDac(), view.opponentSprites(), Math.abs(ano), ano < 0);
            if (editable) { st.value(Math.abs(ano)); mir.setText(ano < 0 ? "● espelhado (⇄)" : "○ espelhado (⇄)"); styleToggle(mir, ano < 0); }
            else ro.setText("ANO " + Math.abs(ano) + (ano < 0 ? "  ⇄ espelhado" : ""));
        } });
    }

    private void pickAno(int cur) {
        if (!(c instanceof Activity)) return;
        AnoPicker.show((Activity) c, view.opponentDac(), view.opponentSprites(), false, cur, "ANO do oponente", false, new AnoPicker.Listener() {
            @Override public void onPick(int ano) { int old = cell(2); setCell(2, old < 0 && ano > 0 ? -ano : ano); }
        });
    }

    private void pageTime(ReactionTable t) {
        pageBox.addView(field("Duração no chão (ticks)", 0, 0, 255));
        pageBox.addView(field("Duração no ar (ticks)", 1, 0, 255));
        final TextView until = btn("ATÉ POUSAR (255 no ar)", false, new View.OnClickListener() { public void onClick(View v) { setCell(1, 255); } });
        if (editable) pageBox.addView(until);
        pageBox.addView(text("Dica: na timeline, arraste a borda direita do passo (a barra amarela) para mudar a duração do cenário atual.", LayoutManager.DIM, 10, false));
        final TextView info = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(info);
        upd(new Runnable() { public void run() {
            int dc = cell(0), da = cell(1);
            styleToggle(until, da == 255);
            info.setText("Chão: " + secs(dc) + "  ·  Ar: " + (da == 255 ? "até pousar (limite de 255 ticks)" : secs(da))
                    + ". O jogo usa a duração de chão enquanto o oponente está no chão e a de ar quando está no ar (60 ticks = 1 s).");
        } });
    }

    private static String secs(int ticks) { return ticks + " ticks = " + String.format(java.util.Locale.US, "%.2f", ticks / 60.0) + "s"; }

    private void pageMove(ReactionTable t) {
        int b = air ? 7 : 3;
        String set = air ? "ar" : "chão";
        pageBox.addView(moveField("Velocidade x (" + set + ")", b));
        pageBox.addView(moveField("Velocidade y (" + set + ")", b + 1));
        pageBox.addView(moveField("Aceleração x (" + set + ")", b + 2));
        pageBox.addView(moveField("Aceleração y (" + set + ")", b + 3));
        if (editable) pageBox.addView(btn("COPIAR ESTES 4 PARA O CENÁRIO " + (air ? "CHÃO" : "AR"), false, new View.OnClickListener() { public void onClick(View v) {
            final int from = air ? 7 : 3, to = air ? 3 : 7;
            final ReactionTable tt = table();
            final int row = sel;
            view.editReaction(type, new Runnable() { public void run() { for (int k = 0; k < 4; k++) tt.set(row, to + k, tt.u8(row, from + k)); } });
            onChanged.run();
            refresh();
        } }));
        final TextView block = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(block);
        upd(new Runnable() { public void run() {
            ReactionTable tt = table();
            int run = tt == null ? -1 : ReactionRuns.runOf(tt, air, sel);
            if (run < 0) block.setText("Este passo ainda não tem velocidade própria (parte do repouso). Preencher um valor cria o bloco.");
            else {
                int[] r = ReactionRuns.runs(tt, air).get(run);
                block.setText("Bloco SPEED: passos " + (r[0] + 1) + " a " + r[1] + (r[1] - r[0] > 1 ? " (os seguintes mantêm esta velocidade; arraste a borda do bloco na timeline para mudar até onde vai)" : "") + ".");
            }
        } });
        pageBox.addView(text("Unidades do jogo: 1 = 0,1 px por tick (a velocidade x só vale para o lado: o oponente virado anda para trás). −1 mantém o valor do passo anterior e −2 reduz pela metade. "
                + "A aceleração soma na velocidade a cada tick, e quando a soma cruza o zero a velocidade para (atrito).", LayoutManager.DIM, 10, false));
    }

    private View moveField(final String name, final int col) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        final TextView lbl = text("", LayoutManager.DIM, 11, false);
        lbl.setPadding(dp(4), dp(8), dp(4), dp(1));
        box.addView(lbl);
        final Stepper st = new Stepper(c).range(-128, 127).step(1);
        final TextView keep = btn("= mantém", false, new View.OnClickListener() { public void onClick(View x) { setCell(col, -1); } });
        final TextView half = btn("½", false, new View.OnClickListener() { public void onClick(View x) { setCell(col, -2); } });
        if (editable) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER_VERTICAL);
            st.keyboard(new Stepper.OnValue() { public void on(double nv) { setCell(col, (int) nv); } }).live(true);
            row.addView(st.view());
            row.addView(keep);
            row.addView(half);
            box.addView(row);
        }
        upd(new Runnable() { public void run() {
            int v = cell(col);
            lbl.setText(name + "  =  " + (v == -1 ? "mantém" : v == -2 ? "metade" : v + (col == 3 || col == 4 || col == 7 || col == 8 ? "  (" + (v / 10.0) + " px/tick)" : "")));
            if (editable) { st.value(v); styleToggle(keep, v == -1); styleToggle(half, v == -2); }
        } });
        return box;
    }

    private void pageVoice(ReactionTable t) {
        pageBox.addView(field("Voz do passo (0 = sem voz)", 13, 0, 127));
        final TextView none = btn("SEM VOZ", false, new View.OnClickListener() { public void onClick(View v) { setCell(13, 0); } });
        if (editable) pageBox.addView(none);
        pageBox.addView(text("O som da voz toca no tick em que o passo começa. O jogo lê o byte com sinal, então só valem 1 a 127 (acima disso nunca toca). Na timeline aparece como ♪ na faixa VOZ.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() { styleToggle(none, cell(13) == 0); } });
    }

    private void pageEffects(ReactionTable t) {
        pageBox.addView(field("Parede (0 = nenhum efeito)", 12, 0, 255));
        final TextView[] q = new TextView[3];
        if (editable) {
            LinearLayout row = new LinearLayout(c);
            q[0] = btn("nenhum (0)", false, new View.OnClickListener() { public void onClick(View v) { setCell(12, 0); } });
            q[1] = btn("2", false, new View.OnClickListener() { public void onClick(View v) { setCell(12, 2); } });
            q[2] = btn("3", false, new View.OnClickListener() { public void onClick(View v) { setCell(12, 3); } });
            for (TextView x : q) row.addView(x);
            pageBox.addView(row);
        }
        pageBox.addView(text("Efeito de parede. Com 2 ou 3, se o oponente encosta na parede durante o passo a reação recomeça na reação indicada em SEQ (e o jogo marca a batida na parede). "
                + "Com 0 a parede não muda a reação. Outros valores seguem a regra do jogo para o tipo de parede.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() {
            if (!editable) return;
            int w = cell(12);
            styleToggle(q[0], w == 0); styleToggle(q[1], w == 2); styleToggle(q[2], w == 3);
        } });
    }

    private void pageSeq(ReactionTable t) {
        pageBox.addView(field("Próxima reação (0 = nenhuma; 1-29 jogo; 30-49 personagem)", 11, 0, 49));
        final TextView none = btn("nenhuma", false, new View.OnClickListener() { public void onClick(View v) { setCell(11, 0); } });
        if (editable) pageBox.addView(none);
        final TextView info = text("", LayoutManager.DIM, 10, false);
        pageBox.addView(info);
        pageBox.addView(text("É a faixa SEQ da timeline: a sequência de reações. Com parede 2 ou 3 é para ela que a reação volta ao bater na parede.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() {
            int comp = cell(11);
            styleToggle(none, comp == 0);
            info.setText(comp == 0 ? "Sem próxima reação: ao acabar os passos, o oponente se levanta ou cai conforme a altura." : "Depois destes passos entra a reação " + (comp >= 30 ? "do personagem " + (comp - 30) : "do jogo " + comp)
                    + (comp == 11 ? " (11: pousar e levantar)." : "."));
        } });
    }

    private void pageTotal(ReactionTable t) {
        final TextView body = text("", LayoutManager.TEXT, 11, false);
        pageBox.addView(body);
        pageBox.addView(text("Tudo vem da simulação do jogo (a mesma da prévia): arrastar o ponteiro na timeline mostra o estado do oponente naquele tick.", LayoutManager.DIM, 10, false));
        upd(new Runnable() { public void run() { if (trace != null) body.setText(totalText()); } });
    }

    private String totalText() {
        StringBuilder sb = new StringBuilder();
        int n = trace.ticks.size();
        int[] all = trace.displacement(n);
        sb.append("Cenário ").append(air ? "AR (oponente a " + ReactionPreview.AIR_HEIGHT + " px do chão)" : "CHÃO").append(": ").append(n).append(" ticks = ")
                .append(String.format(java.util.Locale.US, "%.2f", n / 60.0)).append("s, deslocamento total x ").append(all[0]).append(" px, y ").append(all[1]).append(" px")
                .append(trace.ended ? "." : " (parou no limite de 420 ticks).").append("\n\n");
        for (ReactionTrace.Seg s : trace.segments) {
            int[] a = trace.displacement(s.start), bb = trace.displacement(s.end);
            boolean own = s.charSrc == editable && s.type == type;
            sb.append(own ? "passo " + (s.row + 1) : "→ reação " + (s.charSrc ? "do personagem " : "do jogo ") + s.type + " passo " + (s.row + 1)).append(": ticks ").append(s.start).append("–").append(s.end - 1)
                    .append(" (").append(s.length()).append("), Δx ").append(bb[0] - (s.start == 0 ? 0 : a[0])).append(" Δy ").append(bb[1] - (s.start == 0 ? 0 : a[1])).append(" px\n");
        }
        return sb.toString();
    }

    // ---- campos e edicao ----

    private View field(String name, final int col, int lo, int hi) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        label(box, name);
        if (editable) {
            final Stepper st = new Stepper(c).range(lo, hi).step(1);
            st.keyboard(new Stepper.OnValue() { public void on(double nv) { setCell(col, (int) nv); } }).live(true);
            box.addView(st.view());
            upd(new Runnable() { public void run() { st.value(cell(col)); } });
        } else {
            final TextView ro = text("", LayoutManager.TEXT, 14, true);
            box.addView(ro);
            upd(new Runnable() { public void run() { ro.setText(String.valueOf(cell(col))); } });
        }
        return box;
    }

    private static final boolean[] SIGNED = {false, false, true, true, true, true, true, true, true, true, true, false, false, false};

    /** Colunas de 1 byte: o jogo le o ANO e a voz com sinal, entao a voz acima de 127 nunca toca. */
    private static int limit(int col, int v) {
        if (col == 13) return Math.max(0, Math.min(127, v));
        return SIGNED[col] ? Math.max(-128, Math.min(127, v)) : Math.max(0, Math.min(255, v));
    }

    private boolean lightPending;
    private final Runnable lightRun = new Runnable() { public void run() { lightPending = false; refreshLight(); } };

    /** Grava uma celula no lugar: so atualiza os campos abertos agora; timeline, previa e simulacao seguem logo depois (no maximo a cada ~150 ms). Uma entrada de desfazer por celula. */
    private void setCell(final int col, int value) {
        if (!editable) return;
        final int v = limit(col, value);
        final ReactionTable t = table();
        final int row = sel;
        if (t == null || row < 0 || row >= t.rows) return;
        if (SIGNED[col] ? t.s8(row, col) == v : t.u8(row, col) == v) return;
        view.editReaction(type, "reacao:" + type + ":" + row + ":" + col, new Runnable() { public void run() { t.set(row, col, v); } });
        runUpdaters();
        if (!lightPending) { lightPending = true; pageBox.postDelayed(lightRun, 150); }
    }

    /** Recalcula simulacao, timeline e previa sem recriar a pagina aberta. */
    private void refreshLight() {
        ReactionTable t = table();
        if (t == null) return;
        sel = Math.max(0, Math.min(sel, t.rows - 1));
        trace = recordTrace();
        tl.setData(trace, t, editable, type, air);
        tl.setSelected(sel);
        preview.setMaxTick(trace.ticks.size());
        preview.setValue(optValue);
        preview.seek(tl.pointerTick());
        updateLabel();
        runUpdaters();
        onChanged.run();
    }

    // ---- barra de ferramentas ----

    /** ＋: cria no passo selecionado (passo novo, ou abre a gaveta da faixa para preencher voz, parede, SEQ e speed). */
    private void addMenu(View anchor) {
        android.widget.PopupMenu m = new android.widget.PopupMenu(c, anchor);
        m.getMenu().add(0, 0, 0, "Passo novo (depois do selecionado)");
        m.getMenu().add(0, 1, 1, "Speed neste passo");
        m.getMenu().add(0, 2, 2, "Voz neste passo");
        m.getMenu().add(0, 3, 3, "Efeito de parede neste passo");
        m.getMenu().add(0, 4, 4, "Próxima reação (SEQ) neste passo");
        m.setOnMenuItemClickListener(new android.widget.PopupMenu.OnMenuItemClickListener() {
            @Override public boolean onMenuItemClick(android.view.MenuItem it) {
                int id = it.getItemId();
                if (id == 0) { addRow(); return true; }
                final ReactionTable t = table();
                if (t == null || sel < 0 || sel >= t.rows) return true;
                if (id == 1) {
                    selLane = ReactionTimelineView.LANE_SPEED;
                    if (ReactionRuns.keeps(t, sel, air)) {
                        view.editReaction(type, new Runnable() { public void run() { ReactionRuns.startRun(t, air, sel); } });
                        refresh();
                    }
                }
                else selLane = id == 2 ? ReactionTimelineView.LANE_VOZ : id == 3 ? ReactionTimelineView.LANE_EFEITOS : ReactionTimelineView.LANE_SEQ;
                tl.setSelectedLane(selLane);
                openDrawer(id == 1 ? P_SPEED : id == 2 ? P_VOICE : id == 3 ? P_EFFECTS : P_SEQ);
                return true;
            }
        });
        m.show();
    }

    /** DIVIDIR: parte o passo onde esta o ponteiro em dois (o 2o mantem a velocidade; o ANO do oponente recomeca nele). */
    private void splitAtPointer() {
        final ReactionTable t = table();
        ReactionTrace.Seg sg = tl.segAt(tl.pointerTick());
        if (t == null || trace == null || !tl.isOwn(sg)) {
            android.widget.Toast.makeText(c, "Ponha o ponteiro dentro de um passo desta reação", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        final int row = sg.row, k = tl.pointerTick() - sg.start;
        final BattleSim.DamageTick endOfFirst = k >= 1 && sg.start + k - 1 < trace.ticks.size() ? trace.ticks.get(sg.start + k - 1) : null;
        final boolean[] ok = {false};
        // confere antes (a tabela so muda se couber): em uma copia
        ReactionTable probe = t.copy();
        if (!ReactionEdit.splitKeepingMotion(probe, row, air, k, endOfFirst)) {
            android.widget.Toast.makeText(c, "Ponha o ponteiro depois do 1º tick e antes do fim do passo para dividir", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        view.editReaction(type, new Runnable() { public void run() { ok[0] = ReactionEdit.splitKeepingMotion(t, row, air, k, endOfFirst); } });
        sel = row + 1;
        selLane = ReactionTimelineView.LANE_PASSOS;
        tl.setSelectedLane(selLane);
        onChanged.run();
        refresh();
        android.widget.Toast.makeText(c, "Passo dividido em " + k + " + " + (t.u8(row + 1, ReactionEdit.durColumn(air)) == 255 ? "até pousar" : String.valueOf(t.u8(row + 1, ReactionEdit.durColumn(air)))) + " ticks (a animação do oponente recomeça no 2º passo)", android.widget.Toast.LENGTH_LONG).show();
    }

    /** EXCLUIR: o item selecionado (passo, bloco SPEED, voz, parede ou SEQ do passo). */
    private void deleteSelected() {
        final ReactionTable t = table();
        if (t == null || sel < 0 || sel >= t.rows) return;
        switch (selLane) {
            case ReactionTimelineView.LANE_SPEED: {
                final int run = ReactionRuns.runOf(t, air, sel);
                if (run < 0) { android.widget.Toast.makeText(c, "Este passo não tem velocidade própria", android.widget.Toast.LENGTH_SHORT).show(); return; }
                view.editReaction(type, new Runnable() { public void run() { ReactionRuns.removeRun(t, air, run); } });
                onChanged.run();
                refresh();
                return;
            }
            case ReactionTimelineView.LANE_VOZ: setCell(13, 0); return;
            case ReactionTimelineView.LANE_EFEITOS: setCell(12, 0); return;
            case ReactionTimelineView.LANE_SEQ: setCell(11, 0); return;
            default: delRow();
        }
    }

    private void addRow() {
        final ReactionTable t = table();
        final int after = sel;
        view.editReaction(type, new Runnable() { public void run() { t.insertRow(after); } });
        sel = after + 1;
        onChanged.run();
        refresh();
    }

    private void dupRow() {
        final ReactionTable t = table();
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.duplicateRow(row); } });
        sel = row + 1;
        onChanged.run();
        refresh();
    }

    private void delRow() {
        final ReactionTable t = table();
        if (t.rows <= 1) { android.widget.Toast.makeText(c, "A reação precisa de ao menos um passo", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final int row = sel;
        view.editReaction(type, new Runnable() { public void run() { t.removeRow(row); } });
        onChanged.run();
        refresh();
    }

    private void moveRow(final int dir) {
        final ReactionTable t = table();
        final int from = sel, to = Math.max(0, Math.min(t.rows - 1, from + dir));
        if (to == from) return;
        view.editReaction(type, new Runnable() { public void run() { t.moveRow(from, to); } });
        sel = to;
        onChanged.run();
        refresh();
    }

    // ---- widgets ----

    private TextView text(String s, int color, int sp, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        return t;
    }

    private void label(LinearLayout box, String s) {
        TextView t = text(s, LayoutManager.DIM, 11, false);
        t.setPadding(dp(4), dp(8), dp(4), dp(1));
        box.addView(t);
    }

    private void styleToggle(TextView t, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
    }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        styleToggle(t, on);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(p);
        return t;
    }
}
