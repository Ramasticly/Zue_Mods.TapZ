package com.zue.attackeditor;

/**
 * Onde o oponente esta (e de que lado vem o golpe) na previa e na simulacao do editor de reacoes. {@code placed} = false e o cenario de sempre
 * (oponente a 120 px do centro, golpe vindo da esquerda); true usa {@code x} (px do mundo: o mapa vai de {@link #MIN_X} a {@link #MAX_X}, com
 * as paredes nas pontas). O mesmo objeto alimenta o trace (timeline) e a previa, porque a parede muda o caminho da reacao. Java puro.
 */
final class ReactionSetup {
    static final int MIN_X = -720, MAX_X = 719, AIR_H = 60, MAX_H = 200;

    boolean placed;
    int x;
    /** true = o golpe vem da direita (atacante a direita do oponente, olhando para a esquerda). */
    boolean fromRight;
    /** Altura do oponente acima do chao (px). */
    int heightPx;

    ReactionSetup() { }

    ReactionSetup copy() {
        ReactionSetup s = new ReactionSetup();
        s.placed = placed;
        s.x = x;
        s.fromRight = fromRight;
        s.heightPx = heightPx;
        return s;
    }

    static int clampX(int x) { return Math.max(MIN_X, Math.min(MAX_X, x)); }

    static int clampH(int h) { return Math.max(0, Math.min(MAX_H, h)); }

    /** Parede esquerda: o golpe vem da direita e empurra para a parede. */
    ReactionSetup leftWall() { placed = true; x = MIN_X; fromRight = true; return this; }

    /** Centro do mapa, golpe vindo da esquerda. */
    ReactionSetup center() { placed = true; x = 0; fromRight = false; return this; }

    /** Parede direita: o golpe vem da esquerda (o padrao do jogo). */
    ReactionSetup rightWall() { placed = true; x = MAX_X; fromRight = false; return this; }

    /** Leva o oponente {@code dx} px (arrastar): vira "colocado". */
    ReactionSetup moveBy(int dx) {
        if (!placed) { placed = true; x = 120; }
        x = clampX(x + dx);
        return this;
    }

    ReactionSetup setHeight(int h) { heightPx = clampH(h); return this; }

    /** Chave para saber se mudou (refazer trace e previa). */
    String key() { return placed + ":" + x + ":" + fromRight + ":" + heightPx; }

    /** Texto curto da posicao para a tela. */
    String describe() {
        if (!placed) return "padrão";
        String w = x <= MIN_X + 40 ? " · perto da parede esq." : x >= MAX_X - 40 ? " · perto da parede dir." : "";
        return "x " + x + " px" + w + (fromRight ? " · golpe vem da direita" : " · golpe vem da esquerda");
    }
}
