package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Gaveta do editor de reacoes, no padrao da gaveta da tela principal ({@code TimelineTools.root}): flutua por cima, ancorada acima do transporte,
 * com alca de arrastar (puxar para cima / baixo; tocar alterna as alturas), botao Y (grava a altura atual como padrao), cabecalho
 * (titulo, desfazer, fechar, aplicar) e corpo que rola. A altura padrao e a que sobe ate a base da previa.
 */
final class ReactionSheet {
    /** Limites da gaveta, definidos pelo layout: altura maxima e altura padrao (ao abrir). */
    interface Geo { int maxH(); int defH(); }

    private static final int HANDLE_DP = 26;

    final LinearLayout root;
    final LinearLayout body;
    private final ScrollView scroll;
    private final TextView title;
    private final float d;
    private final Geo geo;

    ReactionSheet(Context c, Geo geo, Runnable onUndo, Runnable onBack, Runnable onDismiss, Runnable onApply, Runnable saveHeight) {
        this.geo = geo;
        this.d = c.getResources().getDisplayMetrics().density;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.BG);
        float rad = dp(14);
        bg.setCornerRadii(new float[]{rad, rad, rad, rad, 0, 0, 0, 0});
        bg.setStroke(dp(1), LayoutManager.PANEL_HI);
        root.setBackground(bg);

        // alca de arrastar ("-"): puxe para cima/baixo; arraste rapido para baixo fecha
        FrameLayout hbox = new FrameLayout(c);
        View bar = new View(c);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(LayoutManager.DIM);
        barBg.setCornerRadius(dp(3));
        bar.setBackground(barBg);
        hbox.addView(bar, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        final Runnable close = onDismiss;
        hbox.setOnTouchListener(new View.OnTouchListener() {
            float downY, prevY, vel; long prevT; int startH; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = prevY = e.getRawY(); prevT = e.getEventTime(); vel = 0; moved = false;
                        startH = root.getHeight();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float y = e.getRawY();
                        long t = e.getEventTime();
                        if (t > prevT) vel = vel * 0.6f + (y - prevY) / (t - prevT) * 1000f * 0.4f;
                        prevY = y; prevT = t;
                        if (Math.abs(y - downY) > dp(4)) moved = true;
                        if (moved) setHeight(startH - (int) (y - downY));
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        if (!moved) { tapHandle(); return true; }
                        float want = startH - (e.getRawY() - downY);
                        if (vel > 1800f || want < peekH() - dp(50)) { if (close != null) close.run(); }
                        return true;
                    }
                    default: return true;
                }
            }
        });
        final Runnable save = saveHeight;
        TextView y = edgeBtn("Y", new View.OnClickListener() { @Override public void onClick(View v) { if (save != null) save.run(); } });
        LinearLayout edge = new LinearLayout(c);
        edge.addView(y, new LinearLayout.LayoutParams(dp(30), dp(22)));
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        elp.setMargins(0, 0, dp(8), 0);
        hbox.addView(edge, elp);
        root.addView(hbox, new LinearLayout.LayoutParams(-1, dp(HANDLE_DP)));

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), 0, dp(6), dp(4));
        title = new I18nTextView(c);
        title.setTextColor(LayoutManager.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(btn("↶", false, onUndo));
        head.addView(btn("✕", false, onBack));
        head.addView(btn("APLICAR", true, onApply));
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // altura variavel: o conteudo rola dentro da gaveta
        body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(8), 0, dp(8), dp(24));
        scroll = new SafeScrollView(c);
        scroll.setFillViewport(false);
        scroll.addView(body, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.setVisibility(View.GONE);
    }

    private int dp(int v) { return Math.round(v * d); }

    private int peekH() { return dp(HANDLE_DP + 44); }

    private int maxH() { return Math.max(peekH() + dp(60), geo.maxH()); }

    void setTitle(String s) { title.setText(s); }

    boolean isOpen() { return root.getVisibility() == View.VISIBLE; }

    void show() {
        root.setVisibility(View.VISIBLE);
        setHeight(geo.defH());
    }

    void hide() { root.setVisibility(View.GONE); }

    void setHeight(int h) {
        h = Math.max(peekH(), Math.min(maxH(), h));
        ViewGroup.LayoutParams p = root.getLayoutParams();
        if (p != null && p.height != h) { p.height = h; root.setLayoutParams(p); }
    }

    void scrollToTop() { scroll.scrollTo(0, 0); }

    private void tapHandle() {
        int h = root.getHeight(), mx = maxH();
        int df = Math.min(mx, geo.defH());
        if (h <= peekH() + dp(10)) setHeight(df);
        else if (h < mx - dp(20) && h < df - dp(20)) setHeight(df);
        else if (h < mx - dp(20)) setHeight(mx);
        else setHeight(df);
    }

    private TextView edgeBtn(String t, View.OnClickListener l) {
        TextView b = new I18nTextView(root.getContext());
        b.setText(t);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(LayoutManager.TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(6));
        g.setColor(LayoutManager.PANEL_HI);
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private TextView btn(String s, boolean on, final Runnable r) {
        TextView t = new I18nTextView(root.getContext());
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setClickable(true);
        t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (r != null) r.run(); } });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(3), 0, dp(3), 0);
        t.setLayoutParams(p);
        return t;
    }
}
