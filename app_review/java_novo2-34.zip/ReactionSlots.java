package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Slots de reacao do personagem (HDAT 14..33 = tipos 0..19, OPT 1 30..49): quais estao vazios, resumo de uma tabela e leitura de outro personagem. */
final class ReactionSlots {
    private ReactionSlots() { }

    static boolean isEmpty(ReactionTable t) { return t == null || t.rows <= 0; }

    /** Tipos (0..19) do personagem sem nenhum passo. */
    static List<Integer> emptySlots(CharData cd) {
        List<Integer> out = new ArrayList<Integer>();
        for (int i = 0; i < CharData.REACTION_COUNT; i++) if (isEmpty(cd.reaction(i))) out.add(Integer.valueOf(i));
        return out;
    }

    /** "3 passos · ANOs 20, 4, 7 · 1.2s no chão" (duração do chão somada; 255 = até pousar). */
    static String summary(ReactionTable t) {
        if (isEmpty(t)) return "vazia";
        StringBuilder anos = new StringBuilder();
        int ticks = 0;
        boolean open = false;
        for (int r = 0; r < t.rows; r++) {
            if (r > 0) anos.append(", ");
            anos.append(Math.abs(t.s8(r, 2)));
            int d = t.u8(r, 0);
            if (d == 255) open = true; else ticks += d;
        }
        return t.rows + (t.rows == 1 ? " passo" : " passos") + " · ANO" + (t.rows == 1 ? " " : "s ") + anos + " · "
                + (open ? "até pousar" : String.format(java.util.Locale.US, "%.1fs no chão", ticks / 60.0));
    }

    /** Candidata a "proxima reacao" (COMP): valor gravado na coluna 11, tabela e resumo. */
    static final class Comp {
        final int value, rows, firstAno;
        final boolean charSrc;
        final String summary;
        Comp(int value, boolean charSrc, ReactionTable t) {
            this.value = value;
            this.charSrc = charSrc;
            this.rows = t.rows;
            this.firstAno = ReactionReplaceScreen.firstAno(t);
            this.summary = ReactionSlots.summary(t);
        }
    }

    /**
     * Reacoes que o COMP pode apontar: aba 0 = do jogo (valores 1..29, que o jogo chama de tipos 1..29) e aba 1 = do personagem (30..49 = tipos 0..19).
     * So as que tem ao menos um passo. O valor 0 (nenhuma) e a opcao a parte do seletor.
     */
    static List<Comp> compCandidates(GameData gd, CharData cd, int tab) {
        List<Comp> out = new ArrayList<Comp>();
        if (tab == 0) {
            for (int v = 1; v < 30 && gd != null; v++) { ReactionTable t = gd.reaction(v); if (!isEmpty(t)) out.add(new Comp(v, false, t)); }
        } else {
            for (int i = 0; i < CharData.REACTION_COUNT && cd != null; i++) { ReactionTable t = cd.reaction(i); if (!isEmpty(t)) out.add(new Comp(30 + i, true, t)); }
        }
        return out;
    }

    /** Aba (0 jogo, 1 personagem) em que o valor COMP esta. */
    static int compTab(int value) { return value >= 30 ? 1 : 0; }

    /** Dados (HDAT) de outro personagem: o 000.bin e, por cima, o 000.bin.txt (como o app faz ao abrir). */
    static CharData readChar(File dir) throws IOException {
        File bin = new File(dir, "000.bin");
        CharData cd = CharData.read(GameData.readAll(bin));
        CharAssets.applyBinTxt(cd, bin);
        return cd;
    }
}
