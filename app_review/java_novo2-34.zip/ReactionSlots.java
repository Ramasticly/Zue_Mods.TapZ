package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Slots de reacao do personagem (HDAT 14..33 = tipos 0..19, OPT 1 30..49): quais estao vazios, resumo de uma tabela e leitura de outro personagem. */
final class ReactionSlots {
    private ReactionSlots() { }

    static boolean isEmpty(ReactionTable t) { return t == null || t.rows <= 0; }

    /** Tipos (0..19) do personagem sem nenhum passo. */
    static List<Integer> emptySlots(CharData cd) {
        List<Integer> out = new ArrayList<Integer>();
        for (int i = 0; i < CharData.REACTION_COUNT; i++) if (isEmpty(cd.reaction(i))) out.add(Integer.valueOf(i));
        return out;
    }

    /** "3 passos · ANOs 20, 4, 7 · 1.2s no chão" (duração do chão somada; 255 = até pousar). */
    static String summary(ReactionTable t) {
        if (isEmpty(t)) return "vazia";
        StringBuilder anos = new StringBuilder();
        int ticks = 0;
        boolean open = false;
        for (int r = 0; r < t.rows; r++) {
            if (r > 0) anos.append(", ");
            anos.append(Math.abs(t.s8(r, 2)));
            int d = t.u8(r, 0);
            if (d == 255) open = true; else ticks += d;
        }
        return t.rows + (t.rows == 1 ? " passo" : " passos") + " · ANO" + (t.rows == 1 ? " " : "s ") + anos + " · "
                + (open ? "até pousar" : String.format(java.util.Locale.US, "%.1fs no chão", ticks / 60.0));
    }

    /** Candidata a "proxima reacao" (COMP): valor gravado na coluna 11, tabela e resumo. */
    static final class Comp {
        final int value, rows, firstAno;
        final boolean charSrc;
        final String summary;
        Comp(int value, boolean charSrc, ReactionTable t) {
            this.value = value;
            this.charSrc = charSrc;
            this.rows = t.rows;
            this.firstAno = ReactionReplaceScreen.firstAno(t);
            this.summary = ReactionSlots.summary(t);
        }
    }

    /**
     * Reacoes que o COMP pode apontar: aba 0 = do jogo (valores 1..29, que o jogo chama de tipos 1..29) e aba 1 = do personagem (30..49 = tipos 0..19).
     * So as que tem ao menos um passo. O valor 0 (nenhuma) e a opcao a parte do seletor.
     */
    static List<Comp> compCandidates(GameData gd, CharData cd, int tab) {
        List<Comp> out = new ArrayList<Comp>();
        if (tab == 0) {
            for (int v = 1; v < 30 && gd != null; v++) { ReactionTable t = gd.reaction(v); if (!isEmpty(t) && !compIsSpecial(v)) out.add(new Comp(v, false, t)); }
        } else {
            for (int i = 0; i < CharData.REACTION_COUNT && cd != null; i++) { ReactionTable t = cd.reaction(i); if (!isEmpty(t)) out.add(new Comp(30 + i, true, t)); }
        }
        return out;
    }

    /** COMP que sao acoes especiais (nao apontam para uma tabela): valor e titulo; ficam no topo da grade. */
    static final int[] COMP_SPECIAL = {11, 12, 50};

    /** O COMP e uma acao especial do jogo (11 deita, 12 quica / levanta, 50 ou mais so pousa e termina)? */
    static boolean compIsSpecial(int value) { return value == 11 || value == 12 || value >= 50; }

    /** Titulo curto do COMP para a grade e o seletor. */
    static String compTitle(int value) {
        if (value == 0) return "Nenhuma";
        if (value == 11) return "11 · faz pousar";
        if (value == 12) return "12 · faz quicar";
        if (value >= 50) return value + " · só pousa e termina";
        return value >= 30 ? "Personagem " + (value - 30) + " (" + value + ")" : "Jogo " + value;
    }

    /** O que o COMP especial faz (uma linha). */
    static String compDetail(int value) {
        if (value == 11) return "Ao pousar fica caído (ANO 24) e a reação termina.";
        if (value == 12) return "Ao pousar quica na reação 12 do jogo; se o jogador apertou A durante a queda, levanta (ANO 22).";
        if (value >= 50) return "Ao tocar o chão só toca o pouso (ANO 13) e termina; não salta para outra reação.";
        if (value == 0) return "Sem próxima reação: ao acabar os passos o oponente levanta ou cai conforme a altura.";
        return "Ao pousar (ou na parede, se o passo tem parede) salta para esta reação.";
    }

    /**
     * Valores que o seletor - N + percorre, em ordem: 0, as acoes especiais (11, 12, 50), depois as reacoes com passos do jogo (1-29, menos 11 e 12, que o COMP nao
     * aponta como tabela) e do personagem (30-49).
     */
    static List<Integer> compSteps(GameData gd, CharData cd) {
        List<Integer> out = new ArrayList<Integer>();
        out.add(Integer.valueOf(0));
        for (int v : COMP_SPECIAL) out.add(Integer.valueOf(v));
        for (Comp c : compCandidates(gd, cd, 0)) if (!compIsSpecial(c.value)) out.add(Integer.valueOf(c.value));
        for (Comp c : compCandidates(gd, cd, 1)) out.add(Integer.valueOf(c.value));
        return out;
    }

    /** Aba (0 jogo, 1 personagem) em que o valor COMP esta. */
    static int compTab(int value) { return value >= 30 ? 1 : 0; }

    /** Dados (HDAT) de outro personagem: o 000.bin e, por cima, o 000.bin.txt (como o app faz ao abrir). */
    static CharData readChar(File dir) throws IOException {
        File bin = new File(dir, "000.bin");
        CharData cd = CharData.read(GameData.readAll(bin));
        CharAssets.applyBinTxt(cd, bin);
        return cd;
    }
}
