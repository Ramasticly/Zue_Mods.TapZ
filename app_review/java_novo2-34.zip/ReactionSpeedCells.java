package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Celulas das faixas SPEED X / SPEED Y da timeline de reacoes: UMA por passo e por tipo (speed e accel), sem unir passos. Speed e accel do mesmo eixo no mesmo
 * passo caem em linhas diferentes da faixa; em passos diferentes dividem a linha. Java puro.
 */
final class ReactionSpeedCells {
    private ReactionSpeedCells() { }

    static final int SPEED = 0, ACCEL = 1;
    /** Valor efetivo desconhecido. */
    static final int UNKNOWN = Integer.MIN_VALUE;

    static final class Cell {
        int row, kind, line, start, end;
        /** Valor gravado na coluna (-1 mantem, -2 metade). */
        int value;
        String text;
    }

    static final class Result {
        final List<Cell> cells = new ArrayList<Cell>();
        /** Linhas da faixa (1 ou 2). */
        int lines = 1;

        Cell find(int row, int kind) {
            for (Cell c : cells) if (c.row == row && c.kind == kind) return c;
            return null;
        }

        /** A celula que ocupa a linha {@code line} no passo {@code row}, ou null. */
        Cell at(int row, int line) {
            for (Cell c : cells) if (c.row == row && c.line == line) return c;
            return null;
        }
    }

    /** Coluna da aceleracao do eixo: chao 5/6, ar 9/10. */
    static int accelCol(boolean air, int axis) { return ReactionRuns.col(air) + 2 + axis; }

    static String tok(int v) { return v == -1 ? "=" : v == -2 ? "½" : String.valueOf(v); }

    /**
     * @param rowStart inicio (tick) do passo na timeline, -1 se o passo nao foi simulado; {@code rowEnd} o fim (exclusivo)
     * @param effective velocidade efetiva (unidade da tabela) do eixo no inicio do passo, {@link #UNKNOWN} se nao se sabe; usada no "=" (mantem)
     */
    static Result build(ReactionTable t, boolean air, int axis, int[] rowStart, int[] rowEnd, int[] effective) {
        Result res = new Result();
        if (t == null) return res;
        int sc = ReactionRuns.col(air, axis), ac = accelCol(air, axis);
        String ax = axis == ReactionRuns.Y ? "y" : "x";
        int runS = 0, runA = 0;                                      // velocidade / aceleracao correntes: um 0 so aparece se para algo que estava andando
        for (int r = 0; r < t.rows && r < rowStart.length; r++) {
            int sv = t.s8(r, sc), av = t.s8(r, ac);
            boolean showS = (sv == -1 || sv == -2) ? false : sv == 0 ? runS != 0 : true;       // mantem (-1) e metade (-2) nao sao faixa; o 0 so aparece se para algo que andava
            boolean showA = (av == -1 || av == -2) ? false : av == 0 ? runA != 0 : true;
            if (sv == -2) runS /= 2; else if (sv != -1) runS = sv;
            if (av == -2) runA /= 2; else if (av != -1) runA = av;
            if (rowStart[r] < 0 || rowEnd[r] <= rowStart[r]) continue;
            if (showS) {
                Cell c = new Cell();
                c.row = r; c.kind = SPEED; c.start = rowStart[r]; c.end = rowEnd[r]; c.value = sv;
                int eff = effective != null && r < effective.length ? effective[r] : UNKNOWN;
                c.text = ax + " " + (sv == -1 ? "=" + (eff == UNKNOWN ? "" : String.valueOf(eff)) : sv == -2 ? "½" + (eff == UNKNOWN ? "" : " " + eff) : String.valueOf(sv));
                res.cells.add(c);
            }
            if (showA) {
                Cell c = new Cell();
                c.row = r; c.kind = ACCEL; c.start = rowStart[r]; c.end = rowEnd[r]; c.value = av;
                c.text = "a" + ax + " " + tok(av);
                res.cells.add(c);
            }
        }
        Collections.sort(res.cells, new Comparator<Cell>() {
            public int compare(Cell a, Cell b) { return a.start != b.start ? a.start - b.start : a.kind - b.kind; }
        });
        int[][] spans = new int[res.cells.size()][];
        for (int i = 0; i < spans.length; i++) spans[i] = new int[]{res.cells.get(i).start, res.cells.get(i).end};
        int[] line = ReactionLayout.stack(spans);
        for (int i = 0; i < line.length; i++) { res.cells.get(i).line = line[i]; res.lines = Math.max(res.lines, line[i] + 1); }
        return res;
    }
}
