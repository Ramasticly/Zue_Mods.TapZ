package com.zue.attackeditor;

/**
 * Tabela de reacao de dano: linhas de 14 bytes (HDAT 10-39 do gamedata, HDAT 14-33 do char).
 * Colunas: 0 duracao no chao, 1 duracao no ar (255 = indefinida), 2 ANO (signed; negativo = vira),
 * 3-6 velocidade/aceleracao no chao (X, Y, aX, aY), 7-10 o mesmo no ar, 11 proxima reacao (COMP),
 * 12 tipo de parede (WALL), 13 voz.
 */
public final class ReactionTable {
    public static final int STRIDE = 14;
    private byte[] d;
    public int rows;

    public ReactionTable(byte[] d, int headerRows) {
        this.d = d == null ? new byte[0] : d;
        int byLen = this.d.length / STRIDE;
        this.rows = (headerRows > 0 && headerRows < byLen) ? headerRows : byLen;
    }

    public boolean has(int row) { return row >= 0 && row < rows; }

    /** Byte sem sinal (0..255); 0 se fora da tabela. */
    public int u8(int row, int col) {
        int p = row * STRIDE + col;
        return (row >= 0 && col >= 0 && col < STRIDE && p < d.length) ? (d[p] & 255) : 0;
    }

    /** Byte com sinal (-128..127); 0 se fora da tabela. */
    public int s8(int row, int col) {
        int p = row * STRIDE + col;
        return (row >= 0 && col >= 0 && col < STRIDE && p < d.length) ? d[p] : 0;
    }

    // ---- edicao em runtime (so tabelas do char; as do gamedata sao fixas) ----

    public ReactionTable copy() {
        ReactionTable t = new ReactionTable(d.clone(), 0);
        t.rows = rows;
        return t;
    }

    /** Reacao em branco: 1 passo (ANO 0, 6 ticks no chao e no ar, sem velocidade, sem proxima reacao). */
    public static ReactionTable blank() {
        ReactionTable t = new ReactionTable(new byte[0], 0);
        t.insertRow(-1);
        return t;
    }

    public void restoreFrom(ReactionTable o) {
        d = o.d.clone();
        rows = o.rows;
    }

    public void set(int row, int col, int value) {
        int p = row * STRIDE + col;
        if (row < 0 || row >= rows || col < 0 || col >= STRIDE) return;
        if (p >= d.length) d = java.util.Arrays.copyOf(d, (row + 1) * STRIDE);
        d[p] = (byte) value;
    }

    /** Insere uma linha nova depois de {@code after} (copia a anterior); -1 = no inicio. */
    public void insertRow(int after) {
        byte[] n = new byte[(rows + 1) * STRIDE];
        int at = (after + 1) * STRIDE;
        System.arraycopy(d, 0, n, 0, Math.min(at, d.length));
        if (after >= 0 && after < rows) System.arraycopy(d, after * STRIDE, n, at, STRIDE);
        else { n[at + 2] = 0; n[at] = 6; n[at + 1] = 6; }
        if (at < d.length) System.arraycopy(d, at, n, at + STRIDE, Math.min(d.length, rows * STRIDE) - at);
        d = n;
        rows++;
    }

    public void removeRow(int row) {
        if (rows <= 1 || row < 0 || row >= rows) return;
        byte[] n = new byte[(rows - 1) * STRIDE];
        System.arraycopy(d, 0, n, 0, row * STRIDE);
        System.arraycopy(d, (row + 1) * STRIDE, n, row * STRIDE, (rows - row - 1) * STRIDE);
        d = n;
        rows--;
    }
}
