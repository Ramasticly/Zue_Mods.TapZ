package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.util.List;

/**
 * Timeline de uma reacao de dano, no estilo da {@link TimelineView} (mesmas medidas de {@link ReactionLayout}): uma faixa de clipes
 * (um por passo da tabela, com a miniatura do ANO do oponente) e, abaixo, as faixas SPEED (blocos em corridas), VOZ, EFEITOS (parede),
 * SEQ (proxima reacao) e CURVA (x e y em px/tick, so leitura). Fechada, mostra so uma linha de resumo por faixa com dados.
 * O ponteiro fica no centro; arrastar rola (e leva a previa junto); pinca faz zoom; arrastar na vertical rola as faixas.
 * Tocar no clipe fechado abre as faixas; aberto, seleciona o passo. Tocar num item (ou celula vazia) de uma faixa abre o menu dele.
 */
final class ReactionTimelineView extends View {
    static final int LANE_PASSOS = ReactionLayout.L_CLIP, LANE_SPEED = ReactionLayout.L_SPEED, LANE_VOZ = ReactionLayout.L_VOZ,
            LANE_EFEITOS = ReactionLayout.L_EFEITOS, LANE_SEQ = ReactionLayout.L_SEQ, LANE_CURVA = ReactionLayout.L_CURVA;

    interface Listener {
        /** Tocou num passo da tabela editada (faixa aberta): selecionar e abrir o menu. */
        void onSelectRow(int row);
        /** Arrastou o ponteiro para o tick (estado depois de {@code tick} ticks). */
        void onScrub(int tick);
        /** Soltou a borda de um passo: nova duracao em ticks (no cenario atual). */
        void onResize(int row, int ticks);
        /** Tocou num item (ou celula vazia) de uma faixa que nao e a dos passos. */
        void onOpenLane(int lane, int row);
        /** Soltou a borda direita de um bloco SPEED: o bloco {@code run} (ver {@link ReactionRuns#runs}) passa a terminar no passo {@code newEnd} (exclusivo). */
        void onResizeRun(int run, int newEnd);
    }

    private static final int C_CLIP = 0xFFE5C100, C_OTHER = 0xFF3A4150, C_SPEED = 0xFF3DDC84, C_VOICE = 0xFF3D8BFF, C_WALL = 0xFFFF9A3C, C_SEQ = 0xFFFF5D8F,
            C_VX = 0xFFFF8A66, C_VY = 0xFF3DDC84;
    private static final int[] LANE_COLORS = {C_CLIP, C_SPEED, C_VOICE, C_WALL, C_SEQ, 0xFF8A90A0};
    private static final float HANDLE_DP = 16;

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Rect sr = new Rect();
    private final Path path = new Path();
    private final ScaleGestureDetector scaler;
    private Listener listener;

    private ReactionTrace trace;
    private ReactionTable table;
    private boolean charSrc, air, editable;
    private int type;
    private Dac opDac;
    private SpriteCache opSprites;
    private int sel = -1;
    private int selLane = LANE_PASSOS;
    private float playTick;
    private float ppt;

    private final boolean[] show = {true, true, true, true, true};
    private final boolean[] has = new boolean[ReactionLayout.LANES];
    private boolean expanded = true;
    private List<ReactionLayout.Row> rows = new java.util.ArrayList<ReactionLayout.Row>();
    private float scrollDp, viewDp, maxDp;

    private static final int M_NONE = 0, M_SCRUB = 1, M_RESIZE = 2, M_RUN = 3, M_VSCROLL = 4, M_PARENT = 5;
    private int mode;
    private float downX, downY, lastY, downTick;
    private boolean moved, scaling;
    private int resizeRow, resizeBase, resizeDur;
    private int runIdx, runBase, runTarget;

    ReactionTimelineView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        ppt = 5f * d;
        t.setTextSize(9f * d);
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector g) {
                ppt = Math.max(1.2f * d, Math.min(16f * d, ppt * g.getScaleFactor()));
                invalidate();
                return true;
            }
        });
    }

    void setListener(Listener l) { listener = l; }

    void setOpponent(Dac dac, SpriteCache sprites) { opDac = dac; opSprites = sprites; }

    /** {@code table}: a tabela mostrada (type/charSrc a identificam); {@code air}: cenario que o trace simulou; {@code editable}: libera arrastar a duracao. */
    void setData(ReactionTrace tr, ReactionTable table, boolean charSrc, int type, boolean air) {
        this.trace = tr;
        this.table = table;
        this.charSrc = charSrc;
        this.editable = charSrc;
        this.type = type;
        this.air = air;
        rebuild();
        invalidate();
    }

    void setSelected(int row) { if (row != sel) { sel = row; invalidate(); } }

    /** Faixa do item selecionado (o passo selecionado fica destacado nessa faixa). */
    void setSelectedLane(int lane) { if (lane != selLane) { selLane = lane; invalidate(); } }

    boolean isExpanded() { return expanded; }

    void setExpanded(boolean e) {
        if (e == expanded) return;
        expanded = e;
        rebuild();
        invalidate();
    }

    boolean isShown(int i) { return show[i]; }

    void setShown(int i, boolean on) {
        if (show[i] == on) return;
        show[i] = on;
        rebuild();
        invalidate();
    }

    void showAll() {
        for (int i = 0; i < show.length; i++) show[i] = true;
        rebuild();
        invalidate();
    }

    /** Teto de altura (px) conforme a area visivel da tela; 0 = so o teto padrao de 188 dp. */
    void setMaxHeightPx(int px) {
        float dp = px <= 0 ? ReactionLayout.CAP : Math.min(ReactionLayout.CAP, Math.max(px / d, 96f));
        if (Math.abs(dp - maxDp) < 0.5f) return;
        maxDp = dp;
        rebuild();
        invalidate();
    }

    /** Ponteiro em ticks (pode ser fracionario durante o play). */
    void setPointer(float tick) {
        float mx = Math.max(0, trace == null ? 0 : trace.ticks.size());
        playTick = Math.max(0f, Math.min(mx, tick));
        invalidate();
    }

    int pointerTick() { return Math.round(playTick); }

    /** Trecho (da tabela editada) que processa o tick {@code tick}, ou null. */
    ReactionTrace.Seg segAt(int tick) {
        if (trace == null) return null;
        for (ReactionTrace.Seg s : trace.segments) if (tick >= s.start && tick < s.end) return s;
        return null;
    }

    boolean isOwn(ReactionTrace.Seg s) { return s != null && s.charSrc == charSrc && s.type == type; }

    // ---- linhas (ReactionLayout) ----

    private void rebuild() {
        java.util.Arrays.fill(has, false);
        if (table != null) {
            has[LANE_SPEED] = !ReactionRuns.runs(table, air).isEmpty();
            for (int r = 0; r < table.rows; r++) {
                if (table.s8(r, 13) > 0) has[LANE_VOZ] = true;
                if (table.u8(r, 12) > 0) has[LANE_EFEITOS] = true;
                if (table.u8(r, 11) > 0) has[LANE_SEQ] = true;
            }
        }
        if (maxDp <= 0) maxDp = ReactionLayout.CAP;
        rows = ReactionLayout.body(show, expanded, has);
        float want = ReactionLayout.viewH(rows, maxDp);
        if (Math.abs(want - viewDp) > 0.5f) { viewDp = want; requestLayout(); }
        scrollDp = ReactionLayout.clampScroll(rows, viewDp, scrollDp);
        ReactionLayout.place(rows, scrollDp);
    }

    @Override protected void onMeasure(int ws, int hs) {
        if (viewDp <= 0) rebuild();
        setMeasuredDimension(MeasureSpec.getSize(ws), Math.round(viewDp * d));
    }

    private float gutter() { return 58f * d; }
    private float contentW() { return Math.max(1f, getWidth() - gutter()); }
    private float xOf(float tick) { return gutter() + contentW() / 2f + (tick - playTick) * ppt; }
    private float tickAt(float x) { return playTick + (x - gutter() - contentW() / 2f) / ppt; }
    private float bodyTopPx() { return ReactionLayout.bodyTop() * d; }

    private ReactionLayout.Row rowOf(int lane) {
        for (ReactionLayout.Row r : rows) if (r.lane == lane) return r;
        return null;
    }

    private static String tok(int v) { return v == -1 ? "=" : v == -2 ? "½" : String.valueOf(v); }

    private String clip(String s, float w) {
        if (t.measureText(s) <= w) return s;
        int n = s.length();
        while (n > 1 && t.measureText(s, 0, n) + t.measureText("…") > w) n--;
        return s.substring(0, n) + "…";
    }

    private ReactionTrace.Seg segOfRow(int row) {
        if (trace == null) return null;
        for (ReactionTrace.Seg s : trace.segments) if (isOwn(s) && s.row == row) return s;
        return null;
    }

    // ---- desenho ----

    @Override protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight(), g = gutter();
        c.drawColor(0xFF12151A);
        if (trace == null || table == null) {
            t.setColor(0xFF4A505E);
            c.drawText("sem reação", g + 8 * d, 60 * d, t);
            return;
        }
        int total = trace.ticks.size();
        c.save();
        c.clipRect(g, 0, W, H);
        ruler(c, W, H);
        // fora da reacao escurece
        p.setColor(0x88000000);
        c.drawRect(g, ReactionLayout.RULER * d, Math.min(W, xOf(0)), H, p);
        if (xOf(total) < W) c.drawRect(Math.max(g, xOf(total)), ReactionLayout.RULER * d, W, H, p);
        // passo sob o ponteiro
        ReactionTrace.Seg cur = segAt(pointerTick());
        if (cur != null) {
            p.setColor(0x16FFFFFF);
            c.drawRect(xOf(cur.start), ReactionLayout.RULER * d, xOf(cur.end), H, p);
        }
        clips(c);
        c.save();
        c.clipRect(g, bodyTopPx(), W, H);
        for (ReactionLayout.Row r : rows) {
            float top = r.top * d, bot = (r.top + r.h) * d;
            if (bot < bodyTopPx() || top > H) continue;
            stripe(c, top, bot);
            switch (r.lane) {
                case LANE_SPEED: speedRow(c, r); break;
                case LANE_VOZ: chipRow(c, r, C_VOICE); break;
                case LANE_EFEITOS: chipRow(c, r, C_WALL); break;
                case LANE_SEQ: chipRow(c, r, C_SEQ); break;
                default: curveRow(c, r, total); break;
            }
        }
        // fronteiras do inicio e do fim da reacao
        p.setColor(0x55FFFFFF);
        p.setStrokeWidth(1f * d);
        c.drawLine(xOf(0), ReactionLayout.RULER * d, xOf(0), H, p);
        c.drawLine(xOf(total), ReactionLayout.RULER * d, xOf(total), H, p);
        guides(c, W, H);
        c.restore();
        // ponteiro
        float px = g + contentW() / 2f;
        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(1.5f * d);
        c.drawLine(px, 0, px, H, p);
        path.reset();
        path.moveTo(px - 5 * d, 0);
        path.lineTo(px + 5 * d, 0);
        path.lineTo(px, 6 * d);
        path.close();
        c.drawPath(path, p);
        c.restore();
        gutterColumn(c, H);
        scrollBar(c, W, H);
    }

    private void stripe(Canvas c, float top, float bot) {
        p.setColor(0x0DFFFFFF);
        c.drawRect(gutter(), top, getWidth(), bot - 1, p);
    }

    private void ruler(Canvas c, float W, float H) {
        float g = gutter();
        int[] steps = {1, 2, 5, 10, 30, 60, 120};
        int step = 120;
        for (int s : steps) if (s * ppt >= 26f * d) { step = s; break; }
        int first = (int) Math.floor(tickAt(g) / step) * step;
        t.setColor(0xFF8A90A0);
        t.setTextSize(9.5f * d);
        p.setColor(0x33FFFFFF);
        p.setStrokeWidth(1f);
        for (int k = Math.max(0, first); xOf(k) < W; k += step) {
            float x = xOf(k);
            if (x < g) continue;
            c.drawLine(x, ReactionLayout.RULER * d - 4 * d, x, H, p);
            c.drawText(k % 60 == 0 && k > 0 ? (k / 60) + "s" : String.valueOf(k), x + 2 * d, 11 * d, t);
        }
    }

    /** Coluna dos nomes das faixas (como a da principal) e o cabecalho "REACAO n". */
    private void gutterColumn(Canvas c, float H) {
        float g = gutter();
        p.setColor(0xFF0E1015);
        c.drawRect(0, 0, g, H, p);
        c.save();
        c.clipRect(0, bodyTopPx(), g, H);
        for (ReactionLayout.Row r : rows) {
            float top = r.top * d, bot = (r.top + r.h) * d;
            if (bot < bodyTopPx() || top > H) continue;
            t.setColor(LANE_COLORS[r.lane]);
            t.setTextSize(r.summary ? 7.5f * d : 9f * d);
            c.drawText(clip(ReactionLayout.NAMES[r.lane], g - 8 * d), 4 * d, (top + bot) / 2f + 3f * d, t);
        }
        c.restore();
        t.setColor(0xFFE6E8EC);
        t.setTextSize(11f * d);
        t.setFakeBoldText(true);
        c.drawText(clip((charSrc ? "REAÇÃO " : "JOGO ") + type, g - 8 * d), 4 * d, ReactionLayout.RULER * d / 2f + 4 * d, t);
        t.setFakeBoldText(false);
        float top = ReactionLayout.RULER * d;
        t.setColor(C_CLIP);
        t.setTextSize(9.5f * d);
        c.drawText("PASSOS", 4 * d, top + ReactionLayout.CLIP * d / 2f - 2 * d, t);
        t.setColor(0xFF6B7280);
        t.setTextSize(8f * d);
        c.drawText(expanded ? "toque p/ fechar" : "toque p/ abrir", 4 * d, top + ReactionLayout.CLIP * d / 2f + 9 * d, t);
        t.setTextSize(9f * d);
    }

    private void scrollBar(Canvas c, float W, float H) {
        float viewH = H - bodyTopPx();
        float content = ReactionLayout.contentH(rows) * d;
        if (content <= viewH + 1) return;
        float th = Math.max(16 * d, viewH * viewH / content);
        float ty = bodyTopPx() + (viewH - th) * (scrollDp * d / Math.max(1f, content - viewH));
        p.setColor(0x55FFFFFF);
        c.drawRoundRect(W - 3 * d, ty, W - 1 * d, ty + th, d, d, p);
    }

    // ---- faixa de clipes: passos ----

    private void clips(Canvas c) {
        float top = ReactionLayout.RULER * d, h = ReactionLayout.CLIP * d, g = gutter(), W = getWidth();
        for (ReactionTrace.Seg s : trace.segments) {
            boolean own = isOwn(s);
            float x0 = xOf(s.start), x1 = xOf(s.end);
            if (x1 < g || x0 > W) continue;
            boolean isSel = own && s.row == sel && selLane == LANE_PASSOS;
            p.setColor(own ? C_CLIP : C_OTHER);
            p.setAlpha(isSel ? 255 : own ? (s.row == sel ? 230 : 185) : 255);
            rf.set(x0 + 1, top + 2 * d, Math.max(x0 + 3 * d, x1 - 1), top + h - 2 * d);
            c.drawRoundRect(rf, 4 * d, 4 * d, p);
            p.setAlpha(255);
            if (isSel) {
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFFFFFFFF);
                p.setStrokeWidth(1.5f * d);
                c.drawRoundRect(rf, 4 * d, 4 * d, p);
                p.setStyle(Paint.Style.FILL);
            }
            c.save();
            c.clipRect(rf);
            float tx = rf.left + 3 * d, box = h - 8 * d;
            if (own) {
                int ano = table.s8(s.row, 2);
                if (rf.width() > box + 4 * d) {
                    drawThumb(c, Math.abs(ano), tx, top + 4 * d, box, ano < 0);
                    tx += box + 3 * d;
                }
                if (rf.right - tx > 14 * d) {
                    t.setColor(0xFF1A1500);
                    t.setFakeBoldText(true);
                    t.setTextSize(9.5f * d);
                    c.drawText("passo " + (s.row + 1) + (ano < 0 ? " ⇄" : ""), tx, top + h / 2f - 2 * d, t);
                    t.setFakeBoldText(false);
                    t.setTextSize(8f * d);
                    int dur = table.u8(s.row, ReactionEdit.durColumn(air));
                    c.drawText("ANO " + Math.abs(ano) + " · " + (dur == 255 ? "até pousar " : "") + s.length() + "t", tx, top + h / 2f + 9 * d, t);
                    t.setTextSize(9f * d);
                }
            } else if (rf.width() > 14 * d) {
                t.setColor(0xFFFFFFFF);
                t.setTextSize(8f * d);
                c.drawText("→ " + (s.charSrc ? "pers. " : "jogo ") + s.type, tx, top + h / 2f + 3 * d, t);
                t.setTextSize(9f * d);
            }
            c.restore();
            // alca de duracao (borda direita): so no personagem e quando a duracao nao e o 255
            if (own && editable) {
                boolean can = ReactionEdit.canResize(table, s.row, air);
                p.setColor(can ? 0xFF1A1500 : 0x66000000);
                float hx = rf.right - 3 * d;
                c.drawRoundRect(hx - 1.5f * d, rf.centerY() - 8 * d, hx + 1.5f * d, rf.centerY() + 8 * d, 2 * d, 2 * d, p);
            }
        }
    }

    // ---- faixas ----

    /** Retangulo (px) do trecho do passo {@code row} na linha {@code r}; false se o passo nao aparece. */
    private boolean cellRect(ReactionLayout.Row r, int row, RectF out) {
        ReactionTrace.Seg s = segOfRow(row);
        if (s == null) return false;
        float v = r.summary ? 2 * d : 2 * d;
        out.set(xOf(s.start) + 1, r.top * d + v, Math.max(xOf(s.start) + 4 * d, xOf(s.end) - 1), (r.top + r.h) * d - v);
        return out.right > gutter() && out.left < getWidth();
    }

    private void emptyCell(Canvas c, RectF r) {
        p.setColor(0x14FFFFFF);
        c.drawRoundRect(r, 3 * d, 3 * d, p);
        if (r.width() > 18 * d && r.height() > 12 * d) {
            t.setColor(0x66FFFFFF);
            t.setTextSize(8f * d);
            c.drawText("＋", r.left + 4 * d, r.centerY() + 3 * d, t);
            t.setTextSize(9f * d);
        }
    }

    private void chip(Canvas c, RectF r, String text, int color, boolean selected, boolean summary) {
        p.setColor(color);
        p.setAlpha(selected ? 255 : 190);
        c.drawRoundRect(r, summary ? 2 * d : 3 * d, summary ? 2 * d : 3 * d, p);
        p.setAlpha(255);
        if (selected) {
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(1.5f * d);
            c.drawRoundRect(r, 3 * d, 3 * d, p);
            p.setStyle(Paint.Style.FILL);
        }
        if (summary || text == null) return;
        c.save();
        c.clipRect(Math.max(r.left, gutter()), r.top, r.right, r.bottom);
        t.setColor(0xFF10131A);
        t.setTextSize(8f * d);
        t.setFakeBoldText(true);
        c.drawText(text, Math.max(r.left, gutter()) + 3 * d, r.centerY() + 3 * d, t);
        t.setFakeBoldText(false);
        t.setTextSize(9f * d);
        c.restore();
    }

    /** VOZ / EFEITOS / SEQ: um chip por passo que tem o valor; passo sem valor = celula vazia (＋) quando aberta. */
    private void chipRow(Canvas c, ReactionLayout.Row r, int color) {
        RectF cell = new RectF();
        for (ReactionTrace.Seg s : trace.segments) {
            if (!isOwn(s) || !cellRect(r, s.row, cell)) continue;
            String text = null;
            if (r.lane == LANE_VOZ) { int v = table.s8(s.row, 13); if (v > 0) text = "♪ " + v; }
            else if (r.lane == LANE_EFEITOS) { int w = table.u8(s.row, 12); if (w > 0) text = "parede " + w; }
            else { int comp = table.u8(s.row, 11); if (comp > 0) text = "→ " + (comp >= 30 ? "pers. " + (comp - 30) : "jogo " + comp); }
            if (text == null) { if (!r.summary) emptyCell(c, cell); continue; }
            chip(c, cell, text, color, selLane == r.lane && s.row == sel, r.summary);
        }
    }

    /** SPEED: um bloco por corrida (passo com velocidade propria + os que a mantem); passos antes da 1a velocidade = celula vazia. */
    private void speedRow(Canvas c, ReactionLayout.Row r) {
        RectF cell = new RectF();
        List<int[]> rs = ReactionRuns.runs(table, air);
        int b = ReactionRuns.col(air);
        int selRun = selLane == LANE_SPEED ? ReactionRuns.runOf(table, air, sel) : -2;
        for (ReactionTrace.Seg s : trace.segments) {
            if (!isOwn(s) || r.summary || ReactionRuns.runOf(table, air, s.row) >= 0 || !cellRect(r, s.row, cell)) continue;
            emptyCell(c, cell);
        }
        for (int i = 0; i < rs.size(); i++) {
            int[] run = rs.get(i);
            ReactionTrace.Seg a = segOfRow(run[0]), z = segOfRow(run[1] - 1);
            if (a == null || z == null) continue;
            float x1 = xOf(z.end);
            if (mode == M_RUN && i == runIdx) {
                ReactionTrace.Seg e = segOfRow(runTarget - 1);
                if (e != null) x1 = xOf(e.end);
            }
            float x0 = xOf(a.start);
            if (x1 < gutter() || x0 > getWidth()) continue;
            float v = 2 * d;
            cell.set(x0 + 1, r.top * d + v, Math.max(x0 + 4 * d, x1 - 1), (r.top + r.h) * d - v);
            String txt = "v " + tok(table.s8(run[0], b)) + "," + tok(table.s8(run[0], b + 1));
            if (table.s8(run[0], b + 2) != 0 || table.s8(run[0], b + 3) != 0) txt += "  a " + tok(table.s8(run[0], b + 2)) + "," + tok(table.s8(run[0], b + 3));
            chip(c, cell, txt, C_SPEED, i == selRun, r.summary);
            if (editable && !r.summary) {
                p.setColor(0xFF10131A);
                float hx = cell.right - 3 * d;
                c.drawRoundRect(hx - 1.5f * d, cell.centerY() - 5 * d, hx + 1.5f * d, cell.centerY() + 5 * d, 2 * d, 2 * d, p);
            }
        }
    }

    /** Curva de x e y em px/tick (so leitura). */
    private void curveRow(Canvas c, ReactionLayout.Row r, int total) {
        float top = r.top * d, h = r.h * d, mid = top + h / 2f;
        float max = 1f;
        for (BattleSim.DamageTick k : trace.ticks) max = Math.max(max, Math.max(Math.abs(k.xs / 128f), Math.abs(k.ys / 128f)));
        float amp = h / 2f - 4 * d;
        p.setColor(0x44FFFFFF);
        p.setStrokeWidth(1f);
        c.drawLine(gutter(), mid, getWidth(), mid, p);
        t.setColor(0xFF8A90A0);
        t.setTextSize(7f * d);
        c.drawText("±" + (Math.round(max * 10f) / 10f) + " px/t", gutter() + 3 * d, top + h - 3 * d, t);
        t.setTextSize(9f * d);
        for (int line = 0; line < 2; line++) {
            p.setColor(line == 0 ? C_VX : C_VY);
            p.setStrokeWidth(1.6f * d);
            float py = 0;
            boolean first = true;
            for (int i = 0; i < total; i++) {
                BattleSim.DamageTick k = trace.ticks.get(i);
                float v = (line == 0 ? k.xs : k.ys) / 128f;
                float x0 = xOf(i), x1 = xOf(i + 1), y = mid - v / max * amp;
                if (x1 < gutter() || x0 > getWidth()) { py = y; first = false; continue; }
                if (!first && py != y) c.drawLine(x0, py, x0, y, p);
                c.drawLine(x0, y, x1, y, p);
                py = y;
                first = false;
            }
        }
        p.setStrokeWidth(1f);
        t.setColor(C_VX);
        c.drawText("x", gutter() + 3 * d, top + 9 * d, t);
        t.setColor(C_VY);
        c.drawText("y", gutter() + 11 * d, top + 9 * d, t);
    }

    /** Linha-guia e valor da alca em uso (duracao do passo ou fim do bloco SPEED). */
    private void guides(Canvas c, float W, float H) {
        if (mode == M_RESIZE) {
            ReactionTrace.Seg s = segOfRow(resizeRow);
            if (s != null) {
                float gx = xOf(s.start + resizeDur * (s.length() / (float) Math.max(1, resizeBase)));
                p.setColor(0xFFFFD84C);
                p.setStrokeWidth(2f * d);
                c.drawLine(gx, ReactionLayout.RULER * d, gx, H, p);
                t.setColor(0xFFFFD84C);
                t.setFakeBoldText(true);
                c.drawText(resizeDur + " ticks", Math.min(gx + 3 * d, W - 52 * d), ReactionLayout.RULER * d + 11 * d, t);
                t.setFakeBoldText(false);
            }
        } else if (mode == M_RUN) {
            ReactionTrace.Seg s = segOfRow(runTarget - 1);
            ReactionLayout.Row r = rowOf(LANE_SPEED);
            if (s != null && r != null) {
                float gx = xOf(s.end);
                p.setColor(0xFFFFD84C);
                p.setStrokeWidth(2f * d);
                c.drawLine(gx, r.top * d, gx, (r.top + r.h) * d, p);
                t.setColor(0xFFFFD84C);
                t.setFakeBoldText(true);
                c.drawText("até o passo " + runTarget, Math.min(gx + 3 * d, W - 70 * d), (r.top + r.h) * d - 2 * d, t);
                t.setFakeBoldText(false);
            }
        }
    }

    private void drawThumb(Canvas c, int ano, float x, float y, float box, boolean flip) {
        p.setColor(0x33000000);
        c.drawRect(x, y, x + box, y + box, p);
        if (opDac == null || opSprites == null) return;
        Ano a = opDac.getAno(ano);
        if (a == null || !a.present || a.mpts.length == 0 || a.mpts[0].image < 0) return;
        SpriteCache.Sprite sp = null;
        try { sp = opSprites.get(a.mpts[0].image); } catch (Exception ignored) { }
        if (sp == null || sp.bitmap == null) return;
        float sw = sp.src.width(), sh = sp.src.height();
        float k = Math.min(box / Math.max(1f, sw), box / Math.max(1f, sh));
        float dw = sw * k, dh = sh * k, cx = x + box / 2f, cy = y + box / 2f;
        rf.set(cx - dw / 2f, cy - dh / 2f, cx + dw / 2f, cy + dh / 2f);
        sr.set(sp.src);
        c.save();
        if (flip) c.scale(-1f, 1f, cx, cy);
        c.drawBitmap(sp.bitmap, sr, rf, null);
        c.restore();
    }

    // ---- toque ----

    private float runEndX(int[] run) {
        ReactionTrace.Seg z = segOfRow(run[1] - 1);
        return z == null ? Float.NaN : xOf(z.end);
    }

    /** Fronteira entre passos (indice do passo seguinte, exclusivo) mais perto de x, da fronteira do inicio da corrida + 1 em diante. */
    private int nearestBoundary(float x) {
        List<int[]> rs = ReactionRuns.runs(table, air);
        int lo = runIdx < rs.size() ? rs.get(runIdx)[0] + 1 : 1, best = lo;
        float bd = Float.MAX_VALUE;
        for (int k = lo; k <= table.rows; k++) {
            ReactionTrace.Seg sg = segOfRow(k - 1);
            if (sg == null) continue;
            float dx = Math.abs(xOf(sg.end) - x);
            if (dx < bd) { bd = dx; best = k; }
        }
        return best;
    }

    private boolean scrollable() { return ReactionLayout.maxScroll(rows, viewDp) > 0.5f; }

    private void scrollBy(float dyPx) {
        scrollDp = ReactionLayout.clampScroll(rows, viewDp, scrollDp - dyPx / d);
        ReactionLayout.place(rows, scrollDp);
        invalidate();
    }

    /** Alcas de arrastar: borda direita de um passo (duracao) ou de um bloco SPEED. */
    private void startEdit(float x, float y) {
        if (!editable || trace == null) return;
        int lane = ReactionLayout.laneAt(rows, y / d);
        if (lane == LANE_PASSOS) {
            for (ReactionTrace.Seg s : trace.segments) {
                if (!isOwn(s) || !ReactionEdit.canResize(table, s.row, air)) continue;
                float ex = xOf(s.end);
                if (x >= ex - HANDLE_DP * d && x <= ex + 8 * d && ex > gutter()) {
                    mode = M_RESIZE;
                    resizeRow = s.row;
                    resizeBase = Math.max(1, table.u8(s.row, ReactionEdit.durColumn(air)));
                    resizeDur = resizeBase;
                    return;
                }
            }
        } else if (lane == LANE_SPEED) {
            List<int[]> rs = ReactionRuns.runs(table, air);
            for (int i = 0; i < rs.size(); i++) {
                float ex = runEndX(rs.get(i));
                if (Float.isNaN(ex) || ex <= gutter()) continue;
                if (x >= ex - HANDLE_DP * d && x <= ex + 8 * d) {
                    mode = M_RUN;
                    runIdx = i;
                    runBase = rs.get(i)[1];
                    runTarget = runBase;
                    return;
                }
            }
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (trace == null || table == null) return true;
        scaler.onTouchEvent(e);
        if (scaler.isInProgress() || e.getPointerCount() > 1) { scaling = true; mode = M_NONE; return true; }
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                downX = x;
                downY = lastY = y;
                downTick = playTick;
                moved = false;
                scaling = false;
                mode = M_NONE;
                if (x >= gutter()) startEdit(x, y);
                else if (y > bodyTopPx()) mode = M_VSCROLL;
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (scaling) return true;
                float dy = y - lastY;
                lastY = y;
                if (Math.abs(x - downX) > 6 * d || Math.abs(y - downY) > 6 * d) moved = true;
                if (mode == M_RESIZE) {
                    resizeDur = ReactionEdit.dragged(resizeBase, x - downX, ppt);
                    invalidate();
                } else if (mode == M_RUN) {
                    runTarget = nearestBoundary(x);
                    invalidate();
                } else if (mode == M_VSCROLL) {
                    scrollBy(dy);
                } else if (moved && mode != M_PARENT) {
                    if (mode == M_NONE) {
                        // trava a direcao no primeiro movimento: vertical ganha com folga (angulo > ~35 graus)
                        float ax = Math.abs(x - downX), ay = Math.abs(y - downY);
                        if (ay > ax * 0.7f) {
                            if (downY > bodyTopPx() && scrollable()) mode = M_VSCROLL;
                            else {                        // nada para rolar aqui: a rolagem da pagina assume
                                mode = M_PARENT;
                                getParent().requestDisallowInterceptTouchEvent(false);
                                return true;
                            }
                        } else mode = M_SCRUB;
                    }
                    if (mode == M_VSCROLL) scrollBy(dy);
                    else if (mode == M_SCRUB) {
                        setPointer(downTick - (x - downX) / ppt);
                        if (listener != null) listener.onScrub(pointerTick());
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                finish(x, y);
                return true;
            case MotionEvent.ACTION_CANCEL:
                mode = M_NONE;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void finish(float x, float y) {
        int m = mode;
        mode = M_NONE;
        if (m == M_RESIZE) {
            int row = resizeRow, nd = resizeDur, base = resizeBase;
            invalidate();
            if (moved && nd != base && listener != null) listener.onResize(row, nd);
            else if (listener != null) listener.onSelectRow(row);
            return;
        }
        if (m == M_RUN) {
            int run = runIdx, nt = runTarget, base = runBase;
            invalidate();
            if (moved && nt != base && listener != null) listener.onResizeRun(run, nt);
            else if (listener != null) {
                List<int[]> rs = ReactionRuns.runs(table, air);
                listener.onOpenLane(LANE_SPEED, run < rs.size() ? rs.get(run)[0] : 0);
            }
            return;
        }
        invalidate();
        if (moved || scaling) return;
        int lane = ReactionLayout.laneAt(rows, y / d);
        if (x < gutter()) {                                  // cabecalho dos clipes: abre / fecha as faixas
            if (lane == LANE_PASSOS) setExpanded(!expanded);
            return;
        }
        ReactionTrace.Seg s = segAt((int) Math.floor(tickAt(x)));
        if (!isOwn(s) || listener == null) return;
        if (lane == LANE_PASSOS) {
            if (!expanded) {                                 // fechada: leva o ponteiro ate o passo e abre as faixas, sem abrir o menu
                setPointer(s.start);
                listener.onScrub(s.start);
                setExpanded(true);
            } else listener.onSelectRow(s.row);
        } else if (lane == LANE_SPEED || lane == LANE_VOZ || lane == LANE_EFEITOS || lane == LANE_SEQ) {
            listener.onOpenLane(lane, s.row);
        }
    }
}
