package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * Timeline de uma reacao de dano, no estilo da timeline do editor: o que {@link ReactionTrace} mostra que o jogo faz, tick a tick.
 * Faixas: PASSOS (uma caixa por linha da tabela, com a miniatura do ANO do oponente; arraste a borda direita para mudar a duracao),
 * SPEED (curva de x e y em px/tick e os valores v/a do passo), VOZ, EFEITOS (parede) e SEQ (proxima reacao).
 * O ponteiro fica no centro; arrastar rola (e leva a previa junto); pinca faz zoom; tocar num passo o seleciona e tocar num item das outras
 * faixas abre a aba dele (tocar numa celula vazia abre para adicionar).
 */
final class ReactionTimelineView extends View {
    static final int LANE_PASSOS = 0, LANE_SPEED = 1, LANE_VOZ = 2, LANE_EFEITOS = 3, LANE_SEQ = 4;

    interface Listener {
        /** Tocou num passo da tabela editada. */
        void onSelectRow(int row);
        /** Arrastou o ponteiro para o tick (estado depois de {@code tick} ticks). */
        void onScrub(int tick);
        /** Soltou a borda de um passo: nova duracao em ticks (no cenario atual). */
        void onResize(int row, int ticks);
        /** Tocou num item (ou celula vazia) de uma faixa que nao e a dos passos. */
        void onOpenLane(int lane, int row);
    }

    private static final float RULER_DP = 16;
    private static final float[] LANE_DP = {56, 52, 20, 20, 20};
    private static final String[] LANE_NAMES = {"PASSOS", "SPEED", "VOZ", "EFEITOS", "SEQ"};
    private static final int C_OWN = 0xFF3A6EA5, C_OWN_SEL = 0xFF4C8DFF, C_OTHER = 0xFF3A4150, C_VX = 0xFFFF8A66, C_VY = 0xFF3DDC84, C_VOICE = 0xFFB07CFF, C_WALL = 0xFFFF5D8F, C_SEQ = 0xFFFFB454;
    private static final float HANDLE_DP = 16;

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Rect sr = new Rect();
    private final Path path = new Path();
    private final ScaleGestureDetector scaler;
    private Listener listener;

    private ReactionTrace trace;
    private ReactionTable table;
    private boolean charSrc, air, editable;
    private int type;
    private Dac opDac;
    private SpriteCache opSprites;
    private int sel = -1;
    private float playTick;
    private float ppt;

    private static final int M_NONE = 0, M_SCRUB = 1, M_RESIZE = 2;
    private int mode;
    private float downX, downY, downTick;
    private boolean moved, scaling;
    private int resizeRow, resizeBase, resizeDur;

    ReactionTimelineView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        ppt = 5f * d;
        t.setTextSize(9f * d);
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector g) {
                ppt = Math.max(1.2f * d, Math.min(16f * d, ppt * g.getScaleFactor()));
                invalidate();
                return true;
            }
        });
    }

    void setListener(Listener l) { listener = l; }

    void setOpponent(Dac dac, SpriteCache sprites) { opDac = dac; opSprites = sprites; }

    /** {@code table}: a tabela mostrada (type/charSrc a identificam); {@code air}: cenario que o trace simulou; {@code editable}: libera arrastar a duracao. */
    void setData(ReactionTrace tr, ReactionTable table, boolean charSrc, int type, boolean air) {
        this.trace = tr;
        this.table = table;
        this.charSrc = charSrc;
        this.editable = charSrc;
        this.type = type;
        this.air = air;
        requestLayout();
        invalidate();
    }

    void setSelected(int row) { if (row != sel) { sel = row; invalidate(); } }

    /** Ponteiro em ticks (pode ser fracionario durante o play). */
    void setPointer(float tick) {
        float mx = Math.max(0, trace == null ? 0 : trace.ticks.size());
        playTick = Math.max(0f, Math.min(mx, tick));
        invalidate();
    }

    int pointerTick() { return Math.round(playTick); }

    /** Trecho (da tabela editada) que processa o tick {@code tick}, ou null. */
    ReactionTrace.Seg segAt(int tick) {
        if (trace == null) return null;
        for (ReactionTrace.Seg s : trace.segments) if (tick >= s.start && tick < s.end) return s;
        return null;
    }

    boolean isOwn(ReactionTrace.Seg s) { return s != null && s.charSrc == charSrc && s.type == type; }

    @Override protected void onMeasure(int ws, int hs) {
        float h = RULER_DP;
        for (float v : LANE_DP) h += v;
        setMeasuredDimension(MeasureSpec.getSize(ws), Math.round(h * d));
    }

    private float gutter() { return 52f * d; }
    private float contentW() { return Math.max(1f, getWidth() - gutter()); }
    private float xOf(float tick) { return gutter() + contentW() / 2f + (tick - playTick) * ppt; }
    private float tickAt(float x) { return playTick + (x - gutter() - contentW() / 2f) / ppt; }

    private float laneTop(int lane) {
        float y = RULER_DP;
        for (int i = 0; i < lane; i++) y += LANE_DP[i];
        return y * d;
    }
    private float laneH(int lane) { return LANE_DP[lane] * d; }

    /** Faixa na altura y, ou -1 (regua). */
    private int laneAt(float y) {
        for (int i = 0; i < LANE_DP.length; i++) if (y >= laneTop(i) && y < laneTop(i) + laneH(i)) return i;
        return -1;
    }

    private static String tok(int v) { return v == -1 ? "=" : v == -2 ? "½" : String.valueOf(v); }

    @Override protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight(), g = gutter();
        c.drawColor(0xFF14161B);
        if (trace == null || table == null) {
            t.setColor(0xFF8A90A0);
            c.drawText("sem reacao", 8 * d, H / 2f, t);
            return;
        }
        for (int i = 0; i < LANE_NAMES.length; i++) {
            p.setColor(i % 2 == 0 ? 0xFF181B21 : 0xFF1B1F27);
            c.drawRect(0, laneTop(i), W, laneTop(i) + laneH(i), p);
            t.setColor(0xFF8A90A0);
            t.setTextSize(8f * d);
            c.drawText(LANE_NAMES[i], 4 * d, laneTop(i) + laneH(i) / 2f + 3 * d, t);
        }
        t.setTextSize(9f * d);
        ruler(c);
        c.save();
        c.clipRect(g, 0, W, H);
        int total = trace.ticks.size();
        for (ReactionTrace.Seg s : trace.segments) {
            float x0 = xOf(s.start), x1 = xOf(s.end);
            if (x1 < g || x0 > W) continue;
            segmentBox(c, s, isOwn(s), x0, x1);
        }
        velocity(c, total);
        p.setColor(0x55FFFFFF);
        p.setStrokeWidth(1f * d);
        c.drawLine(xOf(0), RULER_DP * d, xOf(0), H, p);
        c.drawLine(xOf(total), RULER_DP * d, xOf(total), H, p);
        // alca de duracao em uso: linha-guia e o valor novo
        if (mode == M_RESIZE) {
            ReactionTrace.Seg s = segOfRow(resizeRow);
            if (s != null) {
                float gx = xOf(s.start + resizeDur * (s.length() / (float) Math.max(1, resizeBase)));
                p.setColor(0xFFFFD84C);
                p.setStrokeWidth(2f * d);
                c.drawLine(gx, laneTop(0), gx, H, p);
                t.setColor(0xFFFFD84C);
                t.setFakeBoldText(true);
                c.drawText(resizeDur + " ticks", Math.min(gx + 3 * d, W - 52 * d), laneTop(0) + 11 * d, t);
                t.setFakeBoldText(false);
            }
        }
        c.restore();
        float px = g + contentW() / 2f;
        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(1.5f * d);
        c.drawLine(px, 0, px, H, p);
        path.reset();
        path.moveTo(px - 5 * d, 0);
        path.lineTo(px + 5 * d, 0);
        path.lineTo(px, 6 * d);
        path.close();
        c.drawPath(path, p);
    }

    private ReactionTrace.Seg segOfRow(int row) {
        for (ReactionTrace.Seg s : trace.segments) if (isOwn(s) && s.row == row) return s;
        return null;
    }

    private void ruler(Canvas c) {
        float g = gutter(), W = getWidth();
        int[] steps = {1, 2, 5, 10, 30, 60, 120};
        int step = 120;
        for (int s : steps) if (s * ppt >= 26f * d) { step = s; break; }
        int first = (int) Math.floor(tickAt(g) / step) * step;
        t.setColor(0xFF8A90A0);
        p.setColor(0x33FFFFFF);
        p.setStrokeWidth(1f);
        for (int k = Math.max(0, first); xOf(k) < W; k += step) {
            float x = xOf(k);
            if (x < g) continue;
            c.drawLine(x, RULER_DP * d - 4 * d, x, getHeight(), p);
            c.drawText(k % 60 == 0 && k > 0 ? (k / 60) + "s" : String.valueOf(k), x + 2 * d, 11 * d, t);
        }
    }

    private void segmentBox(Canvas c, ReactionTrace.Seg s, boolean own, float x0, float x1) {
        float top = laneTop(LANE_PASSOS), h = laneH(LANE_PASSOS);
        boolean sel = own && s.row == this.sel;
        p.setColor(own ? (sel ? C_OWN_SEL : C_OWN) : C_OTHER);
        rf.set(x0 + 1, top + 2 * d, Math.max(x0 + 3 * d, x1 - 1), top + h - 2 * d);
        c.drawRoundRect(rf, 4 * d, 4 * d, p);
        c.save();
        c.clipRect(rf);
        float tx = rf.left + 3 * d, box = h - 8 * d;
        t.setColor(0xFFFFFFFF);
        if (own) {
            int ano = table.s8(s.row, 2);
            drawThumb(c, Math.abs(ano), tx, top + 4 * d, box, ano < 0);
            if (rf.width() > box + 6 * d) tx += box + 3 * d;
            if (rf.right - tx > 14 * d) {
                t.setFakeBoldText(true);
                c.drawText("passo " + (s.row + 1) + (ano < 0 ? " ⇄" : ""), tx, top + h / 2f - 3 * d, t);
                t.setFakeBoldText(false);
                t.setTextSize(8f * d);
                int dur = table.u8(s.row, air ? 1 : 0);
                c.drawText("ANO " + Math.abs(ano) + " · " + (dur == 255 ? "até pousar " : "") + s.length() + "t", tx, top + h / 2f + 9 * d, t);
                t.setTextSize(9f * d);
            }
        } else if (rf.width() > 14 * d) {
            t.setTextSize(8f * d);
            c.drawText("→ " + (s.charSrc ? "pers. " : "jogo ") + s.type, tx, top + h / 2f + 3 * d, t);
            t.setTextSize(9f * d);
        }
        c.restore();
        if (!own) return;
        // alca de duracao (borda direita): so no personagem e quando a duracao nao e o 255
        if (editable) {
            boolean can = ReactionEdit.canResize(table, s.row, air);
            p.setColor(can ? 0xFFFFD84C : 0x66FFFFFF);
            float hx = rf.right - 3 * d;
            c.drawRoundRect(hx - 1.5f * d, rf.centerY() - 8 * d, hx + 1.5f * d, rf.centerY() + 8 * d, 2 * d, 2 * d, p);
        }
        int b = air ? 7 : 3;
        speedLane(c, s, x0, x1, "v " + tok(table.s8(s.row, b)) + "," + tok(table.s8(s.row, b + 1)) + "  a " + tok(table.s8(s.row, b + 2)) + "," + tok(table.s8(s.row, b + 3)));
        int voice = table.s8(s.row, 13);
        chip(c, LANE_VOZ, x0, x1, voice > 0 ? "♪ " + voice : null, C_VOICE);
        int wall = table.u8(s.row, 12);
        chip(c, LANE_EFEITOS, x0, x1, wall > 0 ? "parede " + wall : null, C_WALL);
        int comp = table.u8(s.row, 11);
        chip(c, LANE_SEQ, x0, x1, comp > 0 ? "→ " + (comp >= 30 ? "pers. " + (comp - 30) : "jogo " + comp) : null, C_SEQ);
    }

    private void speedLane(Canvas c, ReactionTrace.Seg s, float x0, float x1, String text) {
        float top = laneTop(LANE_SPEED);
        c.save();
        c.clipRect(Math.max(x0, gutter()), top, x1 - 1, top + laneH(LANE_SPEED));
        t.setColor(0xFFE6E8EC);
        t.setTextSize(7.5f * d);
        c.drawText(text, Math.max(x0, gutter()) + 3 * d, top + 9 * d, t);
        t.setTextSize(9f * d);
        c.restore();
    }

    /** Item (ou celula vazia tracejada) de uma faixa de um passo. */
    private void chip(Canvas c, int lane, float x0, float x1, String text, int color) {
        float top = laneTop(lane), h = laneH(lane);
        float l = Math.max(x0 + 1, gutter()), r = x1 - 1;
        if (r <= l) return;
        c.save();
        c.clipRect(l, top, r, top + h);
        if (text == null) {
            p.setColor(0x14FFFFFF);
            c.drawRoundRect(l, top + 3 * d, r, top + h - 3 * d, 3 * d, 3 * d, p);
            if (r - l > 18 * d) {
                t.setColor(0x66FFFFFF);
                t.setTextSize(8f * d);
                c.drawText("＋", l + 4 * d, top + h / 2f + 3 * d, t);
                t.setTextSize(9f * d);
            }
        } else {
            p.setColor(color);
            p.setAlpha(190);
            c.drawRoundRect(l, top + 2 * d, r, top + h - 2 * d, 3 * d, 3 * d, p);
            p.setAlpha(255);
            t.setColor(0xFF10131A);
            t.setTextSize(8f * d);
            t.setFakeBoldText(true);
            c.drawText(text, l + 3 * d, top + h / 2f + 3 * d, t);
            t.setFakeBoldText(false);
            t.setTextSize(9f * d);
        }
        c.restore();
    }

    private void drawThumb(Canvas c, int ano, float x, float y, float box, boolean flip) {
        p.setColor(0x33000000);
        c.drawRect(x, y, x + box, y + box, p);
        if (opDac == null || opSprites == null) return;
        Ano a = opDac.getAno(ano);
        if (a == null || !a.present || a.mpts.length == 0 || a.mpts[0].image < 0) return;
        SpriteCache.Sprite sp = null;
        try { sp = opSprites.get(a.mpts[0].image); } catch (Exception ignored) { }
        if (sp == null || sp.bitmap == null) return;
        float sw = sp.src.width(), sh = sp.src.height();
        float k = Math.min(box / Math.max(1f, sw), box / Math.max(1f, sh));
        float dw = sw * k, dh = sh * k, cx = x + box / 2f, cy = y + box / 2f;
        rf.set(cx - dw / 2f, cy - dh / 2f, cx + dw / 2f, cy + dh / 2f);
        sr.set(sp.src);
        c.save();
        if (flip) c.scale(-1f, 1f, cx, cy);
        c.drawBitmap(sp.bitmap, sr, rf, null);
        c.restore();
    }

    private void velocity(Canvas c, int total) {
        float top = laneTop(LANE_SPEED), h = laneH(LANE_SPEED), mid = top + 12 * d + (h - 12 * d) / 2f;
        float max = 1f;
        for (BattleSim.DamageTick k : trace.ticks) max = Math.max(max, Math.max(Math.abs(k.xs / 128f), Math.abs(k.ys / 128f)));
        float amp = (h - 12 * d) / 2f - 3 * d;
        p.setColor(0x44FFFFFF);
        p.setStrokeWidth(1f);
        c.drawLine(gutter(), mid, getWidth(), mid, p);
        t.setColor(0xFF8A90A0);
        t.setTextSize(7f * d);
        c.drawText("±" + (Math.round(max * 10f) / 10f) + " px/t", 4 * d, top + h - 4 * d, t);
        t.setTextSize(9f * d);
        for (int line = 0; line < 2; line++) {
            p.setColor(line == 0 ? C_VX : C_VY);
            p.setStrokeWidth(1.6f * d);
            float py = 0;
            boolean first = true;
            for (int i = 0; i < total; i++) {
                BattleSim.DamageTick k = trace.ticks.get(i);
                float v = (line == 0 ? k.xs : k.ys) / 128f;
                float x0 = xOf(i), x1 = xOf(i + 1), y = mid - v / max * amp;
                if (x1 < gutter() || x0 > getWidth()) { py = y; first = false; continue; }
                if (!first && py != y) c.drawLine(x0, py, x0, y, p);
                c.drawLine(x0, y, x1, y, p);
                py = y;
                first = false;
            }
        }
        p.setStrokeWidth(1f);
        t.setColor(C_VX);
        c.drawText("x", 4 * d, top + 10 * d, t);
        t.setColor(C_VY);
        c.drawText("y", 12 * d, top + 10 * d, t);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        scaler.onTouchEvent(e);
        if (scaler.isInProgress() || e.getPointerCount() > 1) { scaling = true; mode = M_NONE; return true; }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = e.getX();
                downY = e.getY();
                downTick = playTick;
                moved = false;
                scaling = false;
                mode = M_SCRUB;
                getParent().requestDisallowInterceptTouchEvent(true);
                // alca: borda direita de um passo da tabela (so no personagem e se a duracao nao for 255)
                if (editable && trace != null && laneAt(downY) == LANE_PASSOS) {
                    for (ReactionTrace.Seg s : trace.segments) {
                        if (!isOwn(s) || !ReactionEdit.canResize(table, s.row, air)) continue;
                        float ex = xOf(s.end);
                        if (downX >= ex - HANDLE_DP * d && downX <= ex + 8 * d && ex > gutter()) {
                            mode = M_RESIZE;
                            resizeRow = s.row;
                            resizeBase = Math.max(1, table.u8(s.row, ReactionEdit.durColumn(air)));
                            resizeDur = resizeBase;
                            break;
                        }
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (scaling) return true;
                if (Math.abs(e.getX() - downX) > 6 * d) moved = true;
                if (mode == M_RESIZE) {
                    resizeDur = ReactionEdit.dragged(resizeBase, e.getX() - downX, ppt);
                    invalidate();
                } else if (moved) {
                    setPointer(downTick - (e.getX() - downX) / ppt);
                    if (listener != null) listener.onScrub(pointerTick());
                }
                return true;
            case MotionEvent.ACTION_UP: {
                if (mode == M_RESIZE) {
                    int row = resizeRow, nd = resizeDur, base = resizeBase;
                    mode = M_NONE;
                    invalidate();
                    if (moved && nd != base && listener != null) listener.onResize(row, nd);
                    else if (listener != null) listener.onSelectRow(row);
                    return true;
                }
                mode = M_NONE;
                if (!moved && !scaling && trace != null) {
                    int lane = laneAt(downY);
                    int tk = (int) Math.floor(tickAt(e.getX()));
                    ReactionTrace.Seg s = segAt(tk);
                    if (isOwn(s) && listener != null) {
                        if (lane == LANE_PASSOS || lane < 0) listener.onSelectRow(s.row);
                        else listener.onOpenLane(lane, s.row);
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                mode = M_NONE;
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
