package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * O que o jogo faz com uma reacao, tick a tick: roda a simulacao real (BattleSim) forcando o OPT 1 no defensor e guarda uma foto por tick.
 * A timeline do editor de reacoes desenha daqui (passos, velocidade, posicao), entao nunca diverge da previa.
 */
final class ReactionTrace {
    /** Um trecho continuo na mesma linha da mesma tabela. */
    static final class Seg {
        boolean charSrc, flip;
        int type, row;
        /** Por que este trecho comecou (BattleSim.R_*). */
        int reason;
        /** ticks [start, end): indices em {@link #ticks}, onde 0 = primeiro tick depois do golpe. */
        int start, end;
        int length() { return end - start; }
    }

    final List<BattleSim.DamageTick> ticks = new ArrayList<BattleSim.DamageTick>();
    final List<Seg> segments = new ArrayList<Seg>();
    /** Posicao do defensor antes do 1o tick (px). */
    int startX, startY;
    /** Terminou por falta de reacao (true) ou por bater no limite de ticks (false). */
    boolean ended;

    /** Roda a reacao {@code optValue} (0..29 jogo, 30..49 personagem) num sim novo ate acabar (ou {@code maxTicks}). */
    static ReactionTrace record(BattleSim sim, int optValue, int maxTicks) {
        if (sim == null) return new ReactionTrace();
        sim.forceHit(optValue);
        return recordPrimed(sim, maxTicks);
    }

    /**
     * Como {@link #record}, mas no golpe real: o sim esta logo ANTES do tick do hit (ver {@link ReactionHit#ticksBeforeHit}); o 1o step aplica o hit e roda o 1o tick da
     * reacao. O tick 0 da timeline e o tick do hit.
     */
    static ReactionTrace recordPrimed(BattleSim sim, int maxTicks) {
        ReactionTrace tr = new ReactionTrace();
        if (sim == null) return tr;
        BattleSim.DamageTick s0 = sim.damageTick();
        tr.startX = s0.x;
        tr.startY = s0.y;
        for (int i = 0; i < maxTicks; i++) {
            BattleSim.DamageTick pre = sim.damageTick();
            boolean hitTick = i == 0 && !pre.active;               // este step aplica o hit; o estado anterior ainda nao e de dano
            if (!pre.active && !hitTick) { tr.ended = true; break; }
            sim.step();
            BattleSim.DamageTick t = sim.damageTick();
            if (hitTick) {
                if (!t.active) { tr.ended = true; break; }          // o golpe nao acertou neste tick (nao devia acontecer depois de ticksBeforeHit)
                pre = new BattleSim.DamageTick();
                pre.charSrc = t.charSrc;
                pre.type = t.type;
                pre.row = 0;
                pre.time = 0;
                pre.flip = t.flip;
                pre.reason = BattleSim.R_START;
            }
            // passo/tabela/tempo sao os que ESTE tick processou (o estado depois do tick ja pode ter avancado para a proxima linha); posicao e velocidade, as de depois
            t.active = true;
            t.charSrc = pre.charSrc;
            t.type = pre.type;
            t.row = pre.row;
            t.time = pre.time;
            t.flip = pre.flip;
            t.reason = pre.reason;
            tr.ticks.add(t);
        }
        tr.buildSegments();
        return tr;
    }

    private void buildSegments() {
        segments.clear();
        Seg cur = null;
        for (int i = 0; i < ticks.size(); i++) {
            BattleSim.DamageTick t = ticks.get(i);
            // time == 0 e o 1o tick de uma linha (tambem quando a mesma linha recomeca em sequencia)
            boolean newSeg = cur == null || cur.charSrc != t.charSrc || cur.type != t.type || cur.row != t.row || t.time == 0;
            if (newSeg) {
                cur = new Seg();
                cur.charSrc = t.charSrc;
                cur.type = t.type;
                cur.row = t.row;
                cur.flip = t.flip;
                cur.reason = i == 0 ? BattleSim.R_START : t.reason;
                cur.start = i;
                segments.add(cur);
            }
            cur.end = i + 1;
        }
    }

    /** Motivo curto (PT) de o trecho {@code reason} ter comecado; {@code comp} = coluna COMP do passo anterior (para mostrar o destino). */
    static String reasonText(int reason, boolean charSrc, int type) {
        String dest = (charSrc ? "reação do personagem " : "reação do jogo ") + type;
        switch (reason) {
            case BattleSim.R_START: return "início";
            case BattleSim.R_DUR: return "tempo do passo acabou";
            case BattleSim.R_OPEN: return "passou de 255 ticks → " + dest;
            case BattleSim.R_LAND: return "pousou (COMP) → " + dest;
            case BattleSim.R_WALL: return "bateu na parede (COMP) → " + dest;
            case BattleSim.R_UNDER: return "parede abaixo do chão → " + dest;
            case BattleSim.R_END_AIR: return "fim da tabela voando → " + dest;
            case BattleSim.R_END_KO: return "fim da tabela, KO → " + dest;
            default: return "";
        }
    }

    /** Uma passagem por uma tabela de reacao: do tick em que ela comecou ate o salto para a proxima (pouso, parede, 255, fim) ou o fim da reacao. */
    static final class Occ {
        boolean charSrc;
        int type;
        /** ticks [start, end) desta passagem. */
        int start, end;
        /** Por que comecou (BattleSim.R_*) e de que passagem veio (indice em {@link #occurrences}, -1 = o hit) e em qual passo ela estava. */
        int reason, from = -1, fromRow;
        int length() { return end - start; }
    }

    /** As passagens por tabela, em ordem. Trechos seguidos da mesma tabela que so avancam de passo (tempo do passo) sao a mesma passagem. */
    List<Occ> occurrences() {
        List<Occ> out = new ArrayList<Occ>();
        Occ cur = null;
        Seg prev = null;
        for (Seg sg : segments) {
            boolean newOcc = cur == null || sg.reason != BattleSim.R_DUR && sg.reason != BattleSim.R_START || sg.charSrc != cur.charSrc || sg.type != cur.type;
            if (newOcc) {
                Occ o = new Occ();
                o.charSrc = sg.charSrc;
                o.type = sg.type;
                o.start = sg.start;
                o.reason = cur == null ? BattleSim.R_START : sg.reason;
                o.from = cur == null ? -1 : out.size() - 1;
                o.fromRow = prev == null ? 0 : prev.row;
                out.add(o);
                cur = o;
            }
            cur.end = sg.end;
            prev = sg;
        }
        return out;
    }

    /** Copia so os ticks da passagem {@code o}, com os trechos recontados a partir do tick 0 (a timeline mostra uma reacao por vez). */
    ReactionTrace slice(Occ o) {
        ReactionTrace tr = new ReactionTrace();
        tr.ended = true;
        tr.theoretical = theoretical;
        BattleSim.DamageTick before = o.start > 0 && o.start - 1 < ticks.size() ? ticks.get(o.start - 1) : null;
        tr.startX = before == null ? startX : before.x;
        tr.startY = before == null ? startY : before.y;
        for (int i = o.start; i < o.end && i < ticks.size(); i++) tr.ticks.add(ticks.get(i));
        for (Seg sg : segments) {
            if (sg.start < o.start || sg.end > o.end) continue;
            Seg n = new Seg();
            n.charSrc = sg.charSrc; n.flip = sg.flip; n.type = sg.type; n.row = sg.row; n.reason = sg.reason;
            n.start = sg.start - o.start; n.end = sg.end - o.start;
            tr.segments.add(n);
        }
        return tr;
    }

    /** Indice da passagem que processa o tick (o ultimo se passou do fim), ou -1 sem passagens. */
    int occIndexAt(int tick) {
        List<Occ> os = occurrences();
        int r = -1;
        for (int i = 0; i < os.size(); i++) if (tick >= os.get(i).start) r = i;
        return r;
    }

    /** true quando o trace nao vem da simulacao (golpe nao acertou): so passos e duracoes da tabela, sem deslocamento nem parede. */
    boolean theoretical;

    /** Trace "so tabela": cada passo dura sua duracao (255 mostra 30 ticks), sem velocidade nem posicao. */
    static ReactionTrace theoretical(ReactionTable t, boolean charSrc, int type, boolean air) {
        ReactionTrace tr = new ReactionTrace();
        tr.theoretical = true;
        tr.ended = true;
        if (t == null) return tr;
        for (int row = 0; row < t.rows; row++) {
            int dur = t.u8(row, air ? 1 : 0);
            if (dur == 255) dur = 30;
            for (int k = 0; k < dur; k++) {
                BattleSim.DamageTick d = new BattleSim.DamageTick();
                d.active = true;
                d.charSrc = charSrc;
                d.type = type;
                d.row = row;
                d.time = k;
                d.reason = row == 0 ? BattleSim.R_START : BattleSim.R_DUR;
                tr.ticks.add(d);
            }
        }
        tr.buildSegments();
        return tr;
    }

    /** Rotulo curto (para a faixa SEQ) do motivo. */
    static String shortReason(int reason) {
        switch (reason) {
            case BattleSim.R_OPEN: return "255 t";
            case BattleSim.R_LAND: return "pousou";
            case BattleSim.R_WALL: return "parede";
            case BattleSim.R_UNDER: return "abaixo do chão";
            case BattleSim.R_END_AIR: return "fim → 13";
            case BattleSim.R_END_KO: return "fim KO → 2";
            default: return "";
        }
    }

    /** Trechos da tabela {@code (charSrc, type)}. */
    List<Seg> of(boolean charSrc, int type) {
        List<Seg> out = new ArrayList<Seg>();
        for (Seg s : segments) if (s.charSrc == charSrc && s.type == type) out.add(s);
        return out;
    }

    /** Deslocamento (px) do defensor entre o inicio da reacao e o fim do tick {@code endTick} (exclusivo); {dx, dy}. */
    int[] displacement(int endTick) {
        if (ticks.isEmpty()) return new int[]{0, 0};
        BattleSim.DamageTick last = ticks.get(Math.max(0, Math.min(ticks.size(), endTick) - 1));
        return new int[]{last.x - startX, last.y - startY};
    }
}
