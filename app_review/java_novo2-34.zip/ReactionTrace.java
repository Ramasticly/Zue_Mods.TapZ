package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * O que o jogo faz com uma reacao, tick a tick: roda a simulacao real (BattleSim) forcando o OPT 1 no defensor e guarda uma foto por tick.
 * A timeline do editor de reacoes desenha daqui (passos, velocidade, posicao), entao nunca diverge da previa.
 */
final class ReactionTrace {
    /** Um trecho continuo na mesma linha da mesma tabela. */
    static final class Seg {
        boolean charSrc, flip;
        int type, row;
        /** Por que este trecho comecou (BattleSim.R_*). */
        int reason;
        /** ticks [start, end): indices em {@link #ticks}, onde 0 = primeiro tick depois do golpe. */
        int start, end;
        int length() { return end - start; }
    }

    final List<BattleSim.DamageTick> ticks = new ArrayList<BattleSim.DamageTick>();
    final List<Seg> segments = new ArrayList<Seg>();
    /** Posicao do defensor antes do 1o tick (px). */
    int startX, startY;
    /** Terminou por falta de reacao (true) ou por bater no limite de ticks (false). */
    boolean ended;

    /** Roda a reacao {@code optValue} (0..29 jogo, 30..49 personagem) num sim novo ate acabar (ou {@code maxTicks}). */
    static ReactionTrace record(BattleSim sim, int optValue, int maxTicks) {
        ReactionTrace tr = new ReactionTrace();
        if (sim == null) return tr;
        sim.forceHit(optValue);
        BattleSim.DamageTick s0 = sim.damageTick();
        tr.startX = s0.x;
        tr.startY = s0.y;
        for (int i = 0; i < maxTicks; i++) {
            BattleSim.DamageTick pre = sim.damageTick();
            if (!pre.active) { tr.ended = true; break; }
            sim.step();
            BattleSim.DamageTick t = sim.damageTick();
            // passo/tabela/tempo sao os que ESTE tick processou (o estado depois do tick ja pode ter avancado para a proxima linha); posicao e velocidade, as de depois
            t.active = true;
            t.charSrc = pre.charSrc;
            t.type = pre.type;
            t.row = pre.row;
            t.time = pre.time;
            t.flip = pre.flip;
            t.reason = pre.reason;
            tr.ticks.add(t);
        }
        tr.buildSegments();
        return tr;
    }

    private void buildSegments() {
        segments.clear();
        Seg cur = null;
        for (int i = 0; i < ticks.size(); i++) {
            BattleSim.DamageTick t = ticks.get(i);
            // time == 0 e o 1o tick de uma linha (tambem quando a mesma linha recomeca em sequencia)
            boolean newSeg = cur == null || cur.charSrc != t.charSrc || cur.type != t.type || cur.row != t.row || t.time == 0;
            if (newSeg) {
                cur = new Seg();
                cur.charSrc = t.charSrc;
                cur.type = t.type;
                cur.row = t.row;
                cur.flip = t.flip;
                cur.reason = i == 0 ? BattleSim.R_START : t.reason;
                cur.start = i;
                segments.add(cur);
            }
            cur.end = i + 1;
        }
    }

    /** Motivo curto (PT) de o trecho {@code reason} ter comecado; {@code comp} = coluna COMP do passo anterior (para mostrar o destino). */
    static String reasonText(int reason, boolean charSrc, int type) {
        String dest = (charSrc ? "reação do personagem " : "reação do jogo ") + type;
        switch (reason) {
            case BattleSim.R_START: return "início";
            case BattleSim.R_DUR: return "tempo do passo acabou";
            case BattleSim.R_OPEN: return "passou de 255 ticks → " + dest;
            case BattleSim.R_LAND: return "pousou (COMP) → " + dest;
            case BattleSim.R_WALL: return "bateu na parede (COMP) → " + dest;
            case BattleSim.R_UNDER: return "parede abaixo do chão → " + dest;
            case BattleSim.R_END_AIR: return "fim da tabela voando → " + dest;
            case BattleSim.R_END_KO: return "fim da tabela, KO → " + dest;
            default: return "";
        }
    }

    /** Rotulo curto (para a faixa SEQ) do motivo. */
    static String shortReason(int reason) {
        switch (reason) {
            case BattleSim.R_OPEN: return "255 t";
            case BattleSim.R_LAND: return "pousou";
            case BattleSim.R_WALL: return "parede";
            case BattleSim.R_UNDER: return "abaixo do chão";
            case BattleSim.R_END_AIR: return "fim → 13";
            case BattleSim.R_END_KO: return "fim KO → 2";
            default: return "";
        }
    }

    /** Trechos da tabela {@code (charSrc, type)}. */
    List<Seg> of(boolean charSrc, int type) {
        List<Seg> out = new ArrayList<Seg>();
        for (Seg s : segments) if (s.charSrc == charSrc && s.type == type) out.add(s);
        return out;
    }

    /** Deslocamento (px) do defensor entre o inicio da reacao e o fim do tick {@code endTick} (exclusivo); {dx, dy}. */
    int[] displacement(int endTick) {
        if (ticks.isEmpty()) return new int[]{0, 0};
        BattleSim.DamageTick last = ticks.get(Math.max(0, Math.min(ticks.size(), endTick) - 1));
        return new int[]{last.x - startX, last.y - startY};
    }
}
