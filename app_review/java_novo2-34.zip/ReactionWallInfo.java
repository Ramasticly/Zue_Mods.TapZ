package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Texto do (i) das thumbs de reacao: como a reacao trata a PAREDE e o POUSO (colunas WALL e COMP, por passo). Regras do jogo (md 876 jogo:21095-21200, md 877
 * jogo:21369-21482, camera jogo:15380-15426): WALL 0 nao muda a animacao; WALL 1 so faz a camera acompanhar (quando ja bateu na parede); WALL 2/3 com COMP 1..49
 * reinicia na reacao COMP ao encostar na parede (no chao vai para o jogo 12); COMP fora da parede so vale ao pousar (11 deita, 12 quica, 1..49 vai para a reacao,
 * 50+ so pousa). Java puro; os rotulos "Jogo n"/"Personagem n"/"Passo" passam por {@link I18n#tr} na hora de montar (os modelos {0} do catalogo traduzem o resto).
 */
final class ReactionWallInfo {
    private ReactionWallInfo() { }

    /** Entrega as outras reacoes (para dizer para onde a parede/o pouso leva). */
    interface Lookup {
        ReactionTable game(int type);
        ReactionTable chr(int index);
    }

    /**
     * @param t         a reacao
     * @param charSrc   true = reacao do personagem (md 877, valores 30..49), false = do jogo (md 876, 0..29)
     * @param selfValue valor desta reacao (0..29 jogo, 30..49 personagem), para avisar quando ela aponta para si mesma; -1 = desconhecido
     */
    static List<AttackInfo.Line> lines(ReactionTable t, boolean charSrc, int selfValue, Lookup lk) {
        List<AttackInfo.Line> out = new ArrayList<AttackInfo.Line>();
        if (t == null || t.rows <= 0) {
            out.add(new AttackInfo.Line("Reação vazia: sem passos.", AttackInfo.BIN));
            return out;
        }
        boolean changes = hasWallReaction(t);
        out.add(new AttackInfo.Line(changes ? "Parede: muda a animação — reinicia em outra reação." : "Parede: não muda a animação (o oponente só fica preso na borda da tela).",
                changes ? AttackInfo.RED : AttackInfo.DIM));
        // grupos de passos seguidos com o mesmo (WALL, COMP)
        int r = 0;
        while (r < t.rows) {
            int w = t.u8(r, 12), c = t.u8(r, 11);
            int e = r;
            while (e + 1 < t.rows && t.u8(e + 1, 12) == w && t.u8(e + 1, 11) == c) e++;
            describe(out, charSrc, selfValue, lk, r, e, w, c);
            r = e + 1;
        }
        return out;
    }

    private static boolean isTable(int comp) { return comp >= 1 && comp <= 49; }

    /** Algum passo muda a animacao na parede (WALL 2/3 com COMP de 1 a 49)? Decide a cor do (i): vermelho com reacao de parede, cinza sem. */
    static boolean hasWallReaction(ReactionTable t) {
        if (t == null) return false;
        for (int r = 0; r < t.rows; r++) if (t.u8(r, 12) >= 2 && isTable(t.u8(r, 11))) return true;
        return false;
    }

    private static String steps(int a, int b) { return a == b ? I18n.tr("Passo ") + (a + 1) : I18n.tr("Passos ") + (a + 1) + "–" + (b + 1); }

    /** Tabela para onde o COMP leva, dentro da regra da fonte (null = nao existe). */
    private static ReactionTable dest(boolean charSrc, int comp, Lookup lk) {
        if (lk == null) return null;
        if (charSrc && comp >= 30) return lk.chr(comp - 30);
        if (comp >= 30) return null;
        return lk.game(comp);
    }

    private static String label(int comp) { return comp >= 30 ? I18n.tr("Personagem ") + (comp - 30) : I18n.tr("Jogo ") + comp; }

    /** ANO do 1o passo da tabela ("?" se nao ha). */
    private static String ano(ReactionTable t) { return t == null || t.rows <= 0 ? "?" : String.valueOf(Math.abs(t.s8(0, 2))); }

    private static void describe(List<AttackInfo.Line> out, boolean charSrc, int selfValue, Lookup lk, int a, int b, int w, int c) {
        String who = steps(a, b);
        if (w >= 2 && isTable(c)) {
            ReactionTable d = dest(charSrc, c, lk);
            out.add(new AttackInfo.Line(who + ": na parede reinicia em " + label(c) + " (ANO " + ano(d) + ").", AttackInfo.BIN));
            out.add(new AttackInfo.Line("No chão, em vez disso, quica em " + label(12) + " (ANO " + ano(lk == null ? null : lk.game(12)) + ").", AttackInfo.CODE));
            out.add(new AttackInfo.Line(!charSrc ? "A parede só vale no limite do cenário e se o oponente não estiver subindo (reação do jogo)."
                    : w == 3 ? "WALL 3 vale em qualquer borda da tela, não só no limite do cenário (reação do personagem)."
                    : "A parede só vale no limite do cenário (WALL 2, reação do personagem).", AttackInfo.CODE));
            warn(out, who, charSrc, selfValue, c, d);
            return;
        }
        if (w >= 2) {
            out.add(new AttackInfo.Line(who + ": WALL " + w + " sem um COMP de 1 a 49 — a parede não faz nada.", AttackInfo.BIN));
        } else if (w == 1) {
            out.add(new AttackInfo.Line(who + ": WALL 1 — a animação não muda; se o oponente já bateu na parede, a câmera acompanha.", AttackInfo.BIN));
        }
        if (c == 11) {
            out.add(new AttackInfo.Line(who + ": ao pousar fica caído (ANO 24) e a reação termina.", AttackInfo.BIN));
        } else if (c == 12) {
            out.add(new AttackInfo.Line(who + ": ao pousar quica em " + label(12) + " (ANO " + ano(lk == null ? null : lk.game(12)) + "); se o jogador apertar botão no ar, levanta (ANO 22).", AttackInfo.BIN));
        } else if (isTable(c)) {
            ReactionTable d = dest(charSrc, c, lk);
            out.add(new AttackInfo.Line(who + ": ao pousar vai para " + label(c) + " (ANO " + ano(d) + ").", AttackInfo.BIN));
            warn(out, who, charSrc, selfValue, c, d);
        } else if (c >= 50) {
            out.add(new AttackInfo.Line(who + ": ao pousar só toca o pouso (ANO 13) e termina.", AttackInfo.BIN));
        }
    }

    private static void warn(List<AttackInfo.Line> out, String who, boolean charSrc, int selfValue, int c, ReactionTable d) {
        if (!charSrc && c >= 30) out.add(new AttackInfo.Line("⚠ " + who + ": COMP " + c + " em reação do jogo lê uma tabela que não existe.", AttackInfo.PLAIN));
        else if (d == null || d.rows <= 0) out.add(new AttackInfo.Line("⚠ " + who + ": " + label(c) + " está vazia (sem passos).", AttackInfo.PLAIN));
        else if (c == selfValue) out.add(new AttackInfo.Line("⚠ " + who + ": " + label(c) + " é esta mesma reação (reinicia em laço).", AttackInfo.PLAIN));
    }
}
