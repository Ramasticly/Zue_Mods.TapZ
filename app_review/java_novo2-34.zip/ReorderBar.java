package com.zue.attackeditor;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.DragEvent;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;
import java.util.Map;

/**
 * Linha de botoes do menu superior com a ordem editavel: segurar um botao e arrastar para frente ou para tras muda a ordem
 * (salva no aparelho). O primeiro botao fica fixo fora da rolagem; soltar qualquer botao nele troca o botao fixo.
 * Quem usa so cria os botoes e liga os cliques; a posicao deles e daqui.
 */
final class ReorderBar {
    private static final String PREFS = "toolbar", KEY = "order", KEY_HINT = "hint";

    private static final int NEAREST = -1;

    private final Activity act;
    private final LinearLayout pinnedBox;
    private final HorizontalScrollView scroll;
    private final LinearLayout strip;
    private final Map<String, TextView> buttons;
    private final SharedPreferences prefs;
    private final float density;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private List<String> order;
    private String dragging;
    private int edge;       // -1 rola para a esquerda, 1 para a direita, 0 parado
    private View hot;       // alvo destacado
    private final Runnable autoScroll = new Runnable() {
        @Override public void run() {
            if (dragging == null || edge == 0) return;
            scroll.scrollBy(edge * dp(16), 0);
            handler.postDelayed(this, 16);
        }
    };

    ReorderBar(Activity a, LinearLayout pinnedBox, HorizontalScrollView scroll, LinearLayout strip, Map<String, TextView> buttons) {
        this.act = a;
        this.pinnedBox = pinnedBox;
        this.scroll = scroll;
        this.strip = strip;
        this.buttons = buttons;
        this.prefs = a.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.density = a.getResources().getDisplayMetrics().density;
        List<String> def = ToolbarOrder.defaults();
        // so aceita ids que existem de fato (um botao pode faltar numa build)
        for (int i = def.size() - 1; i >= 0; i--) if (!buttons.containsKey(def.get(i))) def.remove(i);
        this.order = ToolbarOrder.restore(prefs.getString(KEY, ""), def);
        for (final Map.Entry<String, TextView> e : buttons.entrySet()) {
            final String id = e.getKey();
            final TextView b = e.getValue();
            b.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) { return begin(v, id); }
            });
            b.setOnDragListener(new View.OnDragListener() {
                @Override public boolean onDrag(View v, DragEvent ev) { return onDrop(v, ev, indexOf(id)); }
            });
        }
        pinnedBox.setOnDragListener(new View.OnDragListener() {
            @Override public boolean onDrag(View v, DragEvent ev) { return onDrop(v, ev, 0); }
        });
        // area vazia da rolagem (frestas entre botoes e o espaco depois do ultimo): vai para o botao mais proximo
        View.OnDragListener gap = new View.OnDragListener() {
            @Override public boolean onDrag(View v, DragEvent ev) { return onDrop(v, ev, NEAREST); }
        };
        scroll.setOnDragListener(gap);
        strip.setOnDragListener(gap);
        layout();
    }

    List<String> order() { return new java.util.ArrayList<String>(order); }

    /** Ordem de fabrica (SALVAR fixo no inicio). */
    void reset() {
        List<String> def = ToolbarOrder.defaults();
        for (int i = def.size() - 1; i >= 0; i--) if (!buttons.containsKey(def.get(i))) def.remove(i);
        apply(def);
    }

    /** Avisa uma unica vez que da para arrastar os botoes. */
    void hintOnce() {
        if (prefs.getBoolean(KEY_HINT, false)) return;
        prefs.edit().putBoolean(KEY_HINT, true).apply();
        android.widget.Toast.makeText(act, "Dica: segure um botao do menu e arraste para mudar a ordem (AJUDA explica tudo)",
                android.widget.Toast.LENGTH_LONG).show();
    }

    private int indexOf(String id) { return order.indexOf(id); }

    private int dp(int v) { return (int) (v * density + 0.5f); }

    private void apply(List<String> next) {
        order = next;
        prefs.edit().putString(KEY, ToolbarOrder.save(order)).apply();
        layout();
    }

    /** Monta a linha a partir de {@code order}: o 1o no slot fixo, o resto na rolagem. */
    private void layout() {
        pinnedBox.removeAllViews();
        strip.removeAllViews();
        for (int i = 0; i < order.size(); i++) {
            TextView b = buttons.get(order.get(i));
            if (b == null) continue;
            if (b.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup) b.getParent()).removeView(b);
            b.setAlpha(1f);
            b.setScaleX(1f);
            if (i == 0) {
                pinnedBox.addView(b, new LinearLayout.LayoutParams(-2, -2));
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.rightMargin = i == order.size() - 1 ? 0 : dp(5);
                strip.addView(b, lp);
            }
        }
    }

    private boolean begin(View v, String id) {
        dragging = id;
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        ClipData data = ClipData.newPlainText("toolbar", id);
        View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
        boolean ok;
        if (Build.VERSION.SDK_INT >= 24) ok = v.startDragAndDrop(data, shadow, id, 0);
        else ok = v.startDrag(data, shadow, id, 0);
        if (!ok) dragging = null;
        return ok;
    }

    private boolean ours(DragEvent ev) { return ev.getLocalState() instanceof String && ev.getLocalState().equals(dragging); }

    /** Um unico tratador para botoes, slot fixo e area vazia; {@code to} = indice onde o botao arrastado vai ficar se soltar aqui. */
    private boolean onDrop(View v, DragEvent ev, int to) {
        if (!ours(ev)) return false;
        switch (ev.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED: {
                TextView d = buttons.get(dragging);
                if (d != null) d.setAlpha(0.35f);
                return true;
            }
            case DragEvent.ACTION_DRAG_ENTERED:
                if (v != scroll) highlight(v);
                return true;
            case DragEvent.ACTION_DRAG_LOCATION: {
                // posicao do dedo na janela da rolagem (o slot fixo nao anda com ela)
                float inView = v == pinnedBox || v.getParent() == pinnedBox ? -1 : stripX(v, ev.getX()) - scroll.getScrollX();
                int dir = 0;
                if (inView >= 0) {
                    if (inView < dp(48)) dir = -1;
                    else if (inView > scroll.getWidth() - dp(48)) dir = 1;
                }
                if (dir != edge) {
                    edge = dir;
                    handler.removeCallbacks(autoScroll);
                    if (dir != 0) handler.post(autoScroll);
                }
                return true;
            }
            case DragEvent.ACTION_DRAG_EXITED:
                if (hot == v) highlight(null);
                return true;
            case DragEvent.ACTION_DROP: {
                final int from = indexOf(dragging);
                final int dest = to == NEAREST ? nearest(stripX(v, ev.getX())) : to;
                highlight(null);
                // remonta a linha depois que o jogo de eventos de arrastar termina (nao mexer nas views no meio dele)
                if (from >= 0 && dest >= 0 && from != dest) handler.post(new Runnable() {
                    @Override public void run() { apply(ToolbarOrder.move(order, from, dest)); }
                });
                return true;
            }
            case DragEvent.ACTION_DRAG_ENDED: {
                edge = 0;
                handler.removeCallbacks(autoScroll);
                highlight(null);
                TextView d = dragging == null ? null : buttons.get(dragging);
                if (d != null) d.setAlpha(1f);
                dragging = null;
                return true;
            }
            default: return true;
        }
    }

    /** x do dedo no sistema da faixa de botoes (dentro da rolagem, sem descontar a rolagem). */
    private float stripX(View v, float x) {
        if (v == scroll) return x + scroll.getScrollX();
        if (v == strip) return x;
        return v.getLeft() + x;
    }

    /** Indice (em {@code order}) do botao da rolagem cujo centro fica mais perto de {@code x}; -1 se nao ha botoes na rolagem. */
    private int nearest(float x) {
        int best = -1;
        float bestD = Float.MAX_VALUE;
        for (int i = 1; i < order.size(); i++) {
            TextView b = buttons.get(order.get(i));
            if (b == null || b.getParent() != strip) continue;
            float d = Math.abs(b.getLeft() + b.getWidth() / 2f - x);
            if (d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    private void highlight(View v) {
        if (hot != null) hot.setScaleX(1f);
        hot = v;
        if (v != null) v.setScaleX(1.12f);
    }
}
