package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Confirmacao de trocar uma sprite por outra (do personagem, de um CNV de outro pac ou de uma imagem do dispositivo):
 * "Voce quer trocar a SPR_N por SPR_M?", previa 1:1 (antiga | → nova) e CANCELAR | IGUALAR SPRITES | CONFIRMAR.
 */
final class ReplaceConfirm {
    private static final int TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, WARN = 0xFFFFB454;

    private ReplaceConfirm() { }

    /** Escala comum das duas previas: 1:1 ({@code density} px por unidade logica), reduzida so se a maior nao couber em {@code availW} x {@code availH}. */
    static float fitScale(float density, int lw1, int lh1, int lw2, int lh2, float availW, float availH) {
        float k = Math.max(1f, density);
        int mw = Math.max(1, Math.max(lw1, lw2)), mh = Math.max(1, Math.max(lh1, lh2));
        return Math.min(k, Math.min(availW / mw, availH / mh));
    }

    /** Duas previas lado a lado (antiga | seta | nova), cada uma so com o recorte da sprite, na mesma escala. */
    private static final class PairView extends View {
        final SpriteCache.Sprite a, b;
        final Paint bg = new Paint(), p = new Paint(Paint.FILTER_BITMAP_FLAG), tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF dst = new RectF();

        PairView(Activity act, SpriteCache.Sprite a, SpriteCache.Sprite b) {
            super(act);
            this.a = a; this.b = b;
            bg.setColor(0xFF0D0F13);
            p.setFilterBitmap(false);
            tx.setColor(TEXT);
            tx.setTextAlign(Paint.Align.CENTER);
            tx.setTextSize(24f * act.getResources().getDisplayMetrics().density);
        }

        private void one(Canvas c, SpriteCache.Sprite s, float left, float w, float k) {
            if (s == null || s.bitmap == null || s.bitmap.isRecycled()) return;
            float dw = s.logicalWidth * k, dh = s.logicalHeight * k;
            float x = left + (w - dw) / 2f, y = (getHeight() - dh) / 2f;
            dst.set(x, y, x + dw, y + dh);
            c.drawBitmap(s.bitmap, s.src, dst, p);          // so o recorte: o bitmap do cache e a folha inteira
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), arrow = 36f * getResources().getDisplayMetrics().density, half = (w - arrow) / 2f;
            c.drawRect(0, 0, w, h, bg);
            int aw = a == null ? 1 : a.logicalWidth, ah = a == null ? 1 : a.logicalHeight, bw = b == null ? 1 : b.logicalWidth, bh = b == null ? 1 : b.logicalHeight;
            float k = fitScale(getResources().getDisplayMetrics().density, aw, ah, bw, bh, half - 8, h - 8);
            one(c, a, 0, half, k);
            I18nUi.drawText(c, "→", half + arrow / 2f, h / 2f + tx.getTextSize() / 3f, tx);
            one(c, b, half + arrow, half, k);
        }
    }

    /**
     * @param question  "Voce quer trocar a SPR_N por SPR_M?" (ja montada)
     * @param warn      aviso opcional (ex.: tamanho diferente), ou null
     */
    static void show(final Activity act, String question, SpriteCache.Sprite oldS, SpriteCache.Sprite newS, String warn,
                     final Runnable onConfirm, final Runnable onEqualize, final Runnable onCancel) {
        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = SpriteListScreen.dp(act, 18);
        col.setPadding(pad, SpriteListScreen.dp(act, 8), pad, 0);
        TextView q = SpriteListScreen.text(act, question, 15, TEXT, true);
        col.addView(q);
        PairView pv = new PairView(act, oldS, newS);
        col.addView(pv, new LinearLayout.LayoutParams(-1, SpriteListScreen.dp(act, 200)));
        if (warn != null && !warn.isEmpty()) {
            TextView w = SpriteListScreen.text(act, warn, 11, WARN, false);
            w.setPadding(0, SpriteListScreen.dp(act, 6), 0, 0);
            col.addView(w);
        }
        final boolean[] done = {false};
        AlertDialog dlg = new I18nBuilder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert).setView(col)
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface d, int w) { done[0] = true; if (onCancel != null) onCancel.run(); } })
                .setNeutralButton("IGUALAR SPRITES", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface d, int w) { done[0] = true; onEqualize.run(); } })
                .setPositiveButton("CONFIRMAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface d, int w) { done[0] = true; onConfirm.run(); } })
                .create();
        dlg.setOnCancelListener(new DialogInterface.OnCancelListener() { @Override public void onCancel(DialogInterface d) { if (!done[0] && onCancel != null) onCancel.run(); } });
        dlg.show();
    }
}
