package com.zue.attackeditor;

/**
 * REPOSICIONAR (editor de reacoes): quando o golpe nao acerta, acha a distancia e a altura do oponente em que a hitbox do atacante (parado no fim do frame do hit)
 * cai dentro da hurtbox dele. So muda a distancia e a altura do oponente; o atacante fica onde esta. Java puro.
 */
final class RepositionHit {
    private RepositionHit() { }

    /** Monta o sim com o atacante parado no fim do frame da hitbox para uma distancia (px) e uma altura do oponente (px). */
    interface SimFactory { BattleSim held(int distance, int oppHeight); }

    static final int MAX_DIST = 480, MAX_HEIGHT = 200;

    /** Alguma hitbox (flag 2) do atacante cruza alguma hurtbox (flag 1) do oponente neste sim? Mesma regra estrita do jogo. */
    static boolean overlaps(BattleSim s) {
        AttackSim.Obj a = s.attacker().root(), t = s.opponent().root();
        if (a == null || t == null) return false;
        for (Ano.Hit ha : a.hits) {
            if (ha.flag != 2) continue;
            int[] r = BattleSim.worldRect(a, ha);
            for (Ano.Hit ht : t.hits) {
                if (ht.flag != 1) continue;
                int[] q = BattleSim.worldRect(t, ht);
                if (r[0] < q[2] && q[0] < r[2] && r[1] < q[3] && q[1] < r[3]) return true;
            }
        }
        return false;
    }

    /**
     * Um passo: o deslocamento que leva o centro da hurtbox mais proxima ao centro da hitbox. Devolve {distancia, altura} novas (ja limitadas) ou null se o sim
     * nao tem hitbox ou hurtbox.
     */
    static int[] step(BattleSim s, int distance, int oppHeight, boolean facingLeft) {
        AttackSim.Obj a = s.attacker().root(), t = s.opponent().root();
        if (a == null || t == null) return null;
        long best = Long.MAX_VALUE;
        int bdx = 0, bdy = 0;
        boolean found = false;
        for (Ano.Hit ha : a.hits) {
            if (ha.flag != 2) continue;
            int[] r = BattleSim.worldRect(a, ha);
            for (Ano.Hit ht : t.hits) {
                if (ht.flag != 1) continue;
                int[] q = BattleSim.worldRect(t, ht);
                int dx = (r[0] + r[2]) / 2 - (q[0] + q[2]) / 2, dy = (r[1] + r[3]) / 2 - (q[1] + q[3]) / 2;
                long d = (long) dx * dx + (long) dy * dy;
                if (d < best) { best = d; bdx = dx; bdy = dy; found = true; }
            }
        }
        if (!found) return null;
        int nd = Math.max(0, Math.min(MAX_DIST, distance + (facingLeft ? -bdx : bdx)));
        int nh = Math.max(0, Math.min(MAX_HEIGHT, oppHeight - bdy));
        return new int[]{nd, nh};
    }

    /**
     * Repete {@link #step} (o corpo e a camera podem deslocar um pouco) ate a hitbox cruzar a hurtbox, no maximo {@code tries} vezes. Devolve {distancia, altura} ou
     * null se nao ha caixas ou nao coube (limites de distancia 0..480 e altura 0..200).
     */
    static int[] solve(SimFactory f, int distance, int oppHeight, boolean facingLeft, int tries) {
        int d = distance, h = oppHeight;
        for (int i = 0; i < tries; i++) {
            BattleSim s = f.held(d, h);
            if (s == null) return null;
            if (overlaps(s)) return new int[]{d, h};
            int[] n = step(s, d, h, facingLeft);
            if (n == null || (n[0] == d && n[1] == h)) return null;
            d = n[0];
            h = n[1];
        }
        BattleSim s = f.held(d, h);
        return s != null && overlaps(s) ? new int[]{d, h} : null;
    }
}
