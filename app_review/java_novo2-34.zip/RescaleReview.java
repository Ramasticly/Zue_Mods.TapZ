package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * REESCALAR da lista de Sprites com revisao por ANO: para cada sprite marcada (em ordem) e cada ANO que a usa (em ordem) o usuario ve o antes e o depois e escolhe
 * REESCALAR ou NAO REESCALAR. So muda zoom e MID dos Frames daquela sprite naquela ANO; o padrao da sprite (Editar Frame) nao e tocado. Java puro.
 */
final class RescaleReview {
    private RescaleReview() { }

    /** Um passo da revisao: a sprite {@code sprite} na ANO {@code ano}. */
    static final class Step {
        final int sprite, ano;
        Step(int sprite, int ano) { this.sprite = sprite; this.ano = ano; }
        @Override public boolean equals(Object o) { return o instanceof Step && ((Step) o).sprite == sprite && ((Step) o).ano == ano; }
        @Override public int hashCode() { return sprite * 100003 + ano; }
        @Override public String toString() { return "SPR_" + sprite + "/ANO " + ano; }
    }

    /** Quantos Frames da ANO usam a sprite. */
    static int framesUsing(Ano a, int sprite) {
        if (a == null || !a.present || a.mpts == null) return 0;
        int n = 0;
        for (Ano.Mpt m : a.mpts) if (m.image == sprite) n++;
        return n;
    }

    /** Passos na ordem: sprites em ordem crescente e, para cada uma, as ANOs que a usam em ordem crescente. Sprite sem uso em nenhuma ANO nao gera passo. */
    static List<Step> steps(Dac dac, Collection<Integer> sprites) {
        List<Step> out = new ArrayList<Step>();
        if (dac == null || sprites == null) return out;
        for (Integer s : new TreeSet<Integer>(sprites)) {
            for (int i = 0; i < dac.size(); i++) if (framesUsing(dac.getAno(i), s.intValue()) > 0) out.add(new Step(s.intValue(), i));
        }
        return out;
    }

    /** Sprites marcadas que nenhuma ANO usa (nada a reescalar nos Frames). */
    static List<Integer> unused(Dac dac, Collection<Integer> sprites) {
        List<Integer> out = new ArrayList<Integer>();
        if (sprites == null) return out;
        for (Integer s : new TreeSet<Integer>(sprites)) {
            boolean used = false;
            if (dac != null) for (int i = 0; i < dac.size() && !used; i++) used = framesUsing(dac.getAno(i), s.intValue()) > 0;
            if (!used) out.add(s);
        }
        return out;
    }

    /** A ANO com os Frames da sprite reescalados (zoom X=Y e MID do plano); a mesma ANO se nao ha Frame dela. */
    static Ano afterAno(Ano a, int sprite, Centralize.Plan p) {
        if (framesUsing(a, sprite) == 0) return a;
        Ano.Mpt[] out = a.mpts.clone();
        for (int k = 0; k < out.length; k++) if (out[k].image == sprite) out[k] = Centralize.applyToFrame(out[k], p);
        return new Ano(a.index, true, a.flags, a.priority, a.links, out);
    }

    /** Copia rasa do DAC com a ANO do passo ja reescalada: serve para a previa e para o "antes" dos passos seguintes. */
    static Dac afterDac(Dac dac, Step s, Centralize.Plan p) {
        Ano a = dac.getAno(s.ano);
        Ano n = afterAno(a, s.sprite, p);
        return n == a ? dac : dac.copyWith(s.ano, n);
    }

    /** Aplica no proprio DAC os passos aceitos; devolve as ANOs alteradas ({@code count[0]} = Frames reescritos). */
    static TreeSet<Integer> apply(Dac dac, Collection<Step> accepted, Map<Integer, Centralize.Plan> plans, int[] count) {
        TreeSet<Integer> changed = new TreeSet<Integer>();
        if (count != null && count.length > 0) count[0] = 0;
        if (dac == null || accepted == null) return changed;
        for (Step s : accepted) {
            Centralize.Plan p = plans.get(Integer.valueOf(s.sprite));
            Ano a = dac.getAno(s.ano);
            if (p == null || framesUsing(a, s.sprite) == 0) continue;
            int n = framesUsing(a, s.sprite);
            dac.setAno(s.ano, afterAno(a, s.sprite, p));
            changed.add(Integer.valueOf(s.ano));
            if (count != null && count.length > 0) count[0] += n;
        }
        return changed;
    }

    /** Resumo do primeiro Frame da sprite na ANO: "zoom A% -> B%, MID (x, y) -> (x, y)". */
    static String summary(Ano a, int sprite, Centralize.Plan p) {
        if (framesUsing(a, sprite) == 0) return "";
        for (Ano.Mpt m : a.mpts) {
            if (m.image != sprite) continue;
            SpriteDefaults.Def d = SpriteDefaults.read(m);
            return "zoom " + d.zx + "% → " + p.zoom + "%  ·  MID (" + d.midX + ", " + d.midY + ") → (" + p.midX + ", " + p.midY + ")";
        }
        return "";
    }
}
