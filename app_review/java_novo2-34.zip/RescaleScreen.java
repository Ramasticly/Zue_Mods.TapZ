package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * Tela do REESCALAR da lista de Sprites: para cada sprite marcada e cada ANO que a usa mostra a previa ANTES | DEPOIS e dois botoes, REESCALAR e NAO REESCALAR;
 * ao escolher vai para a proxima ANO da sprite e, acabando, para a proxima sprite. No fim aplica so os passos aceitos (zoom e MID dos Frames; o padrao da sprite
 * nao muda), depois da copia bruta do personagem. As contas ficam em {@link RescaleReview}; aqui so tela.
 */
final class RescaleScreen {
    private RescaleScreen() { }

    private static final int BG = 0xFF14171C, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, OK = 0xFF7CE08A, WARN = 0xFFFFB454, ACCENT = 0xFF4C8DFF;

    static void show(final Activity a, final CharAssets ca, final List<RescaleReview.Step> steps, final Map<Integer, Centralize.Plan> plans, final List<Integer> unused, final Runnable applied) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        int p = SpriteListScreen.dp(a, 12);
        root.setPadding(p, p, p, SpriteListScreen.dp(a, 10));
        d.setContentView(root);

        final TextView title = SpriteListScreen.text(a, "", 16, TEXT, true);
        root.addView(title);
        final TextView sub = SpriteListScreen.text(a, "", 11, DIM, false);
        sub.setPadding(0, SpriteListScreen.dp(a, 2), 0, SpriteListScreen.dp(a, 8));
        root.addView(sub);

        android.util.DisplayMetrics dm = a.getResources().getDisplayMetrics();
        int side = Math.min((dm.widthPixels - 3 * p) / 2, Math.round(dm.heightPixels * 0.40f));
        LinearLayout pair = new LinearLayout(a);
        pair.setOrientation(LinearLayout.HORIZONTAL);
        final FrameLayout beforeBox = new FrameLayout(a), afterBox = new FrameLayout(a);
        beforeBox.setBackgroundColor(0xFF0D0F13);
        afterBox.setBackgroundColor(0xFF0D0F13);
        pair.addView(beforeBox, new LinearLayout.LayoutParams(side, side));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(side, side);
        ap.setMargins(p, 0, 0, 0);
        pair.addView(afterBox, ap);
        root.addView(pair);
        LinearLayout caps = new LinearLayout(a);
        TextView cb = SpriteListScreen.text(a, "ANTES", 14, WARN, true), ca2 = SpriteListScreen.text(a, "DEPOIS", 14, OK, true);
        cb.setGravity(Gravity.CENTER);
        ca2.setGravity(Gravity.CENTER);
        caps.addView(cb, new LinearLayout.LayoutParams(side, -2));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(side, -2);
        cp.setMargins(p, 0, 0, 0);
        caps.addView(ca2, cp);
        caps.setPadding(0, SpriteListScreen.dp(a, 4), 0, SpriteListScreen.dp(a, 6));
        root.addView(caps);
        final TextView info = SpriteListScreen.text(a, "", 12, TEXT, false);
        info.setPadding(0, 0, 0, SpriteListScreen.dp(a, 8));
        root.addView(info);

        final int[] at = {0};
        final Dac[] work = {ca.dac};                                              // o DAC com as escolhas ja aceitas: o ANTES do passo seguinte
        final List<RescaleReview.Step> accepted = new ArrayList<RescaleReview.Step>();
        final Runnable[] next = {null};

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, SpriteListScreen.dp(a, 6), 0, 0);
        final TextView yes = SpriteListScreen.button(a, "REESCALAR", null);
        yes.setTextColor(OK);
        final TextView no = SpriteListScreen.button(a, "NÃO REESCALAR", null);
        final TextView cancel = SpriteListScreen.button(a, "CANCELAR TUDO", null);
        root.addView(yes, bp);
        root.addView(no, bp);
        root.addView(cancel, bp);

        final Runnable[] load = {null};
        load[0] = new Runnable() {
            @Override public void run() {
                RescaleReview.Step s = steps.get(at[0]);
                Centralize.Plan pl = plans.get(Integer.valueOf(s.sprite));
                title.setText("SPR_" + s.sprite + "  ·  ANO " + s.ano);
                sub.setText((at[0] + 1) + " de " + steps.size() + "  ·  " + accepted.size() + " aceito(s) até agora");
                info.setText(RescaleReview.summary(work[0].getAno(s.ano), s.sprite, pl));
                Dac after = RescaleReview.afterDac(work[0], s, pl);
                bind(a, ca, beforeBox, work[0], s.ano);
                bind(a, ca, afterBox, after, s.ano);
            }
        };
        next[0] = new Runnable() {
            @Override public void run() {
                at[0]++;
                if (at[0] >= steps.size()) { d.dismiss(); finish(a, ca, accepted, plans, unused, applied); return; }
                load[0].run();
            }
        };
        yes.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            RescaleReview.Step s = steps.get(at[0]);
            accepted.add(s);
            work[0] = RescaleReview.afterDac(work[0], s, plans.get(Integer.valueOf(s.sprite)));
            next[0].run();
        } });
        no.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { next[0].run(); } });
        final Runnable confirmCancel = new Runnable() { @Override public void run() {
            new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Cancelar")
                    .setMessage("Descartar as escolhas e sair sem reescalar nada?")
                    .setNegativeButton("CONTINUAR", null)
                    .setPositiveButton("DESCARTAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dlg, int w) { d.dismiss(); } }).show();
        } };
        cancel.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { confirmCancel.run(); } });
        d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override public boolean onKey(DialogInterface di, int key, android.view.KeyEvent ev) {
                if (key == android.view.KeyEvent.KEYCODE_BACK) { if (ev.getAction() == android.view.KeyEvent.ACTION_UP) confirmCancel.run(); return true; }
                return false;
            }
        });
        d.show();
        load[0].run();
    }

    /** Previa em laco da ANO {@code ano} do DAC {@code dac}. */
    private static void bind(Activity a, CharAssets ca, FrameLayout box, Dac dac, int ano) {
        box.removeAllViews();
        Ano an = dac.getAno(ano);
        if (an == null || !an.present) { box.addView(SpriteListScreen.text(a, "ANO vazia", 12, DIM, false)); return; }
        AnimPreview pv = new AnimPreview(a);
        pv.set(dac, ca.sprites, ano, false);
        // sem a flag de loop toca uma vez, segura o ultimo Frame ~1 s e recomeca; COM a flag fica em laco continuo
        if (!ObjModel.loops(an.mpts)) { pv.setPlayUntil(-1); pv.setAutoReplay(true); }
        box.addView(pv, new FrameLayout.LayoutParams(-1, -1));
    }

    /** Copia bruta do personagem, aplica os passos aceitos no DAC e grava as ANOs alteradas. */
    private static void finish(final Activity a, final CharAssets ca, final List<RescaleReview.Step> accepted, final Map<Integer, Centralize.Plan> plans, final List<Integer> unused, final Runnable applied) {
        if (accepted.isEmpty()) {
            new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Reescalar sprites").setMessage("Nenhuma ANO foi reescalada.").setPositiveButton("OK", null).show();
            return;
        }
        final BusyDialog busy = BusyDialog.show(a, "Reescalando sprites");
        busy.set("Copiando o personagem...", 0, 0);
        new Thread(new Runnable() {
            @Override public void run() {
                String out;
                boolean ok = false;
                try {
                    File bk = PreOptimBackup.run(ca.dir, new java.util.Date(), new Saver.CopyProgress() {
                        @Override public void on(String file, int dn, int total) { busy.set("Copiando o personagem\n" + file, dn, total); }
                    });
                    busy.set("Reescalando...", 0, 0);
                    int[] cnt = new int[1];
                    TreeSet<Integer> changed = RescaleReview.apply(ca.dac, accepted, plans, cnt);
                    String saved = SpriteMassDialogs.persist(ca, changed);
                    ok = true;
                    out = cnt[0] + " frame(s) em " + changed.size() + " ANO(s) reescalado(s) (" + accepted.size() + " de escolha(s))"
                            + (unused.isEmpty() ? "" : "\n\nSem uso em nenhuma ANO (nada a reescalar): " + unused)
                            + ".\n\nCópia bruta do personagem: " + bk.getPath() + (saved.isEmpty() ? "" : "\n" + SpriteMassDialogs.lastPersist);
                } catch (Throwable t) {
                    out = "Erro ao reescalar: " + t;
                }
                busy.dismiss();
                final String text = out;
                final boolean done = ok;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (done) applied.run();
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Reescalar sprites").setMessage(text).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }
}
