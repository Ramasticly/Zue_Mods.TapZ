package com.zue.attackeditor;

import android.content.Context;
import android.view.View;
import android.widget.ScrollView;

/**
 * ScrollView que nao derruba o app quando o foco ficou num filho que ja saiu dela (reconstruir a tela enquanto um campo de teclado ainda tem o foco):
 * o Android estoura {@code IllegalArgumentException: parameter must be a descendant of this view} em {@code onSizeChanged}/{@code isWithinDeltaOfScreen}.
 * Aqui o erro e engolido e o foco e solto. Use no lugar de {@link ScrollView} nas telas que se reconstroem. Tambem tem {@link #rebuild}.
 */
public class SafeScrollView extends ScrollView {
    public SafeScrollView(Context c) { super(c); }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        try { super.onSizeChanged(w, h, oldw, oldh); }
        catch (IllegalArgumentException e) { clearFocus(); }
    }

    @Override public void requestChildFocus(View child, View focused) {
        try { super.requestChildFocus(child, focused); }
        catch (IllegalArgumentException e) { clearFocus(); }
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        try { super.onLayout(changed, l, t, r, b); }
        catch (IllegalArgumentException e) { clearFocus(); }
    }

    /**
     * Solta o foco de dentro de {@code container} antes de trocar os filhos (o campo que ainda esta digitando perde o foco em vez de ficar apontado depois de removido).
     */
    static void releaseFocus(View container) {
        if (container == null) return;
        View f = container.findFocus();
        if (f != null) f.clearFocus();
    }
}
