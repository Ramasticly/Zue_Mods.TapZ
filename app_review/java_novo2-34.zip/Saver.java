package com.zue.attackeditor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Salva o que esta em memoria nos arquivos legiveis (.txt, formato DAC_ACT_ / $GOLPE_n). Os binarios originais
 * (000.dac / 000.bin / 000.cnv) nunca sao tocados: tudo vai para a subpasta {@code salvos/} do personagem.
 */
final class Saver {
    private Saver() { }

    static final String DIR = "salvos";

    // ---- quais ANOs um golpe usa ----

    /** ANOs do DAC do atacante que o golpe alcanca: campos do HDAT 4, links e hitboxes de animacao do personagem (71-125). */
    static TreeSet<Integer> anosOfMove(Dac dac, CharData.Move m) { return anosOfMove(dac, m, null); }

    /** Idem, e com {@code ch} tambem as ANOs das cutscenes (flag 20, ALVO 1 = pack do proprio personagem) e o ANO do oponente agarrado. */
    static TreeSet<Integer> anosOfMove(Dac dac, CharData.Move m, CharData ch) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        ArrayList<Integer> todo = new ArrayList<Integer>();
        int[] refs = {m.animInicial, m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao,
                m.subId, m.subAoAcertar, m.subChao, m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr,
                m.animEndAr, m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado};
        for (int r : refs) if (r > 0) todo.add(Integer.valueOf(r));
        if ((m.flags & 4) != 0 && m.projNormal > 0) { todo.add(Integer.valueOf(m.projNormal + 1)); todo.add(Integer.valueOf(m.projNormal + 2)); }
        if ((m.flags & (8 | 128)) != 0 && m.animInicial > 0) todo.add(Integer.valueOf(m.animInicial + 1));
        while (!todo.isEmpty()) {
            int i = todo.remove(todo.size() - 1).intValue();
            if (i < 0 || i >= dac.size() || out.contains(Integer.valueOf(i))) continue;
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            out.add(Integer.valueOf(i));
            for (int k = 0; k < a.links.length; k++) todo.add(Integer.valueOf(a.links[k].getAno()));
            for (int p = 0; p < a.mpts.length; p++) {
                Ano.Hit[] hs = a.mpts[p].hits;
                for (int h = 0; h < hs.length; h++) {
                    int f = hs[h].flag;
                    if (f >= 71 && f <= 125) todo.add(Integer.valueOf(201 + f - 71));
                    if (f == 20 && ch != null && ch.hasEvent(hs[h].width) && ch.eventField(hs[h].width, 0) == 1) {
                        todo.add(Integer.valueOf(ch.eventField(hs[h].width, 6)));
                        todo.add(Integer.valueOf(ch.eventField(hs[h].width, 8)));
                    }
                }
            }
        }
        return out;
    }

    // ---- textos ----

    static String dacText(Dac dac, java.util.Collection<Integer> only) {
        StringBuilder sb = new StringBuilder("DAC_ACT_ {\n");
        if (only == null) {
            for (int i = 0; i < dac.size(); i++) sb.append(indent(DacText.ano(dac.getAno(i), -1))).append('\n');
        } else {
            for (Integer i : only) sb.append(indent(DacText.ano(dac.getAno(i.intValue()), -1))).append('\n');
        }
        return sb.append("}\n").toString();
    }

    private static String indent(String s) {
        StringBuilder sb = new StringBuilder();
        String[] ls = s.split("\n", -1);
        for (int i = 0; i < ls.length; i++) { sb.append("   ").append(ls[i]); if (i < ls.length - 1) sb.append('\n'); }
        return sb.toString();
    }

    /** Tabelas de reacao do personagem (HDAT 14..33) citadas pelas hitboxes dos ANOs (OPT 1 de 30 a 49). */
    static TreeSet<Integer> reactionsUsed(Dac dac, java.util.Collection<Integer> anos) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        for (Integer ai : anos) {
            Ano a = dac.getAno(ai.intValue());
            if (a == null || !a.present) continue;
            for (int p = 0; p < a.mpts.length; p++) {
                Ano.Mpt m = a.mpts[p];
                if ((m.flags & 0x40) == 0 || m.hits.length == 0) continue;
                int idx = m.optData[1] % 50;
                if (idx >= 30 && idx < 30 + CharData.REACTION_COUNT) out.add(Integer.valueOf(idx - 30));
            }
        }
        return out;
    }

    private static final String[] FR_KEYS = {"DUR_C", "DUR_A", "ANO", "XSPEED", "YSPEED", "XACCEL", "YACCEL", "XSPEED_A", "YSPEED_A", "XACCEL_A", "YACCEL_A", "COMP", "WALL", "VOZ"};
    private static final boolean[] FR_SIGNED = {false, false, true, true, true, true, true, true, true, true, true, false, false, false};

    /** Linhas $FR_n da tabela, no formato do 000.bin.txt. */
    static String frLines(ReactionTable t, String ind) {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < t.rows; r++) {
            sb.append(ind).append("$FR_").append(r).append(": {");
            for (int c = 0; c < FR_KEYS.length; c++) {
                sb.append(c == 0 ? "" : ", ").append('$').append(FR_KEYS[c]).append(": ").append(FR_SIGNED[c] ? t.s8(r, c) : t.u8(r, c));
            }
            sb.append("},\n");
        }
        return sb.toString();
    }

    static String reactionText(ReactionTable t, int type) {
        int stride = ReactionTable.STRIDE;
        return "   $HDAT_" + (CharData.FIRST_REACTION_HDAT + type) + ":{$info:{$COL: " + stride + ", $ROW: " + t.rows
                + ", $SZ: &" + String.format(Locale.US, "%08X", t.rows * stride) + "},\n      $REACAO_DANO_" + type + ":{\n"
                + frLines(t, "         ") + "      },\n   },\n";
    }

    // ---- gravacao "no Runtime": edita os .txt de origem no lugar (blocos trocados, comentarios mantidos) ----

    /** {inicio do '$', indice da '{', indice da '}'} do bloco $KEY: {..}; null se nao existe. */
    static int[] findBlock(String text, String key) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\$" + java.util.regex.Pattern.quote(key) + "(?![0-9A-Za-z_])\\s*:\\s*\\{").matcher(text);
        while (m.find()) {
            int ls = text.lastIndexOf('\n', m.start()) + 1;
            if (text.substring(ls, m.start()).contains("//")) continue;       // dentro de comentario
            int open = m.end() - 1, depth = 0;
            for (int p = open; p < text.length(); p++) {
                char ch = text.charAt(p);
                if (ch == '/' && p + 1 < text.length() && text.charAt(p + 1) == '/') { while (p < text.length() && text.charAt(p) != '\n') p++; continue; }
                if (ch == '{') depth++;
                else if (ch == '}') { depth--; if (depth == 0) return new int[]{m.start(), open, p}; }
            }
            return null;
        }
        return null;
    }

    private static String lineIndent(String text, int pos) {
        int ls = text.lastIndexOf('\n', pos - 1) + 1;
        int e = ls;
        while (e < text.length() && (text.charAt(e) == ' ' || text.charAt(e) == '\t')) e++;
        return text.substring(ls, e);
    }

    /** Troca o bloco $ANO_n pelo texto atual do ANO. false se o bloco nao existe no arquivo. */
    static String patchAno(String text, Ano a, boolean[] found) {
        int[] b = findBlock(text, "ANO_" + a.index);
        found[0] = b != null;
        if (b == null) return text;
        String ind = lineIndent(text, b[0]);
        String nt = DacText.ano(a, -1);
        if (nt.endsWith(",")) nt = nt.substring(0, nt.length() - 1);
        String[] ls = nt.split("\n", -1);
        StringBuilder sb = new StringBuilder(ls[0]);
        for (int i = 1; i < ls.length; i++) sb.append('\n').append(ind).append(ls[i]);
        return text.substring(0, b[0]) + sb + text.substring(b[2] + 1);
    }

    /** Atualiza so os valores dos campos do $GOLPE_n (os comentarios do bloco ficam). */
    static String patchMove(String text, CharData.Move m, int idx, boolean[] found) {
        int[] b = findBlock(text, "GOLPE_" + idx);
        found[0] = b != null;
        if (b == null) return text;
        String blk = text.substring(b[0], b[2] + 1);
        int[] v = DacText.moveVals(m);
        for (int i = 0; i < DacText.MOVE_KEYS.length; i++) {
            blk = blk.replaceFirst("(\\$" + DacText.MOVE_KEYS[i] + "\\s*:\\s*)-?\\d+", "$1" + v[i]);
        }
        return text.substring(0, b[0]) + blk + text.substring(b[2] + 1);
    }

    /** $LARGURA (metade da largura) e $ALTURA do bloco $STATUS_BASE_E_FISICA (HDAT 3). */
    static String patchBody(String text, CharData cd) {
        int[] b = findBlock(text, "STATUS_BASE_E_FISICA");
        if (b == null) return text;
        String blk = text.substring(b[0], b[2] + 1);
        blk = blk.replaceFirst("(\\$LARGURA\\s*:\\s*)-?\\d+", "$1" + (cd.bodyWidth() / 2));
        blk = blk.replaceFirst("(\\$ALTURA\\s*:\\s*)-?\\d+", "$1" + cd.bodyHeight());
        return text.substring(0, b[0]) + blk + text.substring(b[2] + 1);
    }

    /** Troca as linhas $FR_n da reacao (mantem o dicionario de comentarios) e corrige $ROW/$SZ do HDAT. */
    static String patchReaction(String text, ReactionTable t, int type, boolean[] found) {
        int[] b = findBlock(text, "REACAO_DANO_" + type);
        found[0] = b != null;
        if (b == null) return text;
        int fr = -1;
        java.util.regex.Matcher fm = java.util.regex.Pattern.compile("\\$FR_\\d+\\s*:").matcher(text);
        for (int from = b[1]; fm.find(from); from = fm.end()) {
            int fls = text.lastIndexOf('\n', fm.start()) + 1;
            if (!text.substring(fls, fm.start()).contains("//")) { fr = fm.start(); break; }
        }
        String ind = "         ";
        String head;
        if (fr < 0 || fr > b[2]) head = text.substring(0, b[1] + 1) + "\n";
        else {
            int ls = text.lastIndexOf('\n', fr) + 1;
            ind = lineIndent(text, fr);
            head = text.substring(0, ls);
        }
        int closeLs = text.lastIndexOf('\n', b[2]) + 1;
        String closeInd = lineIndent(text, b[2]);
        String out = head + frLines(t, ind) + closeInd + text.substring(b[2]);
        // $info do HDAT 14+type
        int[] hb = findBlock(out, "HDAT_" + (CharData.FIRST_REACTION_HDAT + type));
        if (hb != null) {
            String hs = out.substring(hb[0], Math.min(out.length(), out.indexOf('}', hb[1]) + 1));
            String fixed = hs.replaceFirst("(\\$ROW\\s*:\\s*)\\d+", "$1" + t.rows)
                    .replaceFirst("(\\$SZ\\s*:\\s*&)[0-9A-Fa-f]+", "$1" + String.format(Locale.US, "%08X", t.rows * ReactionTable.STRIDE));
            out = out.substring(0, hb[0]) + fixed + out.substring(hb[0] + hs.length());
        }
        return out;
    }

    static String readText(File f) throws IOException {
        java.io.FileInputStream in = new java.io.FileInputStream(f);
        try {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return new String(o.toByteArray(), "UTF-8");
        } finally { in.close(); }
    }

    /** O que gravar no Runtime: ANOs e/ou golpes (HDAT 4 + reacoes do char). Devolve um resumo. */
    static String saveRuntime(File charDir, Dac dac, CharData data, java.util.Collection<Integer> anos, java.util.Collection<Integer> moves, boolean allReactions) throws IOException {
        int na = 0, nm = 0, nr = 0, miss = 0;
        java.util.TreeSet<Integer> rs = new java.util.TreeSet<Integer>();
        if (moves != null) for (Integer mi : moves) {
            CharData.Move mv = data.moves[mi.intValue()];
            java.util.TreeSet<Integer> as = anosOfMove(dac, mv, data);
            if (anos != null) as.addAll(anos);
            anos = as;
            rs.addAll(reactionsUsed(dac, as));
        }
        if (allReactions) for (int i = 0; i < CharData.REACTION_COUNT; i++) rs.add(Integer.valueOf(i));
        boolean[] f = new boolean[1];
        if (anos != null && !anos.isEmpty()) {
            File fd = new File(charDir, "000.dac.txt");
            if (!fd.isFile()) throw new IOException("000.dac.txt nao encontrado em " + charDir.getPath());
            String t = readText(fd);
            for (Integer i : anos) {
                Ano a = dac.getAno(i.intValue());
                if (a == null) continue;
                t = patchAno(t, a, f);
                if (f[0]) na++; else miss++;
            }
            write(fd, t);
        }
        if (moves != null && !moves.isEmpty() || !rs.isEmpty()) {
            File fb = new File(charDir, "000.bin.txt");
            if (!fb.isFile()) throw new IOException("000.bin.txt nao encontrado em " + charDir.getPath());
            String t = readText(fb);
            if (moves != null) for (Integer mi : moves) {
                t = patchMove(t, data.moves[mi.intValue()], mi.intValue(), f);
                if (f[0]) nm++; else miss++;
            }
            for (Integer ty : rs) {
                ReactionTable rt = data.reaction(ty.intValue());
                if (rt == null) continue;
                t = patchReaction(t, rt, ty.intValue(), f);
                if (f[0]) nr++; else miss++;
            }
            write(fb, t);
        }
        if (data != null) {
            File fb2 = new File(charDir, "000.bin.txt");
            if (fb2.isFile()) {
                String t0 = readText(fb2), t1 = patchBody(t0, data);
                if (!t1.equals(t0)) write(fb2, t1);
            }
        }
        String rules = anos == null ? "" : GameRules.summary(GameRules.check(dac, anos, 0));
        return na + " ANO(s), " + nm + " golpe(s), " + nr + " reacao(oes)" + (miss > 0 ? "  (" + miss + " bloco(s) nao achado(s) no .txt)" : "")
                + (rules.isEmpty() ? "" : "\n" + rules);
    }

    /** Um golpe: bloco $GOLPE_n, tabelas de reacao do personagem que ele usa e os ANOs que ele alcanca. */
    static String moveText(Dac dac, CharData data, CharData.Move m, int idx) {
        TreeSet<Integer> anos = anosOfMove(dac, m, data);
        StringBuilder sb = new StringBuilder();
        sb.append("// golpe ").append(idx).append(" (HDAT 4) + ANOs alcancados: ").append(anos).append('\n');
        String rules = GameRules.summary(GameRules.check(dac, anos, 0));
        if (!rules.isEmpty()) sb.append("// ATENCAO: ").append(rules).append('\n');
        sb.append(DacText.move(m, idx)).append("\n\n");
        TreeSet<Integer> rs = reactionsUsed(dac, anos);
        if (!rs.isEmpty()) {
            sb.append("BIN_CNV_ {\n");
            for (Integer t : rs) {
                ReactionTable rt = data.reaction(t.intValue());
                if (rt != null) sb.append(reactionText(rt, t.intValue()));
            }
            sb.append("}\n\n");
        }
        sb.append(dacText(dac, anos));
        return sb.toString();
    }

    // ---- gravacao ----

    static File dirOf(File charDir) {
        File d = new File(charDir, DIR);
        d.mkdirs();
        return d;
    }

    static void write(File f, String text) throws IOException {
        Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
        try { w.write(text); } finally { w.close(); }
    }

    /** Golpe atual (HDAT 4 + ANOs + reacoes do personagem). */
    static File saveMove(File charDir, Dac dac, CharData data, CharData.Move m, int idx) throws IOException {
        File f = new File(dirOf(charDir), String.format(Locale.US, "golpe_%02d.txt", idx));
        write(f, moveText(dac, data, m, idx));
        return f;
    }

    static File saveAno(File charDir, Dac dac, int index) throws IOException {
        File f = new File(dirOf(charDir), String.format(Locale.US, "ano_%03d.txt", index));
        write(f, dacText(dac, Collections.singletonList(Integer.valueOf(index))));
        return f;
    }

    /** Todos os golpes (cada um com seus ANOs) em golpes.txt. */
    static File saveAllMoves(File charDir, Dac dac, CharData data) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < data.moves.length; i++) sb.append(moveText(dac, data, data.moves[i], i)).append("\n");
        File f = new File(dirOf(charDir), "golpes.txt");
        write(f, sb.toString());
        return f;
    }

    /** Todos os ANOs no mesmo formato do 000.dac.txt (arquivo novo em salvos/, o original nao muda). */
    static File saveAllAnos(File charDir, Dac dac) throws IOException {
        File f = new File(dirOf(charDir), "000.dac.txt");
        write(f, dacText(dac, null));
        return f;
    }

    static List<File> saveAll(File charDir, Dac dac, CharData data) throws IOException {
        List<File> out = new ArrayList<File>();
        out.add(saveAllMoves(charDir, dac, data));
        out.add(saveAllAnos(charDir, dac));
        return out;
    }
}
