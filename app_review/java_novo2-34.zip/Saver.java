package com.zue.attackeditor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Salva o que esta em memoria nos arquivos legiveis (.txt, formato DAC_ACT_ / $GOLPE_n). Os binarios originais
 * (000.dac / 000.bin / 000.cnv) nunca sao tocados: "pasta separada" = {@code Tap Battle/TBRE/Chars/charNN/}; backups = {@code Tap Battle/TBRE/Backups/}.
 */
final class Saver {
    private Saver() { }

    /** Pasta do app ao lado de assets (Tap Battle/TBRE): Chars/ (salvar em pasta separada) e Backups/ (copias de seguranca). */
    static final String TBRE = "TBRE";

    /** {@code Tap Battle/TBRE} para um personagem em {@code Tap Battle/assets/charNN}. */
    static File tbreRoot(File charDir) {
        File p = charDir.getAbsoluteFile().getParentFile();
        File gp = p == null ? null : p.getParentFile();
        return new File(gp != null ? gp : (p != null ? p : charDir), TBRE);
    }

    // ---- quais ANOs um golpe usa ----

    /** ANOs do DAC do atacante que o golpe alcanca: campos do HDAT 4, links e hitboxes de animacao do personagem (71-125). */
    static TreeSet<Integer> anosOfMove(Dac dac, CharData.Move m) { return anosOfMove(dac, m, null); }

    /** Idem, e com {@code ch} tambem as ANOs das cutscenes (flag 20, ALVO 1 = pack do proprio personagem) e o ANO do oponente agarrado. */
    static TreeSet<Integer> anosOfMove(Dac dac, CharData.Move m, CharData ch) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        ArrayList<Integer> todo = new ArrayList<Integer>();
        int[] refs = {m.animInicial, m.projNormal, m.projAbaixo, m.projAcima, m.projGlobal, m.projAoAcertar, m.projChao,
                m.subId, m.subAoAcertar, m.subChao, m.animAoAcertar, m.animSeqChao, m.animEndChao, m.animSeqAr,
                m.animEndAr, m.pousoErrar, m.pousoAcertar, m.oponenteAgarrado};
        for (int r : refs) if (r > 0) todo.add(Integer.valueOf(r));
        if ((m.flags & 4) != 0 && m.projNormal > 0) { todo.add(Integer.valueOf(m.projNormal + 1)); todo.add(Integer.valueOf(m.projNormal + 2)); }
        if ((m.flags & (8 | 128)) != 0 && m.animInicial > 0) todo.add(Integer.valueOf(m.animInicial + 1));
        while (!todo.isEmpty()) {
            int i = todo.remove(todo.size() - 1).intValue();
            if (i < 0 || i >= dac.size() || out.contains(Integer.valueOf(i))) continue;
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            out.add(Integer.valueOf(i));
            for (int k = 0; k < a.links.length; k++) todo.add(Integer.valueOf(a.links[k].getAno()));
            for (int p = 0; p < a.mpts.length; p++) {
                Ano.Hit[] hs = a.mpts[p].hits;
                for (int h = 0; h < hs.length; h++) {
                    int f = hs[h].flag;
                    if (f >= 71 && f <= 125) todo.add(Integer.valueOf(201 + f - 71));
                    if (f == 20 && ch != null && ch.hasEvent(hs[h].width) && ch.eventField(hs[h].width, 0) == 1) {
                        todo.add(Integer.valueOf(ch.eventField(hs[h].width, 6)));
                        todo.add(Integer.valueOf(ch.eventField(hs[h].width, 8)));
                    }
                }
            }
        }
        return out;
    }

    // ---- textos ----

    static String dacText(Dac dac, java.util.Collection<Integer> only) {
        StringBuilder sb = new StringBuilder("DAC_ACT_ {\n");
        if (only == null) {
            for (int i = 0; i < dac.size(); i++) sb.append(indent(DacText.ano(dac.getAno(i), -1))).append('\n');
        } else {
            for (Integer i : only) sb.append(indent(DacText.ano(dac.getAno(i.intValue()), -1))).append('\n');
        }
        return sb.append("}\n").toString();
    }

    static String indent(String s) {
        StringBuilder sb = new StringBuilder();
        String[] ls = s.split("\n", -1);
        for (int i = 0; i < ls.length; i++) { sb.append("   ").append(ls[i]); if (i < ls.length - 1) sb.append('\n'); }
        return sb.toString();
    }

    /** Tabelas de reacao do personagem (HDAT 14..33) citadas pelas hitboxes dos ANOs (OPT 1 de 30 a 49). */
    static TreeSet<Integer> reactionsUsed(Dac dac, java.util.Collection<Integer> anos) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        for (Integer ai : anos) {
            Ano a = dac.getAno(ai.intValue());
            if (a == null || !a.present) continue;
            for (int p = 0; p < a.mpts.length; p++) {
                Ano.Mpt m = a.mpts[p];
                if ((m.flags & 0x40) == 0 || m.hits.length == 0) continue;
                int idx = m.optData[1] % 50;
                if (idx >= 30 && idx < 30 + CharData.REACTION_COUNT) out.add(Integer.valueOf(idx - 30));
            }
        }
        return out;
    }

    private static final String[] FR_KEYS = {"DUR_C", "DUR_A", "ANO", "XSPEED", "YSPEED", "XACCEL", "YACCEL", "XSPEED_A", "YSPEED_A", "XACCEL_A", "YACCEL_A", "COMP", "WALL", "VOZ"};
    private static final boolean[] FR_SIGNED = {false, false, true, true, true, true, true, true, true, true, true, false, false, false};

    /** Linhas $FR_n da tabela, no formato do 000.bin.txt. */
    static String frLines(ReactionTable t, String ind) {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < t.rows; r++) {
            sb.append(ind).append("$FR_").append(r).append(": {");
            for (int c = 0; c < FR_KEYS.length; c++) {
                sb.append(c == 0 ? "" : ", ").append('$').append(FR_KEYS[c]).append(": ").append(FR_SIGNED[c] ? t.s8(r, c) : t.u8(r, c));
            }
            sb.append("},\n");
        }
        return sb.toString();
    }

    static String reactionText(ReactionTable t, int type) {
        int stride = ReactionTable.STRIDE;
        return "   $HDAT_" + (CharData.FIRST_REACTION_HDAT + type) + ":{$info:{$COL: " + stride + ", $ROW: " + t.rows
                + ", $SZ: &" + String.format(Locale.US, "%08X", t.rows * stride) + "},\n      $REACAO_DANO_" + type + ":{\n"
                + frLines(t, "         ") + "      },\n   },\n";
    }

    // ---- gravacao "no Runtime": edita os .txt de origem no lugar (blocos trocados, comentarios mantidos) ----

    /** {inicio do '$', indice da '{', indice da '}'} do bloco $KEY: {..}; null se nao existe. */
    static int[] findBlock(String text, String key) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\$" + java.util.regex.Pattern.quote(key) + "(?![0-9A-Za-z_])\\s*:\\s*\\{").matcher(text);
        while (m.find()) {
            int ls = text.lastIndexOf('\n', m.start()) + 1;
            if (text.substring(ls, m.start()).contains("//")) continue;       // dentro de comentario
            int open = m.end() - 1, depth = 0;
            for (int p = open; p < text.length(); p++) {
                char ch = text.charAt(p);
                if (ch == '/' && p + 1 < text.length() && text.charAt(p + 1) == '/') { while (p < text.length() && text.charAt(p) != '\n') p++; continue; }
                if (ch == '{') depth++;
                else if (ch == '}') { depth--; if (depth == 0) return new int[]{m.start(), open, p}; }
            }
            return null;
        }
        return null;
    }

    private static String lineIndent(String text, int pos) {
        int ls = text.lastIndexOf('\n', pos - 1) + 1;
        int e = ls;
        while (e < text.length() && (text.charAt(e) == ' ' || text.charAt(e) == '\t')) e++;
        return text.substring(ls, e);
    }

    /** Troca o bloco $ANO_n pelo texto atual do ANO. false se o bloco nao existe no arquivo. */
    static String patchAno(String text, Ano a, boolean[] found) {
        int[] b = findBlock(text, "ANO_" + a.index);
        found[0] = b != null;
        if (b == null) return text;
        String ind = lineIndent(text, b[0]);
        String nt = DacText.ano(a, -1);
        if (nt.endsWith(",")) nt = nt.substring(0, nt.length() - 1);
        String[] ls = nt.split("\n", -1);
        StringBuilder sb = new StringBuilder(ls[0]);
        for (int i = 1; i < ls.length; i++) sb.append('\n').append(ind).append(ls[i]);
        return text.substring(0, b[0]) + sb + text.substring(b[2] + 1);
    }

    /** Atualiza so os valores dos campos do $GOLPE_n (os comentarios do bloco ficam). */
    static String patchMove(String text, CharData.Move m, int idx, boolean[] found) {
        int[] b = findBlock(text, "GOLPE_" + idx);
        found[0] = b != null;
        if (b == null) return text;
        String blk = text.substring(b[0], b[2] + 1);
        int[] v = DacText.moveVals(m);
        for (int i = 0; i < DacText.MOVE_KEYS.length; i++) {
            blk = blk.replaceFirst("(\\$" + DacText.MOVE_KEYS[i] + "\\s*:\\s*)-?\\d+", "$1" + v[i]);
        }
        return text.substring(0, b[0]) + blk + text.substring(b[2] + 1);
    }

    /** $LARGURA (metade da largura), $ALTURA e $DISTANCIA_AGARRE do bloco $STATUS_BASE_E_FISICA (HDAT 3). */
    static String patchBody(String text, CharData cd) {
        int[] b = findBlock(text, "STATUS_BASE_E_FISICA");
        if (b == null) return text;
        String blk = text.substring(b[0], b[2] + 1);
        blk = blk.replaceFirst("(\\$LARGURA\\s*:\\s*)-?\\d+", "$1" + (cd.bodyWidth() / 2));
        blk = blk.replaceFirst("(\\$ALTURA\\s*:\\s*)-?\\d+", "$1" + cd.bodyHeight());
        blk = blk.replaceFirst("(\\$DISTANCIA_AGARRE\\s*:\\s*)-?\\d+", "$1" + cd.pullDistance());
        return text.substring(0, b[0]) + blk + text.substring(b[2] + 1);
    }

    /**
     * Troca as linhas $FR_n da reacao (mantem o dicionario de comentarios) e corrige $ROW/$SZ do HDAT. Se o bloco $REACAO_DANO_n nao existe
     * (slot vazio no 000.bin.txt) ele e criado dentro do $HDAT_(14+n); se nem o $HDAT existe, {@code found[0]} = false e nada muda.
     */
    static String patchReaction(String text, ReactionTable t, int type, boolean[] found) {
        int[] b = findBlock(text, "REACAO_DANO_" + type);
        if (b == null) return insertReaction(text, t, type, found);
        found[0] = true;
        int fr = -1;
        java.util.regex.Matcher fm = java.util.regex.Pattern.compile("\\$FR_\\d+\\s*:").matcher(text);
        for (int from = b[1]; fm.find(from); from = fm.end()) {
            int fls = text.lastIndexOf('\n', fm.start()) + 1;
            if (!text.substring(fls, fm.start()).contains("//")) { fr = fm.start(); break; }
        }
        String ind = "         ";
        String head;
        if (fr < 0 || fr > b[2]) head = text.substring(0, b[1] + 1) + "\n";
        else {
            int ls = text.lastIndexOf('\n', fr) + 1;
            ind = lineIndent(text, fr);
            head = text.substring(0, ls);
        }
        String closeInd = lineIndent(text, b[2]);
        String out = head + frLines(t, ind) + closeInd + text.substring(b[2]);
        return fixHdatInfo(out, type, t.rows);
    }

    /** Cria o bloco $REACAO_DANO_n dentro do $HDAT_(14+n) que ja existe no texto (slot vazio). */
    private static String insertReaction(String text, ReactionTable t, int type, boolean[] found) {
        int[] hb = findBlock(text, "HDAT_" + (CharData.FIRST_REACTION_HDAT + type));
        found[0] = hb != null;
        if (hb == null) return text;
        String hind = lineIndent(text, hb[0]);
        String ind = hind + "   ";
        String inner = ind + "$REACAO_DANO_" + type + ":{\n" + frLines(t, ind + "   ") + ind + "},\n";
        int closeLs = text.lastIndexOf('\n', hb[2]) + 1;
        boolean ownLine = text.substring(closeLs, hb[2]).trim().isEmpty();
        int at = ownLine ? closeLs : hb[2];
        String before = text.substring(0, at);
        int q = before.length() - 1;
        while (q >= 0 && Character.isWhitespace(before.charAt(q))) q--;
        String comma = q >= 0 && before.charAt(q) == '}' ? "," : "";          // o $info{...} anterior precisa de virgula
        String out = ownLine
                ? before.substring(0, q + 1) + comma + before.substring(q + 1) + inner + text.substring(at)
                : before.substring(0, q + 1) + comma + "\n" + inner + hind + text.substring(at);
        return fixHdatInfo(out, type, t.rows);
    }

    /** $COL/$ROW/$SZ do $info do HDAT_(14+type). */
    private static String fixHdatInfo(String out, int type, int rows) {
        int[] hb = findBlock(out, "HDAT_" + (CharData.FIRST_REACTION_HDAT + type));
        if (hb == null) return out;
        String hs = out.substring(hb[0], Math.min(out.length(), out.indexOf('}', hb[1]) + 1));
        String fixed = hs.replaceFirst("(\\$COL\\s*:\\s*)\\d+", "$1" + ReactionTable.STRIDE)
                .replaceFirst("(\\$ROW\\s*:\\s*)\\d+", "$1" + rows)
                .replaceFirst("(\\$SZ\\s*:\\s*&)[0-9A-Fa-f]+", "$1" + String.format(Locale.US, "%08X", rows * ReactionTable.STRIDE));
        return out.substring(0, hb[0]) + fixed + out.substring(hb[0] + hs.length());
    }

    /** Slots de reacao do personagem (0..19) cujo $HDAT_(14+n) existe no 000.bin.txt: so nesses da para gravar uma reacao nova. */
    static java.util.TreeSet<Integer> writableReactionSlots(String binText) {
        java.util.TreeSet<Integer> out = new java.util.TreeSet<Integer>();
        for (int i = 0; i < CharData.REACTION_COUNT; i++) if (findBlock(binText, "HDAT_" + (CharData.FIRST_REACTION_HDAT + i)) != null) out.add(Integer.valueOf(i));
        return out;
    }

    static String readText(File f) throws IOException {
        java.io.FileInputStream in = new java.io.FileInputStream(f);
        try {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return new String(o.toByteArray(), "UTF-8");
        } finally { in.close(); }
    }

    /** O que gravar no Runtime: ANOs e/ou golpes (HDAT 4 + reacoes do char). Devolve um resumo. */
    static String saveRuntime(File charDir, Dac dac, CharData data, java.util.Collection<Integer> anos, java.util.Collection<Integer> moves, boolean allReactions) throws IOException {
        int na = 0, nm = 0, nr = 0, miss = 0;
        java.util.TreeSet<Integer> rs = new java.util.TreeSet<Integer>();
        if (moves != null) for (Integer mi : moves) {
            CharData.Move mv = data.moves[mi.intValue()];
            java.util.TreeSet<Integer> as = anosOfMove(dac, mv, data);
            if (anos != null) as.addAll(anos);
            anos = as;
            rs.addAll(reactionsUsed(dac, as));
        }
        if (allReactions) for (int i = 0; i < CharData.REACTION_COUNT; i++) rs.add(Integer.valueOf(i));
        boolean[] f = new boolean[1];
        if (anos != null && !anos.isEmpty()) {
            File fd = new File(charDir, "000.dac.txt");
            if (!fd.isFile()) throw new IOException("000.dac.txt nao encontrado em " + charDir.getPath());
            String t = readText(fd);
            java.util.List<Ano> novos = new java.util.ArrayList<Ano>();
            for (Integer i : anos) {
                Ano a = dac.getAno(i.intValue());
                if (a == null) continue;
                t = patchAno(t, a, f);
                if (f[0]) na++;
                else if (a.present) novos.add(a);              // ANO criado/colado alem do que o arquivo tem: entra como bloco novo no fim do DAC_ACT_
                else miss++;
            }
            if (!novos.isEmpty()) {
                java.util.Collections.sort(novos, new java.util.Comparator<Ano>() { public int compare(Ano x, Ano y) { return x.index - y.index; } });
                t = MoveTransplant.appendAnos(t, novos);
                na += novos.size();
            }
            write(fd, t);
        }
        if (moves != null && !moves.isEmpty() || !rs.isEmpty()) {
            File fb = new File(charDir, "000.bin.txt");
            if (!fb.isFile()) throw new IOException("000.bin.txt nao encontrado em " + charDir.getPath());
            String t = readText(fb);
            if (moves != null) for (Integer mi : moves) {
                t = patchMove(t, data.moves[mi.intValue()], mi.intValue(), f);
                if (f[0]) nm++; else miss++;
            }
            for (Integer ty : rs) {
                ReactionTable rt = data.reaction(ty.intValue());
                if (rt == null) continue;
                t = patchReaction(t, rt, ty.intValue(), f);
                if (f[0]) nr++; else miss++;
            }
            write(fb, t);
        }
        if (data != null) {
            File fb2 = new File(charDir, "000.bin.txt");
            if (fb2.isFile()) {
                String t0 = readText(fb2), t1 = patchBody(t0, data);
                if (data.eventsEdited()) t1 = CutsceneText.patch(t1, data, new boolean[1]);       // HDAT 13 (cutscenes) editado no app
                if (!t1.equals(t0)) write(fb2, t1);
            }
        }
        String rules = anos == null ? "" : GameRules.summary(GameRules.check(dac, anos, 0));
        return na + " ANO(s), " + nm + " golpe(s), " + nr + " reacao(oes)" + (miss > 0 ? "  (" + miss + " bloco(s) nao achado(s) no .txt)" : "")
                + (rules.isEmpty() ? "" : "\n" + rules);
    }

    /** Um golpe: bloco $GOLPE_n, tabelas de reacao do personagem que ele usa e os ANOs que ele alcanca. */
    static String moveText(Dac dac, CharData data, CharData.Move m, int idx) {
        TreeSet<Integer> anos = anosOfMove(dac, m, data);
        StringBuilder sb = new StringBuilder();
        sb.append("// golpe ").append(idx).append(" (HDAT 4) + ANOs alcancados: ").append(anos).append('\n');
        String rules = GameRules.summary(GameRules.check(dac, anos, 0));
        if (!rules.isEmpty()) sb.append("// ATENCAO: ").append(rules).append('\n');
        sb.append(DacText.move(m, idx)).append("\n\n");
        TreeSet<Integer> rs = reactionsUsed(dac, anos);
        if (!rs.isEmpty()) {
            sb.append("BIN_CNV_ {\n");
            for (Integer t : rs) {
                ReactionTable rt = data.reaction(t.intValue());
                if (rt != null) sb.append(reactionText(rt, t.intValue()));
            }
            sb.append("}\n\n");
        }
        sb.append(dacText(dac, anos));
        return sb.toString();
    }

    // ---- gravacao ----

    /** Pasta separada do personagem: Tap Battle/TBRE/Chars/charNN/ (criada se preciso). */
    static File dirOf(File charDir) {
        File d = new File(new File(tbreRoot(charDir), "Chars"), charDir.getName());
        d.mkdirs();
        return d;
    }

    /**
     * Pasta de apoio do personagem: Tap Battle/TBRE/utils/charNN/. Tudo o que NAO e do personagem (arquivos de apoio a edicao e temporarios) fica aqui;
     * na pasta do char ficam so os arquivos dele (DAC, CNV, Bin, PNGs, audios, GIFs).
     */
    static File utilsDir(File charDir) {
        File d = utilsPath(charDir);
        d.mkdirs();
        return d;
    }

    /** Como {@link #utilsDir}, sem criar a pasta (para so ler). */
    static File utilsPath(File charDir) { return new File(new File(tbreRoot(charDir), "utils"), charDir.getName()); }

    /** Pasta dos temporarios das gravacoes atomicas do personagem (utils/charNN/tmp), criada se preciso. */
    static File tmpDir(File charDir) {
        File d = new File(utilsPath(charDir), "tmp");
        d.mkdirs();
        return d;
    }

    /** Move {@code tmp} para {@code dest} (troca o arquivo antigo); se o rename falha (outro volume) copia e apaga. */
    static void moveInto(File tmp, File dest) throws IOException {
        if (dest.exists() && !dest.delete()) throw new IOException("nao consegui substituir " + dest.getName());
        if (tmp.renameTo(dest)) return;
        java.io.FileInputStream in = new java.io.FileInputStream(tmp);
        try {
            FileOutputStream out = new FileOutputStream(dest);
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally { out.close(); }
        } finally { in.close(); }
        if (!tmp.delete()) tmp.deleteOnExit();
    }

    /** Copias de seguranca: Tap Battle/TBRE/Backups/ (criada se preciso). */
    static File backupsDir(File charDir) {
        File d = new File(tbreRoot(charDir), "Backups");
        d.mkdirs();
        return d;
    }

    // ---- salvar em pasta separada: copia completa do personagem + a mesma gravacao do Runtime ----

    /** Progresso da copia: arquivo atual e quantos ja foram, de quantos. */
    interface CopyProgress { void on(String file, int done, int total); }

    /** Pasta separada do personagem: Tap Battle/TBRE/Chars/{@code name}/ (nao cria). */
    static File separateDir(File charDir, String name) { return new File(new File(tbreRoot(charDir), "Chars"), name); }

    /** Primeiro nome livre em TBRE/Chars: base_2, base_3... */
    static String freeName(File charDir, String base) {
        File chars = new File(tbreRoot(charDir), "Chars");
        for (int i = 2; i < 10000; i++) if (!new File(chars, base + "_" + i).exists()) return base + "_" + i;
        return base + "_" + System.currentTimeMillis();
    }

    /** So apaga pastas dentro de TBRE/Chars (nunca assets nem o proprio Chars). */
    static boolean isSeparateCopy(File dir) {
        File p = dir.getAbsoluteFile().getParentFile(), gp = p == null ? null : p.getParentFile();
        return p != null && gp != null && p.getName().equals("Chars") && gp.getName().equals(TBRE);
    }

    static void deleteTree(File f) throws IOException {
        File[] k = f.listFiles();
        if (k != null) for (File c : k) deleteTree(c);
        if (f.exists() && !f.delete()) throw new IOException("nao consegui apagar " + f.getPath());
    }

    private static int countFiles(File dir, boolean includeSalvos) {
        int n = 0;
        File[] k = dir.listFiles();
        if (k != null) for (File c : k) n += c.isDirectory() ? (!includeSalvos && c.getName().equals("salvos") ? 0 : countFiles(c, includeSalvos)) : 1;
        return n;
    }

    /**
     * Copia o personagem inteiro (arquivos e subpastas, menos a velha pasta salvos/) de {@code src} para {@code dst}. {@code merge}: o que ja existe em
     * {@code dst} fica como esta (une as duas pastas); sem merge sobrescreve.
     */
    static void copyChar(File src, File dst, boolean merge, CopyProgress prog) throws IOException { copyChar(src, dst, merge, prog, false); }

    /** Como acima; {@code includeSalvos} tambem copia a velha pasta salvos/ (copia BRUTA: backups). */
    static void copyChar(File src, File dst, boolean merge, CopyProgress prog, boolean includeSalvos) throws IOException {
        int[] done = {0};
        int total = countFiles(src, includeSalvos);
        File tmp = tmpDir(src);
        copyTree(src, dst, merge, prog, done, total, includeSalvos, tmp);
        if (isSeparateCopy(dst)) copyUtils(src, utilsDir(dst), merge, tmp);          // a copia em TBRE/Chars leva o apoio (grupos de GIF, padroes) junto
    }

    /** Copia utils/charNN de {@code srcChar} para {@code dstUtils} (sem a subpasta tmp). */
    static void copyUtils(File srcChar, File dstUtils, boolean merge, File tmpRoot) throws IOException {
        File ut = utilsPath(srcChar);
        if (!ut.isDirectory()) return;
        copyTree(ut, dstUtils, merge, null, new int[1], 0, true, tmpRoot);
        File t = new File(dstUtils, "tmp");
        if (t.isDirectory()) deleteTree(t);
        String[] left = dstUtils.list();
        if (left != null && left.length == 0) dstUtils.delete();          // nada de apoio para levar: nao deixa pasta vazia
    }

    private static void copyTree(File src, File dst, boolean merge, CopyProgress prog, int[] done, int total, boolean includeSalvos, File tmpRoot) throws IOException {
        if (!dst.isDirectory() && !dst.mkdirs()) throw new IOException("nao consegui criar " + dst.getPath());
        File[] kids = src.listFiles();
        if (kids == null) return;
        java.util.Arrays.sort(kids);
        for (File k : kids) {
            File to = new File(dst, k.getName());
            if (k.isDirectory()) {
                if (!includeSalvos && k.getName().equals("salvos")) continue;
                copyTree(k, to, merge, prog, done, total, includeSalvos, tmpRoot);
                continue;
            }
            if (!(merge && to.exists())) {
                File tmp = new File(tmpRoot, to.getName() + ".tmp");          // temporario fora da pasta do personagem (utils/charNN/tmp)
                java.io.FileInputStream in = new java.io.FileInputStream(k);
                try {
                    FileOutputStream out = new FileOutputStream(tmp);
                    try {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    } finally { out.close(); }
                } finally { in.close(); }
                moveInto(tmp, to);
            }
            done[0]++;
            if (prog != null) prog.on(k.getName(), done[0], total);
        }
    }

    /**
     * As 5 formas de salvar do menu aplicadas a uma pasta de personagem (o Runtime ou uma copia): 0 golpe {@code moveIdx}, 1 ANO {@code anoIdx},
     * 2 todos os golpes (com todas as reacoes), 3 todos os ANOs, 4 tudo. Devolve o resumo de {@link #saveRuntime}.
     */
    static String saveInto(File dir, Dac dac, CharData cd, int which, int moveIdx, int anoIdx) throws IOException {
        java.util.ArrayList<Integer> allM = new java.util.ArrayList<Integer>();
        for (int i = 0; i < cd.moves.length; i++) allM.add(Integer.valueOf(i));
        java.util.ArrayList<Integer> allA = new java.util.ArrayList<Integer>();
        for (int i = 0; i < dac.size(); i++) { Ano an = dac.getAno(i); if (an != null && an.present) allA.add(Integer.valueOf(i)); }
        if (which == 0) return saveRuntime(dir, dac, cd, null, Collections.singletonList(Integer.valueOf(moveIdx)), false);
        if (which == 1) return saveRuntime(dir, dac, cd, Collections.singletonList(Integer.valueOf(anoIdx)), null, false);
        if (which == 2) return saveRuntime(dir, dac, cd, null, allM, true);
        if (which == 3) return saveRuntime(dir, dac, cd, allA, null, false);
        return saveRuntime(dir, dac, cd, allA, allM, true);
    }

    static void write(File f, String text) throws IOException {
        Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
        try { w.write(text); } finally { w.close(); }
    }

    /** Golpe atual (HDAT 4 + ANOs + reacoes do personagem). */
    static File saveMove(File charDir, Dac dac, CharData data, CharData.Move m, int idx) throws IOException {
        File f = new File(dirOf(charDir), String.format(Locale.US, "golpe_%02d.txt", idx));
        write(f, moveText(dac, data, m, idx));
        return f;
    }

    static File saveAno(File charDir, Dac dac, int index) throws IOException {
        File f = new File(dirOf(charDir), String.format(Locale.US, "ano_%03d.txt", index));
        write(f, dacText(dac, Collections.singletonList(Integer.valueOf(index))));
        return f;
    }

    /** Todos os golpes (cada um com seus ANOs) em golpes.txt. */
    static File saveAllMoves(File charDir, Dac dac, CharData data) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < data.moves.length; i++) sb.append(moveText(dac, data, data.moves[i], i)).append("\n");
        File f = new File(dirOf(charDir), "golpes.txt");
        write(f, sb.toString());
        return f;
    }

    /** Todos os ANOs no mesmo formato do 000.dac.txt (arquivo novo na pasta separada, o original nao muda). */
    static File saveAllAnos(File charDir, Dac dac) throws IOException {
        File f = new File(dirOf(charDir), "000.dac.txt");
        write(f, dacText(dac, null));
        return f;
    }

    static List<File> saveAll(File charDir, Dac dac, CharData data) throws IOException {
        List<File> out = new ArrayList<File>();
        out.add(saveAllMoves(charDir, dac, data));
        out.add(saveAllAnos(charDir, dac));
        return out;
    }
}
