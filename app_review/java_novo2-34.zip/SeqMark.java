package com.zue.attackeditor;

/** Um ponto da timeline onde o golpe pode trocar de ANO (calculado pela simulacao). */
public final class SeqMark {
    public static final int SEQ = 0, END = 1, HIT = 2, LAND = 3, FALL = 4, GRAB = 5;
    /** SEQ = ANIM_SEQ; END = ANIM_END; HIT = ANIM_AO_ACERTAR; LAND = pouso (errar/acertar); FALL = queda (ANO 89 fixa). */
    public int kind;
    /** Frame (indice do sprite) da ANO onde acontece. */
    public int pat;
    /** ANO de destino atual (LAND: a do pouso ao errar). */
    public int target;
    /** LAND: a do pouso ao acertar. */
    public int target2;
    /** Atacante no ar (usa os campos *_AR do golpe) ou no chao. */
    public boolean air;
    /** O frame tem a flag 38 (bloqueia a troca). */
    public boolean blocked;
    /** Aconteceu de fato na simulacao completa (nao so possivel). */
    public boolean real;
    /** Marcador de entrada: a ANO foi alcancada por esta troca, vinda de fromAno/fromPat. */
    public boolean incoming;
    public int fromAno, fromPat, tick;
    /** O hit veio de um projetil. */
    public boolean projectile;

    public String label() {
        if (incoming) return "← " + new String[]{"SEQ", "END", "SEQ_PROJ", "POUSO", "QUEDA", "AGARRAR"}[kind] + " " + fromAno + "·f" + (fromPat + 1);
        switch (kind) {
            case SEQ: return "SEQ" + (blocked ? " ✕" : " → " + target);
            case END: return "END" + (blocked ? " ✕" : " → " + target);
            case HIT: return "SEQ_PROJ" + (blocked ? " ✕" : " → " + target);
            case LAND: return "POUSO " + (target == 0 ? 13 : target) + "/" + (target2 == 0 ? 13 : target2);
            case GRAB: return "AGARRAR → " + target;
            default: return "QUEDA → 89";
        }
    }

    public String title() {
        if (incoming) return "ENTRADA";
        switch (kind) {
            case SEQ: return "SEQUENCIA";
            case END: return "FIM DO GOLPE";
            case HIT: return "SEQ_PROJETIL";
            case LAND: return "POUSO";
            case GRAB: return "TENTAR AGARRAO";
            default: return "QUEDA";
        }
    }
}
