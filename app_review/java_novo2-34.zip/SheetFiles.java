package com.zue.attackeditor;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Folhas PNG de uma pasta. O {@code $src} do CNV e o INDICE da folha na lista dos PNG (ordem do nome), nao o numero do nome:
 * com 017.png, 018.cnv e 019.png, o {@code $src:18} e a 019.png. Java puro (testado sem Android).
 */
final class SheetFiles {
    private SheetFiles() { }

    private static final Pattern SHEET = Pattern.compile("(\\d{3})\\.png", Pattern.CASE_INSENSITIVE);

    /** E nome de folha (NNN.png)? */
    static boolean isSheetName(String name) { return name != null && SHEET.matcher(name).matches(); }

    /** Numero do nome (017 em 017.png), ou -1. */
    static int numberOf(String name) {
        Matcher m = name == null ? null : SHEET.matcher(name);
        return m != null && m.matches() ? Integer.parseInt(m.group(1)) : -1;
    }

    /** Nome de uma folha pelo numero (o unico lugar que formata). */
    static String name(int number) { return String.format(Locale.US, "%03d.png", number); }

    /** As folhas da pasta (NNN.png), em ordem de numero: a posicao na lista e o {@code $src}. */
    static List<File> list(File dir) {
        ArrayList<File> out = new ArrayList<File>();
        File[] fs = dir == null ? null : dir.listFiles();
        if (fs == null) return out;
        for (File f : fs) if (f.isFile() && isSheetName(f.getName())) out.add(f);
        Collections.sort(out, new Comparator<File>() {
            @Override public int compare(File a, File b) {
                int d = numberOf(a.getName()) - numberOf(b.getName());
                return d != 0 ? d : a.getName().compareTo(b.getName());
            }
        });
        return out;
    }

    /** A folha de indice {@code src}, ou null se a pasta tem menos folhas. */
    static File file(File dir, int src) {
        if (src < 0) return null;
        List<File> l = list(dir);
        return src < l.size() ? l.get(src) : null;
    }

    static int count(File dir) { return list(dir).size(); }

    /** Numero de uma folha nova: depois da ultima, para ela ganhar o indice {@code count} (0 se nao ha folhas). */
    static int nextNumber(File dir) { return nextNumber(list(dir)); }

    static int nextNumber(List<File> sheets) {
        int max = -1;
        for (File f : sheets) max = Math.max(max, numberOf(f.getName()));
        return max + 1;
    }
}
