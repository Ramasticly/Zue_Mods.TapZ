package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Compactar as folhas: planeja mover sprites das folhas de tras para vaos (areas livres) de folhas ANTERIORES, a primeira que couber, para as PNGs do inicio
 * ficarem cheias e as do fim esvaziarem. So movimentos entre folhas existentes (nunca cria folha: o limite de tamanho nao e tocado). O numero da sprite nao
 * muda, so o recorte (folha, x, y) no CNV. Java puro.
 */
final class SheetPack {
    private SheetPack() { }

    /** Uma unidade que muda de lugar: as sprites que dividem o mesmo recorte vao juntas. */
    static final class Move {
        int[] sprites;
        int fromSheet, fromX, fromY, w, h;       // recorte antigo (logico)
        int toSheet, toX, toY;                   // novo lugar (logico)
    }

    private static boolean overlap(Cnv.Entry a, Cnv.Entry b) {
        return a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height;
    }

    private static boolean same(Cnv.Entry a, Cnv.Entry b) {
        return a.source == b.source && a.x == b.x && a.y == b.y && a.width == b.width && a.height == b.height;
    }

    /**
     * Plano de movimentos. {@code cnv} e ATUALIZADO a cada movimento (para os vaos abertos/fechados valerem nos seguintes); quem executa os pixels usa a lista.
     * {@code fixed[i]} (ou null) = a sprite i nao deve se mover (ex.: recorte com problema).
     */
    static List<Move> plan(Cnv cnv, SpriteAlloc.Sheets sh, int scale, int gap, boolean[] fixed) {
        List<Move> out = new ArrayList<Move>();
        for (int pass = 0; pass < 4; pass++) {
            int before = out.size();
            final List<List<Integer>> units = units(cnv, sh, scale, fixed);
            Collections.sort(units, new Comparator<List<Integer>>() {
                @Override public int compare(List<Integer> a, List<Integer> b) {
                    Cnv.Entry x = cnv.byImage(a.get(0)), y = cnv.byImage(b.get(0));
                    if (x.source != y.source) return y.source - x.source;                       // folhas do fim primeiro
                    long ax = (long) x.width * x.height, ay = (long) y.width * y.height;
                    if (ax != ay) return ay > ax ? 1 : -1;                                       // maiores primeiro
                    return a.get(0) - b.get(0);
                }
            });
            for (List<Integer> u : units) {
                Cnv.Entry e = cnv.byImage(u.get(0));
                if (e.source <= 0) continue;
                for (int s = 0; s < e.source; s++) {
                    SpriteAlloc.Spot sp = SpriteAlloc.findIn(cnv, sh, scale, e.width, e.height, gap, s);
                    if (sp == null) continue;
                    Move m = new Move();
                    m.sprites = new int[u.size()];
                    for (int k = 0; k < m.sprites.length; k++) m.sprites[k] = u.get(k).intValue();
                    m.fromSheet = e.source; m.fromX = e.x; m.fromY = e.y; m.w = e.width; m.h = e.height;
                    m.toSheet = s; m.toX = sp.x; m.toY = sp.y;
                    for (int idx : m.sprites) cnv.set(idx, s, sp.x, sp.y, m.w, m.h);
                    out.add(m);
                    break;
                }
            }
            if (out.size() == before) break;
        }
        return out;
    }

    /** Unidades que podem se mover: sprites de recorte identico juntas; fora as que sobrepoem outro recorte so em parte, saem da folha ou estao marcadas como fixas. */
    private static List<List<Integer>> units(Cnv cnv, SpriteAlloc.Sheets sh, int scale, boolean[] fixed) {
        int n = cnv.size();
        List<List<Integer>> bySheet = new ArrayList<List<Integer>>();
        for (int i = 0; i < n; i++) {
            Cnv.Entry e = cnv.byImage(i);
            if (e.width <= 0 || e.height <= 0) continue;
            while (bySheet.size() <= e.source) bySheet.add(new ArrayList<Integer>());
            if (e.source >= 0) bySheet.get(e.source).add(Integer.valueOf(i));
        }
        List<List<Integer>> out = new ArrayList<List<Integer>>();
        boolean[] done = new boolean[n];
        for (int s = 0; s < bySheet.size(); s++) {
            List<Integer> on = bySheet.get(s);
            if (s >= sh.count()) continue;
            int sw = sh.width(s) / scale, shh = sh.height(s) / scale;
            for (Integer a : on) {
                if (done[a.intValue()]) continue;
                Cnv.Entry ea = cnv.byImage(a.intValue());
                List<Integer> unit = new ArrayList<Integer>();
                boolean movable = ea.x >= 0 && ea.y >= 0 && ea.x + ea.width <= sw && ea.y + ea.height <= shh;
                for (Integer b : on) {
                    Cnv.Entry eb = cnv.byImage(b.intValue());
                    if (same(ea, eb)) { unit.add(b); if (fixed != null && b.intValue() < fixed.length && fixed[b.intValue()]) movable = false; }
                    else if (overlap(ea, eb)) movable = false;
                }
                for (Integer b : unit) done[b.intValue()] = true;
                if (movable) out.add(unit);
            }
        }
        return out;
    }
}
