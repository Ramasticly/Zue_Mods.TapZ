package com.zue.attackeditor;

import java.util.Collection;
import java.util.TreeSet;

/**
 * Exclusao de sprites NA FOLHA: o retangulo do recorte e apagado (fica transparente) e a folha PNG que ficar sem nenhuma sprite sai da pasta. Como o
 * {@code $src} do CNV e o INDICE da folha (ordem do nome), tirar uma folha desloca as seguintes e o CNV e renumerado. Java puro.
 */
final class SheetPurge {
    private SheetPurge() { }

    /** Retangulo {x, y, w, h} em pixels da folha ({@code scale} x o recorte logico), cortado ao tamanho da folha; null se nao sobra nada. */
    static int[] rect(Cnv.Entry e, int scale, int sheetW, int sheetH) {
        if (e == null || e.width <= 0 || e.height <= 0 || scale <= 0) return null;
        long x0 = (long) e.x * scale, y0 = (long) e.y * scale, x1 = x0 + (long) e.width * scale, y1 = y0 + (long) e.height * scale;
        x0 = Math.max(0, x0); y0 = Math.max(0, y0);
        x1 = Math.min(sheetW, x1); y1 = Math.min(sheetH, y1);
        if (x1 <= x0 || y1 <= y0) return null;
        return new int[]{(int) x0, (int) y0, (int) (x1 - x0), (int) (y1 - y0)};
    }

    /** Alguma entrada COM tamanho usa a folha {@code sheet}? (entradas vazias nao contam) */
    static boolean referenced(Cnv cnv, int sheet) {
        for (int i = 0; i < cnv.size(); i++) {
            Cnv.Entry e = cnv.byImage(i);
            if (e.source == sheet && e.width > 0 && e.height > 0) return true;
        }
        return false;
    }

    /** Das folhas {@code touched} (as que perderam algum recorte), as que nenhuma sprite usa mais. Em ordem. */
    static TreeSet<Integer> unreferenced(Cnv cnv, int nSheets, Collection<Integer> touched) {
        TreeSet<Integer> out = new TreeSet<Integer>();
        for (Integer s : touched) if (s.intValue() >= 0 && s.intValue() < nSheets && !referenced(cnv, s.intValue())) out.add(s);
        return out;
    }

    /** A folha {@code removedSheet} saiu da lista: as entradas (com tamanho) das folhas seguintes passam a apontar para o indice anterior. */
    static void renumberSources(Cnv cnv, int removedSheet) {
        for (int i = 0; i < cnv.size(); i++) {
            Cnv.Entry e = cnv.byImage(i);
            if (e.width > 0 && e.height > 0 && e.source > removedSheet) cnv.set(i, e.source - 1, e.x, e.y, e.width, e.height);
        }
    }

    /**
     * Retangulos {x, y, w, h} em pixels da folha {@code s} que NENHUMA sprite do CNV cobre (o complemento da uniao dos recortes), cortados ao tamanho da folha.
     * Tudo isso deve ficar transparente.
     */
    static java.util.List<int[]> outsideRects(Cnv cnv, int s, int scale, int sheetW, int sheetH) {
        java.util.ArrayList<int[]> out = new java.util.ArrayList<int[]>();
        if (scale <= 0 || sheetW <= 0 || sheetH <= 0) return out;
        int lw = (sheetW + scale - 1) / scale, lh = (sheetH + scale - 1) / scale;
        for (int[] r : SpriteAlloc.uncovered(cnv, s, 0, 0, lw, lh)) {
            long x0 = (long) r[0] * scale, y0 = (long) r[1] * scale, x1 = Math.min(sheetW, x0 + (long) r[2] * scale), y1 = Math.min(sheetH, y0 + (long) r[3] * scale);
            if (x1 > x0 && y1 > y0) out.add(new int[]{(int) x0, (int) y0, (int) (x1 - x0), (int) (y1 - y0)});
        }
        return out;
    }

    /** Ha algum pixel nao transparente (alpha != 0) dentro de {@code r} em {@code px} (w x h)? */
    static boolean hasPixels(int[] px, int w, int h, int[] r) {
        for (int y = Math.max(0, r[1]); y < Math.min(h, r[1] + r[3]); y++)
            for (int x = Math.max(0, r[0]); x < Math.min(w, r[0] + r[2]); x++) if ((px[y * w + x] >>> 24) != 0) return true;
        return false;
    }

    /** Zera (transparente) os pixels de {@code r}. */
    static void clear(int[] px, int w, int h, int[] r) {
        for (int y = Math.max(0, r[1]); y < Math.min(h, r[1] + r[3]); y++)
            for (int x = Math.max(0, r[0]); x < Math.min(w, r[0] + r[2]); x++) px[y * w + x] = 0;
    }
}
