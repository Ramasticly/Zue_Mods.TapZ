package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.Locale;

/** "Mais" de um som: volume, tom, velocidade (com opcao de unir tom e velocidade) e igualar o volume pela media dos outros sons. */
final class SoundAdjust {
    interface Done { void on(byte[] wav); }

    private final Activity a;
    private final short[] pcm;
    private final double othersRms;          // media do volume dos outros sons (0 = nao ha outros)
    private final Done done;
    private final float d;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Dialog dlg;
    private SeekBar sVol, sTone, sSpeed;
    private TextView tVol, tTone, tSpeed, info, playBtn;
    private CheckBox cLink, cEq;
    private android.media.MediaPlayer mp;
    private boolean busy, updating;

    private SoundAdjust(Activity a, byte[] wav, double othersRms, Done done) {
        this.a = a;
        this.pcm = AudioConvert.pcmOf(wav);
        this.othersRms = othersRms;
        this.done = done;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    static void show(Activity a, byte[] wav, double othersRms, Done done) {
        new SoundAdjust(a, wav, othersRms, done).open();
    }

    /** Volume medio (RMS dos trechos com som) dos outros sons do personagem; 0 se nao ha nenhum com som. */
    static double averageOthers(File dir, File self) {
        double sum = 0;
        int n = 0;
        for (File f : CharSounds.list(dir)) {
            if (f.equals(self) || CharSounds.isEmpty(f)) continue;
            try {
                double r = AudioEffects.activeRms(AudioConvert.pcmOf(GameData.readAll(f)));
                if (r > 0) { sum += r; n++; }
            } catch (java.io.IOException ignored) { }
        }
        return n == 0 ? 0 : sum / n;
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private SeekBar bar(int max, int progress, LinearLayout box, TextView label) {
        label.setPadding(0, dp(10), 0, 0);
        box.addView(label);
        SeekBar s = new SeekBar(a);
        s.setMax(max);
        s.setProgress(progress);
        s.setPadding(dp(14), dp(4), dp(14), dp(2));
        box.addView(s);
        return s;
    }

    private CheckBox check(String text) {
        CheckBox c = new I18nCheckBox(a);
        c.setText(text);
        c.setTextColor(LayoutManager.TEXT);
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        c.setPadding(dp(4), dp(6), 0, dp(6));
        return c;
    }

    private float volume() { return sVol.getProgress() / 100f; }                       // 0..300%
    private float semis() { return sTone.getProgress() - 12; }                         // -12..+12
    private float speed() { return (50 + sSpeed.getProgress()) / 100f; }               // 50..200%

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        box.setPadding(dp(14), dp(14), dp(14), dp(10));

        box.addView(tv("Ajustar som", 17, LayoutManager.TEXT, true));
        info = tv("", 12, LayoutManager.DIM, false);
        info.setPadding(0, dp(2), 0, dp(4));
        box.addView(info);

        tVol = tv("", 14, LayoutManager.ACCENT, true);
        sVol = bar(300, 100, box, tVol);
        tTone = tv("", 14, LayoutManager.ACCENT, true);
        sTone = bar(24, 12, box, tTone);
        tSpeed = tv("", 14, LayoutManager.ACCENT, true);
        sSpeed = bar(150, 50, box, tSpeed);

        cLink = check("Unir tom e velocidade (como acelerar uma fita)");
        box.addView(cLink);
        cEq = check("Igualar o volume aos outros sons");
        if (othersRms <= 0) { cEq.setEnabled(false); cEq.setText("Igualar o volume (nao ha outros sons com audio)"); }
        box.addView(cEq);

        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (updating) return;
                if (fromUser && cLink.isChecked()) {
                    // unidos: tom e velocidade sao a mesma coisa (2^(semitons/12)); o outro controle acompanha
                    updating = true;
                    if (s == sTone) sSpeed.setProgress(clamp((int) Math.round(100 * Math.pow(2, semis() / 12.0)) - 50, 0, 150));
                    else if (s == sSpeed) sTone.setProgress(clamp((int) Math.round(12 * Math.log(speed()) / Math.log(2)) + 12, 0, 24));
                    updating = false;
                }
                refresh();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        };
        sVol.setOnSeekBarChangeListener(l);
        sTone.setOnSeekBarChangeListener(l);
        sSpeed.setOnSeekBarChangeListener(l);
        cLink.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                if (on) {      // passa a valer o tom que a velocidade atual produz
                    updating = true;
                    sTone.setProgress(clamp((int) Math.round(12 * Math.log(speed()) / Math.log(2)) + 12, 0, 24));
                    updating = false;
                }
                refresh();
            }
        });
        cEq.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { refresh(); }
        });

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        playBtn = button("▶  OUVIR COM OS AJUSTES", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { togglePlay(); } });
        row.addView(playBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -2, 0.55f);
        rp.setMargins(dp(8), 0, 0, 0);
        row.addView(button("RESTAURAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { reset(); } }), rp);
        box.addView(row);

        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(0, dp(8), 0, 0);
        foot.addView(button("CANCELAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }),
                new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(8), 0, 0, 0);
        foot.addView(button("APLICAR", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { apply(); } }), lp);
        box.addView(foot);

        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        dlg.setContentView(sv);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface x) { stop(); }
        });
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            dlg.getWindow().setLayout(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.92f), android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        refresh();
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private void reset() {
        updating = true;
        sVol.setProgress(100);
        sTone.setProgress(12);
        sSpeed.setProgress(50);
        cLink.setChecked(false);
        cEq.setChecked(false);
        updating = false;
        refresh();
    }

    private AudioEffects.Params params() {
        AudioEffects.Params q = new AudioEffects.Params();
        q.volume = volume();
        q.linked = cLink.isChecked();
        q.speed = speed();
        q.semitones = semis();
        q.equalize = cEq.isChecked() && othersRms > 0;
        q.targetRms = othersRms;
        return q;
    }

    private void refresh() {
        tVol.setText(String.format(Locale.US, "Volume: %d%%", sVol.getProgress()));
        tTone.setText(String.format(Locale.US, "Tom: %+d semitons", (int) semis()));
        tSpeed.setText(String.format(Locale.US, "Velocidade: %d%%", 50 + sSpeed.getProgress()));
        boolean linked = cLink.isChecked();
        sTone.setAlpha(1f);
        double dur = pcm.length / (double) AudioConvert.RATE;
        double nd = dur / speed();
        String s = String.format(Locale.US, "Duracao: %.2f s → %.2f s", dur, nd);
        if (cEq.isChecked() && othersRms > 0) {
            double own = AudioEffects.activeRms(pcm);
            if (own > 0) s += String.format(Locale.US, "\nMedia dos outros sons: %.0f  ·  este: %.0f  → ganho %d%%", othersRms, own, Math.round(100 * othersRms / own));
        }
        if (linked) s += "\nTom e velocidade andam juntos.";
        info.setText(s);
    }

    private void togglePlay() {
        if (mp != null) { stop(); return; }
        if (busy) return;
        busy = true;
        playBtn.setText("...");
        final AudioEffects.Params q = params();
        new Thread(new Runnable() {
            @Override public void run() {
                File f = null;
                try {
                    byte[] w = AudioConvert.encode(AudioEffects.process(pcm, q).pcm);
                    f = new File(a.getCacheDir(), "ajuste_previa.wav");
                    SpriteLib.writeAtomic(f, w);
                } catch (Exception e) { f = null; }
                final File ff = f;
                ui.post(new Runnable() {
                    @Override public void run() {
                        busy = false;
                        if (ff == null || dlg == null || !dlg.isShowing()) { playBtn.setText("▶  OUVIR COM OS AJUSTES"); return; }
                        try {
                            final android.media.MediaPlayer p = new android.media.MediaPlayer();
                            mp = p;
                            p.setDataSource(ff.getAbsolutePath());
                            p.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() { @Override public void onPrepared(android.media.MediaPlayer m) { if (mp == m) m.start(); } });
                            p.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() { @Override public void onCompletion(android.media.MediaPlayer m) { if (mp == m) stop(); } });
                            p.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() { @Override public boolean onError(android.media.MediaPlayer m, int w, int x) { if (mp == m) stop(); return true; } });
                            playBtn.setText("■  PARAR");
                            p.prepareAsync();
                        } catch (Exception e) { stop(); }
                    }
                });
            }
        }).start();
    }

    private void stop() {
        if (mp != null) { try { mp.stop(); } catch (Exception ignored) { } try { mp.release(); } catch (Exception ignored) { } }
        mp = null;
        if (playBtn != null) playBtn.setText("▶  OUVIR COM OS AJUSTES");
    }

    private void apply() {
        stop();
        final AudioEffects.Params q = params();
        final boolean noChange = Math.abs(q.volume - 1f) < 0.005f && !q.equalize && Math.abs(q.speed - 1f) < 0.005f && Math.abs(q.semitones) < 0.01f;
        if (noChange) { I18nUi.toast(a, "Nenhum ajuste para aplicar.", Toast.LENGTH_SHORT).show(); return; }
        final BusyDialog b = BusyDialog.show(a, "Aplicando ajustes");
        b.set("Processando o audio...", 0, 0);
        new Thread(new Runnable() {
            @Override public void run() {
                final AudioEffects.Result r = AudioEffects.process(pcm, q);
                b.dismiss();
                ui.post(new Runnable() {
                    @Override public void run() {
                        dlg.dismiss();
                        if (r.limited) I18nUi.toast(a, "Volume limitado para o som nao estourar.", Toast.LENGTH_LONG).show();
                        done.on(AudioConvert.encode(r.pcm));
                    }
                });
            }
        }).start();
    }
}
