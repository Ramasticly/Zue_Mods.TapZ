package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;

/** Lista de sons do personagem: escolher, ouvir, substituir, excluir (mutar) e adicionar (ate 20). */
final class SoundDialog {
    interface Choose { void on(int se); }

    private final Activity a;
    private final AttackView view;
    private final File dir;
    private final int currentSe;
    private final Choose choose;
    private final float d;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Dialog dlg;
    private LinearLayout list;
    private TextView count;
    private android.media.MediaPlayer mp;
    private String playingKey;
    private final Map<String, TextView> btns = new HashMap<String, TextView>();

    private SoundDialog(Activity a, AttackView view, File dir, int currentSe, Choose choose) {
        this.a = a;
        this.view = view;
        this.dir = dir;
        this.currentSe = currentSe;
        this.choose = choose;
        this.d = a.getResources().getDisplayMetrics().density;
    }

    static void show(Activity a, AttackView view, File dir, int currentSe, Choose choose) {
        new SoundDialog(a, view, dir, currentSe, choose).open();
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        box.setPadding(dp(12), dp(14), dp(12), dp(8));

        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(tv("Sons do personagem", 17, LayoutManager.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        count = tv("", 12, LayoutManager.DIM, false);
        head.addView(count);
        box.addView(head);

        FrameLayout stack = new FrameLayout(a);
        ScrollView sv = new ScrollView(a);
        list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(8), 0, dp(72));
        sv.addView(list);
        stack.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        TextView fab = tv("+", 28, 0xFFFFFFFF, true);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable fg = new GradientDrawable();
        fg.setShape(GradientDrawable.OVAL);
        fg.setColor(LayoutManager.ACCENT);
        fab.setBackground(fg);
        fab.setElevation(dp(6));
        fab.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { add(); } });
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM | Gravity.END);
        fp.setMargins(0, 0, dp(6), dp(6));
        stack.addView(fab, fp);
        int h = Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.62f);
        box.addView(stack, new LinearLayout.LayoutParams(-1, h));

        TextView close = tv("FECHAR", 14, LayoutManager.ACCENT, true);
        close.setPadding(dp(14), dp(10), dp(14), dp(6));
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } });
        LinearLayout foot = new LinearLayout(a);
        foot.setGravity(Gravity.END);
        foot.addView(close);
        box.addView(foot);

        dlg.setContentView(box);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface x) { stopPlay(); }
        });
        purge();
        refill();
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            dlg.getWindow().setLayout(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.94f), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    /** Sons vazios nao podem ficar em uso no DAC: retira os usos (uma vez por abertura e depois de cada mudanca). */
    private void purge() {
        int n = view.clearSoundUses(CharSounds.emptySounds(dir));
        if (n > 0) toast(n + " uso(s) de sons vazios retirado(s) das animacoes.");
        int t = CharSounds.trimTrailing(dir);              // vazios no fim: apagados de vez, liberam o espaco
        if (t > 0) {
            view.soundsChanged(null);
            toast(t + " som(ns) vazio(s) no fim da lista apagado(s).");
        }
    }

    // ---- previa: um som por vez; o botao vira "parar" enquanto toca; fechar o menu para

    private void stopPlay() {
        String k = playingKey;
        playingKey = null;
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
        if (k != null) icon(k, false);
    }

    private void icon(String key, boolean playing) {
        TextView b = btns.get(key);
        if (b != null) b.setText(playing ? "■" : "▶");
    }

    /** Toca (parando o anterior); tocar o que ja esta tocando para. */
    private void play(final String key, File f, boolean toggle) {
        boolean same = key.equals(playingKey);
        stopPlay();
        if (same && toggle) return;
        if (!f.isFile()) return;
        try {
            final android.media.MediaPlayer p = new android.media.MediaPlayer();
            mp = p;
            playingKey = key;
            icon(key, true);
            p.setDataSource(f.getAbsolutePath());
            p.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(android.media.MediaPlayer m) { if (mp == m) stopPlay(); }
            });
            p.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                @Override public boolean onError(android.media.MediaPlayer m, int w, int x) { if (mp == m) stopPlay(); return true; }
            });
            p.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(android.media.MediaPlayer m) { if (mp == m) m.start(); }
            });
            p.prepareAsync();
        } catch (Exception e) {
            stopPlay();
        }
    }

    private TextView playBtn(final String key, final File f) {
        TextView b = tv(key.equals(playingKey) ? "■" : "▶", 24, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bgp = new GradientDrawable();
        bgp.setShape(GradientDrawable.OVAL);
        bgp.setColor(LayoutManager.ACCENT);
        b.setBackground(bgp);
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { play(key, f, true); } });
        btns.put(key, b);
        return b;
    }

    private LinearLayout.LayoutParams playLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(52));
        lp.setMargins(0, 0, dp(12), 0);
        return lp;
    }

    private LinearLayout row(boolean cur) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(10), dp(8));
        GradientDrawable rg = new GradientDrawable();
        rg.setColor(cur ? 0xFF1E3A66 : LayoutManager.PANEL_HI);
        rg.setCornerRadius(dp(8));
        row.setBackground(rg);
        return row;
    }

    private void section(String title) {
        TextView h = tv(title, 12, LayoutManager.DIM, true);
        h.setPadding(dp(4), dp(10), dp(4), dp(6));
        list.addView(h);
    }

    private void refill() {
        list.removeAllViews();
        btns.clear();
        final File[] wavs = CharSounds.list(dir);
        count.setText(wavs.length + "/" + CharSounds.MAX);
        section("SONS DO PERSONAGEM");
        if (wavs.length == 0) {
            TextView none = tv("Este personagem ainda nao tem sons. Use o + para adicionar.", 13, LayoutManager.DIM, false);
            none.setPadding(dp(4), dp(4), dp(4), dp(8));
            list.addView(none);
        }
        for (int i = 0; i < wavs.length; i++) {
            final int idx = i;
            final File f = wavs[i];
            boolean muted = CharSounds.isEmpty(f);
            LinearLayout row = row(currentSe == 80 + i);
            row.addView(playBtn("c" + i, f), playLp());
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(tv("Som " + (80 + i) + (muted ? "  [vazio]" : ""), 14, muted ? LayoutManager.DIM : LayoutManager.TEXT, true));
            col.addView(tv(f.getName() + "  ·  " + String.format(Locale.US, "%.2f s", AudioConvert.seconds(f.length())), 11, LayoutManager.DIM, false));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            row.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { options(idx, f); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, dp(6));
            list.addView(row, lp);
        }
        // sons comuns do jogo (se_NN.ogg): o som N do sprite toca se_(N-1)
        SoundPlayer sp = view.soundPlayer();
        File[] commons = sp == null ? new File[0] : sp.commonFiles();
        if (commons.length > 0) section("SONS COMUNS DO JOGO (se_)");
        for (final File f : commons) {
            final int se = SoundPlayer.commonNumber(f) + 1;
            LinearLayout row = row(currentSe == se);
            row.addView(playBtn("s" + se, f), playLp());
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(tv("Som " + se, 14, LayoutManager.TEXT, true));
            col.addView(tv(f.getName() + "  ·  " + Math.max(1, f.length() / 1024) + " KB", 11, LayoutManager.DIM, false));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            row.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { commonOptions(se, f); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, dp(6));
            list.addView(row, lp);
        }
    }

    private void commonOptions(final int se, final File f) {
        String[] items = {"Usar este som", "Ouvir / parar"};
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Som " + se + " (" + f.getName() + ")");
        b.setItems(items, new android.content.DialogInterface.OnClickListener() {
            @Override public void onClick(android.content.DialogInterface x, int which) {
                if (which == 0) { dlg.dismiss(); choose.on(se); }
                else play("s" + se, f, true);
            }
        });
        android.app.AlertDialog ad = b.create();
        ad.show();
        style(ad);
    }

    private void options(final int idx, final File f) {
        String[] items = {"Usar este som", "Ouvir", "Cortar...", "Mais... (volume, tom, velocidade)", "Substituir...", "Excluir (mutar)"};
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Som " + (80 + idx));
        b.setItems(items, new android.content.DialogInterface.OnClickListener() {
            @Override public void onClick(android.content.DialogInterface x, int which) {
                if (which == 0) {
                    if (CharSounds.isEmpty(f)) { toast("Som vazio: substitua por um audio antes de usar."); return; }
                    dlg.dismiss(); choose.on(80 + idx);
                }
                else if (which == 1) play("c" + idx, f, true);
                else if (which == 2) trimExisting(f);
                else if (which == 3) adjust(f);
                else if (which == 4) replace(f);
                else mute(f);
            }
        });
        android.app.AlertDialog ad = b.create();
        ad.show();
        style(ad);
    }

    private void style(android.app.AlertDialog ad) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        ad.getWindow().setBackgroundDrawable(bg);
        int tid = a.getResources().getIdentifier("alertTitle", "id", "android");
        View t = tid == 0 ? null : ad.findViewById(tid);
        if (t instanceof TextView) ((TextView) t).setTextColor(LayoutManager.TEXT);
    }

    private void mute(final File f) {
        android.app.AlertDialog ad = new android.app.AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Excluir som?")
                .setMessage("O som vira silencio (vazio) e todos os usos dele nas animacoes sao retirados. O arquivo continua na pasta para os proximos sons nao mudarem de numero.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("EXCLUIR", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) {
                        try {
                            stopPlay();
                            CharSounds.mute(f);
                            view.soundsChanged(f);
                            purge();
                            refill();
                        } catch (IOException e) { toast("Erro: " + e.getMessage()); }
                    }
                }).create();
        ad.show();
        style(ad);
    }

    private void replace(final File f) {
        FilePicker.show(a, "Substituir o som " + f.getName(), false, FilePicker.AUDIO, new FilePicker.Listener() {
            @Override public void onPicked(List<File> files) { convert(files.get(0), f); }
        });
    }

    private void add() {
        if (CharSounds.list(dir).length >= CharSounds.MAX) { toast("Limite de " + CharSounds.MAX + " sons por personagem."); return; }
        FilePicker.show(a, "Adicionar som", false, FilePicker.AUDIO, new FilePicker.Listener() {
            @Override public void onPicked(List<File> files) { convert(files.get(0), null); }
        });
    }

    /** Volume, tom e velocidade do som (e igualar o volume pela media dos outros). */
    private void adjust(final File f) {
        if (CharSounds.isEmpty(f)) { toast("Som vazio: nada para ajustar."); return; }
        stopPlay();
        final byte[] wav;
        try { wav = GameData.readAll(f); } catch (IOException e) { toast("Erro: " + e.getMessage()); return; }
        SoundAdjust.show(a, wav, SoundAdjust.averageOthers(dir, f), new SoundAdjust.Done() {
            @Override public void on(byte[] out) { commit(out, f); }
        });
    }

    /** Corta um som que ja esta na lista. */
    private void trimExisting(final File f) {
        if (CharSounds.isEmpty(f)) { toast("Som vazio: nada para cortar."); return; }
        stopPlay();
        final byte[] wav;
        try { wav = GameData.readAll(f); } catch (IOException e) { toast("Erro: " + e.getMessage()); return; }
        TrimDialog.show(a, wav, 0, Integer.MAX_VALUE, new TrimDialog.Done() {
            @Override public void on(byte[] cut) { commit(cut, f); }
        });
    }

    /** Converte em segundo plano (decodificar MP3/OGG demora); target == null adiciona um novo. */
    private void convert(final File src, final File target) {
        stopPlay();
        toast("Convertendo para WAV 22050 Hz mono...");
        new Thread(new Runnable() {
            @Override public void run() {
                byte[] w = null;
                String err = null;
                try { w = AudioConvert.toGameWav(src); }
                catch (Exception e) { err = e.getMessage() == null ? e.toString() : e.getMessage(); }
                final byte[] fw = w;
                final String fe = err;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (fe != null) { toast("Nao deu: " + fe); return; }
                        afterConvert(fw, target);
                    }
                });
            }
        }).start();
    }

    private static final double LONG_SECONDS = 20.0;

    /** Mais de 20 s: oferece cortar (primeiros 20 s, escolher o trecho ou manter inteiro). */
    private void afterConvert(final byte[] wav, final File target) {
        final double secs = AudioConvert.seconds(wav.length);
        if (secs <= LONG_SECONDS) { commit(wav, target); return; }
        final int max = (int) (LONG_SECONDS * AudioConvert.RATE);
        android.app.AlertDialog ad = new android.app.AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Audio longo")
                .setMessage(String.format(Locale.US, "Este audio tem %.1f s (mais de 20 s). Quer cortar?", secs))
                .setPositiveButton("CORTAR EM 20 S", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { commit(AudioConvert.slice(wav, 0, max), target); }
                })
                .setNeutralButton("ESCOLHER TRECHO", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) {
                        TrimDialog.show(a, wav, 0, max, new TrimDialog.Done() { @Override public void on(byte[] cut) { commit(cut, target); } });
                    }
                })
                .setNegativeButton("MANTER INTEIRO", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { commit(wav, target); }
                }).create();
        ad.show();
        style(ad);
    }

    /** Grava o WAV pronto (novo som se target == null) e atualiza tudo. */
    private void commit(byte[] wav, File target) {
        try {
            File out = target == null ? CharSounds.addBytes(dir, wav) : target;
            if (target != null) CharSounds.replaceBytes(target, wav);
            view.soundsChanged(out);
            purge();
            refill();
            toast(target == null ? "Som adicionado." : "Som atualizado.");
        } catch (IOException e) {
            toast("Nao deu: " + e.getMessage());
        }
    }

    private void toast(String s) { Toast.makeText(a, s, Toast.LENGTH_SHORT).show(); }
}
