package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Ids do campo SE do frame (agora um byte SEM sinal, 0 a 255) e os arquivos de som global (assets/se_NN.ogg, se_NNN.ogg). Java puro.
 *
 * <pre>
 *  id 0          nenhum som
 *  id 1..79      global se_(id-1)  -> se_00 .. se_78 (os sons do jogo)
 *  id 80..99     audio do personagem (NNN.wav, ate 20 por personagem)
 *  id 100..255   global se_(id-1)  -> se_99 .. se_254
 * </pre>
 * Os arquivos se_79 .. se_99 existem so como silencio (o jogo carrega os se_ em sequencia, sem buracos): o primeiro som global novo depois do
 * se_78 e o se_100 (id 101).
 */
final class SoundIds {
    private SoundIds() { }

    static final int CHAR_FIRST = 80, CHAR_LAST = 99, MAX_ID = 255, LAST_ORIGINAL = 78, FIRST_NEW = 100, MAX_COMMON = MAX_ID - 1;

    static boolean isCharId(int id) { return id >= CHAR_FIRST && id <= CHAR_LAST; }

    /** O id toca um som global (se_*)? */
    static boolean isCommonId(int id) { return (id >= 1 && id < CHAR_FIRST) || (id > CHAR_LAST && id <= MAX_ID); }

    /** Numero do arquivo se_N que o id toca, ou -1 (sem som, audio de personagem, fora de 0..255). */
    static int commonOf(int id) { return isCommonId(id) ? id - 1 : -1; }

    /** Id do frame que toca o arquivo se_N. */
    static int idOfCommon(int n) { return n + 1; }

    /** Arquivo de som global que alguem pode escolher num frame (os de 79 a 98 so existem como silencio de preenchimento). */
    static boolean selectable(int n) { return (n >= 0 && n <= LAST_ORIGINAL) || (n >= CHAR_LAST && n <= MAX_COMMON); }

    static String fileName(int n) { return String.format(Locale.US, n < 100 ? "se_%02d.ogg" : "se_%03d.ogg", n); }

    static boolean isFileName(String name) { return name.matches("se_\\d{2,3}\\.ogg"); }

    /** 7 para "se_07.ogg", 100 para "se_100.ogg"; -1 se nao for nome de som global. */
    static int numberOf(String name) {
        if (!isFileName(name)) return -1;
        return Integer.parseInt(name.substring(3, name.indexOf('.')));
    }

    /**
     * Numero do proximo som global novo, dado o maior se_N que existe (-1 se nao ha nenhum): o seguinte, mas depois do se_78 pula os
     * de preenchimento (79..99) e comeca em 100. Acima de se_254 nao ha mais ids: devolve -1.
     */
    static int nextNew(int maxExisting) {
        int n = maxExisting + 1;
        if (n > LAST_ORIGINAL && n < FIRST_NEW) n = FIRST_NEW;
        return n > MAX_COMMON ? -1 : n;
    }

    /** Arquivos de preenchimento (silencio) que faltam para o se_{newN} ficar sem buracos antes dele. */
    static List<Integer> placeholders(Set<Integer> existing, int newN) {
        List<Integer> out = new ArrayList<Integer>();
        for (int n = 0; n < newN; n++) if (!existing.contains(Integer.valueOf(n))) out.add(Integer.valueOf(n));
        return out;
    }

    /**
     * Id com que um som NOVO nasce num frame: o 1o audio do personagem que nao esta vazio (80 = a 1a voz), senao o som comum 1 se existir, senao -1 (nada para tocar).
     * Nunca 0: no jogo o id 0 e "sem som" (SE &lt; 80 toca se_(id-1), e -1 nao toca), entao um frame com a flag de som ligada e id 0 era um "Som 0" que nao toca nada.
     */
    static int defaultId(int wavCount, Set<Integer> emptyIds, boolean hasCommon) {
        for (int i = 0; i < Math.min(wavCount, CHAR_LAST - CHAR_FIRST + 1); i++) {
            Integer id = Integer.valueOf(CHAR_FIRST + i);
            if (emptyIds == null || !emptyIds.contains(id)) return id.intValue();
        }
        return hasCommon ? 1 : -1;
    }

    /** Ids validos num frame, em ordem: 0, globais de 1 a 79 que existem, audios do personagem (80..) e globais novos (100..) que existem. */
    static List<Integer> frameIds(int maxCommonId, int wavCount) {
        List<Integer> l = new ArrayList<Integer>();
        for (int i = 0; i <= Math.min(CHAR_FIRST - 1, Math.max(0, maxCommonId)); i++) l.add(Integer.valueOf(i));
        for (int i = 0; i < Math.min(wavCount, CHAR_LAST - CHAR_FIRST + 1); i++) l.add(Integer.valueOf(CHAR_FIRST + i));
        for (int i = CHAR_LAST + 1; i <= Math.min(MAX_ID, maxCommonId); i++) l.add(Integer.valueOf(i));
        return l;
    }
}
