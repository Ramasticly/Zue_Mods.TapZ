package com.zue.attackeditor;

import android.media.AudioManager;
import android.media.SoundPool;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Toca se_NN.ogg (assets/) e WAVs de personagem via SoundPool, carregando sob demanda. */
public final class SoundPlayer {
    private final SoundPool pool;
    private final Map<String, Integer> ids = new HashMap<String, Integer>();
    private final Set<Integer> ready = new HashSet<Integer>();
    private final Set<Integer> pending = new HashSet<Integer>();
    private final Map<Integer, Float> volume = new HashMap<Integer, Float>();
    private final File root;
    public boolean enabled = true;

    @SuppressWarnings("deprecation")
    public SoundPlayer(File assetsRoot) {
        root = assetsRoot;
        pool = new SoundPool(24, AudioManager.STREAM_MUSIC, 0);   // 8 cortava sons sobrepostos (o mais antigo e roubado)
        pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override public void onLoadComplete(SoundPool p, int id, int status) {
                synchronized (SoundPlayer.this) {
                    if (status != 0) return;
                    ready.add(id);
                    if (pending.remove(id)) play(id);
                }
            }
        });
    }

    /** se_NN.ogg existentes na pasta de assets, em ordem. */
    public File[] commonFiles() {
        File[] fs = root.listFiles();
        if (fs == null) return new File[0];
        java.util.ArrayList<File> out = new java.util.ArrayList<File>();
        for (File f : fs) if (f.isFile() && f.getName().matches("se_\\d+\\.ogg")) out.add(f);
        File[] a = out.toArray(new File[0]);
        java.util.Arrays.sort(a, new java.util.Comparator<File>() {
            @Override public int compare(File x, File y) { return commonNumber(x) - commonNumber(y); }
        });
        return a;
    }

    /** 7 para se_07.ogg. */
    public static int commonNumber(File f) {
        String n = f.getName();
        try { return Integer.parseInt(n.substring(3, n.indexOf('.'))); } catch (Exception e) { return 0; }
    }

    public void playCommon(int n) {
        String name = String.format(java.util.Locale.US, "se_%02d.ogg", n);
        play(new File(root, name), 0.6f);
    }

    /** Audio do personagem: o id-esimo WAV na ordem dos nomes (a mesma ordem em que o jogo carrega). */
    public void playChar(File dir, int id) {
        File[] all = CharAssets.listWavs(dir);
        if (id >= 0 && id < all.length) play(all[id], 1f);
    }

    /** SoundPool corta amostras grandes (limite ~1 MB decodificado): arquivos maiores tocam via MediaPlayer. */
    private static final long BIG = 500L * 1024;
    private final java.util.List<android.media.MediaPlayer> live = new java.util.ArrayList<android.media.MediaPlayer>();

    private void playBig(File f, final float vol) { playBig(f, vol, 0, 0); }

    private volatile boolean paused;

    private void playBig(File f, final float vol, final int offsetMs, final int limitMs) {
        synchronized (live) {
            while (live.size() >= 8) {                       // limite de sons longos simultaneos
                android.media.MediaPlayer old = live.remove(0);
                try { old.release(); } catch (Exception e) { /* ignora */ }
            }
        }
        try {
            final android.media.MediaPlayer mp = new android.media.MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.setVolume(vol, vol);
            mp.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(android.media.MediaPlayer m) {
                    try {
                        if (offsetMs > 0) m.seekTo(offsetMs);
                        if (!paused) m.start();
                        if (limitMs > 0 && !paused) {                       // trecho curto (arrastar a timeline pausada): para sozinho
                            final android.media.MediaPlayer mm = m;
                            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override public void run() {
                                    synchronized (live) { live.remove(mm); }
                                    try { mm.stop(); } catch (Exception e) { /* ignora */ }
                                    try { mm.release(); } catch (Exception e) { /* ignora */ }
                                }
                            }, limitMs);
                        }
                    } catch (Exception e) { /* ignora */ }
                }
            });
            mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(android.media.MediaPlayer m) {
                    synchronized (live) { live.remove(m); }
                    try { m.release(); } catch (Exception e) { /* ignora */ }
                }
            });
            mp.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                @Override public boolean onError(android.media.MediaPlayer m, int w, int x) {
                    synchronized (live) { live.remove(m); }
                    try { m.release(); } catch (Exception e) { /* ignora */ }
                    return true;
                }
            });
            synchronized (live) { live.add(mp); }
            mp.prepareAsync();
        } catch (Exception e) { /* arquivo ilegivel: sem som */ }
    }

    private synchronized void play(File f, float vol) {
        if (!enabled || !f.isFile()) return;
        if (f.length() > BIG) { playBig(f, vol); return; }
        String key = f.getAbsolutePath();
        Integer id = ids.get(key);
        if (id == null) {
            id = Integer.valueOf(pool.load(key, 1));
            ids.put(key, id);
            volume.put(id, Float.valueOf(vol));
            pending.add(id);
            return;
        }
        if (ready.contains(id)) play(id.intValue());
    }

    private final java.util.List<Integer> streams = new java.util.ArrayList<Integer>();

    private void play(int id) {
        Float v = volume.get(Integer.valueOf(id));
        float vol = v == null ? 1f : v.floatValue();
        int st = pool.play(id, vol, vol, 1, 0, 1f);
        if (st != 0) {
            streams.add(Integer.valueOf(st));
            if (streams.size() > 32) streams.remove(0);
        }
    }

    /** Pausa tudo que esta tocando; resumeAll() continua de onde parou. */
    public synchronized void pauseAll() {
        paused = true;
        for (Integer s : streams) { try { pool.pause(s.intValue()); } catch (Exception ignored) { } }
        synchronized (live) {
            for (android.media.MediaPlayer m : live) { try { if (m.isPlaying()) m.pause(); } catch (Exception ignored) { } }
        }
    }

    public synchronized void resumeAll() {
        if (!paused) return;
        paused = false;
        for (Integer s : streams) { try { pool.resume(s.intValue()); } catch (Exception ignored) { } }
        synchronized (live) {
            for (android.media.MediaPlayer m : live) { try { m.start(); } catch (Exception ignored) { } }
        }
    }

    private final Map<String, Integer> durations = new HashMap<String, Integer>();

    /** Duracao do arquivo em ms (0 se nao der para ler). */
    public synchronized int durationMs(File f) {
        String k = f.getAbsolutePath();
        Integer d = durations.get(k);
        if (d != null) return d.intValue();
        int ms = 0;
        android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
        try {
            r.setDataSource(k);
            String v = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (v != null) ms = Integer.parseInt(v);
        } catch (Exception e) { /* sem duracao */ }
        try { r.release(); } catch (Exception e) { /* ignora */ }
        durations.put(k, Integer.valueOf(ms));
        return ms;
    }

    /** Toca um som do personagem ja em andamento: comecou ha {@code elapsedMs}. Nada se ja terminou. */
    public void playCharFrom(File dir, int id, int elapsedMs, int limitMs) {
        File[] all = CharAssets.listWavs(dir);
        if (id >= 0 && id < all.length) playFrom(all[id], 1f, elapsedMs, limitMs);
    }

    public void playCommonFrom(int n, int elapsedMs, int limitMs) {
        playFrom(new File(root, String.format(java.util.Locale.US, "se_%02d.ogg", n)), 0.6f, elapsedMs, limitMs);
    }

    private void playFrom(File f, float vol, int elapsedMs, int limitMs) {
        if (!enabled || !f.isFile()) return;
        int dur = durationMs(f);
        if (dur > 0 && elapsedMs >= dur) return;
        playBig(f, vol, elapsedMs, limitMs);
    }

    /** Para tudo que esta tocando (SoundPool e sons longos). */
    public synchronized void stopAll() {
        paused = false;
        for (Integer s : streams) { try { pool.stop(s.intValue()); } catch (Exception ignored) { } }
        streams.clear();
        pending.clear();
        synchronized (live) {
            for (android.media.MediaPlayer m : live) { try { m.release(); } catch (Exception ignored) { } }
            live.clear();
        }
    }

    /** O arquivo mudou no disco (trocado/mutado): esquece o que o SoundPool carregou dele. */
    public synchronized void invalidate(File f) {
        Integer id = ids.remove(f.getAbsolutePath());
        if (id == null) return;
        ready.remove(id);
        pending.remove(id);
        volume.remove(id);
        try { pool.unload(id.intValue()); } catch (Exception ignored) { }
    }

    public void release() {
        pool.release();
        synchronized (live) {
            for (android.media.MediaPlayer m : live) { try { m.release(); } catch (Exception e) { /* ignora */ } }
            live.clear();
        }
    }
}
