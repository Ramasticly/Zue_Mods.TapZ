package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * SPEEDLINE (Java puro, testado sem Android): a trajetoria de um movimento da ANO como pontos e linhas.
 * Uma {@link Chain} e uma sequencia contigua de frames que se movem (um trecho de velocidade, ou varios um logo depois do outro).
 * Os pontos ficam no INICIO de cada frame da cadeia (onde o personagem esta quando o frame comeca) mais um no fim do ultimo frame;
 * um frame cuja altura muda de sentido ganha um ponto extra (o apice). Posicoes em px, relativas ao inicio da cadeia, "como se
 * olhasse para a direita e sem espelho vertical": quem desenha multiplica pelo lado do personagem.
 * A conta de cada tick e a do jogo: anda com a velocidade atual e depois soma a aceleracao.
 */
final class SpeedLine {
    private SpeedLine() { }

    static final int START = 0, FRAME = 1, APEX = 2, END = 3;

    static final class Pt {
        final int frame, kind, tick;
        final double x, y;
        Pt(int frame, int kind, int tick, double x, double y) { this.frame = frame; this.kind = kind; this.tick = tick; this.x = x; this.y = y; }
    }

    static final class Chain {
        final int head, last;                // frames da cadeia (o ultimo e o que termina no ponto END)
        final List<Pt> pts = new ArrayList<Pt>();
        Chain(int head, int last) { this.head = head; this.last = last; }

        /** Quantos frames a cadeia tem. */
        int frames() { return last - head + 1; }

        /** Pontos que sao "do frame" (START/FRAME/END), em ordem: o indice k e o k-esimo inicio de frame (k = frames() e o fim). */
        Pt vertex(int k) {
            int n = -1;
            for (Pt p : pts) if (p.kind != APEX && ++n == k) return p;
            return null;
        }

        /** Posicao do personagem no frame {@code f} depois de {@code elapsed} ticks, relativa ao inicio da cadeia. */
        double[] posAt(Ano.Mpt[] m, int f, int elapsed) {
            if (f < head) return new double[] {0, 0};
            if (f > last) f = last + 1;
            Pt v = vertex(f - head);
            if (v == null) return new double[] {0, 0};
            if (f > last) return new double[] {v.x, v.y};
            double[] d = offsetAt(m, f, elapsed);
            return new double[] {v.x + d[0], v.y + d[1]};
        }
    }

    /**
     * A seta do Frame atual: o caminho do inicio do frame ate o fim dele, tick a tick (curva com aceleracao), e se o movimento PARA depois dele.
     * Posicoes em px relativas ao inicio da cadeia. {@code path[e]} = posicao depois de e ticks (e = 0 .. ticks do frame).
     */
    static final class Arrow {
        final int frame;
        final double[][] path;
        final boolean stops;
        Arrow(int frame, double[][] path, boolean stops) { this.frame = frame; this.path = path; this.stops = stops; }
        double[] from() { return path[0]; }
        double[] to() { return path[path.length - 1]; }
    }

    /** Seta do frame {@code f} da cadeia; nulo se o frame nao e da cadeia. */
    static Arrow frameArrow(Ano.Mpt[] m, Chain c, int f) {
        if (c == null || m == null || f < c.head || f > c.last || f >= m.length) return null;
        Pt v = c.vertex(f - c.head);
        if (v == null) return null;
        int t = Math.max(0, FrameTools.ticks(m[f]));
        double[][] path = new double[t + 1][];
        for (int e = 0; e <= t; e++) {
            double[] d = offsetAt(m, f, e);
            path[e] = new double[] {v.x + d[0], v.y + d[1]};
        }
        return new Arrow(f, path, stopsAfter(m, c, f));
    }

    /** O movimento para depois do frame {@code f}? (ultimo frame da cadeia, ou o seguinte comeca com speed 0 nos dois eixos) */
    static boolean stopsAfter(Ano.Mpt[] m, Chain c, int f) {
        if (f >= c.last) return true;
        double[] v = FrameTools.startSpeed(m, f + 1);
        return v[0] == 0 && v[1] == 0;
    }

    /** Texto do ponto: o numero do Frame (base 1, como no resto do app) ou, no ponto de tick (apice), "t" + o tick dentro do Frame. */
    static String label(Pt p) { return p.kind == APEX ? "t" + p.tick : String.valueOf(p.frame + 1); }

    /** Cadeias de movimento da ANO (frames com velocidade propria ou aceleracao e os que mantem a velocidade, um colado no outro). */
    static List<Chain> chains(Ano.Mpt[] m) {
        List<Chain> out = new ArrayList<Chain>();
        if (m == null) return out;
        int f = 0;
        while (f < m.length) {
            if (!FrameOps.isMoveHead(m[f])) { f++; continue; }
            int last = FrameOps.moveRunEnd(m, f);
            while (last + 1 < m.length && FrameOps.isMoveHead(m[last + 1])) last = FrameOps.moveRunEnd(m, last + 1);   // trechos colados formam uma linha so
            out.add(build(m, f, last));
            f = last + 1;
        }
        return out;
    }

    /** A cadeia que contem o frame (ou nulo). O frame logo depois do fim tambem conta (e onde fica o ponto final). */
    static Chain chainAt(List<Chain> chains, int frame) {
        for (Chain c : chains) if (frame >= c.head && frame <= c.last + 1) return c;
        return null;
    }

    private static Chain build(Ano.Mpt[] m, int head, int last) {
        Chain c = new Chain(head, last);
        double x = 0, y = 0;
        for (int f = head; f <= last; f++) {
            c.pts.add(new Pt(f, f == head ? START : FRAME, 0, x, y));
            double[] v = FrameTools.startSpeed(m, f);
            double ax = accelOf(m[f], 0), ay = accelOf(m[f], 1);
            int t = FrameTools.ticks(m[f]);
            boolean apex = false;
            for (int k = 0; k < t; k++) {
                x += v[0];
                y += v[1];
                double nextY = v[1] + ay;
                if (!apex && k + 1 < t && ((v[1] < 0 && nextY >= 0) || (v[1] > 0 && nextY <= 0))) {      // a altura muda de sentido dentro do frame (passando ou nao por 0)
                    c.pts.add(new Pt(f, APEX, k + 1, x, y));
                    apex = true;
                }
                v[0] += ax;
                v[1] = nextY;
            }
        }
        c.pts.add(new Pt(last + 1, END, 0, x, y));
        return c;
    }

    private static double accelOf(Ano.Mpt m, int axis) {
        int bit = axis == 0 ? 4 : 8;
        if ((m.flags & 4) == 0 || (m.moveMask & bit) == 0) return 0;
        return (axis == 0 ? m.accelX : m.accelY) / FrameTools.ONE;
    }

    /** Deslocamento {dx, dy} dentro do frame {@code f} depois de {@code elapsed} ticks (0..ticks do frame). */
    static double[] offsetAt(Ano.Mpt[] m, int f, int elapsed) {
        double[] v = FrameTools.startSpeed(m, f);
        double ax = accelOf(m[f], 0), ay = accelOf(m[f], 1);
        int t = Math.min(Math.max(0, elapsed), FrameTools.ticks(m[f]));
        double x = 0, y = 0;
        for (int k = 0; k < t; k++) { x += v[0]; y += v[1]; v[0] += ax; v[1] += ay; }
        return new double[] {x, y};
    }

    /** Velocidade (px/tick) em cada tick da cadeia: {vx[], vy[]} (um valor por tick, na ordem dos frames). */
    static double[][] velocities(Ano.Mpt[] m, Chain c) {
        int total = 0;
        for (int f = c.head; f <= c.last; f++) total += FrameTools.ticks(m[f]);
        double[] vx = new double[total], vy = new double[total];
        int i = 0;
        for (int f = c.head; f <= c.last; f++) {
            double[] v = FrameTools.startSpeed(m, f);
            double ax = accelOf(m[f], 0), ay = accelOf(m[f], 1);
            for (int k = 0; k < FrameTools.ticks(m[f]); k++) { vx[i] = v[0]; vy[i] = v[1]; i++; v[0] += ax; v[1] += ay; }
        }
        return new double[][] {vx, vy};
    }

    // ---- edicao (so mexe em speed/accel, nunca no TIME) ----

    /**
     * Arrasta o ponto {@code k} (1 .. frames(): o inicio do frame seguinte, ou o fim) para (tx, ty) relativo ao inicio da cadeia: muda a
     * speed propria do frame que termina nesse ponto, nos dois eixos, para o personagem chegar la no mesmo tempo (a aceleracao do frame vale).
     * O tempo do frame nunca muda. Frame sem TIME (nao anda) ou k fora do intervalo: devolve {@code m} sem mudar.
     */
    static Ano.Mpt[] dragTo(Ano.Mpt[] m, Chain c, int k, double tx, double ty) {
        if (k < 1 || k > c.frames()) return m;
        int f = c.head + k - 1;
        int t = FrameTools.ticks(m[f]);
        if (t <= 0) return m;
        Pt from = c.vertex(k - 1);
        double dx = tx - from.x, dy = ty - from.y;
        double ax = accelOf(m[f], 0), ay = accelOf(m[f], 1);
        double corr = t * (t - 1) / 2.0;
        double vx = (dx - ax * corr) / t, vy = (dy - ay * corr) / t;
        Ano.Mpt n = FrameTools.setSpeed(FrameTools.setSpeed(m[f], 0, vx, true), 1, vy, true);
        Ano.Mpt[] out = m.clone();
        out[f] = n;
        return out;
    }

    /** O ponto k tira a speed da cadeia toda (primeiro ponto, ou cadeia de um frame so)? Nesse caso o app pede confirmacao. */
    static boolean removesAll(Chain c, int k) { return k <= 0 || c.frames() == 1; }

    /** Tira a speed e a aceleracao de todos os frames da cadeia (como REMOVER SPEED no trecho inteiro). */
    static Ano.Mpt[] removeChainSpeed(Ano.Mpt[] m, Chain c) {
        Ano.Mpt[] out = m.clone();
        for (int f = c.head; f <= c.last; f++) {
            Ano.Mpt n = m[f].copy();
            FrameOps.clear(FrameOps.MOV, n);
            if (FrameTools.keeps(m, f)) { n.wActFlag &= ~64; if (n.wActFlag == 0) n.flags &= ~2; n.normalize(); }
            out[f] = n;
        }
        return out;
    }

    /**
     * "Remover este ponto": o ponto 0 (ou a cadeia de um frame) tira a speed toda ({@link #removesAll}); um ponto do meio faz o frame dele
     * perder a speed e a aceleracao proprias e continuar com a velocidade do anterior (bit 64), passando-a adiante; o ponto final
     * encurta a cadeia em um frame.
     */
    static Ano.Mpt[] removePoint(Ano.Mpt[] m, Chain c, int k) {
        if (k < 0 || k > c.frames()) return m;
        if (removesAll(c, k)) return removeChainSpeed(m, c);
        if (k == c.frames()) {                                   // ponto final: o ultimo frame deixa de andar
            int lastHead = FrameOps.moveHeadOf(m, c.last);
            if (lastHead < 0) return m;
            if (lastHead == c.last) return removeChainSpeed(m, new Chain(c.last, c.last));
            return FrameOps.setMoveRun(m, lastHead, c.last - 1);
        }
        int f = c.head + k;
        Ano.Mpt n = m[f].copy();
        FrameOps.clear(FrameOps.MOV, n);
        n.flags |= 2;
        n.wActFlag |= 64;
        n.normalize();
        Ano.Mpt[] out = m.clone();
        out[f] = n;
        return out;
    }

    /** "Zerar Speed" no ponto k (< frames()): o frame fica com speed propria 0 nos dois eixos, sem aceleracao e sem manter. */
    static Ano.Mpt[] zeroSpeed(Ano.Mpt[] m, Chain c, int k) {
        if (k < 0 || k >= c.frames()) return m;
        int f = c.head + k;
        Ano.Mpt n = m[f].copy();
        FrameOps.clear(FrameOps.MOV, n);
        n.wActFlag &= ~64;
        if (n.wActFlag == 0) n.flags &= ~2;
        n.normalize();
        n = FrameTools.setSpeed(FrameTools.setSpeed(n, 0, 0, true), 1, 0, true);
        Ano.Mpt[] out = m.clone();
        out[f] = n;
        return out;
    }
}
