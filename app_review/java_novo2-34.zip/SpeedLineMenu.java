package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

/** Menu do ponto da SPEEDLINE (remover, zerar speed, aceleracao com previa e presets). */
final class SpeedLineMenu {
    private SpeedLineMenu() { }

    private static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    private static TextView item(Context c, String label, int color, View.OnClickListener l) {
        TextView t = new I18nTextView(c);
        t.setText(label);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setPadding(dp(c, 12), dp(c, 11), dp(c, 12), dp(c, 11));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    /** Pop-up do Frame {@code head + k} (k = posicao dele na cadeia que comeca em {@code head}); (sx, sy) = onde o dedo tocou na tela. */
    static void show(final Activity a, final AttackView v, final int head, final int k, int sx, int sy) {
        final SpeedLine.Chain chain = v.speedLineChain(head);
        if (chain == null || k < 0 || k >= chain.frames()) return;
        final PopupWindow[] pw = new PopupWindow[1];
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(a, 6), dp(a, 6), dp(a, 6), dp(a, 6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1B2029);
        bg.setCornerRadius(dp(a, 12));
        bg.setStroke(1, 0xFF3A4150);
        col.setBackground(bg);
        TextView hd = new I18nTextView(a);
        hd.setText("Frame " + (chain.head + k + 1) + "  ·  movimento de " + chain.frames() + (chain.frames() == 1 ? " frame" : " frames"));
        hd.setTextColor(LayoutManager.DIM);
        hd.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        hd.setPadding(dp(a, 12), dp(a, 4), dp(a, 12), dp(a, 4));
        col.addView(hd);
        col.addView(item(a, "Remover speed", 0xFFFF6B6B, new View.OnClickListener() { @Override public void onClick(View x) { pw[0].dismiss(); removePoint(a, v, head, k); } }));
        col.addView(item(a, "Zerar Speed", 0xFFFFB454, new View.OnClickListener() { @Override public void onClick(View x) {
            pw[0].dismiss();
            SpeedLine.Chain c = v.speedLineChain(head);
            if (c != null) v.replaceMpts(SpeedLine.zeroSpeed(v.currentAno().mpts, c, k), "speedline");
        } }));
        col.addView(item(a, "Aceleracao...", 0xFF3DDC84, new View.OnClickListener() { @Override public void onClick(View x) { pw[0].dismiss(); AccelDialog.show(a, v, head, k); } }));
        TextView ph = new I18nTextView(a);
        ph.setText("Presets (mantem o deslocamento total)");
        ph.setTextColor(LayoutManager.DIM);
        ph.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        ph.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 2));
        col.addView(ph);
        for (int i = 0; i < AccelPresets.NAMES.length; i++) {
            final int preset = i;
            col.addView(item(a, AccelPresets.NAMES[i], LayoutManager.TEXT, new View.OnClickListener() { @Override public void onClick(View x) {
                pw[0].dismiss();
                SpeedLine.Chain c = v.speedLineChain(head);
                if (c != null) v.replaceMpts(AccelPresets.apply(v.currentAno().mpts, c, preset, 100), "speedline");
            } }));
        }
        int sw = a.getResources().getDisplayMetrics().widthPixels, sh = a.getResources().getDisplayMetrics().heightPixels;
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(col);
        int w = dp(a, 250), hgt = Math.min(Math.round(sh * 0.7f), dp(a, 470));
        pw[0] = new PopupWindow(sv, w, hgt, true);
        pw[0].setOutsideTouchable(true);
        pw[0].setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        pw[0].showAtLocation(v, Gravity.NO_GRAVITY, Math.max(dp(a, 8), Math.min(sw - w - dp(a, 8), sx - w / 2)), Math.max(dp(a, 8), Math.min(sh - hgt - dp(a, 8), sy + dp(a, 18))));
    }

    private static void removePoint(final Activity a, final AttackView v, final int head, final int k) {
        final SpeedLine.Chain c = v.speedLineChain(head);
        if (c == null) return;
        if (!SpeedLine.removesAll(c, k)) { v.replaceMpts(SpeedLine.removePoint(v.currentAno().mpts, c, k), "speedline"); return; }
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Remover a speed?")
                .setMessage("Este ponto leva a speed do movimento inteiro (" + c.frames() + " frame(s)): remover tira a speed e a aceleracao do trecho. Os tempos dos frames nao mudam.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("REMOVER", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        SpeedLine.Chain cc = v.speedLineChain(head);
                        if (cc != null) v.replaceMpts(SpeedLine.removeChainSpeed(v.currentAno().mpts, cc), "speedline");
                    }
                }).show();
    }

    /** Previa da aceleracao: velocidade por tick de X (vermelho) e Y (azul), com os limites dos frames. */
    static final class AccelPreviewView extends View {
        private double[][] vel = new double[2][0];
        private int[] bounds = new int[0];
        private int mark = -1;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        AccelPreviewView(Context c) { super(c); }

        void set(double[][] v, int[] frameStarts, int highlightFrame) {
            vel = v;
            bounds = frameStarts;
            mark = highlightFrame;
            invalidate();
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF12151B);
            cv.drawRoundRect(0, 0, w, h, 10 * d, 10 * d, p);
            int n = vel[0].length;
            if (n == 0) return;
            double max = 1;
            for (int a = 0; a < 2; a++) for (double x : vel[a]) max = Math.max(max, Math.abs(x));
            float pad = 8 * d, gw = w - 2 * pad, gh = h - 2 * pad, mid = pad + gh / 2;
            p.setStrokeWidth(1f);
            p.setColor(0xFF3A4150);
            cv.drawLine(pad, mid, w - pad, mid, p);
            for (int i = 0; i < bounds.length; i++) {
                float x = pad + gw * bounds[i] / (float) n;
                p.setColor(i == mark ? 0xFF6AA1FF : 0xFF2A2F3A);
                cv.drawLine(x, pad, x, h - pad, p);
            }
            int[] colors = {0xFFFF6B6B, 0xFF5AA9FF};
            p.setStrokeWidth(2f * d);
            for (int a = 0; a < 2; a++) {
                p.setColor(colors[a]);
                for (int i = 0; i + 1 < n; i++) {
                    float x0 = pad + gw * (i + 0.5f) / n, x1 = pad + gw * (i + 1.5f) / n;
                    float y0 = (float) (mid - vel[a][i] / max * gh / 2), y1 = (float) (mid - vel[a][i + 1] / max * gh / 2);
                    cv.drawLine(x0, y0, x1, y1, p);
                }
                if (n == 1) { float y = (float) (mid - vel[a][0] / max * gh / 2); cv.drawLine(pad, y, w - pad, y, p); }
            }
            p.setStrokeWidth(1f);
            p.setTextSize(10 * d);
            p.setColor(0xFFFF6B6B);
            I18nUi.drawText(cv, "x", pad + 2 * d, pad + 10 * d, p);
            p.setColor(0xFF5AA9FF);
            I18nUi.drawText(cv, "y", pad + 14 * d, pad + 10 * d, p);
        }
    }

    /** Dialogo de aceleracao: previa, accel x/y por frame, velocidade do movimento (%) e presets. */
    static final class AccelDialog {
        private final Activity a;
        private final AttackView v;
        private final int head;
        private Ano.Mpt[] base, work;
        private int frame;                 // frame da cadeia em edicao
        private double pct = 100;
        private AccelPreviewView preview;
        private TextView frameLabel;
        private LinearLayout stepHolder;
        private Stepper pctStepper;

        private AccelDialog(Activity a, AttackView v, int head, int k) {
            this.a = a;
            this.v = v;
            this.head = head;
            Ano.Mpt[] m = v.currentAno().mpts;
            this.base = m;
            this.work = m;
            SpeedLine.Chain c = SpeedLine.chains(m).size() == 0 ? null : v.speedLineChain(head);
            this.frame = c == null ? head : Math.min(c.last, head + k);
        }

        static void show(Activity a, AttackView v, int head, int k) {
            if (v.speedLineChain(head) == null) return;
            new AccelDialog(a, v, head, k).open();
        }

        private SpeedLine.Chain chain() {
            for (SpeedLine.Chain c : SpeedLine.chains(work)) if (head >= c.head && head <= c.last) return c;
            return null;
        }

        private void open() {
            LinearLayout root = new LinearLayout(a);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 4));
            preview = new AccelPreviewView(a);
            root.addView(preview, new LinearLayout.LayoutParams(-1, dp(a, 140)));
            TextView hint = new I18nTextView(a);
            hint.setText("Velocidade por tick: x em vermelho, y em azul. A linha clara marca o inicio do frame em edicao. A aceleração deste frame leva a velocidade até a do próximo.");
            hint.setTextColor(LayoutManager.DIM);
            hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            root.addView(hint);

            LinearLayout nav = new LinearLayout(a);
            nav.setOrientation(LinearLayout.HORIZONTAL);
            nav.setGravity(Gravity.CENTER_VERTICAL);
            TextView prev = Stepper.sideButton(a, "◀"), next = Stepper.sideButton(a, "▶");
            frameLabel = new I18nTextView(a);
            frameLabel.setTextColor(LayoutManager.TEXT);
            frameLabel.setGravity(Gravity.CENTER);
            frameLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            prev.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { step(-1); } });
            next.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { step(1); } });
            nav.addView(prev, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 40)));
            nav.addView(frameLabel, new LinearLayout.LayoutParams(0, -2, 1f));
            nav.addView(next, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 40)));
            root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
            stepHolder = new LinearLayout(a);
            stepHolder.setOrientation(LinearLayout.VERTICAL);
            root.addView(stepHolder);

            label(root, "Velocidade do movimento (%)");
            pctStepper = new Stepper(a).range(5, 500).step(5).keyboard(new Stepper.OnValue() { public void on(double x) {
                pct = x;
                SpeedLine.Chain c = chain();
                if (c != null) work = AccelPresets.scale(base, c, pct);
                refresh(false);
            } }).value(100);
            root.addView(pctStepper.view());
            TextView n2 = new I18nTextView(a);
            n2.setText("Diminui ou aumenta o movimento inteiro mantendo o padrao (os tempos nao mudam).");
            n2.setTextColor(LayoutManager.DIM);
            n2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            root.addView(n2);

            label(root, "Presets (mantem o deslocamento total)");
            for (int i = 0; i < AccelPresets.NAMES.length; i++) {
                final int preset = i;
                TextView b = item(a, AccelPresets.NAMES[i], LayoutManager.TEXT, new View.OnClickListener() { @Override public void onClick(View x) {
                    SpeedLine.Chain c = chain();
                    if (c == null) return;
                    work = AccelPresets.apply(work, c, preset, 100);
                    base = work;
                    pct = 100;
                    pctStepper.value(100);
                    refresh(true);
                } });
                GradientDrawable g = new GradientDrawable();
                g.setColor(LayoutManager.PANEL_HI);
                g.setCornerRadius(dp(a, 8));
                b.setBackground(g);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, dp(a, 3), 0, dp(a, 3));
                root.addView(b, lp);
            }
            ScrollView sv = new SafeScrollView(a);
            sv.addView(root);
            AlertDialog ad = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Aceleracao do movimento")
                    .setView(sv)
                    .setNegativeButton("CANCELAR", null)
                    .setPositiveButton("APLICAR", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) { v.replaceMpts(work, "speedline"); }
                    }).create();
            ad.show();
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(LayoutManager.PANEL);
            bg.setCornerRadius(dp(a, 14));
            ad.getWindow().setBackgroundDrawable(bg);
            refresh(true);
        }

        private TextView label(LinearLayout root, String s) {
            TextView t = new I18nTextView(a);
            t.setText(s);
            t.setTextColor(LayoutManager.TEXT);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            t.setPadding(0, dp(a, 10), 0, dp(a, 2));
            root.addView(t);
            return t;
        }

        private void step(int d) {
            SpeedLine.Chain c = chain();
            if (c == null) return;
            frame = Math.max(c.head, Math.min(c.last, frame + d));
            refresh(true);
        }

        /** Refaz a previa e (se pedido) os campos de accel do frame em edicao. */
        private void refresh(boolean rebuildFields) {
            SpeedLine.Chain c = chain();
            if (c == null) return;
            int[] starts = new int[c.frames() + 1];
            int acc = 0;
            for (int f = c.head; f <= c.last; f++) { starts[f - c.head] = acc; acc += FrameTools.ticks(work[f]); }
            starts[c.frames()] = acc;
            preview.set(SpeedLine.velocities(work, c), starts, frame - c.head);
            frameLabel.setText("Frame " + (frame + 1) + (frame < c.last ? " → " + (frame + 2) : " → fim") + "  (" + (frame - c.head + 1) + " de " + c.frames() + ")  ·  " + FrameTools.ticks(work[frame]) + " ticks");
            if (!rebuildFields) return;
            stepHolder.removeAllViews();
            addAccel("aceleracao x  (px por tick²)", 0);
            addAccel("aceleracao y", 1);
        }

        private void addAccel(String name, final int axis) {
            TextView t = new I18nTextView(a);
            t.setText(name);
            t.setTextColor(LayoutManager.DIM);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            t.setPadding(0, dp(a, 6), 0, 0);
            stepHolder.addView(t);
            Ano.Mpt m = work[frame];
            double cur = (m.flags & 4) != 0 && (m.moveMask & (axis == 0 ? 4 : 8)) != 0 ? (axis == 0 ? m.accelX : m.accelY) / FrameTools.ONE : 0;
            stepHolder.addView(new Stepper(a).range(-99, 99).step(0.1).keyboard(new Stepper.OnValue() { public void on(double x) {
                Ano.Mpt[] n = work.clone();
                n[frame] = FrameTools.setAccel(work[frame], axis, x);
                work = n;
                base = work;
                refresh(false);
            } }).value(cur).view());
        }
    }
}
