package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Acha onde caber uma sprite nova nas folhas existentes (areas livres = mapa de retangulos: o que nenhuma entrada
 * do CNV ocupa; os pixels do PNG nao entram na conta) ou diz que precisa de uma folha nova. Tudo em coordenadas logicas do CNV.
 */
final class SpriteAlloc {
    private SpriteAlloc() { }

    /** Acesso as folhas (pixels fisicos). */
    interface Sheets {
        int count();
        int width(int sheet);
        int height(int sheet);
    }

    static final class Spot {
        int sheet, x, y;
        boolean newSheet;
        int newSize;           // lado (px) da folha nova
    }

    private static final class R {
        int x, y, w, h;
        R(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }
        boolean contains(R o) { return o.x >= x && o.y >= y && o.x + o.w <= x + w && o.y + o.h <= y + h; }
    }

    static int pot(int v) {
        int p = 64;
        while (p < v) p <<= 1;
        return p;
    }

    /** w,h logicos da sprite; gap = folga logica entre sprites (nao exigida na borda da folha). */
    static Spot find(Cnv cnv, Sheets sh, int scale, int w, int h, int gap) {
        ArrayList<Object[]> cands = new ArrayList<Object[]>();   // {score, sheet, y, x, needW, needH}
        int maxDim = 0;
        for (int s = 0; s < sh.count(); s++) {
            int sw = sh.width(s) / scale, shh = sh.height(s) / scale;
            maxDim = Math.max(maxDim, Math.max(sh.width(s), sh.height(s)));
            for (R f : freeRects(cnv, s, sw, shh)) {
                int nw = f.x + f.w >= sw ? w : w + gap, nh = f.y + f.h >= shh ? h : h + gap;
                if (f.w < nw || f.h < nh) continue;
                cands.add(new Object[]{Integer.valueOf(Math.min(f.w - nw, f.h - nh)), Integer.valueOf(s), Integer.valueOf(f.y), Integer.valueOf(f.x)});
            }
        }
        Collections.sort(cands, new Comparator<Object[]>() {
            @Override public int compare(Object[] a, Object[] b) {
                for (int i = 0; i < 4; i++) {
                    int c = ((Integer) a[i]).compareTo((Integer) b[i]);
                    if (c != 0) return c;
                }
                return 0;
            }
        });
        if (!cands.isEmpty()) {
            Object[] c = cands.get(0);
            Spot sp = new Spot();
            sp.sheet = ((Integer) c[1]).intValue();
            sp.y = ((Integer) c[2]).intValue();
            sp.x = ((Integer) c[3]).intValue();
            return sp;
        }
        Spot sp = new Spot();
        sp.newSheet = true;
        sp.sheet = sh.count();
        sp.newSize = Math.max(pot(Math.max(w, h) * scale), maxDim > 0 ? Math.min(maxDim, 1024) : 512);
        return sp;
    }

    /**
     * Melhor encaixe (menor sobra, depois mais acima/esquerda) de uma sprite w x h dentro da folha {@code sheet} SO; null se nao cabe. Nunca cria folha.
     * Mesma folga ({@code gap}) do {@link #find}: nao exigida na borda da folha.
     */
    static Spot findIn(Cnv cnv, Sheets sh, int scale, int w, int h, int gap, int sheet) {
        if (sheet < 0 || sheet >= sh.count() || scale <= 0) return null;
        int sw = sh.width(sheet) / scale, shh = sh.height(sheet) / scale;
        int bestScore = Integer.MAX_VALUE, bestY = 0, bestX = 0;
        boolean found = false;
        for (R f : freeRects(cnv, sheet, sw, shh)) {
            int nw = f.x + f.w >= sw ? w : w + gap, nh = f.y + f.h >= shh ? h : h + gap;
            if (f.w < nw || f.h < nh) continue;
            int score = Math.min(f.w - nw, f.h - nh);
            if (!found || score < bestScore || (score == bestScore && (f.y < bestY || (f.y == bestY && f.x < bestX)))) { found = true; bestScore = score; bestY = f.y; bestX = f.x; }
        }
        if (!found) return null;
        Spot sp = new Spot();
        sp.sheet = sheet; sp.x = bestX; sp.y = bestY;
        return sp;
    }

    /** Retangulos livres maximais da folha {@code s}. */
    static List<R> freeRects(Cnv cnv, int s, int sw, int sh) {
        ArrayList<R> free = new ArrayList<R>();
        free.add(new R(0, 0, sw, sh));
        int step = 0;
        for (int i = 0; i < cnv.size(); i++) {
            Cnv.Entry e = cnv.byImage(i);
            if (e.source != s || e.width <= 0 || e.height <= 0) continue;
            int ux = Math.max(0, e.x), uy = Math.max(0, e.y), ux2 = Math.min(sw, e.x + e.width), uy2 = Math.min(sh, e.y + e.height);
            if (ux2 <= ux || uy2 <= uy) continue;
            ArrayList<R> next = new ArrayList<R>();
            for (R f : free) {
                if (ux >= f.x + f.w || ux2 <= f.x || uy >= f.y + f.h || uy2 <= f.y) { next.add(f); continue; }
                if (ux > f.x) next.add(new R(f.x, f.y, ux - f.x, f.h));
                if (ux2 < f.x + f.w) next.add(new R(ux2, f.y, f.x + f.w - ux2, f.h));
                if (uy > f.y) next.add(new R(f.x, f.y, f.w, uy - f.y));
                if (uy2 < f.y + f.h) next.add(new R(f.x, uy2, f.w, f.y + f.h - uy2));
            }
            free = next;
            if (++step % 24 == 0) free = prune(free);
        }
        return prune(free);
    }

    /**
     * Partes do retangulo logico (x, y, w, h) da folha {@code s} que NENHUMA entrada do CNV usa (as sprites que dividem o mesmo pedaco ficam intactas).
     * Cada item e {x, y, w, h}; vazio se a area toda e usada por outra sprite ou o retangulo e vazio.
     */
    static List<int[]> uncovered(Cnv cnv, int s, int x, int y, int w, int h) {
        ArrayList<R> rest = new ArrayList<R>();
        if (w > 0 && h > 0) rest.add(new R(x, y, w, h));
        for (int i = 0; i < cnv.size() && !rest.isEmpty(); i++) {
            Cnv.Entry e = cnv.byImage(i);
            if (e.source != s || e.width <= 0 || e.height <= 0) continue;
            int ux = e.x, uy = e.y, ux2 = e.x + e.width, uy2 = e.y + e.height;
            ArrayList<R> next = new ArrayList<R>();
            for (R f : rest) {
                if (ux >= f.x + f.w || ux2 <= f.x || uy >= f.y + f.h || uy2 <= f.y) { next.add(f); continue; }
                int cx2 = Math.min(ux2, f.x + f.w);       // faixas sem sobrepor: em cima, embaixo, esquerda e direita da parte coberta
                if (uy > f.y) next.add(new R(f.x, f.y, f.w, uy - f.y));
                if (uy2 < f.y + f.h) next.add(new R(f.x, uy2, f.w, f.y + f.h - uy2));
                int my = Math.max(uy, f.y), my2 = Math.min(uy2, f.y + f.h);
                if (ux > f.x) next.add(new R(f.x, my, ux - f.x, my2 - my));
                if (ux2 < f.x + f.w) next.add(new R(cx2, my, f.x + f.w - ux2, my2 - my));
            }
            rest = next;
        }
        ArrayList<int[]> out = new ArrayList<int[]>();
        for (R f : rest) out.add(new int[]{f.x, f.y, f.w, f.h});
        return out;
    }

    private static ArrayList<R> prune(ArrayList<R> in) {
        ArrayList<R> out = new ArrayList<R>();
        for (int i = 0; i < in.size(); i++) {
            R a = in.get(i);
            boolean inside = false;
            for (int j = 0; j < in.size() && !inside; j++) {
                if (i == j) continue;
                R b = in.get(j);
                if (b.contains(a) && (!a.contains(b) || j < i)) inside = true;
            }
            if (!inside) out.add(a);
        }
        return out;
    }
}
