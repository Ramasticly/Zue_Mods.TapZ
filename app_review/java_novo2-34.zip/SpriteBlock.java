package com.zue.attackeditor;

import java.util.Set;

/** Marcadas seguidas (sem espaco entre elas) formam um bloco que o puxador da primeira move junto. Java puro. */
final class SpriteBlock {
    private SpriteBlock() { }

    /** {primeira, quantas} se as marcadas sao consecutivas (min..max sem buraco); null se vazio ou com espaco. */
    static int[] contiguous(Set<Integer> sel) {
        if (sel == null || sel.isEmpty()) return null;
        int lo = Integer.MAX_VALUE, hi = Integer.MIN_VALUE;
        for (Integer i : sel) { lo = Math.min(lo, i.intValue()); hi = Math.max(hi, i.intValue()); }
        if (lo < 0 || hi - lo + 1 != sel.size()) return null;
        return new int[]{lo, sel.size()};
    }
}
