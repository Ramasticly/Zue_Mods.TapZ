package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Hurtbox, hitbox e efeito dos frames de uma sprite, UMA IMAGEM POR VEZ e com previa: a caixa depende do desenho, entao cada
 * sprite escolhida aparece num frame real que a usa; o resultado ao vivo e conferido ali e so depois vale para todos os frames dela.
 * A previa usa uma copia do DAC com so a ANO de amostra trocada: o DAC real so muda ao APLICAR.
 */
final class SpriteBoxEditor {
    private static final int TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF;

    private final Activity a;
    private final CharAssets ca;
    private final List<Integer> images;
    private final Runnable applied;
    private int pos;
    private int framesChanged;

    private SpriteBoxEditor(Activity a, CharAssets ca, List<Integer> images, Runnable applied) {
        this.a = a; this.ca = ca; this.images = images; this.applied = applied;
    }

    static void show(Activity a, CharAssets ca, List<Integer> images, Runnable applied) {
        if (images.isEmpty()) return;
        new SpriteBoxEditor(a, ca, images, applied).next();
    }

    private void finish() {
        if (framesChanged > 0) {
            applied.run();
            SpriteListScreen.toast(a, framesChanged + " frame(s) alterado(s) (salve o DAC para gravar)");
        }
    }

    /** Proxima imagem que algum frame usa. */
    private void next() {
        while (pos < images.size()) {
            int img = images.get(pos).intValue();
            Set<Integer> one = new HashSet<Integer>();
            one.add(Integer.valueOf(img));
            SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, one);
            if (u.frames > 0) { open(img, u); return; }
            pos++;
        }
        finish();
    }

    private static EditText num(Activity a, int v) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(String.valueOf(v));
        e.setSelectAllOnFocus(true);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        return e;
    }

    private static int val(EditText e, int d) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (NumberFormatException x) { return d; }
    }

    private LinearLayout row(String[] labels, EditText[] es) {
        LinearLayout r = new LinearLayout(a);
        for (int i = 0; i < es.length; i++) {
            LinearLayout c = new LinearLayout(a);
            c.setOrientation(LinearLayout.VERTICAL);
            c.addView(SpriteListScreen.text(a, labels[i], 10, DIM, false));
            c.addView(es[i]);
            r.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return r;
    }

    private void open(final int img, SpriteMass.Usage u) {
        // frame de amostra: o primeiro que usa a imagem
        int sAno = u.anos.get(0).intValue(), sPat = 0;
        Ano base = ca.dac.getAno(sAno);
        for (int k = 0; k < base.mpts.length; k++) if (base.mpts[k].image == img) { sPat = k; break; }
        final Ano sample = base;
        final int pat = sPat, anoIdx = sAno;
        final Ano.Mpt frame = sample.mpts[pat];

        final SpriteMass.Edit ed = new SpriteMass.Edit();
        Ano.Hit h1 = firstHit(frame, 1), h2 = firstHit(frame, 2);
        if (h1 != null) ed.hurtBox = new int[]{h1.x, h1.y, h1.width, h1.height};
        if (h2 != null) ed.hitBox = new int[]{h2.x, h2.y, h2.width, h2.height};

        final ScrollView sv = new SafeScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 6));
        sv.addView(col);
        col.addView(SpriteListScreen.text(a, "SPR_" + img + "  ·  imagem " + (pos + 1) + " de " + images.size() + "\n" + u.frames + " frame(s) em " + u.anos.size()
                + " ANO(s) usam esta imagem. A prévia mostra o frame " + (pat + 1) + " da ANO " + anoIdx + "; ao APLICAR a configuração vale para todos os frames dela.", 12, TEXT, false));
        final AnimPreview pv = new AnimPreview(a);
        pv.setShowHits(true);
        col.addView(pv, new LinearLayout.LayoutParams(-1, SpriteListScreen.dp(a, 250)));

        final int[] sHurt = {h1 != null ? SpriteMass.SET : 0}, sHit = {h2 != null ? SpriteMass.SET : 0}, sFx = {0};
        final String[] tri = {"não mexer", "definir", "remover"};
        final EditText[] hu = {num(a, ed.hurtBox[0]), num(a, ed.hurtBox[1]), num(a, ed.hurtBox[2]), num(a, ed.hurtBox[3])};
        final EditText[] hi = {num(a, ed.hitBox[0]), num(a, ed.hitBox[1]), num(a, ed.hitBox[2]), num(a, ed.hitBox[3])};
        final EditText fx = num(a, 0), fy = num(a, 0);
        final int[] fxAno = {0};
        final Runnable refresh = new Runnable() { @Override public void run() {
            ed.hurt = sHurt[0]; ed.hit = sHit[0];
            for (int i = 0; i < 4; i++) { ed.hurtBox[i] = val(hu[i], 0); ed.hitBox[i] = val(hi[i], 0); }
            ed.effect = sFx[0]; ed.effectAno = fxAno[0]; ed.effectX = val(fx, 0); ed.effectY = val(fy, 0);
            Ano.Mpt[] m = sample.mpts.clone();
            m[pat] = SpriteMass.applyTo(frame, ed);
            Ano shown = new Ano(sample.index, true, sample.flags, sample.priority, sample.links, m);
            pv.set(ca.dac.copyWith(anoIdx, shown), ca.sprites, anoIdx);
            pv.setPlayUntil(pat);
            pv.setMarker(ed.effect == SpriteMass.SET && ed.effectAno >= 201, ed.effectX, ed.effectY);
        } };
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) { }
            public void onTextChanged(CharSequence s, int st, int b, int c) { }
            public void afterTextChanged(Editable e) { refresh.run(); }
        };

        col.addView(title("Hurtbox", "Substitui as hurtboxes (corpo) deste desenho. Verde na prévia."));
        col.addView(cycle(tri, sHurt, refresh));
        col.addView(row(new String[]{"x", "y", "largura", "altura"}, hu));
        col.addView(title("Hitbox", "Substitui as hitboxes (ataque) deste desenho. Dano e reação ficam como estão."));
        col.addView(cycle(tri, sHit, refresh));
        col.addView(row(new String[]{"x", "y", "largura", "altura"}, hi));
        col.addView(title("Efeito do personagem", "Efeito (ANOs 201 a 255) criado neste desenho; a cruz amarela marca o ponto x/y."));
        col.addView(cycle(tri, sFx, refresh));
        final TextView fxBtn = SpriteListScreen.button(a, "ESCOLHER EFEITO", null);
        fxBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            AnoPicker.show(a, ca.dac, ca.sprites, false, fxAno[0], "Efeito do personagem (ANO 201+)", false, new AnoPicker.Listener() {
                @Override public void onPick(int ano) {
                    if (ano < 201) { SpriteListScreen.toast(a, "efeitos do personagem são as ANOs 201 a 255"); return; }
                    fxAno[0] = ano; fxBtn.setText("EFEITO: ANO " + ano); refresh.run();
                }
            });
        } });
        col.addView(fxBtn);
        col.addView(row(new String[]{"x", "y"}, new EditText[]{fx, fy}));
        for (EditText e : hu) e.addTextChangedListener(tw);
        for (EditText e : hi) e.addTextChangedListener(tw);
        fx.addTextChangedListener(tw);
        fy.addTextChangedListener(tw);
        refresh.run();

        final AlertDialog dlg = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Caixas e efeito — SPR_" + img).setView(sv)
                .setNegativeButton("FECHAR", null).setNeutralButton("PULAR", null).setPositiveButton("APLICAR", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ACCENT);
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            refresh.run();
            if (ed.effect == SpriteMass.SET && ed.effectAno < 201) { SpriteListScreen.toast(a, "escolha o efeito (ANO 201+)"); return; }
            if (!ed.any()) { SpriteListScreen.toast(a, "nada marcado: use PULAR para ir à próxima"); return; }
            Set<Integer> one = new HashSet<Integer>();
            one.add(Integer.valueOf(img));
            framesChanged += SpriteMass.apply(ca.dac, one, ed);
            dlg.dismiss();
            pos++;
            next();
        } });
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dlg.dismiss();
            pos++;
            next();
        } });
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dlg.dismiss();
            finish();
        } });
    }

    private static Ano.Hit firstHit(Ano.Mpt m, int flag) {
        if ((m.flags & 0x10) != 0) for (Ano.Hit h : m.hits) if (h.flag == flag) return h;
        return null;
    }

    private View title(String t, String note) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(0, SpriteListScreen.dp(a, 12), 0, SpriteListScreen.dp(a, 2));
        c.addView(SpriteListScreen.text(a, t, 13, ACCENT, true));
        c.addView(SpriteListScreen.text(a, note, 11, DIM, false));
        return c;
    }

    private TextView cycle(final String[] names, final int[] state, final Runnable changed) {
        final TextView t = SpriteListScreen.button(a, names[state[0]], null);
        t.setTextColor(state[0] == 0 ? DIM : ACCENT);
        t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            state[0] = (state[0] + 1) % names.length;
            t.setText(names[state[0]]);
            t.setTextColor(state[0] == 0 ? DIM : ACCENT);
            changed.run();
        } });
        return t;
    }
}
