package com.zue.attackeditor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Resolve IMG (DAC) -> recorte do PNG via CNV. Cada sprite e montado uma unica vez.
 * Falhas nao viram excecao a cada frame: ficam registradas (errorCount/lastError) para o app mostrar.
 */
public final class SpriteCache {
    public static final class Sprite {
        public final Bitmap bitmap;
        /** Recorte em pixels fisicos do PNG. */
        public final Rect src;
        /** Tamanho logico (CNV) usado nas contas de flip/zoom do jogo. */
        public final int logicalWidth;
        public final int logicalHeight;
        /** Tamanho logico realmente desenhavel (proporcional se o recorte passou do PNG). */
        public final float drawWidth;
        public final float drawHeight;

        Sprite(Bitmap bitmap, Rect src, int lw, int lh, float dw, float dh) {
            this.bitmap = bitmap;
            this.src = src;
            this.logicalWidth = lw;
            this.logicalHeight = lh;
            this.drawWidth = dw;
            this.drawHeight = dh;
        }
    }

    private final File characterDir;
    private final Cnv cnv;
    private final Map<Integer, Bitmap> pngs = new HashMap<Integer, Bitmap>();
    private final Map<Integer, Boolean> missingPngs = new HashMap<Integer, Boolean>();
    private static final int BIG_SHEET = 48 * 1024 * 1024;
    private final java.util.ArrayList<Bitmap> crops = new java.util.ArrayList<Bitmap>();
    private Sprite[] sprites;
    private boolean[] failed;
    private final java.util.Set<Integer> outOfRange = new java.util.HashSet<Integer>();
    private int errorCount;
    private String lastError = "";

    public SpriteCache(File characterDir, Cnv cnv) {
        this.characterDir = characterDir;
        this.cnv = cnv;
        this.sprites = new Sprite[cnv.size()];
        this.failed = new boolean[cnv.size()];
    }

    /** Sprite da imagem, ou null se for -1 ou se houve erro (veja lastError). */
    public Sprite get(int image) {
        if (image < 0) return null;
        if (image >= sprites.length) {
            // registra uma unica vez por indice fora da tabela
            if (outOfRange.add(Integer.valueOf(image)))
                error("IMG " + image + " fora do CNV (" + sprites.length + ")");
            return null;
        }
        Sprite cached = sprites[image];
        if (cached != null) {
            if (!cached.bitmap.isRecycled()) return cached;
            sprites[image] = null;
        }
        if (failed[image]) return null;

        Cnv.Entry e = cnv.byImage(image);
        if (e == null) { fail(image, "IMG " + image + " sem entrada no CNV"); return null; }

        Bitmap b = png(e.source);
        if (b == null) { failed[image] = true; return null; }

        int s = cnv.scale();
        int l = e.x * s, t = e.y * s, w = e.width * s, h = e.height * s;
        if (e.width <= 0 || e.height <= 0) { fail(image, "IMG " + image + ": recorte vazio"); return null; }
        if (l < 0 || t < 0 || l >= b.getWidth() || t >= b.getHeight()) {
            fail(image, "IMG " + image + ": recorte fora de " + pngName(e.source));
            return null;
        }
        int cw = Math.min(w, b.getWidth() - l);
        int ch = Math.min(h, b.getHeight() - t);
        float dw = e.width * (cw / (float) w);
        float dh = e.height * (ch / (float) h);
        Sprite sp;
        if (b.getByteCount() > BIG_SHEET) {
            // o canvas acelerado recusa bitmaps grandes (~100 MB): desenha de uma copia so do recorte
            try {
                Bitmap crop = Bitmap.createBitmap(b, l, t, cw, ch);
                crops.add(crop);
                sp = new Sprite(crop, new Rect(0, 0, cw, ch), e.width, e.height, dw, dh);
            } catch (Throwable oom) { fail(image, "IMG " + image + ": sem memoria para o recorte"); return null; }
        } else {
            sp = new Sprite(b, new Rect(l, t, l + cw, t + ch), e.width, e.height, dw, dh);
        }
        sprites[image] = sp;
        return sp;
    }

    private Bitmap png(int source) {
        Integer key = Integer.valueOf(source);
        Bitmap cached = pngs.get(key);
        if (cached != null && !cached.isRecycled()) return cached;
        if (missingPngs.containsKey(key)) return null;
        File f = new File(characterDir, pngName(source));
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inMutable = true;
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            if (b == null) throw new IOException("PNG invalido");
            pngs.put(key, b);
            return b;
        } catch (IOException ex) {
            missingPngs.put(key, Boolean.TRUE);
            error(pngName(source) + ": " + ex.getMessage());
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (IOException ignored) { }
        }
    }

    private static String pngName(int source) {
        return String.format(java.util.Locale.US, "%03d.png", source);
    }

    private void fail(int image, String msg) {
        failed[image] = true;
        error(msg);
    }

    private void error(String msg) {
        errorCount++;
        lastError = msg;
    }

    public int errorCount() { return errorCount; }
    public String lastError() { return lastError; }

    /** Depois de mudar o CNV ou as folhas no disco: esquece tudo e relê (a tabela pode ter crescido). */
    public void reload() {
        clear();
        missingPngs.clear();
        outOfRange.clear();
        sprites = new Sprite[cnv.size()];
        failed = new boolean[cnv.size()];
    }

    /** Folha {@code source} (carrega do disco se preciso); null se nao existe. */
    public Bitmap sheet(int source) { return png(source); }

    public void clear() {
        for (int i = 0; i < sprites.length; i++) sprites[i] = null;
        for (Bitmap b : pngs.values()) if (b != null && !b.isRecycled()) b.recycle();
        pngs.clear();
        for (Bitmap c : crops) if (c != null && !c.isRecycled()) c.recycle();
        crops.clear();
    }
}
