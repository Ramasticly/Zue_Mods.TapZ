package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * "Remover Sprites repetidas": acha sprites iguais ou parecidas, mesmo espelhadas, giradas em 90 graus ou em outra escala
 * (relacao {@link SpriteXform}). Cada sprite vira uma assinatura de 32 x 32 celulas (media por celula, ate o fim da borda) mais um hash do conteudo exato.
 * Java puro: o app entrega os pixels ARGB.
 */
final class SpriteDedup {
    private SpriteDedup() { }

    static final int N = 32;
    /** Diferenca por canal (0..255) a partir da qual a celula conta como diferente. */
    static final int TOL = 20;
    /** As proporcoes (largura / altura) so podem diferir assim para serem a mesma imagem. */
    static final double ASPECT_TOL = 0.04;

    static final class Sig {
        int index, w, h;                 // w x h = tamanho logico do recorte no CNV
        int[] cell = new int[N * N];     // ARGB medio de cada celula
        long hash;                       // pixels exatos (RGB escondido pela transparencia nao conta)
        int area() { return w * h; }
    }

    /** {@code px}: ARGB do recorte inteiro, {@code pw x ph} (pode ser maior que o tamanho logico: personagem x2). */
    static Sig sig(int index, int[] px, int pw, int ph, int logicalW, int logicalH) {
        Sig s = new Sig();
        s.index = index; s.w = logicalW; s.h = logicalH;
        long hs = 1125899906842597L;
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            if ((p >>> 24) == 0) p = 0;
            hs = 31 * hs + p;
        }
        s.hash = hs * 31 + pw * 7L + ph;
        for (int cy = 0; cy < N; cy++) {
            int y0 = cy * ph / N, y1 = Math.max(y0 + 1, (cy + 1) * ph / N);
            for (int cx = 0; cx < N; cx++) {
                int x0 = cx * pw / N, x1 = Math.max(x0 + 1, (cx + 1) * pw / N);
                long a = 0, r = 0, g = 0, b = 0;
                int c = 0;
                for (int y = y0; y < Math.min(ph, y1); y++) {
                    for (int x = x0; x < Math.min(pw, x1); x++) {
                        int p = px[y * pw + x];
                        int pa = p >>> 24;
                        a += pa; r += ((p >> 16) & 255) * pa; g += ((p >> 8) & 255) * pa; b += (p & 255) * pa;     // cor ponderada pelo alpha
                        c++;
                    }
                }
                if (c == 0 || a == 0) { s.cell[cy * N + cx] = 0; continue; }
                s.cell[cy * N + cx] = ((int) (a / c) << 24) | ((int) (r / a) << 16) | ((int) (g / a) << 8) | (int) (b / a);
            }
        }
        return s;
    }

    /** Celula (cx, cy) de R vista pelo mapa g: a que corresponde em K. */
    private static int mapped(Sig r, int g, int cx, int cy) {
        double[] gg = SpriteXform.G[g];
        double u = (cx + 0.5) / N, v = (cy + 0.5) / N;
        double ku = gg[0] * u + gg[1] * v + gg[4], kv = gg[2] * u + gg[3] * v + gg[5];
        int kx = Math.max(0, Math.min(N - 1, (int) Math.floor(ku * N))), ky = Math.max(0, Math.min(N - 1, (int) Math.floor(kv * N)));
        return ky * N + kx;
    }

    static final class Match {
        int score;       // 0..100 (100 = identico no conteudo exato)
        int g;           // relacao R(u, v) = K(g(u, v))
        Match(int score, int g) { this.score = score; this.g = g; }
    }

    /** Melhor relacao de R com K entre as 8; null se nenhuma passa de {@code minPct}. A proporcao tem que bater (com troca de eixos nas giradas). */
    static Match best(Sig r, Sig k, int minPct) { return scan(r, k, minPct, true); }

    /**
     * Como {@link #best}, mas SEM exigir a mesma proporcao (a assinatura 32 x 32 ja e normalizada): serve para ordenar/filtrar qualquer sprite por semelhanca com R
     * (a nota e a das celulas, esticadas se a proporcao for outra). Nunca devolve null para sprites com tamanho valido; 0 se nao ha nada em comum.
     */
    static Match bestAny(Sig r, Sig k) {
        Match m = scan(r, k, 0, false);
        return m != null ? m : new Match(0, 0);
    }

    /** Nota (0..100) de cada sprite de {@code all} contra {@code ref} (a propria ref fica de fora). */
    static java.util.Map<Integer, Integer> scores(Sig ref, java.util.Collection<Sig> all) {
        java.util.Map<Integer, Integer> out = new java.util.HashMap<Integer, Integer>();
        for (Sig k : all) {
            if (k.index == ref.index) continue;
            out.put(Integer.valueOf(k.index), Integer.valueOf(bestAny(ref, k).score));
        }
        return out;
    }

    private static Match scan(Sig r, Sig k, int minPct, boolean gate) {
        Match best = null;
        if (r.w <= 0 || r.h <= 0 || k.w <= 0 || k.h <= 0) return null;
        for (int g = 0; g < 8; g++) {
            double ar = SpriteXform.swapsAxes(g) ? (double) r.h / r.w : (double) r.w / r.h;
            double ak = (double) k.w / k.h;
            if (gate && Math.abs(ar - ak) > ASPECT_TOL * Math.max(ar, ak)) continue;
            int same = 0, used = 0;
            for (int cy = 0; cy < N; cy++) {
                for (int cx = 0; cx < N; cx++) {
                    int p = r.cell[cy * N + cx], q = k.cell[mapped(r, g, cx, cy)];
                    int pa = p >>> 24, qa = q >>> 24;
                    if (pa == 0 && qa == 0) continue;
                    used++;
                    int d = Math.abs(pa - qa);
                    if (pa != 0 && qa != 0) {
                        d = Math.max(d, Math.abs(((p >> 16) & 255) - ((q >> 16) & 255)));
                        d = Math.max(d, Math.abs(((p >> 8) & 255) - ((q >> 8) & 255)));
                        d = Math.max(d, Math.abs((p & 255) - (q & 255)));
                    }
                    if (d <= TOL) same++;
                }
            }
            if (used == 0) continue;
            int sc = Math.min(99, (int) Math.floor(100.0 * same / used));
            if (g == 0 && r.hash == k.hash && r.w == k.w && r.h == k.h) sc = 100;
            if (sc >= minPct && (best == null || sc > best.score)) best = new Match(sc, g);
        }
        return best;
    }

    static final class Member {
        int index;       // sprite
        Match toRep;     // relacao desta sprite com a que fica (null na propria representante)
        int maxScore() { return toRep == null ? 100 : toRep.score; }
    }

    static final class Group {
        final List<Member> members = new ArrayList<Member>();      // [0] = representante (a de maior area)
        int rep() { return members.get(0).index; }
    }

    /** Agrupa: a sprite de maior area ainda livre vira a representante e leva as que casam com ela direto. Grupos de 2 ou mais. */
    static List<Group> groups(List<Sig> sigs, int minPct) {
        List<Sig> order = new ArrayList<Sig>(sigs);
        java.util.Collections.sort(order, new java.util.Comparator<Sig>() {
            @Override public int compare(Sig a, Sig b) { return a.area() != b.area() ? (a.area() > b.area() ? -1 : 1) : (a.index < b.index ? -1 : a.index > b.index ? 1 : 0); }
        });
        boolean[] done = new boolean[order.size()];
        List<Group> out = new ArrayList<Group>();
        for (int i = 0; i < order.size(); i++) {
            if (done[i]) continue;
            Sig rep = order.get(i);
            Group g = null;
            for (int j = i + 1; j < order.size(); j++) {
                if (done[j]) continue;
                Match m = best(order.get(j), rep, minPct);
                if (m == null) continue;
                if (g == null) { g = new Group(); Member r = new Member(); r.index = rep.index; g.members.add(r); done[i] = true; }
                Member mem = new Member();
                mem.index = order.get(j).index; mem.toRep = m;
                g.members.add(mem);
                done[j] = true;
            }
            if (g != null) out.add(g);
        }
        java.util.Collections.sort(out, new java.util.Comparator<Group>() {
            @Override public int compare(Group a, Group b) { return a.rep() - b.rep(); }
        });
        return out;
    }

    // ---- aplicar ----

    /** Uma sprite a remover e a que a substitui, com a relacao entre elas. */
    static final class Choice {
        Sig removed, kept;
        Match match;
    }

    /** Entre as sprites que ficam, a que melhor substitui {@code r}; null se nenhuma casa. */
    static Choice choose(Sig r, List<Sig> kept, int minPct) {
        Choice c = null;
        for (Sig k : kept) {
            if (k.index == r.index) continue;
            Match m = best(r, k, minPct);
            if (m != null && (c == null || m.score > c.match.score)) { c = new Choice(); c.removed = r; c.kept = k; c.match = m; }
        }
        return c;
    }

    /** ANOs usadas como link (filhas) de outra: o deslocamento do link tambem espelha, entao nelas nao se troca Flip. */
    static java.util.Set<Integer> linkChildren(Dac dac) {
        java.util.HashSet<Integer> r = new java.util.HashSet<Integer>();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present || a.links == null) continue;
            for (Ano.Link l : a.links) r.add(Integer.valueOf(l.getAno()));
        }
        return r;
    }

    static final class Result {
        final java.util.TreeSet<Integer> removedSprites = new java.util.TreeSet<Integer>();
        final java.util.TreeSet<Integer> changedAnos = new java.util.TreeSet<Integer>();
        final List<Integer> skipped = new ArrayList<Integer>();       // sprites que ficaram porque um frame nao tem solucao
        int framesRewritten;
    }

    /**
     * Reescreve no DAC os frames das sprites removidas para usarem as que ficam (Flip, zoom, rotacao e posicao ajustados). Uma sprite so e removida se
     * TODOS os frames dela tem solucao; senao ela fica e nada dela muda. Quem chama exclui as removidas com {@link SpriteLib#removeShift} e
     * {@link SpriteRenumber#remapDac}.
     */
    static Result apply(Dac dac, List<Choice> choices) {
        Result res = new Result();
        java.util.Set<Integer> kids = linkChildren(dac);
        for (Choice c : choices) {
            java.util.ArrayList<Object[]> plan = new java.util.ArrayList<Object[]>();       // {ano, indice do mpt, mpt novo}
            boolean ok = true;
            for (int i = 0; i < dac.size() && ok; i++) {
                Ano a = dac.getAno(i);
                if (a == null || !a.present) continue;
                for (int m = 0; m < a.mpts.length && ok; m++) {
                    if (a.mpts[m].image != c.removed.index) continue;
                    Ano.Mpt n = SpriteXform.rewrite(a.mpts[m], c.removed.w, c.removed.h, c.kept.w, c.kept.h, c.match.g, c.kept.index, !kids.contains(Integer.valueOf(i)));
                    if (n == null) ok = false; else plan.add(new Object[]{Integer.valueOf(i), Integer.valueOf(m), n});
                }
            }
            if (!ok) { res.skipped.add(Integer.valueOf(c.removed.index)); continue; }
            for (Object[] p : plan) {
                int ano = ((Integer) p[0]).intValue(), m = ((Integer) p[1]).intValue();
                dac.getAno(ano).mpts[m] = (Ano.Mpt) p[2];
                res.changedAnos.add((Integer) p[0]);
                res.framesRewritten++;
            }
            res.removedSprites.add(Integer.valueOf(c.removed.index));
        }
        return res;
    }
}
