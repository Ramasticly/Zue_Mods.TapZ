package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * "Remover Sprites repetidas": acha sprites iguais ou parecidas, mesmo espelhadas, giradas em 90 graus, em outra escala, achatadas (zoom X diferente de Y)
 * ou em qualquer angulo (relacao {@link SpriteXform}; angulo qualquer em {@link SpriteRotSearch}). Cada sprite vira uma assinatura de 32 x 32 celulas
 * (media por celula, com peso fracionario) do RECORTE JUSTO do conteudo (margens transparentes nao contam) mais um hash do conteudo exato.
 * Java puro: o app entrega os pixels ARGB.
 */
final class SpriteDedup {
    private SpriteDedup() { }

    static final int N = 32;
    /** Diferenca por canal (0..255) a partir da qual a celula conta como diferente. */
    static final int TOL = 20;
    /** Pixels com alpha menor que isto nao contam para o recorte justo (sobras de suavizacao). */
    static final int TIGHT_ALPHA = 8;
    /** Nota a partir da qual duas sprites ja se consideram parentes sem girar (a busca por angulo as pula). */
    static final int RELATED = 50;
    /** Folga extra de tolerancia nas celulas de borda: EDGE_K x contraste, no maximo EDGE_MAX. */
    static final double EDGE_K = 0.7;
    static final int EDGE_MAX = 140;
    /** Lado maior da miniatura usada na busca por angulo qualquer. */
    static final int THUMB = 32;
    /** Limites de sanidade da relacao (escala de K em relacao a R): achatamento maximo e escala minima/maxima. */
    static final double MAX_STRETCH = 8, MIN_SCALE = 0.02, MAX_SCALE = 50;

    static final class Sig {
        int index, w, h;                 // w x h = tamanho logico do recorte no CNV
        int[] cell = new int[N * N];     // ARGB medio de cada celula (sobre o recorte justo)
        long hash;                       // pixels exatos (RGB escondido pela transparencia nao conta)
        boolean empty;                   // nada visivel
        double tx0, ty0, tx1, ty1;       // recorte justo, em 0..1 do retangulo logico
        int[] edge = new int[N * N];     // contraste de cada celula com as 4 vizinhas (0..255): borda tem posicao incerta apos reamostrar
        int[][] cells = new int[3][];    // piramide: 32 x 32, 16 x 16 e 8 x 8 (sprites pequenas se comparam numa grade mais grossa)
        int[][] edges = new int[3][];
        int tpw, tph;                    // tamanho do recorte justo em pixels fisicos
        int nonEmpty;                    // celulas com alguma coisa
        int[] thumb; int tw, th;         // miniatura (ARGB) do recorte justo
        double tux, tuy;                 // pixels logicos por pixel da miniatura
        int[] work; int ww, wh;          // imagem de trabalho (ate SpriteVerify.WORK px) do recorte justo, para a conferencia em pixels
        double wux, wuy;                 // pixels logicos por pixel da imagem de trabalho
        float[] hist = new float[64];    // cores (2 bits por canal) dos pixels opacos, soma 1
        int area() { return w * h; }
        /** Tamanho logico do recorte justo. */
        double tightW() { return (tx1 - tx0) * w; }
        double tightH() { return (ty1 - ty0) * h; }
    }

    /**
     * Media (peso fracionario por area) de {@code px} (ARGB, {@code pw x ph}) na janela [x0,x1) x [y0,y1) em pixels, reamostrada para {@code ow x oh}.
     * Cor ponderada pelo alpha; sem nada visivel numa celula = 0.
     */
    static int[] box(int[] px, int pw, int ph, double x0, double y0, double x1, double y1, int ow, int oh) {
        int[] out = new int[ow * oh];
        double sx = (x1 - x0) / ow, sy = (y1 - y0) / oh;
        for (int cy = 0; cy < oh; cy++) {
            double ya = y0 + cy * sy, yb = ya + sy;
            int iy0 = Math.max(0, (int) Math.floor(ya)), iy1 = Math.min(ph - 1, (int) Math.ceil(yb) - 1);
            for (int cx = 0; cx < ow; cx++) {
                double xa = x0 + cx * sx, xb = xa + sx;
                int ix0 = Math.max(0, (int) Math.floor(xa)), ix1 = Math.min(pw - 1, (int) Math.ceil(xb) - 1);
                double ws = 0, a = 0, r = 0, g = 0, b = 0;
                for (int y = iy0; y <= iy1; y++) {
                    double wy = Math.min(yb, y + 1) - Math.max(ya, y);
                    if (wy <= 0) continue;
                    for (int x = ix0; x <= ix1; x++) {
                        double wx = Math.min(xb, x + 1) - Math.max(xa, x);
                        if (wx <= 0) continue;
                        double w = wx * wy;
                        int p = px[y * pw + x];
                        int pa = p >>> 24;
                        ws += w;
                        a += w * pa; r += w * pa * ((p >> 16) & 255); g += w * pa * ((p >> 8) & 255); b += w * pa * (p & 255);
                    }
                }
                if (ws <= 0 || a <= 0) continue;
                int ia = (int) Math.min(255, a / ws + 0.5);
                out[cy * ow + cx] = (ia << 24) | ((int) Math.min(255, r / a + 0.5) << 16) | ((int) Math.min(255, g / a + 0.5) << 8) | (int) Math.min(255, b / a + 0.5);
            }
        }
        return out;
    }

    /** {@code px}: ARGB do recorte inteiro, {@code pw x ph} (pode ser maior que o tamanho logico: personagem x2). */
    static Sig sig(int index, int[] px, int pw, int ph, int logicalW, int logicalH) {
        Sig s = new Sig();
        s.index = index; s.w = logicalW; s.h = logicalH;
        long hs = 1125899906842597L;
        int minx = pw, miny = ph, maxx = -1, maxy = -1;
        int[] hc = new int[64];
        int opaque = 0;
        int[] colMax = new int[pw], rowMax = new int[ph];
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            if ((p >>> 24) == 0) p = 0;
            hs = 31 * hs + p;
            int pa = p >>> 24;
            if (pa >= TIGHT_ALPHA) {
                int x = i % pw, y = i / pw;
                if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y;
                if (pa > colMax[x]) colMax[x] = pa;
                if (pa > rowMax[y]) rowMax[y] = pa;
                if (pa >= 128) { hc[(((p >> 22) & 3) << 4) | (((p >> 14) & 3) << 2) | ((p >> 6) & 3)]++; opaque++; }
            }
        }
        s.hash = hs * 31 + pw * 7L + ph;
        if (maxx < 0 || logicalW <= 0 || logicalH <= 0) { s.empty = true; return s; }
        // bordas do recorte justo com fracao de pixel: o pixel da ponta cobre so parte do pixel (alpha), entao a borda esta dentro dele
        double fx0 = minx + (1 - colMax[minx] / 255.0), fx1 = maxx + colMax[maxx] / 255.0;
        double fy0 = miny + (1 - rowMax[miny] / 255.0), fy1 = maxy + rowMax[maxy] / 255.0;
        if (fx1 - fx0 < 0.5) { fx0 = minx; fx1 = maxx + 1; }
        if (fy1 - fy0 < 0.5) { fy0 = miny; fy1 = maxy + 1; }
        s.tx0 = fx0 / pw; s.tx1 = fx1 / pw;
        s.ty0 = fy0 / ph; s.ty1 = fy1 / ph;
        s.cell = box(px, pw, ph, fx0, fy0, fx1, fy1, N, N);
        for (int c : s.cell) if ((c >>> 24) != 0) s.nonEmpty++;
        s.tpw = (int) Math.ceil(fx1 - fx0); s.tph = (int) Math.ceil(fy1 - fy0);
        pyramid(s.cells, s.edges, s.cell);
        s.edge = s.edges[0];
        if (opaque > 0) for (int i = 0; i < 64; i++) s.hist[i] = hc[i] / (float) opaque;
        double rw = s.tightW(), rh = s.tightH();
        double k = Math.min(pw / (double) logicalW, THUMB / Math.max(rw, rh));       // pixels da miniatura por pixel logico
        s.tw = Math.max(1, (int) Math.round(rw * k)); s.th = Math.max(1, (int) Math.round(rh * k));
        s.thumb = box(px, pw, ph, fx0, fy0, fx1, fy1, s.tw, s.th);
        s.tux = rw / s.tw; s.tuy = rh / s.th;
        double kw2 = Math.min(pw / (double) logicalW, SpriteVerify.WORK / Math.max(rw, rh));
        s.ww = Math.max(1, (int) Math.round(rw * kw2)); s.wh = Math.max(1, (int) Math.round(rh * kw2));
        s.work = box(px, pw, ph, fx0, fy0, fx1, fy1, s.ww, s.wh);
        s.wux = rw / s.ww; s.wuy = rh / s.wh;
        return s;
    }

    /** Para cada nivel, g e celula (cx, cy) de R: indice da celula de K. */
    private static final int[][][] MAP = new int[3][8][];
    static {
        for (int l = 0; l < 3; l++) {
            int n = N >> l;
            for (int g = 0; g < 8; g++) {
                MAP[l][g] = new int[n * n];
                double[] gg = SpriteXform.G[g];
                for (int cy = 0; cy < n; cy++) {
                    for (int cx = 0; cx < n; cx++) {
                        double u = (cx + 0.5) / n, v = (cy + 0.5) / n;
                        double ku = gg[0] * u + gg[1] * v + gg[4], kv = gg[2] * u + gg[3] * v + gg[5];
                        int kx = Math.max(0, Math.min(n - 1, (int) Math.floor(ku * n))), ky = Math.max(0, Math.min(n - 1, (int) Math.floor(kv * n)));
                        MAP[l][g][cy * n + cx] = ky * n + kx;
                    }
                }
            }
        }
    }

    /** Maior diferenca (alpha ou cor onde ambos aparecem) entre duas celulas ARGB. */
    private static int diff(int p, int q) {
        int pa = p >>> 24, qa = q >>> 24;
        int d = Math.abs(pa - qa);
        if (pa > 64 && qa > 64) {
            d = Math.max(d, Math.abs(((p >> 16) & 255) - ((q >> 16) & 255)));
            d = Math.max(d, Math.abs(((p >> 8) & 255) - ((q >> 8) & 255)));
            d = Math.max(d, Math.abs((p & 255) - (q & 255)));
        }
        return d;
    }

    /** Contraste de cada celula (grade n x n) com as 4 vizinhas. */
    static int[] edgeOf(int[] c, int n) {
        int[] e = new int[n * n];
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
            int p = c[y * n + x], m = 0;
            if (x > 0) m = Math.max(m, diff(p, c[y * n + x - 1]));
            if (x < n - 1) m = Math.max(m, diff(p, c[y * n + x + 1]));
            if (y > 0) m = Math.max(m, diff(p, c[(y - 1) * n + x]));
            if (y < n - 1) m = Math.max(m, diff(p, c[(y + 1) * n + x]));
            e[y * n + x] = m;
        }
        return e;
    }

    /** Reduz a grade n x n pela metade (media 2 x 2 ponderada pelo alpha). */
    static int[] half(int[] c, int n) {
        int m = n / 2;
        int[] o = new int[m * m];
        for (int y = 0; y < m; y++) for (int x = 0; x < m; x++) {
            long a = 0, r = 0, g = 0, b = 0;
            for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
                int p = c[(2 * y + j) * n + 2 * x + i], pa = p >>> 24;
                a += pa; r += (long) pa * ((p >> 16) & 255); g += (long) pa * ((p >> 8) & 255); b += (long) pa * (p & 255);
            }
            if (a == 0) continue;
            o[y * m + x] = ((int) (a / 4) << 24) | ((int) (r / a) << 16) | ((int) (g / a) << 8) | (int) (b / a);
        }
        return o;
    }

    /** Preenche a piramide (32, 16, 8) e as bordas de cada nivel a partir das celulas 32 x 32. */
    static void pyramid(int[][] cells, int[][] edges, int[] c32) {
        cells[0] = c32;
        cells[1] = half(cells[0], N);
        cells[2] = half(cells[1], N / 2);
        for (int l = 0; l < 3; l++) edges[l] = edgeOf(cells[l], N >> l);
    }

    /** Nivel da piramide para comparar duas sprites: a grade nao deve ser mais fina que os pixels da menor (tamanho fisico do recorte justo, menor lado). */
    static int level(Sig r, Sig k) {
        int eff = Math.min(Math.min(r.tpw, r.tph), Math.min(k.tpw, k.tph));
        return eff >= 20 ? 0 : eff >= 10 ? 1 : 2;
    }

    /** Tolerancia de uma celula: TOL no liso; na borda (contraste alto) cresce, porque a posicao exata da borda muda ao reamostrar. */
    private static int tolFor(int edge) { return TOL + Math.min(EDGE_MAX, (int) (EDGE_K * edge)); }

    /**
     * Nota 0..100 de R contra K (celulas 32 x 32) com a relacao {@code g} (0..7). A celula tambem conta como igual se uma das 4 vizinhas da mapeada em K bate
     * (tolera erro de arredondamento e suavizacao de ate 1 celula). {@code minPct} > 0 permite desistir cedo (devolve -1 se nao dara a nota).
     */
    static int cellScore(int[] rc, int[] re, int[] kc, int[] ke, int lvl, int g, int minPct, int allowedBudget) {
        int[] map = MAP[lvl][g];
        int n = N >> lvl;
        int same = 0, used = 0, diff = 0;
        for (int i = 0; i < n * n; i++) {
            int p = rc[i], j = map[i], q = kc[j];
            if ((p >>> 24) == 0 && (q >>> 24) == 0) continue;
            used++;
            int tol = tolFor(Math.max(re[i], ke[j]));
            boolean ok = diff(p, q) <= tol;
            if (!ok) {
                int kx = j % n, ky = j / n;
                ok = (kx > 0 && diff(p, kc[j - 1]) <= tol) || (kx < n - 1 && diff(p, kc[j + 1]) <= tol) || (ky > 0 && diff(p, kc[j - n]) <= tol) || (ky < n - 1 && diff(p, kc[j + n]) <= tol);
            }
            if (ok) same++; else if (++diff > allowedBudget && minPct > 0) return -1;
        }
        if (used == 0) return 0;
        return (int) Math.floor(100.0 * same / used);
    }

    /** Quantas celulas contam (alguma das duas tem coisa) com a relacao g no nivel dado. */
    static int usedCells(int[] rc, int[] kc, int lvl, int g) {
        int[] map = MAP[lvl][g];
        int used = 0;
        for (int i = 0; i < rc.length; i++) if ((rc[i] >>> 24) != 0 || (kc[map[i]] >>> 24) != 0) used++;
        return used;
    }

    /** Variacao total (0..1) entre dois histogramas de cor. */
    static double histTv(float[] a, float[] b) {
        double s = 0;
        for (int i = 0; i < a.length; i++) s += Math.abs(a[i] - b[i]);
        return s / 2;
    }

    static final class Match {
        int score;       // 0..100 (100 = identico no conteudo exato)
        int g;           // relacao R(u, v) = K(g(u, v)); -1 = geral (angulo qualquer), ver gen
        double[] gen;    // mapa afim {a, b, c, d, e, f} do retangulo logico de R para o de K (null = usa SpriteXform.G[g] no retangulo inteiro)
        double sx = 1, sy = 1; // pixels de K por pixel de R em cada eixo da imagem de R (zoom que K precisa para desenhar R = 1 / s)
        double up = 100; // zoom (%) que K precisa para desenhar R no maior eixo (> 100 = K e menor que R: perde qualidade)
        boolean approx;  // angulo qualquer: casamento aproximado
        double rotDeg;   // angulo (so angulo qualquer)
        boolean mirror;  // espelhada (so angulo qualquer)
        boolean verified;                 // conferido em pixels (SpriteVerify)
        double iou, color, detail, palette;   // 0..100: forma (silhueta), cor, detalhes, paleta
        Match(int score, int g) { this.score = score; this.g = g; }
        /** Mapa para o SpriteXform. */
        double[] map() { return gen != null ? gen : SpriteXform.G[Math.max(0, g)]; }
    }

    /** Mapa afim (retangulo de R -> retangulo de K) de {@code g} aplicado entre os recortes justos. */
    static double[] general(Sig r, Sig k, int g) {
        double rwx = r.tx1 - r.tx0, rwy = r.ty1 - r.ty0, kwx = k.tx1 - k.tx0, kwy = k.ty1 - k.ty0;
        double[] gg = SpriteXform.G[g];
        double[][] pt = {{0, 0}, {1, 0}, {0, 1}};
        double[][] out = new double[3][2];
        for (int i = 0; i < 3; i++) {
            double u = (pt[i][0] - r.tx0) / rwx, v = (pt[i][1] - r.ty0) / rwy;
            double ka = gg[0] * u + gg[1] * v + gg[4], kb = gg[2] * u + gg[3] * v + gg[5];
            out[i][0] = k.tx0 + ka * kwx; out[i][1] = k.ty0 + kb * kwy;
        }
        return new double[]{out[1][0] - out[0][0], out[2][0] - out[0][0], out[1][1] - out[0][1], out[2][1] - out[0][1], out[0][0], out[0][1]};
    }

    /** Melhor relacao de R com K entre as 8; null se nenhuma passa de {@code minPct}. Sem exigir proporcao (so limites de sanidade de escala/achatamento). */
    static Match best(Sig r, Sig k, int minPct) { return scan(r, k, minPct, true); }

    /**
     * Como {@link #best}, mas sem os limites de sanidade: serve para ordenar/filtrar qualquer sprite por semelhanca com R
     * (a nota e a das celulas, esticadas se a proporcao for outra). Nunca devolve null; 0 se nao ha nada em comum.
     */
    static Match bestAny(Sig r, Sig k) {
        Match m = scan(r, k, 0, false);
        return m != null ? m : new Match(0, 0);
    }

    /** Nota (0..100) de cada sprite de {@code all} contra {@code ref} (a propria ref fica de fora). */
    static java.util.Map<Integer, Integer> scores(Sig ref, java.util.Collection<Sig> all) {
        java.util.Map<Integer, Integer> out = new java.util.HashMap<Integer, Integer>();
        for (Sig k : all) {
            if (k.index == ref.index) continue;
            out.put(Integer.valueOf(k.index), Integer.valueOf(bestAny(ref, k).score));
        }
        return out;
    }

    private static Match scan(Sig r, Sig k, int minPct, boolean limits) {
        if (r.empty || k.empty) return null;
        Match best = null;
        double rw = r.tightW(), rh = r.tightH(), kw = k.tightW(), kh = k.tightH();
        int lv = level(r, k);
        if (limits && minPct > 0) {         // triagem barata: cores muito diferentes ou preenchimento muito diferente nao chegam a nota
            if (histTv(r.hist, k.hist) > 0.35 + (100 - minPct) / 100.0 * 0.5) return null;
            if (Math.abs(r.nonEmpty - k.nonEmpty) > (0.2 + (100 - minPct) / 100.0) * Math.max(r.nonEmpty, k.nonEmpty)) return null;
        }
        int budget = 0;
        for (int g = 0; g < 8; g++) {
            boolean sw = SpriteXform.swapsAxes(g);
            double sx = (sw ? kh : kw) / rw, sy = (sw ? kw : kh) / rh;          // pixels de K por pixel de R
            if (limits) {
                if (sx < MIN_SCALE || sy < MIN_SCALE || sx > MAX_SCALE || sy > MAX_SCALE) continue;
                if (Math.max(sx / sy, sy / sx) > MAX_STRETCH) continue;
            }
            if (minPct > 0) budget = (int) Math.floor((100 - minPct) / 100.0 * usedCells(r.cells[lv], k.cells[lv], lv, g));
            int sc = cellScore(r.cells[lv], r.edges[lv], k.cells[lv], k.edges[lv], lv, g, minPct, budget);
            if (sc < 0) continue;
            sc = Math.min(99, sc);
            if (g == 0 && r.hash == k.hash && r.w == k.w && r.h == k.h) sc = 100;
            if (sc >= minPct && (best == null || sc > best.score)) {
                best = new Match(sc, g);
                best.sx = sx; best.sy = sy;
                best.up = 100 * Math.max(1 / sx, 1 / sy);
                best.gen = general(r, k, g);
            }
        }
        return best;
    }

    /** Casamentos por angulo qualquer (calculados uma vez por {@link SpriteRotSearch}): par (R, K) -> relacao. */
    static final class Matcher {
        final java.util.Map<Long, Match> rot = new java.util.HashMap<Long, Match>();
        boolean complete = true;      // false = a busca por angulo parou antes de olhar todas (tempo ou cancelada)
        static long key(int r, int k) { return ((long) r << 32) | (k & 0xffffffffL); }
        Match match(Sig r, Sig k, int minPct) {
            Match m = best(r, k, minPct);
            Match q = rot.get(Long.valueOf(key(r.index, k.index)));
            if (q != null && q.score >= minPct && (m == null || q.score > m.score)) m = q;
            return m;
        }
    }

    static final Matcher NONE = new Matcher();

    static final class Member {
        int index;       // sprite
        Match toRep;     // relacao desta sprite com a que fica (null na propria representante)
        int via = -1;    // sprite do grupo com a qual casou (cadeia), -1 = a representante
        int maxScore() { return toRep == null ? 100 : toRep.score; }
    }

    static final class Group {
        final List<Member> members = new ArrayList<Member>();      // [0] = representante (a de maior area)
        int rep() { return members.get(0).index; }
    }

    private static boolean better(Match a, Match b) {
        if (b == null) return true;
        boolean ua = a.up > 105, ub = b.up > 105;
        if (ua != ub) return !ua;
        return a.score > b.score;
    }

    static List<Group> groups(List<Sig> sigs, int minPct) { return groups(sigs, minPct, NONE); }

    /** Agrupamento so por celulas (sem conferencia em pixels, com cadeia): o caminho antigo, usado pelos testes. O app usa {@link DedupAnalysis}. */
    static List<Group> groups(List<Sig> sigs, int minPct, Matcher mx) {
        return DedupAnalysis.coarse(sigs, mx, minPct).groups(sigs, minPct, DedupOptions.legacy());
    }

    // ---- aplicar ----

    /** Uma sprite a remover e a que a substitui, com a relacao entre elas. */
    static final class Choice {
        Sig removed, kept;
        Match match;
    }

    /** Entre as sprites que ficam, a que melhor substitui {@code r}; null se nenhuma casa. */
    static Choice choose(Sig r, List<Sig> kept, int minPct) { return choose(r, kept, minPct, NONE); }

    /** Prefere quem nao precisa ampliar (zoom <= 105 %), depois a nota. */
    static Choice choose(Sig r, List<Sig> kept, int minPct, Matcher mx) {
        Choice c = null;
        for (Sig k : kept) {
            if (k.index == r.index || k.empty) continue;
            Match m = mx.match(r, k, minPct);
            if (m != null && (c == null || better(m, c.match))) { c = new Choice(); c.removed = r; c.kept = k; c.match = m; }
        }
        return c;
    }

    /** ANOs usadas como link (filhas) de outra: o deslocamento do link tambem espelha, entao nelas nao se troca Flip. */
    static java.util.Set<Integer> linkChildren(Dac dac) {
        java.util.HashSet<Integer> r = new java.util.HashSet<Integer>();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present || a.links == null) continue;
            for (Ano.Link l : a.links) r.add(Integer.valueOf(l.getAno()));
        }
        return r;
    }

    static final class Result {
        final java.util.TreeSet<Integer> removedSprites = new java.util.TreeSet<Integer>();
        final java.util.TreeSet<Integer> changedAnos = new java.util.TreeSet<Integer>();
        final List<Integer> skipped = new ArrayList<Integer>();       // sprites que ficaram porque um frame nao tem solucao
        int framesRewritten;
    }

    /**
     * Reescreve no DAC os frames das sprites removidas para usarem as que ficam (Flip, zoom, rotacao e posicao ajustados). Uma sprite so e removida se
     * TODOS os frames dela tem solucao; senao ela fica e nada dela muda. Quem chama exclui as removidas com {@link SpriteLib#removeShift} e
     * {@link SpriteRenumber#remapDac}.
     */
    static Result apply(Dac dac, List<Choice> choices) {
        Result res = new Result();
        java.util.Set<Integer> kids = linkChildren(dac);
        for (Choice c : choices) {
            java.util.ArrayList<Object[]> plan = new java.util.ArrayList<Object[]>();       // {ano, indice do mpt, mpt novo}
            boolean ok = true;
            for (int i = 0; i < dac.size() && ok; i++) {
                Ano a = dac.getAno(i);
                if (a == null || !a.present) continue;
                for (int m = 0; m < a.mpts.length && ok; m++) {
                    if (a.mpts[m].image != c.removed.index) continue;
                    Ano.Mpt n = SpriteXform.rewrite(a.mpts[m], c.removed.w, c.removed.h, c.kept.w, c.kept.h, c.match.map(), c.kept.index, !kids.contains(Integer.valueOf(i)));
                    if (n == null) ok = false; else plan.add(new Object[]{Integer.valueOf(i), Integer.valueOf(m), n});
                }
            }
            if (!ok) { res.skipped.add(Integer.valueOf(c.removed.index)); continue; }
            for (Object[] p : plan) {
                int ano = ((Integer) p[0]).intValue(), m = ((Integer) p[1]).intValue();
                dac.getAno(ano).mpts[m] = (Ano.Mpt) p[2];
                res.changedAnos.add((Integer) p[0]);
                res.framesRewritten++;
            }
            res.removedSprites.add(Integer.valueOf(c.removed.index));
        }
        return res;
    }
}
