package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

/**
 * Padrao visual de cada sprite (zoom X/Y, rotacao, alpha, centro MID e flips) para quando ela e posta num Frame pela timeline, e as contas que
 * somam ajustes a um Frame. Nao muda Frames existentes por conta propria. Java puro; o arquivo fica em TBRE/utils/charNN (nao e do personagem).
 *
 * Composicao, componente a componente: rotacao, alpha e MID SOMAM; zoom MULTIPLICA; flip e OU-EXCLUSIVO.
 */
final class SpriteDefaults {
    static final String FILE = "padroes_sprites.txt";

    /** Valores visuais de um Frame / de um padrao. Neutro: 100/100/0/0/0/0/sem flip. */
    static final class Def {
        int zx = 100, zy = 100, rot, alpha, midX, midY;
        boolean flipH, flipV;

        Def copy() { Def d = new Def(); d.zx = zx; d.zy = zy; d.rot = rot; d.alpha = alpha; d.midX = midX; d.midY = midY; d.flipH = flipH; d.flipV = flipV; return d; }
        boolean isNeutral() { return zx == 100 && zy == 100 && rot == 0 && alpha == 0 && midX == 0 && midY == 0 && !flipH && !flipV; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof Def)) return false;
            Def d = (Def) o;
            return zx == d.zx && zy == d.zy && rot == d.rot && alpha == d.alpha && midX == d.midX && midY == d.midY && flipH == d.flipH && flipV == d.flipV;
        }
        @Override public int hashCode() { return ((zx * 31 + zy) * 31 + rot) * 31 + alpha + midX * 7 + midY * 13 + (flipH ? 1 : 0) + (flipV ? 2 : 0); }
        @Override public String toString() { return zx + "x" + zy + "% rot " + rot + " alpha " + alpha + " mid " + midX + "," + midY + (flipH ? " flipH" : "") + (flipV ? " flipV" : ""); }
    }

    private SpriteDefaults() { }

    // ---- contas ----

    private static int mulPct(int a, int b) { return (int) Math.round(a * (double) b / 100.0); }

    /** {@code base} + {@code delta}: rot/alpha/MID somam, zoom multiplica, flip XOR. */
    static Def add(Def base, Def delta) {
        Def r = new Def();
        r.zx = mulPct(base.zx, delta.zx); r.zy = mulPct(base.zy, delta.zy);
        r.rot = base.rot + delta.rot; r.alpha = base.alpha + delta.alpha;
        r.midX = base.midX + delta.midX; r.midY = base.midY + delta.midY;
        r.flipH = base.flipH ^ delta.flipH; r.flipV = base.flipV ^ delta.flipV;
        return r;
    }

    /** O que falta de {@code from} para {@code to} (o inverso de {@link #add}): {@code add(from, diff(from, to))} = {@code to}. */
    static Def diff(Def from, Def to) {
        Def r = new Def();
        r.zx = from.zx == 0 ? to.zx : (int) Math.round(to.zx * 100.0 / from.zx);
        r.zy = from.zy == 0 ? to.zy : (int) Math.round(to.zy * 100.0 / from.zy);
        r.rot = to.rot - from.rot; r.alpha = to.alpha - from.alpha;
        r.midX = to.midX - from.midX; r.midY = to.midY - from.midY;
        r.flipH = from.flipH ^ to.flipH; r.flipV = from.flipV ^ to.flipV;
        return r;
    }

    // ---- Frame <-> Def ----

    /** Os valores visuais do Frame. */
    static Def read(Ano.Mpt m) {
        Def d = new Def();
        if ((m.flags & 0x80) != 0) { d.rot = m.rot; d.alpha = m.alphaRaw; d.zx = m.xZoom; d.zy = m.yZoom; }
        if ((m.flags & 1) != 0) { d.midX = m.midX; d.midY = m.midY; }
        if ((m.flags & 2) != 0) { d.flipH = (m.wActFlag & ObjModel.FLIP_H) != 0; d.flipV = (m.wActFlag & ObjModel.FLIP_V) != 0; }
        return d;
    }

    /** Copia do Frame com os valores visuais de {@code d} (neutro = o campo some e a flag desliga). */
    static Ano.Mpt write(Ano.Mpt src, Def d) {
        Ano.Mpt m = src.copy();
        if (d.rot == 0 && d.alpha == 0 && d.zx == 100 && d.zy == 100) { m.flags &= ~0x80; m.rot = 0; m.alphaRaw = 0; m.xZoom = 100; m.yZoom = 100; }
        else { m.flags |= 0x80; m.rot = d.rot; m.alphaRaw = d.alpha; m.xZoom = d.zx; m.yZoom = d.zy; }
        if (d.midX == 0 && d.midY == 0) { m.flags &= ~1; m.midX = 0; m.midY = 0; }
        else { m.flags |= 1; m.midX = d.midX; m.midY = d.midY; }
        int w = (m.flags & 2) != 0 ? m.wActFlag : 0;
        w = d.flipH ? (w | ObjModel.FLIP_H) : (w & ~ObjModel.FLIP_H);
        w = d.flipV ? (w | ObjModel.FLIP_V) : (w & ~ObjModel.FLIP_V);
        m.wActFlag = w;
        if (w != 0) m.flags |= 2; else m.flags &= ~2;
        m.normalize();
        return m;
    }

    /** O alpha so soma quando nenhum dos dois esta num modo especial (>= 256: aditivo etc.); nesses o do Frame fica. */
    private static boolean alphaAddable(int a) { return a >= 0 && a < 256; }

    /** Frame + {@code delta} (a soma de um ajuste). */
    static Ano.Mpt addTo(Ano.Mpt m, Def delta) {
        Def cur = read(m), r = add(cur, delta);
        if (!alphaAddable(cur.alpha) || !alphaAddable(r.alpha)) r.alpha = cur.alpha;
        r.alpha = Math.max(0, r.alpha);
        return write(m, r);
    }

    /** Troca a imagem do Frame de {@code oldImg} para {@code newImg}: tira o padrao da antiga e poe o da nova (relativo ao que o Frame ja tem). */
    static Ano.Mpt changeImage(Store st, Ano.Mpt m, int oldImg, int newImg) {
        Ano.Mpt c = m.copy();
        c.image = newImg;
        if (st == null || oldImg == newImg) return c;
        Def o = st.get(oldImg), n = st.get(newImg);
        if (o.equals(n)) return c;
        return addTo(c, diff(o, n));
    }

    /**
     * Todo Frame do DAC que usa {@code from} passa a usar {@code to} com o ajuste {@code adj} somado ao que ele ja tem (igualar sprites). {@code from == to}
     * so soma o ajuste. Devolve as ANOs alteradas; {@code count[0]} = quantos Frames.
     */
    static java.util.TreeSet<Integer> retarget(Dac dac, int from, int to, Def adj, int[] count) {
        java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>();
        if (count != null && count.length > 0) count[0] = 0;
        if (dac == null || from < 0 || to < 0) return changed;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            Ano.Mpt[] out = a.mpts.clone();
            boolean any = false;
            for (int k = 0; k < out.length; k++) {
                if (out[k].image != from) continue;
                Ano.Mpt m = addTo(out[k], adj);
                m.image = to;
                out[k] = m;
                any = true;
                if (count != null && count.length > 0) count[0]++;
            }
            if (any) { dac.setAno(i, new Ano(i, true, a.flags, a.priority, a.links, out)); changed.add(Integer.valueOf(i)); }
        }
        return changed;
    }

    /** Como {@link #changeImage}, mas muda o proprio Frame {@code n} (edicao em sessao): imagem e campos visuais. */
    static void changeImageInPlace(Store st, Ano.Mpt n, int newImg) {
        Ano.Mpt r = changeImage(st, n, n.image, newImg);
        n.image = r.image;
        n.flags = (n.flags & ~(1 | 2 | 0x80)) | (r.flags & (1 | 2 | 0x80));
        n.midX = r.midX; n.midY = r.midY; n.wActFlag = r.wActFlag;
        n.rot = r.rot; n.alphaRaw = r.alphaRaw; n.alpha = r.alpha; n.xZoom = r.xZoom; n.yZoom = r.yZoom; n.razFlags = r.razFlags;
        n.normalize();
    }

    // ---- arquivo / mapa de padroes ----

    /** Padroes por sprite (so as que tem padrao diferente do neutro). */
    static final class Store {
        final TreeMap<Integer, Def> map = new TreeMap<Integer, Def>();
        private File file;
        boolean dirty;

        /** Padrao da sprite (neutro se nao ha). Devolve copia. */
        Def get(int sprite) { Def d = map.get(Integer.valueOf(sprite)); return d == null ? new Def() : d.copy(); }
        boolean has(int sprite) { return map.containsKey(Integer.valueOf(sprite)); }

        void set(int sprite, Def d) {
            if (sprite < 0) return;
            if (d == null || d.isNeutral()) { if (map.remove(Integer.valueOf(sprite)) != null) dirty = true; return; }
            Def old = map.get(Integer.valueOf(sprite));
            if (old != null && old.equals(d)) return;
            map.put(Integer.valueOf(sprite), d.copy());
            dirty = true;
        }

        /** Acompanha a renumeracao ({@code map[antigo] = novo}, -1 = removida). Devolve se algo mudou. */
        boolean remap(int[] m) {
            if (m == null || map.isEmpty()) return false;
            TreeMap<Integer, Def> out = new TreeMap<Integer, Def>();
            boolean changed = false;
            for (Map.Entry<Integer, Def> e : map.entrySet()) {
                int k = e.getKey().intValue();
                int nv = k >= 0 && k < m.length ? m[k] : k;
                if (nv != k) changed = true;
                if (nv >= 0) out.put(Integer.valueOf(nv), e.getValue());
                else changed = true;
            }
            if (!changed) return false;
            map.clear();
            map.putAll(out);
            dirty = true;
            return true;
        }

        String format() {
            StringBuilder sb = new StringBuilder("# padrao visual por sprite: SPR_n zoomX zoomY rotacao alpha midX midY flipH flipV (vale ao pôr a sprite num Frame pela timeline)\n");
            for (Map.Entry<Integer, Def> e : map.entrySet()) {
                Def d = e.getValue();
                sb.append("SPR_").append(e.getKey()).append(' ').append(d.zx).append(' ').append(d.zy).append(' ').append(d.rot).append(' ').append(d.alpha)
                        .append(' ').append(d.midX).append(' ').append(d.midY).append(' ').append(d.flipH ? 1 : 0).append(' ').append(d.flipV ? 1 : 0).append('\n');
            }
            return sb.toString();
        }

        /** Le o texto; linhas invalidas sao ignoradas. */
        void parse(String text) {
            map.clear();
            if (text == null) return;
            for (String line : text.split("\\r?\\n")) {
                line = line.trim();
                if (!line.startsWith("SPR_")) continue;
                String[] p = line.substring(4).split("\\s+");
                if (p.length < 9) continue;
                try {
                    Def d = new Def();
                    int k = Integer.parseInt(p[0]);
                    d.zx = Integer.parseInt(p[1]); d.zy = Integer.parseInt(p[2]); d.rot = Integer.parseInt(p[3]); d.alpha = Integer.parseInt(p[4]);
                    d.midX = Integer.parseInt(p[5]); d.midY = Integer.parseInt(p[6]); d.flipH = !p[7].equals("0"); d.flipV = !p[8].equals("0");
                    if (k >= 0 && !d.isNeutral()) map.put(Integer.valueOf(k), d);
                } catch (NumberFormatException ignored) { /* linha ruim: ignora */ }
            }
        }

        /** Arquivo em TBRE/utils/charNN (le se existir). */
        static Store load(File charDir) {
            Store s = new Store();
            File f = new File(Saver.utilsPath(charDir), FILE);
            s.file = f;
            if (charDir == null || !f.isFile()) return s;
            try { s.parse(new String(GameData.readAll(f), "UTF-8")); } catch (Exception e) { s.map.clear(); }
            return s;
        }

        /** Grava se mudou (vazio apaga o arquivo). */
        void save(File charDir) throws IOException {
            if (!dirty && file != null) return;
            File f = new File(Saver.utilsPath(charDir), FILE);
            if (map.isEmpty()) { if (f.exists()) f.delete(); dirty = false; return; }
            Saver.utilsDir(charDir);
            SpriteLib.writeAtomic(f, format().getBytes("UTF-8"), Saver.tmpDir(charDir));
            dirty = false;
        }
    }
}
