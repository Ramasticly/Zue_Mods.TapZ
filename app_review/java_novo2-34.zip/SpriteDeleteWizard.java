package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Excluir sprites em etapas: UMA tela de decisao por sprite marcada (SPR_N, previa, "O que excluir?": usar outra sprite no lugar / sprite e Frames / sprite e Frames
 * sem imagem, mais "Alinhar MID/RAZ"), uma tela de explicacao para cada escolha e, no fim, um resumo e uma unica aplicacao com os indices antigos
 * ({@link SpriteMass#applyDecisions}) seguida da renumeracao. Nada e alterado antes do APLICAR final: cancelar em qualquer tela deixa tudo como estava.
 */
final class SpriteDeleteWizard {
    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, WARN = 0xFFFFB454;

    private final Activity a;
    private final CharAssets ca;
    private final SpriteLib lib;
    private final Runnable applied;
    private final List<Integer> order;
    private final Set<Integer> all;
    private final Map<Integer, SpriteMass.Decision> dec = new HashMap<Integer, SpriteMass.Decision>();
    private Map<Integer, SpriteDedup.Sig> sigs;

    private SpriteDeleteWizard(Activity a, CharAssets ca, SpriteLib lib, List<Integer> sprites, Runnable applied) {
        this.a = a; this.ca = ca; this.lib = lib; this.applied = applied;
        this.order = new ArrayList<Integer>(new HashSet<Integer>(sprites));
        Collections.sort(order);
        this.all = new HashSet<Integer>(order);
    }

    static void start(Activity a, CharAssets ca, SpriteLib lib, List<Integer> sprites, Runnable applied) {
        if (sprites == null || sprites.isEmpty()) return;
        new SpriteDeleteWizard(a, ca, lib, sprites, applied).decide(0, 1);
    }

    private int dp(int v) { return SpriteListScreen.dp(a, v); }

    private SpriteMass.Usage usage(int sprite) {
        Set<Integer> one = new HashSet<Integer>();
        one.add(Integer.valueOf(sprite));
        return SpriteMass.usage(ca.dac, ca.data, one);
    }

    /** Tela cheia no estilo das outras (fundo escuro, rolagem no meio, rodape com dois botoes). {@code dismissOnNext} false = a tela fica aberta por baixo de outra. */
    private Dialog screen(String title, View content, String backLabel, final Runnable back, String nextLabel, final Runnable next, final boolean dismissOnNext) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, title, 16, TEXT, true);
        ti.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(ti);
        ScrollView sv = new ScrollView(a);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setPadding(dp(12), dp(8), dp(12), dp(12));
        final boolean[] done = {false};
        TextView b1 = SpriteListScreen.button(a, backLabel, new View.OnClickListener() { @Override public void onClick(View v) { done[0] = true; d.dismiss(); if (back != null) back.run(); } });
        TextView b2 = SpriteListScreen.button(a, nextLabel, new View.OnClickListener() { @Override public void onClick(View v) {
            if (dismissOnNext) { done[0] = true; d.dismiss(); }
            next.run();
        } });
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f), l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.leftMargin = dp(8);
        foot.addView(b1, l1);
        foot.addView(b2, l2);
        root.addView(foot);
        d.setCancelable(true);
        d.setOnCancelListener(new DialogInterface.OnCancelListener() { @Override public void onCancel(DialogInterface x) { done[0] = true; if (back != null) back.run(); } });
        d.show();
        return d;
    }

    private LinearLayout column() {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(4), dp(14), dp(8));
        return c;
    }

    // ------------------------------------------------------------------ decisao por sprite

    /** {@code dir}: 1 = indo para a proxima, -1 = voltando (sprites sem uso nao pedem decisao e sao puladas na direcao em que se anda). */
    private void decide(final int at, final int dir) {
        if (at < 0) return;                                           // voltou do primeiro: cancela tudo
        if (at >= order.size()) { summary(); return; }
        final int sprite = order.get(at).intValue();
        final SpriteMass.Usage u = usage(sprite);
        if (u.frames == 0) {                                          // nenhum Frame usa: so sai da lista
            SpriteMass.Decision d0 = new SpriteMass.Decision();
            d0.sprite = sprite; d0.mode = SpriteMass.Decision.BLANK;
            dec.put(Integer.valueOf(sprite), d0);
            decide(at + dir, dir);
            return;
        }
        SpriteMass.Decision prev = dec.get(Integer.valueOf(sprite));
        final int[] choice = {prev != null && prev.mode == SpriteMass.Decision.FRAMES ? 1 : prev != null && prev.mode == SpriteMass.Decision.BLANK && prev.replacement == -2 ? 2 : 0};
        final boolean[] align = {prev != null && prev.align};
        LinearLayout col = column();
        Cnv.Entry e = ca.cnv.byImage(sprite);
        TextView sub = SpriteListScreen.text(a, "SPR_" + sprite + (e == null ? "" : "   " + e.width + "x" + e.height) + "   (" + (at + 1) + " de " + order.size() + ")", 13, DIM, false);
        col.addView(sub);
        ThumbView tv = new ThumbView(a);
        tv.set(ca.sprites, sprite);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(220), dp(220));
        tp.gravity = Gravity.CENTER_HORIZONTAL;
        tp.setMargins(0, dp(6), 0, dp(6));
        col.addView(tv, tp);
        col.addView(SpriteListScreen.text(a, u.frames + " frame(s) em " + u.anos.size() + " ANO(s) usam esta sprite.", 13, TEXT, false));
        col.addView(SpriteListScreen.text(a, "O que excluir?", 15, TEXT, true));
        String[] names = {"Sprite, usar outra Sprite no lugar", "Sprite e Frames", "Sprite, Frames ficam sem imagem"};
        final CheckBox[] cb = new CheckBox[3];
        final CheckBox alignCb = new I18nCheckBox(a);
        for (int i = 0; i < 3; i++) {
            final int k = i;
            cb[i] = new I18nCheckBox(a);
            cb[i].setText(names[i]);
            cb[i].setTextColor(TEXT);
            cb[i].setChecked(i == choice[0]);
            col.addView(cb[i]);
        }
        alignCb.setText("Alinhar MID/RAZ");
        alignCb.setTextColor(TEXT);
        alignCb.setChecked(align[0] && choice[0] == 0);
        alignCb.setEnabled(choice[0] == 0);
        final android.widget.CompoundButton.OnCheckedChangeListener[] ls = new android.widget.CompoundButton.OnCheckedChangeListener[3];
        for (int i = 0; i < 3; i++) {
            final int k = i;
            ls[i] = new android.widget.CompoundButton.OnCheckedChangeListener() { @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                if (!on) { boolean any = false; for (CheckBox c : cb) any |= c.isChecked(); if (!any) cb[k].setChecked(true); return; }
                choice[0] = k;
                for (int j = 0; j < 3; j++) if (j != k && cb[j].isChecked()) { cb[j].setOnCheckedChangeListener(null); cb[j].setChecked(false); cb[j].setOnCheckedChangeListener(ls[j]); }
                alignCb.setEnabled(k == 0);
                if (k != 0) alignCb.setChecked(false);
            } };
            cb[i].setOnCheckedChangeListener(ls[i]);
        }
        col.addView(alignCb, new LinearLayout.LayoutParams(-1, -2));
        col.addView(SpriteListScreen.text(a, "Alinhar MID/RAZ edita os dados dos Frames (centro MID, rotação, zoom e flips RAZ) para a nova sprite ficar o mais parecida possível com a antiga, com a mesma lógica de \"Remover Sprites repetidas\". Só vale em \"usar outra Sprite no lugar\".", 11, DIM, false));
        screen("Remover SPR_" + sprite, col, "VOLTAR", new Runnable() { public void run() { if (at == 0) return; decide(at - 1, -1); } },
                "CONTINUAR", new Runnable() { public void run() { explain(at, sprite, u, choice[0], alignCb.isChecked()); } }, true);
    }

    // ------------------------------------------------------------------ explicacao de cada escolha

    private void explain(final int at, final int sprite, SpriteMass.Usage u, final int choice, final boolean align) {
        LinearLayout col = column();
        String title;
        if (choice == 0) {
            title = "Usar outra Sprite no lugar";
            col.addView(SpriteListScreen.text(a, "Você vai escolher, entre as Sprites do personagem, uma para tomar o lugar da SPR_" + sprite + " nos Frames em que ela aparecia (" + u.frames + " frame(s) em " + u.anos.size()
                    + " ANO(s)). Só o IMG do Frame troca; depois a SPR_" + sprite + " sai da lista e as seguintes são renumeradas (a escolhida acompanha a nova numeração).", 13, TEXT, false));
            col.addView(SpriteListScreen.text(a, "A tela seguinte mostra todas as Sprites; a barra \"Semelhança mínima\" no topo vai filtrando as parecidas (até 90%, só as quase idênticas).", 13, DIM, false));
            if (align) col.addView(SpriteListScreen.text(a, "Alinhar MID/RAZ está ligado: o MID (centro), a rotação, o zoom e os flips dos Frames são recalculados para a nova Sprite ocupar o lugar da antiga (se as proporções forem diferentes, ela é esticada). As caixas de hitbox e hurtbox dos Frames não são ajustadas.", 13, WARN, false));
        } else if (choice == 1) {
            title = "Sprite e Frames";
            col.addView(SpriteListScreen.text(a, "Vai tirar a SPR_" + sprite + " e também os " + u.frames + " Frame(s) que usavam ela (em " + u.anos.size() + " ANO(s): " + anosText(u) + "). Os Frames que sobram seguem em sequência; uma ANO que ficar sem nenhum Frame fica vazia.", 13, TEXT, false));
            StringBuilder w = new StringBuilder();
            if (u.hitOrProjectile || u.hurtbox) w.append("• há Frames com ").append(u.hitOrProjectile && u.hurtbox ? "hitbox, hurtbox ou lançamento de projétil" : u.hurtbox ? "hurtbox" : "hitbox ou lançamento de projétil").append(" entre os que serão excluídos\n");
            if (u.attackAno) w.append("• alguma ANO faz parte de um golpe do Bin (HDAT 4)\n");
            if (!u.fixedAnos.isEmpty()) w.append("• ANO(s) fixa(s) do jogo: ").append(join(u.fixedAnos)).append('\n');
            if (w.length() > 0) col.addView(SpriteListScreen.text(a, "Atenção: excluir esses Frames pode causar bugs no personagem (hitbox, hurtbox, projétil ou golpe deixam de existir ou mudam de Frame):\n" + w, 13, WARN, false));
        } else {
            title = "Sprite, Frames ficam sem imagem";
            col.addView(SpriteListScreen.text(a, "Vai deletar a SPR_" + sprite + " da lista e os " + u.frames + " Frame(s) que usavam ela ficam com IMG -1, que é o mesmo que sem imagem (o Frame continua existindo, com o tempo, as caixas e o resto). As Sprites seguintes são renumeradas.", 13, TEXT, false));
        }
        final Dialog[] ex = {null};
        ex[0] = screen(title, col, "VOLTAR", new Runnable() { public void run() { decide(at, 1); } },
                choice == 0 ? "ESCOLHER SPRITE…" : "CONTINUAR", new Runnable() { public void run() {
                    if (choice == 0) chooseReplacement(at, sprite, align, ex[0]);
                    else {
                        SpriteMass.Decision d = new SpriteMass.Decision();
                        d.sprite = sprite; d.mode = choice == 1 ? SpriteMass.Decision.FRAMES : SpriteMass.Decision.BLANK;
                        if (choice == 2) d.replacement = -2;           // marca a escolha de sem imagem para lembrar ao voltar
                        dec.put(Integer.valueOf(sprite), d);
                        decide(at + 1, 1);
                    }
                } }, choice != 0);
    }

    private static String anosText(SpriteMass.Usage u) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < u.anos.size() && i < 8; i++) b.append(i == 0 ? "" : ", ").append(u.anos.get(i));
        if (u.anos.size() > 8) b.append("…");
        return b.toString();
    }

    private static String join(List<String> l) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.size() && i < 6; i++) b.append(i == 0 ? "" : "; ").append(l.get(i));
        if (l.size() > 6) b.append("…");
        return b.toString();
    }

    // ------------------------------------------------------------------ escolher a substituta (com a barra de semelhanca)

    private void chooseReplacement(final int at, final int sprite, final boolean align, final Dialog explanation) {
        if (sigs == null) {
            SpriteSims.build(a, lib, new SpriteSims.Done() { @Override public void on(Map<Integer, SpriteDedup.Sig> s) { sigs = s; chooseReplacement(at, sprite, align, explanation); } });
            return;
        }
        SpriteMassDialogs.pickSprite(a, ca, lib, all, -1, sprite, sigs, new SpriteMassDialogs.Chosen() { @Override public void on(int r) {
            if (r < 0 || all.contains(Integer.valueOf(r)) || !lib.has(r)) { SpriteListScreen.toast(a, "Escolha outra Sprite (que exista e não esteja entre as excluídas)."); return; }
            SpriteMass.Decision d = new SpriteMass.Decision();
            d.sprite = sprite; d.mode = SpriteMass.Decision.REPLACE; d.replacement = r; d.align = align;
            if (align) { d.removed = sigs.get(Integer.valueOf(sprite)); d.kept = sigs.get(Integer.valueOf(r)); if (d.removed == null || d.kept == null) d.align = false; }
            dec.put(Integer.valueOf(sprite), d);
            if (explanation != null) explanation.dismiss();
            decide(at + 1, 1);
        } });
    }

    // ------------------------------------------------------------------ resumo e aplicacao

    private void summary() {
        StringBuilder b = new StringBuilder();
        for (Integer s : order) {
            SpriteMass.Decision d = dec.get(s);
            SpriteMass.Usage u = usage(s.intValue());
            b.append("• SPR_").append(s).append(": ");
            if (u.frames == 0) b.append("sai da lista (nenhum Frame usa)");
            else if (d == null) b.append("sem decisão");
            else if (d.mode == SpriteMass.Decision.REPLACE) b.append("os ").append(u.frames).append(" Frame(s) passam a usar a SPR_").append(d.replacement).append(d.align ? ", alinhando MID/RAZ" : "");
            else if (d.mode == SpriteMass.Decision.FRAMES) b.append("sai junto com os ").append(u.frames).append(" Frame(s)");
            else b.append("os ").append(u.frames).append(" Frame(s) ficam com IMG -1");
            b.append('\n');
        }
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover " + (order.size() == 1 ? "SPR_" + order.get(0) : order.size() + " sprites") + "?")
                .setMessage(b + "\nAs Sprites seguintes são renumeradas e as ANOs alteradas são gravadas no 000.dac.txt.")
                .setNegativeButton("VOLTAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { decide(order.size() - 1, -1); } })
                .setPositiveButton("REMOVER", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { apply(); } }).show();
    }

    private void apply() {
        List<SpriteMass.Decision> ds = new ArrayList<SpriteMass.Decision>();
        for (Integer s : order) {
            SpriteMass.Decision d = dec.get(s);
            if (d == null) { d = new SpriteMass.Decision(); d.sprite = s.intValue(); d.mode = SpriteMass.Decision.BLANK; }
            if (d.mode == SpriteMass.Decision.REPLACE && (d.replacement < 0 || all.contains(Integer.valueOf(d.replacement)) || !lib.has(d.replacement))) d.mode = SpriteMass.Decision.BLANK;
            ds.add(d);
        }
        SpriteMass.Applied ap = SpriteMass.applyDecisions(ca.dac, ds);
        int[] map = lib.removeShift(all);
        java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>(ap.changed);
        changed.addAll(SpriteRenumber.remapDac(ca.dac, map));
        String saved = SpriteMassDialogs.persist(ca, changed);
        applied.run();
        if (!changed.isEmpty()) new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("DAC gravado")
                .setMessage(SpriteMassDialogs.lastPersist).setPositiveButton("OK", null).show();
        StringBuilder m = new StringBuilder(order.size() == 1 ? "SPR_" + order.get(0) + " removida" : order.size() + " sprites removidas");
        if (ap.replaced > 0) m.append("; ").append(ap.replaced).append(" frame(s) trocaram de sprite").append(ap.aligned > 0 ? " (" + ap.aligned + " com MID/RAZ alinhado)" : "");
        if (ap.deleted > 0) m.append("; ").append(ap.deleted).append(" frame(s) excluído(s)").append(ap.linksRemoved > 0 ? "; " + ap.linksRemoved + " link(s) para ANO vazia removido(s)" : "");
        if (ap.blanked > 0) m.append("; ").append(ap.blanked).append(" frame(s) ficaram com imagem -1");
        if (!ap.alignFailed.isEmpty()) m.append("; sem solução de alinhamento em SPR_").append(ap.alignFailed).append(" (só o IMG trocou)");
        m.append(saved);
        SpriteListScreen.toast(a, m.toString());
    }
}
