package com.zue.attackeditor;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

/** Desenho de uma sprite do cache: so o RECORTE (o {@code bitmap} do cache e a folha PNG inteira; {@code src} diz qual parte e a sprite). */
final class SpriteDraw {
    private SpriteDraw() { }

    /**
     * Desenha o recorte de {@code s} transformado por {@code m} (matriz que leva as coordenadas da folha para a tela): recorta ao retangulo da sprite antes de
     * desenhar, para nada do resto da folha aparecer.
     */
    static void crop(Canvas c, SpriteCache.Sprite s, Matrix m, int alpha, Paint p) {
        if (s == null || s.bitmap == null || s.bitmap.isRecycled()) return;
        p.setAlpha(alpha);
        c.save();
        c.concat(m);
        c.clipRect(s.src);
        c.drawBitmap(s.bitmap, 0, 0, p);
        c.restore();
    }
}
