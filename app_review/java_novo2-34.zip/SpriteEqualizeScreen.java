package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Tela unica de "Editar Frames" e "Igualar sprites": previa da sprite com zoom X/Y, rotacao, alpha, centro (MID) e flips, e os campos que os mexem.
 * Modo normal: os campos SAO o padrao da sprite (vale para novas adicoes na timeline). Modo igualar ({@code relative}): a sprite original aparece por baixo,
 * esmaecida, e os campos sao o AJUSTE da nova em relacao a ela (somado ao que a original ja tem). Nada e gravado aqui: quem chama recebe os valores em APLICAR.
 */
final class SpriteEqualizeScreen {
    private static final int BG = 0xFF14171C, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF2E9E4F, BAD = 0xFFC0392B;

    interface Listener { void apply(SpriteDefaults.Def fields); }

    static final class Cfg {
        String title, hint, applyLabel = "APLICAR";
        SpriteCache.Sprite main;
        SpriteCache.Sprite ghost;                      // original por baixo (modo igualar)
        SpriteDefaults.Def ghostDef = new SpriteDefaults.Def();
        SpriteDefaults.Def start = new SpriteDefaults.Def();      // valores iniciais dos campos
        boolean relative;
        String extraLabel;                             // botao extra (ex.: ajustar caixas uma imagem por vez)
        Runnable extra;
        Listener on;
    }

    private SpriteEqualizeScreen() { }

    /** Quadro do jogo (SpriteXform) para os valores do padrao. */
    static SpriteXform.Frame frame(SpriteDefaults.Def d) {
        SpriteXform.Frame f = new SpriteXform.Frame();
        f.flipH = d.flipH; f.flipV = d.flipV; f.ox = d.midX; f.oy = d.midY; f.rot = d.rot; f.zx = d.zx; f.zy = d.zy;
        return f;
    }

    /** Onde caem 3 cantos da sprite ((0,0), (1,0), (0,1)) no sistema do jogo (origem na ancora): x0,y0,x1,y1,x2,y2. */
    static double[] corners(SpriteDefaults.Def d, int lw, int lh) {
        SpriteXform.Frame f = frame(d);
        double[] p0 = SpriteXform.place(f, lw, lh, 0, 0), p1 = SpriteXform.place(f, lw, lh, 1, 0), p2 = SpriteXform.place(f, lw, lh, 0, 1);
        return new double[]{p0[0], p0[1], p1[0], p1[1], p2[0], p2[1]};
    }

    /** Ancora da previa (igual a da previa principal, AttackView.recenter): centro na largura e 55% da altura, abaixo do corpo real. */
    static float anchorX(float w) { return w * 0.5f; }
    static float anchorY(float h) { return h * 0.55f; }
    /** Escala 1:1 da previa principal: uma unidade logica = {@code density} pixels (1 dp). */
    static float baseScale(float density) { return Math.max(1f, density); }

    /** Previa: xadrez escuro, cruz na ancora, a original esmaecida (se ha) e a sprite com os valores. */
    private static final class Preview extends View {
        SpriteCache.Sprite main, ghost;
        SpriteDefaults.Def mainDef = new SpriteDefaults.Def(), ghostDef = new SpriteDefaults.Def();
        boolean showGhost = true;
        float zoom = 1f;
        final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG), line = new Paint(), tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Matrix mx = new Matrix();

        Preview(Activity a) {
            super(a);
            line.setColor(0x55FFFFFF);
            line.setStrokeWidth(1f);
            tx.setColor(DIM);
            tx.setTextSize(11f * a.getResources().getDisplayMetrics().density);
            setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { zoom = zoom >= 2f ? 0.5f : zoom * 2f; invalidate(); } });
        }

        private float baseScale() { return SpriteEqualizeScreen.baseScale(getResources().getDisplayMetrics().density) * zoom; }

        private void draw(Canvas c, SpriteCache.Sprite s, SpriteDefaults.Def d, float k, int alpha) {
            if (s == null || s.bitmap == null || s.bitmap.isRecycled()) return;
            double[] q = corners(d, s.logicalWidth, s.logicalHeight);
            float cx = anchorX(getWidth()), cy = anchorY(getHeight());
            Rect r = s.src;
            float[] src = {r.left, r.top, r.right, r.top, r.left, r.bottom};
            // os 3 pontos vao para (0,0), (1,0), (0,1) do desenho: o quadro inteiro e a imagem inteira
            float[] dst = {cx + (float) q[0] * k, cy + (float) q[1] * k, cx + (float) q[2] * k, cy + (float) q[3] * k, cx + (float) q[4] * k, cy + (float) q[5] * k};
            if (!mx.setPolyToPoly(src, 0, dst, 0, 3)) return;
            SpriteDraw.crop(c, s, mx, alpha, p);          // so o recorte da sprite (o bitmap do cache e a folha inteira)
        }

        private static int alphaOf(SpriteDefaults.Def d) { return d.alpha >= 256 ? 170 : Math.max(25, 255 - Math.max(0, d.alpha)); }

        @Override protected void onDraw(Canvas c) {
            c.drawColor(0xFF0D0F13);
            float k = baseScale();
            float cx = anchorX(getWidth()), cy = anchorY(getHeight());
            c.drawLine(0, cy, getWidth(), cy, line);
            c.drawLine(cx, 0, cx, getHeight(), line);
            if (showGhost && ghost != null) draw(c, ghost, ghostDef, k, 110);
            draw(c, main, mainDef, k, alphaOf(mainDef));
            tx.setTextAlign(Paint.Align.LEFT);
            I18nUi.drawText(c, "toque para ampliar/reduzir (" + Math.round(zoom * 100) + "%)", 8, getHeight() - 8, tx);
        }
    }

    static void show(final Activity a, final Cfg cfg) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, cfg.title, 16, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        if (cfg.hint != null) {
            TextView h = SpriteListScreen.text(a, cfg.hint, 11, DIM, false);
            h.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
            root.addView(h);
        }
        final Preview pv = new Preview(a);
        pv.main = cfg.main; pv.ghost = cfg.ghost; pv.ghostDef = cfg.ghostDef;
        int side = a.getResources().getDisplayMetrics().widthPixels;           // previa quadrada (1:1) na largura da tela
        root.addView(pv, new LinearLayout.LayoutParams(side, side));

        final SpriteDefaults.Def cur = cfg.start.copy();
        final Runnable[] sync = {null};
        final EditText zx = num(a), zy = num(a), rot = num(a), al = num(a), mx = num(a), my = num(a);
        final TextView fh = SpriteListScreen.button(a, "", null), fv = SpriteListScreen.button(a, "", null);
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                pv.mainDef = cfg.relative ? SpriteDefaults.add(cfg.ghostDef, cur) : cur.copy();
                pv.invalidate();
            }
        };
        final Runnable fill = new Runnable() {
            @Override public void run() {
                zx.setText(String.valueOf(cur.zx)); zy.setText(String.valueOf(cur.zy)); rot.setText(String.valueOf(cur.rot)); al.setText(String.valueOf(cur.alpha));
                mx.setText(String.valueOf(cur.midX)); my.setText(String.valueOf(cur.midY));
                fh.setText(cur.flipH ? "Flip horizontal: LIGADO" : "Flip horizontal: desligado");
                fv.setText(cur.flipV ? "Flip vertical: LIGADO" : "Flip vertical: desligado");
                fh.setTextColor(cur.flipH ? OK : TEXT);
                fv.setTextColor(cur.flipV ? OK : TEXT);
                refresh.run();
            }
        };
        sync[0] = fill;

        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        sv.addView(col);
        String unit = cfg.relative ? " (ajuste)" : "";
        col.addView(row(a, "Zoom X %" + unit, zx, 5, new Setter() { public void set(int v) { cur.zx = Math.max(1, v); refresh.run(); } }));
        col.addView(row(a, "Zoom Y %" + unit, zy, 5, new Setter() { public void set(int v) { cur.zy = Math.max(1, v); refresh.run(); } }));
        col.addView(row(a, "Rotação °" + unit, rot, 5, new Setter() { public void set(int v) { cur.rot = v; refresh.run(); } }));
        col.addView(row(a, "Alpha" + unit, al, 8, new Setter() { public void set(int v) { cur.alpha = Math.max(0, v); refresh.run(); } }));
        col.addView(row(a, "Centro X (MID)" + unit, mx, 1, new Setter() { public void set(int v) { cur.midX = v; refresh.run(); } }));
        col.addView(row(a, "Centro Y (MID)" + unit, my, 1, new Setter() { public void set(int v) { cur.midY = v; refresh.run(); } }));
        fh.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cur.flipH = !cur.flipH; sync[0].run(); } });
        fv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cur.flipV = !cur.flipV; sync[0].run(); } });
        LinearLayout fl = new LinearLayout(a);
        fl.addView(fh, new LinearLayout.LayoutParams(0, -2, 1f));
        fl.addView(fv, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(fl);
        col.addView(SpriteListScreen.text(a, cfg.relative
                ? "Alpha: 0 = opaco; +n = n/255 mais transparente (256 e 512 são modos especiais e não somam). Zoom multiplica, rotação, alpha e centro somam ao que a original já tem; o flip se inverte em relação a ela."
                : "Alpha: 0 = opaco; +n = n/255 mais transparente. Zoom 100%, 0°, alpha 0 e centro 0,0 = sem ajuste (o campo some do Frame).", 11, DIM, false));
        if (cfg.extra != null) {
            TextView ex = SpriteListScreen.button(a, cfg.extraLabel, new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); cfg.extra.run(); } });
            col.addView(ex);
        }
        if (cfg.ghost != null) {
            final android.widget.CheckBox cb = new I18nCheckBox(a);
            cb.setText("Mostrar a original por baixo");
            cb.setTextColor(TEXT);
            cb.setChecked(true);
            cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { pv.showGhost = on; pv.invalidate(); }
            });
            col.addView(cb);
        }
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8));
        TextView cancel = SpriteListScreen.button(a, "CANCELAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } });
        cancel.setTextColor(0xFFFF6B6B);
        TextView reset = SpriteListScreen.button(a, "REDEFINIR", new View.OnClickListener() { @Override public void onClick(View v) {
            SpriteDefaults.Def z = new SpriteDefaults.Def();
            cur.zx = z.zx; cur.zy = z.zy; cur.rot = 0; cur.alpha = 0; cur.midX = 0; cur.midY = 0; cur.flipH = false; cur.flipV = false;
            sync[0].run();
        } });
        TextView ok = SpriteListScreen.button(a, cfg.applyLabel, new View.OnClickListener() { @Override public void onClick(View v) {
            d.dismiss();
            if (cfg.on != null) cfg.on.apply(cur.copy());
        } });
        ok.setTextColor(0xFF7CE08A);
        bar.addView(cancel);
        bar.addView(reset, SpriteListScreen.lpm(a, 8));
        bar.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(bar);
        fill.run();
        d.show();
    }

    private interface Setter { void set(int v); }

    private static EditText num(Activity a) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setTextColor(TEXT);
        e.setSelectAllOnFocus(true);
        e.setTypeface(android.graphics.Typeface.MONOSPACE);
        return e;
    }

    /** Linha "rotulo  [−] [valor] [+]". */
    private static LinearLayout row(final Activity a, String label, final EditText et, final int step, final Setter set) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(SpriteListScreen.text(a, label, 13, DIM, false), new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 150), -2));
        TextView minus = SpriteListScreen.button(a, "−", null), plus = SpriteListScreen.button(a, "+", null);
        final Runnable read = new Runnable() {
            @Override public void run() {
                try { set.set(Integer.parseInt(et.getText().toString().trim())); } catch (NumberFormatException ex) { /* mantem */ }
            }
        };
        Hold.attach(minus, new Hold.Rep() { @Override public void step(int repeat) { bump(et, -step * Hold.multiplier(repeat), set); } });      // segurar pula cada vez mais numeros
        Hold.attach(plus, new Hold.Rep() { @Override public void step(int repeat) { bump(et, step * Hold.multiplier(repeat), set); } });
        et.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int af) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) { read.run(); }
        });
        r.addView(minus);
        r.addView(et, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 90), -2));
        r.addView(plus);
        return r;
    }

    private static void bump(EditText et, int delta, Setter set) {
        int v = 0;
        try { v = Integer.parseInt(et.getText().toString().trim()); } catch (NumberFormatException ex) { /* 0 */ }
        et.setText(String.valueOf(v + delta));
        et.setSelection(et.getText().length());
    }
}
