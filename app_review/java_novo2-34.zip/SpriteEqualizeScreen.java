package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Tela unica de "Editar Frame" e "Igualar sprites": previa da sprite com zoom X/Y, rotacao, alpha, centro (MID) e flips, e os campos que os mexem.
 * Modo normal: os campos SAO o padrao da sprite (vale para novas adicoes na timeline). Modo igualar ({@code relative}): a sprite original aparece por baixo,
 * esmaecida, e os campos sao o AJUSTE da nova em relacao a ela (somado ao que a original ja tem). Nada e gravado aqui: quem chama recebe os valores em APLICAR.
 */
final class SpriteEqualizeScreen {
    private static final int BG = 0xFF14171C, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF2E9E4F, BAD = 0xFFC0392B;

    interface Listener { void apply(SpriteDefaults.Def fields); }

    static final class Cfg {
        String title, hint, applyLabel = "APLICAR";
        SpriteCache.Sprite main;
        SpriteCache.Sprite ghost;                      // original por baixo (modo igualar)
        SpriteDefaults.Def start = new SpriteDefaults.Def();      // valores iniciais dos campos
        boolean relative;
        SpriteDefaults.Def resetTo;                    // REDEFINIR volta para ele (null = zerado); no Editar Frame e o padrao automatico da sprite
        String extraLabel;                             // botao extra (ex.: ajustar caixas uma imagem por vez)
        Runnable extra;
        Listener on;
    }

    private SpriteEqualizeScreen() { }

    static final int MIN_ZOOM = 0, MAX_FIELD = 9999;
    /** Folga ao enquadrar as sprites na previa (25%). */
    static final float FIT_MARGIN = 0.25f;

    /** Zoom e alpha nunca ficam abaixo de 0. */
    static int clampZoom(int v) { return Math.max(MIN_ZOOM, Math.min(MAX_FIELD, v)); }
    static int clampAlpha(int v) { return Math.max(0, Math.min(MAX_FIELD, v)); }

    /** Caixa {x0, y0, x1, y1} (unidades logicas) que a previa enquadra ao abrir: a uniao da antiga zerada e da principal com os valores iniciais; fixa enquanto se ajusta. */
    static double[] framingBox(Cfg cfg) {
        double[] b = {Double.MAX_VALUE, Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE};
        addBox(b, cfg.ghost, ghostDefFor(cfg));
        addBox(b, cfg.main, mainDefFor(cfg, cfg.start));
        if (b[0] > b[2]) return new double[]{0, 0, 40, 60};
        return b;
    }

    private static void addBox(double[] b, SpriteCache.Sprite s, SpriteDefaults.Def d) {
        if (s == null) return;
        double[] q = corners(d, s.logicalWidth, s.logicalHeight);
        double[] xs = {q[0], q[2], q[4], q[2] + q[4] - q[0]}, ys = {q[1], q[3], q[5], q[3] + q[5] - q[1]};
        for (int i = 0; i < 4; i++) {
            b[0] = Math.min(b[0], xs[i]); b[1] = Math.min(b[1], ys[i]);
            b[2] = Math.max(b[2], xs[i]); b[3] = Math.max(b[3], ys[i]);
        }
    }

    /** Igualar: a original e sempre desenhada ZERADA (ancora 0,0, RAZ padrao) - nunca com os valores de um Frame nem com o padrao guardado dela. */
    static SpriteDefaults.Def ghostDefFor(Cfg cfg) { return new SpriteDefaults.Def(); }

    /** A sprite principal e desenhada com exatamente os campos (no Igualar tambem partem do zero: sao o que sera SOMADO a cada Frame). */
    static SpriteDefaults.Def mainDefFor(Cfg cfg, SpriteDefaults.Def cur) { return cur.copy(); }

    /** Quadro do jogo (SpriteXform) para os valores do padrao. */
    static SpriteXform.Frame frame(SpriteDefaults.Def d) {
        SpriteXform.Frame f = new SpriteXform.Frame();
        f.flipH = d.flipH; f.flipV = d.flipV; f.ox = d.midX; f.oy = d.midY; f.rot = d.rot; f.zx = d.zx; f.zy = d.zy;
        return f;
    }

    /** Onde caem 3 cantos da sprite ((0,0), (1,0), (0,1)) no sistema do jogo (origem na ancora): x0,y0,x1,y1,x2,y2. */
    static double[] corners(SpriteDefaults.Def d, int lw, int lh) {
        SpriteXform.Frame f = frame(d);
        double[] p0 = SpriteXform.place(f, lw, lh, 0, 0), p1 = SpriteXform.place(f, lw, lh, 1, 0), p2 = SpriteXform.place(f, lw, lh, 0, 1);
        return new double[]{p0[0], p0[1], p1[0], p1[1], p2[0], p2[1]};
    }

    /** Previa igual a principal: grade, linha central, chao e camera livre (arrastar move, pinca da zoom, toque duplo centraliza); a original esmaecida e a sprite com os valores. */
    private static final class Preview extends View {
        SpriteCache.Sprite main, ghost;
        SpriteDefaults.Def mainDef = new SpriteDefaults.Def(), ghostDef = new SpriteDefaults.Def();
        boolean showGhost = true;
        final PreviewCam cam = new PreviewCam();
        final float density;
        final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG), tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Matrix mx = new Matrix();
        final ScaleGestureDetector scaler;
        final GestureDetector taps;
        float lastX, lastY;
        boolean dragging;
        double[] box = {0, 0, 40, 60};          // caixa a enquadrar (unidades logicas)

        Preview(Activity a) {
            super(a);
            density = a.getResources().getDisplayMetrics().density;
            tx.setColor(DIM);
            tx.setTextSize(11f * density);
            cam.recenter(1f, 1f, density);
            cam.minScale = 0.02f;          // sprites enormes precisam caber (a previa principal para em 0,5)
            scaler = new ScaleGestureDetector(a, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) {
                    cam.zoomAt(d.getFocusX(), d.getFocusY(), d.getScaleFactor());
                    invalidate();
                    return true;
                }
            });
            taps = new GestureDetector(a, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    fit();          // toque duplo: volta ao enquadramento inicial (sprites centralizadas)
                    invalidate();
                    return true;
                }
            });
        }

        void fit() { cam.fitBox(getWidth(), getHeight(), box[0], box[1], box[2], box[3], FIT_MARGIN); }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) { fit(); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            taps.onTouchEvent(e);
            scaler.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: lastX = e.getX(); lastY = e.getY(); dragging = true; break;
                case MotionEvent.ACTION_POINTER_DOWN: dragging = false; break;
                case MotionEvent.ACTION_POINTER_UP: {
                    int keep = e.getActionIndex() == 0 ? 1 : 0;
                    lastX = e.getX(keep); lastY = e.getY(keep);
                    dragging = e.getPointerCount() == 2;
                    break;
                }
                case MotionEvent.ACTION_MOVE:
                    if (dragging && !scaler.isInProgress() && e.getPointerCount() == 1) {
                        cam.pan(e.getX() - lastX, e.getY() - lastY);
                        lastX = e.getX(); lastY = e.getY();
                        invalidate();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    break;
                default:
                    break;
            }
            return true;
        }

        private void draw(Canvas c, SpriteCache.Sprite s, SpriteDefaults.Def d, int alpha) {
            if (s == null || s.bitmap == null || s.bitmap.isRecycled()) return;
            double[] q = corners(d, s.logicalWidth, s.logicalHeight);
            Rect r = s.src;
            float[] src = {r.left, r.top, r.right, r.top, r.left, r.bottom};
            float k = cam.scale;
            // os 3 pontos vao para (0,0), (1,0), (0,1) do desenho; a ancora do personagem e a origem da camera
            float[] dst = {cam.originX + (float) q[0] * k, cam.originY + (float) q[1] * k, cam.originX + (float) q[2] * k, cam.originY + (float) q[3] * k,
                    cam.originX + (float) q[4] * k, cam.originY + (float) q[5] * k};
            if (!mx.setPolyToPoly(src, 0, dst, 0, 3)) return;
            SpriteDraw.crop(c, s, mx, alpha, p);          // so o recorte da sprite (o bitmap do cache e a folha inteira)
        }

        private static int alphaOf(SpriteDefaults.Def d) { return d.alpha >= 256 ? 170 : Math.max(25, 255 - Math.max(0, d.alpha)); }

        @Override protected void onDraw(Canvas c) {
            c.drawColor(0xFF0D0F13);
            PreviewGrid.draw(c, getWidth(), getHeight(), cam.originX, cam.originY, cam.scale, density, true, false);          // so a grade: sem linha central nem chao
            if (showGhost && ghost != null) draw(c, ghost, ghostDef, 110);
            draw(c, main, mainDef, alphaOf(mainDef));
            tx.setTextAlign(Paint.Align.LEFT);
            I18nUi.drawText(c, "arraste: mover \u00b7 pin\u00e7a: zoom \u00b7 toque duplo: centralizar", 8, getHeight() - 8, tx);
        }
    }

    static void show(final Activity a, final Cfg cfg) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, cfg.title, 16, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        if (cfg.hint != null) {
            TextView h = SpriteListScreen.text(a, cfg.hint, 11, DIM, false);
            h.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
            root.addView(h);
        }
        final Preview pv = new Preview(a);
        pv.main = cfg.main; pv.ghost = cfg.ghost; pv.ghostDef = ghostDefFor(cfg); pv.box = framingBox(cfg);
        int side = a.getResources().getDisplayMetrics().widthPixels;           // previa quadrada (1:1) na largura da tela
        root.addView(pv, new LinearLayout.LayoutParams(side, side));

        final SpriteDefaults.Def cur = cfg.start.copy();
        final Runnable[] sync = {null};
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                pv.mainDef = mainDefFor(cfg, cur);
                pv.invalidate();
            }
        };
        final TextView fh = SpriteListScreen.button(a, "", null), fv = SpriteListScreen.button(a, "", null);
        final boolean[] unite = {cur.zx == cur.zy};          // "Unir zoom": marcada por padrao (so desmarcada se o valor inicial ja tem X e Y diferentes)

        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        sv.addView(col);
        String unit = cfg.relative ? " (ajuste)" : "";
        // ordem: MID no topo; depois o zoom (com "Unir zoom"); depois rotacao, flips e alpha. Todos de 1 em 1, segurar repete, tocar no numero abre o teclado
        final Stepper sMx = stepper(a, -MAX_FIELD, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.midX = (int) v; refresh.run(); } });
        final Stepper sMy = stepper(a, -MAX_FIELD, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.midY = (int) v; refresh.run(); } });
        col.addView(field(a, "Centro X (MID)" + unit, sMx));
        col.addView(field(a, "Centro Y (MID)" + unit, sMy));
        final android.widget.CheckBox join = new I18nCheckBox(a);
        join.setText("Unir zoom");
        join.setTextColor(TEXT);
        col.addView(join);
        final Stepper sZ = stepper(a, MIN_ZOOM, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.zx = clampZoom((int) v); cur.zy = cur.zx; refresh.run(); } });
        final Stepper sZx = stepper(a, MIN_ZOOM, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.zx = clampZoom((int) v); refresh.run(); } });
        final Stepper sZy = stepper(a, MIN_ZOOM, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.zy = clampZoom((int) v); refresh.run(); } });
        final View rowZ = field(a, "Zoom %" + unit, sZ), rowZx = field(a, "Zoom X %" + unit, sZx), rowZy = field(a, "Zoom Y %" + unit, sZy);
        col.addView(rowZ);
        col.addView(rowZx);
        col.addView(rowZy);
        final Stepper sRot = stepper(a, -MAX_FIELD, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.rot = (int) v; refresh.run(); } });
        col.addView(field(a, "Rotação °" + unit, sRot));
        fh.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cur.flipH = !cur.flipH; sync[0].run(); } });
        fv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cur.flipV = !cur.flipV; sync[0].run(); } });
        LinearLayout fl = new LinearLayout(a);
        fl.addView(fh, new LinearLayout.LayoutParams(0, -2, 1f));
        fl.addView(fv, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(fl);
        final Stepper sAl = stepper(a, 0, MAX_FIELD, new Stepper.OnValue() { public void on(double v) { cur.alpha = clampAlpha((int) v); refresh.run(); } });
        col.addView(field(a, "Alpha" + unit, sAl));
        final Runnable fill = new Runnable() {
            @Override public void run() {
                sMx.value(cur.midX); sMy.value(cur.midY); sRot.value(cur.rot); sAl.value(cur.alpha);
                sZ.value(cur.zx); sZx.value(cur.zx); sZy.value(cur.zy);
                join.setChecked(unite[0]);
                rowZ.setVisibility(unite[0] ? View.VISIBLE : View.GONE);
                rowZx.setVisibility(unite[0] ? View.GONE : View.VISIBLE);
                rowZy.setVisibility(unite[0] ? View.GONE : View.VISIBLE);
                fh.setText(cur.flipH ? "Flip horizontal: LIGADO" : "Flip horizontal: desligado");
                fv.setText(cur.flipV ? "Flip vertical: LIGADO" : "Flip vertical: desligado");
                fh.setTextColor(cur.flipH ? OK : TEXT);
                fv.setTextColor(cur.flipV ? OK : TEXT);
                refresh.run();
            }
        };
        sync[0] = fill;
        join.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                if (on == unite[0]) return;
                unite[0] = on;
                if (on) cur.zy = cur.zx;          // unir: Y passa a valer X
                sync[0].run();
            }
        });
        col.addView(SpriteListScreen.text(a, cfg.relative
                ? "Alpha: 0 = opaco; +n = n/255 mais transparente (256 e 512 são modos especiais e não somam). Em cada Frame o zoom multiplica; rotação, alpha e centro somam; o flip se inverte."
                : "Alpha: 0 = opaco; +n = n/255 mais transparente. Zoom 100%, 0°, alpha 0 e centro 0,0 = sem ajuste (o campo some do Frame).", 11, DIM, false));
        if (cfg.extra != null) {
            TextView ex = SpriteListScreen.button(a, cfg.extraLabel, new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); cfg.extra.run(); } });
            col.addView(ex);
        }
        if (cfg.ghost != null) {
            final android.widget.CheckBox cb = new I18nCheckBox(a);
            cb.setText("Mostrar a original por baixo");
            cb.setTextColor(TEXT);
            cb.setChecked(true);
            cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { pv.showGhost = on; pv.invalidate(); }
            });
            col.addView(cb);
        }
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8));
        TextView cancel = SpriteListScreen.button(a, "CANCELAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } });
        cancel.setTextColor(0xFFFF6B6B);
        TextView reset = SpriteListScreen.button(a, "REDEFINIR", new View.OnClickListener() { @Override public void onClick(View v) {
            SpriteDefaults.Def z = cfg.resetTo != null ? cfg.resetTo : new SpriteDefaults.Def();
            cur.zx = z.zx; cur.zy = z.zy; cur.rot = z.rot; cur.alpha = z.alpha; cur.midX = z.midX; cur.midY = z.midY; cur.flipH = z.flipH; cur.flipV = z.flipV;
            unite[0] = true;
            sync[0].run();
        } });
        TextView ok = SpriteListScreen.button(a, cfg.applyLabel, new View.OnClickListener() { @Override public void onClick(View v) {
            d.dismiss();
            if (cfg.on != null) cfg.on.apply(cur.copy());
        } });
        ok.setTextColor(0xFF7CE08A);
        bar.addView(cancel);
        bar.addView(reset, SpriteListScreen.lpm(a, 8));
        bar.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(bar);
        fill.run();
        d.show();
    }

    /** Controle "− valor +" do app: de 1 em 1, segurar repete continuamente, tocar no numero abre o teclado (vale enquanto digita). */
    private static Stepper stepper(Activity a, int min, int max, Stepper.OnValue l) {
        return new Stepper(a).step(1).range(min, max).keyboard(l).live(true);
    }

    /** Linha "rotulo  [−] valor [+]". */
    private static LinearLayout field(Activity a, String label, Stepper st) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(SpriteListScreen.text(a, label, 13, DIM, false), new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 150), -2));
        r.addView(st.view());
        return r;
    }
}
