package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Sprites seguidas que vieram de uma imagem animada (GIF, WebP, APNG): o grupo guarda onde comecam, quantas sao e o atraso de cada
 * quadro. Fica em sprite_grupos.json na pasta (o montador de PACs ignora .json); o CNV continua sendo so a lista de sprites.
 */
public final class SpriteGroups {
    public static final String FILE = "sprite_grupos.json";

    public static final class Group {
        public String name;
        public int first, count;          // faixa de sprites do grupo: first .. first+count-1
        public int[] delayMs;             // um atraso por quadro
        /** Ordem da animacao: sprite de cada quadro (permite reaproveitar uma sprite em varios quadros). null = quadro k usa a sprite first+k. */
        public int[] seq;

        public Group(String name, int first, int count, int[] delayMs) {
            this.name = name; this.first = first; this.count = count; this.delayMs = delayMs;
        }

        public int last() { return first + count - 1; }
        /** Quantos quadros tem a animacao (pode ser mais que as sprites, se houver reaproveitamento). */
        public int frames() { return seq != null ? seq.length : count; }
        /** Sprite do quadro k. */
        public int spriteAt(int k) { return seq != null ? seq[k] : first + k; }
        /** Quantas sprites diferentes a animacao usa (menos que os quadros se ha reaproveitamento). */
        public int distinctSprites() {
            if (seq == null) return count;
            java.util.HashSet<Integer> h = new java.util.HashSet<Integer>();
            for (int v : seq) h.add(Integer.valueOf(v));
            return h.size();
        }
        public int delayAt(int k) { return k < delayMs.length ? delayMs[k] : 100; }
        public boolean contains(int idx) { return idx >= first && idx <= last(); }
    }

    public final List<Group> list = new ArrayList<Group>();

    public Group at(int idx) {
        for (Group g : list) if (g.contains(idx)) return g;
        return null;
    }

    public Group startingAt(int idx) {
        for (Group g : list) if (g.first == idx) return g;
        return null;
    }

    /**
     * Acompanha a exclusao de sprites com renumeracao: {@code map[antigo] = novo} (-1 = removida). O grupo perde os quadros das sprites
     * removidas (e os atrasos deles); com menos de 2 quadros deixa de ser um grupo. Devolve quantos grupos mudaram ou sumiram.
     */
    public int remap(int[] map) {
        int changed = 0;
        for (int gi = list.size() - 1; gi >= 0; gi--) {
            Group g = list.get(gi);
            int newFirst = -1, kept = 0;
            for (int k = 0; k < g.count; k++) {
                int idx = g.first + k;
                int nv = idx >= 0 && idx < map.length ? map[idx] : idx;
                if (nv < 0) continue;
                if (newFirst < 0) newFirst = nv;
                kept++;
            }
            int[] nseq = null, nd;
            if (g.seq != null) {
                java.util.ArrayList<Integer> sq = new java.util.ArrayList<Integer>(), dl = new java.util.ArrayList<Integer>();
                for (int k = 0; k < g.seq.length; k++) {
                    int v = g.seq[k];
                    int nv = v >= 0 && v < map.length ? map[v] : v;
                    if (nv < 0) continue;
                    sq.add(Integer.valueOf(nv)); dl.add(Integer.valueOf(g.delayAt(k)));
                }
                nseq = new int[sq.size()]; nd = new int[sq.size()];
                for (int k = 0; k < nseq.length; k++) { nseq[k] = sq.get(k).intValue(); nd[k] = dl.get(k).intValue(); }
            } else {
                nd = new int[kept];
                for (int k = 0, o = 0; k < g.count; k++) {
                    int idx = g.first + k;
                    int nv = idx >= 0 && idx < map.length ? map[idx] : idx;
                    if (nv >= 0) nd[o++] = g.delayAt(k);
                }
            }
            int frames = nseq != null ? nseq.length : kept;
            if (frames < 2 || kept < 1) { list.remove(gi); changed++; continue; }
            if (newFirst != g.first || kept != g.count || nseq != null || nd.length != g.delayMs.length) {
                g.first = newFirst; g.count = kept; g.delayMs = nd; g.seq = nseq;
                changed++;
            }
        }
        return changed;
    }

    /**
     * Acompanha o movimento de uma sprite ({@link SpriteMove#moveMap}): {@code map[antigo] = novo}, uma permutacao. Um GIF inteiro dentro da faixa deslocada
     * acompanha (mesmo deslocamento); reordenar quadros DENTRO do mesmo GIF mantem o GIF (os atrasos vao junto com a sprite); qualquer outro caso
     * (a sprite sai ou entra num GIF, ou o corta no meio) desfaz aquele GIF. Devolve quantos GIFs foram desfeitos.
     */
    public int remapMove(int[] map) {
        int dissolved = 0;
        for (int gi = list.size() - 1; gi >= 0; gi--) {
            Group g = list.get(gi);
            boolean inRange = g.first >= 0 && g.last() < map.length;
            if (!inRange) continue;
            int[] n = new int[g.count];
            for (int k = 0; k < g.count; k++) n[k] = map[g.first + k];
            boolean uniform = true;
            for (int k = 0; k < g.count; k++) if (n[k] != n[0] + k) uniform = false;
            boolean sameRange = true;
            boolean[] seen = new boolean[g.count];
            for (int k = 0; k < g.count; k++) {
                int r = n[k] - g.first;
                if (r < 0 || r >= g.count || seen[r]) { sameRange = false; break; }
                seen[r] = true;
            }
            if (!uniform && !sameRange) { list.remove(gi); dissolved++; continue; }
            if (g.seq != null) for (int k = 0; k < g.seq.length; k++) if (g.seq[k] >= 0 && g.seq[k] < map.length) g.seq[k] = map[g.seq[k]];
            if (uniform) { g.first = n[0]; continue; }
            if (g.seq == null) {                       // quadro k usa a sprite first+k: o atraso acompanha a sprite
                int[] nd = new int[g.count];
                for (int k = 0; k < g.count; k++) nd[n[k] - g.first] = g.delayAt(k);
                g.delayMs = nd;
            }
        }
        return dissolved;
    }

    public void add(Group g) { list.add(g); }

    public void remove(Group g) { list.remove(g); }

    /** Desfaz os grupos que incluem algum dos indices. Devolve quantos. */
    public int dissolveTouching(int... idx) {
        int n = 0;
        for (int i = list.size() - 1; i >= 0; i--) {
            for (int k : idx) if (list.get(i).contains(k)) { list.remove(i); n++; break; }
        }
        return n;
    }

    // ---- arquivo ----

    public static SpriteGroups load(File dir) {
        SpriteGroups g = new SpriteGroups();
        File f = new File(dir, FILE);
        if (!f.isFile()) return g;
        try {
            g.parse(new String(GameData.readAll(f), "UTF-8"));
        } catch (Exception e) {
            g.list.clear();
        }
        return g;
    }

    /** Grava (ou apaga o arquivo se nao ha grupos). */
    public void save(File dir) throws IOException {
        File f = new File(dir, FILE);
        if (list.isEmpty()) { if (f.exists()) f.delete(); return; }
        SpriteLib.writeAtomic(f, toJson().getBytes("UTF-8"));
    }

    String toJson() {
        StringBuilder sb = new StringBuilder("{\"grupos\":[\n");
        for (int i = 0; i < list.size(); i++) {
            Group g = list.get(i);
            sb.append("  {\"nome\":\"").append(g.name.replace("\\", "\\\\").replace("\"", "\\\"")).append("\",\"inicio\":").append(g.first)
                    .append(",\"qtd\":").append(g.count).append(",\"atrasos\":[");
            for (int k = 0; k < g.delayMs.length; k++) sb.append(k > 0 ? "," : "").append(g.delayMs[k]);
            sb.append("]");
            if (g.seq != null) {
                sb.append(",\"seq\":[");
                for (int k = 0; k < g.seq.length; k++) sb.append(k > 0 ? "," : "").append(g.seq[k]);
                sb.append("]");
            }
            sb.append("}").append(i + 1 < list.size() ? "," : "").append('\n');
        }
        return sb.append("]}\n").toString();
    }

    private static final Pattern OBJ = Pattern.compile("\\{\\s*\"nome\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"\\s*,\\s*\"inicio\"\\s*:\\s*(\\d+)\\s*,\\s*\"qtd\"\\s*:\\s*(\\d+)\\s*,\\s*\"atrasos\"\\s*:\\s*\\[([^\\]]*)\\]\\s*(?:,\\s*\"seq\"\\s*:\\s*\\[([^\\]]*)\\]\\s*)?\\}");

    void parse(String text) {
        list.clear();
        Matcher m = OBJ.matcher(text);
        while (m.find()) {
            String name = m.group(1).replace("\\\"", "\"").replace("\\\\", "\\");
            int first = Integer.parseInt(m.group(2)), count = Integer.parseInt(m.group(3));
            String[] parts = m.group(4).trim().isEmpty() ? new String[0] : m.group(4).split(",");
            int[] sq = null;
            if (m.group(5) != null && !m.group(5).trim().isEmpty()) {
                String[] sp = m.group(5).split(",");
                sq = new int[sp.length];
                for (int i = 0; i < sp.length; i++) sq[i] = Integer.parseInt(sp[i].trim());
            }
            int nf = sq != null ? sq.length : count;
            int[] d = new int[nf];
            for (int i = 0; i < nf; i++) d[i] = i < parts.length ? Integer.parseInt(parts[i].trim()) : 100;
            if (nf >= 2) { Group g = new Group(name, first, count, d); g.seq = sq; list.add(g); }
        }
    }

    /** Ticks do jogo (60 por segundo) de um atraso em ms, entre 1 e 255. */
    public static int ticks(int delayMs) {
        int d = delayMs <= 0 ? 100 : delayMs;
        return Math.max(1, Math.min(255, Math.round(d * 60f / 1000f)));
    }
}
