package com.zue.attackeditor;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Plano para trazer sprites de outro pac (um .cnv com as folhas PNG na mesma pasta) para o personagem: quais sprites existem de verdade,
 * quais repetem o mesmo recorte (so entram uma vez) e quanto ampliar para manter o tamanho na tela. Java puro (testado sem Android).
 */
final class SpriteImportPlan {
    private SpriteImportPlan() { }

    /** Uma sprite distinta do pac de origem. {@code same} = outras sprites da tabela que apontam para o mesmo recorte. */
    static final class Item {
        final int index;
        final int width, height;           // em unidades logicas (como no CNV)
        final List<Integer> same = new ArrayList<Integer>();

        Item(int index, int width, int height) { this.index = index; this.width = width; this.height = height; }
    }

    /** Sprites com desenho (largura e altura > 0), uma por recorte (folha, x, y, largura, altura) e na ordem da tabela. */
    static List<Item> items(Cnv cnv) {
        List<Item> out = new ArrayList<Item>();
        Map<String, Item> seen = new HashMap<String, Item>();
        for (int i = 0; i < cnv.size(); i++) {
            Cnv.Entry e = cnv.byImage(i);
            if (e == null || e.width <= 0 || e.height <= 0) continue;
            String key = e.source + ":" + e.x + ":" + e.y + ":" + e.width + ":" + e.height;
            Item prev = seen.get(key);
            if (prev != null) { prev.same.add(Integer.valueOf(i)); continue; }
            Item it = new Item(i, e.width, e.height);
            seen.put(key, it);
            out.add(it);
        }
        return out;
    }

    /** Quantas vezes ampliar para manter o tamanho na tela: o personagem usa escala 2 e efeito/charf/bobj escala 1 (so amplia, nunca reduz). */
    static int factor(int srcScale, int dstScale) {
        if (srcScale <= 0 || dstScale <= srcScale) return 1;
        return Math.max(1, Math.round(dstScale / (float) srcScale));
    }

    static boolean isCnvName(String name) {
        String n = name.toLowerCase(Locale.US);
        return n.endsWith(".cnv") || n.endsWith(".cnv.txt");
    }

    /** O arquivo .cnv (binario) correspondente ao tocado: "000.cnv.txt" vira "000.cnv" (o leitor prefere o .txt se existir). */
    static File cnvOf(File picked) {
        String n = picked.getName();
        if (n.toLowerCase(Locale.US).endsWith(".cnv.txt")) return new File(picked.getParentFile(), n.substring(0, n.length() - 4));
        return picked;
    }

    /** Pastas de personagem usam escala 2: charNN (tambem char5, char05_copia, Char05); charf/chara... sao outros packs. */
    static boolean isCharacterDir(File dir) { return dir != null && dir.getName().matches("(?i)char\\d+.*"); }

    /** Pasta de personagem: nome charNN ou tem um *.bin.txt (so personagem tem; efeito/charf/bobj nao). */
    static boolean isCharacterPac(File dir) { return isCharacterDir(dir) || (dir != null && TxtFiles.find(dir, "bin") != null); }

    /**
     * Deduz a escala quando a pasta nao diz: {@code c} lido sem dividir (coordenadas como estao no .cnv) e {@code sheetWH[folha] = {largura, altura}}
     * dos PNG (0 = nao existe). Devolve 2 se os recortes so cabem nas folhas multiplicados por 2 e, multiplicados, quase enchem alguma folha
     * (folha empacotada: o .cnv guarda a metade dos pixels); senao 0 = sem evidencia (vale a pasta). Nunca devolve 1: so promove 1 -> 2.
     */
    static int guessScale(Cnv c, int[][] sheetWH) {
        if (c == null || sheetWH == null) return 0;
        double fill = 0;
        int checked = 0;
        for (int i = 0; i < c.size(); i++) {
            Cnv.Entry e = c.byImage(i);
            if (e == null || e.width <= 0 || e.height <= 0 || e.source < 0 || e.source >= sheetWH.length) continue;
            int w = sheetWH[e.source][0], h = sheetWH[e.source][1];
            if (w <= 0 || h <= 0) continue;
            checked++;
            long r = 2L * (e.x + e.width), b = 2L * (e.y + e.height);
            if (e.x < 0 || e.y < 0 || r > w || b > h) return 0;       // nao cabe dobrado: escala 1
            fill = Math.max(fill, Math.max(r / (double) w, b / (double) h));
        }
        return checked > 0 && fill >= 0.85 ? 2 : 0;
    }

    /** Nao importa do proprio personagem. */
    static boolean sameFolder(File a, File b) {
        try { return a != null && b != null && a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (java.io.IOException e) { return a != null && a.equals(b); }
    }

    /** Resumo para a lista: "SPR_12  32x48 (= SPR_20, SPR_31)". */
    static String describe(Item it) {
        StringBuilder b = new StringBuilder("SPR_").append(it.index).append("  ").append(it.width).append('x').append(it.height);
        if (!it.same.isEmpty()) {
            b.append("  (= ");
            for (int i = 0; i < it.same.size(); i++) { if (i > 0) b.append(", "); b.append("SPR_").append(it.same.get(i)); if (i == 3 && it.same.size() > 4) { b.append(", ..."); break; } }
            b.append(')');
        }
        return b.toString();
    }
}
