package com.zue.attackeditor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;

/**
 * Lista de sprites de uma pasta (personagem, effect, charf): as folhas (NNN.png) e o CNV continuam como o jogo espera;
 * aqui so se corta por cima, em memoria. Adicionar procura espaco livre nas folhas existentes e so cria folha nova
 * se nao couber. As mudancas ficam na memoria ate {@link #commit()}.
 */
public final class SpriteLib {
    public final File dir;
    private final File cnvFile;
    public final Cnv cnv;
    public final int scale;
    private final Map<Integer, Bitmap> sheets = new HashMap<Integer, Bitmap>();
    private final HashSet<Integer> dirty = new HashSet<Integer>();
    private boolean cnvDirty;
    /** As folhas na ordem do {@code $src} (indice = posicao); as novas, ainda nao gravadas, entram no fim com o nome que vao ter. */
    private final ArrayList<File> sheetFiles;
    private int nSheets;
    private int newSheets;
    /** Grupos de sprites que vieram de imagens animadas. */
    public final SpriteGroups groups;
    private boolean groupsDirty;

    public SpriteLib(File dir, File cnvFile, Cnv cnv, int scale) {
        this.dir = dir;
        this.cnvFile = cnvFile;
        this.cnv = cnv;
        this.scale = scale;
        this.groups = SpriteGroups.load(dir);
        this.sheetFiles = new ArrayList<File>(SheetFiles.list(dir));
        nSheets = sheetFiles.size();
    }

    public static boolean isSheetName(String n) { return SheetFiles.isSheetName(n); }

    public int sheetCount() { return nSheets; }
    public int count() { return cnv.size(); }

    /** Tamanho logico (largura, altura) do recorte da sprite no CNV, ou null se nao tem. */
    public int[] logicalSize(int image) {
        Cnv.Entry e = cnv.byImage(image);
        return e == null || e.width <= 0 || e.height <= 0 ? null : new int[]{e.width, e.height};
    }

    /** Esquece as folhas lidas que nao tem alteracao pendente (o arquivo no disco mudou por fora, ex.: PNG otimizado). */
    public void dropSheetCache() {
        for (java.util.Iterator<Map.Entry<Integer, Bitmap>> it = sheets.entrySet().iterator(); it.hasNext();) {
            Map.Entry<Integer, Bitmap> e = it.next();
            if (dirty.contains(e.getKey())) continue;
            if (e.getValue() != null && !e.getValue().isRecycled()) e.getValue().recycle();
            it.remove();
        }
    }
    public boolean isDirty() { return cnvDirty || groupsDirty || !dirty.isEmpty(); }

    /** Folha em memoria (editavel); null se nao existe. */
    public Bitmap sheet(int s) {
        Bitmap b = sheets.get(Integer.valueOf(s));
        if (b != null && !b.isRecycled()) return b;
        if (s < 0 || s >= nSheets) return null;
        File f = sheetFiles.get(s);
        if (!f.isFile()) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        o.inMutable = true;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        b = BitmapFactory.decodeFile(f.getPath(), o);
        if (b != null) {
            if (!b.isMutable()) { Bitmap m = b.copy(Bitmap.Config.ARGB_8888, true); b.recycle(); b = m; }
            sheets.put(Integer.valueOf(s), b);
        }
        return b;
    }

    /** true se a imagem tem desenho (entrada com tamanho). */
    public boolean has(int image) {
        Cnv.Entry e = cnv.byImage(image);
        return e != null && e.width > 0 && e.height > 0;
    }

    /** Por que o recorte da sprite {@code image} nao funciona (null = certo; vazia nao conta): ver {@link CropProblem}. */
    public String cutProblem(int image) {
        Cnv.Entry e = cnv.byImage(image);
        if (e != null && (e.width <= 0 || e.height <= 0)) return null;
        File f = e == null || e.source < 0 || e.source >= sheetFiles.size() ? null : sheetFiles.get(e.source);
        Bitmap sh = f == null || !f.isFile() ? null : sheet(e.source);
        return CropProblem.reason(e, scale, f == null ? null : f.getName(), sheetFiles.size(), sh == null ? 0 : sh.getWidth(), sh == null ? 0 : sh.getHeight());
    }

    /** Sprites com desenho cujo recorte falha, como linhas "SPR_n: motivo" (ate {@code max}). */
    public java.util.List<String> cutProblems(int max) {
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        for (int i = 0; i < cnv.size() && out.size() < max; i++) {
            String why = cutProblem(i);
            if (why != null) out.add("SPR_" + i + ": " + why);
        }
        return out;
    }

    /** Copia dos pixels da sprite (tamanho fisico); null se vazia ou fora da folha. */
    public Bitmap cut(int image) {
        Cnv.Entry e = cnv.byImage(image);
        if (e == null || e.width <= 0 || e.height <= 0) return null;
        Bitmap sh = sheet(e.source);
        if (sh == null) return null;
        int l = e.x * scale, t = e.y * scale, w = e.width * scale, h = e.height * scale;
        Rect sr = new Rect(Math.max(0, l), Math.max(0, t), Math.min(sh.getWidth(), l + w), Math.min(sh.getHeight(), t + h));
        if (sr.width() <= 0 || sr.height() <= 0) return null;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        new Canvas(out).drawBitmap(sh, sr, new Rect(sr.left - l, sr.top - t, sr.right - l, sr.bottom - t), null);
        return out;
    }

    // ---- operacoes ----

    /** Adiciona a imagem como a proxima sprite (indice = fim da tabela). Devolve o indice. */
    public int add(Bitmap img) throws IOException {
        int idx = cnv.size();
        place(idx, img);
        return idx;
    }

    /** Adiciona os quadros de uma imagem animada como sprites seguidas e registra o grupo. Devolve o indice da primeira. */
    public int addAnimation(String name, java.util.List<Bitmap> frames, int[] delaysMs) throws IOException {
        return addAnimation(name, frames, delaysMs, null);
    }

    /** Chamado depois de cada quadro gravado (progresso). */
    public interface Step { void on(int done); }

    public int addAnimation(String name, java.util.List<Bitmap> frames, int[] delaysMs, Step step) throws IOException {
        int first = cnv.size();
        int n = 0;
        for (Bitmap b : frames) { add(b); n++; if (step != null) step.on(n); }
        int[] d = new int[frames.size()];
        for (int i = 0; i < d.length; i++) d[i] = delaysMs != null && i < delaysMs.length ? delaysMs[i] : 100;
        if (frames.size() >= 2) { groups.add(new SpriteGroups.Group(name, first, frames.size(), d)); groupsDirty = true; }
        return first;
    }

    /** Remove todas as sprites do grupo (como remove, uma a uma) e o proprio grupo. */
    public void removeGroup(SpriteGroups.Group g) {
        for (int i = g.first; i <= g.last(); i++) { if (i < cnv.size()) { cnv.clear(i); cnvDirty = true; } }
        groups.remove(g);
        trimTrailing();
        groupsDirty = true;
    }

    /** Assinaturas de todos os quadros do GIF (para o preview e a escolha da tolerancia). */
    public GifOptimizer.Analysis analyze(SpriteGroups.Group g, Step step) {
        GifOptimizer.Analysis an = new GifOptimizer.Analysis();
        an.n = g.frames();
        an.sprite = new int[an.n];
        an.valid = new boolean[an.n];
        an.score = new int[an.n][an.n];
        GifOptimizer.Sig[] sg = new GifOptimizer.Sig[an.n];
        for (int k = 0; k < an.n; k++) {
            int sp = g.spriteAt(k);
            an.sprite[k] = sp;
            if (step != null) step.on(k + 1);
            if (!has(sp)) continue;
            Bitmap b = cut(sp);
            if (b == null) continue;
            int[] px = new int[b.getWidth() * b.getHeight()];
            b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
            sg[k] = GifOptimizer.sig(px, b.getWidth(), b.getHeight());
            b.recycle();
            an.valid[k] = true;
        }
        for (int i = 0; i < an.n; i++) {
            if (sg[i] == null) continue;
            for (int j = i + 1; j < an.n; j++) {
                if (sg[j] == null) continue;
                // quadros da mesma sprite sao identicos sem comparar
                int sc = an.sprite[i] == an.sprite[j] ? 100 : GifOptimizer.score(sg[i], sg[j]);
                an.score[i][j] = an.score[j][i] = sc;
            }
        }
        return an;
    }

    /**
     * Aplica o reaproveitamento: o quadro k passa a usar a sprite do quadro repr[k]; sprites que ninguem mais usa ficam vazias (espaco livre).
     * Os atrasos de cada quadro nao mudam (a animacao dura o mesmo). Devolve pares {sprite removida, sprite que a substitui} para o DAC.
     */
    public java.util.List<int[]> applyReuse(SpriteGroups.Group g, GifOptimizer.Analysis an, int[] repr) {
        java.util.ArrayList<int[]> map = new java.util.ArrayList<int[]>();
        int[] nseq = new int[an.n];
        for (int k = 0; k < an.n; k++) nseq[k] = repr[k] < 0 ? an.sprite[k] : an.sprite[repr[k]];
        java.util.HashSet<Integer> used = new java.util.HashSet<Integer>();
        for (int v : nseq) used.add(Integer.valueOf(v));
        java.util.HashSet<Integer> done = new java.util.HashSet<Integer>();
        for (int k = 0; k < an.n; k++) {
            int sp = an.sprite[k];
            if (repr[k] < 0 || used.contains(Integer.valueOf(sp)) || !has(sp) || !done.add(Integer.valueOf(sp))) continue;
            cnv.clear(sp);
            map.add(new int[]{sp, nseq[k]});
        }
        if (map.isEmpty() && java.util.Arrays.equals(nseq, g.seq != null ? g.seq : identitySeq(g))) return map;
        g.seq = nseq;
        cnvDirty = true;
        groupsDirty = true;
        trimTrailing();
        return map;
    }

    private static int[] identitySeq(SpriteGroups.Group g) {
        int[] r = new int[g.count];
        for (int i = 0; i < r.length; i++) r[i] = g.first + i;
        return r;
    }

    /** O grupo deixa de existir; as sprites continuam como estao. */
    public void dissolve(SpriteGroups.Group g) {
        groups.remove(g);
        groupsDirty = true;
    }

    /**
     * Troca a imagem da sprite {@code idx} (mesmo indice). Primeiro a sprite antiga sai da folha (so o que nenhuma outra sprite usa), deixando o
     * espaco livre E sem pixels; so depois a nova e alocada, entao uma sprite menor pode assumir o lugar da antiga e o resto fica para outras.
     */
    public void replace(int idx, Bitmap img) throws IOException {
        Cnv.Entry old = cnv.byImage(idx);
        int os = old.source, ox = old.x, oy = old.y, ow = old.width, oh = old.height;
        Bitmap saved = cut(idx);                // pixels antigos, para devolver se a nova nao couber
        cnv.clear(idx);                         // o espaco antigo fica livre no mapa e pode ser reaproveitado
        erase(os, ox, oy, ow, oh);
        try {
            place(idx, img);
        } catch (IOException e) {
            cnv.set(idx, os, ox, oy, ow, oh);
            if (saved != null) restore(os, ox, oy, saved);
            throw e;
        } finally {
            if (saved != null) saved.recycle();
        }
    }

    /** Apaga da folha os pixels da area logica que nenhuma entrada do CNV usa. */
    private void erase(int source, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0 || source < 0 || source >= nSheets) return;
        java.util.List<int[]> parts = SpriteAlloc.uncovered(cnv, source, x, y, w, h);
        if (parts.isEmpty()) return;
        Bitmap sh = sheet(source);
        if (sh == null) return;
        Canvas c = new Canvas(sh);
        Paint clr = new Paint();
        clr.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        for (int[] p : parts) c.drawRect(p[0] * scale, p[1] * scale, (p[0] + p[2]) * scale, (p[1] + p[3]) * scale, clr);
        dirty.add(Integer.valueOf(source));
    }

    private void restore(int source, int x, int y, Bitmap px) {
        Bitmap sh = source >= 0 && source < nSheets ? sheet(source) : null;
        if (sh == null) return;
        new Canvas(sh).drawBitmap(px, x * scale, y * scale, null);
        dirty.add(Integer.valueOf(source));
    }

    /** Zera as coordenadas da sprite no CNV: o indice continua na tabela (os outros nao mudam) e o espaco passa a contar como livre. As folhas nao sao tocadas. */
    public void remove(int idx) {
        if (idx < 0 || idx >= cnv.size()) return;
        cnv.clear(idx);
        cnvDirty = true;
        trimTrailing();
    }

    /**
     * Exclui as sprites e RENUMERA as seguintes (se a SPR_0 sai, a 1 vira 0, a 2 vira 1...). Devolve o mapa antigo -> novo (-1 = removida);
     * quem chama reescreve os usos no DAC ({@link SpriteRenumber#remapDac}). Os pixels ficam nas folhas, mas sem entrada no CNV: contam como espaco livre.
     */
    public int[] removeShift(java.util.Set<Integer> idx) {
        int n = cnv.size();
        boolean[] rem = new boolean[n];
        for (Integer i : idx) if (i.intValue() >= 0 && i.intValue() < n) rem[i.intValue()] = true;
        int[] map = SpriteRenumber.map(n, rem);
        cnv.removeShift(rem);
        if (groups.remap(map) > 0) groupsDirty = true;
        cnvDirty = true;
        return map;
    }

    /** Entradas vazias no fim da tabela nao servem para nada: sao descartadas para liberar os indices. Devolve quantas. */
    public int trimTrailing() {
        int n = cnv.size();
        while (n > 1 && !has(n - 1)) n--;
        int removed = cnv.size() - n;
        if (removed <= 0) return 0;
        cnv.truncate(n);
        final int keep = n;
        // GIF que ia alem do novo fim: perde so os quadros do fim; com menos de 2 quadros deixa de ser GIF
        for (int i = groups.list.size() - 1; i >= 0; i--) {
            SpriteGroups.Group g = groups.list.get(i);
            if (g.last() < keep) continue;
            int nc = keep - g.first;
            if (g.seq != null) {
                // animacao com sprites reaproveitadas: a faixa de sprites encolhe, os quadros (ordem e tempos) continuam
                if (nc >= 1) g.count = nc; else groups.list.remove(i);
            } else if (nc >= 2) {
                g.delayMs = java.util.Arrays.copyOf(g.delayMs, nc);
                g.count = nc;
            } else groups.list.remove(i);
            groupsDirty = true;
        }
        cnvDirty = true;
        return removed;
    }

    /** Muda so o recorte na folha (os pixels nao se mexem). */
    public void setCrop(int idx, int source, int x, int y, int w, int h) {
        cnv.set(idx, Math.max(0, Math.min(source, Math.max(0, nSheets - 1))), x, y, Math.max(0, w), Math.max(0, h));
        cnvDirty = true;
    }

    /** Troca de lugar as entradas {@code from} e {@code to} (cresce a tabela com vazias se {@code to} for alem do fim). */
    public void swap(int from, int to) {
        if (from == to || from < 0 || to < 0) return;
        if (groups.dissolveTouching(from, to) > 0) groupsDirty = true;
        cnv.ensureSize(Math.max(from, to) + 1);
        Cnv.Entry a = cnv.byImage(from), b = cnv.byImage(to);
        cnv.set(from, b.source, b.x, b.y, b.width, b.height);
        cnv.set(to, a.source, a.x, a.y, a.width, a.height);
        cnvDirty = true;
    }

    /** Quantos GIFs a ultima {@link #move} desfez. */
    public int lastMoveDissolved;

    /** Move a sprite {@code from} para o slot {@code to} (as do meio deslocam 1): CNV e grupos de GIF acompanham. Devolve o mapa antigo -> novo (para o DAC). */
    public int[] move(int from, int to) {
        int n = cnv.size();
        int[] map = SpriteMove.moveMap(n, from, to);
        lastMoveDissolved = 0;
        if (from == to || from < 0 || to < 0 || from >= n || to >= n) return map;
        SpriteMove.moveCnv(cnv, from, to);
        lastMoveDissolved = groups.remapMove(map);
        groupsDirty = true;
        cnvDirty = true;
        return map;
    }

    /** Folhas normais ficam em ate 2048 px; sprite maior ganha folha propria (potencia de 2). Acima de 4096 px e reduzida (trava de seguranca: 8192+ passa de 100 MB e o Android recusa desenhar). */
    public static final int MAX_SIDE = 4096;
    public int downscaled;   // quantas sprites foram reduzidas por passar do limite

    private void place(int idx, Bitmap img) throws IOException {
        if (img.getWidth() > MAX_SIDE || img.getHeight() > MAX_SIDE) {
            float k = MAX_SIDE / (float) Math.max(img.getWidth(), img.getHeight());
            Bitmap r = Bitmap.createScaledBitmap(img, Math.max(1, Math.round(img.getWidth() * k)), Math.max(1, Math.round(img.getHeight() * k)), true);
            downscaled++;
            place2(idx, r);
            if (r != img) r.recycle();
            return;
        }
        place2(idx, img);
    }

    private void place2(int idx, Bitmap img) throws IOException {
        int lw = Math.max(1, (img.getWidth() + scale - 1) / scale), lh = Math.max(1, (img.getHeight() + scale - 1) / scale);
        SpriteAlloc.Spot sp = SpriteAlloc.find(cnv, adapter(), scale, lw, lh, 1);
        if (sp.newSheet) {
            Bitmap ns = Bitmap.createBitmap(sp.newSize, sp.newSize, Bitmap.Config.ARGB_8888);
            sheets.put(Integer.valueOf(nSheets), ns);
            sp.sheet = nSheets;
            sheetFiles.add(new File(dir, SheetFiles.name(SheetFiles.nextNumber(sheetFiles))));      // depois da ultima: ganha o indice nSheets
            nSheets++;
            newSheets++;
            if (nSheets > 255) throw new IOException("mais de 255 folhas de sprite");
        }
        Bitmap sh = sheet(sp.sheet);
        if (sh == null) throw new IOException("folha " + sp.sheet + " ilegivel");
        Canvas c = new Canvas(sh);
        Paint clr = new Paint();
        clr.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        c.drawRect(sp.x * scale, sp.y * scale, (sp.x + lw) * scale, (sp.y + lh) * scale, clr);
        c.drawBitmap(img, sp.x * scale, sp.y * scale, null);
        dirty.add(Integer.valueOf(sp.sheet));
        cnv.set(idx, sp.sheet, sp.x, sp.y, lw, lh);
        cnvDirty = true;
    }

    private SpriteAlloc.Sheets adapter() {
        return new SpriteAlloc.Sheets() {
            @Override public int count() { return nSheets; }
            @Override public int width(int s) { Bitmap b = sheet(s); return b == null ? 0 : b.getWidth(); }
            @Override public int height(int s) { Bitmap b = sheet(s); return b == null ? 0 : b.getHeight(); }
        };
    }

    // ---- disco ----

    /** Grava as folhas mudadas (e novas) e o CNV; se entraram folhas novas, os WAVs passam a comecar depois delas. */
    public void commit() throws IOException {
        trimTrailing();
        for (Integer s : new ArrayList<Integer>(dirty)) {
            Bitmap b = sheets.get(s);
            if (b == null) continue;
            File out = sheetFiles.get(s.intValue());
            File tmp = new File(dir, out.getName() + ".tmp");
            FileOutputStream fo = new FileOutputStream(tmp);
            try { b.compress(Bitmap.CompressFormat.PNG, 100, fo); } finally { fo.close(); }
            if (out.exists() && !out.delete()) throw new IOException("nao consegui substituir " + out.getName());
            if (!tmp.renameTo(out)) throw new IOException("nao consegui gravar " + out.getName());
        }
        // o jogo monta o .cnv a partir do .cnv.txt: o que vale e o texto (o binario e refeito na compilacao)
        if (cnvDirty || newSheets > 0) writeAtomic(new File(cnvFile.getPath() + ".txt"), cnv.toTxt().getBytes("UTF-8"));
        if (newSheets > 0) shiftWavs();
        if (groupsDirty) groups.save(dir);
        groupsDirty = false;
        dirty.clear();
        cnvDirty = false;
        newSheets = 0;
    }

    private void shiftWavs() {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        ArrayList<File> wavs = new ArrayList<File>();
        for (File f : fs) if (f.isFile() && f.getName().matches("\\d{3}\\.wav")) wavs.add(f);
        if (wavs.isEmpty()) return;
        Collections.sort(wavs, new Comparator<File>() { @Override public int compare(File a, File b) { return a.getName().compareTo(b.getName()); } });
        int first = Integer.parseInt(wavs.get(0).getName().substring(0, 3));
        int top = SheetFiles.nextNumber(sheetFiles) - 1;       // maior numero de folha
        if (first > top) return;
        int shift = top + 1 - first;
        for (int i = wavs.size() - 1; i >= 0; i--) {
            int n = Integer.parseInt(wavs.get(i).getName().substring(0, 3)) + shift;
            wavs.get(i).renameTo(new File(dir, String.format(Locale.US, "%03d.wav", n)));
        }
    }

    static void writeAtomic(File f, byte[] data) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream fo = new FileOutputStream(tmp);
        try { fo.write(data); } finally { fo.close(); }
        if (f.exists() && !f.delete()) throw new IOException("nao consegui substituir " + f.getName());
        if (!tmp.renameTo(f)) throw new IOException("nao consegui gravar " + f.getName());
    }

    public void release() {
        for (Bitmap b : sheets.values()) if (b != null && !b.isRecycled()) b.recycle();
        sheets.clear();
    }

    // ---- PNGs soltos (colocados na pasta por fora do app) ----

    /** PNGs da pasta que nao sao folhas (nome diferente de NNN.png), do mais antigo para o mais novo. */
    public static File[] loose(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) return new File[0];
        ArrayList<File> out = new ArrayList<File>();
        for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.US);
            if (f.isFile() && n.endsWith(".png") && !isSheetName(n)) out.add(f);
        }
        File[] a = out.toArray(new File[0]);
        Arrays.sort(a, new Comparator<File>() {
            @Override public int compare(File x, File y) {
                long d = x.lastModified() - y.lastModified();
                return d != 0 ? (d < 0 ? -1 : 1) : x.getName().compareTo(y.getName());
            }
        });
        return a;
    }

    /**
     * Cada PNG solto vira a proxima sprite (do mais antigo ao mais novo); o arquivo solto e apagado (a imagem ja esta na folha). Grava ao final. Devolve quantas entraram.
     */
    public int importLoose() throws IOException {
        File[] fs = loose(dir);
        int n = 0;
        for (File f : fs) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b == null) continue;
            int idx;
            try { idx = add(b); } finally { b.recycle(); }
            if (!f.delete()) throw new IOException("nao consegui apagar " + f.getName() + " (ja entrou como SPR_" + idx + ")");
            n++;
        }
        if (n > 0) commit();
        return n;
    }
}
