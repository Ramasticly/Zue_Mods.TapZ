package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Lista de sprites (SPR_0, SPR_1...) de uma pasta: as folhas ficam intactas no disco, aqui elas aparecem cortadas pelo CNV.
 * Modo gerenciar: adicionar, substituir, remover, mudar o recorte e o indice. Modo escolher: toque devolve o indice.
 */
final class SpriteListScreen {
    private SpriteListScreen() { }

    /** Escolha na lista: uma sprite (troca a imagem do frame) ou quadros de uma imagem animada (viram frames novos). */
    interface Picker {
        void onPick(int image);
        void onPickFrames(int[] images, int[] delaysMs);
    }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, HI = 0xFF21402C;

    /** {@code picker} null = gerenciar; senao escolher. {@code selected} = indice atual (destacado), -1 se nenhum. */
    static void show(final Activity a, final String title, final CharAssets ca, final int selected, final Picker picker, final Runnable changed) {
        final SpriteLib lib = ca.lib();
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(a, 12), 0, 0);
        d.setContentView(root);

        final TextView ti = text(a, "", 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 2));
        root.addView(ti);
        final TextView sub = text(a, "", 11, DIM, false);
        sub.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 8));
        root.addView(sub);
        final TextView badBanner = text(a, "", 11, 0xFFFF6B6B, true);
        badBanner.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        badBanner.setVisibility(View.GONE);
        root.addView(badBanner);

        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final java.util.TreeSet<Integer> sel = new java.util.TreeSet<Integer>();      // sprites marcadas (acoes em massa)
        final Runnable[] selChanged = {null};
        final ArrayList<int[]> rows = new ArrayList<int[]>();          // {tipo, indice}: 0 sprite, 1 grupo recolhido, 2 cabecalho de grupo aberto
        final java.util.HashSet<Integer> open = new java.util.HashSet<Integer>();
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return rows.size(); }
            @Override public Object getItem(int i) { return rows.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                int type = rows.get(pos)[0], i = rows.get(pos)[1];
                SpriteGroups.Group g = type == 0 ? null : lib.groups.startingAt(i);
                boolean inGroup = type == 0 && lib.groups.at(i) != null;
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, inGroup ? 28 : 12), dp(a, 6), dp(a, 12), dp(a, 6));
                if (type == 0 && i == selected) row.setBackgroundColor(HI);
                if (type == 2) row.setBackgroundColor(0xFF1B2A44);
                if (type != 2) {
                    ImageView iv = new ImageView(a);
                    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    iv.setBackgroundColor(0xFF0D0F13);
                    Bitmap tb = thumb(lib, thumbs, i);
                    if (tb != null) iv.setImageBitmap(tb);
                    row.addView(iv, new LinearLayout.LayoutParams(dp(a, 60), dp(a, 60)));
                }
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setPadding(dp(a, type == 2 ? 0 : 12), 0, 0, 0);
                if (type == 0) {
                    Cnv.Entry e = ca.cnv.byImage(i);
                    boolean empty = e == null || e.width <= 0 || e.height <= 0;
                    String why = empty ? null : lib.cutProblem(i);
                    t.setText("SPR_" + i + (i == selected ? "   \u2713 atual" : "") + "\n" + (empty ? "(vazia)"
                            : e.width + "x" + e.height + "  folha " + e.source + "  x " + e.x + "  y " + e.y) + (why != null ? "\n\u26A0 " + why : ""));
                    t.setTextColor(why != null ? 0xFFFF6B6B : empty ? DIM : i == selected ? OK : TEXT);
                } else if (type == 1) {
                    Cnv.Entry e = ca.cnv.byImage(i);
                    t.setText("GIF  " + g.name + "\nSPR_" + g.first + " a SPR_" + g.last() + "  \u00b7  " + framesText(g)
                            + (e != null && e.width > 0 ? "  \u00b7  " + e.width + "x" + e.height : "") + "  \u00b7  " + totalMs(g) + " ms");
                    t.setTextColor(ACCENT);
                    t.setTypeface(Typeface.DEFAULT_BOLD);
                } else {
                    t.setText("\u25BC  GIF  " + g.name + "  (" + framesText(g) + ") \u2014 toque para recolher");
                    t.setTextColor(ACCENT);
                }
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                if (picker == null && type != 2) {
                    // caixa de marcar (acoes em massa); GIF marca/desmarca todos os quadros
                    final int fi = i;
                    final boolean grp = type == 1;
                    final SpriteGroups.Group gg = g;
                    final android.widget.CheckBox cb = new I18nCheckBox(a);
                    boolean on;
                    if (grp) { on = true; for (int k = gg.first; k <= gg.last() && k < lib.count(); k++) if (lib.has(k) && !sel.contains(Integer.valueOf(k))) on = false; }
                    else on = sel.contains(Integer.valueOf(fi));
                    cb.setChecked(on);
                    cb.setFocusable(false);
                    cb.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            boolean now = cb.isChecked();
                            if (grp) { for (int k = gg.first; k <= gg.last() && k < lib.count(); k++) if (lib.has(k)) { if (now) sel.add(Integer.valueOf(k)); else sel.remove(Integer.valueOf(k)); } }
                            else if (now) sel.add(Integer.valueOf(fi)); else sel.remove(Integer.valueOf(fi));
                            if (selChanged[0] != null) selChanged[0].run();
                        }
                    });
                    row.addView(cb, new LinearLayout.LayoutParams(-2, -2));
                }
                return row;
            }
        };
        lv.setAdapter(ad);

        final Runnable refresh = new Runnable() {
            @Override public void run() {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
                rows.clear();
                for (int i = 0; i < lib.count(); i++) {
                    SpriteGroups.Group g = lib.groups.startingAt(i);
                    if (g == null) { rows.add(new int[]{0, i}); continue; }
                    if (open.contains(Integer.valueOf(g.first))) {
                        rows.add(new int[]{2, i});
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) rows.add(new int[]{0, k});
                    } else rows.add(new int[]{1, i});
                    i = Math.min(g.last(), lib.count() - 1);
                }
                ti.setText((picker == null ? "Sprites \u2014 " : "Escolher sprite \u2014 ") + title);
                sub.setText(lib.count() + " imagem(ns)  \u00b7  " + lib.groups.list.size() + " GIF(s)  \u00b7  " + lib.sheetCount() + " folha(s) PNG  \u00b7  escala " + lib.scale
                        + (picker == null ? "  \u00b7  toque para editar" : ""));
                final java.util.List<String> badCuts = lib.cutProblems(80);        // recorte que nao funciona: motivo exato (alerta copiavel)
                badBanner.setVisibility(badCuts.isEmpty() ? View.GONE : View.VISIBLE);
                if (!badCuts.isEmpty()) {
                    badBanner.setText(badCuts.size() + " sprite(s) com problema de recorte \u2014 toque para ver");
                    badBanner.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                        java.util.ArrayList<String> rep = new java.util.ArrayList<String>();
                        rep.add(lib.dir.getPath() + "  (escala " + lib.scale + ")");
                        rep.addAll(badCuts);
                        ErrorListDialog.show(a, "Erro de recorte", rep);
                    } });
                }
                java.util.Iterator<Integer> it = sel.iterator();
                while (it.hasNext()) { int k = it.next().intValue(); if (k >= lib.count() || !lib.has(k)) it.remove(); }
                if (selChanged[0] != null) selChanged[0].run();
                ad.notifyDataSetChanged();
            }
        };
        // aplica no disco, atualiza preview e lista
        final Runnable uiOnly = new Runnable() {
            @Override public void run() { ca.reloadSprites(); refresh.run(); if (changed != null) changed.run(); }   // recicla bitmaps: so na UI thread
        };
        uiOnlyR = uiOnly;
        final Runnable applied = new Runnable() {
            @Override public void run() {
                try { lib.commit(); } catch (Exception ex) { toast(a, "Erro ao gravar: " + ex.getMessage()); }
                ca.reloadSprites();
                refresh.run();
                if (changed != null) changed.run();
            }
        };

        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        final TextView addBtn = button(a, "+ ADICIONAR", new View.OnClickListener() {
            @Override public void onClick(View v) { openAdd(a, title, lib, applied, uiOnly, lv); }
        });
        bar.addView(addBtn);
        bar.addView(button(a, "OTIMIZAR", new View.OnClickListener() {
            @Override public void onClick(View v) { SpriteOptimize.menu(a, ca, lib, applied); }
        }), lpm(a, 8));
        bar.addView(button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }), lpm(a, 8));
        root.addView(bar);

        // barra das acoes em massa (aparece quando ha sprites marcadas)
        final LinearLayout selBar = new LinearLayout(a);
        selBar.setOrientation(LinearLayout.HORIZONTAL);
        selBar.setGravity(Gravity.CENTER_VERTICAL);
        selBar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        selBar.setVisibility(View.GONE);
        final TextView selCount = text(a, "", 12, ACCENT, true);
        selBar.addView(selCount, new LinearLayout.LayoutParams(0, -2, 1f));
        selBar.addView(button(a, "EDITAR FRAMES", new View.OnClickListener() { @Override public void onClick(View v) {
            SpriteMassDialogs.editFrames(a, ca, new ArrayList<Integer>(sel), applied);
        } }), lpm(a, 6));
        selBar.addView(button(a, "EXCLUIR", new View.OnClickListener() { @Override public void onClick(View v) {
            final ArrayList<Integer> list = new ArrayList<Integer>(sel);
            SpriteMassDialogs.confirmDelete(a, ca, lib, list, new Runnable() { @Override public void run() { sel.clear(); applied.run(); } });
        } }), lpm(a, 6));
        if (picker == null) root.addView(selBar);
        if (picker == null) d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override public boolean onKey(DialogInterface di, int key, android.view.KeyEvent ev) {
                if (key == android.view.KeyEvent.KEYCODE_BACK && !sel.isEmpty()) {
                    if (ev.getAction() == android.view.KeyEvent.ACTION_UP) {
                        sel.clear();
                        selChanged[0].run();
                        ad.notifyDataSetChanged();
                    }
                    return true;
                }
                return false;
            }
        });
        selChanged[0] = new Runnable() { @Override public void run() {
            selBar.setVisibility(sel.isEmpty() ? View.GONE : View.VISIBLE);
            addBtn.setVisibility(sel.isEmpty() ? View.VISIBLE : View.GONE);
            selCount.setText(sel.size() + " marcada(s)  (voltar limpa)");
        } };

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                int type = rows.get(pos)[0], idx = rows.get(pos)[1];
                if (picker == null && !sel.isEmpty() && type != 2) {
                    // com algo marcado, tocar na linha so marca/desmarca
                    if (type == 0) { if (!sel.remove(Integer.valueOf(idx))) sel.add(Integer.valueOf(idx)); }
                    else {
                        SpriteGroups.Group g = lib.groups.startingAt(idx);
                        boolean all = true;
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k) && !sel.contains(Integer.valueOf(k))) all = false;
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k)) { if (all) sel.remove(Integer.valueOf(k)); else sel.add(Integer.valueOf(k)); }
                    }
                    selChanged[0].run();
                    ad.notifyDataSetChanged();
                    return;
                }
                if (type == 2) { open.remove(Integer.valueOf(idx)); refresh.run(); return; }
                if (type == 1) {
                    SpriteGroups.Group g = lib.groups.startingAt(idx);
                    if (picker != null) pickGroup(a, ca, lib, g, picker, d);
                    else groupActions(a, ca, lib, g, open, applied, refresh);
                    return;
                }
                if (picker != null) { d.dismiss(); picker.onPick(idx); return; }
                actions(a, ca, lib, idx, applied);
            }
        });
        if (picker != null) {
            lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                    int type = rows.get(pos)[0], idx = rows.get(pos)[1];
                    if (type == 0) actions(a, ca, lib, idx, applied);
                    else if (type == 1) groupActions(a, ca, lib, lib.groups.startingAt(idx), open, applied, refresh);
                    return true;
                }
            });
        }
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) { for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle(); thumbs.clear(); }
        });
        refresh.run();
        if (lib.trimTrailing() > 0) applied.run();      // vazias no fim da tabela: descartadas ao abrir
        d.show();
        if (selected >= 0) {
            for (int r = 0; r < rows.size(); r++) if (rows.get(r)[0] == 0 && rows.get(r)[1] == selected) { lv.setSelection(Math.max(0, r - 2)); break; }
        }
    }

    /** "6 quadros" ou, com sprites reaproveitadas, "6 quadros (3 sprites)". */
    private static String framesText(SpriteGroups.Group g) {
        int s = g.distinctSprites();
        return g.frames() + " quadros" + (s != g.frames() ? " (" + s + " sprite" + (s == 1 ? "" : "s") + ")" : "");
    }

    private static int totalMs(SpriteGroups.Group g) {
        int t = 0;
        for (int v : g.delayMs) t += v;
        return t;
    }

    private static Bitmap thumb(SpriteLib lib, Map<Integer, Bitmap> thumbs, int i) {
        Bitmap tb = thumbs.get(Integer.valueOf(i));
        if (tb == null && lib.has(i)) {
            Bitmap full = lib.cut(i);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(i), tb);
            }
        }
        return tb;
    }

    // ---- GIF (grupo de sprites) ----

    /** ESCOLHER num GIF: modo GIF (todos os quadros, a animacao completa) ou modo PNG (so os quadros marcados). */
    private static void pickGroup(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g, final Picker picker, final Dialog list) {
        String msg = framesText(g) + " (SPR_" + g.first + " a SPR_" + g.last() + ").\n\n"
                + "MODO GIF: coloca todos os quadros na timeline, depois do frame atual, formando a animacao completa com os tempos do GIF.\n\n"
                + "MODO PNG: voce marca quais quadros quer, e so eles entram na timeline.";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(g.name).setMessage(msg)
                .setPositiveButton("MODO GIF", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface x, int w) {
                        // quadros sem sprite (removidos) saem e o anterior segura o tempo; quadros seguidos com a mesma sprite viram um so
                        int[] img = new int[g.frames()], dl = new int[g.frames()];
                        int j = -1, pending = 0;
                        for (int k = 0; k < g.frames(); k++) {
                            int sp = g.spriteAt(k), d = g.delayAt(k);
                            if (!lib.has(sp)) { if (j >= 0) dl[j] += d; else pending += d; }
                            else if (j >= 0 && img[j] == sp) dl[j] += d;
                            else { img[++j] = sp; dl[j] = d + pending; pending = 0; }
                        }
                        if (j < 0) { toast(a, "todos os quadros deste GIF estao vazios"); return; }
                        img = java.util.Arrays.copyOf(img, j + 1);
                        dl = java.util.Arrays.copyOf(dl, j + 1);
                        list.dismiss();
                        picker.onPickFrames(img, dl);
                    }
                })
                .setNeutralButton("MODO PNG", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface x, int w) { frameChooser(a, lib, g, picker, list); }
                })
                .setNegativeButton("CANCELAR", null).show();
    }

    /** Lista dos quadros do GIF com caixas de marcar. */
    private static void frameChooser(final Activity a, final SpriteLib lib, final SpriteGroups.Group g, final Picker picker, final Dialog list) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = text(a, "Quadros de " + g.name, 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 2));
        root.addView(ti);
        TextView hint = text(a, "Toque nos quadros que quer na timeline (entram na ordem da lista).", 11, DIM, false);
        hint.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 8));
        root.addView(hint);
        final boolean[] on = new boolean[g.frames()];
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final TextView ok = button(a, "ADICIONAR 0", null);
        final Runnable upd = new Runnable() {
            @Override public void run() {
                int n = 0;
                for (boolean b : on) if (b) n++;
                ok.setText("ADICIONAR " + n + " \u00c0 TIMELINE");
            }
        };
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return g.frames(); }
            @Override public Object getItem(int i) { return Integer.valueOf(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6));
                if (on[i]) row.setBackgroundColor(HI);
                ImageView iv = new ImageView(a);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setBackgroundColor(0xFF0D0F13);
                Bitmap tb = thumb(lib, thumbs, g.spriteAt(i));
                if (tb != null) iv.setImageBitmap(tb);
                row.addView(iv, new LinearLayout.LayoutParams(dp(a, 60), dp(a, 60)));
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setPadding(dp(a, 12), 0, 0, 0);
                t.setText((on[i] ? "\u2713  " : "") + "Quadro " + (i + 1) + "  (SPR_" + g.spriteAt(i) + ")\n" + g.delayAt(i) + " ms");
                t.setTextColor(on[i] ? OK : TEXT);
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) { on[pos] = !on[pos]; ad.notifyDataSetChanged(); upd.run(); }
        });
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        bar.addView(button(a, "TODOS", new View.OnClickListener() { @Override public void onClick(View v) { java.util.Arrays.fill(on, true); ad.notifyDataSetChanged(); upd.run(); } }));
        bar.addView(button(a, "NENHUM", new View.OnClickListener() { @Override public void onClick(View v) { java.util.Arrays.fill(on, false); ad.notifyDataSetChanged(); upd.run(); } }), lpm(a, 8));
        root.addView(bar);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 12));
        foot.addView(button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = 0;
                for (boolean b : on) if (b) n++;
                if (n == 0) { toast(a, "marque pelo menos um quadro"); return; }
                int[] img = new int[n], dl = new int[n];
                for (int i = 0, k = 0; i < g.frames(); i++) if (on[i]) { img[k] = g.spriteAt(i); dl[k++] = g.delayAt(i); }
                d.dismiss();
                list.dismiss();
                picker.onPickFrames(img, dl);
            }
        });
        foot.addView(ok, lpm(a, 8));
        root.addView(foot);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) { for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle(); thumbs.clear(); }
        });
        upd.run();
        d.show();
    }

    private static void groupActions(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g,
                                     final java.util.HashSet<Integer> open, final Runnable applied, final Runnable refresh) {
        String[] items = {"Editar os quadros um a um", "Otimizar GIF (tirar quadros repetidos)", "Desagrupar (viram sprites comuns)", "Remover o GIF inteiro"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(g.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) { open.add(Integer.valueOf(g.first)); refresh.run(); }
                        else if (which == 1) optimize(a, ca, lib, g, applied);
                        else if (which == 2) { lib.dissolve(g); applied.run(); }
                        else new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover " + g.name + "?")
                                .setMessage("As " + g.count + " sprites (SPR_" + g.first + " a SPR_" + g.last() + ") tem as coordenadas zeradas e o espaco na folha fica livre. Os frames do DAC que as usam passam a imagem -1.")
                                .setNegativeButton("CANCELAR", null)
                                .setPositiveButton("REMOVER", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d2, int w) {
                                        int n = 0;
                                        ArrayList<Integer> imgs = new ArrayList<Integer>();
                                        for (int i = g.first; i <= g.last(); i++) imgs.add(Integer.valueOf(i));
                                        java.util.TreeSet<Integer> anos = SpriteMassDialogs.anosUsing(ca, imgs);
                                        for (int i = g.first; i <= g.last(); i++) n += ca.clearImageUses(i);
                                        lib.removeGroup(g);
                                        String sv = SpriteMassDialogs.persist(ca, anos);
                                        applied.run();
                                        toast(a, "GIF removido" + (n > 0 ? "; " + n + " frame(s) do DAC ficaram com imagem -1" + sv : ""));
                                    }
                                }).show();
                    }
                }).setNegativeButton("FECHAR", null).show();
    }

    /** Otimizar GIF: analisa os quadros (com loading), mostra a previa de quais viram qual e deixa escolher a tolerancia. */
    private static void optimize(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Analisando " + g.name);
        final int total = g.frames();
        new Thread(new Runnable() {
            @Override public void run() {
                GifOptimizer.Analysis res = null;
                try {
                    res = lib.analyze(g, new SpriteLib.Step() {
                        @Override public void on(int done) { busy.set("Lendo quadros", done, total); }
                    });
                } catch (Throwable ex) { /* res nulo: aviso abaixo */ }
                busy.dismiss();
                final GifOptimizer.Analysis an = res;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (an == null) { toast(a, "Nao consegui analisar os quadros"); return; }
                        optimizePreview(a, ca, lib, g, an, applied);
                    }
                });
            }
        }).start();
    }

    private static void optimizePreview(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g,
                                        final GifOptimizer.Analysis an, final Runnable applied) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = text(a, "Otimizar " + g.name, 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 2));
        root.addView(ti);
        TextView hint = text(a, "Quadros iguais ou parecidos (em qualquer ponto da animacao) passam a usar uma so sprite. A animacao dura o mesmo. "
                + "Mais alto = so quadros quase identicos; mais baixo = otimizacao extrema.", 11, DIM, false);
        hint.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        root.addView(hint);
        final TextView tol = text(a, "", 14, ACCENT, true);
        tol.setPadding(dp(a, 14), 0, dp(a, 14), 0);
        root.addView(tol);
        final android.widget.SeekBar sb = new android.widget.SeekBar(a);
        sb.setMax(100 - GifOptimizer.MIN_PCT);
        sb.setProgress(95 - GifOptimizer.MIN_PCT);
        sb.setPadding(dp(a, 18), dp(a, 6), dp(a, 18), dp(a, 6));
        root.addView(sb);
        final TextView sum = text(a, "", 12, TEXT, false);
        sum.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        root.addView(sum);
        final int[][] repr = new int[1][];
        final java.util.ArrayList<Integer> shown = new java.util.ArrayList<Integer>();
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final TextView ok = button(a, "APLICAR", null);
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int p) { return shown.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View cv, ViewGroup parent) {
                int i = shown.get(p).intValue();                     // um item por sprite (o primeiro quadro que a usa)
                int r = repr[0][i];
                boolean changed = r >= 0 && an.sprite[r] != an.sprite[i];
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6));
                if (changed) row.setBackgroundColor(HI);
                row.addView(thumbView(a, lib, thumbs, an.sprite[i]), new LinearLayout.LayoutParams(dp(a, 56), dp(a, 56)));
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setPadding(dp(a, 10), 0, dp(a, 6), 0);
                String uses = usedBy(an, i);
                if (r < 0) { t.setText("SPR_" + an.sprite[i] + "\nvazia (ignorada)"); t.setTextColor(DIM); }
                else if (changed) {
                    t.setText("SPR_" + an.sprite[i] + "  (" + uses + ")\nigual \u00e0 SPR_" + an.sprite[r] + " (" + an.score[r][i] + "%) \u2192 usa SPR_" + an.sprite[r]);
                    t.setTextColor(OK);
                } else { t.setText("SPR_" + an.sprite[i] + "  (" + uses + ")\nfica"); t.setTextColor(TEXT); }
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                if (changed) {
                    TextView arrow = text(a, "\u2192", 18, OK, true);
                    row.addView(arrow);
                    row.addView(thumbView(a, lib, thumbs, an.sprite[r]), new LinearLayout.LayoutParams(dp(a, 56), dp(a, 56)));
                }
                return row;
            }
        };
        lv.setAdapter(ad);
        final Runnable upd = new Runnable() {
            @Override public void run() {
                int pct = GifOptimizer.MIN_PCT + sb.getProgress();
                tol.setText("Semelhan\u00e7a m\u00ednima: " + pct + "%" + (pct == 100 ? "  (so identicos)" : ""));
                repr[0] = GifOptimizer.match(an, pct);
                shown.clear();
                for (int k = 0; k < an.n; k++) if (an.first[k] == k) shown.add(Integer.valueOf(k));
                int rem = GifOptimizer.removedCount(an, repr[0]), valid = GifOptimizer.distinctSprites(an);
                sum.setText(rem == 0 ? "Nenhuma sprite a menos (" + valid + " sprites, " + an.n + " quadros)." : rem + " de " + valid + " sprites seriam dispensadas \u2192 ficam " + (valid - rem) + " sprites para " + an.n + " quadros.");
                ok.setEnabled(rem > 0);
                ok.setAlpha(rem > 0 ? 1f : 0.4f);
                ad.notifyDataSetChanged();
            }
        };
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean fromUser) { upd.run(); }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) { }
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 12));
        foot.addView(button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final int[] rp = repr[0];
                if (GifOptimizer.removedCount(an, rp) == 0) return;
                d.dismiss();
                final BusyDialog busy = BusyDialog.show(a, "Otimizando " + g.name);
                busy.set("Reaproveitando quadros", 0, 0);
                new Thread(new Runnable() {
                    @Override public void run() {
                        java.util.List<int[]> map = null;
                        try {
                            map = lib.applyReuse(g, an, rp);
                            busy.set("Gravando as folhas de sprites...", 0, 0);
                            lib.commit();
                        } catch (Throwable ex) { /* o resultado vazio avisa */ }
                        busy.dismiss();
                        final java.util.List<int[]> fm = map;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                int uses = 0;
                                java.util.TreeSet<Integer> anos = new java.util.TreeSet<Integer>();
                                if (fm != null) {
                                    ArrayList<Integer> from = new ArrayList<Integer>();
                                    for (int[] p : fm) from.add(Integer.valueOf(p[0]));
                                    anos = SpriteMassDialogs.anosUsing(ca, from);
                                    for (int[] p : fm) uses += ca.remapImageUses(p[0], p[1]);
                                }
                                String sv = SpriteMassDialogs.persist(ca, anos);
                                applied.run();
                                int n = fm == null ? 0 : fm.size();
                                toast(a, n + " sprite(s) liberada(s)" + (uses > 0 ? "; " + uses + " frame(s) do DAC passaram a usar a sprite que ficou" + sv : ""));
                            }
                        });
                    }
                }).start();
            }
        });
        foot.addView(ok, lpm(a, 8));
        root.addView(foot);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) { for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle(); thumbs.clear(); }
        });
        upd.run();
        d.show();
    }

    /** "quadro 3" / "quadros 1, 4, 6": em quais quadros do GIF a sprite do quadro i aparece. */
    private static String usedBy(GifOptimizer.Analysis an, int i) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (int k = 0; k < an.n; k++) {
            if (an.sprite[k] != an.sprite[i]) continue;
            n++;
            if (n <= 6) sb.append(n > 1 ? ", " : "").append(k + 1);
        }
        if (n > 6) sb.append("\u2026 +").append(n - 6);
        return (n == 1 ? "quadro " : "quadros ") + sb;
    }

    private static ImageView thumbView(Activity a, SpriteLib lib, Map<Integer, Bitmap> thumbs, int sprite) {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        Bitmap tb = thumb(lib, thumbs, sprite);
        if (tb != null) iv.setImageBitmap(tb);
        return iv;
    }

    // ---- acoes de uma sprite ----

    private static void actions(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        String[] items = {"Substituir imagem", "Mostrar usos", "Mudar recorte na folha", "Mudar índice (só no CNV)", "Hurtbox / hitbox / efeito dos frames (com prévia)", "Remover da lista"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("SPR_" + idx)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) replace(a, lib, idx, applied);
                        else if (which == 1) showUses(a, ca, idx);
                        else if (which == 2) crop(a, ca, lib, idx, applied);
                        else if (which == 3) reindex(a, lib, idx, applied);
                        else if (which == 4) { ArrayList<Integer> one = new ArrayList<Integer>(); one.add(Integer.valueOf(idx)); SpriteBoxEditor.show(a, ca, one, applied); }
                        else remove(a, ca, lib, idx, applied);
                    }
                }).setNegativeButton("FECHAR", null).show();
    }

    /** "Mostrar usos": onde a sprite aparece, uma linha por ANO ("Ano 3, Frames 1, 4 e 7"). */
    private static void showUses(Activity a, CharAssets ca, int idx) {
        String text = SpriteUses.text(ca.dac, idx);
        TextView tv = text(a, text.isEmpty() ? "Nenhum Frame de nenhuma ANO usa esta sprite." : text, 14, TEXT, false);
        tv.setPadding(dp(a, 20), dp(a, 10), dp(a, 20), dp(a, 10));
        tv.setTextIsSelectable(true);
        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        sv.addView(tv);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Usos de SPR_" + idx).setView(sv).setPositiveButton("OK", null).show();
    }

    private static Runnable uiOnlyR;

    /** + ADICIONAR: seletor de arquivos (imagens e CNV de outros pacs); VOLTAR da escolha de sprites do CNV reabre este seletor na pasta do CNV. */
    private static void openAdd(final Activity a, final String title, final SpriteLib lib, final Runnable applied, final Runnable uiOnly, final ListView lv) {
        FilePicker.show(a, "Adicionar sprites a " + title, true, FilePicker.IMAGES_CNV, new FilePicker.Listener() {
            @Override public void onPicked(List<File> files) {
                importFiles(a, lib, files, applied, lv);
            }
        }, new FilePicker.CnvListener() {
            @Override public void onCnv(File cnv) {
                PacSpritePicker.show(a, cnv, lib, uiOnly, 0, new Runnable() {
                    @Override public void run() { openAdd(a, title, lib, applied, uiOnly, lv); }
                }, -1);
            }
        });
    }

    private static void replace(final Activity a, final SpriteLib lib, final int idx, final Runnable applied) {
        FilePicker.show(a, "Nova imagem para SPR_" + idx, false, FilePicker.IMAGES_CNV, new FilePicker.Listener() {
            @Override public void onPicked(final List<File> files) {
                final BusyDialog busy = BusyDialog.show(a, "Abrindo imagem");
                busy.set(files.get(0).getName(), 0, 0);
                new Thread(new Runnable() {
                    @Override public void run() {
                        ImageImport.prog = new ImageImport.Prog() {
                            @Override public void on(String what, int done, int total) { busy.set(files.get(0).getName() + "\n" + what, done, total); }
                        };
                        ImageImport.Loaded ld0 = null;
                        String err = null;
                        try { ld0 = ImageImport.load(files.get(0)); }
                        catch (Throwable t) { err = t.getMessage(); }
                        ImageImport.prog = null;
                        busy.dismiss();
                        final ImageImport.Loaded ld = ld0;
                        final String fe = err;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() { afterReplace(a, lib, idx, applied, files.get(0), ld, fe); }
                        });
                    }
                }).start();
            }
        }, new FilePicker.CnvListener() {      // tocar num .cnv: escolher UMA sprite dele para substituir
            @Override public void onCnv(File cnv) {
                PacSpritePicker.show(a, cnv, lib, uiOnlyR, 0, new Runnable() {
                    @Override public void run() { replace(a, lib, idx, applied); }
                }, idx);
            }
        });
    }

    private static void afterReplace(final Activity a, final SpriteLib lib, final int idx, final Runnable applied, File file,
                                     final ImageImport.Loaded ld, String err) {
        if (ld == null) { toast(a, file.getName() + ": " + err); return; }
        final Runnable go = new Runnable() {
            @Override public void run() {
                final BusyDialog busy = BusyDialog.show(a, "Substituindo sprite");
                busy.set("Gravando as folhas de sprites...", 0, 0);
                new Thread(new Runnable() {
                    @Override public void run() {
                        String err = null;
                        try { lib.replace(idx, ld.frames.get(0)); lib.commit(); } catch (Exception ex) { err = ex.getMessage(); }
                        recycle(ld);
                        busy.dismiss();
                        final String fe = err;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (fe != null) toast(a, "Erro: " + fe);
                                uiOnlyR.run();
                            }
                        });
                    }
                }).start();
            }
        };
        if (ld.notice == null) { go.run(); return; }
        String msg = file.getName() + ":\n" + ld.notice + (ld.animated() ? "\n\nAo substituir so o primeiro quadro e usado." : "");
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Converter imagem").setMessage(msg)
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { recycle(ld); } })
                .setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { go.run(); } })
                .setOnCancelListener(new DialogInterface.OnCancelListener() { @Override public void onCancel(DialogInterface x) { recycle(ld); } })
                .show();
    }

    private static void recycle(ImageImport.Loaded ld) {
        for (Bitmap b : ld.frames) if (b != null && !b.isRecycled()) b.recycle();
        ld.frames.clear();
    }

    /** Abre cada arquivo (convertendo se preciso), avisa das conversoes e adiciona; imagem animada vira varias sprites seguidas. */
    private static void importFiles(final Activity a, final SpriteLib lib, final List<File> files, final Runnable applied, final ListView lv) {
        final BusyDialog busy = BusyDialog.show(a, "Convertendo imagens");
        new Thread(new Runnable() {
            @Override public void run() {
                final ArrayList<ImageImport.Loaded> ok = new ArrayList<ImageImport.Loaded>();
                final StringBuilder fail = new StringBuilder();
                int frames = 0;
                final int n = files.size();
                for (int i = 0; i < n; i++) {
                    final File f = files.get(i);
                    final int fi = i;
                    ImageImport.prog = new ImageImport.Prog() {
                        @Override public void on(String what, int done, int total) {
                            busy.set(f.getName() + "\n" + what + (total > 0 ? " " + done + "/" + total : " " + done), fi, n);
                        }
                    };
                    busy.set(f.getName(), i, n);
                    try {
                        ImageImport.Loaded ld = ImageImport.load(f);
                        ok.add(ld);
                        frames += ld.frames.size();
                    } catch (Throwable t) {
                        fail.append("\u2022 ").append(f.getName()).append(": ").append(t.getMessage()).append('\n');
                    }
                }
                ImageImport.prog = null;
                busy.dismiss();
                final int totalFrames = frames;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() { afterImport(a, lib, ok, fail, totalFrames, uiOnlyR, lv); }
                });
            }
        }).start();
    }

    /** Depois de abrir os arquivos: avisa das conversoes e pergunta; confirmando, grava as sprites em segundo plano com progresso. */
    private static void afterImport(final Activity a, final SpriteLib lib, final ArrayList<ImageImport.Loaded> ok, StringBuilder fail,
                                    int frames, final Runnable applied, final ListView lv) {
        if (ok.isEmpty()) { toast(a, "Nenhuma imagem aberta.\n" + fail); return; }
        final int first = lib.count();
        final int total = frames;
        final Runnable go = new Runnable() {
            @Override public void run() {
                final BusyDialog busy = BusyDialog.show(a, "Adicionando sprites");
                new Thread(new Runnable() {
                    @Override public void run() {
                        int added = 0, bad = 0;
                        for (ImageImport.Loaded ld : ok) {
                            busy.set(ld.file.getName(), added + bad, total);
                            if (ld.animated()) {
                                final int base = added + bad;
                                final String nm = ld.file.getName();
                                try {
                                    lib.addAnimation(nm, ld.frames, ld.delays, new SpriteLib.Step() {
                                        @Override public void on(int done) { busy.set(nm, base + done, total); }
                                    });
                                    added += ld.frames.size();
                                } catch (Exception ex) { bad += ld.frames.size(); }
                            } else {
                                for (Bitmap b : ld.frames) {
                                    try { lib.add(b); added++; } catch (Exception ex) { bad++; }
                                    busy.set(ld.file.getName(), added + bad, total);
                                }
                            }
                            recycle(ld);
                            busy.set(ld.file.getName(), added + bad, total);
                        }
                        busy.set("Gravando as folhas de sprites...", 0, 0);     // comprime os PNGs e grava o CNV (e o que mais pesa)
                        try { lib.commit(); } catch (Exception ex) { /* o applied tenta de novo e mostra o erro */ }
                        busy.dismiss();
                        final int fa = added, fb = bad;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                applied.run();
                                if (fa > 0) lv.setSelection(first);
                                toast(a, fa + " sprite(s) adicionada(s)" + (fa > 0 ? " (SPR_" + first + " a SPR_" + (first + fa - 1) + ")" : "") + (fb > 0 ? ", " + fb + " falharam" : "")
                                        + (lib.downscaled > 0 ? ". " + lib.downscaled + " reduzida(s) para no maximo " + SpriteLib.MAX_SIDE + " px" : ""));
                                lib.downscaled = 0;
                            }
                        });
                    }
                }).start();
            }
        };
        StringBuilder msg = new StringBuilder();
        for (ImageImport.Loaded ld : ok) {
            if (ld.notice != null) msg.append("\u2022 ").append(ld.file.getName()).append(": ").append(ld.notice).append("\n\n");
        }
        if (fail.length() > 0) msg.append("Nao abriu:\n").append(fail);
        if (msg.length() == 0) { go.run(); return; }
        msg.append(frames).append(" sprite(s) serao criadas, a partir de SPR_").append(first).append('.');
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Converter imagens").setMessage(msg.toString())
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface x, int w) { for (ImageImport.Loaded ld : ok) recycle(ld); }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface x) { for (ImageImport.Loaded ld : ok) recycle(ld); }
                })
                .setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { go.run(); } })
                .show();
    }

    private static void remove(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        ArrayList<Integer> one = new ArrayList<Integer>();
        one.add(Integer.valueOf(idx));
        SpriteMassDialogs.confirmDelete(a, ca, lib, one, applied);
    }

    private static void reindex(final Activity a, final SpriteLib lib, final int idx, final Runnable applied) {
        final EditText et = new EditText(a);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(idx));
        et.setSelectAllOnFocus(true);
        et.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), dp(a, 12));
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Novo índice de SPR_" + idx)
                .setMessage("A sprite vai para o índice digitado e a que estava la vem para SPR_" + idx + " (troca de lugar). So o CNV muda: as folhas PNG continuam iguais e o DAC continua apontando para os mesmos numeros.")
                .setView(et).setNegativeButton("CANCELAR", null)
                .setPositiveButton("MUDAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) {
                        int to;
                        try { to = Integer.parseInt(et.getText().toString().trim()); } catch (NumberFormatException e) { toast(a, "numero invalido"); return; }
                        if (to < 0 || to > 4000) { toast(a, "indice fora do limite"); return; }
                        lib.swap(idx, to);
                        applied.run();
                    }
                }).show();
    }

    // ---- recorte ----

    /** Folha com o retangulo do recorte desenhado por cima. */
    private static final class CropView extends View {
        Bitmap sheet;
        int x, y, w, h, scale = 1;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        CropView(Activity a) { super(a); }
        @Override protected void onDraw(Canvas c) {
            c.drawColor(0xFF0D0F13);
            if (sheet == null) return;
            float s = Math.min(getWidth() / (float) sheet.getWidth(), getHeight() / (float) sheet.getHeight());
            p.setFilterBitmap(false);
            p.setColor(0xFF2A2F3A);
            c.drawRect(0, 0, sheet.getWidth() * s, sheet.getHeight() * s, p);
            c.drawBitmap(sheet, null, new android.graphics.RectF(0, 0, sheet.getWidth() * s, sheet.getHeight() * s), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, getResources().getDisplayMetrics().density));
            p.setColor(0xFFFF4D4D);
            c.drawRect(x * scale * s, y * scale * s, (x + w) * scale * s, (y + h) * scale * s, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    private static void crop(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        Cnv.Entry e0 = ca.cnv.byImage(idx);
        final int[] v = {e0.source, e0.x, e0.y, e0.width, e0.height};
        final String[] names = {"folha", "x", "y", "largura", "altura"};
        final EditText[] ets = new EditText[5];
        final CropView cv = new CropView(a);
        cv.scale = lib.scale;
        final Runnable sync = new Runnable() {
            @Override public void run() {
                cv.sheet = lib.sheet(Math.max(0, Math.min(v[0], lib.sheetCount() - 1)));
                cv.x = v[1]; cv.y = v[2]; cv.w = v[3]; cv.h = v[4];
                cv.invalidate();
            }
        };
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 14), dp(a, 8), dp(a, 14), dp(a, 4));
        box.addView(cv, new LinearLayout.LayoutParams(-1, dp(a, 220)));
        box.addView(text(a, "Valores logicos do CNV (x" + lib.scale + " em pixels). Os pixels da folha nao se mexem: so o recorte muda.", 11, DIM, false), lpt(a, 6));
        for (int k = 0; k < 5; k++) {
            final int kk = k;
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView lab = text(a, names[k], 13, DIM, false);
            row.addView(lab, new LinearLayout.LayoutParams(dp(a, 70), -2));
            TextView minus = button(a, "−", null);
            final EditText et = new EditText(a);
            ets[k] = et;
            et.setText(String.valueOf(v[k]));
            et.setInputType(InputType.TYPE_CLASS_NUMBER);
            et.setSingleLine(true);
            et.setGravity(Gravity.CENTER);
            et.setTextColor(TEXT);
            et.setTypeface(Typeface.MONOSPACE);
            TextView plus = button(a, "+", null);
            final Runnable set = new Runnable() {
                @Override public void run() {
                    try { v[kk] = Math.max(0, Integer.parseInt(et.getText().toString().trim())); } catch (NumberFormatException ex) { et.setText(String.valueOf(v[kk])); }
                    sync.run();
                }
            };
            minus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { v[kk] = Math.max(0, v[kk] - 1); et.setText(String.valueOf(v[kk])); sync.run(); } });
            plus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { v[kk]++; et.setText(String.valueOf(v[kk])); sync.run(); } });
            et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override public boolean onEditorAction(TextView t, int act, android.view.KeyEvent ev) { set.run(); return false; }
            });
            et.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View x, boolean has) { if (!has) set.run(); } });
            row.addView(minus);
            row.addView(et, new LinearLayout.LayoutParams(dp(a, 90), -2));
            row.addView(plus);
            box.addView(row, lpt(a, 2));
        }
        sync.run();
        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        sv.addView(box);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Recorte de SPR_" + idx).setView(sv)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("APLICAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) {
                        for (EditText et : ets) et.clearFocus();
                        lib.setCrop(idx, v[0], v[1], v[2], v[3], v[4]);
                        applied.run();
                    }
                }).show();
    }

    // ---- pecas ----

    private static Bitmap decode(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeFile(f.getPath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    static void toast(Activity a, String s) { I18nUi.toast(a, s, android.widget.Toast.LENGTH_LONG).show(); }

    static int dp(Activity a, int v) { return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f); }

    static LinearLayout.LayoutParams lpm(Activity a, int left) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(a, left), 0, 0, 0);
        return p;
    }

    private static LinearLayout.LayoutParams lpt(Activity a, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(a, top), 0, 0);
        return p;
    }

    static TextView text(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static TextView button(Activity a, String s, View.OnClickListener c) {
        TextView t = text(a, s, 12, TEXT, true);
        t.setPadding(dp(a, 14), dp(a, 9), dp(a, 14), dp(a, 9));
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setStroke(1, LINE);
        g.setCornerRadius(dp(a, 8));
        t.setBackground(g);
        if (c != null) t.setOnClickListener(c);
        return t;
    }
}
