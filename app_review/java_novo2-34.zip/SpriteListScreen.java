package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Lista de sprites (SPR_0, SPR_1...) de uma pasta: as folhas ficam intactas no disco, aqui elas aparecem cortadas pelo CNV.
 * Modo gerenciar: adicionar, substituir, remover, mudar o recorte e o indice. Modo escolher: toque devolve o indice.
 */
final class SpriteListScreen {
    private SpriteListScreen() { }

    /** Escolha na lista: uma sprite (troca a imagem do frame) ou quadros de uma imagem animada (viram frames novos). */
    interface Picker {
        void onPick(int image);
        void onPickFrames(int[] images, int[] delaysMs);
    }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, HI = 0xFF21402C, WARN_C = 0xFFFFB454;

    /** {@code picker} null = gerenciar; senao escolher. {@code selected} = indice atual (destacado), -1 se nenhum. */
    static void show(final Activity a, final String title, final CharAssets ca, final int selected, final Picker picker, final Runnable changed) {
        show(a, title, ca, selected, picker, changed, null);
    }

    /**
     * Como {@link #show}, mas com {@code excluded} nao nulo vira "so escolher uma sprite": sem + ADICIONAR / OTIMIZAR, sem acoes de edicao no toque longo e sem
     * limpar sprites vazias ao abrir (os indices nao mudam por baixo de quem esta escolhendo), e as sprites de {@code excluded} (as que saem / a origem) nao podem ser escolhidas.
     */
    static void show(final Activity a, final String title, final CharAssets ca, final int selected, final Picker picker, final Runnable changed, final Set<Integer> excluded) {
        show(a, title, ca, selected, picker, changed, excluded, null);
    }

    /**
     * Seletor de substituta com semelhanca: {@code scores} (indice -> nota 0..100 contra a sprite que sai) liga uma barra "Semelhanca minima" no topo. Em 0% mostra todas;
     * subindo (ate 90%) fica so o que passa da nota, em ordem decrescente de nota, cada linha com " · NN%".
     */
    static void show(final Activity a, final String title, final CharAssets ca, final int selected, final Picker picker, final Runnable changed, final Set<Integer> excluded,
                     final Map<Integer, Integer> scores) {
        show(a, title, ca, selected, picker, changed, excluded, scores, -1);
    }

    /** Como acima; {@code replacing} >= 0 mostra no topo uma miniatura pequena da sprite que sera substituida. */
    static void show(final Activity a, final String title, final CharAssets ca, final int selected, final Picker picker, final Runnable changed, final Set<Integer> excluded,
                     final Map<Integer, Integer> scores, final int replacing) {
        final SpriteLib lib0 = ca.lib();
        final boolean chooseOnly0 = excluded != null && picker != null;
        if (chooseOnly0 || lib0.isOrganized()) { showScreen(a, title, ca, selected, picker, changed, excluded, scores, replacing); return; }
        // ao abrir SPRITES: loading que apaga o que esta fora dos recortes, le os vaos das folhas e leva as sprites para as folhas do inicio; so depois a tela abre
        final BusyDialog busy = BusyDialog.show(a, "Organizando as folhas");
        new Thread(new Runnable() {
            @Override public void run() {
                SpriteLib.Organized res = null;
                String err = null;
                try {
                    res = lib0.organize(new SpriteLib.Progress() {
                        @Override public void on(String what, int done, int total) { busy.set(what, done, total); }
                    });
                    if (res.changed()) { busy.set("Gravando as folhas", 0, 0); lib0.commit(); lib0.dropSheetCache(); }
                } catch (Throwable ex) { err = String.valueOf(ex.getMessage()); }
                busy.dismiss();
                final SpriteLib.Organized r = res;
                final String e = err;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (r != null && r.changed()) {
                            ca.reloadSprites();
                            if (changed != null) changed.run();
                            java.util.ArrayList<String> parts = new java.util.ArrayList<String>();
                            if (r.moved > 0) parts.add(r.moved + " sprite(s) realocada(s)");
                            if (r.removedSheets > 0) parts.add(r.removedSheets + " folha(s) apagada(s)");
                            if (r.cleaned > 0) parts.add(r.cleaned + " folha(s) limpa(s)");
                            if (!parts.isEmpty()) {
                                StringBuilder sb = new StringBuilder();
                                for (String t : parts) { if (sb.length() > 0) sb.append(" \u00b7 "); sb.append(t); }
                                toast(a, sb.toString());
                            }
                        }
                        if (e != null) toast(a, "Erro ao organizar as folhas: " + e);
                        showScreen(a, title, ca, selected, picker, changed, excluded, scores, replacing);
                    }
                });
            }
        }).start();
    }

    /** Modo "varias": marcar uma ou mais sprites (na ordem do numero) e dar o time delas; ADICIONAR devolve {@code images} e o time. */
    interface MultiListener { void onPick(int[] images, AddSprites.Spec spec); }
    private static MultiListener pendingMulti;
    private static int lastMultiTime = 6;
    private static int lastMode = 0;                                           // CENTRAR, REESCALAR, PADRAO, DEFINIR (indice em AddSprites.MODES)
    private static final String[] MODE_HELP = {
            "CENTRAR: põe a sprite centrada (pés no chão), sem mudar o tamanho (usa o zoom do padrão).",
            "REESCALAR: muda o zoom para a altura da 1ª sprite do Parado e centra.",
            "PADRÃO: usa o padrão do Editar Frame de cada sprite.",
            "DEFINIR: você escolhe posição, RAZ, Hitbox e Hurtbox, só para os Frames adicionados."};
    private static final AddSprites.Define lastDefine = new AddSprites.Define();

    /** Lista de sprites do personagem para ESCOLHER varias de uma vez (Adicionar Sprite da timeline), com o campo Time (ticks) e o botao ADICIONAR N. */
    static void showMulti(Activity a, String title, CharAssets ca, Runnable changed, MultiListener l) {
        pendingMulti = l;
        show(a, title, ca, -1, new Picker() {
            @Override public void onPick(int image) { }
            @Override public void onPickFrames(int[] images, int[] delaysMs) { }
        }, changed);
    }

    private static void showScreen(final Activity a, final String title, final CharAssets ca, final int selected, final Picker picker, final Runnable changed, final Set<Integer> excluded,
                                   final Map<Integer, Integer> scores, final int replacing) {
        final MultiListener multi = pendingMulti;
        pendingMulti = null;
        final Runnable[] multiRefresh = {null};
        final boolean chooseOnly = excluded != null && picker != null;
        final int[] minPct = {0};
        final Runnable[] rebuild = {null};
        final SpriteLib lib = ca.lib();
        final int[] sortMode = {SpriteSort.NUMBER};          // ORDENAR: com uma ordem ativa a lista e plana (sem GIFs nem puxador)
        final int[][] sim = {null, null};                    // melhor nota e par de cada sprite (Mais parecidas), calculado sob demanda
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(a, 12), 0, 0);
        d.setContentView(root);

        final TextView ti = text(a, "", 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 2));
        root.addView(ti);
        final TextView sub = text(a, "", 11, DIM, false);
        sub.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 8));
        root.addView(sub);
        final TextView badBanner = text(a, "", 11, 0xFFFF6B6B, true);
        badBanner.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        badBanner.setVisibility(View.GONE);
        root.addView(badBanner);
        final ArrayList<Bitmap> stripBmps = new ArrayList<Bitmap>();
        if (chooseOnly && replacing >= 0) root.addView(replacingStrip(a, ca.lib(), replacing, stripBmps));

        if (chooseOnly && scores != null) {
            final TextView simLbl = text(a, "Semelhança mínima: 0%  (0% mostra todas; 90% só as quase idênticas)", 12, TEXT, false);
            simLbl.setPadding(dp(a, 14), dp(a, 2), dp(a, 14), 0);
            root.addView(simLbl);
            final android.widget.SeekBar simBar = new android.widget.SeekBar(a);
            simBar.setMax(90);
            simBar.setProgress(0);
            simBar.setPadding(dp(a, 18), dp(a, 4), dp(a, 18), dp(a, 8));
            simBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean fromUser) {
                    minPct[0] = p;
                    simLbl.setText("Semelhança mínima: " + p + "%  (0% mostra todas; 90% só as quase idênticas)");
                    if (rebuild[0] != null) rebuild[0].run();
                }
                @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
                @Override public void onStopTrackingTouch(android.widget.SeekBar s) { }
            });
            root.addView(simBar);
        }

        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final java.util.TreeSet<Integer> sel = new java.util.TreeSet<Integer>();      // sprites marcadas (acoes em massa)
        final ArrayList<Integer> pickOrder = new ArrayList<Integer>();      // modo multiplo: sprites na ORDEM em que foram marcadas (sel espelha, ordenado)
        final Runnable[] selChanged = {null};
        final ArrayList<int[]> rows = new ArrayList<int[]>();          // {tipo, indice}: 0 sprite, 1 grupo recolhido, 2 cabecalho de grupo aberto
        final java.util.HashSet<Integer> open = new java.util.HashSet<Integer>();
        final DragListView lv = new DragListView(a);
        final DragCtx dctx = new DragCtx(a, ca, lib);
        dctx.lv = lv; dctx.rows = rows; dctx.sel = sel; dctx.open = open;
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return rows.size(); }
            @Override public Object getItem(int i) { return rows.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                int type = rows.get(pos)[0], i = rows.get(pos)[1];
                SpriteGroups.Group g = type == 0 ? null : lib.groups.startingAt(i);
                boolean inGroup = type == 0 && lib.groups.at(i) != null && sortMode[0] == SpriteSort.NUMBER;
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, inGroup ? 28 : 12), dp(a, 6), dp(a, 12), dp(a, 6));
                if (type == 0 && i == selected) row.setBackgroundColor(HI);
                if (type == 2) row.setBackgroundColor(0xFF1B2A44);
                if (pos >= dctx.dragPos && dctx.dragPos >= 0 && pos < dctx.dragPos + dctx.dragRows) row.setAlpha(0.35f);      // a linha que esta sendo arrastada fica esmaecida (o fantasma segue o dedo)
                if (type != 2) {
                    ImageView iv = new ImageView(a);
                    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    iv.setBackgroundColor(0xFF0D0F13);
                    Bitmap tb = thumb(lib, thumbs, i);
                    if (tb != null) iv.setImageBitmap(tb);
                    final int previewIdx = i;
                    iv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { previewSprite(a, lib, previewIdx); } });      // previa flutuante
                    row.addView(iv, new LinearLayout.LayoutParams(dp(a, 60), dp(a, 60)));
                }
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setPadding(dp(a, type == 2 ? 0 : 12), 0, 0, 0);
                if (type == 0) {
                    Cnv.Entry e = ca.cnv.byImage(i);
                    boolean empty = e == null || e.width <= 0 || e.height <= 0;
                    String why = empty ? null : lib.cutProblem(i);
                    t.setText("SPR_" + i + (i == selected ? "   \u2713 atual" : "") + (sortMode[0] != SpriteSort.NUMBER ? "  \u00b7  " + sortInfo(sortMode[0], i, lib, ca, sim[0]) : "") + (chooseOnly && scores != null && scores.get(Integer.valueOf(i)) != null ? "  \u00b7  " + scores.get(Integer.valueOf(i)) + "%" : "") + "\n" + (empty ? "(vazia)"
                            : e.width + "x" + e.height + "  folha " + e.source + "  x " + e.x + "  y " + e.y) + (why != null ? "\n\u26A0 " + why : ""));
                    t.setTextColor(why != null ? 0xFFFF6B6B : empty || (chooseOnly && excluded.contains(Integer.valueOf(i))) ? DIM : i == selected ? OK : TEXT);
                    if (chooseOnly && excluded.contains(Integer.valueOf(i))) t.setText(t.getText() + "\n(não pode: é a que sai)");
                } else if (type == 1) {
                    Cnv.Entry e = ca.cnv.byImage(i);
                    t.setText("GIF  " + g.name + "\nSPR_" + g.first + " a SPR_" + g.last() + "  \u00b7  " + framesText(g)
                            + (e != null && e.width > 0 ? "  \u00b7  " + e.width + "x" + e.height : "") + "  \u00b7  " + totalMs(g) + " ms");
                    t.setTextColor(ACCENT);
                    t.setTypeface(Typeface.DEFAULT_BOLD);
                } else {
                    t.setText("\u25BC  GIF  " + g.name + "  (" + framesText(g) + ") \u2014 toque para recolher");
                    t.setTextColor(ACCENT);
                }
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                final int[] blk = picker == null && sortMode[0] == SpriteSort.NUMBER && !sel.isEmpty() ? SpriteBlock.contiguous(sel) : null;
                final boolean showHandle = picker == null && sortMode[0] == SpriteSort.NUMBER
                        && (sel.isEmpty() ? ((type == 0 && !inGroup) || type == 1) : (blk != null && i == blk[0] && type != 2));
                if (showHandle) {
                    // puxador "-": so reage a tocar e SEGURAR; ai a linha infla e da para arrastar (muda o slot). Sprite solta: ela; GIF ENCOLHIDO: todas as sprites juntas;
                    // GIF aberto (cabecalho e quadros): sem puxador
                    TextView handle = text(a, "\u2013", 24, DIM, true);
                    handle.setGravity(Gravity.CENTER);
                    handle.setMinimumWidth(dp(a, 48));
                    handle.setMinimumHeight(dp(a, 48));
                    handle.setOnTouchListener(new Dragger(dctx, row, i, blk != null ? blk[1] : type == 1 && g != null ? g.count : 1));      // marcadas seguidas: o puxador da primeira move o bloco
                    row.addView(handle, new LinearLayout.LayoutParams(-2, -2));
                }
                if (multi != null && type != 2) {
                    // selo da ordem da selecao (no lugar da caixa): 1, 2, 3...; a 1a fica destacada; GIF: \u2713 quando todos os quadros estao marcados
                    boolean all = true, any = false;
                    int num = 0;
                    if (type == 1) { for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k)) { if (pickOrder.contains(Integer.valueOf(k))) any = true; else all = false; } all = all && any; }
                    else { num = pickOrder.indexOf(Integer.valueOf(i)) + 1; any = num > 0; all = any; }
                    TextView badge = text(a, type == 1 ? (all ? "\u2713" : "") : (num > 0 ? String.valueOf(num) : ""), 14, num == 1 || (type == 1 && all) ? 0xFFFFFFFF : TEXT, true);
                    badge.setGravity(Gravity.CENTER);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.OVAL);
                    bg.setColor(num == 1 ? ACCENT : any ? 0xFF2A3350 : 0x00000000);
                    bg.setStroke(dp(a, 2), any ? ACCENT : LINE);
                    badge.setBackground(bg);
                    if (num == 1) row.setBackgroundColor(0xFF1F3354);
                    row.addView(badge, new LinearLayout.LayoutParams(dp(a, 34), dp(a, 34)));
                } else if (picker == null && type != 2) {
                    // caixa de marcar (acoes em massa); GIF marca/desmarca todos os quadros
                    final int fi = i;
                    final boolean grp = type == 1;
                    final SpriteGroups.Group gg = g;
                    final android.widget.CheckBox cb = new I18nCheckBox(a);
                    boolean on;
                    if (grp) { on = true; for (int k = gg.first; k <= gg.last() && k < lib.count(); k++) if (lib.has(k) && !sel.contains(Integer.valueOf(k))) on = false; }
                    else on = sel.contains(Integer.valueOf(fi));
                    cb.setChecked(on);
                    cb.setFocusable(false);
                    cb.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            boolean now = cb.isChecked();
                            if (grp) { for (int k = gg.first; k <= gg.last() && k < lib.count(); k++) if (lib.has(k)) { if (now) sel.add(Integer.valueOf(k)); else sel.remove(Integer.valueOf(k)); } }
                            else if (now) sel.add(Integer.valueOf(fi)); else sel.remove(Integer.valueOf(fi));
                            if (selChanged[0] != null) selChanged[0].run();
                        }
                    });
                    row.addView(cb, new LinearLayout.LayoutParams(-2, -2));
                }
                return row;
            }
        };
        lv.setAdapter(ad);

        // monta as linhas; com a barra de semelhanca acima de 0% vira uma lista plana so do que passa, da maior nota para a menor
        final Runnable buildRows = new Runnable() {
            @Override public void run() {
                rows.clear();
                if (chooseOnly && scores != null && minPct[0] > 0) {
                    final ArrayList<Integer> ok = new ArrayList<Integer>();
                    for (int i = 0; i < lib.count(); i++) {
                        Integer sc = scores.get(Integer.valueOf(i));
                        if (sc != null && sc.intValue() >= minPct[0] && lib.has(i) && !excluded.contains(Integer.valueOf(i))) ok.add(Integer.valueOf(i));
                    }
                    java.util.Collections.sort(ok, new java.util.Comparator<Integer>() {
                        @Override public int compare(Integer x, Integer y) {
                            int c = scores.get(y).intValue() - scores.get(x).intValue();
                            return c != 0 ? c : x.intValue() - y.intValue();
                        }
                    });
                    for (Integer i : ok) rows.add(new int[]{0, i.intValue()});
                    return;
                }
                if (picker == null && sortMode[0] != SpriteSort.NUMBER) {
                    int[][] wh = sizesOf(lib);
                    for (Integer i : SpriteSort.order(sortMode[0], lib.count(), wh[0], wh[1], SpriteSort.useCounts(ca.dac, lib.count()), sim[0], sim[1])) rows.add(new int[]{0, i.intValue()});
                    return;
                }
                for (int i = 0; i < lib.count(); i++) {
                    SpriteGroups.Group g = lib.groups.startingAt(i);
                    if (g == null) { rows.add(new int[]{0, i}); continue; }
                    if (open.contains(Integer.valueOf(g.first))) {
                        rows.add(new int[]{2, i});
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) rows.add(new int[]{0, k});
                    } else rows.add(new int[]{1, i});
                    i = Math.min(g.last(), lib.count() - 1);
                }
            }
        };
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
                buildRows.run();
                ti.setText(multi != null ? "Adicionar sprites \u2014 toque para marcar (1, 2, 3\u2026 = ordem) \u2014 " + title : (picker == null ? "Sprites \u2014 " : "Escolher sprite \u2014 ") + title);
                sub.setText(lib.count() + " imagem(ns)  \u00b7  " + lib.groups.list.size() + " GIF(s)  \u00b7  " + lib.sheetCount() + " folha(s) PNG  \u00b7  escala " + lib.scale
                        + (picker == null ? "  \u00b7  toque para editar" : ""));
                final java.util.List<String> badCuts = lib.cutProblems(80);        // recorte que nao funciona: motivo exato (alerta copiavel)
                badBanner.setVisibility(badCuts.isEmpty() ? View.GONE : View.VISIBLE);
                if (!badCuts.isEmpty()) {
                    badBanner.setText(badCuts.size() + " sprite(s) com problema de recorte \u2014 toque para ver");
                    badBanner.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                        java.util.ArrayList<String> rep = new java.util.ArrayList<String>();
                        rep.add(lib.dir.getPath() + "  (escala " + lib.scale + ")");
                        rep.addAll(badCuts);
                        ErrorListDialog.show(a, "Erro de recorte", rep);
                    } });
                }
                java.util.Iterator<Integer> it = sel.iterator();
                while (it.hasNext()) { int k = it.next().intValue(); if (k >= lib.count() || !lib.has(k)) it.remove(); }
                if (multi != null) pickOrder.retainAll(sel);
                if (selChanged[0] != null) selChanged[0].run();
                ad.notifyDataSetChanged();
            }
        };
        rebuild[0] = new Runnable() { @Override public void run() { buildRows.run(); ad.notifyDataSetChanged(); lv.setSelection(0); } };      // so as linhas: sem reciclar as miniaturas
        // aplica no disco, atualiza preview e lista
        final Runnable uiOnly = new Runnable() {
            @Override public void run() { ca.reloadSprites(); refresh.run(); if (changed != null) changed.run(); }   // recicla bitmaps: so na UI thread
        };
        uiOnlyR = uiOnly;
        final Runnable applied = new Runnable() {
            @Override public void run() {
                try { lib.commit(); } catch (Exception ex) { toast(a, "Erro ao gravar: " + ex.getMessage()); }
                ca.reloadSprites();
                sim[0] = null; sim[1] = null;          // a semelhanca guardada vale para a lista de antes
                refresh.run();
                if (changed != null) changed.run();
            }
        };

        dctx.ad = ad;
        dctx.applied = applied;
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        final TextView addBtn = button(a, "+ ADICIONAR", new View.OnClickListener() {
            @Override public void onClick(View v) { openAdd(a, title, lib, applied, uiOnly, lv); }
        });
        if (!chooseOnly) bar.addView(addBtn);
        final TextView optBtn = button(a, "OTIMIZAR", new View.OnClickListener() {
            @Override public void onClick(View v) { SpriteOptimize.menu(a, ca, lib, applied); }
        });
        if (!chooseOnly && multi == null) bar.addView(optBtn, lpm(a, 8));
        final TextView sortBtn = button(a, "ORDENAR", new View.OnClickListener() {
            @Override public void onClick(View v) {
                new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Ordenar sprites").setItems(SpriteSort.NAMES, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, final int which) {
                        final Runnable go = new Runnable() { @Override public void run() { sortMode[0] = which; sel.clear(); refresh.run(); } };
                        if (which == SpriteSort.SIMILAR && sim[0] == null) computeSimilar(a, lib, sim, go);
                        else go.run();
                    }
                }).setNegativeButton("FECHAR", null).show();
            }
        });
        if (picker == null) bar.addView(sortBtn, lpm(a, 8));
        final TextView closeBtn = button(a, "FECHAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } });
        bar.addView(closeBtn, lpm(a, 8));
        final LinearLayout[] multiBar = {null};
        if (multi != null) {
            // rodape da selecao: Time, USAR N IMAGEM(NS) e o botao de 4 modos (CENTRAR / REESCALAR / PADRAO / DEFINIR); montado aqui, adicionado depois da lista
            LinearLayout mb = new LinearLayout(a);
            mb.setOrientation(LinearLayout.VERTICAL);
            mb.setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 8));
            mb.setBackgroundColor(CARD);
            LinearLayout l1 = new LinearLayout(a);
            l1.setGravity(Gravity.CENTER_VERTICAL);
            l1.addView(text(a, "Time", 13, TEXT, false), new LinearLayout.LayoutParams(dp(a, 56), -2));
            final int[] timeV = {AddSprites.clampTime(lastMultiTime)};
            l1.addView(new Stepper(a).step(1).range(AddSprites.MIN_TIME, AddSprites.MAX_TIME).keyboard(new Stepper.OnValue() {
                @Override public void on(double v) { timeV[0] = AddSprites.clampTime((int) v); lastMultiTime = timeV[0]; }
            }).live(true).value(timeV[0]).view());
            mb.addView(l1);
            LinearLayout l2 = new LinearLayout(a);
            l2.setGravity(Gravity.CENTER_VERTICAL);
            l2.setPadding(0, dp(a, 6), 0, 0);
            final TextView defBtn = button(a, "DEFINIR\u2026", new View.OnClickListener() {
                @Override public void onClick(View v) { AddDefineDialog.show(a, lastDefine, null); }
            });
            final TextView modeBtn = button(a, "", null);
            final Runnable modeRefresh = new Runnable() { @Override public void run() {
                modeBtn.setText("MODO: " + AddSprites.MODE_NAMES[lastMode]);
                defBtn.setVisibility(AddSprites.MODES[lastMode] == AddSprites.Mode.DEFINE ? View.VISIBLE : View.GONE);
            } };
            modeBtn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    lastMode = (lastMode + 1) % AddSprites.MODES.length;
                    modeRefresh.run();
                    toast(a, MODE_HELP[lastMode]);
                    if (AddSprites.MODES[lastMode] == AddSprites.Mode.DEFINE) AddDefineDialog.show(a, lastDefine, null);
                }
            });
            modeRefresh.run();
            l2.addView(modeBtn);
            l2.addView(defBtn, lpm(a, 8));
            final TextView go = button(a, "USAR", new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (pickOrder.isEmpty()) { toast(a, "marque pelo menos uma sprite"); return; }
                    int[] imgs = new int[pickOrder.size()];
                    int k = 0;
                    for (Integer i : pickOrder) imgs[k++] = i.intValue();          // na ordem da marcacao
                    AddSprites.Spec spec = new AddSprites.Spec(AddSprites.MODES[lastMode], timeV[0], lastDefine.copy());
                    d.dismiss();
                    multi.onPick(imgs, spec);
                }
            });
            go.setTextColor(OK);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(0, -2, 1f);
            gp.setMargins(dp(a, 10), 0, 0, 0);
            l2.addView(go, gp);
            mb.addView(l2);
            multiRefresh[0] = new Runnable() { @Override public void run() { go.setText("USAR " + pickOrder.size() + " IMAGEM(NS)"); go.setAlpha(pickOrder.isEmpty() ? 0.4f : 1f); } };
            multiBar[0] = mb;
            multiRefresh[0].run();
        }
        root.addView(bar);

        // barra das acoes em massa (aparece quando ha sprites marcadas)
        final LinearLayout selBar = new LinearLayout(a);
        selBar.setOrientation(LinearLayout.HORIZONTAL);
        selBar.setGravity(Gravity.CENTER_VERTICAL);
        selBar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        selBar.setVisibility(View.GONE);
        final TextView selCount = text(a, "", 12, ACCENT, true);
        selBar.addView(selCount, new LinearLayout.LayoutParams(0, -2, 1f));
        selBar.addView(button(a, "EDITAR FRAME", new View.OnClickListener() { @Override public void onClick(View v) {
            SpriteMassDialogs.editFrames(a, ca, new ArrayList<Integer>(sel), applied);
        } }), lpm(a, 6));
        selBar.addView(button(a, "REESCALAR", new View.OnClickListener() { @Override public void onClick(View v) {
            rescale(a, ca, lib, new ArrayList<Integer>(sel), applied);
        } }), lpm(a, 6));
        selBar.addView(button(a, "EXCLUIR", new View.OnClickListener() { @Override public void onClick(View v) {
            final ArrayList<Integer> list = new ArrayList<Integer>(sel);
            SpriteMassDialogs.confirmDelete(a, ca, lib, list, new Runnable() { @Override public void run() { sel.clear(); applied.run(); } });
        } }), lpm(a, 6));
        if (picker == null) root.addView(selBar);
        if (picker == null) d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override public boolean onKey(DialogInterface di, int key, android.view.KeyEvent ev) {
                if (key == android.view.KeyEvent.KEYCODE_BACK && !sel.isEmpty()) {
                    if (ev.getAction() == android.view.KeyEvent.ACTION_UP) {
                        sel.clear();
                        selChanged[0].run();
                        ad.notifyDataSetChanged();
                    }
                    return true;
                }
                return false;
            }
        });
        final boolean[] wasEmpty = {true};
        selChanged[0] = new Runnable() { @Override public void run() {
            boolean empty = sel.isEmpty();
            selBar.setVisibility(empty ? View.GONE : View.VISIBLE);
            // com sprite(s) marcada(s): somem ADICIONAR, OTIMIZAR, FECHAR e o puxador das linhas
            addBtn.setVisibility(empty ? View.VISIBLE : View.GONE);
            optBtn.setVisibility(empty ? View.VISIBLE : View.GONE);
            closeBtn.setVisibility(empty ? View.VISIBLE : View.GONE);
            selCount.setText(sel.size() + " marcada(s)  (voltar limpa)");
            if (multiRefresh[0] != null) multiRefresh[0].run();
            if (picker == null) { wasEmpty[0] = empty; ad.notifyDataSetChanged(); }      // as linhas se refazem: o puxador some/volta e, com marcadas seguidas, fica so na primeira
        } };

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                int type = rows.get(pos)[0], idx = rows.get(pos)[1];
                if (multi != null && type != 2) {
                    // modo multiplo: tocar na linha marca/desmarca (a ordem e a da marcacao); a thumb abre a previa
                    if (type == 0) { if (!pickOrder.remove(Integer.valueOf(idx))) pickOrder.add(Integer.valueOf(idx)); }
                    else {
                        SpriteGroups.Group g = lib.groups.startingAt(idx);
                        boolean all = true;
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k) && !pickOrder.contains(Integer.valueOf(k))) all = false;
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k)) { if (all) pickOrder.remove(Integer.valueOf(k)); else if (!pickOrder.contains(Integer.valueOf(k))) pickOrder.add(Integer.valueOf(k)); }
                    }
                    sel.clear(); sel.addAll(pickOrder);
                    selChanged[0].run();
                    ad.notifyDataSetChanged();
                    return;
                }
                if (picker == null && !sel.isEmpty() && type != 2) {
                    // com algo marcado, tocar na linha so marca/desmarca
                    if (type == 0) { if (!sel.remove(Integer.valueOf(idx))) sel.add(Integer.valueOf(idx)); }
                    else {
                        SpriteGroups.Group g = lib.groups.startingAt(idx);
                        boolean all = true;
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k) && !sel.contains(Integer.valueOf(k))) all = false;
                        for (int k = g.first; k <= g.last() && k < lib.count(); k++) if (lib.has(k)) { if (all) sel.remove(Integer.valueOf(k)); else sel.add(Integer.valueOf(k)); }
                    }
                    selChanged[0].run();
                    ad.notifyDataSetChanged();
                    return;
                }
                if (type == 2) { open.remove(Integer.valueOf(idx)); refresh.run(); return; }
                if (chooseOnly) {
                    if (type == 1) { open.add(Integer.valueOf(lib.groups.startingAt(idx).first)); refresh.run(); return; }      // abre o GIF: escolhe-se uma sprite so
                    if (excluded.contains(Integer.valueOf(idx))) { toast(a, "SPR_" + idx + " é a sprite que sai: escolha outra."); return; }
                    if (!lib.has(idx)) { toast(a, "SPR_" + idx + " está vazia: escolha outra."); return; }
                    d.dismiss();
                    picker.onPick(idx);
                    return;
                }
                if (type == 1) {
                    SpriteGroups.Group g = lib.groups.startingAt(idx);
                    if (picker != null) pickGroup(a, ca, lib, g, picker, d);
                    else groupActions(a, ca, lib, g, open, applied, refresh);
                    return;
                }
                if (picker != null) { d.dismiss(); picker.onPick(idx); return; }
                actions(a, ca, lib, idx, applied);
            }
        });
        if (picker != null && !chooseOnly && multi == null) {
            lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                    int type = rows.get(pos)[0], idx = rows.get(pos)[1];
                    if (type == 0) actions(a, ca, lib, idx, applied);
                    else if (type == 1) groupActions(a, ca, lib, lib.groups.startingAt(idx), open, applied, refresh);
                    return true;
                }
            });
        }
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        if (multiBar[0] != null) root.addView(multiBar[0]);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
                for (Bitmap b : stripBmps) if (b != null && !b.isRecycled()) b.recycle();
                stripBmps.clear();
            }
        });
        refresh.run();
        if (!chooseOnly) {
            boolean fix = lib.trimTrailing() > 0;      // vazias no fim da tabela: descartadas ao abrir (a organizacao inicial ja roda antes, com loading)
            if (fix) applied.run();
        }
        d.show();
        if (selected >= 0) {
            for (int r = 0; r < rows.size(); r++) if (rows.get(r)[0] == 0 && rows.get(r)[1] == selected) { lv.setSelection(Math.max(0, r - 2)); break; }
        }
    }

    /** "6 quadros" ou, com sprites reaproveitadas, "6 quadros (3 sprites)". */
    private static String framesText(SpriteGroups.Group g) {
        int s = g.distinctSprites();
        return g.frames() + " quadros" + (s != g.frames() ? " (" + s + " sprite" + (s == 1 ? "" : "s") + ")" : "");
    }

    private static int totalMs(SpriteGroups.Group g) {
        int t = 0;
        for (int v : g.delayMs) t += v;
        return t;
    }

    /** Faixa fina com a miniatura pequena (48 dp) da sprite {@code idx} e a legenda {@code label}: so para o usuario saber o que esta substituindo. */
    static View previewStrip(Activity a, Bitmap bmp, String label) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(a, 14), dp(a, 2), dp(a, 14), dp(a, 6));
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        if (bmp != null) iv.setImageBitmap(bmp);
        row.addView(iv, new LinearLayout.LayoutParams(dp(a, 48), dp(a, 48)));
        TextView t = text(a, label, 12, WARN_C, true);
        t.setPadding(dp(a, 10), 0, 0, 0);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        return row;
    }

    /** Miniatura reduzida (~96 px) da sprite {@code idx}; null se nao tem desenho. Quem pede recicla. */
    static Bitmap smallCut(SpriteLib lib, int idx) {
        Bitmap full = lib.has(idx) ? lib.cut(idx) : null;
        if (full == null) return null;
        float sc = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
        if (sc >= 1f) return full;
        Bitmap b = Bitmap.createScaledBitmap(full, Math.max(1, Math.round(full.getWidth() * sc)), Math.max(1, Math.round(full.getHeight() * sc)), true);
        full.recycle();
        return b;
    }

    static String replacingLabel(SpriteLib lib, int idx) {
        int[] ls = lib.logicalSize(idx);
        return "Substituindo SPR_" + idx + (ls == null ? "" : "  \u00b7  " + ls[0] + "\u00d7" + ls[1]);
    }

    static View replacingStrip(Activity a, SpriteLib lib, int idx, ArrayList<Bitmap> keep) {
        Bitmap b = smallCut(lib, idx);
        if (b != null) keep.add(b);
        return previewStrip(a, b, replacingLabel(lib, idx));
    }

    private static Bitmap thumb(SpriteLib lib, Map<Integer, Bitmap> thumbs, int i) {
        Bitmap tb = thumbs.get(Integer.valueOf(i));
        if (tb == null && lib.has(i)) {
            Bitmap full = lib.cut(i);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(i), tb);
            }
        }
        return tb;
    }

    // ---- GIF (grupo de sprites) ----

    /** ESCOLHER num GIF: modo GIF (todos os quadros, a animacao completa) ou modo PNG (so os quadros marcados). */
    private static void pickGroup(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g, final Picker picker, final Dialog list) {
        String msg = framesText(g) + " (SPR_" + g.first + " a SPR_" + g.last() + ").\n\n"
                + "MODO GIF: coloca todos os quadros na timeline, depois do frame atual, formando a animacao completa com os tempos do GIF.\n\n"
                + "MODO PNG: voce marca quais quadros quer, e so eles entram na timeline.";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(g.name).setMessage(msg)
                .setPositiveButton("MODO GIF", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface x, int w) {
                        // quadros sem sprite (removidos) saem e o anterior segura o tempo; quadros seguidos com a mesma sprite viram um so
                        int[] img = new int[g.frames()], dl = new int[g.frames()];
                        int j = -1, pending = 0;
                        for (int k = 0; k < g.frames(); k++) {
                            int sp = g.spriteAt(k), d = g.delayAt(k);
                            if (!lib.has(sp)) { if (j >= 0) dl[j] += d; else pending += d; }
                            else if (j >= 0 && img[j] == sp) dl[j] += d;
                            else { img[++j] = sp; dl[j] = d + pending; pending = 0; }
                        }
                        if (j < 0) { toast(a, "todos os quadros deste GIF estao vazios"); return; }
                        img = java.util.Arrays.copyOf(img, j + 1);
                        dl = java.util.Arrays.copyOf(dl, j + 1);
                        list.dismiss();
                        picker.onPickFrames(img, dl);
                    }
                })
                .setNeutralButton("MODO PNG", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface x, int w) { frameChooser(a, lib, g, picker, list); }
                })
                .setNegativeButton("CANCELAR", null).show();
    }

    /** Lista dos quadros do GIF com caixas de marcar. */
    private static void frameChooser(final Activity a, final SpriteLib lib, final SpriteGroups.Group g, final Picker picker, final Dialog list) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = text(a, "Quadros de " + g.name, 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 2));
        root.addView(ti);
        TextView hint = text(a, "Toque nos quadros que quer na timeline (entram na ordem da lista).", 11, DIM, false);
        hint.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 8));
        root.addView(hint);
        final boolean[] on = new boolean[g.frames()];
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final TextView ok = button(a, "ADICIONAR 0", null);
        final Runnable upd = new Runnable() {
            @Override public void run() {
                int n = 0;
                for (boolean b : on) if (b) n++;
                ok.setText("ADICIONAR " + n + " \u00c0 TIMELINE");
            }
        };
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return g.frames(); }
            @Override public Object getItem(int i) { return Integer.valueOf(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6));
                if (on[i]) row.setBackgroundColor(HI);
                ImageView iv = new ImageView(a);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setBackgroundColor(0xFF0D0F13);
                Bitmap tb = thumb(lib, thumbs, g.spriteAt(i));
                if (tb != null) iv.setImageBitmap(tb);
                row.addView(iv, new LinearLayout.LayoutParams(dp(a, 60), dp(a, 60)));
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setPadding(dp(a, 12), 0, 0, 0);
                t.setText((on[i] ? "\u2713  " : "") + "Quadro " + (i + 1) + "  (SPR_" + g.spriteAt(i) + ")\n" + g.delayAt(i) + " ms");
                t.setTextColor(on[i] ? OK : TEXT);
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) { on[pos] = !on[pos]; ad.notifyDataSetChanged(); upd.run(); }
        });
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(a, 12), 0, dp(a, 12), dp(a, 8));
        bar.addView(button(a, "TODOS", new View.OnClickListener() { @Override public void onClick(View v) { java.util.Arrays.fill(on, true); ad.notifyDataSetChanged(); upd.run(); } }));
        bar.addView(button(a, "NENHUM", new View.OnClickListener() { @Override public void onClick(View v) { java.util.Arrays.fill(on, false); ad.notifyDataSetChanged(); upd.run(); } }), lpm(a, 8));
        root.addView(bar);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 12));
        foot.addView(button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = 0;
                for (boolean b : on) if (b) n++;
                if (n == 0) { toast(a, "marque pelo menos um quadro"); return; }
                int[] img = new int[n], dl = new int[n];
                for (int i = 0, k = 0; i < g.frames(); i++) if (on[i]) { img[k] = g.spriteAt(i); dl[k++] = g.delayAt(i); }
                d.dismiss();
                list.dismiss();
                picker.onPickFrames(img, dl);
            }
        });
        foot.addView(ok, lpm(a, 8));
        root.addView(foot);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) { for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle(); thumbs.clear(); }
        });
        upd.run();
        d.show();
    }

    private static void groupActions(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g,
                                     final java.util.HashSet<Integer> open, final Runnable applied, final Runnable refresh) {
        String[] items = {"Editar os quadros um a um", "Otimizar GIF (tirar quadros repetidos)", "Desagrupar (viram sprites comuns)", "Remover o GIF inteiro"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(g.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) { open.add(Integer.valueOf(g.first)); refresh.run(); }
                        else if (which == 1) optimize(a, ca, lib, g, applied);
                        else if (which == 2) { lib.dissolve(g); applied.run(); }
                        else new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover " + g.name + "?")
                                .setMessage("As " + g.count + " sprites (SPR_" + g.first + " a SPR_" + g.last() + ") tem as coordenadas zeradas e o espaco na folha fica livre. Os frames do DAC que as usam passam a imagem -1.\n\nO recorte de cada sprite é APAGADO da folha PNG (fica transparente) e folhas PNG que ficarem sem sprites são apagadas da pasta.")
                                .setNegativeButton("CANCELAR", null)
                                .setPositiveButton("REMOVER", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d2, int w) {
                                        int n = 0;
                                        ArrayList<Integer> imgs = new ArrayList<Integer>();
                                        for (int i = g.first; i <= g.last(); i++) imgs.add(Integer.valueOf(i));
                                        java.util.TreeSet<Integer> anos = SpriteMassDialogs.anosUsing(ca, imgs);
                                        for (int i = g.first; i <= g.last(); i++) n += ca.clearImageUses(i);
                                        lib.removeGroup(g);
                                        String sv = SpriteMassDialogs.persist(ca, anos);
                                        applied.run();
                                        toast(a, "GIF removido" + (n > 0 ? "; " + n + " frame(s) do DAC ficaram com imagem -1" + sv : ""));
                                    }
                                }).show();
                    }
                }).setNegativeButton("FECHAR", null).show();
    }

    /** Otimizar GIF: analisa os quadros (com loading), mostra a previa de quais viram qual e deixa escolher a tolerancia. */
    private static void optimize(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Analisando " + g.name);
        final int total = g.frames();
        new Thread(new Runnable() {
            @Override public void run() {
                GifOptimizer.Analysis res = null;
                try {
                    res = lib.analyze(g, new SpriteLib.Step() {
                        @Override public void on(int done) { busy.set("Lendo quadros", done, total); }
                    });
                } catch (Throwable ex) { /* res nulo: aviso abaixo */ }
                busy.dismiss();
                final GifOptimizer.Analysis an = res;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (an == null) { toast(a, "Nao consegui analisar os quadros"); return; }
                        optimizePreview(a, ca, lib, g, an, applied);
                    }
                });
            }
        }).start();
    }

    private static void optimizePreview(final Activity a, final CharAssets ca, final SpriteLib lib, final SpriteGroups.Group g,
                                        final GifOptimizer.Analysis an, final Runnable applied) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = text(a, "Otimizar " + g.name, 16, TEXT, true);
        ti.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 2));
        root.addView(ti);
        TextView hint = text(a, "Quadros iguais ou parecidos (em qualquer ponto da animacao) passam a usar uma so sprite. A animacao dura o mesmo. "
                + "Mais alto = so quadros quase identicos; mais baixo = otimizacao extrema.", 11, DIM, false);
        hint.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        root.addView(hint);
        final TextView tol = text(a, "", 14, ACCENT, true);
        tol.setPadding(dp(a, 14), 0, dp(a, 14), 0);
        root.addView(tol);
        final android.widget.SeekBar sb = new android.widget.SeekBar(a);
        sb.setMax(100 - GifOptimizer.MIN_PCT);
        sb.setProgress(95 - GifOptimizer.MIN_PCT);
        sb.setPadding(dp(a, 18), dp(a, 6), dp(a, 18), dp(a, 6));
        root.addView(sb);
        final TextView sum = text(a, "", 12, TEXT, false);
        sum.setPadding(dp(a, 14), 0, dp(a, 14), dp(a, 6));
        root.addView(sum);
        final int[][] repr = new int[1][];
        final java.util.ArrayList<Integer> shown = new java.util.ArrayList<Integer>();
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        // sprites vazias do GIF (sem desenho): saem no APLICAR
        final java.util.TreeSet<Integer> empties = new java.util.TreeSet<Integer>();
        for (int k = 0; k < an.n; k++) if (!an.valid[k]) empties.add(Integer.valueOf(an.sprite[k]));
        // ANTES | DEPOIS: o GIF tocando em laco, lado a lado
        final Map<Integer, Bitmap> big = new HashMap<Integer, Bitmap>();
        int maxDim = 1;
        for (int k = 0; k < an.n; k++) { int[] ls = an.valid[k] ? lib.logicalSize(an.sprite[k]) : null; if (ls != null) maxDim = Math.max(maxDim, Math.max(ls[0], ls[1]) * lib.scale); }
        final float bigScale = Math.min(1f, 200f / maxDim);
        final GifPlayView pvBefore = new GifPlayView(a), pvAfter = new GifPlayView(a);
        final TextView capBefore = text(a, "", 11, DIM, false), capAfter = text(a, "", 11, OK, false);
        {
            LinearLayout side = new LinearLayout(a);
            side.setOrientation(LinearLayout.HORIZONTAL);
            side.setPadding(dp(a, 12), dp(a, 2), dp(a, 12), dp(a, 6));
            int box = Math.min(dp(a, 160), (a.getResources().getDisplayMetrics().widthPixels - dp(a, 36)) / 2);
            for (int c2 = 0; c2 < 2; c2++) {
                LinearLayout col = new LinearLayout(a);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                col.addView(c2 == 0 ? pvBefore : pvAfter, new LinearLayout.LayoutParams(box, box));
                col.addView(c2 == 0 ? capBefore : capAfter);
                side.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            }
            root.addView(side);
        }
        final ListView lv = new ListView(a);
        lv.setDividerHeight(1);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        final TextView ok = button(a, "APLICAR", null);
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int p) { return shown.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View cv, ViewGroup parent) {
                int i = shown.get(p).intValue();                     // um item por sprite (o primeiro quadro que a usa)
                int r = repr[0][i];
                boolean changed = r >= 0 && an.sprite[r] != an.sprite[i];
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(a, 12), dp(a, 6), dp(a, 12), dp(a, 6));
                if (changed) row.setBackgroundColor(HI);
                row.addView(thumbView(a, lib, thumbs, an.sprite[i]), new LinearLayout.LayoutParams(dp(a, 56), dp(a, 56)));
                TextView t = new I18nTextView(a);
                t.setTextSize(13);
                t.setPadding(dp(a, 10), 0, dp(a, 6), 0);
                String uses = usedBy(an, i);
                if (r < 0) { t.setText("SPR_" + an.sprite[i] + "\nvazia \u2192 ser\u00e1 removida"); t.setTextColor(WARN_C); }
                else if (changed) {
                    t.setText("SPR_" + an.sprite[i] + "  (" + uses + ")\nigual \u00e0 SPR_" + an.sprite[r] + " (" + an.score[r][i] + "%) \u2192 usa SPR_" + an.sprite[r]);
                    t.setTextColor(OK);
                } else { t.setText("SPR_" + an.sprite[i] + "  (" + uses + ")\nfica"); t.setTextColor(TEXT); }
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                if (changed) {
                    TextView arrow = text(a, "\u2192", 18, OK, true);
                    row.addView(arrow);
                    row.addView(thumbView(a, lib, thumbs, an.sprite[r]), new LinearLayout.LayoutParams(dp(a, 56), dp(a, 56)));
                }
                return row;
            }
        };
        lv.setAdapter(ad);
        final Runnable upd = new Runnable() {
            @Override public void run() {
                int pct = GifOptimizer.MIN_PCT + sb.getProgress();
                tol.setText("Semelhan\u00e7a m\u00ednima: " + pct + "%" + (pct == 100 ? "  (so identicos)" : ""));
                repr[0] = GifOptimizer.match(an, pct);
                shown.clear();
                for (int k = 0; k < an.n; k++) if (an.first[k] == k) shown.add(Integer.valueOf(k));
                int rem = GifOptimizer.removedCount(an, repr[0]), valid = GifOptimizer.distinctSprites(an);
                String emp = empties.isEmpty() ? "" : " \u00b7 " + empties.size() + " vazia(s) sai(em)";
                sum.setText((rem == 0 ? "Nenhuma sprite a menos (" + valid + " sprites, " + an.n + " quadros)." : rem + " de " + valid + " sprites seriam dispensadas \u2192 ficam " + (valid - rem) + " sprites para " + an.n + " quadros.") + emp);
                boolean any = rem > 0 || !empties.isEmpty();
                ok.setEnabled(any);
                ok.setAlpha(any ? 1f : 0.4f);
                ad.notifyDataSetChanged();
                // DEPOIS: cada quadro mostra a sprite que passara a usar; quadros de sprite vazia somem da animacao
                java.util.ArrayList<Bitmap> fa = new java.util.ArrayList<Bitmap>();
                java.util.ArrayList<Integer> da = new java.util.ArrayList<Integer>();
                for (int k = 0; k < an.n; k++) {
                    if (!an.valid[k] || repr[0][k] < 0) continue;
                    fa.add(bigOf(lib, big, an.sprite[repr[0][k]], bigScale));
                    da.add(Integer.valueOf(g.delayAt(k)));
                }
                int[] dd = new int[da.size()];
                for (int q = 0; q < dd.length; q++) dd[q] = da.get(q).intValue();
                pvAfter.set(fa.toArray(new Bitmap[0]), dd);
                capAfter.setText("DEPOIS: " + (valid - rem) + " sprite(s) \u00b7 " + fa.size() + " quadro(s)");
            }
        };
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean fromUser) { upd.run(); }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) { }
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 12));
        foot.addView(button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final int[] rp = repr[0];
                if (GifOptimizer.removedCount(an, rp) == 0 && empties.isEmpty()) return;
                d.dismiss();
                final BusyDialog busy = BusyDialog.show(a, "Otimizando " + g.name);
                busy.set("Reaproveitando quadros", 0, 0);
                final int gFirst = g.first, gCount = g.count;
                new Thread(new Runnable() {
                    @Override public void run() {
                        int uses = 0, removed = 0, renum = 0;
                        java.util.TreeSet<Integer> anos = new java.util.TreeSet<Integer>();
                        String err = null;
                        try {
                            java.util.List<int[]> fm = lib.applyReuse(g, an, rp);                      // 1) duplicadas liberadas (pixels apagados)
                            ArrayList<Integer> from = new ArrayList<Integer>();
                            for (int[] p : fm) from.add(Integer.valueOf(p[0]));
                            anos.addAll(SpriteMassDialogs.anosUsing(ca, from));
                            for (int[] p : fm) uses += ca.remapImageUses(p[0], p[1]);                    // 2) Frames do DAC passam a sprite que ficou
                            boolean[] has = new boolean[gCount];
                            for (int k = 0; k < gCount; k++) has[k] = lib.has(gFirst + k);
                            java.util.TreeSet<Integer> del = GifOptimizer.toDelete(gFirst, gCount, has);   // 3) vazias (liberadas + as que ja eram)
                            if (!del.isEmpty()) {
                                busy.set("Removendo sprites vazias", 0, 0);
                                anos.addAll(SpriteMassDialogs.anosUsing(ca, new ArrayList<Integer>(del)));
                                int[] rmap = lib.removeShift(del);                                       // apaga pixels/folhas e renumera o CNV e o GIF
                                java.util.TreeSet<Integer> ch = SpriteRenumber.remapDac(ca.dac, rmap);   // 4) renumera os Frames no DAC
                                SpriteMassDialogs.renumbered(ca, rmap);
                                anos.addAll(ch);
                                renum = ch.size();
                                removed = del.size();
                            }
                            busy.set("Gravando as folhas de sprites...", 0, 0);
                            lib.commit();
                        } catch (Throwable ex) { err = ex.getMessage() == null ? ex.toString() : ex.getMessage(); }
                        busy.dismiss();
                        final int fu = uses, fr = removed, fn = renum;
                        final java.util.TreeSet<Integer> fa = anos;
                        final String fe = err;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                String sv = fe == null ? SpriteMassDialogs.persist(ca, fa) : "";
                                applied.run();
                                toast(a, fe != null ? "Erro ao otimizar: " + fe : fr + " sprite(s) removida(s)" + (fu > 0 ? "; " + fu + " frame(s) do DAC passaram a usar a sprite que ficou" : "")
                                        + (fn > 0 ? "; " + fn + " ANO(s) renumerada(s) no DAC" : "") + sv);
                            }
                        });
                    }
                }).start();
            }
        });
        foot.addView(ok, lpm(a, 8));
        root.addView(foot);
        Bitmap[] fb = new Bitmap[an.n];
        int[] db = new int[an.n];
        for (int k = 0; k < an.n; k++) { fb[k] = an.valid[k] ? bigOf(lib, big, an.sprite[k], bigScale) : null; db[k] = g.delayAt(k); }
        pvBefore.set(fb, db);
        capBefore.setText("ANTES: " + GifOptimizer.distinctSprites(an) + " sprite(s) \u00b7 " + an.n + " quadro(s)");
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface x) {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
                for (Bitmap b : big.values()) if (b != null && !b.isRecycled()) b.recycle();
                big.clear();
            }
        });
        upd.run();
        d.show();
    }

    /** Quadro do GIF para a previa Antes/Depois: a sprite inteira, reduzida pelo mesmo fator em todas (as proporcoes entre elas se mantem). */
    private static Bitmap bigOf(SpriteLib lib, Map<Integer, Bitmap> cache, int sprite, float scale) {
        Bitmap b = cache.get(Integer.valueOf(sprite));
        if (b == null) {
            Bitmap full = lib.cut(sprite);
            if (full == null) return null;
            b = scale >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, Math.round(full.getWidth() * scale)), Math.max(1, Math.round(full.getHeight() * scale)), true);
            if (b != full) full.recycle();
            cache.put(Integer.valueOf(sprite), b);
        }
        return b;
    }

    /** "quadro 3" / "quadros 1, 4, 6": em quais quadros do GIF a sprite do quadro i aparece. */
    private static String usedBy(GifOptimizer.Analysis an, int i) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (int k = 0; k < an.n; k++) {
            if (an.sprite[k] != an.sprite[i]) continue;
            n++;
            if (n <= 6) sb.append(n > 1 ? ", " : "").append(k + 1);
        }
        if (n > 6) sb.append("\u2026 +").append(n - 6);
        return (n == 1 ? "quadro " : "quadros ") + sb;
    }

    private static ImageView thumbView(Activity a, SpriteLib lib, Map<Integer, Bitmap> thumbs, int sprite) {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        Bitmap tb = thumb(lib, thumbs, sprite);
        if (tb != null) iv.setImageBitmap(tb);
        return iv;
    }

    // ---- acoes de uma sprite ----

    private static TextView menuRow(Activity a, String label, int indentDp, int color, View.OnClickListener c) {
        TextView t = text(a, label, 16, color, false);
        t.setPadding(dp(a, 16 + indentDp), dp(a, 14), dp(a, 16), dp(a, 14));
        t.setOnClickListener(c);
        return t;
    }

    /** Menu da sprite: Substituir (expande: Outra Sprite do personagem / Escolher do Dispositivo), Mostrar usos, Predefinicoes, Mudar recorte, Excluir. */
    private static void actions(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        final LinearLayout sub = new LinearLayout(a);
        sub.setOrientation(LinearLayout.VERTICAL);
        sub.setVisibility(View.GONE);
        final TextView arrow = text(a, "\u25BE", 16, DIM, true);
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView lbl = text(a, "Substituir", 16, TEXT, false);
        lbl.setPadding(dp(a, 16), dp(a, 14), dp(a, 8), dp(a, 14));
        head.addView(lbl, new LinearLayout.LayoutParams(0, -2, 1f));
        arrow.setPadding(dp(a, 8), 0, dp(a, 20), 0);
        head.addView(arrow);
        head.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean open = sub.getVisibility() == View.VISIBLE;
                sub.setVisibility(open ? View.GONE : View.VISIBLE);
                arrow.setText(open ? "\u25BE" : "\u25B4");
            }
        });
        box.addView(head);
        sub.addView(menuRow(a, "Escolher do Personagem", 20, TEXT, new View.OnClickListener() { @Override public void onClick(View v) { dlg[0].dismiss(); SpriteMassDialogs.swapUses(a, ca, lib, idx, applied); } }));
        sub.addView(menuRow(a, "Escolher do Dispositivo", 20, TEXT, new View.OnClickListener() { @Override public void onClick(View v) { dlg[0].dismiss(); replace(a, ca, lib, idx, applied); } }));
        box.addView(sub);
        box.addView(menuRow(a, "Mostrar usos", 0, TEXT, new View.OnClickListener() { @Override public void onClick(View v) { dlg[0].dismiss(); showUses(a, ca, idx); } }));
        box.addView(menuRow(a, "Editar Frame", 0, TEXT, new View.OnClickListener() { @Override public void onClick(View v) {
            dlg[0].dismiss();
            ArrayList<Integer> one = new ArrayList<Integer>();
            one.add(Integer.valueOf(idx));
            SpriteMassDialogs.editFrames(a, ca, one, applied);          // o mesmo menu do EDITAR FRAMES (hurtbox/hitbox/efeito estao no botao dele)
        } }));
        box.addView(menuRow(a, "Mudar recorte", 0, TEXT, new View.OnClickListener() { @Override public void onClick(View v) { dlg[0].dismiss(); crop(a, ca, lib, idx, applied); } }));
        box.addView(menuRow(a, "Excluir", 0, 0xFFFF6B6B, new View.OnClickListener() { @Override public void onClick(View v) { dlg[0].dismiss(); remove(a, ca, lib, idx, applied); } }));
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(box);
        dlg[0] = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("SPR_" + idx).setView(sv).setNegativeButton("FECHAR", null).show();
    }

    /**
     * REESCALAR: zoom pela altura da 1a sprite do Parado e MID com os pes no chao nos Frames do DAC que usam as marcadas, ANO por ANO: para cada sprite e cada ANO que a
     * usa abre a previa ANTES | DEPOIS com REESCALAR / NAO REESCALAR ({@link RescaleScreen}). O padrao da sprite (Editar Frame) nao muda. Avisa bem claro que mexe em Frames e
     * que sprites posicionadas antes podem ficar descentralizadas; a copia bruta do personagem e feita no fim, antes de gravar.
     */
    private static void rescale(final Activity a, final CharAssets ca, final SpriteLib lib, final List<Integer> marked, final Runnable applied) {
        final Centralize.Sizes sz = ca.sizes();
        final double refH = Centralize.refHeight(ca.dac, sz);
        if (refH <= 0) { toast(a, "Não achei a 1ª sprite do Parado (ANO 0, frame 1) para servir de referência de altura."); return; }
        final java.util.Map<Integer, Centralize.Plan> plans = new java.util.TreeMap<Integer, Centralize.Plan>();
        for (Integer i : marked) { int[] ls = sz.logical(i.intValue()); if (ls != null) plans.put(i, Centralize.plan(refH, ls[0], ls[1])); }
        if (plans.isEmpty()) { toast(a, "As sprites marcadas não têm desenho."); return; }
        final List<RescaleReview.Step> steps = RescaleReview.steps(ca.dac, plans.keySet());
        final List<Integer> unused = RescaleReview.unused(ca.dac, plans.keySet());
        if (steps.isEmpty()) { toast(a, "Nenhuma ANO usa as sprites marcadas: não há Frames para reescalar."); return; }
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Reescalar sprites")
                .setMessage("Esta função serve para REESCALAR e CENTRALIZAR sprites nos Frames: para cada uma das " + plans.size() + " marcadas ela muda o ZOOM (a altura na tela fica igual à da 1ª sprite do Parado) e o MID "
                        + "(x = −largura/2, y = −altura, com o zoom) dos Frames do DAC que usam essa sprite. O padrão do Editar Frame NÃO muda.\n\n"
                        + "Você vai ver, ANO por ANO, a prévia ANTES | DEPOIS de cada uso e escolher REESCALAR ou NÃO REESCALAR (" + steps.size() + " passo(s)).\n\n"
                        + "Atenção: sprites que já estavam posicionadas antes podem ficar DESCENTRALIZADAS, e as animações escolhidas mudam de tamanho e de posição. "
                        + "Rotação, alpha e flips dos Frames não mudam.\n\n"
                        + "No fim, antes de gravar, é feita uma cópia bruta do personagem inteiro em Backups/PreOptim/.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("COMEÇAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { RescaleScreen.show(a, ca, steps, plans, unused, applied); }
                }).show();
    }

    /** Tamanhos logicos {largura[], altura[]} de todas as sprites (0 = sem desenho). */
    private static int[][] sizesOf(SpriteLib lib) {
        int n = lib.count();
        int[] w = new int[n], h = new int[n];
        for (int i = 0; i < n; i++) { int[] ls = lib.has(i) ? lib.logicalSize(i) : null; if (ls != null) { w[i] = ls[0]; h[i] = ls[1]; } }
        return new int[][]{w, h};
    }

    /** Texto do criterio ativo para a linha da sprite {@code i}. */
    private static String sortInfo(int mode, int i, SpriteLib lib, CharAssets ca, int[] best) {
        int[][] wh = sizesOf(lib);
        return SpriteSort.info(mode, i, wh[0], wh[1], mode == SpriteSort.USES_DESC || mode == SpriteSort.USES_ASC ? SpriteSort.useCounts(ca.dac, lib.count()) : null, best);
    }

    /** Melhor nota de cada sprite contra qualquer outra (todas contra todas, com tempo limite), para a ordem "Mais parecidas". */
    private static void computeSimilar(final Activity a, final SpriteLib lib, final int[][] sim, final Runnable done) {
        SpriteSims.build(a, lib, new SpriteSims.Done() {
            @Override public void on(final Map<Integer, SpriteDedup.Sig> sigs) {
                final BusyDialog busy = BusyDialog.show(a, "Comparando sprites");
                new Thread(new Runnable() {
                    @Override public void run() {
                        final int n = lib.count();
                        final int[] best = new int[n], partner = new int[n];
                        java.util.Arrays.fill(best, -1);
                        java.util.Arrays.fill(partner, -1);
                        long deadline = android.os.SystemClock.uptimeMillis() + 120000L;
                        boolean partial = false;
                        try {
                            for (int i = 0; i < n && !partial; i++) {
                                busy.set("Comparando sprites", i, n);
                                SpriteDedup.Sig si = sigs.get(Integer.valueOf(i));
                                if (si == null || si.empty) continue;
                                for (int j = i + 1; j < n; j++) {
                                    SpriteDedup.Sig sj = sigs.get(Integer.valueOf(j));
                                    if (sj == null || sj.empty) continue;
                                    int sc = SpriteDedup.bestAny(si, sj).score;
                                    if (sc > best[i]) { best[i] = sc; partner[i] = j; }
                                    if (sc > best[j]) { best[j] = sc; partner[j] = i; }
                                }
                                if (android.os.SystemClock.uptimeMillis() > deadline) partial = true;
                            }
                        } catch (Throwable t) { partial = true; }
                        busy.dismiss();
                        final boolean fp = partial;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                sim[0] = best; sim[1] = partner;
                                if (fp) toast(a, "A comparação passou do tempo: as notas das últimas sprites podem estar incompletas.");
                                done.run();
                            }
                        });
                    }
                }).start();
            }
        });
    }

    /** "Mostrar usos": onde a sprite aparece, uma linha por ANO ("Ano 3, Frames 1, 4 e 7"). */
    private static void showUses(Activity a, CharAssets ca, int idx) {
        String text = SpriteUses.text(ca.dac, idx);
        TextView tv = text(a, text.isEmpty() ? "Nenhum Frame de nenhuma ANO usa esta sprite." : text, 14, TEXT, false);
        tv.setPadding(dp(a, 20), dp(a, 10), dp(a, 20), dp(a, 10));
        tv.setTextIsSelectable(true);
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(tv);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Usos de SPR_" + idx).setView(sv).setPositiveButton("OK", null).show();
    }

    private static Runnable uiOnlyR;

    /** + ADICIONAR: seletor de arquivos (imagens e CNV de outros pacs); VOLTAR da escolha de sprites do CNV reabre este seletor na pasta do CNV. */
    private static void openAdd(final Activity a, final String title, final SpriteLib lib, final Runnable applied, final Runnable uiOnly, final ListView lv) {
        FilePicker.show(a, "Adicionar sprites a " + title, true, FilePicker.IMAGES_CNV, new FilePicker.Listener() {
            @Override public void onPicked(List<File> files) {
                importFiles(a, lib, files, applied, lv);
            }
        }, new FilePicker.CnvListener() {
            @Override public void onCnv(File cnv) {
                PacSpritePicker.show(a, cnv, lib, uiOnly, 0, new Runnable() {
                    @Override public void run() { openAdd(a, title, lib, applied, uiOnly, lv); }
                }, -1);
            }
        });
    }

    private static void replace(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        FilePicker.show(a, "Nova imagem para SPR_" + idx, false, FilePicker.IMAGES_CNV, smallCut(lib, idx), replacingLabel(lib, idx), new FilePicker.Listener() {
            @Override public void onPicked(final List<File> files) {
                if (SpriteImportPlan.sameFolder(files.get(0).getParentFile(), lib.dir)) {          // PNG da pasta do proprio personagem: isso e do personagem
                    toast(a, "Esse arquivo é do próprio personagem: use \"Escolher do Personagem\".");
                    return;
                }
                final BusyDialog busy = BusyDialog.show(a, "Abrindo imagem");
                busy.set(files.get(0).getName(), 0, 0);
                new Thread(new Runnable() {
                    @Override public void run() {
                        ImageImport.prog = new ImageImport.Prog() {
                            @Override public void on(String what, int done, int total) { busy.set(files.get(0).getName() + "\n" + what, done, total); }
                        };
                        ImageImport.Loaded ld0 = null;
                        String err = null;
                        try { ld0 = ImageImport.load(files.get(0)); }
                        catch (Throwable t) { err = t.getMessage(); }
                        ImageImport.prog = null;
                        busy.dismiss();
                        final ImageImport.Loaded ld = ld0;
                        final String fe = err;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() { afterReplace(a, ca, lib, idx, applied, files.get(0), ld, fe); }
                        });
                    }
                }).start();
            }
        }, new FilePicker.CnvListener() {      // tocar num .cnv: escolher UMA sprite dele para substituir
            @Override public void onCnv(File cnv) {
                PacSpritePicker.show(a, cnv, lib, uiOnlyR, 0, new Runnable() {
                    @Override public void run() { replace(a, ca, lib, idx, applied); }
                }, idx, cnvHook(a, ca, lib, idx));          // sprite de um CNV de outro pac: confirmacao 1:1 com IGUALAR SPRITES
            }
        });
    }

    private static void afterReplace(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied, File file,
                                     final ImageImport.Loaded ld, String err) {
        if (ld == null) { toast(a, file.getName() + ": " + err); return; }
        final SpriteDefaults.Def[] adj = {null};          // igualar: ajuste escolhido na tela (somado aos Frames e ao padrao depois de trocar a imagem)
        final Runnable go = new Runnable() {
            @Override public void run() {
                final BusyDialog busy = BusyDialog.show(a, "Substituindo sprite");
                busy.set("Gravando as folhas de sprites...", 0, 0);
                new Thread(new Runnable() {
                    @Override public void run() {
                        String err = null;
                        try { lib.replace(idx, ld.frames.get(0)); lib.commit(); } catch (Exception ex) { err = ex.getMessage(); }
                        recycle(ld);
                        busy.dismiss();
                        final String fe = err;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (fe != null) toast(a, "Erro: " + fe);
                                else if (adj[0] != null) toast(a, SpriteMassDialogs.applyAdjustInSlot(ca, idx, adj[0]));
                                uiOnlyR.run();
                            }
                        });
                    }
                }).start();
            }
        };
        // confirmacao 1:1 (antiga | → nova): CONFIRMAR troca simples; IGUALAR SPRITES abre a tela e troca com o ajuste
        final Runnable start = new Runnable() {
            @Override public void run() {
                SpriteCache.Sprite old = ca.sprites.get(idx);
                Bitmap nb = ld.frames.isEmpty() ? null : ld.frames.get(0);
                if (nb == null) { toast(a, "Não consegui montar a prévia da nova imagem."); recycle(ld); return; }
                final SpriteCache.Sprite fresh = freshSprite(lib, nb);
                ReplaceConfirm.show(a, "Você quer trocar a SPR_" + idx + " por esta imagem?", old, fresh, SpriteMass.sizeWarningImage(lib, ca.cnv, idx, nb),
                        go,
                        new Runnable() { @Override public void run() {
                            SpriteMassDialogs.equalizeScreen(a, ca, idx, ca.sprites.get(idx), fresh, new SpriteEqualizeScreen.Listener() {
                                @Override public void apply(SpriteDefaults.Def f) { adj[0] = f; go.run(); }
                            });
                        } },
                        new Runnable() { @Override public void run() { recycle(ld); } });
            }
        };
        if (ld.notice == null) { start.run(); return; }
        String msg = file.getName() + ":\n" + ld.notice + (ld.animated() ? "\n\nAo substituir so o primeiro quadro e usado." : "");
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Converter imagem").setMessage(msg)
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { recycle(ld); } })
                .setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { start.run(); } })
                .setOnCancelListener(new DialogInterface.OnCancelListener() { @Override public void onCancel(DialogInterface x) { recycle(ld); } })
                .show();
    }

    /** Sprite "solta" (bitmap proprio, sem folha) para a previa: o recorte e a imagem toda; tamanho logico = pixels / escala. */
    static SpriteCache.Sprite freshSprite(SpriteLib lib, Bitmap nb) {
        int sc = Math.max(1, lib.scale);
        int lw = Math.max(1, (nb.getWidth() + sc - 1) / sc), lh = Math.max(1, (nb.getHeight() + sc - 1) / sc);
        return new SpriteCache.Sprite(nb, new android.graphics.Rect(0, 0, nb.getWidth(), nb.getHeight()), lw, lh, lw, lh);
    }

    /** Sprite escolhida num CNV de outro pac para substituir a SPR_idx: confirmacao 1:1 (CONFIRMAR | IGUALAR SPRITES | CANCELAR). */
    private static PacSpritePicker.ReplaceHook cnvHook(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx) {
        return new PacSpritePicker.ReplaceHook() {
            @Override public void chosen(final SpriteLib src, final int srcIdx, final int factor, String cnvName) {
                Bitmap b = src.cut(srcIdx);
                if (b == null) {
                    String why = src.cutProblem(srcIdx);
                    toast(a, "SPR_" + srcIdx + ": " + (why != null ? why : "o recorte não gerou imagem"));
                    src.release();
                    return;
                }
                if (factor > 1) {
                    Bitmap big = Bitmap.createScaledBitmap(b, b.getWidth() * factor, b.getHeight() * factor, false);
                    b.recycle();
                    b = big;
                }
                final Bitmap nb = b;
                final SpriteCache.Sprite fresh = freshSprite(lib, nb);
                final SpriteDefaults.Def[] adj = {null};
                final Runnable doIt = new Runnable() {
                    @Override public void run() {
                        PacSpritePicker.replaceWith(a, src, lib, srcIdx, idx, factor, uiOnlyR, new Runnable() {
                            @Override public void run() { if (adj[0] != null) toast(a, SpriteMassDialogs.applyAdjustInSlot(ca, idx, adj[0])); }
                        });
                    }
                };
                ReplaceConfirm.show(a, "Você quer trocar a SPR_" + idx + " por SPR_" + srcIdx + " de " + cnvName + "?", ca.sprites.get(idx), fresh,
                        SpriteMass.sizeWarningImage(lib, ca.cnv, idx, nb), doIt,
                        new Runnable() { @Override public void run() {
                            SpriteMassDialogs.equalizeScreen(a, ca, idx, ca.sprites.get(idx), fresh, new SpriteEqualizeScreen.Listener() {
                                @Override public void apply(SpriteDefaults.Def f) { adj[0] = f; doIt.run(); }
                            });
                        } },
                        new Runnable() { @Override public void run() { src.release(); } });
            }
        };
    }

    private static void recycle(ImageImport.Loaded ld) {
        for (Bitmap b : ld.frames) if (b != null && !b.isRecycled()) b.recycle();
        ld.frames.clear();
    }

    /** Abre cada arquivo (convertendo se preciso), avisa das conversoes e adiciona; imagem animada vira varias sprites seguidas. */
    private static void importFiles(final Activity a, final SpriteLib lib, final List<File> files, final Runnable applied, final ListView lv) {
        final BusyDialog busy = BusyDialog.show(a, "Convertendo imagens");
        new Thread(new Runnable() {
            @Override public void run() {
                final ArrayList<ImageImport.Loaded> ok = new ArrayList<ImageImport.Loaded>();
                final StringBuilder fail = new StringBuilder();
                int frames = 0;
                final int n = files.size();
                for (int i = 0; i < n; i++) {
                    final File f = files.get(i);
                    final int fi = i;
                    ImageImport.prog = new ImageImport.Prog() {
                        @Override public void on(String what, int done, int total) {
                            busy.set(f.getName() + "\n" + what + (total > 0 ? " " + done + "/" + total : " " + done), fi, n);
                        }
                    };
                    busy.set(f.getName(), i, n);
                    try {
                        ImageImport.Loaded ld = ImageImport.load(f);
                        ok.add(ld);
                        frames += ld.frames.size();
                    } catch (Throwable t) {
                        fail.append("\u2022 ").append(f.getName()).append(": ").append(t.getMessage()).append('\n');
                    }
                }
                ImageImport.prog = null;
                busy.dismiss();
                final int totalFrames = frames;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() { afterImport(a, lib, ok, fail, totalFrames, uiOnlyR, lv); }
                });
            }
        }).start();
    }

    /** Depois de abrir os arquivos: avisa das conversoes e pergunta; confirmando, grava as sprites em segundo plano com progresso. */
    private static void afterImport(final Activity a, final SpriteLib lib, final ArrayList<ImageImport.Loaded> ok, StringBuilder fail,
                                    int frames, final Runnable applied, final ListView lv) {
        if (ok.isEmpty()) { toast(a, "Nenhuma imagem aberta.\n" + fail); return; }
        final int first = lib.count();
        final int total = frames;
        final Runnable go = new Runnable() {
            @Override public void run() {
                final BusyDialog busy = BusyDialog.show(a, "Adicionando sprites");
                new Thread(new Runnable() {
                    @Override public void run() {
                        int added = 0, bad = 0;
                        for (ImageImport.Loaded ld : ok) {
                            busy.set(ld.file.getName(), added + bad, total);
                            if (ld.animated()) {
                                final int base = added + bad;
                                final String nm = ld.file.getName();
                                try {
                                    lib.addAnimation(nm, ld.frames, ld.delays, new SpriteLib.Step() {
                                        @Override public void on(int done) { busy.set(nm, base + done, total); }
                                    });
                                    added += ld.frames.size();
                                } catch (Exception ex) { bad += ld.frames.size(); }
                            } else {
                                for (Bitmap b : ld.frames) {
                                    try { lib.add(b); added++; } catch (Exception ex) { bad++; }
                                    busy.set(ld.file.getName(), added + bad, total);
                                }
                            }
                            recycle(ld);
                            busy.set(ld.file.getName(), added + bad, total);
                        }
                        busy.set("Gravando as folhas de sprites...", 0, 0);     // comprime os PNGs e grava o CNV (e o que mais pesa)
                        try { lib.commit(); } catch (Exception ex) { /* o applied tenta de novo e mostra o erro */ }
                        busy.dismiss();
                        final int fa = added, fb = bad;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                applied.run();
                                if (fa > 0) lv.setSelection(first);
                                toast(a, fa + " sprite(s) adicionada(s)" + (fa > 0 ? " (SPR_" + first + " a SPR_" + (first + fa - 1) + ")" : "") + (fb > 0 ? ", " + fb + " falharam" : "")
                                        + (lib.downscaled > 0 ? ". " + lib.downscaled + " reduzida(s) para no maximo " + SpriteLib.MAX_SIDE + " px" : ""));
                                lib.downscaled = 0;
                            }
                        });
                    }
                }).start();
            }
        };
        StringBuilder msg = new StringBuilder();
        for (ImageImport.Loaded ld : ok) {
            if (ld.notice != null) msg.append("\u2022 ").append(ld.file.getName()).append(": ").append(ld.notice).append("\n\n");
        }
        if (fail.length() > 0) msg.append("Nao abriu:\n").append(fail);
        if (msg.length() == 0) { go.run(); return; }
        msg.append(frames).append(" sprite(s) serao criadas, a partir de SPR_").append(first).append('.');
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Converter imagens").setMessage(msg.toString())
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface x, int w) { for (ImageImport.Loaded ld : ok) recycle(ld); }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface x) { for (ImageImport.Loaded ld : ok) recycle(ld); }
                })
                .setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface x, int w) { go.run(); } })
                .show();
    }

    private static void remove(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        ArrayList<Integer> one = new ArrayList<Integer>();
        one.add(Integer.valueOf(idx));
        SpriteMassDialogs.confirmDelete(a, ca, lib, one, applied);
    }

    // ---- previa flutuante da miniatura ----

    /** Toque na miniatura: a sprite inteira, maior, numa area quadrada flutuante; tocar fora (ou nela) fecha. */
    static void previewSprite(final Activity a, SpriteLib lib, int i) {
        final Bitmap full = lib.cut(i);
        if (full == null) { toast(a, "SPR_" + i + " está vazia"); return; }
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        android.util.DisplayMetrics dm = a.getResources().getDisplayMetrics();
        int side = Math.min(Math.round(dm.widthPixels * 0.8f), Math.round(dm.heightPixels * 0.6f));
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(BG);
        box.setPadding(dp(a, 8), dp(a, 8), dp(a, 8), dp(a, 8));
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(a.getResources(), full);
        bd.setFilterBitmap(false);
        iv.setImageDrawable(bd);
        iv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } });
        box.addView(iv, new LinearLayout.LayoutParams(side, side));
        TextView cap = text(a, "SPR_" + i + "  \u00b7  " + full.getWidth() + "\u00d7" + full.getHeight(), 12, DIM, false);
        cap.setPadding(dp(a, 2), dp(a, 6), dp(a, 2), 0);
        box.addView(cap);
        d.setContentView(box);
        d.setCanceledOnTouchOutside(true);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() { @Override public void onDismiss(DialogInterface x) { full.recycle(); } });
        d.show();
    }

    // ---- reorganizar slots: puxador "-" (segurar e arrastar) ----

    /** O que o gesto de arrastar precisa da tela da lista. */
    private static DragPlan.Groups groupsOf(final SpriteLib lib) {
        return new DragPlan.Groups() {
            @Override public int firstOf(int sprite) { SpriteGroups.Group g = lib.groups.at(sprite); return g == null ? -1 : g.first; }
            @Override public int lastOf(int sprite) { SpriteGroups.Group g = lib.groups.at(sprite); return g == null ? -1 : g.last(); }
        };
    }

    /** ListView que, durante um arraste, entrega TODOS os eventos ao {@link Dragger}: se a linha arrastada sai da tela (rolagem) o Android cancela o toque dela, e isso nao pode soltar a sprite. */
    private static final class DragListView extends ListView {
        Dragger drag;
        DragListView(android.content.Context c) { super(c); }
        @Override public boolean dispatchTouchEvent(MotionEvent e) {
            Dragger d = drag;
            if (d != null && d.active) { d.onListTouch(e); return true; }
            return super.dispatchTouchEvent(e);
        }
    }

    private static final class DragCtx {
        final Activity a; final CharAssets ca; final SpriteLib lib;
        DragListView lv; int dragPos = -1, dragRows = 1; ArrayList<int[]> rows; java.util.TreeSet<Integer> sel; java.util.HashSet<Integer> open;
        BaseAdapter ad; Runnable applied;
        DragCtx(Activity a, CharAssets ca, SpriteLib lib) { this.a = a; this.ca = ca; this.lib = lib; }
    }

    /**
     * Gesto do puxador: tocar e SEGURAR arma o arraste (toque simples nao faz nada); a linha infla, o toast avisa e o dedo precisa andar ~28 dp antes de a linha
     * comecar a se mover (e ela acompanha amortecida no comeco). Ao soltar, a sprite vai para o slot da linha sob ela: CNV, GIFs e DAC sao reescritos.
     */
    private static final class Dragger implements View.OnTouchListener {
        private static final int START_DP = 28, SOFT_DP = 70, EDGE_DP = 64;
        final DragCtx c; final LinearLayout row; final int from, len;      // len > 1: GIF encolhido, move as len sprites juntas
        float downX, downY, dampedDy;
        boolean armed, active, dragging;
        int startTop, rowH, targetPos = -1, rowPos, blockRows = 1;
        android.graphics.drawable.ColorDrawable gap;           // slot AZUL: onde a sprite vai cair
        android.graphics.drawable.ColorDrawable origin;        // slot VERMELHO: o lugar de onde ela saiu (soltar aqui = desistir)
        android.graphics.drawable.BitmapDrawable ghost;
        Bitmap ghostBmp;
        Runnable lp, scroller;
        float fingerRawY;

        Dragger(DragCtx c, LinearLayout row, int from, int len) { this.c = c; this.row = row; this.from = from; this.len = Math.max(1, len); }

        @Override public boolean onTouch(final View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY(); fingerRawY = downY;
                    armed = true; active = false; dragging = false;
                    lp = new Runnable() { @Override public void run() { if (armed) begin(v); } };
                    v.postDelayed(lp, ViewConfiguration.getLongPressTimeout());
                    return true;                                    // o toque no puxador e consumido (nao abre o menu da linha)
                case MotionEvent.ACTION_MOVE: {
                    if (active) return true;            // arraste armado: quem manda e o DragListView (o Android pode cancelar o toque do puxador quando a lista rola)
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    fingerRawY = e.getRawY();
                    if (!active) {
                        if (Math.hypot(dx, dy) > ViewConfiguration.get(v.getContext()).getScaledTouchSlop()) { armed = false; v.removeCallbacks(lp); }
                        return true;
                    }
                    move(dy);
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    armed = false;
                    v.removeCallbacks(lp);
                    // com o arraste armado o puxador NAO decide nada: um ACTION_CANCEL dele (a linha saiu da tela na rolagem) nao pode encerrar o arraste com o dedo ainda na tela;
                    // so o UP visto pelo DragListView grava (onListTouch)
                    return true;
                default:
                    return true;
            }
        }

        /** Eventos depois de armado (vindos do {@link DragListView}): so SOLTAR (UP) grava; CANCEL (ex.: a linha saiu da tela na rolagem) desfaz sem mover nada. */
        void onListTouch(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_MOVE:
                    fingerRawY = e.getRawY();
                    move(e.getRawY() - downY);
                    break;
                case MotionEvent.ACTION_UP:
                    fingerRawY = e.getRawY();
                    end(true);
                    active = false;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    end(false);
                    active = false;
                    break;
                default:
                    break;
            }
        }

        private void begin(View v) {
            active = true;
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            c.lv.requestDisallowInterceptTouchEvent(true);
            for (android.view.ViewParent pp = c.lv.getParent(); pp != null; pp = pp.getParent()) pp.requestDisallowInterceptTouchEvent(true);      // nenhum pai rouba o toque
            startTop = row.getTop();
            rowH = row.getHeight();
            rowPos = c.lv.getPositionForView(row);
            // bloco (marcadas seguidas): as linhas que cobrem as sprites from..from+len-1 andam juntas
            blockRows = 1;
            if (len > 1) {
                blockRows = 0;
                for (int[] r : c.rows) if (r[1] >= from && r[1] <= from + len - 1) blockRows++;
                blockRows = Math.max(1, blockRows);
            }
            int firstVis = c.lv.getFirstVisiblePosition(), dv = c.lv.getDividerHeight(), total = 0;
            for (int k = 0; k < blockRows; k++) {
                View chd = c.lv.getChildAt(rowPos + k - firstVis);
                total += (chd != null ? chd.getHeight() : rowH) + (k > 0 ? dv : 0);
            }
            rowH = total;                                   // altura do bloco inteiro (fantasma, slots e empurrao)
            c.dragPos = rowPos;
            c.dragRows = blockRows;
            c.lv.drag = this;
            // fantasma: foto da linha que segue o dedo (continua visivel mesmo que a linha original saia da tela na rolagem)
            origin = new android.graphics.drawable.ColorDrawable(0x66FF4D4D);
            origin.setBounds(0, startTop, c.lv.getWidth(), startTop + rowH);
            c.lv.getOverlay().add(origin);
            gap = new android.graphics.drawable.ColorDrawable(0x664C8DFF);
            gap.setBounds(0, 0, 0, 0);                                  // o azul so aparece quando a ordem mudaria
            c.lv.getOverlay().add(gap);
            try {
                ghostBmp = Bitmap.createBitmap(Math.max(1, row.getWidth()), Math.max(1, rowH), Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(ghostBmp);
                cv.drawColor(0xFF2C3A5C);
                int yy = 0;
                for (int k = 0; k < blockRows; k++) {                  // foto das linhas do bloco, empilhadas
                    View chd = c.lv.getChildAt(rowPos + k - firstVis);
                    if (chd == null) continue;
                    cv.save();
                    cv.translate(0, yy);
                    chd.draw(cv);
                    cv.restore();
                    yy += chd.getHeight() + dv;
                }
                ghost = new android.graphics.drawable.BitmapDrawable(c.a.getResources(), ghostBmp);
                updateGhost(0f);
                c.lv.getOverlay().add(ghost);
            } catch (Throwable ex) { ghost = null; }
            for (int k = 0; k < blockRows; k++) { View chd = c.lv.getChildAt(rowPos + k - firstVis); if (chd != null) chd.setAlpha(0.35f); }
            toast(c.a, blockRows > 1 || len > 1 ? "arraste o bloco para reorganizar as Sprites (solte no vermelho para cancelar)" : "arraste para reorganizar as Sprites (solte no vermelho para cancelar)");
        }

        private void updateGhost(float dy) {
            if (ghost == null) return;
            int infl = Math.round(rowH * 0.03f), top = Math.round(startTop + dy);
            ghost.setBounds(-infl, top - infl, c.lv.getWidth() + infl, top + rowH + infl);
            ghost.invalidateSelf();
        }

        private void move(float dy) {
            float adj = Math.max(0f, Math.abs(dy) - dp(c.a, START_DP));
            if (!dragging) { if (adj <= 0f) return; dragging = true; startScroller(); }          // pesado no comeco: so depois do limiar
            float soft = dp(c.a, SOFT_DP);
            float eff = adj <= soft ? adj * 0.5f : soft * 0.5f + (adj - soft);
            dampedDy = Math.signum(dy) * eff;
            updateGhost(dampedDy);
            updateTarget();
        }

        /** Alvo sob o centro do fantasma, SEM contar a propria linha arrastada. Acima da primeira linha visivel = antes dela (com a lista no topo, SPR_0). */
        private void updateTarget() {
            int first = c.lv.getFirstVisiblePosition(), n = c.lv.getChildCount();
            int[] tops = new int[n], bottoms = new int[n];
            for (int i = 0; i < n; i++) { View ch = c.lv.getChildAt(i); tops[i] = ch.getTop(); bottoms[i] = ch.getBottom(); }
            float centerY = startTop + rowH / 2f + dampedDy;
            int pos = -1;
            int ri = rowPos - first, re = rowPos + blockRows - 1 - first;          // primeira e ultima linha do bloco (indices de filhos)
            float selfTop = ri >= 0 && ri < n ? tops[ri] : (ri < 0 ? -1e9f : 1e9f);
            float selfBottom = re >= 0 && re < n ? bottoms[re] : (re < 0 ? -1e9f : 1e9f);
            boolean overSelf = centerY >= selfTop && centerY < selfBottom;
            if (!overSelf) {
                int ci = DragPlan.hit(tops, bottoms, -1, centerY);
                if (ci >= 0) pos = first + ci;
                if (pos >= rowPos && pos < rowPos + blockRows) pos = -1;          // dentro do proprio bloco = nao muda
            }
            targetPos = pos;
            int ins = pos < 0 ? rowPos : DragPlan.insertionPos(c.rows, pos, rowPos, groupsOf(c.lib));
            applyShifts(DragPlan.pushed(rowPos, blockRows, ins), ins, first, n);
        }

        /**
         * Dois slots: o VERMELHO fica no lugar de origem (as vizinhas nao o preenchem) e o AZUL abre no ponto de insercao, empurrando as linhas seguintes para baixo
         * ({@link DragPlan#pushed}). Soltar sobre o vermelho nao muda nada.
         */
        private void applyShifts(int[] sh, int ins, int first, int n) {
            float h = rowH + c.lv.getDividerHeight();
            for (int i = 0; i < n; i++) {
                View ch = c.lv.getChildAt(i);
                int p = first + i;
                float want = sh[2] != 0 && p >= sh[0] && p <= sh[1] ? sh[2] * h : 0f;
                if (ch.getTranslationY() != want) ch.animate().translationY(want).setDuration(150).start();
            }
            View own = c.lv.getChildAt(rowPos - first), ownEnd = c.lv.getChildAt(rowPos + blockRows - 1 - first);
            if (origin != null) {
                if (own != null) origin.setBounds(0, own.getTop(), c.lv.getWidth(), ownEnd != null ? ownEnd.getBottom() : own.getTop() + rowH);
                else origin.setBounds(0, 0, 0, 0);                      // a linha de origem esta fora da tela: o vermelho volta quando ela reaparecer
                origin.invalidateSelf();
            }
            if (gap != null) {
                int gapTop = -1;
                if (DragPlan.blueAt(rowPos, blockRows, ins)) {
                    View at = c.lv.getChildAt(ins - first);
                    View before = c.lv.getChildAt(ins - 1 - first);
                    if (at != null) gapTop = at.getTop();
                    else if (before != null) gapTop = before.getBottom() + c.lv.getDividerHeight();
                }
                if (gapTop >= 0) gap.setBounds(0, gapTop, c.lv.getWidth(), gapTop + rowH);
                else gap.setBounds(0, 0, 0, 0);
                gap.invalidateSelf();
            }
        }

        private void clearShifts() {
            int n = c.lv.getChildCount();
            for (int i = 0; i < n; i++) { View ch = c.lv.getChildAt(i); ch.animate().cancel(); ch.setTranslationY(0f); }
            if (gap != null) { c.lv.getOverlay().remove(gap); gap = null; }
            if (origin != null) { c.lv.getOverlay().remove(origin); origin = null; }
            if (ghost != null) { c.lv.getOverlay().remove(ghost); ghost = null; }
            if (ghostBmp != null) { ghostBmp.recycle(); ghostBmp = null; }
        }

        /** Perto da borda de cima/baixo a lista rola sozinha enquanto o dedo estiver ali. */
        private void startScroller() {
            scroller = new Runnable() {
                @Override public void run() {
                    if (!active || !dragging) return;
                    int[] loc = new int[2];
                    c.lv.getLocationOnScreen(loc);
                    float top = loc[1], bottom = loc[1] + c.lv.getHeight();
                    int step = 0;
                    if (fingerRawY < top + dp(c.a, EDGE_DP)) step = -dp(c.a, 10);
                    else if (fingerRawY > bottom - dp(c.a, EDGE_DP)) step = dp(c.a, 10);
                    if (step != 0) { c.lv.scrollListBy(step); updateTarget(); }
                    c.lv.postDelayed(this, 16);
                }
            };
            c.lv.post(scroller);
        }

        /** Ponto de insercao (antes da sprite N, 0..count) para o bloco: sempre nas pontas de um GIF/sprite, nunca no meio de outro GIF. */
        private int insertionPoint(int pos) {
            if (pos < 0 || pos >= c.rows.size()) return -1;
            int[] r = c.rows.get(pos);
            boolean down = pos > rowPos;
            if (r[0] == 0) {
                SpriteGroups.Group g = c.lib.groups.at(r[1]);
                if (g != null) return down ? g.last() + 1 : g.first;
                return down ? r[1] + 1 : r[1];
            }
            SpriteGroups.Group g = c.lib.groups.startingAt(r[1]);
            if (g == null) return -1;
            return down ? g.last() + 1 : g.first;
        }

        private void end(boolean drop) {
            if (scroller != null) c.lv.removeCallbacks(scroller);
            clearShifts();
            row.setAlpha(1f);
            for (int k = 0; k < blockRows; k++) { View chd = c.lv.getChildAt(rowPos + k - c.lv.getFirstVisiblePosition()); if (chd != null) chd.setAlpha(1f); }
            c.dragPos = -1;
            c.dragRows = 1;
            c.lv.drag = null;
            boolean go = drop && dragging;
            int pos = targetPos;
            targetPos = -1;
            dragging = false;
            if (!go) return;
            if (len > 1) {
                int ins = insertionPoint(pos);
                int nf = ins < 0 ? -1 : SpriteMove.blockTarget(from, len, Math.min(ins, c.lib.count()));
                if (nf < 0 || nf + len > c.lib.count()) return;
                commit(c.lib.moveBlock(from, len, nf), nf);
                return;
            }
            int ins = insertionPoint(pos);                      // nunca no meio de um GIF: antes ou depois dele
            if (ins < 0) return;
            int to = ins > from ? ins - 1 : ins;
            if (to == from || to < 0 || to >= c.lib.count()) return;
            commit(c.lib.move(from, to), to);
        }

        private void commit(int[] map, int to) {
            java.util.TreeSet<Integer> changed = SpriteRenumber.remapDac(c.ca.dac, map);
            SpriteMassDialogs.renumbered(c.ca, map);
            String saved = SpriteMassDialogs.persist(c.ca, changed);
            java.util.TreeSet<Integer> ns = new java.util.TreeSet<Integer>();
            for (Integer k : c.sel) ns.add(Integer.valueOf(k.intValue() >= 0 && k.intValue() < map.length ? map[k.intValue()] : k.intValue()));
            c.sel.clear();
            c.sel.addAll(ns);
            java.util.HashSet<Integer> no = new java.util.HashSet<Integer>();
            for (Integer f : c.open) {
                int nf = f.intValue() >= 0 && f.intValue() < map.length ? map[f.intValue()] : f.intValue();
                if (c.lib.groups.startingAt(nf) != null) no.add(Integer.valueOf(nf));
            }
            c.open.clear();
            c.open.addAll(no);
            int dissolved = c.lib.lastMoveDissolved;
            c.applied.run();
            String what = len > 1 ? "Bloco SPR_" + from + " a SPR_" + (from + len - 1) + " agora começa em SPR_" + to : "SPR_" + from + " agora é SPR_" + to;
            toast(c.a, what + (changed.isEmpty() ? "" : "  \u00b7  " + changed.size() + " ANO(s) ajustada(s)") + (dissolved > 0 ? "  \u00b7  " + dissolved + " GIF(s) desfeito(s)" : "") + saved);
        }
    }

    // ---- recorte ----

    /** Folha com o retangulo do recorte desenhado por cima. */
    private static final class CropView extends View {
        Bitmap sheet;
        int x, y, w, h, scale = 1;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        CropView(Activity a) { super(a); }
        @Override protected void onDraw(Canvas c) {
            c.drawColor(0xFF0D0F13);
            if (sheet == null) return;
            float s = Math.min(getWidth() / (float) sheet.getWidth(), getHeight() / (float) sheet.getHeight());
            p.setFilterBitmap(false);
            p.setColor(0xFF2A2F3A);
            c.drawRect(0, 0, sheet.getWidth() * s, sheet.getHeight() * s, p);
            c.drawBitmap(sheet, null, new android.graphics.RectF(0, 0, sheet.getWidth() * s, sheet.getHeight() * s), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, getResources().getDisplayMetrics().density));
            p.setColor(0xFFFF4D4D);
            c.drawRect(x * scale * s, y * scale * s, (x + w) * scale * s, (y + h) * scale * s, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    private static void crop(final Activity a, final CharAssets ca, final SpriteLib lib, final int idx, final Runnable applied) {
        Cnv.Entry e0 = ca.cnv.byImage(idx);
        final int[] v = {e0.source, e0.x, e0.y, e0.width, e0.height};
        final String[] names = {"folha", "x", "y", "largura", "altura"};
        final EditText[] ets = new EditText[5];
        final CropView cv = new CropView(a);
        cv.scale = lib.scale;
        final Runnable sync = new Runnable() {
            @Override public void run() {
                cv.sheet = lib.sheet(Math.max(0, Math.min(v[0], lib.sheetCount() - 1)));
                cv.x = v[1]; cv.y = v[2]; cv.w = v[3]; cv.h = v[4];
                cv.invalidate();
            }
        };
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 14), dp(a, 8), dp(a, 14), dp(a, 4));
        box.addView(cv, new LinearLayout.LayoutParams(-1, dp(a, 220)));
        box.addView(text(a, "Valores logicos do CNV (x" + lib.scale + " em pixels). Os pixels da folha nao se mexem: so o recorte muda.", 11, DIM, false), lpt(a, 6));
        for (int k = 0; k < 5; k++) {
            final int kk = k;
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView lab = text(a, names[k], 13, DIM, false);
            row.addView(lab, new LinearLayout.LayoutParams(dp(a, 70), -2));
            TextView minus = button(a, "−", null);
            final EditText et = new EditText(a);
            ets[k] = et;
            et.setText(String.valueOf(v[k]));
            et.setInputType(InputType.TYPE_CLASS_NUMBER);
            et.setSingleLine(true);
            et.setGravity(Gravity.CENTER);
            et.setTextColor(TEXT);
            et.setTypeface(Typeface.MONOSPACE);
            TextView plus = button(a, "+", null);
            final Runnable set = new Runnable() {
                @Override public void run() {
                    try { v[kk] = Math.max(0, Integer.parseInt(et.getText().toString().trim())); } catch (NumberFormatException ex) { et.setText(String.valueOf(v[kk])); }
                    sync.run();
                }
            };
            minus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { v[kk] = Math.max(0, v[kk] - 1); et.setText(String.valueOf(v[kk])); sync.run(); } });
            plus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { v[kk]++; et.setText(String.valueOf(v[kk])); sync.run(); } });
            et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override public boolean onEditorAction(TextView t, int act, android.view.KeyEvent ev) { set.run(); return false; }
            });
            et.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View x, boolean has) { if (!has) set.run(); } });
            row.addView(minus);
            row.addView(et, new LinearLayout.LayoutParams(dp(a, 90), -2));
            row.addView(plus);
            box.addView(row, lpt(a, 2));
        }
        sync.run();
        android.widget.ScrollView sv = new SafeScrollView(a);
        sv.addView(box);
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Recorte de SPR_" + idx).setView(sv)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("APLICAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) {
                        for (EditText et : ets) et.clearFocus();
                        lib.setCrop(idx, v[0], v[1], v[2], v[3], v[4]);
                        applied.run();
                    }
                }).show();
    }

    // ---- pecas ----

    private static Bitmap decode(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeFile(f.getPath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    static void toast(Activity a, String s) { I18nUi.toast(a, s, android.widget.Toast.LENGTH_LONG).show(); }

    static int dp(Activity a, int v) { return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f); }

    static LinearLayout.LayoutParams lpm(Activity a, int left) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(a, left), 0, 0, 0);
        return p;
    }

    private static LinearLayout.LayoutParams lpt(Activity a, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(a, top), 0, 0);
        return p;
    }

    static TextView text(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static TextView button(Activity a, String s, View.OnClickListener c) {
        TextView t = text(a, s, 12, TEXT, true);
        t.setPadding(dp(a, 14), dp(a, 9), dp(a, 14), dp(a, 9));
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setStroke(1, LINE);
        g.setCornerRadius(dp(a, 8));
        t.setBackground(g);
        if (c != null) t.setOnClickListener(c);
        return t;
    }
}
