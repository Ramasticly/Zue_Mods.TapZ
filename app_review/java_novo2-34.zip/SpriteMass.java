package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Operacoes em massa nos frames (MPTs) do DAC que usam certas imagens (sprites): uso, exclusao dos frames e edicao de dados.
 * Sem interface: a tela fica em {@link SpriteMassDialogs}.
 */
final class SpriteMass {
    private SpriteMass() { }

    /** Onde as imagens sao usadas. */
    static final class Usage {
        int frames;
        final List<Integer> anos = new ArrayList<Integer>();
        /** Algum frame atingido tem hitbox (flag 2) ou lancamento de projetil (flag 0). */
        boolean hitOrProjectile;
        /** Alguma ANO atingida pertence a um golpe do BIN (HDAT 4). */
        boolean attackAno;
    }

    static Usage usage(Dac dac, CharData cd, Set<Integer> images) {
        Usage u = new Usage();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            int n = 0;
            for (Ano.Mpt m : a.mpts) {
                if (!images.contains(Integer.valueOf(m.image))) continue;
                n++;
                if ((m.flags & 0x10) != 0) for (Ano.Hit h : m.hits) if (h.flag == 2 || h.flag == 0) u.hitOrProjectile = true;
            }
            if (n == 0) continue;
            u.frames += n;
            u.anos.add(Integer.valueOf(i));
            if (cd != null) {
                CharData.Move own = cd.ownerOf(i);
                if (own != null && !own.generic) u.attackAno = true;
            }
        }
        return u;
    }

    /**
     * Tira dos ANOs os frames que usam as imagens (os que sobram seguem em sequencia: $MPT_0, $MPT_1...).
     * ANO que ficou sem nenhum frame vira vazia ("$ANO_n: { },"). Devolve quantos frames sairam.
     */
    /** Links apagados pela ultima chamada de deleteFrames (apontavam para ANOs que ficaram vazias). */
    static int lastLinksRemoved;
    /** ANOs que a ultima chamada de deleteFrames alterou (para gravar no .txt). */
    static final java.util.TreeSet<Integer> lastChanged = new java.util.TreeSet<Integer>();

    static int deleteFrames(Dac dac, Set<Integer> images) {
        int removed = 0;
        java.util.HashSet<Integer> emptied = new java.util.HashSet<Integer>();
        lastLinksRemoved = 0;
        lastChanged.clear();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            ArrayList<Ano.Mpt> keep = new ArrayList<Ano.Mpt>();
            for (Ano.Mpt m : a.mpts) if (!images.contains(Integer.valueOf(m.image))) keep.add(m);
            if (keep.size() == a.mpts.length) continue;
            removed += a.mpts.length - keep.size();
            lastChanged.add(Integer.valueOf(i));
            if (keep.isEmpty()) { dac.setAno(i, new Ano(i, false, 0, 0, new Ano.Link[0], new Ano.Mpt[0])); emptied.add(Integer.valueOf(i)); }
            else dac.setAno(i, new Ano(i, true, a.flags, a.priority, a.links, FrameOps.normalizeLoop(a.mpts, keep.toArray(new Ano.Mpt[0]))));
        }
        // ANO vazia nao faz sentido como link: tira os links que apontam para as que ficaram vazias
        if (!emptied.isEmpty()) {
            for (int i = 0; i < dac.size(); i++) {
                Ano a = dac.getAno(i);
                if (a == null || !a.present || a.links.length == 0) continue;
                ArrayList<Ano.Link> ls = new ArrayList<Ano.Link>();
                for (Ano.Link l : a.links) if (!emptied.contains(Integer.valueOf(l.getAno()))) ls.add(l);
                if (ls.size() == a.links.length) continue;
                lastLinksRemoved += a.links.length - ls.size();
                lastChanged.add(Integer.valueOf(i));
                int fl = ls.isEmpty() ? (a.flags & ~2) : a.flags;
                dac.setAno(i, new Ano(i, true, fl, a.priority, ls.toArray(new Ano.Link[0]), a.mpts));
            }
        }
        return removed;
    }

    /** Frames que a ultima chamada de replaceUses trocou de imagem. */
    static int lastReplaced;

    /**
     * Troca o IMG de todo Frame de toda ANO que usa uma das imagens de {@code from} por {@code to} (so o indice: posicao, zoom e caixas ficam). Devolve as ANOs
     * alteradas; vazio e nada feito se {@code to} for negativo ou estiver em {@code from}. Na exclusao com substituicao roda ANTES da renumeracao, com os indices antigos.
     */
    static java.util.TreeSet<Integer> replaceUses(Dac dac, Set<Integer> from, int to) {
        java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>();
        lastReplaced = 0;
        if (dac == null || from == null || to < 0 || from.contains(Integer.valueOf(to))) return changed;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            boolean any = false;
            for (Ano.Mpt m : a.mpts) {
                if (m.image >= 0 && from.contains(Integer.valueOf(m.image))) { m.image = to; lastReplaced++; any = true; }
            }
            if (any) changed.add(Integer.valueOf(i));
        }
        return changed;
    }

    /** Aviso quando a imagem que entra tem tamanho diferente de alguma das que saem (so o IMG troca: o desenho muda de tamanho); vazio se nao ha diferenca. */
    static String sizeWarning(Cnv cnv, Set<Integer> from, int to) {
        Cnv.Entry t = cnv == null ? null : cnv.byImage(to);
        if (t == null) return "";
        StringBuilder b = new StringBuilder();
        for (Integer i : new java.util.TreeSet<Integer>(from)) {
            Cnv.Entry e = cnv.byImage(i.intValue());
            if (e == null || e.width <= 0 || e.height <= 0) continue;
            if (e.width != t.width || e.height != t.height) b.append(b.length() == 0 ? "" : ", ").append("SPR_").append(i).append(" (").append(e.width).append("x").append(e.height).append(")");
        }
        return b.length() == 0 ? "" : b + " tem tamanho diferente de SPR_" + to + " (" + t.width + "x" + t.height + "): só o IMG troca, então o desenho muda de tamanho e de âncora.";
    }

    // ---- edicao de dados em massa

    /** 0 = nao mexer, 1 = definir, 2 = remover. */
    static final int KEEP = 0, SET = 1, REMOVE = 2;

    static final class Edit {
        boolean zoom;  int zoomX = 100, zoomY = 100;
        boolean rot;   int rotDeg;
        boolean alpha; int alphaRaw;
        int hurt = KEEP, hit = KEEP;          // hurtbox (flag 1) / hitbox (flag 2)
        int[] hurtBox = {-16, -48, 32, 48};   // x, y, largura, altura
        int[] hitBox = {0, -40, 40, 24};
        int effect = KEEP; int effectAno = 0; int effectX, effectY;   // efeito do personagem (ANO 201..255)
        int pos = KEEP; int midX, midY;       // centro proprio do frame
        int flipH = KEEP, flipV = KEEP;       // SET = ligar, REMOVE = desligar

        boolean any() {
            return zoom || rot || alpha || hurt != KEEP || hit != KEEP || (effect != KEEP && (effect == REMOVE || effectAno >= 201))
                    || pos != KEEP || flipH != KEEP || flipV != KEEP;
        }
    }

    /** Flag de hit do efeito do personagem (ANO 201 = flag 71). */
    static int effectFlag(int ano) { return ObjModel.fxFlag(2, ano); }

    private static Ano.Mpt setHit(Ano.Mpt m, int flag, int mode, int x, int y, int w, int h) {
        ArrayList<Ano.Hit> hits = new ArrayList<Ano.Hit>();
        if ((m.flags & 0x10) != 0) for (Ano.Hit k : m.hits) if (k.flag != flag) hits.add(k);
        if (mode == SET) {
            Ano.Hit n = new Ano.Hit();
            n.flag = flag; n.x = x; n.y = y; n.width = w; n.height = h;
            hits.add(n);
        }
        m.hits = hits.isEmpty() ? Ano.NO_HITS : hits.toArray(new Ano.Hit[0]);
        if (m.hits.length > 0) m.flags |= 0x10; else m.flags &= ~0x10;
        return m;
    }

    /** Aplica a edicao num frame (copia). */
    static Ano.Mpt applyTo(Ano.Mpt src, Edit e) {
        Ano.Mpt m = src.copy();
        if (e.zoom || e.rot || e.alpha) {
            boolean has = (m.flags & 0x80) != 0;
            int rot = has ? m.rot : 0, al = has ? m.alphaRaw : 0, zx = has ? m.xZoom : 100, zy = has ? m.yZoom : 100;
            if (e.rot) rot = e.rotDeg;
            if (e.alpha) al = e.alphaRaw;
            if (e.zoom) { zx = e.zoomX; zy = e.zoomY; }
            if (rot == 0 && al == 0 && zx == 100 && zy == 100) { m.flags &= ~0x80; m.rot = 0; m.alphaRaw = 0; m.xZoom = 100; m.yZoom = 100; }
            else { m.flags |= 0x80; m.rot = rot; m.alphaRaw = al; m.xZoom = zx; m.yZoom = zy; }
        }
        if (e.hurt != KEEP) setHit(m, 1, e.hurt, e.hurtBox[0], e.hurtBox[1], e.hurtBox[2], e.hurtBox[3]);
        if (e.hit != KEEP) setHit(m, 2, e.hit, e.hitBox[0], e.hitBox[1], e.hitBox[2], e.hitBox[3]);
        if (e.effect != KEEP && (e.effect == REMOVE || e.effectAno >= 201)) {
            setHit(m, effectFlag(e.effectAno), e.effect, e.effectX, e.effectY, 0, 0);
        }
        if (e.pos == SET) { m.flags |= 1; m.midX = e.midX; m.midY = e.midY; }
        else if (e.pos == REMOVE) { m.flags &= ~1; m.midX = 0; m.midY = 0; }
        if (e.flipH != KEEP || e.flipV != KEEP) {
            int w = (m.flags & 2) != 0 ? m.wActFlag : 0;
            if (e.flipH == SET) w |= ObjModel.FLIP_H; else if (e.flipH == REMOVE) w &= ~ObjModel.FLIP_H;
            if (e.flipV == SET) w |= ObjModel.FLIP_V; else if (e.flipV == REMOVE) w &= ~ObjModel.FLIP_V;
            m.wActFlag = w;
            if (w != 0) m.flags |= 2; else m.flags &= ~2;
        }
        m.normalize();
        return m;
    }

    /** Aplica a edicao em todo frame do DAC que usa as imagens; devolve quantos frames mudaram. */
    static int apply(Dac dac, Set<Integer> images, Edit e) {
        if (!e.any()) return 0;
        int n = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            boolean touched = false;
            Ano.Mpt[] out = a.mpts.clone();
            for (int k = 0; k < out.length; k++) {
                if (!images.contains(Integer.valueOf(out[k].image))) continue;
                out[k] = applyTo(out[k], e);
                touched = true;
                n++;
            }
            if (touched) dac.setAno(i, new Ano(i, true, a.flags, a.priority, a.links, out));
        }
        return n;
    }
}
