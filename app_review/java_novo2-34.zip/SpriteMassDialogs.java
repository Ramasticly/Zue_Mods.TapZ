package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Telas das acoes em massa nas sprites: confirmar exclusao (com a opcao de tirar os frames) e editar os frames que as usam. */
final class SpriteMassDialogs {
    private SpriteMassDialogs() { }

    private static final int TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, WARN = 0xFFFFB454;

    static Set<Integer> setOf(List<Integer> l) { return new HashSet<Integer>(l); }

    // ------------------------------------------------------------------ excluir

    /** Confirma a exclusao de uma ou mais sprites; "Excluir Frames com essa Sprite" tira os frames em vez de deixa-los sem imagem. */
    static void confirmDelete(final Activity a, final CharAssets ca, final SpriteLib lib, final List<Integer> sprites, final Runnable applied) {
        SpriteDeleteWizard.start(a, ca, lib, sprites, applied);
    }

    /** Escolha de uma sprite (o resultado de "ESCOLHER SPRITE…"). */
    interface Chosen { void on(int sprite); }

    /**
     * Abre a lista de sprites so para escolher uma (sem editar; as de {@code excluded} nao podem ser escolhidas), com a barra de semelhanca contra a sprite {@code ref}.
     * {@code sigs} ja lidas (null = le agora, com a tela de "Analisando sprites").
     */
    static void pickSprite(final Activity a, final CharAssets ca, final SpriteLib lib, final Set<Integer> excluded, final int current, final int ref,
                           final java.util.Map<Integer, SpriteDedup.Sig> sigs, final Chosen out) {
        if (sigs == null) {
            SpriteSims.build(a, lib, new SpriteSims.Done() { @Override public void on(java.util.Map<Integer, SpriteDedup.Sig> s2) { pickSprite(a, ca, lib, excluded, current, ref, s2, out); } });
            return;
        }
        java.util.Map<Integer, Integer> scores = null;
        SpriteDedup.Sig rs = sigs.get(Integer.valueOf(ref));
        if (rs != null) scores = SpriteDedup.scores(rs, sigs.values());
        SpriteListScreen.show(a, ca.dir.getName(), ca, current, new SpriteListScreen.Picker() {
            @Override public void onPick(int image) { out.on(image); }
            @Override public void onPickFrames(int[] images, int[] delaysMs) { }
        }, null, excluded, scores, ref);
    }

    /**
     * Escolher do Personagem: os Frames que usam {@code from} passam a usar outra sprite; nada e excluido nem renumerado. Depois de escolher a sprite abre a confirmacao
     * (antiga | → nova) com CANCELAR | IGUALAR SPRITES | CONFIRMAR.
     */
    static void swapUses(final Activity a, final CharAssets ca, final SpriteLib lib, final int from, final Runnable applied) {
        final Set<Integer> one = new HashSet<Integer>();
        one.add(Integer.valueOf(from));
        final SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, one);
        if (u.frames == 0) { SpriteListScreen.toast(a, "Nenhum Frame de nenhuma ANO usa a SPR_" + from + ": não há o que trocar."); return; }
        pickSprite(a, ca, lib, one, -1, from, null, new Chosen() { @Override public void on(final int to) {
            if (to < 0 || to == from || !lib.has(to)) { SpriteListScreen.toast(a, "Escolha outra sprite (que exista)."); return; }
            String w = SpriteMass.sizeWarning(ca.cnv, one, to);
            String info = u.frames + " frame(s) em " + u.anos.size() + " ANO(s) vão de SPR_" + from + " para SPR_" + to + ". A SPR_" + from + " continua na lista e nada é renumerado." + (w.isEmpty() ? "" : "\n" + w);
            ReplaceConfirm.show(a, "Você quer trocar a SPR_" + from + " por SPR_" + to + "?", sprite(ca, from), sprite(ca, to), info,
                    new Runnable() { @Override public void run() {
                        java.util.TreeSet<Integer> changed = SpriteMass.replaceUses(ca.dac, one, to);
                        int n = SpriteMass.lastReplaced;
                        String saved = persist(ca, changed);
                        applied.run();
                        SpriteListScreen.toast(a, n + " frame(s) em " + changed.size() + " ANO(s) agora usam a SPR_" + to + saved);
                    } },
                    new Runnable() { @Override public void run() { equalizeToSprite(a, ca, from, to, applied); } }, null);
        } });
    }

    /** Resultado da ultima gravacao do DAC (texto para o usuario conferir). */
    static String lastPersist = "";

    /** Grava as ANOs alteradas em 000.dac.txt (as sprites/CNV sao gravadas na hora, entao o DAC precisa acompanhar). */
    static String persist(CharAssets ca, java.util.Collection<Integer> anos) {
        if (anos.isEmpty()) { lastPersist = "nenhuma ANO usava essas sprites: o DAC não mudou"; return ""; }
        java.io.File f = new java.io.File(ca.dir, "000.dac.txt");
        try {
            String r;
            if (!f.isFile()) {
                // sem o .txt de origem: grava o DAC inteiro no formato dele
                Saver.write(f, Saver.dacText(ca.dac, null));
                r = "000.dac.txt não existia: criado com todas as ANOs";
            } else {
                r = Saver.saveRuntime(ca.dir, ca.dac, ca.data, anos, null, false);
            }
            lastPersist = f.getPath() + "\nANOs gravadas: " + anos + "\n" + r;
            return "; DAC gravado em 000.dac.txt";
        } catch (Exception e) {
            lastPersist = "ERRO ao gravar " + f.getPath() + ":\n" + e;
            return "; ERRO ao gravar 000.dac.txt";
        }
    }

    /** ANOs que usam alguma das imagens. */
    static java.util.TreeSet<Integer> anosUsing(CharAssets ca, java.util.Collection<Integer> images) {
        java.util.TreeSet<Integer> r = new java.util.TreeSet<Integer>();
        r.addAll(SpriteMass.usage(ca.dac, ca.data, new java.util.HashSet<Integer>(images)).anos);
        return r;
    }

    // ------------------------------------------------------------------ editar frames

    /** Botao que alterna entre as opcoes (indice em {@code state[0]}). */
    private static TextView cycle(final Activity a, final String[] names, final int[] state, final Runnable changed) {
        final TextView t = SpriteListScreen.button(a, names[state[0]], null);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                state[0] = (state[0] + 1) % names.length;
                t.setText(names[state[0]]);
                t.setTextColor(state[0] == 0 ? DIM : ACCENT);
                if (changed != null) changed.run();
            }
        });
        t.setTextColor(state[0] == 0 ? DIM : ACCENT);
        return t;
    }

    private static EditText num(Activity a, int value) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(String.valueOf(value));
        e.setSelectAllOnFocus(true);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        e.setMinWidth(SpriteListScreen.dp(a, 56));
        return e;
    }

    private static int val(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (NumberFormatException x) { return def; }
    }

    private static LinearLayout fields(Activity a, String[] labels, EditText[] es) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < es.length; i++) {
            LinearLayout c = new LinearLayout(a);
            c.setOrientation(LinearLayout.VERTICAL);
            c.addView(SpriteListScreen.text(a, labels[i], 10, DIM, false));
            c.addView(es[i]);
            r.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return r;
    }

    private static void section(Activity a, LinearLayout col, String title, String note) {
        TextView t = SpriteListScreen.text(a, title, 13, ACCENT, true);
        t.setPadding(0, SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 2));
        col.addView(t);
        if (note != null) col.addView(SpriteListScreen.text(a, note, 11, DIM, false));
    }

    /** Acompanha a renumeracao de sprites (mapa antigo -> novo; -1 = excluida) nos padroes visuais de TBRE/utils/charNN. */
    static void renumbered(CharAssets ca, int[] map) {
        if (ca.defaults().remap(map)) ca.saveDefaults();
    }

    /** Sprite para a previa: recorte do cache. */
    static SpriteCache.Sprite sprite(CharAssets ca, int idx) { return ca.sprites.get(idx); }

    /**
     * EDITAR FRAMES: define o PADRAO visual das sprites (zoom X/Y, rotacao, alpha, centro, flip) para quando forem postas num Frame pela timeline. Nao muda os
     * Frames que ja existem. Hurtbox, hitbox e efeito continuam sendo ajustados uma imagem por vez.
     */
    static void editFrames(final Activity a, final CharAssets ca, final List<Integer> sprites, final Runnable applied) {
        if (sprites.isEmpty()) return;
        final int first = sprites.get(0).intValue();
        SpriteEqualizeScreen.Cfg cfg = new SpriteEqualizeScreen.Cfg();
        cfg.title = sprites.size() == 1 ? "Editar Frame  \u00b7  SPR_" + first : "Editar Frame  \u00b7  " + sprites.size() + " sprites";
        cfg.hint = "Define o padrão da sprite: ele é aplicado quando ela é posta num Frame pela timeline (Adicionar Sprite, trocar a Imagem). Os Frames que já existem não mudam."
                + (sprites.size() > 1 ? " Os valores valem para todas as sprites marcadas (a prévia mostra a SPR_" + first + ")." : "");
        cfg.main = sprite(ca, first);
        cfg.start = ca.defaults().get(first);
        cfg.resetTo = ca.defaults().auto(first);          // REDEFINIR volta ao padrao automatico (pes no chao, centrada)
        cfg.applyLabel = "SALVAR PADRÃO";
        cfg.extraLabel = "HURTBOX / HITBOX / EFEITO (uma imagem por vez, com prévia)";
        cfg.extra = new Runnable() { @Override public void run() { SpriteBoxEditor.show(a, ca, sprites, applied); } };
        cfg.on = new SpriteEqualizeScreen.Listener() {
            @Override public void apply(SpriteDefaults.Def f) {
                for (Integer s : sprites) ca.defaults().set(s.intValue(), f);
                String err = ca.saveDefaults();
                SpriteListScreen.toast(a, (sprites.size() == 1 ? "Padrão da SPR_" + first : "Padrão de " + sprites.size() + " sprites") + (f.isNeutral() ? " removido" : " salvo")
                        + " (vale para novas adições na timeline; os Frames existentes não mudam)" + (err == null ? "" : "; ERRO ao gravar: " + err));
                if (applied != null) applied.run();
            }
        };
        SpriteEqualizeScreen.show(a, cfg);
    }

    /**
     * IGUALAR SPRITES com outra sprite do personagem ({@code from} → {@code to}): tela com a original por baixo; ao aplicar, os Frames que usam a original passam a usar
     * a nova ja com o ajuste somado e o padrao da nova vira o da original + ajuste. Nada e excluido nem renumerado.
     */
    static void equalizeToSprite(final Activity a, final CharAssets ca, final int from, final int to, final Runnable applied) {
        SpriteEqualizeScreen.Cfg cfg = new SpriteEqualizeScreen.Cfg();
        cfg.title = "Igualar SPR_" + to + " \u2192 no lugar da SPR_" + from;
        cfg.hint = "A SPR_" + from + " (antiga, esmaecida) e a SPR_" + to + " (nova) aparecem ancoradas em 0,0, com o RAZ todo padrão (não os valores de um Frame). "
                + "Ajuste a nova até ficar igual à antiga: esses valores serão somados aos de cada Frame que usa a SPR_" + from + ".";
        cfg.main = sprite(ca, to);
        cfg.ghost = sprite(ca, from);
        cfg.relative = true;
        cfg.applyLabel = "IGUALAR";
        cfg.on = new SpriteEqualizeScreen.Listener() {
            @Override public void apply(SpriteDefaults.Def adj) {
                int[] cnt = new int[1];
                java.util.TreeSet<Integer> changed = SpriteDefaults.retarget(ca.dac, from, to, adj, cnt);
                ca.defaults().set(to, SpriteDefaults.add(ca.defaults().get(from), adj));
                String err = ca.saveDefaults();
                String saved = persist(ca, changed);
                applied.run();
                SpriteListScreen.toast(a, cnt[0] + " frame(s) em " + changed.size() + " ANO(s) agora usam a SPR_" + to + "; padrão da SPR_" + to + " atualizado" + saved
                        + (err == null ? "" : "; ERRO ao gravar o padrão: " + err));
            }
        };
        SpriteEqualizeScreen.show(a, cfg);
    }

    /** Depois de trocar a imagem do slot (dispositivo / CNV): soma o ajuste nos Frames do slot e no padrao dele; devolve o texto do aviso. */
    static String applyAdjustInSlot(CharAssets ca, int slot, SpriteDefaults.Def adj) {
        int[] cnt = new int[1];
        java.util.TreeSet<Integer> changed = SpriteDefaults.retarget(ca.dac, slot, slot, adj, cnt);
        ca.defaults().set(slot, SpriteDefaults.add(ca.defaults().get(slot), adj));
        String perr = ca.saveDefaults();
        String saved = persist(ca, changed);
        return "SPR_" + slot + " substituída; " + cnt[0] + " frame(s) em " + changed.size() + " ANO(s) igualado(s)" + saved + (perr == null ? "" : "; ERRO ao gravar o padrão: " + perr);
    }

    /** Igualar com a imagem do dispositivo: mostra a tela com a original (capturada antes de trocar) e a nova; {@code done} recebe o ajuste. */
    static void equalizeScreen(Activity a, CharAssets ca, int slot, SpriteCache.Sprite original, SpriteCache.Sprite fresh, SpriteEqualizeScreen.Listener done) {
        SpriteEqualizeScreen.Cfg cfg = new SpriteEqualizeScreen.Cfg();
        cfg.title = "Igualar a nova imagem da SPR_" + slot;
        cfg.hint = "A imagem atual da SPR_" + slot + " (esmaecida) e a nova aparecem ancoradas em 0,0, com o RAZ todo padrão (não os valores de um Frame). "
                + "Ajuste a nova até ficar igual à atual: esses valores serão somados aos de cada Frame que usa a SPR_" + slot + ".";
        cfg.main = fresh;
        cfg.ghost = original;
        cfg.relative = true;
        cfg.applyLabel = "SUBSTITUIR";
        cfg.on = done;
        SpriteEqualizeScreen.show(a, cfg);
    }
}
