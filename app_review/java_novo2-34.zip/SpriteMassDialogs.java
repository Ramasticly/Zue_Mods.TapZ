package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Telas das acoes em massa nas sprites: confirmar exclusao (com a opcao de tirar os frames) e editar os frames que as usam. */
final class SpriteMassDialogs {
    private SpriteMassDialogs() { }

    private static final int TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, WARN = 0xFFFFB454;

    static Set<Integer> setOf(List<Integer> l) { return new HashSet<Integer>(l); }

    // ------------------------------------------------------------------ excluir

    /** Confirma a exclusao de uma ou mais sprites; "Excluir Frames com essa Sprite" tira os frames em vez de deixa-los sem imagem. */
    static void confirmDelete(final Activity a, final CharAssets ca, final SpriteLib lib, final List<Integer> sprites, final Runnable applied) {
        final Set<Integer> set = setOf(sprites);
        final SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, set);
        String name = sprites.size() == 1 ? "SPR_" + sprites.get(0) : sprites.size() + " sprites";
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(SpriteListScreen.dp(a, 20), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 20), 0);
        TextView msg = SpriteListScreen.text(a, "As sprites seguintes são RENUMERADAS (se sai a SPR_0, a 1 vira 0, a 2 vira 1...) e todos os frames do DAC acompanham. "
                + (u.frames == 0 ? "Nenhum frame do DAC usa " + (sprites.size() == 1 ? "esta sprite." : "estas sprites.")
                : u.frames + " frame(s) em " + u.anos.size() + " ANO(s) usam " + (sprites.size() == 1 ? "esta sprite" : "estas sprites")
                + " e ficam sem imagem (imagem -1), a não ser que você marque uma das opções abaixo."), 13, TEXT, false);
        col.addView(msg);
        final CheckBox cb = new I18nCheckBox(a);
        cb.setText("Excluir Frames com essa Sprite");
        cb.setTextColor(TEXT);
        cb.setEnabled(u.frames > 0);
        col.addView(cb);
        TextView ex = SpriteListScreen.text(a, "Tira o frame completamente e os que sobram seguem em sequência. Se uma ANO ficar sem nenhum frame, ela fica vazia ($ANO_n: { }).", 11, DIM, false);
        col.addView(ex);
        // substituir: os Frames passam a usar outra sprite (so o IMG), depois a exclusao renumera
        final CheckBox cr = new I18nCheckBox(a);
        cr.setText("Substituir os Frames por outra Sprite");
        cr.setTextColor(TEXT);
        cr.setEnabled(u.frames > 0);
        col.addView(cr);
        final LinearLayout repBox = new LinearLayout(a);
        repBox.setOrientation(LinearLayout.VERTICAL);
        repBox.setVisibility(View.GONE);
        final int[] chosen = {-1};
        final ThumbView thumb = new ThumbView(a);
        final TextView repInfo = SpriteListScreen.text(a, "Nenhuma sprite escolhida.", 12, TEXT, false);
        final TextView repWarn = SpriteListScreen.text(a, "", 11, WARN, false);
        LinearLayout repRow = new LinearLayout(a);
        repRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        repRow.addView(thumb, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 64), SpriteListScreen.dp(a, 64)));
        LinearLayout rt = new LinearLayout(a);
        rt.setOrientation(LinearLayout.VERTICAL);
        rt.setPadding(SpriteListScreen.dp(a, 10), 0, 0, 0);
        rt.addView(repInfo);
        rt.addView(SpriteListScreen.button(a, "ESCOLHER SPRITE…", new View.OnClickListener() { @Override public void onClick(View v) {
            pickSprite(a, ca, lib, set, chosen[0], new Chosen() { @Override public void on(int sprite) {
                chosen[0] = sprite;
                thumb.set(ca.sprites, sprite);
                Cnv.Entry e = ca.cnv.byImage(sprite);
                repInfo.setText("SPR_" + sprite + (e == null ? "" : "  (" + e.width + "x" + e.height + ")"));
                repWarn.setText(SpriteMass.sizeWarning(ca.cnv, set, sprite));
            } });
        } }));
        repRow.addView(rt, new LinearLayout.LayoutParams(0, -2, 1f));
        repBox.addView(repRow);
        repBox.addView(repWarn);
        col.addView(repBox);
        TextView ex2 = SpriteListScreen.text(a, "Todo Frame que usava " + (sprites.size() == 1 ? "esta sprite" : "estas sprites") + " passa a usar a escolhida (só o IMG muda) e depois as sprites são renumeradas: a escolhida acompanha a nova numeração. Não pode ser uma das que saem.", 11, DIM, false);
        col.addView(ex2);
        cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() { @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
            if (on && cr.isChecked()) cr.setChecked(false);
        } });
        cr.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() { @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
            if (on && cb.isChecked()) cb.setChecked(false);
            repBox.setVisibility(on ? View.VISIBLE : View.GONE);
        } });
        ScrollView sv = new ScrollView(a);
        sv.addView(col);
        final AlertDialog dlg = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover " + name + "?").setView(sv)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("REMOVER", null).create();
        dlg.show();
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final boolean frames = cb.isChecked() && u.frames > 0;
                final boolean replace = cr.isChecked() && u.frames > 0;
                if (replace) {
                    int r = chosen[0];
                    if (r < 0 || set.contains(Integer.valueOf(r)) || !lib.has(r)) {      // revalida: a escolha precisa existir e nao pode sair junto
                        SpriteListScreen.toast(a, "Escolha a sprite que vai substituir (ela não pode ser uma das que saem).");
                        return;
                    }
                }
                dlg.dismiss();
                if (frames && (u.hitOrProjectile || u.attackAno)) {
                    String why = (u.hitOrProjectile ? "• há frames com hitbox ou lançamento de projétil entre os que serão excluídos\n" : "")
                            + (u.attackAno ? "• alguma sprite é de uma ANO de ataque do BIN (HDAT 4)\n" : "");
                    new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Atenção")
                            .setMessage("Excluir esses frames pode causar bugs no personagem (hitbox, projétil ou golpe deixam de existir ou mudam de frame):\n\n" + why
                                    + "\nContinuar mesmo assim?")
                            .setNegativeButton("CANCELAR", null)
                            .setPositiveButton("EXCLUIR", new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface d2, int w2) { doDelete(a, ca, lib, sprites, set, MODE_FRAMES, -1, applied); }
                            }).show();
                } else doDelete(a, ca, lib, sprites, set, replace ? MODE_REPLACE : frames ? MODE_FRAMES : MODE_BLANK, replace ? chosen[0] : -1, applied);
            }
        });
    }

    /** Escolha de uma sprite (o resultado de "ESCOLHER SPRITE…"). */
    interface Chosen { void on(int sprite); }

    /** Abre a lista de sprites so para escolher uma (sem editar; as de {@code excluded} nao podem ser escolhidas). */
    static void pickSprite(final Activity a, final CharAssets ca, final SpriteLib lib, final Set<Integer> excluded, int current, final Chosen out) {
        SpriteListScreen.show(a, ca.dir.getName(), ca, current, new SpriteListScreen.Picker() {
            @Override public void onPick(int image) { out.on(image); }
            @Override public void onPickFrames(int[] images, int[] delaysMs) { }
        }, null, excluded);
    }

    /** "Trocar os Usos" (menu da sprite): os Frames que usam {@code from} passam a usar outra sprite; nada e excluido nem renumerado. */
    static void swapUses(final Activity a, final CharAssets ca, final SpriteLib lib, final int from, final Runnable applied) {
        final Set<Integer> one = new HashSet<Integer>();
        one.add(Integer.valueOf(from));
        final SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, one);
        if (u.frames == 0) { SpriteListScreen.toast(a, "Nenhum Frame de nenhuma ANO usa a SPR_" + from + ": não há o que trocar."); return; }
        pickSprite(a, ca, lib, one, -1, new Chosen() { @Override public void on(final int to) {
            if (to < 0 || to == from || !lib.has(to)) { SpriteListScreen.toast(a, "Escolha outra sprite (que exista)."); return; }
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(SpriteListScreen.dp(a, 20), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 20), 0);
            LinearLayout row = new LinearLayout(a);
            row.setGravity(android.view.Gravity.CENTER);
            ThumbView t1 = new ThumbView(a), t2 = new ThumbView(a);
            t1.set(ca.sprites, from);
            t2.set(ca.sprites, to);
            row.addView(t1, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 84), SpriteListScreen.dp(a, 84)));
            row.addView(SpriteListScreen.text(a, "  →  ", 20, TEXT, true));
            row.addView(t2, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 84), SpriteListScreen.dp(a, 84)));
            col.addView(row);
            col.addView(SpriteListScreen.text(a, u.frames + " frame(s) em " + u.anos.size() + " ANO(s) vão de SPR_" + from + " para SPR_" + to
                    + ". A SPR_" + from + " continua na lista e nada é renumerado.", 13, TEXT, false));
            String w = SpriteMass.sizeWarning(ca.cnv, one, to);
            if (!w.isEmpty()) col.addView(SpriteListScreen.text(a, w, 11, WARN, false));
            new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Trocar os Usos").setView(col)
                    .setNegativeButton("CANCELAR", null)
                    .setPositiveButton("TROCAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface d, int wh) {
                        java.util.TreeSet<Integer> changed = SpriteMass.replaceUses(ca.dac, one, to);
                        int n = SpriteMass.lastReplaced;
                        String saved = persist(ca, changed);
                        applied.run();
                        SpriteListScreen.toast(a, n + " frame(s) em " + changed.size() + " ANO(s) agora usam a SPR_" + to + saved);
                    } }).show();
        } });
    }

    /** Resultado da ultima gravacao do DAC (texto para o usuario conferir). */
    static String lastPersist = "";

    /** Grava as ANOs alteradas em 000.dac.txt (as sprites/CNV sao gravadas na hora, entao o DAC precisa acompanhar). */
    static String persist(CharAssets ca, java.util.Collection<Integer> anos) {
        if (anos.isEmpty()) { lastPersist = "nenhuma ANO usava essas sprites: o DAC não mudou"; return ""; }
        java.io.File f = new java.io.File(ca.dir, "000.dac.txt");
        try {
            String r;
            if (!f.isFile()) {
                // sem o .txt de origem: grava o DAC inteiro no formato dele
                Saver.write(f, Saver.dacText(ca.dac, null));
                r = "000.dac.txt não existia: criado com todas as ANOs";
            } else {
                r = Saver.saveRuntime(ca.dir, ca.dac, ca.data, anos, null, false);
            }
            lastPersist = f.getPath() + "\nANOs gravadas: " + anos + "\n" + r;
            return "; DAC gravado em 000.dac.txt";
        } catch (Exception e) {
            lastPersist = "ERRO ao gravar " + f.getPath() + ":\n" + e;
            return "; ERRO ao gravar 000.dac.txt";
        }
    }

    /** ANOs que usam alguma das imagens. */
    static java.util.TreeSet<Integer> anosUsing(CharAssets ca, java.util.Collection<Integer> images) {
        java.util.TreeSet<Integer> r = new java.util.TreeSet<Integer>();
        r.addAll(SpriteMass.usage(ca.dac, ca.data, new java.util.HashSet<Integer>(images)).anos);
        return r;
    }

    static final int MODE_BLANK = 0, MODE_FRAMES = 1, MODE_REPLACE = 2;

    private static void doDelete(Activity a, CharAssets ca, SpriteLib lib, List<Integer> sprites, Set<Integer> set, int mode, int replacement, Runnable applied) {
        int n;
        boolean frames = mode == MODE_FRAMES;
        java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>();
        if (mode == MODE_FRAMES) { n = SpriteMass.deleteFrames(ca.dac, set); changed.addAll(SpriteMass.lastChanged); }
        else if (mode == MODE_REPLACE) { changed.addAll(SpriteMass.replaceUses(ca.dac, set, replacement)); n = SpriteMass.lastReplaced; }       // com os indices antigos
        else { changed.addAll(SpriteMass.usage(ca.dac, ca.data, set).anos); n = 0; for (Integer i : sprites) n += ca.clearImageUses(i.intValue()); }
        // exclui e RENUMERA (a SPR_1 vira 0 se a 0 sai...): o DAC inteiro acompanha, senao os frames apontariam para outras sprites
        int[] map = lib.removeShift(set);
        changed.addAll(SpriteRenumber.remapDac(ca.dac, map));
        // a remocao da sprite ja e gravada na hora (CNV/folhas); o DAC tambem, senao voltaria a apontar para sprites que nao existem
        String saved = persist(ca, changed);
        applied.run();
        if (!changed.isEmpty()) new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("DAC gravado")
                .setMessage(lastPersist).setPositiveButton("OK", null).show();
        String name = sprites.size() == 1 ? "SPR_" + sprites.get(0) + " removida" : sprites.size() + " sprites removidas";
        String what;
        if (n <= 0) what = saved;
        else if (mode == MODE_REPLACE) what = "; " + n + " frame(s) agora usam a SPR_" + (replacement >= 0 && replacement < map.length ? map[replacement] : replacement) + saved;
        else if (frames) what = "; " + n + " frame(s) excluído(s)" + (SpriteMass.lastLinksRemoved > 0 ? "; " + SpriteMass.lastLinksRemoved + " link(s) para ANO vazia removido(s)" : "") + saved;
        else what = "; " + n + " frame(s) do DAC ficaram com imagem -1" + saved;
        SpriteListScreen.toast(a, name + what);
    }

    // ------------------------------------------------------------------ editar frames

    /** Botao que alterna entre as opcoes (indice em {@code state[0]}). */
    private static TextView cycle(final Activity a, final String[] names, final int[] state, final Runnable changed) {
        final TextView t = SpriteListScreen.button(a, names[state[0]], null);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                state[0] = (state[0] + 1) % names.length;
                t.setText(names[state[0]]);
                t.setTextColor(state[0] == 0 ? DIM : ACCENT);
                if (changed != null) changed.run();
            }
        });
        t.setTextColor(state[0] == 0 ? DIM : ACCENT);
        return t;
    }

    private static EditText num(Activity a, int value) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(String.valueOf(value));
        e.setSelectAllOnFocus(true);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        e.setMinWidth(SpriteListScreen.dp(a, 56));
        return e;
    }

    private static int val(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (NumberFormatException x) { return def; }
    }

    private static LinearLayout fields(Activity a, String[] labels, EditText[] es) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < es.length; i++) {
            LinearLayout c = new LinearLayout(a);
            c.setOrientation(LinearLayout.VERTICAL);
            c.addView(SpriteListScreen.text(a, labels[i], 10, DIM, false));
            c.addView(es[i]);
            r.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return r;
    }

    private static void section(Activity a, LinearLayout col, String title, String note) {
        TextView t = SpriteListScreen.text(a, title, 13, ACCENT, true);
        t.setPadding(0, SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 2));
        col.addView(t);
        if (note != null) col.addView(SpriteListScreen.text(a, note, 11, DIM, false));
    }

    /** Muda dados dos frames que usam as sprites escolhidas (zoom, rotacao, alpha, hurtbox, hitbox, efeito, posicao e flip). */
    static void editFrames(final Activity a, final CharAssets ca, final List<Integer> sprites, final Runnable applied) {
        final Set<Integer> set = setOf(sprites);
        final SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, set);
        if (u.frames == 0) { SpriteListScreen.toast(a, "nenhum frame do DAC usa " + (sprites.size() == 1 ? "essa sprite" : "essas sprites")); return; }
        final SpriteMass.Edit ed = new SpriteMass.Edit();
        final ScrollView sv = new ScrollView(a);
        final LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(SpriteListScreen.dp(a, 18), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 18), SpriteListScreen.dp(a, 6));
        sv.addView(col);
        col.addView(SpriteListScreen.text(a, u.frames + " frame(s) em " + u.anos.size() + " ANO(s) usam " + (sprites.size() == 1 ? "SPR_" + sprites.get(0) : sprites.size() + " sprites")
                + ". Zoom, rotação, alpha, posição e flip valem para todos eles (toque no botão para alternar). Hurtbox, hitbox e efeito são ajustados uma imagem por vez.", 12, TEXT, false));

        final int[] sZoom = {0}, sRot = {0}, sAlpha = {0}, sPos = {0}, sFh = {0}, sFv = {0};
        final String[] onoff = {"não mexer", "definir"}, tri = {"não mexer", "definir", "remover"}, flip = {"não mexer", "ligar", "desligar"};

        section(a, col, "Zoom", "100 = tamanho normal.");
        col.addView(cycle(a, onoff, sZoom, null));
        final EditText zx = num(a, 100), zy = num(a, 100);
        col.addView(fields(a, new String[]{"zoom x %", "zoom y %"}, new EditText[]{zx, zy}));

        section(a, col, "Rotação", null);
        col.addView(cycle(a, onoff, sRot, null));
        final EditText rot = num(a, 0);
        col.addView(fields(a, new String[]{"graus"}, new EditText[]{rot}));

        section(a, col, "Alpha", "0 = opaco; 256 = aditivo; 512 = outro modo; +n = n/255 mais transparente.");
        col.addView(cycle(a, onoff, sAlpha, null));
        final EditText al = num(a, 0);
        col.addView(fields(a, new String[]{"alpha"}, new EditText[]{al}));

        section(a, col, "Hurtbox, hitbox e efeito", "Dependem do desenho de cada imagem: não entram em massa. Use o botão para ajustar uma imagem por vez, com prévia do frame.");
        final TextView oneBy = SpriteListScreen.button(a, "AJUSTAR UMA IMAGEM POR VEZ (com prévia)", null);
        col.addView(oneBy);

        section(a, col, "Posição (centro próprio do frame)", null);
        col.addView(cycle(a, tri, sPos, null));
        final EditText px = num(a, 0), py = num(a, 0);
        col.addView(fields(a, new String[]{"centro x", "centro y"}, new EditText[]{px, py}));

        section(a, col, "Flip (espelhar)", null);
        LinearLayout fl = new LinearLayout(a);
        fl.addView(SpriteListScreen.text(a, "horizontal ", 12, DIM, false));
        fl.addView(cycle(a, flip, sFh, null));
        fl.addView(SpriteListScreen.text(a, "  vertical ", 12, DIM, false));
        fl.addView(cycle(a, flip, sFv, null));
        col.addView(fl);

        final AlertDialog dlg = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Editar frames em massa").setView(sv)
                .setNegativeButton("CANCELAR", null).setPositiveButton("APLICAR", null).create();
        dlg.show();
        oneBy.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dlg.dismiss();
            SpriteBoxEditor.show(a, ca, sprites, applied);
        } });
        android.widget.Button pos = dlg.getButton(AlertDialog.BUTTON_POSITIVE);
        pos.setTextColor(ACCENT);
        pos.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            ed.zoom = sZoom[0] == 1; ed.zoomX = val(zx, 100); ed.zoomY = val(zy, 100);
            ed.rot = sRot[0] == 1; ed.rotDeg = val(rot, 0);
            ed.alpha = sAlpha[0] == 1; ed.alphaRaw = val(al, 0);
            ed.pos = sPos[0]; ed.midX = val(px, 0); ed.midY = val(py, 0);
            ed.flipH = sFh[0]; ed.flipV = sFv[0];
            if (!ed.any()) { SpriteListScreen.toast(a, "nada marcado para mudar"); return; }
            dlg.dismiss();
            int n = SpriteMass.apply(ca.dac, set, ed);
            applied.run();
            SpriteListScreen.toast(a, n + " frame(s) alterado(s) (salve o DAC para gravar)");
        } });
    }
}
