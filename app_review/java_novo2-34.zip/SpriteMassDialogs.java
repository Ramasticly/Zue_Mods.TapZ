package com.zue.attackeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Telas das acoes em massa nas sprites: confirmar exclusao (com a opcao de tirar os frames) e editar os frames que as usam. */
final class SpriteMassDialogs {
    private SpriteMassDialogs() { }

    private static final int TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, WARN = 0xFFFFB454;

    static Set<Integer> setOf(List<Integer> l) { return new HashSet<Integer>(l); }

    // ------------------------------------------------------------------ excluir

    /** Confirma a exclusao de uma ou mais sprites; "Excluir Frames com essa Sprite" tira os frames em vez de deixa-los sem imagem. */
    static void confirmDelete(final Activity a, final CharAssets ca, final SpriteLib lib, final List<Integer> sprites, final Runnable applied) {
        SpriteDeleteWizard.start(a, ca, lib, sprites, applied);
    }

    /** Escolha de uma sprite (o resultado de "ESCOLHER SPRITE…"). */
    interface Chosen { void on(int sprite); }

    /**
     * Abre a lista de sprites so para escolher uma (sem editar; as de {@code excluded} nao podem ser escolhidas), com a barra de semelhanca contra a sprite {@code ref}.
     * {@code sigs} ja lidas (null = le agora, com a tela de "Analisando sprites").
     */
    static void pickSprite(final Activity a, final CharAssets ca, final SpriteLib lib, final Set<Integer> excluded, final int current, final int ref,
                           final java.util.Map<Integer, SpriteDedup.Sig> sigs, final Chosen out) {
        if (sigs == null) {
            SpriteSims.build(a, lib, new SpriteSims.Done() { @Override public void on(java.util.Map<Integer, SpriteDedup.Sig> s2) { pickSprite(a, ca, lib, excluded, current, ref, s2, out); } });
            return;
        }
        java.util.Map<Integer, Integer> scores = null;
        SpriteDedup.Sig rs = sigs.get(Integer.valueOf(ref));
        if (rs != null) scores = SpriteDedup.scores(rs, sigs.values());
        SpriteListScreen.show(a, ca.dir.getName(), ca, current, new SpriteListScreen.Picker() {
            @Override public void onPick(int image) { out.on(image); }
            @Override public void onPickFrames(int[] images, int[] delaysMs) { }
        }, null, excluded, scores, ref);
    }

    /** "Trocar os Usos" (menu da sprite): os Frames que usam {@code from} passam a usar outra sprite; nada e excluido nem renumerado. */
    static void swapUses(final Activity a, final CharAssets ca, final SpriteLib lib, final int from, final Runnable applied) {
        final Set<Integer> one = new HashSet<Integer>();
        one.add(Integer.valueOf(from));
        final SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, one);
        if (u.frames == 0) { SpriteListScreen.toast(a, "Nenhum Frame de nenhuma ANO usa a SPR_" + from + ": não há o que trocar."); return; }
        pickSprite(a, ca, lib, one, -1, from, null, new Chosen() { @Override public void on(final int to) {
            if (to < 0 || to == from || !lib.has(to)) { SpriteListScreen.toast(a, "Escolha outra sprite (que exista)."); return; }
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(SpriteListScreen.dp(a, 20), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 20), 0);
            LinearLayout row = new LinearLayout(a);
            row.setGravity(android.view.Gravity.CENTER);
            ThumbView t1 = new ThumbView(a), t2 = new ThumbView(a);
            t1.set(ca.sprites, from);
            t2.set(ca.sprites, to);
            row.addView(t1, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 84), SpriteListScreen.dp(a, 84)));
            row.addView(SpriteListScreen.text(a, "  →  ", 20, TEXT, true));
            row.addView(t2, new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 84), SpriteListScreen.dp(a, 84)));
            col.addView(row);
            col.addView(SpriteListScreen.text(a, u.frames + " frame(s) em " + u.anos.size() + " ANO(s) vão de SPR_" + from + " para SPR_" + to
                    + ". A SPR_" + from + " continua na lista e nada é renumerado.", 13, TEXT, false));
            String w = SpriteMass.sizeWarning(ca.cnv, one, to);
            if (!w.isEmpty()) col.addView(SpriteListScreen.text(a, w, 11, WARN, false));
            new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Trocar os Usos").setView(col)
                    .setNegativeButton("CANCELAR", null)
                    .setPositiveButton("TROCAR", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface d, int wh) {
                        java.util.TreeSet<Integer> changed = SpriteMass.replaceUses(ca.dac, one, to);
                        int n = SpriteMass.lastReplaced;
                        String saved = persist(ca, changed);
                        applied.run();
                        SpriteListScreen.toast(a, n + " frame(s) em " + changed.size() + " ANO(s) agora usam a SPR_" + to + saved);
                    } }).show();
        } });
    }

    /** Resultado da ultima gravacao do DAC (texto para o usuario conferir). */
    static String lastPersist = "";

    /** Grava as ANOs alteradas em 000.dac.txt (as sprites/CNV sao gravadas na hora, entao o DAC precisa acompanhar). */
    static String persist(CharAssets ca, java.util.Collection<Integer> anos) {
        if (anos.isEmpty()) { lastPersist = "nenhuma ANO usava essas sprites: o DAC não mudou"; return ""; }
        java.io.File f = new java.io.File(ca.dir, "000.dac.txt");
        try {
            String r;
            if (!f.isFile()) {
                // sem o .txt de origem: grava o DAC inteiro no formato dele
                Saver.write(f, Saver.dacText(ca.dac, null));
                r = "000.dac.txt não existia: criado com todas as ANOs";
            } else {
                r = Saver.saveRuntime(ca.dir, ca.dac, ca.data, anos, null, false);
            }
            lastPersist = f.getPath() + "\nANOs gravadas: " + anos + "\n" + r;
            return "; DAC gravado em 000.dac.txt";
        } catch (Exception e) {
            lastPersist = "ERRO ao gravar " + f.getPath() + ":\n" + e;
            return "; ERRO ao gravar 000.dac.txt";
        }
    }

    /** ANOs que usam alguma das imagens. */
    static java.util.TreeSet<Integer> anosUsing(CharAssets ca, java.util.Collection<Integer> images) {
        java.util.TreeSet<Integer> r = new java.util.TreeSet<Integer>();
        r.addAll(SpriteMass.usage(ca.dac, ca.data, new java.util.HashSet<Integer>(images)).anos);
        return r;
    }

    // ------------------------------------------------------------------ editar frames

    /** Botao que alterna entre as opcoes (indice em {@code state[0]}). */
    private static TextView cycle(final Activity a, final String[] names, final int[] state, final Runnable changed) {
        final TextView t = SpriteListScreen.button(a, names[state[0]], null);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                state[0] = (state[0] + 1) % names.length;
                t.setText(names[state[0]]);
                t.setTextColor(state[0] == 0 ? DIM : ACCENT);
                if (changed != null) changed.run();
            }
        });
        t.setTextColor(state[0] == 0 ? DIM : ACCENT);
        return t;
    }

    private static EditText num(Activity a, int value) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(String.valueOf(value));
        e.setSelectAllOnFocus(true);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        e.setMinWidth(SpriteListScreen.dp(a, 56));
        return e;
    }

    private static int val(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (NumberFormatException x) { return def; }
    }

    private static LinearLayout fields(Activity a, String[] labels, EditText[] es) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < es.length; i++) {
            LinearLayout c = new LinearLayout(a);
            c.setOrientation(LinearLayout.VERTICAL);
            c.addView(SpriteListScreen.text(a, labels[i], 10, DIM, false));
            c.addView(es[i]);
            r.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return r;
    }

    private static void section(Activity a, LinearLayout col, String title, String note) {
        TextView t = SpriteListScreen.text(a, title, 13, ACCENT, true);
        t.setPadding(0, SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 2));
        col.addView(t);
        if (note != null) col.addView(SpriteListScreen.text(a, note, 11, DIM, false));
    }

    /** Muda dados dos frames que usam as sprites escolhidas (zoom, rotacao, alpha, hurtbox, hitbox, efeito, posicao e flip). */
    static void editFrames(final Activity a, final CharAssets ca, final List<Integer> sprites, final Runnable applied) {
        final Set<Integer> set = setOf(sprites);
        final SpriteMass.Usage u = SpriteMass.usage(ca.dac, ca.data, set);
        if (u.frames == 0) { SpriteListScreen.toast(a, "nenhum frame do DAC usa " + (sprites.size() == 1 ? "essa sprite" : "essas sprites")); return; }
        final SpriteMass.Edit ed = new SpriteMass.Edit();
        final ScrollView sv = new ScrollView(a);
        final LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(SpriteListScreen.dp(a, 18), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 18), SpriteListScreen.dp(a, 6));
        sv.addView(col);
        col.addView(SpriteListScreen.text(a, u.frames + " frame(s) em " + u.anos.size() + " ANO(s) usam " + (sprites.size() == 1 ? "SPR_" + sprites.get(0) : sprites.size() + " sprites")
                + ". Zoom, rotação, alpha, posição e flip valem para todos eles (toque no botão para alternar). Hurtbox, hitbox e efeito são ajustados uma imagem por vez.", 12, TEXT, false));

        final int[] sZoom = {0}, sRot = {0}, sAlpha = {0}, sPos = {0}, sFh = {0}, sFv = {0};
        final String[] onoff = {"não mexer", "definir"}, tri = {"não mexer", "definir", "remover"}, flip = {"não mexer", "ligar", "desligar"};

        section(a, col, "Zoom", "100 = tamanho normal.");
        col.addView(cycle(a, onoff, sZoom, null));
        final EditText zx = num(a, 100), zy = num(a, 100);
        col.addView(fields(a, new String[]{"zoom x %", "zoom y %"}, new EditText[]{zx, zy}));

        section(a, col, "Rotação", null);
        col.addView(cycle(a, onoff, sRot, null));
        final EditText rot = num(a, 0);
        col.addView(fields(a, new String[]{"graus"}, new EditText[]{rot}));

        section(a, col, "Alpha", "0 = opaco; 256 = aditivo; 512 = outro modo; +n = n/255 mais transparente.");
        col.addView(cycle(a, onoff, sAlpha, null));
        final EditText al = num(a, 0);
        col.addView(fields(a, new String[]{"alpha"}, new EditText[]{al}));

        section(a, col, "Hurtbox, hitbox e efeito", "Dependem do desenho de cada imagem: não entram em massa. Use o botão para ajustar uma imagem por vez, com prévia do frame.");
        final TextView oneBy = SpriteListScreen.button(a, "AJUSTAR UMA IMAGEM POR VEZ (com prévia)", null);
        col.addView(oneBy);

        section(a, col, "Posição (centro próprio do frame)", null);
        col.addView(cycle(a, tri, sPos, null));
        final EditText px = num(a, 0), py = num(a, 0);
        col.addView(fields(a, new String[]{"centro x", "centro y"}, new EditText[]{px, py}));

        section(a, col, "Flip (espelhar)", null);
        LinearLayout fl = new LinearLayout(a);
        fl.addView(SpriteListScreen.text(a, "horizontal ", 12, DIM, false));
        fl.addView(cycle(a, flip, sFh, null));
        fl.addView(SpriteListScreen.text(a, "  vertical ", 12, DIM, false));
        fl.addView(cycle(a, flip, sFv, null));
        col.addView(fl);

        final AlertDialog dlg = new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Editar frames em massa").setView(sv)
                .setNegativeButton("CANCELAR", null).setPositiveButton("APLICAR", null).create();
        dlg.show();
        oneBy.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dlg.dismiss();
            SpriteBoxEditor.show(a, ca, sprites, applied);
        } });
        android.widget.Button pos = dlg.getButton(AlertDialog.BUTTON_POSITIVE);
        pos.setTextColor(ACCENT);
        pos.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            ed.zoom = sZoom[0] == 1; ed.zoomX = val(zx, 100); ed.zoomY = val(zy, 100);
            ed.rot = sRot[0] == 1; ed.rotDeg = val(rot, 0);
            ed.alpha = sAlpha[0] == 1; ed.alphaRaw = val(al, 0);
            ed.pos = sPos[0]; ed.midX = val(px, 0); ed.midY = val(py, 0);
            ed.flipH = sFh[0]; ed.flipV = sFv[0];
            if (!ed.any()) { SpriteListScreen.toast(a, "nada marcado para mudar"); return; }
            dlg.dismiss();
            int n = SpriteMass.apply(ca.dac, set, ed);
            applied.run();
            SpriteListScreen.toast(a, n + " frame(s) alterado(s) (salve o DAC para gravar)");
        } });
    }
}
