package com.zue.attackeditor;

/** Mover uma sprite de slot (arrastar na lista): as do meio deslocam 1; CNV e DAC acompanham. Java puro. */
final class SpriteMove {
    private SpriteMove() { }

    /** Permutacao antigo -> novo: a sprite {@code from} vai para {@code to} e as do meio deslocam 1. Indices invalidos = identidade. */
    static int[] moveMap(int count, int from, int to) {
        int[] m = new int[Math.max(0, count)];
        for (int i = 0; i < m.length; i++) m[i] = i;
        if (from == to || from < 0 || to < 0 || from >= count || to >= count) return m;
        m[from] = to;
        if (to > from) { for (int i = from + 1; i <= to; i++) m[i] = i - 1; }
        else { for (int i = to; i < from; i++) m[i] = i + 1; }
        return m;
    }

    /** Reordena as entradas do CNV como {@link #moveMap}: o recorte (folha, x, y, largura, altura) vai junto com a sprite. */
    static void moveCnv(Cnv cnv, int from, int to) {
        int n = cnv.size();
        if (from == to || from < 0 || to < 0 || from >= n || to >= n) return;
        Cnv.Entry[] old = new Cnv.Entry[n];
        for (int i = 0; i < n; i++) old[i] = cnv.byImage(i);
        int[] map = moveMap(n, from, to);
        for (int i = 0; i < n; i++) {
            Cnv.Entry e = old[i];
            cnv.set(map[i], e.source, e.x, e.y, e.width, e.height);
        }
    }

    /** Verdadeiro se {@code map} e uma permutacao de 0..n-1 (sem repetir nem perder indices). */
    static boolean isPermutation(int[] map) {
        boolean[] seen = new boolean[map.length];
        for (int v : map) {
            if (v < 0 || v >= map.length || seen[v]) return false;
            seen[v] = true;
        }
        return true;
    }
}
