package com.zue.attackeditor;

/** Mover uma sprite de slot (arrastar na lista): as do meio deslocam 1; CNV e DAC acompanham. Java puro. */
final class SpriteMove {
    private SpriteMove() { }

    /** Permutacao antigo -> novo: a sprite {@code from} vai para {@code to} e as do meio deslocam 1. Indices invalidos = identidade. */
    static int[] moveMap(int count, int from, int to) {
        int[] m = new int[Math.max(0, count)];
        for (int i = 0; i < m.length; i++) m[i] = i;
        if (from == to || from < 0 || to < 0 || from >= count || to >= count) return m;
        m[from] = to;
        if (to > from) { for (int i = from + 1; i <= to; i++) m[i] = i - 1; }
        else { for (int i = to; i < from; i++) m[i] = i + 1; }
        return m;
    }

    /**
     * Permutacao antigo -> novo ao mover o BLOCO de {@code len} sprites que comeca em {@code first} (um GIF inteiro) para comecar em {@code newFirst}
     * (0 .. count - len); as de fora mantem a ordem e deslocam. Argumentos invalidos = identidade.
     */
    static int[] moveBlockMap(int count, int first, int len, int newFirst) {
        int[] m = new int[Math.max(0, count)];
        for (int i = 0; i < m.length; i++) m[i] = i;
        if (len < 1 || first < 0 || first + len > count || newFirst < 0 || newFirst + len > count || newFirst == first) return m;
        int[] order = new int[count];                       // order[k] = sprite antiga que ficara no slot k
        int o = 0, placed = 0;
        for (int k = 0; k < count; k++) {
            if (k >= newFirst && k < newFirst + len) { order[k] = first + (k - newFirst); placed++; continue; }
            while (o >= first && o < first + len) o++;      // pula o bloco
            order[k] = o++;
        }
        for (int k = 0; k < count; k++) m[order[k]] = k;
        return m;
    }

    /** Onde o bloco passa a comecar se for solto antes da sprite {@code ins} (0 .. count): nao muda nada se {@code ins} cai dentro ou nas pontas dele. -1 = sem mudanca. */
    static int blockTarget(int first, int len, int ins) {
        if (ins >= first && ins <= first + len) return -1;
        return ins > first + len ? ins - len : ins;
    }

    /** Reordena as entradas do CNV pelo mapa antigo -> novo: o recorte (folha, x, y, largura, altura) vai junto com a sprite. */
    static void applyMap(Cnv cnv, int[] map) {
        int n = cnv.size();
        if (map.length != n) return;
        Cnv.Entry[] old = new Cnv.Entry[n];
        for (int i = 0; i < n; i++) old[i] = cnv.byImage(i);
        for (int i = 0; i < n; i++) {
            Cnv.Entry e = old[i];
            cnv.set(map[i], e.source, e.x, e.y, e.width, e.height);
        }
    }

    /** Reordena as entradas do CNV como {@link #moveMap}. */
    static void moveCnv(Cnv cnv, int from, int to) { applyMap(cnv, moveMap(cnv.size(), from, to)); }

    /** Verdadeiro se {@code map} e uma permutacao de 0..n-1 (sem repetir nem perder indices). */
    static boolean isPermutation(int[] map) {
        boolean[] seen = new boolean[map.length];
        for (int v : map) {
            if (v < 0 || v >= map.length || seen[v]) return false;
            seen[v] = true;
        }
        return true;
    }
}
