package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * Botao OTIMIZAR da lista de sprites: remover sprites repetidas (espelhadas, giradas, em outra escala), remover sprites nao usadas e converter as folhas PNG para 8 bits.
 * Os calculos ficam em {@link SpriteDedup}, {@link SpriteXform}, {@link SpriteRenumber} e {@link Png8} (testados sem Android); aqui so a tela.
 */
final class SpriteOptimize {
    private SpriteOptimize() { }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, WARN = 0xFFFFB454;

    static void menu(final Activity a, final CharAssets ca, final SpriteLib lib, final Runnable applied) {
        String[] items = {"Remover Sprites repetidas", "Remover Sprites não usadas", "Otimizar PNGs (8 bits)"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Otimizar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) dedup(a, ca, lib, applied);
                        else if (which == 1) UnusedScreen.show(a, ca, lib, applied);
                        else pngs(a, ca, lib, applied);
                    }
                }).setNegativeButton("FECHAR", null).show();
    }

    // ------------------------------------------------------------------ 1. sprites repetidas

    private static void dedup(final Activity a, final CharAssets ca, final SpriteLib lib, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Analisando sprites");
        new Thread(new Runnable() {
            @Override public void run() {
                final List<SpriteDedup.Sig> sigs = new ArrayList<SpriteDedup.Sig>();
                int n = lib.count();
                try {
                    for (int i = 0; i < n; i++) {
                        busy.set("Lendo sprites", i, n);
                        int[] ls = lib.logicalSize(i);
                        if (ls == null) continue;
                        Bitmap b = lib.cut(i);
                        if (b == null) continue;
                        int[] px = new int[b.getWidth() * b.getHeight()];
                        b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                        sigs.add(SpriteDedup.sig(i, px, b.getWidth(), b.getHeight(), ls[0], ls[1]));
                        b.recycle();
                    }
                } catch (Throwable t) { /* segue com o que leu */ }
                // giros em qualquer angulo, pares candidatos e conferencia em pixels: uma vez so, pode demorar (ate 4 min)
                DedupAnalysis found = new DedupAnalysis();
                for (SpriteDedup.Sig s : sigs) found.byIndex.put(Integer.valueOf(s.index), s);
                try {
                    found = DedupAnalysis.analyze(sigs, new DedupAnalysis.Progress() {
                        @Override public boolean on(String stage, int done, int total) { busy.set(stage, done, total); return true; }
                    }, 240000);
                } catch (Throwable t) { found.complete = false; }
                final DedupAnalysis an = found;
                busy.dismiss();
                a.runOnUiThread(new Runnable() { @Override public void run() { DedupScreen.show(a, ca, lib, sigs, an, applied); } });
            }
        }).start();
    }

    // ------------------------------------------------------------------ 2. PNGs de 8 bits

    private static void pngs(final Activity a, final CharAssets ca, final SpriteLib lib, final Runnable applied) {
        final List<File> sheets = SheetFiles.list(ca.dir);
        if (sheets.isEmpty()) { SpriteListScreen.toast(a, "Nenhuma folha PNG nesta pasta"); return; }
        String msg = "Converte as " + sheets.size() + " folha(s) PNG para 8 bits com paleta (até 256 cores por folha, transparência mantida) para diminuir o tamanho. "
                + "Folhas com mais de 256 cores perdem um pouco de cor. Folhas que não ficam menores não são trocadas.\n\n"
                + "Antes de gravar, o personagem INTEIRO (DAC, CNV, Bin, áudios, PNGs e GIFs) é copiado, sem alterar nada, para\nBackups/PreOptim/AAAAMMDD_HHMMSS_" + ca.dir.getName() + "/\n"
                + "(ocupa o mesmo espaço do personagem a cada vez).";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Otimizar PNGs").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("OTIMIZAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) { runPngs(a, ca, lib, sheets, applied); }
                }).show();
    }

    private static void runPngs(final Activity a, final CharAssets ca, final SpriteLib lib, final List<File> sheets, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Otimizando PNGs");
        new Thread(new Runnable() {
            @Override public void run() {
                StringBuilder sb = new StringBuilder();
                long before = 0, after = 0;
                int done = 0;
                File bk;
                try {
                    bk = PreOptimBackup.run(ca.dir, new java.util.Date(), new Saver.CopyProgress() {
                        @Override public void on(String file, int d, int total) { busy.set("Copiando o personagem\n" + file, d, total); }
                    });
                } catch (Throwable t) {
                    busy.dismiss();
                    final String msg = "Não consegui fazer a cópia de segurança, então nada foi alterado:\n" + t.getMessage();
                    a.runOnUiThread(new Runnable() { @Override public void run() { new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Otimizar PNGs").setMessage(msg).setPositiveButton("OK", null).show(); } });
                    return;
                }
                for (File f : sheets) {
                    busy.set(f.getName(), done++, sheets.size());
                    long old = f.length();
                    before += old;
                    try {
                        final Bitmap bm = BitmapFactory.decodeFile(f.getPath());
                        if (bm == null) { sb.append(f.getName()).append(": não consegui ler\n"); after += old; continue; }
                        final int w = bm.getWidth(), h = bm.getHeight();
                        Png8.Out o = Png8.encode(new Png8.Rows() {
                            @Override public int width() { return w; }
                            @Override public int height() { return h; }
                            @Override public void row(int y, int[] out) { bm.getPixels(out, 0, w, 0, y, w, 1); }
                        });
                        bm.recycle();
                        Png8.Img check = Png8.decode(o.png);
                        if (check.w != w || check.h != h) throw new IOException("conferência falhou (tamanho)");
                        if (o.png.length >= old) { sb.append(f.getName()).append(": já é pequena (").append(old / 1024).append(" KB), mantida\n"); after += old; continue; }
                        SpriteLib.writeAtomic(f, o.png);
                        after += o.png.length;
                        sb.append(f.getName()).append(": ").append(old / 1024).append(" KB → ").append(o.png.length / 1024).append(" KB (").append(o.colors).append(" cores")
                                .append(o.lossless ? ", sem perda" : ", reduzida").append(")\n");
                    } catch (Throwable t) {
                        after += old;
                        sb.append(f.getName()).append(": erro ").append(t.getMessage()).append('\n');
                    }
                }
                sb.append("\nTotal: ").append(before / 1024).append(" KB → ").append(after / 1024).append(" KB\nCópia bruta do personagem: ").append(bk.getPath());
                busy.dismiss();
                final String text = sb.toString();
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        lib.dropSheetCache();
                        applied.run();
                        TextView tv = SpriteListScreen.text(a, text, 12, TEXT, false);
                        tv.setPadding(SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 8));
                        ScrollView s = new ScrollView(a);
                        s.addView(tv);
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("PNGs otimizados").setView(s).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }
}
