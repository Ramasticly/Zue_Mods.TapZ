package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * Botao OTIMIZAR da lista de sprites: remover sprites repetidas (espelhadas, giradas, em outra escala) e converter as folhas PNG para 8 bits.
 * Os calculos ficam em {@link SpriteDedup}, {@link SpriteXform}, {@link SpriteRenumber} e {@link Png8} (testados sem Android); aqui so a tela.
 */
final class SpriteOptimize {
    private SpriteOptimize() { }

    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, LINE = 0xFF3A4150, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, WARN = 0xFFFFB454;

    static void menu(final Activity a, final CharAssets ca, final SpriteLib lib, final Runnable applied) {
        String[] items = {"Remover Sprites repetidas", "Otimizar PNGs (8 bits)"};
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Otimizar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) dedup(a, ca, lib, applied); else pngs(a, ca, lib, applied);
                    }
                }).setNegativeButton("FECHAR", null).show();
    }

    // ------------------------------------------------------------------ backup

    /** Tap Battle/TBRE/Backups/PreOptim/charNN/ (criada se preciso). */
    static File backupDir(File charDir) {
        File d = new File(new File(Saver.backupsDir(charDir), "PreOptim"), charDir.getName());
        d.mkdirs();
        return d;
    }

    /** Copia o arquivo para a pasta de backup sem sobrescrever um backup que ja exista (o primeiro e o original de verdade). */
    static boolean backup(File charDir, File f) throws IOException {
        if (f == null || !f.isFile()) return false;
        File out = new File(backupDir(charDir), f.getName());
        if (out.exists()) return false;
        FileInputStream in = new FileInputStream(f);
        FileOutputStream os = new FileOutputStream(out);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } finally { in.close(); os.close(); }
        return true;
    }

    // ------------------------------------------------------------------ 1. sprites repetidas

    private static void dedup(final Activity a, final CharAssets ca, final SpriteLib lib, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Analisando sprites");
        new Thread(new Runnable() {
            @Override public void run() {
                final List<SpriteDedup.Sig> sigs = new ArrayList<SpriteDedup.Sig>();
                int n = lib.count();
                try {
                    for (int i = 0; i < n; i++) {
                        busy.set("Lendo sprites", i, n);
                        int[] ls = lib.logicalSize(i);
                        if (ls == null) continue;
                        Bitmap b = lib.cut(i);
                        if (b == null) continue;
                        int[] px = new int[b.getWidth() * b.getHeight()];
                        b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                        sigs.add(SpriteDedup.sig(i, px, b.getWidth(), b.getHeight(), ls[0], ls[1]));
                        b.recycle();
                    }
                } catch (Throwable t) { /* segue com o que leu */ }
                busy.dismiss();
                a.runOnUiThread(new Runnable() { @Override public void run() { dedupScreen(a, ca, lib, sigs, applied); } });
            }
        }).start();
    }

    private static String relation(int g) {
        switch (g) {
            case 0: return "igual (ou só em outra escala)";
            case 1: return "espelhada na horizontal (Flip X)";
            case 2: return "espelhada na vertical (Flip Y)";
            case 3: return "girada 180°";
            default: return "girada 90° (ou espelhada na diagonal)";
        }
    }

    private static void dedupScreen(final Activity a, final CharAssets ca, final SpriteLib lib, final List<SpriteDedup.Sig> sigs, final Runnable applied) {
        final Dialog d = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, SpriteListScreen.dp(a, 12), 0, 0);
        d.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Remover Sprites repetidas", 16, TEXT, true);
        ti.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, "Sprites iguais ou parecidas (também espelhadas, giradas 90° ou em outra escala) formam um grupo. Marque as que quer REMOVER: os frames do DAC "
                + "passam a usar a que fica, com Flip, zoom, rotação e posição ajustados para o desenho ficar igual. Em cada grupo precisa ficar ao menos uma.", 11, DIM, false);
        hint.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        root.addView(hint);
        final TextView tol = SpriteListScreen.text(a, "", 14, ACCENT, true);
        tol.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), 0);
        root.addView(tol);
        final SeekBar sb = new SeekBar(a);
        sb.setMax(50);
        sb.setProgress(40);
        sb.setPadding(SpriteListScreen.dp(a, 18), SpriteListScreen.dp(a, 6), SpriteListScreen.dp(a, 18), SpriteListScreen.dp(a, 6));
        root.addView(sb);
        final TextView sum = SpriteListScreen.text(a, "", 12, TEXT, false);
        sum.setPadding(SpriteListScreen.dp(a, 14), 0, SpriteListScreen.dp(a, 14), SpriteListScreen.dp(a, 6));
        root.addView(sum);
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final TextView ok = SpriteListScreen.button(a, "REMOVER MARCADAS", null);
        final Map<Integer, SpriteDedup.Sig> byIndex = new HashMap<Integer, SpriteDedup.Sig>();
        for (SpriteDedup.Sig s : sigs) byIndex.put(Integer.valueOf(s.index), s);
        final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
        final HashSet<Integer> remove = new HashSet<Integer>();
        final List<SpriteDedup.Group>[] groups = new List[1];
        final int[] minPct = {90};
        final Runnable[] rebuild = new Runnable[1];
        final Runnable counts = new Runnable() {
            @Override public void run() {
                int n = remove.size();
                sum.setText(groups[0].isEmpty() ? "Nenhum grupo de sprites repetidas com esta semelhança." : groups[0].size() + " grupo(s); " + n + " sprite(s) marcada(s) para remover de " + sigs.size() + ".");
                ok.setEnabled(n > 0);
                ok.setAlpha(n > 0 ? 1f : 0.4f);
            }
        };
        rebuild[0] = new Runnable() {
            @Override public void run() {
                minPct[0] = 50 + sb.getProgress();
                tol.setText("Semelhança mínima: " + minPct[0] + "%" + (minPct[0] == 100 ? "  (só idênticas)" : ""));
                groups[0] = SpriteDedup.groups(sigs, minPct[0]);
                remove.clear();
                list.removeAllViews();
                for (final SpriteDedup.Group g : groups[0]) {
                    LinearLayout card = new LinearLayout(a);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8));
                    card.setBackgroundColor(CARD);
                    LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
                    clp.setMargins(SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 4), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 4));
                    final List<CheckBox> boxes = new ArrayList<CheckBox>();
                    for (int mi = 0; mi < g.members.size(); mi++) {
                        final SpriteDedup.Member m = g.members.get(mi);
                        LinearLayout row = new LinearLayout(a);
                        row.setOrientation(LinearLayout.HORIZONTAL);
                        row.setGravity(Gravity.CENTER_VERTICAL);
                        row.setPadding(0, SpriteListScreen.dp(a, 4), 0, SpriteListScreen.dp(a, 4));
                        row.addView(thumb(a, lib, thumbs, m.index), new LinearLayout.LayoutParams(SpriteListScreen.dp(a, 56), SpriteListScreen.dp(a, 56)));
                        SpriteDedup.Sig sg = byIndex.get(Integer.valueOf(m.index));
                        TextView t = new I18nTextView(a);
                        t.setTextSize(12);
                        t.setTextColor(m.toRep == null ? OK : TEXT);
                        t.setPadding(SpriteListScreen.dp(a, 10), 0, SpriteListScreen.dp(a, 6), 0);
                        t.setText("SPR_" + m.index + "  (" + (sg == null ? 0 : sg.w) + "×" + (sg == null ? 0 : sg.h) + ")\n"
                                + (m.toRep == null ? "a maior do grupo" : relation(m.toRep.g) + " · " + m.toRep.score + "%"));
                        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                        final CheckBox cb = new I18nCheckBox(a);
                        cb.setText("remover");
                        cb.setTextColor(TEXT);
                        cb.setTextSize(12);
                        boxes.add(cb);
                        final Integer key = Integer.valueOf(m.index);
                        if (m.toRep != null) { cb.setChecked(true); remove.add(key); }
                        cb.setOnClickListener(new View.OnClickListener() {
                            @Override public void onClick(View v) {
                                if (cb.isChecked()) {
                                    int staying = 0;
                                    for (SpriteDedup.Member o : g.members) if (!remove.contains(Integer.valueOf(o.index)) && o.index != m.index) staying++;
                                    if (staying == 0) {
                                        cb.setChecked(false);
                                        SpriteListScreen.toast(a, "Precisa ficar ao menos uma sprite em cada grupo");
                                        return;
                                    }
                                    remove.add(key);
                                } else remove.remove(key);
                                counts.run();
                            }
                        });
                        row.addView(cb);
                        card.addView(row);
                    }
                    list.addView(card, clp);
                }
                counts.run();
            }
        };
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { tol.setText("Semelhança mínima: " + (50 + p) + "%"); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { rebuild[0].run(); }
        });
        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 12), SpriteListScreen.dp(a, 12));
        foot.addView(SpriteListScreen.button(a, "VOLTAR", new View.OnClickListener() { @Override public void onClick(View v) { d.dismiss(); } }));
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (remove.isEmpty()) return;
                d.dismiss();
                applyDedup(a, ca, lib, groups[0], remove, byIndex, minPct[0], applied);
            }
        });
        foot.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        d.show();
        rebuild[0].run();
    }

    private static ImageView thumb(Activity a, SpriteLib lib, Map<Integer, Bitmap> cache, int idx) {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        Bitmap tb = cache.get(Integer.valueOf(idx));
        if (tb == null) {
            Bitmap full = lib.cut(idx);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                cache.put(Integer.valueOf(idx), tb);
            }
        }
        if (tb != null) iv.setImageBitmap(tb);
        return iv;
    }

    private static void applyDedup(final Activity a, final CharAssets ca, final SpriteLib lib, final List<SpriteDedup.Group> groups, final HashSet<Integer> remove,
                                   final Map<Integer, SpriteDedup.Sig> byIndex, final int minPct, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Removendo sprites repetidas");
        busy.set("Reescrevendo os frames...", 0, 0);
        new Thread(new Runnable() {
            @Override public void run() {
                String out;
                try {
                    // backup antes de mexer: DAC, CNV e grupos de GIF (texto)
                    int copied = 0;
                    for (String n : new String[]{"000.dac.txt", "000.cnv.txt", SpriteGroups.FILE}) if (backup(ca.dir, new File(ca.dir, n))) copied++;
                    List<SpriteDedup.Choice> choices = new ArrayList<SpriteDedup.Choice>();
                    for (SpriteDedup.Group g : groups) {
                        List<SpriteDedup.Sig> kept = new ArrayList<SpriteDedup.Sig>();
                        for (SpriteDedup.Member m : g.members) if (!remove.contains(Integer.valueOf(m.index))) kept.add(byIndex.get(Integer.valueOf(m.index)));
                        for (SpriteDedup.Member m : g.members) {
                            if (!remove.contains(Integer.valueOf(m.index))) continue;
                            SpriteDedup.Choice c = SpriteDedup.choose(byIndex.get(Integer.valueOf(m.index)), kept, 0);
                            if (c != null) choices.add(c);
                        }
                    }
                    SpriteDedup.Result res = SpriteDedup.apply(ca.dac, choices);
                    java.util.TreeSet<Integer> changed = new java.util.TreeSet<Integer>(res.changedAnos);
                    if (!res.removedSprites.isEmpty()) {
                        int[] map = lib.removeShift(res.removedSprites);
                        changed.addAll(SpriteRenumber.remapDac(ca.dac, map));
                    }
                    String saved = SpriteMassDialogs.persist(ca, changed);
                    StringBuilder sb = new StringBuilder();
                    sb.append(res.removedSprites.size()).append(" sprite(s) removida(s); ").append(res.framesRewritten).append(" frame(s) reescrito(s) em ").append(res.changedAnos.size()).append(" ANO(s).\n");
                    sb.append("As sprites seguintes foram renumeradas.\n");
                    if (!res.skipped.isEmpty()) sb.append("Ficaram (algum frame não tem como ficar igual): SPR_").append(res.skipped).append('\n');
                    sb.append("\nCópia dos arquivos anteriores: ").append(backupDir(ca.dir).getPath()).append(copied == 0 ? " (já havia cópia; a original foi mantida)" : "").append(saved.isEmpty() ? "" : "\n" + SpriteMassDialogs.lastPersist);
                    out = sb.toString();
                } catch (Throwable t) {
                    out = "Erro ao remover sprites repetidas: " + t;
                }
                busy.dismiss();
                final String text = out;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        applied.run();
                        TextView tv = SpriteListScreen.text(a, text, 13, TEXT, false);
                        tv.setPadding(SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 8));
                        ScrollView s = new ScrollView(a);
                        s.addView(tv);
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Sprites repetidas").setView(s).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------ 2. PNGs de 8 bits

    private static void pngs(final Activity a, final CharAssets ca, final SpriteLib lib, final Runnable applied) {
        final List<File> sheets = SheetFiles.list(ca.dir);
        if (sheets.isEmpty()) { SpriteListScreen.toast(a, "Nenhuma folha PNG nesta pasta"); return; }
        String msg = "Converte as " + sheets.size() + " folha(s) PNG para 8 bits com paleta (até 256 cores por folha, transparência mantida) para diminuir o tamanho. "
                + "Folhas com mais de 256 cores perdem um pouco de cor.\n\nAntes de gravar, os PNG originais são copiados para\nBackups/PreOptim/" + ca.dir.getName() + "/\n"
                + "(se já existir cópia de um arquivo, a original é mantida). Folhas que não ficam menores não são trocadas.";
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Otimizar PNGs").setMessage(msg)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("OTIMIZAR", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) { runPngs(a, ca, lib, sheets, applied); }
                }).show();
    }

    private static void runPngs(final Activity a, final CharAssets ca, final SpriteLib lib, final List<File> sheets, final Runnable applied) {
        final BusyDialog busy = BusyDialog.show(a, "Otimizando PNGs");
        new Thread(new Runnable() {
            @Override public void run() {
                StringBuilder sb = new StringBuilder();
                long before = 0, after = 0;
                int done = 0;
                for (File f : sheets) {
                    busy.set(f.getName(), done++, sheets.size());
                    long old = f.length();
                    before += old;
                    try {
                        final Bitmap bm = BitmapFactory.decodeFile(f.getPath());
                        if (bm == null) { sb.append(f.getName()).append(": não consegui ler\n"); after += old; continue; }
                        final int w = bm.getWidth(), h = bm.getHeight();
                        Png8.Out o = Png8.encode(new Png8.Rows() {
                            @Override public int width() { return w; }
                            @Override public int height() { return h; }
                            @Override public void row(int y, int[] out) { bm.getPixels(out, 0, w, 0, y, w, 1); }
                        });
                        bm.recycle();
                        Png8.Img check = Png8.decode(o.png);
                        if (check.w != w || check.h != h) throw new IOException("conferência falhou (tamanho)");
                        if (o.png.length >= old) { sb.append(f.getName()).append(": já é pequena (").append(old / 1024).append(" KB), mantida\n"); after += old; continue; }
                        backup(ca.dir, f);
                        SpriteLib.writeAtomic(f, o.png);
                        after += o.png.length;
                        sb.append(f.getName()).append(": ").append(old / 1024).append(" KB → ").append(o.png.length / 1024).append(" KB (").append(o.colors).append(" cores")
                                .append(o.lossless ? ", sem perda" : ", reduzida").append(")\n");
                    } catch (Throwable t) {
                        after += old;
                        sb.append(f.getName()).append(": erro ").append(t.getMessage()).append('\n');
                    }
                }
                sb.append("\nTotal: ").append(before / 1024).append(" KB → ").append(after / 1024).append(" KB\nCópia dos originais: ").append(backupDir(ca.dir).getPath());
                busy.dismiss();
                final String text = sb.toString();
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        lib.dropSheetCache();
                        applied.run();
                        TextView tv = SpriteListScreen.text(a, text, 12, TEXT, false);
                        tv.setPadding(SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 8), SpriteListScreen.dp(a, 16), SpriteListScreen.dp(a, 8));
                        ScrollView s = new ScrollView(a);
                        s.addView(tv);
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("PNGs otimizados").setView(s).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }
}
