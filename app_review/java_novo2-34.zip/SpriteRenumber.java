package com.zue.attackeditor;

import java.util.TreeSet;

/**
 * Exclusao de sprites com renumeracao: monta o mapa antigo -> novo e reescreve as imagens usadas no DAC. Java puro.
 */
final class SpriteRenumber {
    private SpriteRenumber() { }

    /** {@code map[antigo] = novo}; -1 para as removidas. */
    static int[] map(int count, boolean[] removed) {
        int[] m = new int[count];
        int next = 0;
        for (int i = 0; i < count; i++) m[i] = i < removed.length && removed[i] ? -1 : next++;
        return m;
    }

    /** Permutacao que troca so os slots {@code a} e {@code b} (tamanho {@code max(a, b) + 1}; o resto fica no lugar). */
    static int[] swapMap(int a, int b) {
        int[] m = new int[Math.max(a, b) + 1];
        for (int i = 0; i < m.length; i++) m[i] = i;
        if (a >= 0 && b >= 0) { m[a] = b; m[b] = a; }
        return m;
    }

    /**
     * Reescreve o {@code image} de todos os frames do DAC pelo mapa (imagem removida vira -1; -1 continua -1; indices alem do mapa ficam como estao).
     * Devolve as ANOs que mudaram (para gravar no 000.dac.txt).
     */
    static TreeSet<Integer> remapDac(Dac dac, int[] map) {
        TreeSet<Integer> changed = new TreeSet<Integer>();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            boolean any = false;
            for (int m = 0; m < a.mpts.length; m++) {
                int img = a.mpts[m].image;
                if (img < 0 || img >= map.length) continue;
                int nv = map[img];
                if (nv != img) { a.mpts[m].image = nv; any = true; }
            }
            if (any) changed.add(Integer.valueOf(i));
        }
        return changed;
    }
}
