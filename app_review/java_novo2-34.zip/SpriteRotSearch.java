package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * "Remover Sprites repetidas": acha copias GIRADAS EM QUALQUER ANGULO (com escala e achatamento) de outra sprite. Java puro.
 *
 * Modelo (o que o DAC desenha): R = Rot(theta) . diag(sx, sy) . [espelho] . K  (zoom X/Y no eixo da imagem, depois a rotacao).
 * Para cada sprite R (a menor do par) e cada angulo testado, a miniatura de R e DESGIRADA por -theta, recortada justo e comparada com K pelo mesmo
 * criterio de {@link SpriteDedup} (o recorte justo normaliza escala e achatamento). Passos de 15 graus, depois refino ate o grau inteiro (o rot do DAC e inteiro).
 * So pares que passam de um filtro barato (histograma de cores parecido) sao girados, e so as sprites que nao casam sem girar. E aproximado: a rotacao
 * de pixels borra as bordas, por isso o resultado vem marcado como {@code approx}.
 */
final class SpriteRotSearch {
    private SpriteRotSearch() { }

    /** Notas abaixo disto nao entram no mapa (ruido). */
    static final int FLOOR = 70;
    /** Candidatas por sprite (as de histograma mais parecido) e distancia maxima de histograma (variacao total, 0..1). */
    static final int TOPK = 5;
    static final double MAX_TV = 0.35;
    static final double COARSE_STEP = 15;
    /** Sprites cujo recorte justo tem lado menor que isto (px logicos) nao giram: nao ha o que comparar. */
    static final double MIN_SIDE = 8;
    /** Alpha minimo (0..255) para o recorte justo da imagem desgirada (a rotacao borra a borda). */
    static final int D_ALPHA = SpriteDedup.TIGHT_ALPHA;

    interface Progress { /** @return false para cancelar */ boolean on(int done, int total); }

    /** Imagem de R desgirada por {@code theta} e recortada justo. */
    static final class Derot {
        int[][] cells = new int[3][], edges = new int[3][];
        int nonEmpty;
        double dx0, dy0, dx1, dy1;       // recorte justo em px logicos, relativo ao centro do recorte justo de R
        int minPx;                       // menor lado do recorte justo, em pixels da grade
        boolean empty;
        double w() { return dx1 - dx0; }
        double h() { return dy1 - dy0; }
    }

    /** Amostra bilinear (alpha pre-multiplicado) de {@code px} (tw x th) em (x, y) com o centro do pixel em .5; fora = transparente. */
    private static int sample(int[] px, int tw, int th, double x, double y) {
        double fx = x - 0.5, fy = y - 0.5;
        int x0 = (int) Math.floor(fx), y0 = (int) Math.floor(fy);
        double tx = fx - x0, ty = fy - y0;
        double a = 0, r = 0, g = 0, b = 0;
        for (int j = 0; j < 2; j++) {
            for (int i = 0; i < 2; i++) {
                int sx = x0 + i, sy = y0 + j;
                if (sx < 0 || sy < 0 || sx >= tw || sy >= th) continue;
                double wt = (i == 0 ? 1 - tx : tx) * (j == 0 ? 1 - ty : ty);
                int c = px[sy * tw + sx];
                double ca = (c >>> 24) * wt;
                a += ca; r += ca * ((c >> 16) & 255); g += ca * ((c >> 8) & 255); b += ca * (c & 255);
            }
        }
        if (a <= 0) return 0;
        int ia = (int) Math.min(255, Math.round(a));
        return (ia << 24) | ((int) Math.min(255, Math.round(r / a)) << 16) | ((int) Math.min(255, Math.round(g / a)) << 8) | (int) Math.min(255, Math.round(b / a));
    }

    /** Desgira a miniatura de R por {@code thetaDeg} (anti-horario e horario seguem o mesmo sentido do DAC: p_R = c + Rot(theta) (p_D - c)). */
    static Derot derotate(SpriteDedup.Sig r, double thetaDeg) {
        Derot d = new Derot();
        double s = (r.tux + r.tuy) / 2;                                   // px logicos por pixel da grade de saida
        double rw = r.tightW(), rh = r.tightH();
        double rho = Math.hypot(rw / 2, rh / 2);
        int g = (int) Math.ceil(2 * rho / s) + 2;
        double ct = Math.cos(Math.toRadians(thetaDeg)), st = Math.sin(Math.toRadians(thetaDeg));
        int[] out = new int[g * g];
        int[] colMax = new int[g], rowMax = new int[g];
        int minx = g, miny = g, maxx = -1, maxy = -1;
        for (int j = 0; j < g; j++) {
            for (int i = 0; i < g; i++) {
                double qx = (i + 0.5 - g / 2.0) * s, qy = (j + 0.5 - g / 2.0) * s;
                double px = qx * ct - qy * st, py = qx * st + qy * ct;            // Rot(theta) q: de onde da imagem de R vem
                int c = sample(r.thumb, r.tw, r.th, r.tw / 2.0 + px / r.tux, r.th / 2.0 + py / r.tuy);
                out[j * g + i] = c;
                int ca = c >>> 24;
                if (ca >= D_ALPHA) {
                    if (i < minx) minx = i; if (i > maxx) maxx = i; if (j < miny) miny = j; if (j > maxy) maxy = j;
                    if (ca > colMax[i]) colMax[i] = ca;
                    if (ca > rowMax[j]) rowMax[j] = ca;
                }
            }
        }
        if (maxx < 0) { d.empty = true; return d; }
        double fx0 = minx + (1 - colMax[minx] / 255.0), fx1 = maxx + colMax[maxx] / 255.0;      // bordas com fracao de pixel (como em SpriteDedup.sig)
        double fy0 = miny + (1 - rowMax[miny] / 255.0), fy1 = maxy + rowMax[maxy] / 255.0;
        if (fx1 - fx0 < 0.5) { fx0 = minx; fx1 = maxx + 1; }
        if (fy1 - fy0 < 0.5) { fy0 = miny; fy1 = maxy + 1; }
        d.dx0 = (fx0 - g / 2.0) * s; d.dx1 = (fx1 - g / 2.0) * s;
        d.dy0 = (fy0 - g / 2.0) * s; d.dy1 = (fy1 - g / 2.0) * s;
        d.minPx = (int) Math.ceil(Math.min(fx1 - fx0, fy1 - fy0));
        int[] c32 = SpriteDedup.box(out, g, g, fx0, fy0, fx1, fy1, SpriteDedup.N, SpriteDedup.N);
        for (int c : c32) if ((c >>> 24) != 0) d.nonEmpty++;
        SpriteDedup.pyramid(d.cells, d.edges, c32);
        return d;
    }

    private static int lvl(Derot d, SpriteDedup.Sig k) {
        int eff = Math.min(d.minPx, Math.min(k.tpw, k.tph));
        return eff >= 20 ? 0 : eff >= 10 ? 1 : 2;
    }

    /** Nota (0..99) da imagem desgirada contra K (sem espelho, ou espelhada na horizontal); -1 se a escala/achatamento passa dos limites. */
    static int score(Derot d, SpriteDedup.Sig k, boolean mirror, int minPct) {
        if (d.empty) return -1;
        double sx = k.tightW() / d.w(), sy = k.tightH() / d.h();
        if (sx < SpriteDedup.MIN_SCALE || sy < SpriteDedup.MIN_SCALE || sx > SpriteDedup.MAX_SCALE || sy > SpriteDedup.MAX_SCALE) return -1;
        if (Math.max(sx / sy, sy / sx) > SpriteDedup.MAX_STRETCH) return -1;
        int lv = lvl(d, k);
        int budget = (int) Math.ceil((100 - minPct) / 100.0 * (d.nonEmpty + k.nonEmpty));
        int sc = SpriteDedup.cellScore(d.cells[lv], d.edges[lv], k.cells[lv], k.edges[lv], lv, mirror ? 1 : 0, minPct, budget);
        return sc < 0 ? -1 : Math.min(99, sc);
    }

    private static double norm(double deg) {
        double a = deg % 360;
        if (a > 180) a -= 360;
        if (a <= -180) a += 360;
        return a;
    }

    /** Casamento de R com K por angulo qualquer (R girada de theta em relacao a K); null se nenhum passa de {@code floor}. */
    static SpriteDedup.Match find(SpriteDedup.Sig r, SpriteDedup.Sig k, int floor) {
        if (r.empty || k.empty || r.thumb == null) return null;
        double bestTheta = 0, bestScore = -1;
        boolean bestMirror = false;
        int steps = (int) Math.round(360 / COARSE_STEP);
        double[] coarse = new double[2 * steps];
        for (int m = 0; m < 2; m++) {
            for (int i = 0; i < steps; i++) {
                double th = norm(i * COARSE_STEP);
                int sc = score(derotate(r, th), k, m == 1, floor - 8);
                coarse[m * steps + i] = sc;
                if (sc > bestScore) { bestScore = sc; bestTheta = th; bestMirror = m == 1; }
            }
        }
        if (bestScore < floor - 8) return null;
        // refino: o melhor de cada espelho (o outro pode ganhar depois do refino)
        double outScore = -1, outTheta = 0;
        boolean outMirror = false;
        for (int m = 0; m < 2; m++) {
            int bi = 0;
            for (int i = 1; i < steps; i++) if (coarse[m * steps + i] > coarse[m * steps + bi]) bi = i;
            if (coarse[m * steps + bi] < floor - 8) continue;
            double th = norm(bi * COARSE_STEP);
            double sc = coarse[m * steps + bi];
            for (double step = COARSE_STEP / 2; step >= 1.5; step /= 2) {
                for (int dir = -1; dir <= 1; dir += 2) {
                    double t2 = norm(th + dir * step);
                    int s2 = score(derotate(r, t2), k, m == 1, 0);
                    if (s2 > sc) { sc = s2; th = t2; }
                }
            }
            double ti = Math.rint(th);                                   // o DAC guarda graus inteiros: avalia o inteiro e os vizinhos
            for (int dd = -1; dd <= 1; dd++) {
                double t2 = norm(ti + dd);
                int s2 = score(derotate(r, t2), k, m == 1, 0);
                if (s2 > sc || (s2 == sc && dd == 0)) { sc = s2; th = t2; }
            }
            if (sc > outScore) { outScore = sc; outTheta = th; outMirror = m == 1; }
        }
        if (outScore < floor) return null;
        Derot d = derotate(r, outTheta);
        SpriteDedup.Match mt = new SpriteDedup.Match((int) outScore, -1);
        mt.approx = true; mt.rotDeg = outTheta; mt.mirror = outMirror;
        mt.gen = general(r, k, d, outTheta, outMirror);
        double sx = k.tightW() / d.w(), sy = k.tightH() / d.h();
        mt.sx = sx; mt.sy = sy;
        mt.up = 100 * Math.max(1 / sx, 1 / sy);
        return mt;
    }

    /** Mapa afim do retangulo logico de R para o de K: R(u, v) = K(map(u, v)). */
    static double[] general(SpriteDedup.Sig r, SpriteDedup.Sig k, Derot d, double thetaDeg, boolean mirror) {
        double ct = Math.cos(Math.toRadians(thetaDeg)), st = Math.sin(Math.toRadians(thetaDeg));
        double cx = (r.tx0 + r.tx1) / 2 * r.w, cy = (r.ty0 + r.ty1) / 2 * r.h;       // centro do recorte justo de R, em px logicos do retangulo
        double[][] pt = {{0, 0}, {1, 0}, {0, 1}};
        double[][] out = new double[3][2];
        for (int i = 0; i < 3; i++) {
            double rx = pt[i][0] * r.w - cx, ry = pt[i][1] * r.h - cy;
            double qx = rx * ct + ry * st, qy = -rx * st + ry * ct;                    // Rot(-theta)
            double a = (qx - d.dx0) / d.w(), b = (qy - d.dy0) / d.h();
            if (mirror) a = 1 - a;
            out[i][0] = k.tx0 + a * (k.tx1 - k.tx0); out[i][1] = k.ty0 + b * (k.ty1 - k.ty0);
        }
        return new double[]{out[1][0] - out[0][0], out[2][0] - out[0][0], out[1][1] - out[0][1], out[2][1] - out[0][1], out[0][0], out[0][1]};
    }

    /**
     * Procura angulos para as sprites de {@code sigs}. {@code deadlineMs}: tempo maximo (ms); passou, devolve o que achou ate ali ({@code complete} = false).
     * {@code floor}: nota minima guardada.
     */
    static SpriteDedup.Matcher run(List<SpriteDedup.Sig> sigs, int floor, long deadlineMs, Progress prog) {
        SpriteDedup.Matcher mx = new SpriteDedup.Matcher();
        long t0 = System.currentTimeMillis();
        List<SpriteDedup.Sig> all = new ArrayList<SpriteDedup.Sig>();
        for (SpriteDedup.Sig s : sigs) if (!s.empty && s.thumb != null) all.add(s);
        int n = all.size();
        for (int ri = 0; ri < n; ri++) {
            if (prog != null && !prog.on(ri, n)) { mx.complete = false; return mx; }
            if (System.currentTimeMillis() - t0 > deadlineMs) { mx.complete = false; return mx; }
            SpriteDedup.Sig r = all.get(ri);
            if (Math.min(r.tightW(), r.tightH()) < MIN_SIDE) continue;
            // candidatas: maiores (ou iguais com indice menor) de histograma parecido
            List<SpriteDedup.Sig> cand = new ArrayList<SpriteDedup.Sig>();
            List<Double> dist = new ArrayList<Double>();
            for (SpriteDedup.Sig k : all) {
                if (k == r || k.area() < r.area() || (k.area() == r.area() && k.index > r.index)) continue;
                if (Math.min(k.tightW(), k.tightH()) < MIN_SIDE) continue;
                double t = SpriteDedup.histTv(r.hist, k.hist);
                if (t > MAX_TV) continue;
                int at = 0;
                while (at < dist.size() && dist.get(at) <= t) at++;
                if (at >= TOPK) continue;
                cand.add(at, k); dist.add(at, Double.valueOf(t));
                if (cand.size() > TOPK) { cand.remove(TOPK); dist.remove(TOPK); }
            }
            for (SpriteDedup.Sig k : cand) {
                if (SpriteDedup.best(r, k, SpriteDedup.RELATED) != null) continue;      // ja se relacionam sem girar
                SpriteDedup.Match m = find(r, k, floor);
                if (m != null) mx.rot.put(Long.valueOf(SpriteDedup.Matcher.key(r.index, k.index)), m);
            }
        }
        return mx;
    }
}
