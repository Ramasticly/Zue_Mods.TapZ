package com.zue.attackeditor;

import android.app.Activity;
import android.graphics.Bitmap;
import java.util.HashMap;
import java.util.Map;

/** Assinaturas (SpriteDedup.Sig) de todas as sprites do personagem, lidas em segundo plano com a tela de "Analisando sprites"; servem para a nota de semelhanca e o alinhamento. */
final class SpriteSims {
    private SpriteSims() { }

    interface Done { void on(Map<Integer, SpriteDedup.Sig> sigs); }

    static void build(final Activity a, final SpriteLib lib, final Done done) {
        final BusyDialog busy = BusyDialog.show(a, "Analisando sprites");
        new Thread(new Runnable() {
            @Override public void run() {
                final Map<Integer, SpriteDedup.Sig> sigs = new HashMap<Integer, SpriteDedup.Sig>();
                int n = lib.count();
                try {
                    for (int i = 0; i < n; i++) {
                        busy.set("Lendo sprites", i, n);
                        int[] ls = lib.logicalSize(i);
                        if (ls == null) continue;
                        Bitmap b = lib.cut(i);
                        if (b == null) continue;
                        int[] px = new int[b.getWidth() * b.getHeight()];
                        b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                        sigs.put(Integer.valueOf(i), SpriteDedup.sig(i, px, b.getWidth(), b.getHeight(), ls[0], ls[1]));
                        b.recycle();
                    }
                } catch (Throwable t) { /* segue com o que leu */ }
                busy.dismiss();
                a.runOnUiThread(new Runnable() { @Override public void run() { done.on(sigs); } });
            }
        }).start();
    }
}
