package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Ordens da lista de sprites (tamanho em bytes e em px, mais/menos usos, mais parecidas) e o texto do criterio por linha. Java puro. */
final class SpriteSort {
    private SpriteSort() { }

    static final int NUMBER = 0, BYTES_DESC = 1, BYTES_ASC = 2, PX_DESC = 3, PX_ASC = 4, USES_DESC = 5, USES_ASC = 6, SIMILAR = 7;
    static final String[] NAMES = {"Número (padrão)", "Tamanho em bytes ↓ (maiores)", "Tamanho em bytes ↑ (menores)", "Tamanho em Px ↓ (maiores)", "Tamanho em Px ↑ (menores)",
            "Mais usos", "Menos usos", "Mais parecidas"};

    /** Memoria do recorte em RGBA (L × A × 4), sem ler arquivo. */
    static long bytes(int w, int h) { return (long) Math.max(0, w) * Math.max(0, h) * 4L; }

    /** Quantos Frames do DAC usam cada imagem (0..count-1). */
    static int[] useCounts(Dac dac, int count) {
        int[] u = new int[Math.max(0, count)];
        if (dac == null) return u;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present || a.mpts == null) continue;
            for (Ano.Mpt m : a.mpts) if (m.image >= 0 && m.image < u.length) u[m.image]++;
        }
        return u;
    }

    /**
     * Indices na ordem pedida. {@code w}/{@code h}: tamanho logico (0 = sem desenho; vai para o fim em toda ordem, menos NUMBER). {@code best}/{@code partner}: melhor nota
     * (0..100, -1 = sem par) e a sprite com que casou (so para SIMILAR). Estavel: empate cai no numero.
     */
    static List<Integer> order(final int mode, int count, final int[] w, final int[] h, final int[] uses, final int[] best, final int[] partner) {
        List<Integer> out = new ArrayList<Integer>();
        for (int i = 0; i < count; i++) out.add(Integer.valueOf(i));
        if (mode == NUMBER) return out;
        Collections.sort(out, new Comparator<Integer>() {
            @Override public int compare(Integer x, Integer y) {
                int i = x.intValue(), j = y.intValue();
                boolean ei = drawn(w, h, i) == 0, ej = drawn(w, h, j) == 0;
                if (ei != ej) return ei ? 1 : -1;                          // vazias por ultimo
                long a = 0, b = 0;
                switch (mode) {
                    case BYTES_DESC: a = bytes(w[j], h[j]); b = bytes(w[i], h[i]); break;
                    case BYTES_ASC: a = bytes(w[i], h[i]); b = bytes(w[j], h[j]); break;
                    case PX_DESC: a = drawn(w, h, j); b = drawn(w, h, i); break;
                    case PX_ASC: a = drawn(w, h, i); b = drawn(w, h, j); break;
                    case USES_DESC: a = at(uses, j); b = at(uses, i); break;
                    case USES_ASC: a = at(uses, i); b = at(uses, j); break;
                    case SIMILAR: {
                        int si = at(best, i, -1), sj = at(best, j, -1);
                        if (si != sj) return sj - si;                       // nota maior primeiro; sem par (-1) por ultimo
                        int ki = si < 0 ? i : Math.min(i, at(partner, i, i)), kj = sj < 0 ? j : Math.min(j, at(partner, j, j));
                        if (ki != kj) return ki - kj;                       // as parecidas entre si ficam juntas
                        return i - j;
                    }
                    default: break;
                }
                if (a != b) return a < b ? -1 : 1;
                return i - j;
            }
        });
        return out;
    }

    private static long drawn(int[] w, int[] h, int i) { return i < w.length && i < h.length ? (long) Math.max(0, w[i]) * Math.max(0, h[i]) : 0; }
    private static int at(int[] a, int i) { return at(a, i, 0); }
    private static int at(int[] a, int i, int def) { return a != null && i >= 0 && i < a.length ? a[i] : def; }

    /** Texto do criterio para a linha ("1.280 B", "32×40 px", "5 usos", "100%"), ou "" se o modo nao mostra. */
    static String info(int mode, int i, int[] w, int[] h, int[] uses, int[] best) {
        switch (mode) {
            case BYTES_DESC: case BYTES_ASC: return grouped(bytes(at(w, i), at(h, i))) + " B";
            case PX_DESC: case PX_ASC: return at(w, i) + "×" + at(h, i) + " px";
            case USES_DESC: case USES_ASC: { int n = at(uses, i); return n + (n == 1 ? " uso" : " usos"); }
            case SIMILAR: { int s = at(best, i, -1); return s < 0 ? "sem par" : s + "%"; }
            default: return "";
        }
    }

    /** 1280 -> "1.280". */
    static String grouped(long v) {
        String s = Long.toString(v);
        StringBuilder b = new StringBuilder();
        for (int k = 0; k < s.length(); k++) { if (k > 0 && (s.length() - k) % 3 == 0) b.append('.'); b.append(s.charAt(k)); }
        return b.toString();
    }
}
