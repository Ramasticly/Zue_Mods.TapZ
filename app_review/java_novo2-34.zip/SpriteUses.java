package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/** "Mostrar usos" da sprite: em que ANO e Frame ela aparece. Java puro. */
final class SpriteUses {
    private SpriteUses() { }

    /** Uma linha por ANO: {@code {ano, frame, frame, ...}} (frames de 1 em diante), em ordem. */
    static List<int[]> find(Dac dac, int image) {
        List<int[]> out = new ArrayList<int[]>();
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present) continue;
            List<Integer> fr = new ArrayList<Integer>();
            for (int f = 0; f < a.mpts.length; f++) if (a.mpts[f].image == image) fr.add(Integer.valueOf(f + 1));
            if (fr.isEmpty()) continue;
            int[] row = new int[fr.size() + 1];
            row[0] = i;
            for (int k = 0; k < fr.size(); k++) row[k + 1] = fr.get(k).intValue();
            out.add(row);
        }
        return out;
    }

    /** "Ano 3, Frame 1" / "Ano 3, Frames 1 e 4" / "Ano 3, Frames 1, 4, 7 e 9". */
    static String line(int[] row) {
        int n = row.length - 1;
        StringBuilder b = new StringBuilder("Ano ").append(row[0]).append(n == 1 ? ", Frame " : ", Frames ");
        for (int k = 1; k <= n; k++) {
            if (k > 1) b.append(k == n ? " e " : ", ");
            b.append(row[k]);
        }
        return b.toString();
    }

    static String text(Dac dac, int image) {
        List<int[]> rows = find(dac, image);
        if (rows.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (int[] r : rows) b.append(line(r)).append('\n');
        return b.toString().trim();
    }
}
