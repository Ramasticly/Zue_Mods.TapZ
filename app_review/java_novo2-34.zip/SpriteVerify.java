package com.zue.attackeditor;

/**
 * Conferencia em PIXELS de um par de sprites ja relacionado por {@link SpriteDedup} (8 relacoes ou angulo qualquer): desenha K no espaco de R com o mapa
 * afim, refina escala X/Y, posicao e rotacao (busca local, passos que diminuem) e mede forma (IoU das mascaras), cor (erro medio dos pixels opacos nos dois)
 * e detalhes (correlacao das bordas internas). As metricas valem para o que o DAC desenha de verdade: o mapa e quantizado (zoom e rotacao inteiros)
 * antes de medir. Java puro.
 */
final class SpriteVerify {
    private SpriteVerify() { }

    /** Maior lado da imagem de trabalho (pixels fisicos do recorte justo). */
    static final int WORK = 96;
    /** Sprites com menos pixels que isto de lado nao tem o que refinar. */
    static final int MIN_REFINE = 6;

    // ---- amostragem / desenho ----

    /** Bilinear com alpha pre-multiplicado; (x, y) em pixels com o centro do pixel em .5; fora da imagem = transparente. */
    static int sample(int[] px, int w, int h, double x, double y) {
        double fx = x - 0.5, fy = y - 0.5;
        int x0 = (int) Math.floor(fx), y0 = (int) Math.floor(fy);
        double tx = fx - x0, ty = fy - y0;
        double a = 0, r = 0, g = 0, b = 0;
        for (int j = 0; j < 2; j++) {
            int sy = y0 + j;
            if (sy < 0 || sy >= h) continue;
            for (int i = 0; i < 2; i++) {
                int sx = x0 + i;
                if (sx < 0 || sx >= w) continue;
                double wt = (i == 0 ? 1 - tx : tx) * (j == 0 ? 1 - ty : ty);
                int c = px[sy * w + sx];
                double ca = (c >>> 24) * wt;
                a += ca; r += ca * ((c >> 16) & 255); g += ca * ((c >> 8) & 255); b += ca * (c & 255);
            }
        }
        if (a <= 0) return 0;
        return ((int) Math.min(255, Math.round(a)) << 24) | ((int) Math.min(255, Math.round(r / a)) << 16) | ((int) Math.min(255, Math.round(g / a)) << 8) | (int) Math.min(255, Math.round(b / a));
    }

    /** Media de n x n amostras dentro do pixel (evita serrilhado quando K aparece menor). */
    private static int sampleSuper(int[] px, int w, int h, double x, double y, double dxi, double dyi, double dxj, double dyj, int n) {
        if (n <= 1) return sample(px, w, h, x, y);
        double a = 0, r = 0, g = 0, b = 0;
        int cnt = 0;
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                double fi = (i + 0.5) / n - 0.5, fj = (j + 0.5) / n - 0.5;
                int c = sample(px, w, h, x + fi * dxi + fj * dxj, y + fi * dyi + fj * dyj);
                int ca = c >>> 24;
                a += ca; r += (double) ca * ((c >> 16) & 255); g += (double) ca * ((c >> 8) & 255); b += (double) ca * (c & 255);
                cnt++;
            }
        }
        if (a <= 0) return 0;
        return ((int) Math.min(255, Math.round(a / cnt)) << 24) | ((int) Math.min(255, Math.round(r / a)) << 16) | ((int) Math.min(255, Math.round(g / a)) << 8) | (int) Math.min(255, Math.round(b / a));
    }

    /**
     * Desenha K (pixels {@code kpx}, {@code kpw x kph} cobrindo o retangulo logico inteiro de K) numa grade {@code outW x outH} que cobre o retangulo logico
     * inteiro de R: R(u, v) = K(gen(u, v)). Usada pela tela Comparar.
     */
    static int[] renderRect(int[] kpx, int kpw, int kph, double[] gen, int outW, int outH) {
        int[] out = new int[outW * outH];
        // pixels de K por pixel de saida (para saber se precisa de supersample)
        double dxi = (gen[0] / outW) * kpw, dyi = (gen[2] / outW) * kph, dxj = (gen[1] / outH) * kpw, dyj = (gen[3] / outH) * kph;
        int n = (int) Math.max(1, Math.min(3, Math.ceil(Math.max(Math.abs(dxi) + Math.abs(dxj), Math.abs(dyi) + Math.abs(dyj)))));
        for (int j = 0; j < outH; j++) {
            for (int i = 0; i < outW; i++) {
                double u = (i + 0.5) / outW, v = (j + 0.5) / outH;
                double ku = gen[0] * u + gen[1] * v + gen[4], kv = gen[2] * u + gen[3] * v + gen[5];
                out[j * outW + i] = sampleSuper(kpx, kpw, kph, ku * kpw, kv * kph, dxi, dyi, dxj, dyj, n);
            }
        }
        return out;
    }

    /** K (imagem de trabalho) desenhada na grade de trabalho de R, com o mapa {@code gen} (retangulo logico de R -> retangulo logico de K). */
    static int[] renderWork(SpriteDedup.Sig r, SpriteDedup.Sig k, double[] gen) { return renderWork(r, k, gen, 1); }

    /** Como acima, mas so a cada {@code stride}-esimo pixel da grade de R (busca de refino mais rapida): a saida tem {@link #strideW} x {@link #strideH}. */
    static int[] renderWork(SpriteDedup.Sig r, SpriteDedup.Sig k, double[] gen, int stride) {
        int ow = strideW(r.ww, stride), oh = strideW(r.wh, stride);
        int[] out = new int[ow * oh];
        double rx0 = r.tx0 * r.w, ry0 = r.ty0 * r.h;
        double kx0 = k.tx0 * k.w, ky0 = k.ty0 * k.h;
        // derivadas em pixels de K de trabalho por pixel de R de trabalho
        double sxk = k.w / k.wux, syk = k.h / k.wuy;
        double dxi = gen[0] * r.wux / r.w * sxk, dyi = gen[2] * r.wux / r.w * syk, dxj = gen[1] * r.wuy / r.h * sxk, dyj = gen[3] * r.wuy / r.h * syk;
        int n = (int) Math.max(1, Math.min(3, Math.ceil(Math.max(Math.abs(dxi) + Math.abs(dxj), Math.abs(dyi) + Math.abs(dyj)))));
        for (int jj = 0; jj < oh; jj++) {
            int j = jj * stride;
            for (int ii = 0; ii < ow; ii++) {
                int i = ii * stride;
                double u = (rx0 + (i + 0.5) * r.wux) / r.w, v = (ry0 + (j + 0.5) * r.wuy) / r.h;
                double ku = gen[0] * u + gen[1] * v + gen[4], kv = gen[2] * u + gen[3] * v + gen[5];
                double wx = (ku * k.w - kx0) / k.wux, wy = (kv * k.h - ky0) / k.wuy;
                out[jj * ow + ii] = sampleSuper(k.work, k.ww, k.wh, wx, wy, dxi * stride, dyi * stride, dxj * stride, dyj * stride, n);
            }
        }
        return out;
    }

    static int strideW(int w, int stride) { return (w + stride - 1) / stride; }

    /** A imagem de trabalho de R tirada a cada {@code stride} pixels (mesma grade de {@link #renderWork(SpriteDedup.Sig, SpriteDedup.Sig, double[], int)}). */
    static int[] strided(SpriteDedup.Sig r, int stride) {
        int ow = strideW(r.ww, stride), oh = strideW(r.wh, stride);
        int[] out = new int[ow * oh];
        for (int jj = 0; jj < oh; jj++) for (int ii = 0; ii < ow; ii++) out[jj * ow + ii] = r.work[jj * stride * r.ww + ii * stride];
        return out;
    }

    // ---- metricas ----

    static final class Metrics {
        double iou, color, detail;       // 0..100
        double objective() { return iou / 100.0 + color / 100.0; }
    }

    private static int cdiff(int p, int q) {
        int d = Math.abs(((p >> 16) & 255) - ((q >> 16) & 255));
        d = Math.max(d, Math.abs(((p >> 8) & 255) - ((q >> 8) & 255)));
        return Math.max(d, Math.abs((p & 255) - (q & 255)));
    }

    private static double luma(int p) { return 0.299 * ((p >> 16) & 255) + 0.587 * ((p >> 8) & 255) + 0.114 * (p & 255); }

    /** Diferenca de cor (maior canal, 0..255) a partir da qual um pixel conta como "cor diferente". */
    static final int COLOR_TOL = 40;

    /**
     * Compara a imagem de R ({@code a}) com a de K desenhada na mesma grade ({@code b}), {@code w x h}.
     * Forma = Dice das mascaras (alpha >= 128) tolerando 1 pixel de erro de posicao; cor = % dos pixels opacos nos dois cuja cor bate (o vizinho mais parecido a ate
     * 1 pixel vale, diferenca <= {@link #COLOR_TOL}). Mede "quanto da imagem e igual", entao uma regiao diferente pequena nao some na media.
     */
    static Metrics measure(int[] a, int[] b, int w, int h, boolean withDetail) {
        Metrics m = new Metrics();
        int na = 0, nb = 0, ma = 0, mb = 0, inter = 0, equal = 0, interiorN = 0, interiorEq = 0;
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int p = a[j * w + i], q = b[j * w + i];
                boolean pa = (p >>> 24) >= 128, qa = (q >>> 24) >= 128;
                if (pa) { na++; if (qa || near(b, w, h, i, j)) ma++; }
                if (qa) { nb++; if (pa || near(a, w, h, i, j)) mb++; }
                if (!(pa && qa)) continue;
                inter++;
                int best = 255;                                   // tolera 1 pixel de erro de posicao: vale o vizinho que mais combina
                for (int dj = -1; dj <= 1 && best > COLOR_TOL; dj++) {
                    int yy = j + dj;
                    if (yy < 0 || yy >= h) continue;
                    for (int di = -1; di <= 1; di++) {
                        int xx = i + di;
                        if (xx < 0 || xx >= w) continue;
                        int c = b[yy * w + xx];
                        if ((c >>> 24) < 128) continue;
                        int d = cdiff(p, c);
                        if (d < best) best = d;
                    }
                }
                boolean eq = best <= COLOR_TOL;
                if (eq) equal++;
                if (interior(a, b, w, h, i, j)) { interiorN++; if (eq) interiorEq++; }
            }
        }
        m.iou = na + nb == 0 ? 0 : 100.0 * (ma + mb) / (na + nb);
        // cor: so o miolo (as bordas misturam cor ao reamostrar); sem miolo (sprite minuscula), tudo que se sobrepoe
        m.color = interiorN >= 8 ? 100.0 * interiorEq / interiorN : inter == 0 ? 0 : 100.0 * equal / inter;
        m.detail = withDetail ? detail(a, b, w, h) : 100;
        return m;
    }

    /** O pixel e as 8 vizinhas sao opacos nas duas imagens? */
    private static boolean interior(int[] a, int[] b, int w, int h, int i, int j) {
        if (i < 1 || j < 1 || i >= w - 1 || j >= h - 1) return false;
        for (int dj = -1; dj <= 1; dj++) for (int di = -1; di <= 1; di++) {
            int k = (j + dj) * w + i + di;
            if ((a[k] >>> 24) < 128 || (b[k] >>> 24) < 128) return false;
        }
        return true;
    }

    /** Ha um pixel opaco (alpha >= 128) a ate 1 pixel de (i, j)? */
    private static boolean near(int[] img, int w, int h, int i, int j) {
        for (int dj = -1; dj <= 1; dj++) {
            int yy = j + dj;
            if (yy < 0 || yy >= h) continue;
            for (int di = -1; di <= 1; di++) {
                int xx = i + di;
                if (xx >= 0 && xx < w && (img[yy * w + xx] >>> 24) >= 128) return true;
            }
        }
        return false;
    }

    /** Correlacao (0..100) do mapa de gradiente de luma, so dentro da area opaca nos dois (menos 1 pixel de borda), depois de suavizar 3 x 3. */
    static double detail(int[] a, int[] b, int w, int h) {
        double[] la = blurLuma(a, w, h), lb = blurLuma(b, w, h);
        double[] ga = grad(la, w, h), gb = grad(lb, w, h);
        double sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0;
        int n = 0;
        for (int j = 2; j < h - 2; j++) {
            for (int i = 2; i < w - 2; i++) {
                boolean in = true;
                for (int dj = -2; dj <= 2 && in; dj++) for (int di = -2; di <= 2; di++) {
                    if ((a[(j + dj) * w + i + di] >>> 24) < 128 || (b[(j + dj) * w + i + di] >>> 24) < 128) { in = false; break; }
                }
                if (!in) continue;
                double x = ga[j * w + i], y = gb[j * w + i];
                sa += x; sb += y; saa += x * x; sbb += y * y; sab += x * y; n++;
            }
        }
        if (n < 8) return 100;                                    // quase nada de area interna: sem detalhe para comparar
        double va = saa / n - (sa / n) * (sa / n), vb = sbb / n - (sb / n) * (sb / n);
        double ea = 4.0, eb = 4.0;                                // variancia abaixo disto = liso (diferenca de luma desprezivel)
        if (va < ea && vb < eb) return 100;
        if (va < ea || vb < eb) return 0;
        double cov = sab / n - (sa / n) * (sb / n);
        return Math.max(0, Math.min(100, 100 * cov / Math.sqrt(va * vb)));
    }

    private static double[] blurLuma(int[] px, int w, int h) {
        double[] l = new double[w * h], o = new double[w * h];
        for (int i = 0; i < l.length; i++) l[i] = (px[i] >>> 24) >= 128 ? luma(px[i]) : 0;
        for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
            double s = 0; int c = 0;
            for (int dj = -1; dj <= 1; dj++) for (int di = -1; di <= 1; di++) {
                int x = i + di, y = j + dj;
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                s += l[y * w + x]; c++;
            }
            o[j * w + i] = s / c;
        }
        return o;
    }

    private static double[] grad(double[] l, int w, int h) {
        double[] g = new double[w * h];
        for (int j = 1; j < h - 1; j++) for (int i = 1; i < w - 1; i++) {
            double gx = l[j * w + i + 1] - l[j * w + i - 1], gy = l[(j + 1) * w + i] - l[(j - 1) * w + i];
            g[j * w + i] = Math.abs(gx) + Math.abs(gy);
        }
        return g;
    }

    // ---- quantizacao (o que o DAC consegue guardar) ----

    /** Mapa equivalente ao que sai de {@link SpriteXform#solve} para um frame "padrao" de R (sem zoom/rotacao/flip): zoom e rotacao inteiros. null se nao ha solucao. */
    static double[] quantized(double[] gen, int wR, int hR, int wK, int hK) {
        SpriteXform.Frame id = new SpriteXform.Frame();
        SpriteXform.Frame f = SpriteXform.solve(id, wR, hR, wK, hK, gen, true);
        if (f == null) return null;
        double[] t = SpriteXform.place(f, wK, hK, 0, 0), p1 = SpriteXform.place(f, wK, hK, 1, 0), p2 = SpriteXform.place(f, wK, hK, 0, 1);
        double m11 = p1[0] - t[0], m21 = p1[1] - t[1], m12 = p2[0] - t[0], m22 = p2[1] - t[1];
        double det = m11 * m22 - m12 * m21;
        if (Math.abs(det) < 1e-12) return null;
        double[][] out = new double[3][2];
        double[][] pt = {{0, 0}, {1, 0}, {0, 1}};
        for (int i = 0; i < 3; i++) {
            double[] wp = SpriteXform.place(id, wR, hR, pt[i][0], pt[i][1]);
            double dx = wp[0] - t[0], dy = wp[1] - t[1];
            out[i][0] = (m22 * dx - m12 * dy) / det;
            out[i][1] = (-m21 * dx + m11 * dy) / det;
        }
        return new double[]{out[1][0] - out[0][0], out[2][0] - out[0][0], out[1][1] - out[0][1], out[2][1] - out[0][1], out[0][0], out[0][1]};
    }

    // ---- refino ----

    /** Perturba {@code gen}: K com escala (1+sx, 1+sy) e deslocada (tx, ty) (fracao do recorte justo de K), e R girada de {@code rotDeg} em torno do centro do recorte justo. */
    static double[] perturb(double[] gen, SpriteDedup.Sig r, SpriteDedup.Sig k, double sx, double sy, double tx, double ty, double rotDeg) {
        double ct = Math.cos(Math.toRadians(rotDeg)), st = Math.sin(Math.toRadians(rotDeg));
        double crx = (r.tx0 + r.tx1) / 2 * r.w, cry = (r.ty0 + r.ty1) / 2 * r.h;
        double ckx = (k.tx0 + k.tx1) / 2 * k.w, cky = (k.ty0 + k.ty1) / 2 * k.h;
        double[][] pt = {{0, 0}, {1, 0}, {0, 1}};
        double[][] out = new double[3][2];
        for (int i = 0; i < 3; i++) {
            double rx = pt[i][0] * r.w - crx, ry = pt[i][1] * r.h - cry;
            double qx = rx * ct + ry * st + crx, qy = -rx * st + ry * ct + cry;            // Rot(-delta)
            double u = qx / r.w, v = qy / r.h;
            double ku = (gen[0] * u + gen[1] * v + gen[4]) * k.w, kv = (gen[2] * u + gen[3] * v + gen[5]) * k.h;
            ku = ckx + (ku - ckx) / (1 + sx) + tx * k.tightW();
            kv = cky + (kv - cky) / (1 + sy) + ty * k.tightH();
            out[i][0] = ku / k.w; out[i][1] = kv / k.h;
        }
        return new double[]{out[1][0] - out[0][0], out[2][0] - out[0][0], out[1][1] - out[0][1], out[2][1] - out[0][1], out[0][0], out[0][1]};
    }

    private static double eval(SpriteDedup.Sig r, SpriteDedup.Sig k, double[] gen) {
        return measure(r.work, renderWork(r, k, gen), r.ww, r.wh, false).objective();
    }

    /** Objetivo na grade reduzida (a cada 2 pixels): usado so no refino. */
    private static double evalFast(SpriteDedup.Sig r, int[] a2, SpriteDedup.Sig k, double[] gen, int w2, int h2) {
        return measure(a2, renderWork(r, k, gen, 2), w2, h2, false).objective();
    }

    /** Objetivo minimo (iou + cor, 0..2) do mapa inicial para valer refinar: abaixo disso o par nao e a mesma imagem. */
    static final double REFINE_GATE = 1.4;
    /** Forma e cor minimas do mapa inicial para valer refinar (copias reais: forma >= 100 e cor >= 96 em 168 casos; sem relacao: cor quase sempre < 70). */
    static final double GATE_IOU = 88, GATE_COLOR = 70;
    /** Objetivo que o refino precisa ter alcancado depois dos passos grandes para continuar nos pequenos. */
    static final double REFINE_KEEP = 1.7;

    /**
     * Refina o mapa de {@code m} (busca local por coordenada, passos que diminuem) e mede as metricas do mapa quantizado (o que o DAC desenha).
     * Preenche iou/color/detail/palette/verified em {@code m}; {@code m.gen} passa a ser o mapa refinado. Pares sem solucao no DAC ficam com metricas 0.
     */
    static void verify(SpriteDedup.Sig r, SpriteDedup.Sig k, SpriteDedup.Match m) {
        m.palette = 100 * (1 - SpriteDedup.histTv(r.hist, k.hist));
        m.verified = true;
        if (r.empty || k.empty || r.work == null || k.work == null) { m.iou = m.color = m.detail = 0; return; }
        double[] gen = m.map();
        Metrics b0 = measure(r.work, renderWork(r, k, gen), r.ww, r.wh, false);
        double base = b0.objective();
        if (b0.iou < GATE_IOU || b0.color < GATE_COLOR) {                       // claramente nao e a mesma imagem: guarda o que mediu e nao gasta mais
            m.iou = b0.iou; m.color = b0.color; m.detail = 0;
            return;
        }
        // sem sobreposicao minima nem vale refinar
        if (Math.min(r.ww, r.wh) >= MIN_REFINE) {
            final int stride = Math.min(r.ww, r.wh) >= 24 ? 2 : 1;
            final int[] aF = stride == 2 ? strided(r, 2) : r.work;
            final int wF = strideW(r.ww, stride), hF = strideW(r.wh, stride);
            double[] steps = {0.06, 0.03, 0.015, 0.0075};
            double[] tsteps = {0.04, 0.02, 0.01, 0.005};
            double[] rsteps = {3, 2, 1, 0};
            double[] p = new double[5];           // sx, sy, tx, ty, rot
            double[] lim = {0.12, 0.12, 0.08, 0.08, 4};
            double best = stride == 2 ? evalFast(r, aF, k, gen, wF, hF) : base;
            for (int lv = 0; lv < 4; lv++) {
                for (int round = 0; round < 2; round++) {
                    boolean any = false;
                    for (int q = 0; q < 5; q++) {
                        double st = q < 2 ? steps[lv] : q < 4 ? tsteps[lv] : rsteps[lv];
                        if (st <= 0) continue;
                        for (int dir = -1; dir <= 1; dir += 2) {
                            double[] pp = p.clone();
                            pp[q] += dir * st;
                            if (Math.abs(pp[q]) > lim[q] + 1e-9) continue;
                            double[] g2 = perturb(gen, r, k, pp[0], pp[1], pp[2], pp[3], pp[4]);
                            double v = stride == 2 ? evalFast(r, aF, k, g2, wF, hF) : eval(r, k, g2);
                            if (v > best + 1e-9) { best = v; p = pp; any = true; }
                        }
                    }
                    if (!any) break;
                }
                if (lv == 1 && best < REFINE_KEEP) break;       // depois dos passos grandes ainda longe de uma copia: nao gasta o resto
            }
            gen = perturb(gen, r, k, p[0], p[1], p[2], p[3], p[4]);
        }
        m.gen = gen;
        double[] q = quantized(gen, r.w, r.h, k.w, k.h);
        if (q == null) { m.iou = m.color = m.detail = 0; return; }
        Metrics x = measure(r.work, renderWork(r, k, q), r.ww, r.wh, true);
        m.iou = x.iou; m.color = x.color; m.detail = x.detail;
    }
}
