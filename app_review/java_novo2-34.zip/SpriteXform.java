package com.zue.attackeditor;

/**
 * Troca a sprite R de um frame por outra sprite K que e a mesma imagem espelhada / girada em 90 graus / em outra escala, reescrevendo
 * Flip X/Y, rotacao, zoom e posicao do frame para o desenho ficar igual. Java puro.
 *
 * Geometria (de AttackRenderer.drawObj, objeto sem zoom proprio): sprite de largura/altura logicas w x h, zoom zx/zy (%), centro proprio (ox, oy)
 * e rotacao rot. Com sx = -1 se Flip X e sy = -1 se Flip Y: o ponto (u, v) do desenho (0..1) cai em
 * Rot(sx * rot) . ( sx * (ox + u * W), sy * (oy + v * H) ), com W = w * zx / 100 e H = h * zy / 100. (O Flip Y nao inverte a rotacao no jogo.)
 *
 * g (0..7) diz como o conteudo de R aparece em K: R(u, v) = K(g(u, v)):
 * 0 igual, 1 espelho horizontal, 2 espelho vertical, 3 giro de 180, 4 transposta, 5..7 as outras tres com troca de eixos (giros de 90 graus e transposta invertida).
 */
final class SpriteXform {
    private SpriteXform() { }

    /** Matriz linear {{a, b}, {c, d}} e deslocamento {e, f} de g: (u, v) -> (a u + b v + e, c u + d v + f). */
    static final double[][] G = {
        {1, 0, 0, 1, 0, 0}, {-1, 0, 0, 1, 1, 0}, {1, 0, 0, -1, 0, 1}, {-1, 0, 0, -1, 1, 1},
        {0, 1, 1, 0, 0, 0}, {0, -1, 1, 0, 1, 0}, {0, 1, -1, 0, 0, 1}, {0, -1, -1, 0, 1, 1}};

    /** As dimensoes de K trocam de eixo em relacao a R? */
    static boolean swapsAxes(int g) { return g >= 4; }

    static final class Frame {
        boolean flipH, flipV;
        int ox, oy, rot, zx = 100, zy = 100;
    }

    static Frame read(Ano.Mpt m) {
        Frame f = new Frame();
        if ((m.flags & 2) != 0) { f.flipH = (m.wActFlag & 16) != 0; f.flipV = (m.wActFlag & 32) != 0; }
        if (m.hasMid) { f.ox = m.midX; f.oy = m.midY; }
        if (m.hasRaz) { f.rot = m.rot; f.zx = m.xZoom; f.zy = m.yZoom; }
        return f;
    }

    /** Onde o ponto (u, v) da sprite cai (coordenadas do jogo, origem na ancora do objeto). */
    static double[] place(Frame f, int w, int h, double u, double v) {
        double W = w * f.zx / 100.0, H = h * f.zy / 100.0;
        double sx = f.flipH ? -1 : 1, sy = f.flipV ? -1 : 1;
        double x = sx * (f.ox + u * W), y = sy * (f.oy + v * H);
        double a = Math.toRadians(sx * f.rot);
        return new double[]{x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)};
    }

    /**
     * Novos valores do frame para desenhar K (wK x hK) no lugar de R (wR x hR) com a relacao {@code g}; null se nao existe (eixos nao ortogonais).
     * {@code allowFlip} = false recusa solucoes que mudam Flip X/Y (frames de ANO usada como link filho: o deslocamento do link tambem espelha).
     */
    static Frame solve(Frame r, int wR, int hR, int wK, int hK, int g, boolean allowFlip) {
        double[] gg = G[g];
        double sxR = r.flipH ? -1 : 1, syR = r.flipV ? -1 : 1;
        double W = wR * r.zx / 100.0, H = hR * r.zy / 100.0;
        double rhoR = Math.toRadians(sxR * r.rot);
        double cr = Math.cos(rhoR), sr = Math.sin(rhoR);
        // L_R = Rot(rhoR) . diag(sxR W, syR H)
        double l11 = cr * sxR * W, l21 = sr * sxR * W, l12 = -sr * syR * H, l22 = cr * syR * H;
        double tx0 = cr * sxR * r.ox - sr * syR * r.oy, ty0 = sr * sxR * r.ox + cr * syR * r.oy;
        // L_K = L_R . G^-1 (G ortogonal: inversa = transposta)
        double ga = gg[0], gb = gg[1], gc = gg[2], gd = gg[3];
        double k11 = l11 * ga + l12 * gb, k12 = l11 * gc + l12 * gd, k21 = l21 * ga + l22 * gb, k22 = l21 * gc + l22 * gd;
        double c1x = k11, c1y = k21, c2x = k12, c2y = k22;
        double n1 = Math.hypot(c1x, c1y), n2 = Math.hypot(c2x, c2y);
        if (n1 < 1e-9 || n2 < 1e-9) return null;
        if (Math.abs(c1x * c2x + c1y * c2y) > 1e-6 * n1 * n2) return null;            // eixos nao ortogonais: nao e um desenho possivel
        double det = c1x * c2y - c1y * c2x;
        // t_K = t_R - L_K . g0
        double tkx = tx0 - (k11 * gg[4] + k12 * gg[5]), tky = ty0 - (k21 * gg[4] + k22 * gg[5]);
        Frame best = null;
        double bestCost = Double.MAX_VALUE;
        for (int sxi = 0; sxi < 2; sxi++) {
            for (int syi = 0; syi < 2; syi++) {
                double sx = sxi == 0 ? 1 : -1, sy = syi == 0 ? 1 : -1;
                if (sx * sy * det < 0) continue;
                boolean flipsChange = (sx != sxR) || (sy != syR);
                if (flipsChange && !allowFlip) continue;
                double rho = Math.atan2(c1y, c1x) - (sx < 0 ? Math.PI : 0);
                double rotDeg = Math.toDegrees(sx * rho);
                int rot = (int) Math.round(rotDeg);
                while (rot > 180) rot -= 360;
                while (rot <= -180) rot += 360;
                double wk2 = n1, hk2 = n2;
                // (ox', oy') = diag(sx, sy) . Rot(-rho) . t_K
                double cc = Math.cos(rho), ss = Math.sin(rho);
                double ux = cc * tkx + ss * tky, uy = -ss * tkx + cc * tky;
                Frame f = new Frame();
                f.flipH = sx < 0; f.flipV = sy < 0;
                f.ox = (int) Math.round(sx * ux); f.oy = (int) Math.round(sy * uy);
                f.rot = rot;
                f.zx = (int) Math.round(wk2 / wK * 100.0);
                f.zy = (int) Math.round(hk2 / hK * 100.0);
                double cost = ((sx != sxR ? 1 : 0) + (sy != syR ? 1 : 0)) * 10 + (rot != r.rot ? 1 : 0);
                if (cost < bestCost) { bestCost = cost; best = f; }
            }
        }
        return best;
    }

    /** Escreve os valores do frame no MPT (copia): Flip, centro proprio e RAZ so quando precisam existir (o alpha do RAZ e preservado). */
    static Ano.Mpt write(Ano.Mpt src, Frame f, int newImage) {
        Ano.Mpt m = src.copy();
        m.image = newImage;
        int base = (m.flags & 2) != 0 ? m.wActFlag : 0;
        int w = (base & ~(16 | 32)) | (f.flipH ? 16 : 0) | (f.flipV ? 32 : 0);
        if (w != 0) { m.flags |= 2; m.wActFlag = w; } else { m.flags &= ~2; m.wActFlag = 0; }
        if (f.ox != 0 || f.oy != 0) { m.flags |= 1; m.midX = f.ox; m.midY = f.oy; }
        else { m.flags &= ~1; m.midX = 0; m.midY = 0; }
        boolean hadAlpha = (m.flags & 0x80) != 0 && m.alphaRaw != 0;
        if (f.rot != 0 || f.zx != 100 || f.zy != 100 || hadAlpha) {
            if ((m.flags & 0x80) == 0) { m.flags |= 0x80; m.alphaRaw = 0; }
            m.rot = f.rot; m.xZoom = f.zx; m.yZoom = f.zy;
        } else {
            m.flags &= ~0x80; m.rot = 0; m.alphaRaw = 0; m.xZoom = 100; m.yZoom = 100;
        }
        m.normalize();
        return m;
    }

    /** Reescreve o MPT {@code m} (que usa R) para usar K; null se nao ha solucao. */
    static Ano.Mpt rewrite(Ano.Mpt m, int wR, int hR, int wK, int hK, int g, int kImage, boolean allowFlip) {
        Frame f = solve(read(m), wR, hR, wK, hK, g, allowFlip);
        return f == null ? null : write(m, f, kImage);
    }
}
