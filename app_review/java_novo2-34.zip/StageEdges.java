package com.zue.attackeditor;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Retangulo azul da tela do jogo (480 x 320), retangulo amarelo do zoom e bordas vermelhas do mapa: desenhados na principal e na previa da reacao. */
final class StageEdges {
    private StageEdges() { }

    /** {@code top}/{@code bot}: extensao vertical (mundo) das bordas do mapa; {@code scale}: zoom atual da view (para a espessura). */
    static void draw(Canvas c, BattleSim sim, Paint p, float scale, float top, float bot) { draw(c, sim, p, scale, top, bot, false); }

    /** {@code alwaysMap}: desenha as bordas do mapa mesmo com o botao BORDAS desligado (a previa da reacao precisa vê-las). */
    static void draw(Canvas c, BattleSim sim, Paint p, float scale, float top, float bot, boolean alwaysMap) {
        p.setStrokeWidth(2f / scale);
        p.setColor(0xFF4C8DFF);
        float sl = sim.screenLeft() / 65536f, sr = sl + 480f;
        Paint.Style st = p.getStyle();
        p.setStyle(Paint.Style.STROKE);
        float stp = sim.screenTop() / 65536f;
        c.drawRect(sl, stp, sr, stp + 320f, p);
        float[] zr = sim.zoomRect();
        if (zr != null) {
            p.setColor(0xFFFFC94C);
            c.drawRect(zr[0], zr[1], zr[2], zr[3], p);
        }
        p.setStyle(st);
        if (BattleSim.edgeMode == 0 && !alwaysMap) return;
        p.setColor(0xFFFF5050);
        float ml = sim.mapLeft() / 65536f, mr = sim.mapRight() / 65536f;
        c.drawLine(ml, top, ml, bot, p);
        c.drawLine(mr, top, mr, bot, p);
    }
}
