package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Seletor "−  valor  +": segurar nos botoes repete (se hold); o numero do meio ou abre o teclado (keyboard) ou so avisa um toque
 * (tap: abre uma lista, nunca o teclado). Guarda o valor atual; setValue() atualiza o texto sem disparar o listener.
 */
final class Stepper {
    interface OnValue { void on(double v); }

    private final Context c;
    private final float d;
    private final LinearLayout row;
    private final TextView minus, plus;
    private View center;
    private EditText edit;
    private TextView label;
    private double value, step = 1, min = -1e9, max = 1e9;
    private boolean hold = true;
    private OnValue listener;
    private Runnable onTap;
    private int color = LayoutManager.TEXT;
    private String suffix = "";

    Stepper(Context c) {
        this.c = c;
        this.d = c.getResources().getDisplayMetrics().density;
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        minus = side("−");
        plus = side("+");
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView side(String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(LayoutManager.TEXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setClickable(true);
        return t;
    }

    /** Botao lateral no mesmo estilo (para quem monta a linha sozinho, ex.: a pagina SOM). */
    static TextView sideButton(Context c, String s) { return new Stepper(c).side(s); }

    Stepper step(double s) { step = s; return this; }
    Stepper range(double lo, double hi) { min = lo; max = hi; return this; }
    Stepper hold(boolean h) { hold = h; return this; }
    Stepper color(int col) { color = col; if (edit != null) edit.setTextColor(col); if (label != null) label.setTextColor(col); return this; }
    Stepper suffix(String s) { suffix = s; return this; }
    Stepper value(double v) { value = clamp(v); show(); return this; }

    /** O numero do meio e um campo de teclado; confirmar (ok ou sair do campo) chama o listener. */
    Stepper keyboard(OnValue l) {
        listener = l;
        edit = new EditText(c);
        edit.setTextColor(color);
        edit.setTypeface(Typeface.MONOSPACE);
        edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        edit.setSingleLine(true);
        edit.setGravity(Gravity.CENTER);
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        edit.setImeOptions(EditorInfo.IME_ACTION_DONE);
        edit.setSelectAllOnFocus(true);
        edit.setPadding(dp(4), dp(4), dp(4), dp(4));
        final Runnable commit = new Runnable() { public void run() {
            double v;
            try { v = Double.parseDouble(edit.getText().toString().trim().replace(',', '.')); } catch (NumberFormatException e) { show(); return; }
            v = clamp(v);
            if (v != value) { value = v; if (listener != null) listener.on(v); }
            show();
        } };
        edit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent k) { commit.run(); return false; }
        });
        edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) { if (!has) commit.run(); }
        });
        center = edit;
        return this;
    }

    /** O numero do meio so avisa o toque (sem teclado). */
    Stepper tap(Runnable r) {
        onTap = r;
        label = new TextView(c);
        label.setTextColor(color);
        label.setTypeface(Typeface.MONOSPACE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        label.setGravity(Gravity.CENTER);
        label.setPadding(dp(4), dp(8), dp(4), dp(8));
        label.setClickable(true);
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL);
        g.setCornerRadius(dp(8));
        label.setBackground(g);
        label.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { if (onTap != null) onTap.run(); } });
        center = label;
        return this;
    }

    Stepper onChange(OnValue l) { listener = l; return this; }

    private double clamp(double v) { return Math.max(min, Math.min(max, v)); }

    private void nudge(int dir) {
        double v = clamp(Math.round((value + dir * step) * 1000.0) / 1000.0);
        if (v == value) return;
        value = v;
        show();
        if (listener != null) listener.on(v);
    }

    private void show() {
        String s = LayoutManagerFmt.fmt(value) + suffix;
        if (edit != null) { if (!edit.isFocused() || !edit.getText().toString().equals(s)) edit.setText(LayoutManagerFmt.fmt(value)); }
        if (label != null) label.setText(s);
    }

    /** Monta (uma vez) e devolve a linha. */
    LinearLayout view() {
        if (row.getChildCount() > 0) return row;
        if (center == null) tap(null);
        show();
        if (hold) {
            Hold.attach(minus, new Runnable() { public void run() { nudge(-1); } });
            Hold.attach(plus, new Runnable() { public void run() { nudge(1); } });
        } else {
            minus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nudge(-1); } });
            plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nudge(1); } });
        }
        // compacto, do tamanho dos campos de antes (nao ocupa a largura toda)
        row.addView(minus, new LinearLayout.LayoutParams(dp(40), dp(38)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(78), -2);
        cp.setMargins(dp(4), 0, dp(4), 0);
        row.addView(center, cp);
        row.addView(plus, new LinearLayout.LayoutParams(dp(40), dp(38)));
        return row;
    }

    double value() { return value; }
}
