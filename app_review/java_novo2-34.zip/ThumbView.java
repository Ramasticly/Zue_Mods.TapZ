package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Miniatura de uma sprite (imagem do CNV) centralizada num fundo escuro; "sem imagem" quando o indice e -1 ou nao carrega. */
final class ThumbView extends View {
    private SpriteCache cache;
    private int image = -1;
    private final Paint bg = new Paint(), txt = new Paint(Paint.ANTI_ALIAS_FLAG), bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();

    ThumbView(Context c) {
        super(c);
        bg.setColor(0xFF0D0F13);
        txt.setColor(0xFF8A90A0);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(13f * c.getResources().getDisplayMetrics().density);
    }

    void set(SpriteCache cache, int image) {
        this.cache = cache;
        this.image = image;
        invalidate();
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        dst.set(0, 0, w, h);
        float r = 10f * getResources().getDisplayMetrics().density;
        cv.drawRoundRect(dst, r, r, bg);
        SpriteCache.Sprite sp = image < 0 || cache == null ? null : cache.get(image);
        if (sp == null || sp.bitmap == null) {
            I18nUi.drawText(cv, image < 0 ? "sem imagem" : "imagem " + image + " indisponível", w / 2f, h / 2f, txt);
            return;
        }
        float sw = sp.src.width(), sh = sp.src.height();
        float k = Math.min((w - 16) / sw, (h - 16) / sh);
        k = Math.min(k, 4f);
        float dw = sw * k, dh = sh * k;
        dst.set((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f);
        cv.drawBitmap(sp.bitmap, sp.src, dst, bmp);
    }
}
