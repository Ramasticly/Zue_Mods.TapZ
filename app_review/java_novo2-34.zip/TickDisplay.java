package com.zue.attackeditor;

/**
 * Numero do tick mostrado ao avancar pelo botao +1 tick (Java puro). Ticks em que a animacao fica congelada (hitstop, trava cinematica)
 * travam o numero; ao liberar, a contagem continua no seguinte ao travado: so os ticks dos Frames contam, os congelados nao.
 */
final class TickDisplay {
    private int offset;
    private boolean stalled;
    private int lockedReal = -1;

    /** Depois de um passo: {@code realTick} = tick da simulacao agora, {@code stalledNow} = a animacao esta congelada neste passo. */
    void afterStep(int realTick, boolean stalledNow) {
        if (stalledNow) {
            if (!stalled) lockedReal = realTick;       // entrou no congelamento: o numero fica neste tick
            stalled = true;
        } else {
            if (stalled) offset += realTick - lockedReal - 1;      // saiu: o proximo numero e o travado + 1
            stalled = false;
            lockedReal = -1;
        }
    }

    void reset() { offset = 0; stalled = false; lockedReal = -1; }

    boolean stalled() { return stalled; }

    int shown(int realTick) { return stalled ? lockedReal - offset : realTick - offset; }
}
