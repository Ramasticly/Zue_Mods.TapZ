package com.zue.attackeditor;

import java.util.List;

/** Liga os gestos e botoes da timeline por sprite as operacoes de {@link FrameOps} e {@link ObjModel}. */
final class TimelineOps implements TimelineView.Listener {
    interface Pick { void on(int index); }

    interface Host {
        /** Seleciona o item na timeline e abre as ferramentas dele. */
        void show(int type, int idx, int flag, int occ);
        void closeTools();
        /** Fechar sem aplicar (toque fora): descarta a sessao de edicao. */
        void cancelTools();
        void toast(String msg);
        void choose(String title, String[] items, Pick pick);
    }

    // itens do menu "ADICIONAR"
    static final String[] ADD_ITEMS = {"Sprite", "Hitbox (ataque)", "Hurtbox (corpo)", "Projetil", "Efeito", "Acao especial", "Som", "Velocidade", "Animacao ligada (link)"};

    private final AttackView v;
    private final TimelineView tl;
    private final Host host;

    TimelineOps(AttackView v, TimelineView tl, Host host) {
        this.v = v;
        this.tl = tl;
        this.host = host;
    }

    private Ano.Mpt[] mpts() {
        Ano a = v.currentAno();
        return a == null ? null : a.mpts;
    }

    /** Aplica a nova lista de MPTs e volta o ponteiro para {@code tick}. */
    private void apply(Ano.Mpt[] mp, int tick) {
        v.replaceMpts(mp);
        int[] st = FrameOps.starts(mp);
        int total = FrameOps.total(mp);
        int t = Math.max(0, Math.min(total - 1, tick));
        int fr = Math.max(0, FrameOps.frameAt(mp, t));
        v.seekToPatTick(fr, t - st[fr]);
    }

    private int frameAtPlayhead(Ano.Mpt[] mp) {
        int f = FrameOps.frameAt(mp, tl.playheadTick());
        return f < 0 ? mp.length - 1 : f;
    }

    // ---- menu ADICIONAR ----

    void addMenu() {
        if (v.currentAno() == null) { host.toast("nenhuma ANO carregada"); return; }
        host.choose("Adicionar", ADD_ITEMS, new Pick() { public void on(int i) { add(i); } });
    }

    void add(int item) {
        Ano a = v.currentAno();
        if (a == null) return;
        switch (item) {
            case 0: addSpriteAfter(frameAtPlayhead(a.mpts)); break;
            case 1: addObject(2); break;
            case 2: addObject(1); break;
            case 3: addObject(0); break;
            case 4: addObject(10); break;
            case 5:
                AttackData add = v.attackData();
                final int[] fl = ObjModel.actionFlagsFor(add == null ? null : add.move, add == null ? -1 : add.moveIndex);
                final String[] names = new String[fl.length];
                for (int i = 0; i < names.length; i++) names[i] = ObjModel.actionName(fl[i]);
                host.choose("Acao especial", names, new Pick() { public void on(int i) { addObject(fl[i]); } });
                break;
            case 6: addProp(FrameOps.SOM, TimelineView.T_SOUND); break;
            case 7: addProp(FrameOps.MOV, TimelineView.T_MOVE); break;
            default: addLink(); break;
        }
    }

    private void addSpriteAfter(int f) {
        Ano.Mpt[] mp = mpts();
        Ano.Mpt[] n = FrameOps.duplicate(mp, f);
        apply(n, FrameOps.starts(n)[f + 1]);
        host.show(TimelineView.T_SPRITE, f + 1, -1, -1);
    }

    void addObject(int flag) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int f = frameAtPlayhead(mp);
        int occ = ObjModel.count(mp[f], flag);
        Ano.Hit proto = ObjModel.defaultHit(flag);
        // hitbox/hurtbox novas herdam a caixa da ultima do mesmo tipo (facilita ajustar)
        if (ObjModel.kindOf(flag) == ObjModel.HITBOX || ObjModel.kindOf(flag) == ObjModel.HURTBOX) {
            for (int i = f; i >= 0; i--) {
                Ano.Hit h = ObjModel.find(mp[i], flag, 0);
                if (h != null) { proto.x = h.x; proto.y = h.y; proto.width = h.width; proto.height = h.height; break; }
            }
        }
        Ano.Mpt[] n = ObjModel.add(mp, f, f, proto);
        apply(n, tl.playheadTick());
        host.show(TimelineView.T_OBJ, -1, flag, occ);
    }

    private void addProp(int track, int type) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int tick = tl.playheadTick();
        FrameOps.Split s = FrameOps.addKey(mp, track, tick);
        if (s == null) { host.toast("nao da para dividir este sprite aqui"); return; }
        apply(s.mpts, FrameOps.starts(s.mpts)[s.index]);
        host.show(type, s.index, -1, -1);
    }

    private void addLink() {
        Ano a = v.currentAno();
        Ano.Link[] ls = new Ano.Link[a.links.length + 1];
        System.arraycopy(a.links, 0, ls, 0, a.links.length);
        ls[a.links.length] = new Ano.Link(0, 0, 0x4000 | 0x8000);
        v.replaceAno(new Ano(a.index, true, a.flags | 2, a.priority, ls, a.mpts));
        host.show(TimelineView.T_LINK, a.links.length, -1, -1);
    }

    // ---- barra de ferramentas ----

    /** DIVIDIR: corta o sprite sob o ponteiro (o resultado visual continua igual). */
    void split() {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int tick = tl.playheadTick();
        if (tl.selectedType() == TimelineView.T_OBJ) { splitObject(mp, tick); return; }
        FrameOps.Split s = FrameOps.splitAt(mp, tick);
        if (s == null) { host.toast("nao da para dividir aqui"); return; }
        if (!s.changed) { host.toast("o ponteiro ja esta no inicio de um sprite"); return; }
        apply(s.mpts, tick);
        host.closeTools();          // so divide: nenhum dos dois pedacos fica selecionado nem abre a edicao
    }

    /** DIVIDIR com um objeto selecionado: separa na divisa de frames mais proxima do ponteiro (ficam dois objetos independentes). */
    private void splitObject(Ano.Mpt[] mp, int tick) {
        ObjModel.Obj o = tl.selectedObj();
        if (o == null) return;
        if (o.f1 <= o.f0) { host.toast("o objeto tem um so frame: nao ha divisa para dividir"); return; }
        int[] st = FrameOps.starts(mp);
        int bf = -1, bd = Integer.MAX_VALUE;
        for (int f = o.f0 + 1; f <= o.f1; f++) {
            int dd = Math.abs(st[f] - tick);
            if (dd < bd) { bd = dd; bf = f; }
        }
        if (bf < 0) return;
        Ano.Mpt[] out = mp.clone();
        Ano.Mpt c = mp[bf].copy();
        Ano.Hit h = ObjModel.find(c, o.flag, o.occ);
        if (h == null) return;
        h.cut = true;
        out[bf] = c;
        apply(out, tick);
        host.closeTools();          // so divide: nenhum dos dois objetos fica selecionado
    }

    void duplicateSelected() {
        Ano.Mpt[] mp = mpts();
        int ty = tl.selectedType();
        if (mp == null || ty == TimelineView.T_NONE) { host.toast("selecione um item"); return; }
        if (ty == TimelineView.T_OBJ) {
            ObjModel.Obj o = tl.selectedObj();
            if (o == null) return;
            // o duplicado entra no proximo frame depois do objeto (o mesmo que puxar a borda direita ate la)
            int f = o.f1 + 1;
            if (f >= mp.length) { host.toast("ja esta no ultimo sprite: nao ha proximo frame"); return; }
            int occ = ObjModel.count(mp[f], o.flag);
            Ano.Hit proto = ObjModel.find(mp[o.f1], o.flag, o.occ);
            if (proto == null) return;
            apply(ObjModel.add(mp, f, f, proto), tl.playheadTick());
            host.show(TimelineView.T_OBJ, -1, o.flag, occ);
        } else if (ty == TimelineView.T_LINK) {
            host.toast("selecione um sprite ou objeto");
        } else {
            int i = tl.selectedIndex();
            Ano.Mpt[] n = FrameOps.duplicate(mp, i);
            apply(n, FrameOps.starts(n)[i + 1]);
            host.show(TimelineView.T_SPRITE, i + 1, -1, -1);
        }
    }

    void deleteSelected() {
        Ano a = v.currentAno();
        int ty = tl.selectedType(), i = tl.selectedIndex();
        if (a == null || ty == TimelineView.T_NONE) { host.toast("selecione um item"); return; }
        int tick = tl.playheadTick();
        if (ty == TimelineView.T_SPRITE) {
            Ano.Mpt[] n = FrameOps.delete(a.mpts, i);
            if (n == null) { host.toast("a ANO precisa de ao menos um sprite"); return; }
            apply(n, FrameOps.starts(n)[Math.min(i, n.length - 1)]);
        } else if (ty == TimelineView.T_OBJ) {
            ObjModel.Obj o = tl.selectedObj();
            if (o == null) return;
            apply(ObjModel.remove(a.mpts, o), tick);
        } else if (ty == TimelineView.T_LINK) {
            if (i >= a.links.length) return;
            Ano.Link[] ls = new Ano.Link[a.links.length - 1];
            for (int k = 0, o = 0; k < a.links.length; k++) if (k != i) ls[o++] = a.links[k];
            v.replaceAno(new Ano(a.index, true, ls.length > 0 ? a.flags | 2 : a.flags & ~2, a.priority, ls, a.mpts));
        } else {
            int track = ty == TimelineView.T_SOUND ? FrameOps.SOM : ty == TimelineView.T_MOVE ? FrameOps.MOV : -1;
            if (track < 0) {            // estilo: limpa espelhar/manter e transformacao
                Ano.Mpt c = a.mpts[i].copy();
                c.wActFlag &= ~(ObjModel.FLIP_H | ObjModel.FLIP_V | ObjModel.KEEP_SPEED);
                if (c.wActFlag == 0) c.flags &= ~2;
                c.normalize();
                Ano.Mpt[] n = a.mpts.clone();
                n[i] = c;
                FrameOps.clear(FrameOps.RAZ, c);
                apply(n, tick);
            } else {
                apply(FrameOps.clearKey(a.mpts, track, i), tick);
            }
        }
        tl.clearSelection();
        host.closeTools();
    }

    // ---- gestos ----

    @Override public void onSelect(int type, int idx, int flag, int occ) {
        if (type == TimelineView.T_NONE) { host.cancelTools(); return; }
        if (type == TimelineView.T_SEQ) {
            java.util.List<SeqMark> ms = v.sequenceMarks();
            if (idx >= 0 && idx < ms.size()) v.seekToPat(ms.get(idx).pat);
        } else if (type != TimelineView.T_OBJ && type != TimelineView.T_LINK) v.seekToPat(idx);
        host.show(type, idx, flag, occ);
    }

    @Override public void onScrub(int pat, int elapsed) { v.seekToPatTick(pat, elapsed); }

    @Override public void onResize(int frame, int newTime) {
        Ano.Mpt[] mp = mpts();
        if (mp == null || frame >= mp.length) return;
        apply(FrameOps.setDuration(mp, frame, newTime), tl.playheadTick());
        host.show(TimelineView.T_SPRITE, frame, -1, -1);
    }

    @Override public void onTrimRun(int type, int flag, int occ, int fromFrame, int t0, int t1) {
        Ano.Mpt[] mp = mpts();
        if (mp == null || fromFrame < 0 || fromFrame >= mp.length) return;
        int total = FrameOps.total(mp);
        int fromTick = FrameOps.starts(mp)[fromFrame];
        t1 = Math.max(1, Math.min(total, t1));
        t0 = Math.max(0, Math.min(t1 - 1, t0));
        // a sprite e absoluta: as bordas ja vem assentadas nas divisoes de sprite (nada e dividido aqui)
        int nf0 = FrameOps.frameAt(mp, t0), nf1 = FrameOps.frameAt(mp, t1 - 1);
        int from = FrameOps.frameAt(mp, fromTick);
        if (nf0 < 0 || nf1 < 0 || from < 0) return;
        int tick = tl.playheadTick();
        if (type == TimelineView.T_OBJ) {
            ObjModel.Obj o = ObjModel.find(ObjModel.objects(mp), flag, occ, from);
            if (o == null) return;
            apply(ObjModel.trim(mp, o, nf0, nf1), tick);
            host.show(TimelineView.T_OBJ, -1, flag, occ);
        } else if (type == TimelineView.T_MOVE) {
            if (!FrameOps.isMoveHead(mp[from])) return;
            apply(FrameOps.setMoveRun(mp, from, nf1), tick);
            host.show(TimelineView.T_MOVE, from, -1, -1);
        } else if (type == TimelineView.T_STYLE) {
            apply(FrameOps.setStyleRun(mp, from, nf1), tick);
            host.show(TimelineView.T_STYLE, from, -1, -1);
        }
    }

    @Override public void onLoop(boolean on) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        apply(ObjModel.setLoop(mp, on), tl.playheadTick());
        host.toast(on ? "loop ligado: a animacao repete" : "loop desligado");
    }

    @Override public void onAddSprite() {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        addSpriteAfter(mp.length - 1);
    }

    @Override public void onEmpty(int type, int frame) {
        Ano.Mpt[] mp = mpts();
        if (mp == null || frame < 0 || frame >= mp.length) return;
        v.seekToPat(frame);
        if (type == TimelineView.T_STYLE) { host.show(type, frame, -1, -1); return; }
        int track = type == TimelineView.T_SOUND ? FrameOps.SOM : FrameOps.MOV;
        Ano.Mpt c = mp[frame].copy();
        FrameOps.defaults(track, c);
        Ano.Mpt[] n = mp.clone();
        n[frame] = c;
        apply(n, FrameOps.starts(n)[frame]);
        host.show(type, frame, -1, -1);
    }
}
