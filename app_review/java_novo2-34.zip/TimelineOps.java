package com.zue.attackeditor;

import java.util.List;

/** Liga os gestos e botoes da timeline por sprite as operacoes de {@link FrameOps} e {@link ObjModel}. */
final class TimelineOps implements TimelineView.Listener {
    interface Pick { void on(int index); }

    interface Host {
        /** Seleciona o item na timeline e abre as ferramentas dele. */
        void show(int type, int idx, int flag, int occ);
        void closeTools();
        /** Fechar sem aplicar (toque fora): descarta a sessao de edicao. */
        void cancelTools();
        void toast(String msg);
        void choose(String title, String[] items, Pick pick);
        /** Menu do + do fim da timeline (CAMADA, Adicionar Sprite...). */
        void endMenu();
        /** Seleciona o sprite e abre a gaveta direto na pagina Imagem. */
        void showImagePage(int idx);
        /** Abre o fluxo do golpe (editavel), onde se definem SEQ/END/pouso... */
        void openFlow();
        /** Lista de sprites do personagem para marcar varias (com o time delas); {@code l} recebe as escolhidas. */
        void pickSprites(SpriteListScreen.MultiListener l);
    }

    // itens do menu "ADICIONAR"
    static final String[] ADD_ITEMS = {"Sprite", "Hitbox (ataque)", "Hurtbox (corpo)", "Projetil", "Efeito", "Acao especial", "Som", "Velocidade", "Animacao ligada (link)", "SEQ (fluxo de sequencias)"};

    private final AttackView v;
    private final TimelineView tl;
    private final Host host;

    TimelineOps(AttackView v, TimelineView tl, Host host) {
        this.v = v;
        this.tl = tl;
        this.host = host;
    }

    private Ano.Mpt[] mpts() {
        Ano a = v.currentAno();
        return a == null ? null : a.mpts;
    }

    /** Aplica a nova lista de MPTs e volta o ponteiro para {@code tick}. */
    private void apply(Ano.Mpt[] mp, int tick) {
        v.replaceMpts(mp);
        int[] st = FrameOps.starts(mp);
        int total = FrameOps.total(mp);
        int t = Math.max(0, Math.min(total - 1, tick));
        int fr = Math.max(0, FrameOps.frameAt(mp, t));
        v.seekToPatTick(fr, t - st[fr]);
    }

    private int frameAtPlayhead(Ano.Mpt[] mp) {
        int f = FrameOps.frameAt(mp, tl.playheadTick());
        return f < 0 ? mp.length - 1 : f;
    }

    // ---- menu ADICIONAR ----

    void addMenu() {
        if (v.currentAno() == null) { host.toast("nenhuma ANO carregada"); return; }
        host.choose("Adicionar", ADD_ITEMS, new Pick() { public void on(int i) { add(i); } });
    }

    void add(int item) {
        Ano a = v.currentAno();
        if (a == null) return;
        switch (item) {
            case 0: addSpriteAtPlayhead(); break;
            case 1: addObject(2); break;
            case 2: addObject(1); break;
            case 3: addObject(0); break;
            case 4: addObject(10); break;
            case 5:
                AttackData add = v.attackData();
                final int[] fl = ObjModel.actionFlagsFor(add == null ? null : add.move, add == null ? -1 : add.moveIndex, frameOfPlayhead());
                final String[] names = new String[fl.length];
                for (int i = 0; i < names.length; i++) names[i] = ObjModel.actionName(fl[i]);
                host.choose("Acao especial", names, new Pick() { public void on(int i) { addObject(fl[i]); } });
                break;
            case 6: addProp(FrameOps.SOM, TimelineView.T_SOUND); break;
            case 7: addProp(FrameOps.MOV, TimelineView.T_MOVE); break;
            case 9: host.openFlow(); break;
            default: addLink(); break;
        }
    }

    /** Sprite novo no ponteiro: depois do frame se o ponteiro esta no meio dele; na divisa (ou no inicio/fim) fica no lugar dela. */
    private void addSpriteAtPlayhead() {
        Ano.Mpt[] mp = mpts();
        if (mp == null || mp.length == 0) return;
        int k = FrameOps.insertIndexAt(mp, tl.playheadTick());
        Ano.Mpt[] n = FrameOps.insertCopyAt(mp, k);
        apply(n, FrameOps.starts(n)[k]);
        host.show(TimelineView.T_SPRITE, k, -1, -1);
    }

    /** Frame do ponteiro (para o menu esconder o Puxar oponente onde ja ha Teleportar atras), ou null. */
    Ano.Mpt frameOfPlayhead() {
        Ano.Mpt[] mp = mpts();
        return mp == null || mp.length == 0 ? null : mp[frameAtPlayhead(mp)];
    }

    void addObject(int flag) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int f = frameAtPlayhead(mp);
        if (flag == ObjModel.ACT_BEHIND) {          // Teleportar atras = Puxar oponente (x -120) + Flip X, tratados como um so
            if (ObjModel.hasBehind(mp[f])) { host.toast("este frame ja tem Teleportar atras"); return; }
            int occB = ObjModel.count(mp[f], 40);
            apply(ObjModel.addBehind(mp, f, f), tl.playheadTick());
            host.show(TimelineView.T_OBJ, -1, 40, occB);
            return;
        }
        int occ = ObjModel.count(mp[f], flag);
        Ano.Hit proto = ObjModel.defaultHit(flag);
        // hitbox/hurtbox novas herdam a caixa da ultima do mesmo tipo (facilita ajustar)
        if (ObjModel.kindOf(flag) == ObjModel.HITBOX || ObjModel.kindOf(flag) == ObjModel.HURTBOX) {
            for (int i = f; i >= 0; i--) {
                Ano.Hit h = ObjModel.find(mp[i], flag, 0);
                if (h != null) { proto.x = h.x; proto.y = h.y; proto.width = h.width; proto.height = h.height; break; }
            }
        }
        Ano.Mpt[] n = ObjModel.add(mp, f, f, proto);
        apply(n, tl.playheadTick());
        host.show(TimelineView.T_OBJ, -1, flag, occ);
    }

    private void addProp(int track, int type) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int tick = tl.playheadTick();
        FrameOps.Split s = FrameOps.addKey(mp, track, tick);
        if (s == null) { host.toast("nao da para dividir este sprite aqui"); return; }
        apply(s.mpts, FrameOps.starts(s.mpts)[s.index]);
        host.show(type, s.index, -1, -1);
    }

    private void addLink() {
        Ano a = v.currentAno();
        Ano.Link[] ls = new Ano.Link[a.links.length + 1];
        System.arraycopy(a.links, 0, ls, 0, a.links.length);
        ls[a.links.length] = new Ano.Link(0, 0, 0x4000 | 0x8000);
        v.replaceAno(new Ano(a.index, true, a.flags | 2, a.priority, ls, a.mpts));
        host.show(TimelineView.T_LINK, a.links.length, -1, -1);
    }

    // ---- barra de ferramentas ----

    /** DIVIDIR: corta o sprite sob o ponteiro (o resultado visual continua igual). */
    void split() {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int tick = tl.playheadTick();
        if (tl.selectedType() == TimelineView.T_OBJ) { splitObject(mp, tick); return; }
        if (tl.selectedType() == TimelineView.T_MOVE) { splitMoveRun(mp, tick); return; }
        FrameOps.Split s = FrameOps.splitAt(mp, tick);
        if (s == null) { host.toast("nao da para dividir aqui"); return; }
        if (!s.changed) { host.toast("o ponteiro ja esta no inicio de um sprite"); return; }
        apply(s.mpts, tick);
        host.closeTools();          // so divide: nenhum dos dois pedacos fica selecionado nem abre a edicao
    }

    /** DIVIDIR com um trecho de velocidade selecionado: o ponteiro vira o inicio de um segundo trecho (a velocidade continua a mesma). */
    private void splitMoveRun(Ano.Mpt[] mp, int tick) {
        int f = FrameOps.frameAt(mp, tick);
        int head = f < 0 ? -1 : FrameOps.moveHeadOf(mp, f);
        if (head < 0) { host.toast("o ponteiro esta fora de um trecho de velocidade"); return; }
        if (f == head && FrameOps.starts(mp)[f] == tick) { host.toast("o ponteiro esta no inicio do trecho de velocidade: mova o ponteiro para dentro dele"); return; }
        FrameOps.Split s = FrameOps.splitMove(mp, tick);
        if (s == null) { host.toast("nao da para dividir a velocidade aqui"); return; }
        apply(s.mpts, tick);
        host.closeTools();
    }

    /**
     * DIVIDIR com um objeto selecionado: o objeto pertence ao frame, entao corta na divisa de frames mais proxima do
     * ponteiro (ficam dois objetos independentes) e o ponteiro vai para essa divisa.
     */
    private void splitObject(Ano.Mpt[] mp, int tick) {
        ObjModel.Obj o = tl.selectedObj();
        if (o == null || !ObjModel.sane(mp, o)) return;
        int[] st = FrameOps.starts(mp);
        int bf = ObjModel.splitBoundary(st, o, tick);
        if (bf < 0) { host.toast("o objeto tem um so frame: nao ha divisa para dividir"); return; }
        Ano.Mpt[] out = mp.clone();
        Ano.Mpt c = mp[bf].copy();
        Ano.Hit h = ObjModel.find(c, o.flag, o.occ);
        if (h == null) { host.toast("nao da para dividir aqui"); return; }
        h.cut = true;
        out[bf] = c;
        apply(out, st[bf]);
        host.closeTools();          // so divide: nenhum dos dois objetos fica selecionado
    }

    void duplicateSelected() {
        Ano.Mpt[] mp = mpts();
        int ty = tl.selectedType();
        if (mp == null || ty == TimelineView.T_NONE) { host.toast("selecione um item"); return; }
        if (ty == TimelineView.T_OBJ) {
            ObjModel.Obj o = tl.selectedObj();
            if (o == null) return;
            // o duplicado entra no proximo frame depois do objeto (o mesmo que puxar a borda direita ate la)
            int f = o.f1 + 1;
            if (f >= mp.length) { host.toast("ja esta no ultimo sprite: nao ha proximo frame"); return; }
            int occ = ObjModel.count(mp[f], o.flag);
            Ano.Hit proto = ObjModel.find(mp[o.f1], o.flag, o.occ);
            if (proto == null) return;
            Ano.Mpt[] dn = ObjModel.add(mp, f, f, proto);
            if (o.behind) dn[f] = ObjModel.setSpriteBit(dn[f], ObjModel.FLIP_H, true);        // o Flip X vai junto com o Teleportar atras
            apply(dn, tl.playheadTick());
            host.show(TimelineView.T_OBJ, -1, o.flag, occ);
        } else if (ty == TimelineView.T_LINK) {
            host.toast("selecione um sprite ou objeto");
        } else {
            int i = tl.selectedIndex();
            if (!FrameOps.ok(mp, i)) { host.toast("selecione um item"); return; }
            Ano.Mpt[] n = FrameOps.duplicate(mp, i);
            apply(n, FrameOps.starts(n)[i + 1]);
            host.show(TimelineView.T_SPRITE, i + 1, -1, -1);
        }
    }

    void deleteSelected() {
        Ano a = v.currentAno();
        int ty = tl.selectedType(), i = tl.selectedIndex();
        if (a == null || ty == TimelineView.T_NONE) { host.toast("selecione um item"); return; }
        int tick = tl.playheadTick();
        if (ty == TimelineView.T_SPRITE) {
            if (!FrameOps.ok(a.mpts, i)) { host.toast("selecione um item"); return; }
            Ano.Mpt[] n = FrameOps.delete(a.mpts, i);
            if (n == null) { host.toast("a ANO precisa de ao menos um sprite"); return; }
            apply(n, FrameOps.starts(n)[Math.min(i, n.length - 1)]);
        } else if (ty == TimelineView.T_OBJ) {
            ObjModel.Obj o = tl.selectedObj();
            if (o == null) return;
            apply(ObjModel.remove(a.mpts, o), tick);
        } else if (ty == TimelineView.T_LINK) {
            if (i < 0 || i >= a.links.length) return;
            Ano.Link[] ls = new Ano.Link[a.links.length - 1];
            for (int k = 0, o = 0; k < a.links.length; k++) if (k != i) ls[o++] = a.links[k];
            v.replaceAno(new Ano(a.index, true, ls.length > 0 ? a.flags | 2 : a.flags & ~2, a.priority, ls, a.mpts));
        } else {
            int track = ty == TimelineView.T_SOUND ? FrameOps.SOM : ty == TimelineView.T_MOVE ? FrameOps.MOV : -1;
            if (track < 0) {            // estilo: limpa espelhar/manter e transformacao
                Ano.Mpt c = a.mpts[i].copy();
                c.wActFlag &= ~(ObjModel.FLIP_H | ObjModel.FLIP_V);
                if (c.wActFlag == 0) c.flags &= ~2;
                c.normalize();
                Ano.Mpt[] n = a.mpts.clone();
                n[i] = c;
                FrameOps.clear(FrameOps.RAZ, c);
                apply(n, tick);
            } else {
                apply(FrameOps.clearKey(a.mpts, track, i), tick);
            }
        }
        tl.clearSelection();
        host.closeTools();
    }

    // ---- gestos ----

    @Override public void onSelect(int type, int idx, int flag, int occ) {
        if (type == TimelineView.T_NONE) { host.cancelTools(); return; }
        Ano.Mpt[] mp = mpts();
        if (type == TimelineView.T_SEQ) {
            java.util.List<SeqMark> ms = v.sequenceMarks();
            if (idx >= 0 && idx < ms.size()) seekIntoFrames(ms.get(idx).pat, ms.get(idx).pat);
        } else if (mp != null && idx >= 0 && idx < mp.length) {
            if (type == TimelineView.T_SPRITE || type == TimelineView.T_SOUND) seekIntoFrames(idx, idx);
            else if (type == TimelineView.T_MOVE) seekIntoFrames(idx, idx);          // cada Frame tem a sua celula de velocidade: nao seleciona o trecho todo
            else if (type == TimelineView.T_STYLE) seekIntoFrames(FrameOps.styleRunStart(mp, idx), FrameOps.styleRunEnd(mp, idx));
        }
        host.show(type, idx, flag, occ);
    }

    /** O ponteiro so vai para o clipe se estiver fora dele: antes, no inicio; depois, no ultimo tick. Dentro, fica onde esta. */
    private void seekIntoFrames(int f0, int f1) {
        Ano.Mpt[] mp = mpts();
        if (mp == null || f0 < 0 || f0 >= mp.length) return;
        f1 = Math.max(f0, Math.min(f1, mp.length - 1));
        int[] st = FrameOps.starts(mp);
        seekIntoClip(st[f0], st[f1] + FrameOps.span(mp[f1]));
    }

    private void seekIntoClip(int t0, int t1) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        int tick = tl.playheadTick();
        int target = FrameOps.clipTarget(tick, t0, t1);
        if (target == tick) return;
        int fr = FrameOps.frameAt(mp, target);
        if (fr < 0) return;
        v.seekToPatTick(fr, target - FrameOps.starts(mp)[fr]);
    }

    @Override public void onClip(int t0, int t1) { seekIntoClip(t0, t1); }

    @Override public void onScrub(int pat, int elapsed) { v.seekToPatTick(pat, elapsed); }

    @Override public void onResize(int frame, int newTime) {
        Ano.Mpt[] mp = mpts();
        if (!FrameOps.ok(mp, frame)) return;
        apply(FrameOps.setDuration(mp, frame, newTime), tl.playheadTick());
        host.show(TimelineView.T_SPRITE, frame, -1, -1);
    }

    @Override public void onTrimRun(int type, int flag, int occ, int fromFrame, int t0, int t1) {
        Ano.Mpt[] mp = mpts();
        if (mp == null || fromFrame < 0 || fromFrame >= mp.length) return;
        int total = FrameOps.total(mp);
        int fromTick = FrameOps.starts(mp)[fromFrame];
        t1 = Math.max(1, Math.min(total, t1));
        t0 = Math.max(0, Math.min(t1 - 1, t0));
        // a sprite e absoluta: as bordas ja vem assentadas nas divisoes de sprite (nada e dividido aqui)
        int nf0 = FrameOps.frameAt(mp, t0), nf1 = FrameOps.frameAt(mp, t1 - 1);
        int from = FrameOps.frameAt(mp, fromTick);
        if (nf0 < 0 || nf1 < 0 || from < 0) return;
        int tick = tl.playheadTick();
        if (type == TimelineView.T_OBJ) {
            ObjModel.Obj o = ObjModel.find(ObjModel.objects(mp), flag, occ, from);
            if (o == null) return;
            apply(ObjModel.trim(mp, o, nf0, nf1), tick);
            host.show(TimelineView.T_OBJ, -1, flag, occ);
        } else if (type == TimelineView.T_MOVE) {
            if (!FrameOps.isMoveHead(mp[from])) return;
            apply(FrameOps.setMoveRun(mp, from, nf1), tick);
            host.show(TimelineView.T_MOVE, from, -1, -1);
        } else if (type == TimelineView.T_STYLE) {
            apply(FrameOps.setStyleRun(mp, from, nf1), tick);
            host.show(TimelineView.T_STYLE, from, -1, -1);
        }
    }

    @Override public void onLoop(boolean on) {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        v.setLoop(on);
        host.toast(on ? "loop ligado: a animacao repete" : "loop desligado");
    }

    @Override public void onAddSprite() {
        if (mpts() == null) return;
        host.endMenu();          // o + do fim abre o menu (antes adicionava uma sprite direto)
    }

    /** Menu do + do fim: Adicionar Sprite = nova sprite depois do ponteiro, com a gaveta aberta na pagina Imagem. */
    void addSpriteEditing() {
        Ano.Mpt[] mp = mpts();
        if (mp == null) return;
        final int f = frameAtPlayhead(mp);
        final AttackData ad = v.attackData();
        if (ad == null || ad.attacker == null) return;
        // escolher uma ou mais sprites do personagem (com o time delas): so cria os Frames depois de escolher
        host.pickSprites(new SpriteListScreen.MultiListener() {
            @Override public void onPick(int[] images, AddSprites.Spec spec) {
                Ano.Mpt[] cur = mpts();
                if (cur == null) return;
                int at = Math.min(f, cur.length - 1);
                Centralize.Sizes sz = ad.attacker.sizes();
                double refH = Centralize.refHeight(ad.attacker.dac, sz);
                boolean noRef = spec.mode == AddSprites.Mode.RESCALE && refH <= 0;
                Ano.Mpt[] n = AddSprites.insert(cur, at, images, spec, ad.attacker.defaults(), sz, refH);
                if (n == cur) { host.toast("nao da para adicionar as sprites aqui"); return; }
                apply(n, FrameOps.starts(n)[at + 1]);
                host.show(TimelineView.T_SPRITE, at + 1, -1, -1);
                if (noRef) host.toast("sem a 1a sprite do Parado (ANO 0): usei CENTRAR, sem mudar o tamanho");
            }
        });
    }

    int layer() { return LayerOps.layerOf(v.currentAno()); }

    /** CAMADA: grava a nova camada da ANO atual (+ = mais em cima). */
    int setLayer(int layer) {
        Ano a = v.currentAno();
        if (a == null) return 0;
        Ano na = LayerOps.setLayer(a, layer);
        v.replaceAno(na, "camada");
        return LayerOps.layerOf(na);
    }

    @Override public void onEmpty(int type, int frame, int axis) {
        if (type == TimelineView.T_SEQ) { host.openFlow(); return; }          // faixa de transicoes sem marca: abre o fluxo editavel
        Ano.Mpt[] mp = mpts();
        if (mp == null || frame < 0 || frame >= mp.length) return;
        seekIntoFrames(frame, frame);
        if (type == TimelineView.T_STYLE) { host.show(type, frame, -1, -1); return; }
        int track = type == TimelineView.T_SOUND ? FrameOps.SOM : FrameOps.MOV;
        Ano.Mpt c = mp[frame].copy();
        if (track == FrameOps.MOV) FrameOps.defaultsMove(c, axis); else FrameOps.defaults(track, c);
        Ano.Mpt[] n = mp.clone();
        n[frame] = c;
        apply(n, FrameOps.starts(n)[frame]);
        host.show(type, frame, -1, -1);
    }
}
