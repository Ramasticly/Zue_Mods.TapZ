package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** Inspetores abaixo da timeline: sprite, objetos (hitbox, projetil, efeito, acoes) e links, editados em runtime. */
final class TimelineTools {
    private interface Mut { void apply(Ano.Mpt m); }
    private interface Setter { void set(double v); }

    // secoes do inspetor de sprite
    private static final int S_IMG = 0, S_TEMPO = 1, S_MOVER = 2, S_ESTILO = 3, S_SOM = 4, S_RAZ = 5, S_ALL = 6;
    private static final String[] SEC = {"IMAGEM", "TEMPO", "MOVER", "ESTILO", "SOM", "RAZ", "ALL"};
    private static final int C_SPRITE = 0xFFE5C100;

    private final Context c;
    private final AttackView view;
    private final TimelineView tl;
    private final float d;
    private final Runnable onChanged, onClose;
    Navigator nav;
    final LinearLayout root;
    private final TextView title;
    private final LinearLayout body;
    private int type = TimelineView.T_NONE, idx = -1, flag = -1, occ = -1, section;
    private int lastPat = -1;

    TimelineTools(Context c, AttackView view, TimelineView tl, Runnable onChanged, Runnable onClose) {
        this.c = c;
        this.view = view;
        this.tl = tl;
        this.d = c.getResources().getDisplayMetrics().density;
        this.onChanged = onChanged;
        this.onClose = onClose;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable sheetBg = new GradientDrawable();
        sheetBg.setColor(LayoutManager.BG);
        float rad = dp(14);
        sheetBg.setCornerRadii(new float[]{rad, rad, rad, rad, 0, 0, 0, 0});
        sheetBg.setStroke(dp(1), LayoutManager.PANEL_HI);
        root.setBackground(sheetBg);
        // alca de arrastar ("-"): puxe para cima/baixo para ajustar; arraste rapido para baixo fecha
        FrameLayout hbox = new FrameLayout(c);
        View bar = new View(c);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(LayoutManager.DIM);
        barBg.setCornerRadius(dp(3));
        bar.setBackground(barBg);
        hbox.addView(bar, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        hbox.setOnTouchListener(new View.OnTouchListener() {
            float downY, prevY, vel; long prevT; int startH; boolean moved;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        downY = prevY = e.getRawY(); prevT = e.getEventTime(); vel = 0; moved = false;
                        startH = root.getHeight();
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE: {
                        float y = e.getRawY();
                        long t = e.getEventTime();
                        if (t > prevT) vel = vel * 0.6f + (y - prevY) / (t - prevT) * 1000f * 0.4f;
                        prevY = y; prevT = t;
                        if (Math.abs(y - downY) > dp(4)) moved = true;
                        if (moved) setSheetHeight(startH - (int) (y - downY));
                        return true;
                    }
                    case android.view.MotionEvent.ACTION_UP: {
                        if (!moved) { tapHandle(); return true; }
                        float want = startH - (e.getRawY() - downY);
                        if (vel > 1800f || want < peekH() - dp(50)) { if (onCancel != null) onCancel.run(); }
                        return true;
                    }
                    default: return true;
                }
            }
        });
        root.addView(hbox, new LinearLayout.LayoutParams(-1, dp(22)));
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), 0, dp(6), dp(4));
        title = new TextView(c);
        title.setTextColor(LayoutManager.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(btn("\u21B6", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (TimelineTools.this.view.undoEdit()) {
                    baseUndo = Math.min(baseUndo, TimelineTools.this.view.undoCount());
                    refresh();
                }
            }
        }));
        head.addView(btn("\u2715", false, new View.OnClickListener() {
            @Override public void onClick(View v) { if (onCancel != null) onCancel.run(); }
        }));
        head.addView(btn("APLICAR", true, new View.OnClickListener() {
            @Override public void onClick(View v) { applyAllTab(); if (onApply != null) onApply.run(); }
        }));
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));
        // a gaveta tem altura variavel: o conteudo rola dentro dela
        body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(8), 0, dp(8), dp(24));
        ScrollView bodyScroll = new ScrollView(c);
        bodyScrollRef = bodyScroll;
        bodyScroll.setFillViewport(false);
        bodyScroll.addView(body, new ViewGroup.LayoutParams(-1, -2));
        root.addView(bodyScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.setVisibility(View.GONE);
    }

    // ---- gaveta (bottom sheet) ----

    private View scrollRef;
    private Runnable onApply, onCancel;
    private int sheetH, baseUndo = -1;

    void setSheetHost(View scroll, Runnable apply, Runnable cancel) {
        scrollRef = scroll;
        onApply = apply;
        onCancel = cancel;
    }

    private int peekH() { return dp(22 + 44); }

    private int maxH() {
        int avail = (scrollRef == null ? 0 : scrollRef.getHeight()) + (root.getVisibility() == View.VISIBLE ? root.getHeight() : 0);
        return Math.max(peekH() + dp(60), avail - dp(56));
    }

    private void setSheetHeight(int h) {
        h = Math.max(peekH(), Math.min(maxH(), h));
        sheetH = h;
        ViewGroup.LayoutParams p = root.getLayoutParams();
        if (p != null && p.height != h) { p.height = h; root.setLayoutParams(p); }
    }

    private void tapHandle() {
        int h = root.getHeight(), mx = maxH();
        if (h <= peekH() + dp(10)) setSheetHeight(Math.max(dp(220), mx / 2));
        else if (h < mx - dp(20)) setSheetHeight(mx);
        else setSheetHeight(Math.max(dp(220), mx / 2));
    }

    /** Abre a gaveta; no primeiro acesso guarda o ponto de desfazer (para descartar se nao aplicar). */
    void openSheet() {
        if (baseUndo < 0) {
            view.breakUndo();
            baseUndo = view.undoCount();
        }
        boolean was = root.getVisibility() == View.VISIBLE;
        root.setVisibility(View.VISIBLE);
        if (!was) {
            int h = sheetH > 0 ? sheetH : Math.max(dp(220), maxH() / 2);
            setSheetHeight(h);
        }
    }

    /** Fecha mantendo o que ja foi feito. */
    void hideSheet() {
        view.stopSounds();
        baseUndo = -1;
        root.setVisibility(View.GONE);
    }

    /** Mesmo efeito de tocar fora / arrastar para baixo: descarta o que nao foi aplicado e fecha. */
    void cancelSheet() { if (onCancel != null) onCancel.run(); }

    boolean sheetOpen() { return root.getVisibility() == View.VISIBLE; }

    /** Descarta tudo o que foi editado desde que a gaveta abriu; devolve quantos passos desfez. */
    int discardSession() {
        int n = 0;
        if (baseUndo >= 0) while (view.undoCount() > baseUndo && view.undoEdit()) n++;
        baseUndo = -1;
        root.setVisibility(View.GONE);
        onChanged.run();
        return n;
    }

    // ---- util de UI ----

    private int dp(int v) { return Math.round(v * d); }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
        t.setPadding(dp(8), dp(7), dp(8), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(p);
        return t;
    }

    private LinearLayout line() {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(l, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    private TextView note(String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.DIM);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        body.addView(t);
        return t;
    }

    private static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e9) return String.valueOf((long) v);
        String s = String.format(Locale.US, "%.3f", v);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s;
    }

    /** Linha "nome  [-] valor [+]" com campo digitavel (aplica ao confirmar ou ao sair do campo). */
    private void num(LinearLayout parent, String name, double value, final double step, final Setter set) {
        TextView lab = new TextView(c);
        lab.setText(name);
        lab.setTextColor(LayoutManager.DIM);
        lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        parent.addView(lab, new LinearLayout.LayoutParams(dp(58), -2));
        final EditText et = new EditText(c);
        et.setText(fmt(value));
        et.setTextColor(LayoutManager.TEXT);
        et.setTypeface(Typeface.MONOSPACE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        et.setSingleLine(true);
        et.setGravity(Gravity.CENTER);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.setPadding(dp(4), dp(4), dp(4), dp(4));
        final double[] cur = {value};
        final Runnable commit = new Runnable() {
            @Override public void run() {
                double v;
                try { v = Double.parseDouble(et.getText().toString().trim()); } catch (NumberFormatException e) { et.setText(fmt(cur[0])); return; }
                if (v == cur[0]) return;
                cur[0] = v;
                set.set(v);
            }
        };
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent k) { commit.run(); return false; }
        });
        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) { if (!has) commit.run(); }
        });
        TextView bMinus = btn("−", false, null);
        Hold.attach(bMinus, new Runnable() { @Override public void run() {
            cur[0] -= step;
            et.setText(fmt(cur[0]));
            set.set(cur[0]);
        } });
        parent.addView(bMinus);
        parent.addView(et, new LinearLayout.LayoutParams(dp(78), -2));
        TextView bPlus = btn("+", false, null);
        Hold.attach(bPlus, new Runnable() { @Override public void run() {
            cur[0] += step;
            et.setText(fmt(cur[0]));
            set.set(cur[0]);
        } });
        parent.addView(bPlus);
    }

    // ---- estado / ciclo ----

    void refresh() {
        show(type, idx, flag, occ);
        onChanged.run();
    }

    /** O ponteiro mudou de sprite: o inspetor acompanha (so quando nao esta tocando). */
    void follow(int pat, boolean playing) {
        if (pat == lastPat) return;
        lastPat = pat;
        if (playing || type == TimelineView.T_NONE || type == TimelineView.T_LINK || type == TimelineView.T_SEQ || root.getVisibility() != View.VISIBLE) return;
        if (type == TimelineView.T_OBJ) { show(type, idx, flag, occ); return; }
        int ni = pat;
        Ano fa = cur();
        if (type == TimelineView.T_MOVE && fa != null) {
            int h = FrameOps.moveHeadOf(fa.mpts, pat);
            if (h >= 0) ni = h;
        }
        show(type, ni, flag, occ);
        tl.select(type, ni, flag, occ);
    }

    private Ano cur() { return view.currentAno(); }

    private Ano.Mpt sprite() {
        Ano a = cur();
        if (a == null || idx < 0 || idx >= a.mpts.length) return null;
        return a.mpts[idx];
    }

    private void edit(Mut mu) {
        Ano.Mpt m = sprite();
        if (m == null) return;
        Ano.Mpt n = m.copy();
        mu.apply(n);
        n.normalize();
        view.changeMpt(idx, n);
        onChanged.run();
    }

    private void editAndRebuild(Mut mu) {
        edit(mu);
        show(type, idx, flag, occ);
    }

    private static void bit(Ano.Mpt m, int b, boolean on) { if (on) m.flags |= b; else m.flags &= ~b; }

    /** Como replaceMpts, mas para edicoes grandes: recalcula a animacao em segundo plano com a janela de progresso. */
    private void replaceMptsBusy(final Ano.Mpt[] mp, final int newIdx, String title, final Runnable after) {
        final Ano a = cur();
        if (a == null) return;
        if (!(c instanceof android.app.Activity)) { replaceMpts(mp, newIdx); if (after != null) after.run(); return; }
        final BusyDialog busy = BusyDialog.show((android.app.Activity) c, title);
        busy.set("Recalculando a animacao...", 0, 0);
        view.replaceAnoAsync(new Ano(a.index, true, a.flags, a.priority, a.links, mp), new Runnable() {
            @Override public void run() {
                busy.set("Atualizando a linha do tempo...", 0, 0);
                idx = Math.max(0, Math.min(mp.length - 1, newIdx));
                view.seekToPat(idx);
                show(type, idx, flag, occ);
                onChanged.run();
                if (after != null) after.run();
                busy.dismiss();
            }
        });
    }

    private void replaceMpts(Ano.Mpt[] mp, int newIdx) {
        Ano a = cur();
        if (a == null) return;
        view.replaceAno(new Ano(a.index, true, a.flags, a.priority, a.links, mp));
        idx = Math.max(0, Math.min(mp.length - 1, newIdx));
        view.seekToPat(idx);
        show(type, idx, flag, occ);
        onChanged.run();
    }

    private TextView head(String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setPadding(dp(4), dp(6), dp(4), dp(1));
        body.addView(t);
        return t;
    }

    void show(int ty, int i, int fl, int oc) {
        type = ty;
        idx = i;
        flag = fl;
        occ = oc;
        body.removeAllViews();
        if (ty == TimelineView.T_NONE) return;
        Ano a = cur();
        if (a == null) return;
        lastPat = view.currentPat();
        if (!(ty == TimelineView.T_OBJ && focusOn && fl == focusFlag && oc == focusOcc)) focusOn = false;
        if (ty == TimelineView.T_OBJ) { object(a); return; }
        if (ty == TimelineView.T_SEQ && openSeqAsHitbox(a, i)) return;
        if (ty == TimelineView.T_SEQ) { title.setTextColor(0xFFFF5D8F); seqPanel(a); return; }
        if (ty == TimelineView.T_LINK) { title.setTextColor(0xFF2EC4C4); title.setText("ANIMACAO LIGADA  ·  " + (i + 1) + "/" + a.links.length); link(a); return; }
        if (ty == TimelineView.T_MOVE) section = S_MOVER;
        else if (ty == TimelineView.T_STYLE) section = S_ESTILO;
        else if (ty == TimelineView.T_SOUND) section = S_SOM;
        else if (section == S_MOVER || section == S_ESTILO || section == S_SOM) section = S_IMG;
        if (idx < 0 || idx >= a.mpts.length) return;
        title.setTextColor(C_SPRITE);
        title.setText("SPRITE " + (idx + 1) + "/" + a.mpts.length + "  ·  " + ObjModel.seconds(FrameOps.span(a.mpts[idx])));
        sprite(a);
    }

    // ---- sprite ----

    private void sprite(final Ano a) {
        LinearLayout tabs = new LinearLayout(c);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        for (int k = 0; k < SEC.length; k++) {
            final int kk = k;
            tabs.addView(btn(SEC[k], section == k, new View.OnClickListener() { public void onClick(View v) {
                section = kk;
                type = kk == S_MOVER ? TimelineView.T_MOVE : kk == S_ESTILO ? TimelineView.T_STYLE : kk == S_SOM ? TimelineView.T_SOUND : TimelineView.T_SPRITE;
                tl.select(type, idx, -1, -1);
                show(type, idx, -1, -1);
            } }));
        }
        hs.addView(tabs);
        body.addView(hs);
        switch (section) {
            case S_IMG: secImagem(a); break;
            case S_TEMPO: secTempo(a); break;
            case S_MOVER: secMover(); break;
            case S_ESTILO: secEstilo(); break;
            case S_SOM: secSom(); break;
            case S_RAZ: secRaz(); break;
            case S_ALL: secAll(a); break;
            default: secImagem(a); break;
        }
    }

    /** Abre a lista de sprites do personagem do atacante para trocar a imagem do frame (com "+ ADICIONAR" na propria lista). */
    private void chooseImage() {
        AttackData ad = view.attackData();
        if (ad == null || !(c instanceof android.app.Activity)) return;
        Ano.Mpt cur = sprite();
        SpriteListScreen.show((android.app.Activity) c, ad.attacker.dir.getName(), ad.attacker, cur == null ? -1 : cur.image, new SpriteListScreen.Picker() {
            @Override public void onPick(final int image) {
                edit(new Mut() { public void apply(Ano.Mpt n) { n.image = image; } });
                show(type, idx, flag, occ);
            }
            @Override public void onPickFrames(int[] images, int[] delaysMs) {
                Ano an = cur();
                if (an == null || images.length == 0) return;
                int[] ticks = new int[images.length];
                for (int k = 0; k < ticks.length; k++) ticks[k] = SpriteGroups.ticks(k < delaysMs.length ? delaysMs[k] : 100);
                final int nIns = images.length;
                replaceMptsBusy(FrameOps.insertSprites(an.mpts, idx, images, ticks), idx + 1, "Adicionando " + nIns + " quadros", new Runnable() {
                    @Override public void run() {
                        tl.select(TimelineView.T_SPRITE, idx, -1, -1);
                        android.widget.Toast.makeText(c, nIns + " sprite(s) inseridas depois do frame " + (idx) + " (sem hitboxes: use ALL para copiar do frame anterior)", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, new Runnable() { @Override public void run() { view.refreshAfterExternalEdit(); tl.invalidate(); onChanged.run(); } });
    }

    // ---- ALL: aplicar as coisas deste frame em outros frames ----

    private static int allMode = 0, allN = 1, allMask = FrameOps.A_DEFAULT;
    private static final String[] ALL_NAMES = {"Posição x/y (centro)", "Hitboxes", "Hurtboxes", "Animações (efeitos e projéteis)", "Sons", "Flip (espelhar)", "Zoom", "Rotação",
            "Transparência (alpha)", "Ações especiais", "Estilo (manter velocidade...)", "Velocidade", "Duração (tempo)", "Imagem (sprite)"};
    private static final int[] ALL_BITS = {FrameOps.A_POS, FrameOps.A_HIT, FrameOps.A_HURT, FrameOps.A_ANIM, FrameOps.A_SOUND, FrameOps.A_FLIP, FrameOps.A_ZOOM, FrameOps.A_ROT,
            FrameOps.A_ALPHA, FrameOps.A_ACTION, FrameOps.A_STYLE, FrameOps.A_MOVE, FrameOps.A_TIME, FrameOps.A_IMAGE};

    private void secAll(final Ano a) {
        note("Aplique as coisas deste frame (" + (idx + 1) + ") nos outros frames desta animação.");
        head("FRAMES");
        LinearLayout r = line();
        String[] md = {"próximos N", "N anteriores", "todos desta ANO", "esta sprite (nesta ANO)", "esta sprite (todas as ANOs)"};
        for (int k = 0; k < 5; k++) {
            final int kk = k;
            if (k == 3) r = line();
            r.addView(btn((allMode == k ? "● " : "○ ") + md[k], allMode == k, new View.OnClickListener() { public void onClick(View v) {
                allMode = kk;
                show(type, idx, flag, occ);
            } }));
        }
        if (allMode < 2) {
            num(line(), "N", allN, 1, new Setter() { public void set(double v) {
                allN = Math.max(1, Math.min(999, (int) v));
                show(type, idx, flag, occ);
            } });
        }
        int[] rg = FrameOps.targetRange(a.mpts.length, idx, allMode, allN);
        int count = 0;
        for (int f = rg[0]; f <= rg[1]; f++) if (f != idx) count++;
        if (allMode >= 3) {
            int img = a.mpts[idx].image;
            count = FrameOps.countSprite(a.mpts, idx, img);
            int anos = count > 0 ? 1 : 0;
            if (allMode == 4) {
                Dac dd = view.packDac(2);
                count = 0; anos = 0;
                if (dd != null) for (int i = 0; i < dd.size(); i++) {
                    Ano oa = dd.getAno(i);
                    if (oa == null || !oa.present) continue;
                    int cn = FrameOps.countSprite(oa.mpts, oa.index == a.index ? idx : -1, img);
                    if (cn > 0) { count += cn; anos++; }
                }
            }
            note("Sprite " + img + (allMode == 4 ? ": " + count + " outro(s) frame(s) em " + anos + " ANO(s)" : ": " + count + " outro(s) frame(s) nesta ANO")
                    + (count == 0 ? " (nenhum frame para atingir)" : "") + ".");
        } else
        note(count == 0 ? "Não há frames nesse intervalo." : "Vai atingir " + count + " frame(s): " + (rg[0] + 1) + (rg[1] > rg[0] ? " a " + (rg[1] + 1) : "")
                + (rg[0] <= idx && idx <= rg[1] && allMode == 2 ? " (menos este)" : "") + ".");
        head("COPIAR");
        LinearLayout row = null;
        for (int k = 0; k < ALL_NAMES.length; k++) {
            if (k == 9) head("TUDO MAIS");
            final int bit = ALL_BITS[k];
            if (k % 2 == 0 || k == 9) row = line();
            boolean on = (allMask & bit) != 0;
            row.addView(btn((on ? "☑ " : "☐ ") + ALL_NAMES[k], on, new View.OnClickListener() { public void onClick(View v) {
                allMask ^= bit;
                show(type, idx, flag, occ);
            } }));
        }
        LinearLayout q = line();
        q.addView(btn("MARCAR TUDO", false, new View.OnClickListener() { public void onClick(View v) { allMask = FrameOps.A_ALL; show(type, idx, flag, occ); } }));
        q.addView(btn("BÁSICO", false, new View.OnClickListener() { public void onClick(View v) { allMask = FrameOps.A_DEFAULT; show(type, idx, flag, occ); } }));
        q.addView(btn("LIMPAR", false, new View.OnClickListener() { public void onClick(View v) { allMask = 0; show(type, idx, flag, occ); } }));
        note("Cada coisa marcada substitui a do frame de destino pela deste frame; se este frame não tem aquilo, o destino também fica sem. "
                + "Hitboxes iguais em frames seguidos viram um objeto só na timeline. Imagem, duração e velocidade ficam desmarcadas de propósito. Transições e dano (opções do frame) estão presos aos hits e não são copiados.");
        note("Use o APLICAR do topo para copiar nos " + count + " frame(s).");
    }

    /** Aba ALL: chamado pelo APLICAR do topo; copia as coisas marcadas deste frame nos frames escolhidos. */
    private void applyAllTab() {
        if (section != S_ALL || allMask == 0) return;
        Ano an = cur();
        if (an == null) return;
        if (allMode >= 3) { applySpriteTab(an); return; }
        int[] t = FrameOps.targetRange(an.mpts.length, idx, allMode, allN);
        int n = 0;
        for (int f = Math.max(0, t[0]); f <= Math.min(an.mpts.length - 1, t[1]); f++) if (f != idx) n++;
        if (n == 0) return;
        final int nAp = n;
        replaceMptsBusy(FrameOps.applyAll(an.mpts, idx, t[0], t[1], allMask), idx, "Aplicando em " + n + " frame(s)", new Runnable() {
            @Override public void run() { android.widget.Toast.makeText(c, "Aplicado em " + nAp + " frame(s)", android.widget.Toast.LENGTH_SHORT).show(); }
        });
    }

    /** ALL por sprite: aplica nos frames com a mesma imagem (nesta ANO, ou em todas as ANOs do personagem). */
    private void applySpriteTab(final Ano an) {
        final Ano.Mpt src = an.mpts[idx];
        final java.util.ArrayList<Ano> out = new java.util.ArrayList<Ano>();
        int frames = 0;
        if (allMode == 3) {
            if (FrameOps.countSprite(an.mpts, idx, src.image) > 0) {
                frames = FrameOps.countSprite(an.mpts, idx, src.image);
                out.add(new Ano(an.index, true, an.flags, an.priority, an.links, FrameOps.applySprite(an.mpts, idx, src, allMask)));
            }
        } else {
            Dac dd = view.packDac(2);
            if (dd != null) for (int i = 0; i < dd.size(); i++) {
                Ano oa = dd.getAno(i);
                if (oa == null || !oa.present || oa.mpts == null) continue;
                int skip = oa.index == an.index ? idx : -1;
                int cn = FrameOps.countSprite(oa.mpts, skip, src.image);
                if (cn == 0) continue;
                frames += cn;
                out.add(new Ano(oa.index, true, oa.flags, oa.priority, oa.links, FrameOps.applySprite(oa.mpts, skip, src, allMask)));
            }
        }
        if (out.isEmpty()) { android.widget.Toast.makeText(c, "Nenhum outro frame com essa sprite", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final int nf = frames, na = out.size();
        if (!(c instanceof android.app.Activity)) { view.replaceAnosAsync(out, null); return; }
        final BusyDialog busy = BusyDialog.show((android.app.Activity) c, "Aplicando em " + nf + " frame(s)");
        busy.set("Recalculando a animacao...", 0, 0);
        view.replaceAnosAsync(out, new Runnable() { public void run() {
            show(type, idx, flag, occ);
            onChanged.run();
            busy.dismiss();
            android.widget.Toast.makeText(c, "Aplicado em " + nf + " frame(s) de " + na + " ANO(s)", android.widget.Toast.LENGTH_SHORT).show();
        } });
    }

    private void secImagem(final Ano a) {
        Ano.Mpt m = sprite();
        LinearLayout imgRow = line();
        num(imgRow, "imagem", m.image, 1, new Setter() { public void set(final double v) {
            edit(new Mut() { public void apply(Ano.Mpt n) { n.image = (int) v; } });
            refreshTitle();
        } });
        imgRow.addView(btn("ESCOLHER", false, new View.OnClickListener() { public void onClick(View v) { chooseImage(); } }));
        boolean mid = (m.flags & 1) != 0;
        LinearLayout l = line();
        l.addView(btn(mid ? "● centro proprio" : "○ centro proprio", mid, new View.OnClickListener() { public void onClick(View v) {
            final boolean now = (sprite().flags & 1) != 0;
            if (now) shiftLinks(-sprite().midX, -sprite().midY);      // desligar o centro volta a sprite ao zero
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 1, !now); if (!now) { n.midX = 0; n.midY = 0; } } });
        } }));
        if (mid) {
            num(line(), "centro x", m.midX, 1, new Setter() { public void set(final double v) {
                final int old = sprite().midX;
                edit(new Mut() { public void apply(Ano.Mpt n) { n.midX = (int) v; } });
                shiftLinks((int) v - old, 0); } });
            num(line(), "centro y", m.midY, 1, new Setter() { public void set(final double v) {
                final int old = sprite().midY;
                edit(new Mut() { public void apply(Ano.Mpt n) { n.midY = (int) v; } });
                shiftLinks(0, (int) v - old); } });
        }
        if (a.links.length > 0) linkMoveBlock(a);
        LinearLayout b = line();
        b.addView(btn("◀ mover", false, new View.OnClickListener() { public void onClick(View v) { swap(a, -1); } }));
        b.addView(btn("mover ▶", false, new View.OnClickListener() { public void onClick(View v) { swap(a, 1); } }));
        b.addView(btn("duplicar", false, new View.OnClickListener() { public void onClick(View v) { duplicate(a); } }));
        b.addView(btn("remover", false, new View.OnClickListener() { public void onClick(View v) { remove(a); } }));
    }

    // ---- mover sprite + animacoes ligadas (links) ----
    /** 0 = nao sincroniza, 1 = so o frame atual, 2 = todos os frames da ANO filha. */
    private static int linkSync = 1;

    /**
     * Ao deslocar o centro de um frame da ANO pai, aplica o mesmo deslocamento ao centro dos frames das ANOs filhas:
     * modo 1 = o frame correspondente (o mesmo indice quando o filho sincroniza sprites; senao o primeiro);
     * modo 2 = todos os frames do filho.
     */
    private void shiftLinks(int dx, int dy) {
        Ano a = cur();
        if (linkSync == 0 || a == null || a.links.length == 0 || (dx == 0 && dy == 0)) return;
        java.util.HashSet<Integer> done = new java.util.HashSet<Integer>();
        for (int i = 0; i < a.links.length; i++) {
            Ano.Link l = a.links[i];
            if (l.getAno() == a.index || !done.add(l.getAno())) continue;
            Ano ch = view.anoAt(l.getAno());
            if (ch == null || !ch.present || ch.mpts.length == 0) continue;
            Ano.Mpt[] mp = new Ano.Mpt[ch.mpts.length];
            for (int k = 0; k < mp.length; k++) mp[k] = ch.mpts[k].copy();
            int only = l.syncMpt() ? Math.min(idx, mp.length - 1) : 0;
            for (int k = 0; k < mp.length; k++) {
                if (linkSync == 1 && k != only) continue;
                Ano.Mpt m = mp[k];
                if ((m.flags & 1) == 0) { m.flags |= 1; m.midX = 0; m.midY = 0; }
                m.midX += dx;
                m.midY += dy;
                m.normalize();
            }
            view.replaceAnoAt(new Ano(ch.index, true, ch.flags, ch.priority, ch.links, mp));
        }
        onChanged.run();
    }

    private void linkMoveBlock(final Ano a) {
        LinearLayout l = line();
        note("Ao mover o centro da sprite, desloca tambem o centro da ANO filha:");
        l.addView(btn(linkSync == 1 ? "● sincronizar frame atual" : "○ sincronizar frame atual", linkSync == 1, new View.OnClickListener() { public void onClick(View v) {
            linkSync = linkSync == 1 ? 0 : 1;
            show(type, idx, flag, occ);
        } }));
        l.addView(btn(linkSync == 2 ? "● sincronizar todos os frames" : "○ sincronizar todos os frames", linkSync == 2, new View.OnClickListener() { public void onClick(View v) {
            linkSync = linkSync == 2 ? 0 : 2;
            show(type, idx, flag, occ);
        } }));
        LinearLayout b = line();
        b.addView(btn("mover LINK (bx/by)", false, new View.OnClickListener() { public void onClick(View v) {
            pickLink("Mover qual link?", new TimelineOps.Pick() { public void on(int li) { moveLinkDialog(li); } });
        } }));
        b.addView(btn("editar LINK", false, new View.OnClickListener() { public void onClick(View v) {
            pickLink("Editar qual link?", new TimelineOps.Pick() { public void on(int li) {
                Ano cu = cur();
                if (nav != null && cu != null && li < cu.links.length) nav.openAno(cu.links[li].getAno(), false);
            } });
        } }));
        note("Frame atual: o frame do filho de mesmo indice (se sincroniza sprites) ou o primeiro. Todos: todos os frames do filho.");
    }

    private void pickLink(String title, final TimelineOps.Pick pick) {
        Ano a = cur();
        if (a == null || a.links.length == 0) return;
        if (a.links.length == 1) { pick.on(0); return; }
        String[] items = new String[a.links.length];
        for (int i = 0; i < items.length; i++) items[i] = "Link " + (i + 1) + "  ->  ANO " + a.links[i].getAno();
        new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(title)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) { pick.on(which); }
                }).show();
    }

    private void moveLinkDialog(final int li) {
        Ano a = cur();
        if (a == null || li >= a.links.length) return;
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(8), dp(14), dp(8));
        Ano.Link l0 = a.links[li];
        LinearLayout r1 = new LinearLayout(c);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout r2 = new LinearLayout(c);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        num(r1, "base x", l0.baseX, 1, new Setter() { public void set(double v) { setLinkBase(li, (int) v, null); } });
        num(r2, "base y", l0.baseY, 1, new Setter() { public void set(double v) { setLinkBase(li, null, (int) v); } });
        box.addView(r1);
        box.addView(r2);
        new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Link " + (li + 1) + "  ->  ANO " + l0.getAno()).setView(box).setPositiveButton("OK", null).show();
    }

    private void setLinkBase(int li, Integer x, Integer y) {
        Ano a = cur();
        if (a == null || li >= a.links.length) return;
        Ano.Link[] n = a.links.clone();
        Ano.Link o = n[li];
        n[li] = new Ano.Link(x != null ? x : o.baseX, y != null ? y : o.baseY, o.flags);
        view.replaceAno(new Ano(a.index, true, a.flags, a.priority, n, a.mpts));
        onChanged.run();
    }

    private void refreshTitle() {
        Ano a = cur();
        if (a == null || idx < 0 || idx >= a.mpts.length) return;
        title.setText("SPRITE " + (idx + 1) + "/" + a.mpts.length + "  ·  " + ObjModel.seconds(FrameOps.span(a.mpts[idx])));
    }

    private void secTempo(Ano a) {
        Ano.Mpt m = sprite();
        boolean t = (m.flags & 0x20) != 0;
        LinearLayout l = line();
        l.addView(btn(t ? "● tem duracao" : "○ tem duracao", t, new View.OnClickListener() { public void onClick(View v) {
            final boolean now = (sprite().flags & 0x20) != 0;
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 0x20, !now); if (!now) n.time = 4; } });
            refreshTitle();
        } }));
        if (t) {
            num(line(), "ticks", m.time, 1, new Setter() { public void set(final double v) {
                edit(new Mut() { public void apply(Ano.Mpt n) { n.time = Math.max(1, Math.min(255, (int) v)); } });
                refreshTitle();
            } });
            note("= " + TimelineView.timeText(m.time) + "  (60 ticks = 1 segundo). Dica: arraste a borda esquerda ou direita do clipe amarelo para cortar.");
        } else {
            note("Sem duracao: o sprite nao avanca sozinho (a timeline mostra 3 ticks).");
        }
    }

    private interface DurSet { void apply(int frames); }

    /** Campo DURACAO em frames completos: a sprite e absoluta, o item so escolhe por quantos frames dura. */
    private void durationField(Ano a, int first, int frames, int maxFrames, final DurSet set) {
        int ticks = 0;
        int[] st = FrameOps.starts(a.mpts);
        for (int f = first; f < first + frames && f < a.mpts.length; f++) ticks += FrameOps.span(a.mpts[f]);
        final int max = Math.max(1, maxFrames);
        num(line(), "duracao", frames, 1, new Setter() { public void set(double v) {
            set.apply(Math.max(1, Math.min(max, (int) Math.round(v))));
        } });
        note("em frames completos (de 1 a " + max + "): " + frames + (frames == 1 ? " frame" : " frames") + " = " + ObjModel.timeText(ticks)
                + ". O tempo de cada frame se muda na sprite.");
    }

    private void secMover() {
        Ano.Mpt m = sprite();
        boolean on = (m.flags & 4) != 0;
        if (!on) {
            note("Este sprite nao altera a velocidade.");
            line().addView(btn("+ ADICIONAR VELOCIDADE", true, new View.OnClickListener() { public void onClick(View v) {
                editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 4, true); n.moveMask = 1; n.speedX = 0; } });
            } }));
            return;
        }
        final Ano ma = cur();
        if (FrameOps.isMoveHead(ma.mpts[idx])) {
            final int head = idx;
            int last = FrameOps.moveRunEnd(ma.mpts, head);
            durationField(ma, head, last - head + 1, FrameOps.nextMoveHead(ma.mpts, head) - head, new DurSet() { public void apply(int n) {
                view.replaceMpts(FrameOps.setMoveRun(cur().mpts, head, head + n - 1));
                refresh();
            } });
        }
        String[] nm = {"veloc. x", "veloc. y", "acel. x", "acel. y"};
        for (int k = 0; k < 4; k++) {
            final int bitK = 1 << k;
            final int kk = k;
            boolean has = (m.moveMask & bitK) != 0;
            LinearLayout l = line();
            l.addView(btn(has ? "●" : "○", has, new View.OnClickListener() { public void onClick(View v) {
                editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { n.moveMask ^= bitK; } }); } }));
            if (has) {
                int raw = k == 0 ? m.speedX : k == 1 ? m.speedY : k == 2 ? m.accelX : m.accelY;
                num(l, nm[k], raw / 65536.0, k < 2 ? 1 : 0.1, new Setter() { public void set(final double v) {
                    edit(new Mut() { public void apply(Ano.Mpt n) {
                        int r = (int) (v * 65536.0);
                        if (kk == 0) n.speedX = r; else if (kk == 1) n.speedY = r; else if (kk == 2) n.accelX = r; else n.accelY = r; } });
                } });
            } else {
                TextView t = new TextView(c);
                t.setText(nm[k] + " (desligado)");
                t.setTextColor(LayoutManager.DIM);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
                l.addView(t);
            }
        }
        note("pixels por tick (aceleracao: px/tick²). Para manter a velocidade do sprite anterior, ligue \"manter velocidade\" em ESTILO.");
        line().addView(btn("✕ remover velocidade", false, new View.OnClickListener() { public void onClick(View v) {
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 4, false); n.moveMask = 0; } }); } }));
    }

    private void secEstilo() {
        Ano.Mpt m = sprite();
        final Ano sa = cur();
        if (FrameOps.styleSig(m) != 0) {
            final int first = FrameOps.styleRunStart(sa.mpts, idx);
            int last = FrameOps.styleRunEnd(sa.mpts, idx);
            durationField(sa, first, last - first + 1, sa.mpts.length - first, new DurSet() { public void apply(int n) {
                view.replaceMpts(FrameOps.setStyleRun(cur().mpts, first, first + n - 1));
                refresh();
            } });
        }
        LinearLayout l = line();
        l.addView(styleChip("↔ espelhar H", ObjModel.FLIP_H, m));
        l.addView(styleChip("↕ espelhar V", ObjModel.FLIP_V, m));
        l.addView(styleChip("⏩ manter velocidade", ObjModel.KEEP_SPEED, m));
        boolean interp = ObjModel.optField(m, 2) != 0;
        line().addView(btn(interp ? "● suavizar movimento entre sprites" : "○ suavizar movimento entre sprites", interp, new View.OnClickListener() { public void onClick(View v) {
            setOpt(2, ObjModel.optField(sprite(), 2) != 0 ? 0 : 1);
            show(type, idx, flag, occ);
        } }));
        note("Espelhar vale em relacao a direcao do personagem. Manter velocidade conserva a velocidade do sprite anterior. O dano e a reacao ficam na hitbox.");
        note("Rotacao, transparencia e zoom ficam na aba RAZ.");
    }

    private static boolean unirZoom = false;

    private void secRaz() {
        Ano.Mpt m = sprite();
        boolean raz = (m.flags & 0x80) != 0;
        LinearLayout r = line();
        r.addView(btn(raz ? "● transformacao ativa" : "○ transformacao ativa", raz, new View.OnClickListener() { public void onClick(View v) {
            final boolean now = (sprite().flags & 0x80) != 0;
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) {
                bit(n, 0x80, !now);
                if (!now) { n.rot = 0; n.alphaRaw = 0; n.xZoom = 100; n.yZoom = 100; }
            } });
        } }));
        if (!raz) { note("Ligue a transformacao para usar rotacao, alpha e zoom neste frame."); return; }
        head("ZOOM");
        LinearLayout u = line();
        u.addView(btn(unirZoom ? "☑ unir zoom" : "☐ unir zoom", unirZoom, new View.OnClickListener() { public void onClick(View v) {
            unirZoom = !unirZoom;
            show(type, idx, flag, occ);
        } }));
        u.addView(btn("zoom 100%", false, new View.OnClickListener() { public void onClick(View v) {
            edit(new Mut() { public void apply(Ano.Mpt n) { n.xZoom = 100; n.yZoom = 100; } });
            show(type, idx, flag, occ);
        } }));
        num(line(), "zoom x", m.xZoom, 1, new Setter() { public void set(final double v) {
            final int ox = sprite().xZoom, oy = sprite().yZoom;
            edit(new Mut() { public void apply(Ano.Mpt n) {
                n.xZoom = (int) v;
                if (unirZoom && ox != 0) n.yZoom = (int) Math.round(oy * v / ox);
            } });
            if (unirZoom) show(type, idx, flag, occ);
        } });
        num(line(), "zoom y", m.yZoom, 1, new Setter() { public void set(final double v) {
            final int ox = sprite().xZoom, oy = sprite().yZoom;
            edit(new Mut() { public void apply(Ano.Mpt n) {
                n.yZoom = (int) v;
                if (unirZoom && oy != 0) n.xZoom = (int) Math.round(ox * v / oy);
            } });
            if (unirZoom) show(type, idx, flag, occ);
        } });
        note("Unir zoom: mudar um eixo muda o outro na mesma proporcao (a sprite cresce sem deformar). 100 = tamanho normal.");
        head("ALPHA");
        num(line(), "alpha", m.alphaRaw, 1, new Setter() { public void set(final double v) {
            edit(new Mut() { public void apply(Ano.Mpt n) { n.alphaRaw = (int) v; } }); } });
        note("0 = opaco; 256 = aditivo; 512 = outro modo; +n = n/255 mais transparente");
        head("ROTACAO");
        num(line(), "graus", m.rot, 1, new Setter() { public void set(final double v) {
            edit(new Mut() { public void apply(Ano.Mpt n) { n.rot = (int) v; } }); } });
    }

    private TextView styleChip(String label, final int bitMask, Ano.Mpt m) {
        final boolean on = ObjModel.spriteBit(m, bitMask);
        return btn(on ? "● " + label : "○ " + label, on, new View.OnClickListener() { public void onClick(View v) {
            Ano.Mpt cm = sprite();
            if (cm == null) return;
            view.changeMpt(idx, ObjModel.setSpriteBit(cm, bitMask, !ObjModel.spriteBit(cm, bitMask)));
            show(type, idx, flag, occ);
            onChanged.run();
        } });
    }

    private void pickSound(final int currentSe) {
        AttackData ad = view.attackData();
        if (ad == null || !(c instanceof android.app.Activity)) return;
        SoundDialog.show((android.app.Activity) c, view, ad.attacker.dir, currentSe, new SoundDialog.Choose() { public void on(final int se) {
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 8, true); n.se = Math.max(-128, Math.min(127, se)); } });
            view.previewSe(se);
        } });
    }

    private void secSom() {
        Ano.Mpt m = sprite();
        boolean on = (m.flags & 8) != 0;
        if (!on) {
            note("Este sprite nao toca som.");
            line().addView(btn("ESCOLHER SOM", true, new View.OnClickListener() { public void onClick(View v) { pickSound(-1); } }));
            final int[] id = {1};
            num(line(), "som", 1, 1, new Setter() { public void set(double v) { id[0] = (int) v; } });
            line().addView(btn("+ ADICIONAR SOM", false, new View.OnClickListener() { public void onClick(View v) {
                editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 8, true); n.se = Math.max(-128, Math.min(127, id[0])); } });
            } }));
            return;
        }
        line().addView(btn("ESCOLHER SOM", true, new View.OnClickListener() { public void onClick(View v) { pickSound(sprite().se); } }));
        num(line(), "som", m.se, 1, new Setter() { public void set(final double v) {
            edit(new Mut() { public void apply(Ano.Mpt n) { n.se = Math.max(-128, Math.min(127, (int) v)); } });
            view.previewSe(sprite().se);
        } });
        LinearLayout l = line();
        l.addView(btn("▶ ouvir", false, new View.OnClickListener() { public void onClick(View v) { view.previewSe(sprite().se); } }));
        l.addView(btn("✕ remover som", false, new View.OnClickListener() { public void onClick(View v) {
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 8, false); n.se = -1; } }); } }));
        note("O som toca uma vez, quando o sprite comeca. De 1 a 79 sao sons comuns do jogo; de 80 em diante, os do personagem.");
    }


    private void setOpt(int field, int value) {
        Ano.Mpt m = sprite();
        if (m == null) return;
        view.changeMpt(idx, ObjModel.setOptField(m, field, value));
        onChanged.run();
    }

    private void swap(Ano a, int dir) {
        int j = idx + dir;
        if (j < 0 || j >= a.mpts.length) return;
        Ano.Mpt[] mp = a.mpts.clone();
        Ano.Mpt tmp = mp[idx]; mp[idx] = mp[j]; mp[j] = tmp;
        replaceMpts(mp, j);
    }

    private void duplicate(Ano a) {
        Ano.Mpt[] mp = FrameOps.duplicate(a.mpts, idx);
        replaceMpts(mp, idx + 1);
        tl.select(TimelineView.T_SPRITE, idx, -1, -1);
    }

    private void remove(Ano a) {
        Ano.Mpt[] mp = FrameOps.delete(a.mpts, idx);
        if (mp == null) return;
        replaceMpts(mp, Math.min(idx, mp.length - 1));
        tl.select(TimelineView.T_SPRITE, idx, -1, -1);
    }

    // ---- objetos ----

    private ObjModel.Obj curObj() {
        Ano a = cur();
        if (a == null) return null;
        int pat = Math.max(0, view.currentPat());
        ObjModel.Obj best = null;
        int bd = Integer.MAX_VALUE;
        for (ObjModel.Obj o : ObjModel.objects(a.mpts)) {
            if (o.flag != flag || o.occ != occ) continue;
            int dd = pat < o.f0 ? o.f0 - pat : pat > o.f1 ? pat - o.f1 : 0;
            if (dd < bd) { bd = dd; best = o; }
        }
        return best;
    }

    private int patIn(ObjModel.Obj o) { return Math.max(o.f0, Math.min(o.f1, view.currentPat())); }

    private void object(Ano a) {
        ObjModel.Obj o = curObj();
        if (o == null) { title.setText(""); return; }
        int pat = patIn(o);
        title.setTextColor(ObjModel.KIND_COLORS[o.kind]);
        String nm = o.kind == ObjModel.EFFECT ? "EFEITO" : o.kind == ObjModel.ACTION ? ObjModel.actionName(o.flag).toUpperCase(java.util.Locale.US) : ObjModel.KIND_NAMES[o.kind].toUpperCase(java.util.Locale.US);
        int t0 = FrameOps.starts(a.mpts)[o.f0], t1 = FrameOps.starts(a.mpts)[o.f1] + FrameOps.span(a.mpts[o.f1]);
        title.setText(nm + "  ·  " + ObjModel.seconds(t0).replace("s", "") + "–" + ObjModel.seconds(t1));
        durationField(a, o.f0, o.f1 - o.f0 + 1, a.mpts.length - o.f0, new DurSet() { public void apply(int n) {
            ObjModel.Obj oo = curObj();
            if (oo == null) return;
            view.replaceMpts(ObjModel.trim(cur().mpts, oo, oo.f0, oo.f0 + n - 1));
            refresh();
        } });
        if (o.f1 > o.f0) note("Frames conectados (" + (o.f0 + 1) + "–" + (o.f1 + 1) + "): mudar aqui muda em todos. Para editar um frame separado, selecione o objeto e use DIVIDIR na divisa de frames mais proxima.");
        switch (o.kind) {
            case ObjModel.HITBOX: case ObjModel.HURTBOX: box(a, o, pat); break;
            case ObjModel.PROJ: projectile(a, o, pat); break;
            case ObjModel.EFFECT: effect(a, o, pat); break;
            default: action(a, o, pat); break;
        }
        if (o.kind != ObjModel.HITBOX && o.kind != ObjModel.HURTBOX) keyInfo(a, o, pat);
    }

    /** Botao para remover o objeto (sem keyframes: os valores mudam so entre sprites). */
    private void keyInfo(Ano a, final ObjModel.Obj o, final int pat) {
        LinearLayout l = line();
        l.addView(btn("✕ remover objeto", false, new View.OnClickListener() { public void onClick(View v) {
            view.replaceMpts(ObjModel.remove(cur().mpts, o));
            tl.clearSelection();
            onClose.run();
            onChanged.run();
        } }));
    }

    private void editCoords(final ObjModel.Obj o, final int pat, final int field, final int val) {
        Ano a = cur();
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        if (h == null) return;
        int x = h.x, y = h.y, w = h.width, hh = h.height;
        if (field == 0) x = val; else if (field == 1) y = val; else if (field == 2) w = val; else hh = val;
        Ano.Mpt[] n = ObjModel.setCoordsRange(a.mpts, o, o.f0, o.f1, x, y, w, hh);      // conectado: todos os frames do objeto
        if (n == null) return;
        view.replaceMpts(n, "obj:" + a.index + ":" + o.flag + ":" + o.occ + ":" + field + ":" + pat);
        onChanged.run();
        // atualiza a timeline
        tl.invalidate();
    }

    private Setter coord(final ObjModel.Obj o, final int pat, final int field) {
        return new Setter() { public void set(double v) { editCoords(o, pat, field, (int) v); } };
    }

    // ---- transicao (SEQ / END) dentro do menu de Hitbox ----

    private boolean focusOn;
    private ScrollView bodyScrollRef;

    /** Rola o menu ate o fim (a secao de sequencia fica la). */
    private void scrollBodyToEnd() {
        if (bodyScrollRef == null) return;
        bodyScrollRef.post(new Runnable() { public void run() { bodyScrollRef.fullScroll(View.FOCUS_DOWN); } });
    }
    private int focusFlag, focusOcc;

    /** Clique no marcador SEQ/END da timeline: abre o menu da hitbox daquele frame, com a secao de transicao no topo. */
    private boolean openSeqAsHitbox(Ano a, int i) {
        java.util.List<SeqMark> ms = view.sequenceMarks();
        if (i < 0 || i >= ms.size()) return false;
        SeqMark m = ms.get(i);
        if (m.incoming || (m.kind != SeqMark.SEQ && m.kind != SeqMark.END && m.kind != SeqMark.HIT)) return false;
        if (m.kind == SeqMark.HIT) {                       // SEQ_PROJETIL: abre o menu do projetil (o ultimo lancado ate este frame, ou o primeiro)
            ObjModel.Obj pick = null;
            for (ObjModel.Obj o : ObjModel.objects(a.mpts)) {
                if (o.kind != ObjModel.PROJ) continue;
                if (pick == null || (o.f0 <= m.pat && o.f0 >= pick.f0)) pick = o;
            }
            if (pick == null) return false;
            focusOn = true; focusFlag = pick.flag; focusOcc = pick.occ;
            view.seekToPat(m.pat);
            tl.select(TimelineView.T_OBJ, -1, pick.flag, pick.occ);
            show(TimelineView.T_OBJ, -1, pick.flag, pick.occ);
            return true;
        }
        for (ObjModel.Obj o : ObjModel.objects(a.mpts)) {
            if (o.kind != ObjModel.HITBOX || m.pat < o.f0 || m.pat > o.f1) continue;
            focusOn = true; focusFlag = o.flag; focusOcc = o.occ;
            view.seekToPat(m.pat);
            tl.select(TimelineView.T_OBJ, -1, o.flag, o.occ);
            show(TimelineView.T_OBJ, -1, o.flag, o.occ);
            return true;
        }
        return false;
    }

    private static String anoText(int v) { return v == 0 ? "sem" : "ANO " + v; }

    /**
     * Botao "+ Transicao" / "Editar Transicao". Fora de uma ANO de SEQ: edita a SEQ (chao e ar). Dentro da ANO de SEQ: edita a END
     * (so existe ali: a END dispara num novo hit enquanto o atacante esta na ANO da SEQ). Na ANO de END nao ha transicao propria.
     */
    private void transitionBlock(Ano a, final ObjModel.Obj hitObj) {
        AttackData ad = view.attackData();
        head("Transição (sequência)");
        if (ad == null || ad.move == null || ad.move.generic) { note("Este ataque não tem dados de golpe (HDAT 4): sem transição."); return; }
        final CharData.Move mv = ad.move;
        final int cur = a.index;
        boolean seqC = mv.animSeqChao != 0 && cur == mv.animSeqChao, seqA = mv.animSeqAr != 0 && cur == mv.animSeqAr;
        boolean endHere = (mv.animEndChao != 0 && cur == mv.animEndChao) || (mv.animEndAr != 0 && cur == mv.animEndAr);
        if (!seqC && !seqA && endHere) {
            note("Esta ANO é o fim da sequência (END): não tem transição própria.");
            line().addView(btn("⇢ VER FLUXO", false, new View.OnClickListener() {
                public void onClick(View v) { if (c instanceof android.app.Activity) FlowDialog.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { show(type, idx, flag, occ); onChanged.run(); } }); }
            }));
            return;
        }
        final int kind = (seqC || seqA) ? SeqMark.END : SeqMark.SEQ;
        // variantes que valem aqui: SEQ = chao e ar; END = so a variante cuja SEQ e esta ANO
        final boolean wantGround = kind == SeqMark.SEQ || seqC, wantAir = kind == SeqMark.SEQ || seqA;
        String nm = kind == SeqMark.SEQ ? "Seq" : "End";
        int vg = kind == SeqMark.SEQ ? mv.animSeqChao : mv.animEndChao, va = kind == SeqMark.SEQ ? mv.animSeqAr : mv.animEndAr;
        String st = "";
        if (wantGround) st += nm + " chão: " + anoText(vg);
        if (wantAir) st += (st.isEmpty() ? "" : "   ·   ") + nm + " ar: " + anoText(va);
        note(st);
        if (kind == SeqMark.END) note("Esta ANO é o destino da SEQ: a END dispara num novo hit enquanto o atacante está aqui.");
        else note("A SEQ dispara quando um hit conecta nesta ANO. Chão e ar são definidos separadamente (o jogo escolhe pela posição do atacante).");
        boolean any = (wantGround && vg != 0) || (wantAir && va != 0);
        final boolean fg = wantGround, fa = wantAir;
        LinearLayout r = line();
        r.addView(btn((any ? "✎ Editar Transição" : "+ Transição") + (kind == SeqMark.END ? " END" : ""), true, new View.OnClickListener() {
            public void onClick(View v) { transitionDialog(kind, cur, fg, fa); }
        }));
        if (hitObj != null && kind == SeqMark.SEQ) {
            final Ano ca = cur();
            final boolean blk = ca != null && ObjModel.hasFlagRange(ca.mpts, hitObj.f0, hitObj.f1, 38);
            note("Bloquear sequência (flag 38) impede a SEQ de disparar quando este hit conecta.");
            line().addView(btn(blk ? "✕ DESBLOQUEAR SEQUÊNCIA" : "+ BLOQUEAR SEQUÊNCIA", blk, new View.OnClickListener() {
                public void onClick(View v) {
                    Ano cu = cur();
                    if (cu == null) return;
                    replaceMpts(ObjModel.setFlagRange(cu.mpts, hitObj.f0, hitObj.f1, 38, !blk), idx);
                    onChanged.run();
                }
            }));
        }
        r.addView(btn("⇢ VER FLUXO", false, new View.OnClickListener() {
            public void onClick(View v) { if (c instanceof android.app.Activity) FlowDialog.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { show(type, idx, flag, occ); onChanged.run(); } }); }
        }));
    }

    private android.widget.EditText ano255(int v) {
        android.widget.EditText e = new android.widget.EditText(c);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setText(v == 0 ? "" : String.valueOf(v));
        e.setHint("0 = sem");
        e.setTextColor(LayoutManager.TEXT);
        e.setHintTextColor(LayoutManager.DIM);
        e.setSingleLine(true);
        return e;
    }

    private void transitionDialog(final int kind, final int curAno, final boolean wantGround, final boolean wantAir) {
        final CharData.Move mv = view.attackData().move;
        final String nm = kind == SeqMark.SEQ ? "Seq" : "End";
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(8), dp(16), dp(4));
        TextView info = new TextView(c);
        info.setText(kind == SeqMark.SEQ ? "Para qual ANO o golpe vai quando um hit conecta (0 = nenhuma). Máximo " + CharData.Move.MAX + "."
                : "Para qual ANO o golpe vai num novo hit durante a SEQ (0 = nenhuma). Máximo " + CharData.Move.MAX + ".");
        info.setTextColor(LayoutManager.DIM);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        col.addView(info);
        final android.widget.EditText eg = ano255(kind == SeqMark.SEQ ? mv.animSeqChao : mv.animEndChao);
        final android.widget.EditText ea = ano255(kind == SeqMark.SEQ ? mv.animSeqAr : mv.animEndAr);
        if (wantGround) { col.addView(tvLabel(nm + " Chão")); col.addView(eg); }
        if (wantAir) { col.addView(tvLabel(nm + " Ar")); col.addView(ea); }
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(kind == SeqMark.SEQ ? "Transição (SEQ)" : "Transição (END)").setView(col)
                .setNegativeButton("CANCELAR", null).setPositiveButton("SALVAR", null).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button pos = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
        if (pos != null) {
            pos.setTextColor(LayoutManager.ACCENT);
            pos.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                int g = wantGround ? parse255(eg) : -1, ar = wantAir ? parse255(ea) : -1;
                if (g == curAno || ar == curAno) { Toast.makeText(c, "A transição não pode apontar para a própria ANO.", Toast.LENGTH_SHORT).show(); return; }
                if (wantGround && wantAir && ((g == 0) != (ar == 0))) {
                    // so um dos dois definido: pergunta o que fazer com o outro
                    dlg.dismiss();
                    askOther(kind, g, ar);
                    return;
                }
                dlg.dismiss();
                applyTransition(kind, wantGround ? g : -1, wantAir ? ar : -1);
            } });
        }
    }

    private TextView tvLabel(String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private static int parse255(android.widget.EditText e) {
        try { return Math.max(0, Math.min(CharData.Move.MAX, Integer.parseInt(e.getText().toString().trim()))); } catch (Exception x) { return 0; }
    }

    /** Definiu so chao ou so ar: avisa e deixa copiar para o outro ou manter sem transicao. */
    private void askOther(final int kind, final int g, final int ar) {
        final String nm = kind == SeqMark.SEQ ? "Seq" : "End";
        final boolean groundSet = g != 0;
        final String set = groundSet ? "chão" : "ar", other = groundSet ? "ar" : "chão";
        final int v = groundSet ? g : ar;
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Só " + nm + " " + set + " definida")
                .setMessage("Você definiu " + nm + " " + set + " (ANO " + v + "), mas não definiu " + nm + " " + other + ". "
                        + "Quando o atacante estiver no " + other + ", o hit não vai trocar de ANO.\n\nQuer usar a mesma ANO no " + other + " também?")
                .setPositiveButton("USAR A MESMA NO " + other.toUpperCase(java.util.Locale.US), new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { applyTransition(kind, v, v); }
                })
                .setNeutralButton("DEIXAR SEM " + nm.toUpperCase(java.util.Locale.US) + " NO " + other.toUpperCase(java.util.Locale.US), new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { applyTransition(kind, g, ar); }
                })
                .setNegativeButton("VOLTAR", null).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button b1 = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE), b2 = dlg.getButton(android.app.AlertDialog.BUTTON_NEUTRAL);
        if (b1 != null) b1.setTextColor(LayoutManager.ACCENT);
        if (b2 != null) b2.setTextColor(LayoutManager.ACCENT);
    }

    /** g / ar = -1: nao mexe naquela variante. */
    private void applyTransition(final int kind, final int g, final int ar) {
        view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) {
            if (g >= 0) setMoveField(mv, kind, false, 0, g);
            if (ar >= 0) setMoveField(mv, kind, true, 0, ar);
        } });
        show(type, idx, flag, occ);
        onChanged.run();
    }

    private void box(Ano a, ObjModel.Obj o, int pat) {
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        LinearLayout t = line();
        t.addView(btn("Hitbox (ataque)", o.kind == ObjModel.HITBOX, convert(o, 2)));
        t.addView(btn("Hurtbox (corpo)", o.kind == ObjModel.HURTBOX, convert(o, 1)));
        num(line(), "x", h.x, 1, coord(o, pat, 0));
        num(line(), "y", h.y, 1, coord(o, pat, 1));
        num(line(), "largura", h.width, 1, coord(o, pat, 2));
        num(line(), "altura", h.height, 1, coord(o, pat, 3));
        keyInfo(a, o, pat);     // remover fica junto da hitbox, antes de reacao/sequencia
        if (o.kind == ObjModel.HITBOX) {
            head("Dano e reacao (deste sprite)");
            Ano.Mpt m = a.mpts[pat];
            final int p2 = pat;
            num(line(), "dano", ObjModel.optField(m, 0), 1, optSetter(p2, 0));
            reactionBlock(p2);
            transitionBlock(a, o);
            if (focusOn) scrollBodyToEnd();
        }
    }

    private static final String[] GROUPS = {"normal (efeito 0, som 3, empurra)", "som alternativo (efeito 0, som 4, empurra)",
            "forte (efeito 1, som 6, empurra)", "leve (meio hitstop, sem empurrar)", "sem efeito, som nem hitstop"};

    /** Miniplayer da reacao (OPT 1) + escolha por previas + editor dos passos. */
    private void reactionBlock(final int pat) {
        Ano a = cur();
        if (a == null || pat < 0 || pat >= a.mpts.length) return;
        final int value = ObjModel.optField(a.mpts[pat], 1);
        final Opt1 op = new Opt1(value);
        head("Reacao do oponente");
        LinearLayout l = line();
        ReactionPreview rp = new ReactionPreview(c, view);
        rp.setValue(value);
        l.addView(rp, new LinearLayout.LayoutParams(dp(112), dp(112)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        l.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView info = new TextView(c);
        info.setText(op.valid ? (op.fromChar ? "reacao do personagem " + op.type : "reacao do jogo " + op.type) + "\n" + GROUPS[op.group] : "valor invalido (" + value + ")");
        info.setTextColor(LayoutManager.TEXT);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        info.setPadding(dp(6), 0, 0, dp(2));
        col.addView(info);
        LinearLayout r1 = new LinearLayout(c);
        r1.addView(btn("\u25C0", false, new View.OnClickListener() { public void onClick(View v) { cycleReaction(pat, value, -1); } }));
        r1.addView(btn("\u25B6", false, new View.OnClickListener() { public void onClick(View v) { cycleReaction(pat, value, 1); } }));
        r1.addView(btn("ESCOLHER", true, new View.OnClickListener() { public void onClick(View v) { pickReaction(pat, value); } }));
        col.addView(r1);
        LinearLayout r2 = new LinearLayout(c);
        r2.addView(btn(op.fromChar ? "EDITAR PASSOS" : "VER PASSOS", false, new View.OnClickListener() { public void onClick(View v) {
            if (!op.valid) return;
            new ReactionEditor(c, view, op.index, new Runnable() { public void run() { onChanged.run(); } }).show();
        } }));
        r2.addView(btn("efeito/som", false, new View.OnClickListener() { public void onClick(View v) {
            new android.app.AlertDialog.Builder(c).setTitle("Efeito, som e empurrao").setItems(GROUPS, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface dlg, int which) {
                    applyReaction(pat, which * 50 + (value >= 0 ? value % 50 : 0));
                }
            }).show();
        } }));
        col.addView(r2);
        if (op.valid && !op.fromChar) note("Tabelas do jogo (gamedata) sao fixas: nao podem ser editadas.");
    }

    private void applyReaction(int pat, int value) {
        Ano a = cur();
        if (a == null) return;
        view.changeMpt(pat, ObjModel.setOptField(a.mpts[pat], 1, value));
        show(type, idx, flag, occ);
        onChanged.run();
    }

    private void cycleReaction(int pat, int value, int dir) {
        int group = Math.max(0, Math.min(4, value / 50)), idx2 = value >= 0 ? value % 50 : 0;
        for (int k = 0; k < 50; k++) {
            idx2 = (idx2 + dir + 50) % 50;
            if (view.hasReaction(idx2)) break;
        }
        applyReaction(pat, group * 50 + idx2);
    }

    private void pickReaction(final int pat, final int value) {
        final int group = Math.max(0, Math.min(4, value / 50));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        LinearLayout row = null;
        int n = 0;
        for (int i = 0; i < 50; i++) {
            if (!view.hasReaction(i)) continue;
            if (n % 3 == 0) { row = new LinearLayout(c); col.addView(row); }
            n++;
            final int index = i;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(2), dp(2), dp(4));
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == value % 50 ? 0xFF1E3A66 : 0x00000000);
            g.setCornerRadius(dp(6));
            cell.setBackground(g);
            ReactionPreview rp = new ReactionPreview(c, view);
            rp.setValue(group * 50 + i);
            cell.addView(rp, new LinearLayout.LayoutParams(dp(92), dp(92)));
            TextView lab = new TextView(c);
            lab.setText(i < 30 ? "jogo " + i : "personagem " + (i - 30));
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            lab.setTextColor(LayoutManager.DIM);
            lab.setGravity(Gravity.CENTER);
            cell.addView(lab);
            cell.setClickable(true);
            cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                dlg[0].dismiss();
                applyReaction(pat, group * 50 + index);
            } });
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        ScrollView sv = new ScrollView(c);
        sv.addView(col);
        dlg[0] = new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Escolher reacao").setView(sv).setNegativeButton("FECHAR", null).create();
        dlg[0].show();
        styleDialog(dlg[0]);
    }

    private Setter optSetter(final int pat, final int field) {
        return new Setter() { public void set(double v) {
            Ano a = cur();
            if (a == null) return;
            view.changeMpt(pat, ObjModel.setOptField(a.mpts[pat], field, (int) v));
            onChanged.run();
        } };
    }

    private View.OnClickListener convert(final ObjModel.Obj o, final int newFlag) {
        return new View.OnClickListener() { public void onClick(View v) {
            if (o.flag == newFlag) return;
            view.replaceMpts(ObjModel.setFlag(cur().mpts, o, newFlag));
            int nocc = ObjModel.count(cur().mpts[o.f0], newFlag) - 1;
            flag = newFlag;
            occ = Math.max(0, nocc);
            tl.select(TimelineView.T_OBJ, -1, flag, occ);
            refresh();
        } };
    }

    // ---- projetil ----

    /** A ANO e uma animacao de projetil do golpe (principal, +1/+2, reacoes ou sub-projetil)? Ai o hit flag 0 gera sub-projetil. */
    private static boolean isProjectileAno(int ano, CharData.Move mv) {
        int[] base = {mv.projNormal, mv.projAbaixo, mv.projAcima};
        for (int b : base) if (b > 0 && ano >= b && ano <= b + 2) return true;
        int[] other = {mv.projAoAcertar, mv.projChao, mv.projGlobal, mv.subId, mv.subAoAcertar, mv.subChao};
        for (int o2 : other) if (o2 > 0 && o2 == ano) return true;
        return false;
    }

    private void projectile(Ano a, final ObjModel.Obj o, int pat) {
        final CharData.Move mv = view.moveData();
        if (mv == null) return;
        if (mv.generic) {
            note("No modo ANO o projetil nao tem golpe associado. Volte ao modo golpe para escolher a animacao, a perseguicao e a velocidade.");
            return;
        }
        head("Projetil lancado neste ponto");
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        // jogo (md 969): projetil principal nasce em x do atacante + x do hit; se cair ATRAS do atacante, vai para 480 px a frente.
        // Sub-projeteis (hit flag 0 numa ANO de projetil) nao tem essa regra; com ATK_FLAGS 32/64 o x/y do hit e ignorado.
        final boolean mainSpawn = !isProjectileAno(a.index, mv) && (mv.flags & (32 | 64)) == 0;
        if (mainSpawn) {
            num(line(), "x", h.x, 1, new Setter() { public void set(double v) {
                if (v < 0) { v = 0; android.widget.Toast.makeText(c, "x mínimo 0: atrás do atacante o jogo joga o projétil 480 px à frente", android.widget.Toast.LENGTH_SHORT).show(); }
                editCoords(o, pat, 0, (int) v);
            } });
            note("x fica entre 0 e à frente do atacante: com x negativo (atrás dele) o jogo lança o projétil a 480 px de distância.");
        } else {
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            if ((mv.flags & (32 | 64)) != 0) note("Com as flags de nascer no oponente (32/64) o x/y deste ponto é ignorado.");
        }
        num(line(), "y", h.y, 1, coord(o, pat, 1));
        note("y: se o projétil ficar abaixo do chão o jogo o puxa para o chão a cada tick.");
        line().addView(btn("🌿 RAMIFICAÇÃO DO PROJÉTIL", true, new View.OnClickListener() { public void onClick(View v) {
            if (c instanceof android.app.Activity) ProjectileTree.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { onChanged.run(); } });
        } }));
        note("Mostra o caminho completo: ANIM_INICIAL → projétil (+ANO+1/+2 com 3 projéteis) → reações (acerto, chão, global) → sub-projétil.");
        head("Animacao do projetil");
        num(line(), "ANO", mv.projNormal, 1, new Setter() { public void set(final double v) {
            view.editMove(new Runnable() { public void run() { mv.projNormal = Math.max(0, Math.min(4095, (int) v)); } });
            show(type, idx, flag, occ);
            onChanged.run();
        } });
        final Ano pa = view.anoAt(mv.projNormal);
        if (pa != null && pa.present) {
            AnimPreview pv = new AnimPreview(c);
            pv.set(view.packDac(2), view.packSprites(2), mv.projNormal);
            LinearLayout l = line();
            l.addView(pv, new LinearLayout.LayoutParams(dp(84), dp(84)));
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            l.addView(col, new LinearLayout.LayoutParams(-2, -2));
            col.addView(btn("✎ EDITAR ANIMACAO", true, new View.OnClickListener() { public void onClick(View v) {
                if (nav != null) nav.openAno(mv.projNormal, true);
            } }));
            col.addView(btn("trocar ANO", false, new View.OnClickListener() { public void onClick(View v) { pickProjectile(mv); } }));
        } else {
            note("Esta ANO esta vazia ou nao existe.");
            line().addView(btn("escolher ANO de projetil", true, new View.OnClickListener() { public void onClick(View v) { pickProjectile(mv); } }));
        }
        head("Comportamento");
        final boolean homing = mv.homing == 0;
        line().addView(btn(homing ? "● persegue o oponente" : "○ persegue o oponente", homing, new View.OnClickListener() { public void onClick(View v) {
            view.editMove(new Runnable() { public void run() { mv.homing = homing ? 1 : 0; } });
            show(type, idx, flag, occ);
            onChanged.run();
        } }));
        if (homing) {
            num(line(), "veloc. giro", mv.homingSpeed, 1, new Setter() { public void set(final double v) {
                view.editMove(new Runnable() { public void run() { mv.homingSpeed = (int) v; } });
                onChanged.run();
            } });
        }
        if (pa != null && pa.present && pa.mpts.length > 0) {
            Ano.Mpt f0 = pa.mpts[0];
            double sp = (f0.flags & 4) != 0 && (f0.moveMask & 1) != 0 ? f0.speedX / 65536.0 : 0;
            final int anoIdx = pa.index;
            num(line(), "velocidade", sp, 1, new Setter() { public void set(final double v) {
                Ano cp = view.anoAt(anoIdx);
                if (cp == null) return;
                Ano.Mpt[] n = cp.mpts.clone();
                Ano.Mpt m0 = n[0].copy();
                m0.flags |= 4;
                m0.moveMask |= 1;
                m0.speedX = (int) (v * 65536.0);
                m0.normalize();
                n[0] = m0;
                view.replaceAnoAt(new Ano(cp.index, true, cp.flags, cp.priority, cp.links, n));
                onChanged.run();
            } });
            note("Velocidade horizontal inicial (px/tick) do primeiro sprite do projetil.");
        }
        head("Outras animacoes do projetil");
        projField("ao acertar", mv, 0);
        projField("no chao", mv, 1);
        projField("abaixo", mv, 2);
        projField("acima", mv, 3);
        projField("global", mv, 4);
        projField("sub-proj.", mv, 5);
        projField("sub ao acertar", mv, 6);
        projField("sub no chao", mv, 7);
        projField("repeticoes", mv, 8);
        projSeqBlock(mv);
        if (focusOn) scrollBodyToEnd();
    }

    /** SEQ_PROJETIL (ANIM_AO_ACERTAR do BIN): fim do menu do projetil. */
    private void projSeqBlock(final CharData.Move mv) {
        head("Sequência do projétil (SEQ_PROJETIL)");
        note("SEQ_PROJETIL: " + anoText(mv.animAoAcertar));
        note("Quando o primeiro acerto de cada projétil conecta, o atacante troca para esta ANO (vale para o golpe todo). A SEQ vem logo depois, a não ser que o primeiro frame desta ANO tenha uma hitbox flag 38. Máximo " + CharData.Move.MAX + ".");
        LinearLayout r = line();
        final boolean any = mv.animAoAcertar != 0;
        r.addView(btn(any ? "✎ Editar SEQ_PROJETIL" : "+ SEQ_PROJETIL", true, new View.OnClickListener() { public void onClick(View v) { projSeqDialog(mv); } }));
        r.addView(btn("⇢ VER FLUXO", false, new View.OnClickListener() {
            public void onClick(View v) { if (c instanceof android.app.Activity) FlowDialog.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { show(type, idx, flag, occ); onChanged.run(); } }); }
        }));
    }

    private void projSeqDialog(final CharData.Move mv) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(8), dp(16), dp(4));
        TextView info = new TextView(c);
        info.setText("Para qual ANO o atacante vai quando o projétil acerta (0 = nenhuma). Máximo " + CharData.Move.MAX + ".");
        info.setTextColor(LayoutManager.DIM);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        col.addView(info);
        final android.widget.EditText e = ano255(mv.animAoAcertar);
        col.addView(tvLabel("SEQ_PROJETIL"));
        col.addView(e);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("SEQ_PROJETIL").setView(col)
                .setNegativeButton("CANCELAR", null).setPositiveButton("SALVAR", null).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button pos = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
        if (pos != null) {
            pos.setTextColor(LayoutManager.ACCENT);
            pos.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                final int val = parse255(e);
                dlg.dismiss();
                view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move m) { m.animAoAcertar = val; } });
                show(type, idx, flag, occ);
                onChanged.run();
            } });
        }
    }

    private void projField(String name, final CharData.Move mv, final int f) {
        int v;
        switch (f) {
            case 0: v = mv.projAoAcertar; break;
            case 1: v = mv.projChao; break;
            case 2: v = mv.projAbaixo; break;
            case 3: v = mv.projAcima; break;
            case 4: v = mv.projGlobal; break;
            case 5: v = mv.subId; break;
            case 6: v = mv.subAoAcertar; break;
            case 7: v = mv.subChao; break;
            default: v = mv.maxRep; break;
        }
        num(line(), name, v, 1, new Setter() { public void set(final double x) {
            view.editMove(new Runnable() { public void run() {
                int iv = (int) x;
                switch (f) {
                    case 0: mv.projAoAcertar = iv; break;
                    case 1: mv.projChao = iv; break;
                    case 2: mv.projAbaixo = iv; break;
                    case 3: mv.projAcima = iv; break;
                    case 4: mv.projGlobal = iv; break;
                    case 5: mv.subId = iv; break;
                    case 6: mv.subAoAcertar = iv; break;
                    case 7: mv.subChao = iv; break;
                    default: mv.maxRep = iv; break;
                }
            } });
            onChanged.run();
        } });
    }

    /** Lista de ANOs do personagem com a previa animada de cada uma. */
    private void pickProjectile(final CharData.Move mv) {
        final Dac dac = view.packDac(2);
        if (dac == null) return;
        final int[] chosen = {-1};
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        LinearLayout grid = animGrid(dac, view.packSprites(2), 0, dac.size() - 1, "ANO ", mv.projNormal, new AnimPick() { public void on(int ano) {
            chosen[0] = ano;
            dlg[0].dismiss();
            view.editMove(new Runnable() { public void run() { mv.projNormal = chosen[0]; } });
            show(type, idx, flag, occ);
            onChanged.run();
        } });
        dlg[0] = dialog("Animacao do projetil", grid);
    }

    // ---- efeitos ----

    private interface AnimPick { void on(int ano); }

    private android.app.AlertDialog dialog(String title, View content) {
        ScrollView sv = new ScrollView(c);
        sv.addView(content);
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title).setView(sv).setNegativeButton("FECHAR", null).create();
        dlg.show();
        styleDialog(dlg);
        return dlg;
    }

    /** Mesmas cores do resto do app (fundo do painel, botao de destaque). */
    private void styleDialog(android.app.AlertDialog dlg) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        dlg.getWindow().setBackgroundDrawable(bg);
        android.widget.Button b = dlg.getButton(android.app.AlertDialog.BUTTON_NEGATIVE);
        if (b != null) b.setTextColor(LayoutManager.ACCENT);
        int tid = c.getResources().getIdentifier("alertTitle", "id", "android");
        View tv = tid == 0 ? null : dlg.findViewById(tid);
        if (tv instanceof TextView) ((TextView) tv).setTextColor(LayoutManager.TEXT);
    }

    /** Grade de previas animadas (4 por linha) das ANOs presentes em [first, last] do DAC. */
    private LinearLayout animGrid(Dac dac, SpriteCache sp, int first, int last, String prefix, int selectedAno, final AnimPick pick) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout row = null;
        int n = 0;
        for (int a = first; a <= last; a++) {
            Ano an = dac.getAno(a);
            if (an == null || !an.present || an.mpts.length == 0) continue;
            if (n % 4 == 0) {
                row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(row);
            }
            n++;
            final int ano = a;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(2), dp(2), dp(4));
            GradientDrawable g = new GradientDrawable();
            g.setColor(a == selectedAno ? 0xFF1E3A66 : 0x00000000);
            g.setCornerRadius(dp(6));
            cell.setBackground(g);
            AnimPreview pv = new AnimPreview(c);
            pv.set(dac, sp, a);
            cell.addView(pv, new LinearLayout.LayoutParams(dp(68), dp(68)));
            TextView lab = new TextView(c);
            lab.setText(prefix + a);
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            lab.setTextColor(LayoutManager.DIM);
            lab.setGravity(Gravity.CENTER);
            cell.addView(lab);
            cell.setClickable(true);
            cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pick.on(ano); } });
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        if (n == 0) {
            TextView none = new TextView(c);
            none.setText("Nenhuma animacao disponivel neste pacote.");
            none.setTextColor(LayoutManager.DIM);
            col.addView(none);
        }
        return col;
    }

    private void effect(Ano a, final ObjModel.Obj o, int pat) {
        final int pack = ObjModel.fxPack(o.flag);
        final int ano = ObjModel.fxAno(o.flag);
        LinearLayout l = line();
        AnimPreview pv = new AnimPreview(c);
        pv.set(view.packDac(pack), view.packSprites(pack), ano);
        l.addView(pv, new LinearLayout.LayoutParams(dp(92), dp(92)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        l.addView(col, new LinearLayout.LayoutParams(-2, -2));
        TextView nm = new TextView(c);
        nm.setText(ObjModel.fxPackName(pack, ano) + " · " + ano);
        nm.setTextColor(LayoutManager.TEXT);
        nm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        nm.setPadding(dp(6), 0, 0, dp(2));
        col.addView(nm);
        col.addView(btn("TROCAR EFEITO", true, new View.OnClickListener() { public void onClick(View v) { pickEffect(o); } }));
        if (pack == 2) col.addView(btn("✎ EDITAR EFEITO", false, new View.OnClickListener() { public void onClick(View v) {
            if (nav != null) nav.openAno(ano, false);
        } }));
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        num(line(), "x", h.x, 1, coord(o, pat, 0));
        num(line(), "y", h.y, 1, coord(o, pat, 1));
        note("O efeito nasce junto com este objeto, na posicao relativa ao personagem, e some quando o objeto termina.");
    }

    private void pickEffect(final ObjModel.Obj o) {
        LinearLayout all = new LinearLayout(c);
        all.setOrientation(LinearLayout.VERTICAL);
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        // grupos: EFFECT, CHARF, auras do personagem (ANO 201..208) e efeitos do personagem (209+)
        int[][] groups = {
            {0, ObjModel.fxAno(ObjModel.FX_GENERAL_FIRST), ObjModel.fxAno(ObjModel.FX_GENERAL_LAST)},
            {1, ObjModel.fxAno(ObjModel.FX_CHARF_FIRST), ObjModel.fxAno(ObjModel.FX_CHARF_LAST)},
            {2, ObjModel.fxAno(ObjModel.FX_CHAR_FIRST), 208},
            {2, 209, ObjModel.fxAno(ObjModel.FX_CHAR_LAST)}};
        for (int gi = 0; gi < groups.length; gi++) {
            final int pk = groups[gi][0];
            int a0 = groups[gi][1], a1 = groups[gi][2];
            TextView h = head(ObjModel.fxPackName(pk, a0));
            body.removeView(h);
            all.addView(h);
            Dac dac = view.packDac(pk);
            if (dac == null) {
                TextView none = new TextView(c);
                none.setText("pacote nao carregado");
                none.setTextColor(LayoutManager.DIM);
                none.setPadding(dp(6), 0, 0, dp(6));
                all.addView(none);
                continue;
            }
            all.addView(animGrid(dac, view.packSprites(pk), a0, a1, "", o.flag >= 0 && ObjModel.fxPack(o.flag) == pk ? ObjModel.fxAno(o.flag) : -1, new AnimPick() { public void on(int ano) {
                dlg[0].dismiss();
                int nf = ObjModel.fxFlag(pk, ano);
                Ano cu = cur();
                if (cu == null) return;
                view.replaceMpts(ObjModel.setFlag(cu.mpts, o, nf));
                int nocc = ObjModel.count(cur().mpts[o.f0], nf) - 1;
                flag = nf;
                occ = Math.max(0, nocc);
                tl.select(TimelineView.T_OBJ, -1, flag, occ);
                refresh();
            } }));
        }
        dlg[0] = dialog("Escolher efeito", all);
    }

    // ---- acoes especiais ----

    private String describe(int f) {
        switch (f) {
            case 3: case 4: case 5: return "Faz o fundo tremer enquanto o objeto existe. Escolha a intensidade.";
            case 20: return "Dispara uma cutscene: a linha EVENTO do HDAT 13 do personagem (ANO, duracao, camera, stun). X/y e o ponto onde a cena nasce (espelhado pelo lado do objeto).";
            case 26: return "O defensor (CPU ou jogador) nao consegue defender enquanto este golpe esta ativo.";
            case 27: return "Enquanto ativo, o golpe nao pode ser cancelado.";
            case 28: return "O dano deste golpe ignora o ataque e a defesa.";
            case 30: case 31: return "Aproxima a camera enquanto o item estiver ativo. Frames = tempo da transicao ate o zoom; a duracao e a do proprio item na timeline.";
            case 32: return "O personagem toma dano proprio (quantidade em DANO do sprite).";
            case 33: return "Marca um estado interno do jogador que o jogo nao le: nao tem efeito.";
            case 34: return "Cura vida do personagem (quantidade em DANO do sprite).";
            case 37: return "Os acertos deste golpe nao contam no combo.";
            case 38: return "Bloqueia a sequencia: impede encadear o proximo golpe.";
            case 39: return "Teleporta o personagem ate o oponente.";
            case 40: return "Puxa o oponente ate o personagem, com deslocamento.";
            case ObjModel.VF_WINDOW: return describeWindow();
            case ObjModel.VF_SCENE: return "Esconde as camadas do cenario (fundo) enquanto este objeto estiver ativo e a camera passa para a prioridade 1 (tela limpa dos golpes especiais). Tambem desliga o impacto na parede dos dois lutadores. A preview do editor nao desenha o cenario.";
            case ObjModel.VF_WALL: return "Impacto na parede: toca o som 6, zera o cancelamento do oponente e cria a poeira de impacto na borda da tela. Precisa ter um ataque que jogue o oponente na parede (o jogo ignora o frame se o personagem nao estiver batendo na parede). Disponivel so nas ANOs de reacao do gamedata com velocidade/aceleracao X.";
            default:
                if (ObjModel.isDust(f)) return "Poeira / fumaca: cria um efeito de fumaca na posicao do personagem (vira para o lado em que ele olha). Escolha o tipo abaixo (1 a 15). Tipos 1-5: pacote bobj ANOs 10-14; 6-7: effect ANOs 78-79; 8-15: effect ANOs 70-77. Cada frame com a flag cria um novo efeito.";
                return "Acao sem nome conhecido.";
        }
    }

    private String describeWindow() {
        AttackData ad = view.attackData();
        switch (ObjModel.windowUseOf(ad == null ? null : ad.move, ad == null ? -1 : ad.moveIndex)) {
            case ObjModel.WIN_GRAB:
                return "Tentar agarrão: nos frames deste objeto, no ANO inicial do golpe, o personagem vai para o lado do oponente (na altura dele) e segue para o ANO seguinte (ANIM_INICIAL + 1), sem esperar o ANO inicial acabar. Com a flag 8 vale mesmo sem acertar; com a 128 só se o oponente estiver em reação de dor deste golpe.";
            case ObjModel.WIN_REPEAT:
                return "O frame com essa função permite repetir o lançamento do projétil. A repetição alterna sempre entre os ANOs 40 e 41."
                        + (ad != null && ad.moveIndex == 3 ? " No golpe 3 (no ar), em teste a repetição só funcionou com a janela maior: estenda este objeto por mais frames." : "");
            case ObjModel.WIN_CONFLICT:
                return "Conflito: este golpe tem agarrão (flag 8/128) e repetição de projétil (MAX_REPETICOES > 0), e os dois usam a mesma janela 512. Escolha um dos dois nas OPÇÕES do golpe.";
            default:
                return "Janela 512 (cancel). Neste golpe nenhuma opção a usa; ela é só preservada.";
        }
    }

    private void action(Ano a, final ObjModel.Obj o, int pat) {
        note(describe(o.flag));
        int f = o.flag;
        if (f == ObjModel.VF_WINDOW) {
            AttackData wd = view.attackData();
            if (wd != null && wd.move != null && ObjModel.windowUseOf(wd.move, wd.moveIndex) == ObjModel.WIN_REPEAT)
                projField("Quantidade máxima de repetições", wd.move, 8);
            return;
        }
        if (f == ObjModel.VF_SCENE || f == ObjModel.VF_WALL) return;
        if (ObjModel.isDust(f)) {
            head("Tipo de poeira");
            LinearLayout row = null;
            for (int t = 1; t <= 15; t++) {
                if ((t - 1) % 5 == 0) row = line();
                row.addView(btn(String.valueOf(t), f == ObjModel.VF_DUST + t, convertAction(o, ObjModel.VF_DUST + t)));
            }
            return;
        }
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        if (f >= 3 && f <= 5) {
            LinearLayout l = line();
            String[] nm = {"leve", "medio", "forte"};
            for (int k = 0; k < 3; k++) l.addView(btn(nm[k], f == 3 + k, convertAction(o, 3 + k)));
        } else if (f == 20) {
            num(line(), "evento", h.width, 1, coord(o, pat, 2));
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
            AttackData ad20 = view.attackData();
            if (ad20 != null && ad20.attacker != null) note(CutsceneInfo.describe(ad20.attacker.data, h.width, h.x, h.y));
        } else if (f == 30 || f == 31) {
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
            num(line(), "zoom %", h.width, 1, coord(o, pat, 2));
            num(line(), "frames", h.height, 1, coord(o, pat, 3));
        } else if (f == 32 || f == 34) {
            num(line(), "quantidade", ObjModel.optField(a.mpts[pat], 0), 1, optSetter(pat, 0));
        } else if (f == 40) {
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
        }
        line().addView(btn("trocar acao", false, new View.OnClickListener() { public void onClick(View v) {
            final String[] names = new String[ObjModel.ACTION_FLAGS.length];
            for (int i = 0; i < names.length; i++) names[i] = ObjModel.actionName(ObjModel.ACTION_FLAGS[i]);
            new android.app.AlertDialog.Builder(c).setTitle("Acao especial").setItems(names, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface dlg, int which) { convertAction(o, ObjModel.ACTION_FLAGS[which]).onClick(null); }
            }).show();
        } }));
    }

    private View.OnClickListener convertAction(final ObjModel.Obj o, final int newFlag) { return convert(o, newFlag); }

    // ---- sequencia ----

    private static int moveField(CharData.Move mv, int kind, boolean air, int which) {
        switch (kind) {
            case SeqMark.SEQ: return air ? mv.animSeqAr : mv.animSeqChao;
            case SeqMark.END: return air ? mv.animEndAr : mv.animEndChao;
            case SeqMark.HIT: return mv.animAoAcertar;
            default: return which == 0 ? mv.pousoErrar : mv.pousoAcertar;
        }
    }

    private static void setMoveField(CharData.Move mv, int kind, boolean air, int which, int x) {
        switch (kind) {
            case SeqMark.SEQ: if (air) mv.animSeqAr = x; else mv.animSeqChao = x; break;
            case SeqMark.END: if (air) mv.animEndAr = x; else mv.animEndChao = x; break;
            case SeqMark.HIT: mv.animAoAcertar = x; break;
            default: if (which == 0) mv.pousoErrar = x; else mv.pousoAcertar = x;
        }
    }

    private void moveNum(String label, final SeqMark m, final int which) {
        num(line(), label, moveField(view.attackData().move, m.kind, m.air, which), 1, new Setter() { public void set(final double v) {
            final int x = Math.max(0, Math.min(CharData.Move.MAX, (int) v));
            view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) { setMoveField(mv, m.kind, m.air, which, x); } });
            show(type, idx, flag, occ);
            onChanged.run();
        } });
    }

    private void seqPanel(final Ano a) {
        java.util.List<SeqMark> ms = view.sequenceMarks();
        if (idx < 0 || idx >= ms.size() || view.attackData() == null) { title.setText("TRANSICAO"); note("Sem marcador aqui."); return; }
        final SeqMark m = ms.get(idx);
        final int kind = m.kind;
        if (m.incoming) {
            title.setText("ENTRADA  ·  " + m.label().substring(2));
            note("Esta ANO foi alcançada no tick " + m.tick + " pela troca " + new String[]{"SEQ", "END", "SEQ_PROJETIL (ao acertar)", "POUSO", "QUEDA"}[kind]
                    + ", vinda da ANO " + m.fromAno + " (frame " + (m.fromPat + 1) + "). A causa está na timeline daquela ANO.");
            final int fa = m.fromAno;
            LinearLayout rl = line();
            rl.addView(btn("✎ IR PARA ANO " + fa, true, new View.OnClickListener() { public void onClick(View v) { if (nav != null) nav.openAno(fa, false); } }));
            return;
        }
        title.setTextColor(TimelineView.markColor(m));
        title.setText(m.title() + "  ·  frame " + (m.pat + 1) + (kind == SeqMark.LAND || kind == SeqMark.FALL ? "" : (m.air ? "  ·  no ar" : "  ·  no chao")) + (m.projectile ? "  ·  projetil" : ""));
        switch (kind) {
            case SeqMark.SEQ: note("Se o hit conectar aqui, o golpe segue para a ANO abaixo (ANIM_SEQ do BIN). Maximo 255."); break;
            case SeqMark.END: note("Hit durante a sequencia: leva a ANO abaixo (ANIM_END do BIN). Maximo 255."); break;
            case SeqMark.HIT: note("SEQ_PROJETIL: o primeiro acerto do projetil troca o atacante para esta ANO (ANIM_AO_ACERTAR do BIN, vale para o golpe todo). Maximo 255."); break;
            case SeqMark.LAND: note("Onde o atacante toca o chao. ANO do pouso ao errar / ao acertar (0 = pouso padrao, ANO 13). Maximo 255."); break;
            default: note("O atacante terminou a animacao no ar e cai: o jogo toca a ANO 89 (fixa, nao editavel)."); break;
        }
        if (m.real) note("Esta troca acontece de fato na simulacao (tick " + m.tick + ").");
        if (m.blocked) note("BLOQUEADA: este frame tem a flag 38, entao a troca nao dispara.");
        if (kind == SeqMark.FALL) return;
        if (kind == SeqMark.LAND) { moveNum("errar", m, 0); moveNum("acertar", m, 1); }
        else moveNum("ANO", m, 0);
        LinearLayout r = line();
        final int pat = m.pat;
        r.addView(btn("✎ EDITAR ANO", true, new View.OnClickListener() { public void onClick(View v) {
            CharData.Move mv = view.attackData().move;
            int t = moveField(mv, kind, m.air, 0);
            if (kind == SeqMark.LAND && t == 0) t = 13;
            if (nav != null && t > 0) nav.openAno(t, false);
        } }));
        if (kind == SeqMark.LAND) {
            r.addView(btn("EDITAR (acertar)", false, new View.OnClickListener() { public void onClick(View v) {
                int t = view.attackData().move.pousoAcertar;
                if (t == 0) t = 13;
                if (nav != null) nav.openAno(t, false);
            } }));
            r.addView(btn("PADRAO (13)", false, new View.OnClickListener() { public void onClick(View v) {
                view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) { mv.pousoErrar = 0; mv.pousoAcertar = 0; } });
                show(type, idx, flag, occ);
                onChanged.run();
            } }));
            return;
        }
        r.addView(btn(m.blocked ? "DESBLOQUEAR SEQUÊNCIA" : "BLOQUEAR SEQUÊNCIA", m.blocked, new View.OnClickListener() { public void onClick(View v) {
            Ano cu = cur();
            if (cu == null || pat >= cu.mpts.length) return;
            Ano.Mpt n = cu.mpts[pat].copy();
            java.util.ArrayList<Ano.Hit> hl = new java.util.ArrayList<Ano.Hit>();
            boolean had = false;
            for (Ano.Hit h : n.hits) { if (h.flag == 38) had = true; else hl.add(h); }
            if (!had) { Ano.Hit h = new Ano.Hit(); h.flag = 38; hl.add(h); n.flags |= 0x10; }
            else if (hl.isEmpty()) n.flags &= ~0x10;
            n.hits = hl.toArray(new Ano.Hit[0]);
            n.normalize();
            view.changeMpt(pat, n);
            show(type, idx, flag, occ);
            onChanged.run();
        } }));
        r.addView(btn("APAGAR", false, new View.OnClickListener() { public void onClick(View v) {
            view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) {
                if (kind == SeqMark.SEQ) { mv.animSeqAr = 0; mv.animSeqChao = 0; }
                else if (kind == SeqMark.END) { mv.animEndAr = 0; mv.animEndChao = 0; }
                else mv.animAoAcertar = 0;
            } });
            onClose.run();
            onChanged.run();
        } }));
    }

    // ---- links (animacao ligada) ----

    private void link(final Ano a) {
        if (idx < 0 || idx >= a.links.length) { note("Esta ANO nao tem animacoes ligadas."); return; }
        final Ano.Link l = a.links[idx];
        note("Uma animacao ligada toca junto com esta, sincronizada.");
        num(line(), "ANO", l.getAno(), 1, linkSetter(a, 2));
        LinearLayout e = line();
        e.addView(btn("✎ EDITAR ANIMACAO", true, new View.OnClickListener() { public void onClick(View v) { if (nav != null) nav.openAno(l.getAno(), false); } }));
        num(line(), "base x", l.baseX, 1, linkSetter(a, 0));
        num(line(), "base y", l.baseY, 1, linkSetter(a, 1));
        LinearLayout r = line();
        r.addView(btn("nao herda a posicao (0,0)", l.spawnPos(), new View.OnClickListener() { public void onClick(View v) { linkFlag(a, 0x1000); } }));
        r.addView(btn("segue o personagem", l.syncXY(), new View.OnClickListener() { public void onClick(View v) { linkFlag(a, 0x4000); } }));
        r.addView(btn("sincroniza sprites", l.syncMpt(), new View.OnClickListener() { public void onClick(View v) { linkFlag(a, 0x8000); } }));
    }

    private Setter linkSetter(final Ano a, final int field) {
        return new Setter() { public void set(double v) {
            Ano.Link[] n = a.links.clone();
            Ano.Link o = n[idx];
            int x = (int) v;
            if (field == 0) n[idx] = new Ano.Link(x, o.baseY, o.flags);
            else if (field == 1) n[idx] = new Ano.Link(o.baseX, x, o.flags);
            else n[idx] = new Ano.Link(o.baseX, o.baseY, (o.flags & ~0xFFF) | (x & 0xFFF));
            applyLinks(a, n, idx);
        } };
    }

    private void linkFlag(Ano a, int bitMask) {
        Ano.Link[] n = a.links.clone();
        Ano.Link o = n[idx];
        n[idx] = new Ano.Link(o.baseX, o.baseY, o.flags ^ bitMask);
        applyLinks(a, n, idx);
    }

    private void applyLinks(Ano a, Ano.Link[] n, int sel) {
        int fl = n.length > 0 ? (a.flags | 2) : (a.flags & ~2);
        view.replaceAno(new Ano(a.index, true, fl, a.priority, n, a.mpts));
        idx = n.length == 0 ? -1 : Math.min(sel, n.length - 1);
        if (idx < 0) { onClose.run(); onChanged.run(); return; }
        show(type, idx, flag, occ);
        onChanged.run();
    }
}
