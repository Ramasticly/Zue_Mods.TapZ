package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** Inspetores abaixo da timeline: sprite, objetos (hitbox, projetil, efeito, acoes) e links, editados em runtime. */
final class TimelineTools {
    private interface Mut { void apply(Ano.Mpt m); }
    private interface Setter { void set(double v); }

    // secoes do inspetor de sprite
    private static final int S_IMG = 0, S_TEMPO = 1, S_MOVER = 2, S_ESTILO = 3, S_SOM = 4, S_ALL = 6;
    private static final int C_SPRITE = 0xFFE5C100;

    private final Context c;
    private final AttackView view;
    private final TimelineView tl;
    private final float d;
    private final Runnable onChanged, onClose;
    Navigator nav;
    final LinearLayout root;
    private final TextView title;
    private final LinearLayout body;
    private int type = TimelineView.T_NONE, idx = -1, flag = -1, occ = -1, section;
    private int lastPat = -1;

    TimelineTools(Context c, AttackView view, TimelineView tl, Runnable onChanged, Runnable onClose) {
        this.c = c;
        this.view = view;
        this.tl = tl;
        this.d = c.getResources().getDisplayMetrics().density;
        this.onChanged = onChanged;
        this.onClose = onClose;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable sheetBg = new GradientDrawable();
        sheetBg.setColor(LayoutManager.BG);
        float rad = dp(14);
        sheetBg.setCornerRadii(new float[]{rad, rad, rad, rad, 0, 0, 0, 0});
        sheetBg.setStroke(dp(1), LayoutManager.PANEL_HI);
        root.setBackground(sheetBg);
        // alca de arrastar ("-"): puxe para cima/baixo para ajustar; arraste rapido para baixo fecha
        FrameLayout hbox = new FrameLayout(c);
        View bar = new View(c);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(LayoutManager.DIM);
        barBg.setCornerRadius(dp(3));
        bar.setBackground(barBg);
        hbox.addView(bar, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        hbox.setOnTouchListener(new View.OnTouchListener() {
            float downY, prevY, vel; long prevT; int startH; boolean moved;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        downY = prevY = e.getRawY(); prevT = e.getEventTime(); vel = 0; moved = false;
                        startH = root.getHeight();
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE: {
                        float y = e.getRawY();
                        long t = e.getEventTime();
                        if (t > prevT) vel = vel * 0.6f + (y - prevY) / (t - prevT) * 1000f * 0.4f;
                        prevY = y; prevT = t;
                        if (Math.abs(y - downY) > dp(4)) moved = true;
                        if (moved) setSheetHeight(startH - (int) (y - downY));
                        return true;
                    }
                    case android.view.MotionEvent.ACTION_UP: {
                        if (!moved) { tapHandle(); return true; }
                        float want = startH - (e.getRawY() - downY);
                        if (vel > 1800f || want < peekH() - dp(50)) { if (onCancel != null) onCancel.run(); }
                        return true;
                    }
                    default: return true;
                }
            }
        });
        // botoes na borda, a direita: Y salva a altura atual como padrao; T poe a timeline acima do menu
        btnY = edgeBtn("Y", new View.OnClickListener() {
            @Override public void onClick(View v) { if (saveH != null) saveH.run(); }
        });
        btnT = edgeBtn("T", new View.OnClickListener() {
            @Override public void onClick(View v) { if (toggleT != null) toggleT.run(); }
        });
        LinearLayout edge = new LinearLayout(c);
        edge.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(dp(30), dp(22));
        elp.setMargins(dp(3), 0, 0, 0);
        edge.addView(btnY, elp);
        edge.addView(btnT, new LinearLayout.LayoutParams(elp));
        FrameLayout.LayoutParams edgeLp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        edgeLp.setMargins(0, 0, dp(8), 0);
        hbox.addView(edge, edgeLp);
        root.addView(hbox, new LinearLayout.LayoutParams(-1, dp(HANDLE_DP)));
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), 0, dp(6), dp(4));
        title = new I18nTextView(c);
        title.setTextColor(LayoutManager.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        // desfazer/refazer DENTRO do menu: do primeiro passo ate o original e de volta; so enxergam o que foi feito neste menu
        btnUndo = btn("\u21B6", false, new View.OnClickListener() {
            @Override public void onClick(View v) { if (TimelineTools.this.view.undoEdit()) refresh(); }
        });
        btnRedo = btn("\u21B7", false, new View.OnClickListener() {
            @Override public void onClick(View v) { if (TimelineTools.this.view.redoEdit()) refresh(); }
        });
        head.addView(btnUndo);
        head.addView(btnRedo);
        head.addView(btn("\u2715", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                // primeiro fecha a pagina aberta (volta a grade); so com a grade na tela fecha o menu de edicao
                if (section != G_GRID && type != TimelineView.T_OBJ && type != TimelineView.T_SEQ && type != TimelineView.T_LINK && type != TimelineView.T_NONE) { backToGrid(); return; }
                if (onCancel != null) onCancel.run();
            }
        }));
        head.addView(btn("APLICAR", true, new View.OnClickListener() {
            @Override public void onClick(View v) { applyAllTab(); if (onApply != null) onApply.run(); }
        }));
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));
        // a gaveta tem altura variavel: o conteudo rola dentro dela
        body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(8), 0, dp(8), dp(24));
        ScrollView bodyScroll = new ScrollView(c);
        bodyScrollRef = bodyScroll;
        bodyScroll.setFillViewport(false);
        bodyScroll.addView(body, new ViewGroup.LayoutParams(-1, -2));
        root.addView(bodyScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.setVisibility(View.GONE);
    }

    // ---- gaveta (bottom sheet) ----

    private View scrollRef;
    private Runnable onApply, onCancel, saveH, toggleT;
    private int sheetH;
    private TextView btnUndo, btnRedo;

    /** Esmaece ↶ ↷ quando nao ha o que desfazer / refazer neste menu. */
    void updateUndoButtons() {
        if (btnUndo == null) return;
        btnUndo.setAlpha(view.canUndo() ? 1f : 0.35f);
        btnRedo.setAlpha(view.canRedo() ? 1f : 0.35f);
    }
    private Geo geo;
    private TextView btnY, btnT;
    private static final int HANDLE_DP = 26;

    /** Limites da gaveta, definidos pelo layout: altura maxima e altura padrao (ao abrir). */
    interface Geo { int maxH(); int defH(); }

    void setGeometry(Geo g, Runnable saveHeight, Runnable toggleTimeline) {
        geo = g;
        saveH = saveHeight;
        toggleT = toggleTimeline;
    }

    /** Realce do botao T (modo timeline acima do menu). */
    void setTOn(boolean on) {
        if (btnT == null) return;
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(6));
        g.setColor(on ? C_BLUE : LayoutManager.PANEL_HI);
        btnT.setBackground(g);
    }

    /** Depois de trocar de modo: se a gaveta esta aberta, volta a altura padrao do modo. */
    void refit() { if (root.getVisibility() == View.VISIBLE && geo != null) setSheetHeight(geo.defH()); }

    private TextView edgeBtn(String t, View.OnClickListener l) {
        TextView b = new I18nTextView(c);
        b.setText(t);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(LayoutManager.TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(6));
        g.setColor(LayoutManager.PANEL_HI);
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    void setSheetHost(View scroll, Runnable apply, Runnable cancel) {
        scrollRef = scroll;
        onApply = apply;
        onCancel = cancel;
    }

    private int peekH() { return dp(HANDLE_DP + 44); }

    private int maxH() {
        if (geo != null) return Math.max(peekH() + dp(60), geo.maxH());
        int avail = (scrollRef == null ? 0 : scrollRef.getHeight()) + (root.getVisibility() == View.VISIBLE ? root.getHeight() : 0);
        return Math.max(peekH() + dp(60), avail - dp(56));
    }

    private int defH() { return geo != null ? geo.defH() : Math.max(dp(220), maxH() / 2); }

    private void setSheetHeight(int h) {
        h = Math.max(peekH(), Math.min(maxH(), h));
        sheetH = h;
        ViewGroup.LayoutParams p = root.getLayoutParams();
        if (p != null && p.height != h) { p.height = h; root.setLayoutParams(p); }
        if (onResize != null) onResize.run();
    }

    /** Fracao 0..1 de quanto a gaveta subiu entre o minimo e o maximo (0 se fechada). */
    float sheetFraction() {
        if (root.getVisibility() != View.VISIBLE) return 0f;
        int lo = peekH(), hi = maxH();
        return hi <= lo ? 0f : Math.max(0f, Math.min(1f, (sheetH - lo) / (float) (hi - lo)));
    }

    private Runnable onResize;
    void setOnSheetResize(Runnable r) { onResize = r; }

    private void tapHandle() {
        int h = root.getHeight(), mx = maxH();
        int df = Math.min(mx, defH());
        if (h <= peekH() + dp(10)) setSheetHeight(df);
        else if (h < mx - dp(20) && h < df - dp(20)) setSheetHeight(df);
        else if (h < mx - dp(20)) setSheetHeight(mx);
        else setSheetHeight(df);
    }

    /** Abre a gaveta; no primeiro acesso guarda o ponto de desfazer (para descartar se nao aplicar). */
    void openSheet() {
        if (!view.inUndoSession()) view.beginUndoSession();          // a partir daqui desfazer/refazer valem so para este menu
        boolean was = root.getVisibility() == View.VISIBLE;
        root.setVisibility(View.VISIBLE);
        if (!was) {
            setSheetHeight(defH());          // sempre abre na altura padrao; arrastar e temporario, o Y torna permanente
        }
    }

    /** Fecha mantendo o que ja foi feito. */
    void hideSheet() {
        view.stopSounds();
        view.commitUndoSession();            // APLICAR: o menu inteiro vira UM passo do desfazer da timeline
        root.setVisibility(View.GONE);
        if (onResize != null) onResize.run();
    }

    /** Mesmo efeito de tocar fora / arrastar para baixo: descarta o que nao foi aplicado e fecha. */
    void cancelSheet() { if (onCancel != null) onCancel.run(); }

    boolean sheetOpen() { return root.getVisibility() == View.VISIBLE; }

    /** Descarta tudo o que foi editado desde que a gaveta abriu; devolve quantos passos desfez. */
    int discardSession() {
        int n = view.discardUndoSession();
        root.setVisibility(View.GONE);
        if (onResize != null) onResize.run();
        onChanged.run();
        return n;
    }

    // ---- util de UI ----

    private int dp(int v) { return Math.round(v * d); }

    private TextView btn(String s, boolean on, View.OnClickListener l) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(on ? Color.WHITE : LayoutManager.TEXT);
        t.setPadding(dp(8), dp(7), dp(8), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? LayoutManager.ACCENT : LayoutManager.PANEL);
        g.setCornerRadius(dp(7));
        t.setBackground(g);
        t.setClickable(true);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        t.setLayoutParams(p);
        return t;
    }

    private LinearLayout line() {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(l, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    private TextView note(String s) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.DIM);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        body.addView(t);
        return t;
    }

    private static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e9) return String.valueOf((long) v);
        String s = String.format(Locale.US, "%.3f", v);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s;
    }

    /** Linha "nome  [-] valor [+]" com campo digitavel (aplica ao confirmar ou ao sair do campo). */
    private void num(LinearLayout parent, String name, double value, final double step, final Setter set) {
        TextView lab = new I18nTextView(c);
        lab.setText(name);
        lab.setTextColor(LayoutManager.DIM);
        lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        parent.addView(lab, new LinearLayout.LayoutParams(dp(58), -2));
        final EditText et = new EditText(c);
        et.setText(fmt(value));
        et.setTextColor(LayoutManager.TEXT);
        et.setTypeface(Typeface.MONOSPACE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        et.setSingleLine(true);
        et.setGravity(Gravity.CENTER);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.setPadding(dp(4), dp(4), dp(4), dp(4));
        final double[] cur = {value};
        final Runnable commit = new Runnable() {
            @Override public void run() {
                double v;
                try { v = Double.parseDouble(et.getText().toString().trim()); } catch (NumberFormatException e) { et.setText(fmt(cur[0])); return; }
                if (v == cur[0]) return;
                cur[0] = v;
                set.set(v);
            }
        };
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent k) { commit.run(); return false; }
        });
        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) { if (!has) commit.run(); }
        });
        TextView bMinus = btn("−", false, null);
        Hold.attach(bMinus, new Runnable() { @Override public void run() {
            cur[0] -= step;
            et.setText(fmt(cur[0]));
            set.set(cur[0]);
        } });
        parent.addView(bMinus);
        parent.addView(et, new LinearLayout.LayoutParams(dp(78), -2));
        TextView bPlus = btn("+", false, null);
        Hold.attach(bPlus, new Runnable() { @Override public void run() {
            cur[0] += step;
            et.setText(fmt(cur[0]));
            set.set(cur[0]);
        } });
        parent.addView(bPlus);
    }

    // ---- estado / ciclo ----

    void refresh() {
        show(type, idx, flag, occ);
        onChanged.run();
    }

    /** O ponteiro mudou de sprite: o inspetor acompanha (so quando nao esta tocando). */
    /** Tocou numa sprite da timeline: abre a grade de opcoes (as paginas de velocidade, som e estilo abrem direto pelos itens delas). */
    void gridFirst() { section = G_GRID; }

    /** Abre a gaveta direto na pagina Imagem do sprite (Adicionar Sprite). */
    void imageFirst() { section = S_IMG; }

    void follow(int pat, boolean playing) {
        if (pat == lastPat) return;
        lastPat = pat;
        if (pat < 0) return;                       // sem simulacao / sem frame: nao ha o que seguir
        if (playing || type == TimelineView.T_NONE || type == TimelineView.T_LINK || type == TimelineView.T_SEQ || root.getVisibility() != View.VISIBLE) return;
        if (type == TimelineView.T_OBJ) {
            if (isBoxFlag(flag)) {            // hitbox/hurtbox: so muda se o novo frame tem esta box; senao fica como esta
                Ano fo = cur();
                if (fo == null || ObjModel.find(ObjModel.objects(fo.mpts), flag, occ, pat) == null) return;
            }
            show(type, idx, flag, occ);
            return;
        }
        int ni = pat;
        Ano fa = cur();
        int sel = ni;
        if (type == TimelineView.T_MOVE && fa != null) {
            int h = FrameOps.moveHeadOf(fa.mpts, pat);
            if (h >= 0) sel = h;
        }
        show(type, ni, flag, occ);
        tl.select(type, sel, flag, occ);
    }

    private Ano cur() { return view.currentAno(); }

    private Ano.Mpt sprite() {
        Ano a = cur();
        if (a == null || idx < 0 || idx >= a.mpts.length) return null;
        return a.mpts[idx];
    }

    private void edit(Mut mu) {
        Ano.Mpt m = sprite();
        if (m == null) return;
        Ano.Mpt n = m.copy();
        mu.apply(n);
        n.normalize();
        view.changeMpt(idx, n);
        onChanged.run();
    }

    private void editAndRebuild(Mut mu) {
        edit(mu);
        show(type, idx, flag, occ);
    }

    private static void bit(Ano.Mpt m, int b, boolean on) { if (on) m.flags |= b; else m.flags &= ~b; }

    /** Como replaceMpts, mas para edicoes grandes: recalcula a animacao em segundo plano com a janela de progresso. */
    private void replaceMptsBusy(final Ano.Mpt[] mp, final int newIdx, String title, final Runnable after) {
        final Ano a = cur();
        if (a == null) return;
        if (!(c instanceof android.app.Activity)) { replaceMpts(mp, newIdx); if (after != null) after.run(); return; }
        final BusyDialog busy = BusyDialog.show((android.app.Activity) c, title);
        busy.set("Recalculando a animacao...", 0, 0);
        view.replaceAnoAsync(new Ano(a.index, true, a.flags, a.priority, a.links, mp), new Runnable() {
            @Override public void run() {
                busy.set("Atualizando a linha do tempo...", 0, 0);
                idx = Math.max(0, Math.min(mp.length - 1, newIdx));
                view.seekToPatKeep(idx);
                show(type, idx, flag, occ);
                onChanged.run();
                if (after != null) after.run();
                busy.dismiss();
            }
        });
    }

    private void replaceMpts(Ano.Mpt[] mp, int newIdx) {
        Ano a = cur();
        if (a == null) return;
        view.replaceAno(new Ano(a.index, true, a.flags, a.priority, a.links, mp));
        idx = Math.max(0, Math.min(mp.length - 1, newIdx));
        view.seekToPatKeep(idx);
        show(type, idx, flag, occ);
        onChanged.run();
    }

    private TextView head(String s) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setPadding(dp(4), dp(6), dp(4), dp(1));
        body.addView(t);
        return t;
    }

    void show(int ty, int i, int fl, int oc) {
        if (ty != TimelineView.T_OBJ || type != TimelineView.T_OBJ || fl != flag || oc != occ) boxPat = -1;
        type = ty;
        idx = i;
        flag = fl;
        occ = oc;
        // sem sprite selecionada (objeto, link, transicao, nada) nenhuma pagina de sprite continua "viva": o APLICAR da pagina Copiar
        // chegou a agir com idx == -1 (ArrayIndexOutOfBounds em FrameOps.applyAll)
        if (ty == TimelineView.T_OBJ || ty == TimelineView.T_LINK || ty == TimelineView.T_SEQ || ty == TimelineView.T_NONE) section = G_GRID;
        stopSoundCard();
        updateUndoButtons();
        body.removeAllViews();
        if (ty == TimelineView.T_NONE) return;
        Ano a = cur();
        if (a == null) return;
        lastPat = view.currentPat();
        if (!(ty == TimelineView.T_OBJ && focusOn && fl == focusFlag && oc == focusOcc)) focusOn = false;
        if (ty == TimelineView.T_OBJ) { object(a); return; }
        if (ty == TimelineView.T_SEQ && openSeqAsHitbox(a, i)) return;
        if (ty == TimelineView.T_SEQ) { title.setTextColor(0xFFFF5D8F); seqPanel(a); return; }
        if (ty == TimelineView.T_LINK) { title.setTextColor(0xFF2EC4C4); title.setText("ANIMACAO LIGADA  ·  " + (i + 1) + "/" + a.links.length); link(a); return; }
        if (ty == TimelineView.T_MOVE) section = S_MOVER;
        else if (ty == TimelineView.T_STYLE) section = S_ESTILO;
        else if (ty == TimelineView.T_SOUND) section = S_SOM;
        else if (section == S_MOVER || section == S_ESTILO || section == S_SOM) section = G_GRID;
        if (idx < 0 || idx >= a.mpts.length) return;
        title.setTextColor(C_SPRITE);
        title.setText("SPRITE " + (idx + 1) + "/" + a.mpts.length + "  ·  " + ObjModel.seconds(FrameOps.span(a.mpts[idx])));
        sprite(a);
    }

    // ---- sprite ----

    // ---- gaveta da sprite: grade de botoes + paginas (Imagem, Tempo, Som, Movimento, Efeitos, Copiar) ----

    private static final int G_GRID = -1;
    private static final int C_GREEN = 0xFF3DDC84, C_RED = 0xFFE5484D, C_GRAY = 0xFFA0A4AC, C_BLUE = 0xFF4C8DFF, C_AMBER = 0xFFFFB454, C_RECV = 0xFFFFD84C;
    private SoundDialog soundCard;

    private void sprite(final Ano a) {
        if (section != S_IMG && section != S_TEMPO && section != S_MOVER && section != S_ESTILO && section != S_SOM && section != S_ALL) section = G_GRID;
        switch (section) {
            case S_IMG: pgImagem(a); break;
            case S_TEMPO: pgTempo(a); break;
            case S_SOM: pgSom(a); break;
            case S_MOVER: pgMover(a); break;
            case S_ESTILO: pgEfeitos(a); break;
            case S_ALL: pageHead("Copiar", C_BLUE); secAll(a); break;
            default: grid(a); break;
        }
    }

    private void stopSoundCard() {
        if (soundCard != null) { soundCard.stop(); soundCard = null; }
    }

    private View tile(String name, int kind, int color, View.OnClickListener l) {
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL);
        g.setCornerRadius(dp(12));
        t.setBackground(g);
        t.addView(new IconView(c, kind, color), new LinearLayout.LayoutParams(dp(38), dp(38)));
        TextView n = new I18nTextView(c);
        n.setText(name);
        n.setTextColor(LayoutManager.TEXT);
        n.setTypeface(Typeface.DEFAULT_BOLD);
        n.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(4), 0, 0);
        t.addView(n);
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private void grid(Ano a) {
        String[] names = {"Imagem", "Tempo", "Som", "Movimento", "Efeitos", "Copiar"};
        int[] kinds = {IconView.IMAGE, IconView.CLOCK, IconView.SOUND, IconView.MOVE, IconView.FX, IconView.COPY};
        int[] cols = {C_SPRITE, C_GREEN, C_RED, C_GREEN, C_GRAY, C_BLUE};
        final int[] pages = {S_IMG, S_TEMPO, S_SOM, S_MOVER, S_ESTILO, S_ALL};
        for (int r = 0; r < 2; r++) {
            LinearLayout row = line();
            for (int k = 0; k < 3; k++) {
                final int pg = pages[r * 3 + k];
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(84), 1f);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(tile(names[r * 3 + k], kinds[r * 3 + k], cols[r * 3 + k], new View.OnClickListener() {
                    public void onClick(View v) { openPage(pg); }
                }), lp);
            }
        }
        note("Frame " + (idx + 1) + " de " + a.mpts.length + ". Toque numa opção para editar.");
    }

    private void openPage(int pg) {
        section = pg;
        type = pg == S_MOVER ? TimelineView.T_MOVE : pg == S_ESTILO ? TimelineView.T_STYLE : pg == S_SOM ? TimelineView.T_SOUND : TimelineView.T_SPRITE;
        tl.select(type, idx, -1, -1);
        show(type, idx, -1, -1);
    }

    private void backToGrid() {
        section = G_GRID;
        type = TimelineView.T_SPRITE;
        tl.select(type, idx, -1, -1);
        show(type, idx, -1, -1);
    }

    private void pageHead(String name, int color) {
        LinearLayout h = line();
        h.addView(btn("◀", false, new View.OnClickListener() { public void onClick(View v) { backToGrid(); } }));
        TextView t = new I18nTextView(c);
        t.setText(name);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setPadding(dp(8), 0, 0, 0);
        h.addView(t);
    }

    private TextView lab(String s) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.DIM);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setPadding(dp(6), dp(8), dp(6), 0);
        body.addView(t);
        return t;
    }

    private void put(Stepper st) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(2), dp(4), dp(2));
        body.addView(st.view(), lp);
    }

    private android.widget.CheckBox check(String text, boolean on, android.widget.CompoundButton.OnCheckedChangeListener l) {
        android.widget.CheckBox cb = new I18nCheckBox(c);
        cb.setText(text);
        cb.setTextColor(LayoutManager.TEXT);
        cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        cb.setChecked(on);
        cb.setOnCheckedChangeListener(l);
        body.addView(cb);
        return cb;
    }

    private TextView wide(String s, int color, View.OnClickListener l) {
        TextView t = btn(s, false, l);
        t.setTextColor(color);
        t.setPadding(dp(8), dp(11), dp(8), dp(11));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(4), dp(10), dp(4), dp(2));
        t.setLayoutParams(lp);
        body.addView(t);
        return t;
    }

    private void editMid(final Mut mu) {
        edit(new Mut() { public void apply(Ano.Mpt n) {
            if ((n.flags & 1) == 0) { n.flags |= 1; n.midX = 0; n.midY = 0; }
            mu.apply(n);
        } });
    }

    private void editRaz(final Mut mu) {
        edit(new Mut() { public void apply(Ano.Mpt n) {
            if ((n.flags & 0x80) == 0) { n.flags |= 0x80; n.rot = 0; n.alphaRaw = 0; n.xZoom = 100; n.yZoom = 100; }
            mu.apply(n);
        } });
    }

    // ---- Imagem ----

    private static boolean unirZoom = true, moveLinks = false;

    private void pgImagem(final Ano a) {
        pageHead("Imagem", C_SPRITE);
        Ano.Mpt m = sprite();
        AttackData ad = view.attackData();
        final SpriteCache sc = ad == null ? null : ad.attacker.sprites;
        int maxImg = ad != null && ad.attacker.cnv != null ? Math.max(0, ad.attacker.cnv.size() - 1) : 9999;
        final ThumbView thumb = new ThumbView(c);
        thumb.set(sc, m.image);
        // prévia 1:1 com 30% da largura da tela; o − N + fica na frente dela: x = 65% da largura, centro na altura da prévia (y + h/2)
        int screenW = c.getResources().getDisplayMetrics().widthPixels;
        int side = Math.round(screenW * 0.30f);
        android.widget.FrameLayout strip = new android.widget.FrameLayout(c);
        android.widget.FrameLayout.LayoutParams tp = new android.widget.FrameLayout.LayoutParams(side, side, Gravity.START | Gravity.TOP);
        strip.addView(thumb, tp);
        Stepper imgStep = new Stepper(c).range(-1, maxImg).step(1).tap(new Runnable() { public void run() { chooseImage(); } })
                .onChange(new Stepper.OnValue() { public void on(final double v) {
                    edit(new Mut() { public void apply(Ano.Mpt n) { n.image = (int) v; } });
                    thumb.set(sc, (int) v);
                    refreshTitle();
                } }).value(m.image);
        View stepView = imgStep.view();
        stepView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int bodyPad = dp(8);                                          // a gaveta tem 8dp de margem nos dois lados
        int x = Math.round(screenW * 0.65f) - bodyPad;
        x = Math.min(x, screenW - 2 * bodyPad - stepView.getMeasuredWidth() - dp(4));      // tela estreita: nao deixa o − N + passar da borda
        x = Math.max(x, side + dp(6));
        android.widget.FrameLayout.LayoutParams sp = new android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL);
        sp.leftMargin = x;
        strip.addView(stepView, sp);
        LinearLayout.LayoutParams stripLp = new LinearLayout.LayoutParams(-1, side);
        stripLp.setMargins(0, dp(6), 0, dp(4));
        body.addView(strip, stripLp);
        note("Segure − ou + para percorrer as sprites; toque no número para escolher na grade de sprites.");

        lab("POSIÇÃO");
        LinearLayout pos = line();
        pos.addView(axisLabel("x"));
        stepIn(pos, new Stepper(c).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            final int old = sprite().midX;
            editMid(new Mut() { public void apply(Ano.Mpt n) { n.midX = (int) v; } });
            if (moveLinks) shiftLinkBases((int) v - old, 0);
        } }).value(m.midX));
        pos.addView(axisLabel("y"));
        stepIn(pos, new Stepper(c).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            final int old = sprite().midY;
            editMid(new Mut() { public void apply(Ano.Mpt n) { n.midY = (int) v; } });
            if (moveLinks) shiftLinkBases(0, (int) v - old);
        } }).value(m.midY));
        note("Posição do centro da sprite neste frame (x e y).");
        if (a.links.length > 0) {
            check("mover links junto", moveLinks, new android.widget.CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { moveLinks = on; }
            });
            note("Ao mudar a posição, soma o mesmo deslocamento no bx/by de todos os links desta ANO (vale para todos os frames dela).");
            wide("EDITAR POSIÇÃO DO LINK", C_BLUE, new View.OnClickListener() { public void onClick(View v) { openLinkEditor(); } });
        }

        lab("ZOOM");
        check("unir zoom X e Y", unirZoom, new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) { unirZoom = on; show(type, idx, flag, occ); }
        });
        if (unirZoom) {
            put(new Stepper(c).range(0, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
                editRaz(new Mut() { public void apply(Ano.Mpt n) { n.xZoom = (int) v; n.yZoom = (int) v; } });
            } }).value(m.xZoom));
        } else {
            LinearLayout z = line();
            z.addView(axisLabel("x"));
            stepIn(z, new Stepper(c).range(0, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
                editRaz(new Mut() { public void apply(Ano.Mpt n) { n.xZoom = (int) v; } });
            } }).value(m.xZoom));
            z.addView(axisLabel("y"));
            stepIn(z, new Stepper(c).range(0, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
                editRaz(new Mut() { public void apply(Ano.Mpt n) { n.yZoom = (int) v; } });
            } }).value(m.yZoom));
        }
        note("100 = tamanho normal.");

        lab("ROTAÇÃO (graus)");
        put(new Stepper(c).range(-3600, 3600).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editRaz(new Mut() { public void apply(Ano.Mpt n) { n.rot = (int) v; } });
        } }).value(m.rot));
        note("Em graus.");
        lab("ALPHA");
        put(new Stepper(c).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editRaz(new Mut() { public void apply(Ano.Mpt n) { n.alphaRaw = (int) v; } });
        } }).value(m.alphaRaw));
        note("0 = opaco; 256 = aditivo; 512 = outro modo; +n = n/255 mais transparente.");

        wide("REMOVER IMAGEM", C_RED, new View.OnClickListener() { public void onClick(View v) {
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { n.image = -1; } });
            refreshTitle();
        } });
    }

    private TextView axisLabel(String s) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.DIM);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setPadding(dp(6), 0, dp(2), 0);
        return t;
    }

    /** Stepper dentro de uma linha dividida (metade da largura). */
    private void stepIn(LinearLayout row, Stepper st) {
        row.addView(st.view(), new LinearLayout.LayoutParams(-2, -2));
    }

    /** Soma (dx, dy) no bx/by de todos os links da ANO atual. */
    private void shiftLinkBases(int dx, int dy) {
        Ano a = cur();
        if (a == null || a.links.length == 0 || (dx == 0 && dy == 0)) return;
        Ano.Link[] n = new Ano.Link[a.links.length];
        for (int i = 0; i < n.length; i++) n[i] = new Ano.Link(a.links[i].baseX + dx, a.links[i].baseY + dy, a.links[i].flags);
        view.replaceAno(new Ano(a.index, true, a.flags, a.priority, n, a.mpts));
        onChanged.run();
    }

    private void openLinkEditor() {
        Ano a = cur();
        if (a == null || a.links.length == 0 || !(c instanceof android.app.Activity)) return;
        LinkPosDialog.show((android.app.Activity) c, view, a.index, Math.max(0, idx), new Runnable() { public void run() { onChanged.run(); show(type, idx, flag, occ); } });
    }

    // ---- Tempo ----

    private void pgTempo(final Ano a) {
        pageHead("Tempo", C_GREEN);
        Ano.Mpt m = sprite();
        lab("ticks do frame (60 ticks = 1 segundo)");
        final TextView warn = new I18nTextView(c);
        warn.setTextColor(C_AMBER);
        warn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        warn.setPadding(dp(8), dp(4), dp(8), dp(4));
        final TextView dur = new I18nTextView(c);
        dur.setTextColor(LayoutManager.TEXT);
        dur.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        dur.setTypeface(Typeface.DEFAULT_BOLD);
        dur.setPadding(dp(8), dp(4), dp(8), dp(4));
        final Runnable upd = new Runnable() { public void run() {
            Ano.Mpt now = sprite();
            if (now == null) return;
            int t = FrameTools.ticks(now);
            if (t == 0) {
                warn.setText("Tempo 0! O frame fica travado: não avança sozinho (na estrutura do frame é o mesmo que desativar o TIME). A timeline o mostra com 3 ticks.");
                warn.setVisibility(View.VISIBLE);
                dur.setText("Duração: travado");
            } else {
                warn.setVisibility(View.GONE);
                dur.setText("Duração: " + FrameTools.seconds(t) + "  (" + t + " ticks)");
            }
        } };
        put(new Stepper(c).range(0, 255).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            final Ano.Mpt t = FrameTools.setTime(sprite(), (int) v);
            edit(new Mut() { public void apply(Ano.Mpt n) { n.flags = t.flags; n.time = t.time; } });
            refreshTitle();
            upd.run();
        } }).value(FrameTools.ticks(m)));
        body.addView(warn);
        body.addView(dur);
        upd.run();
        wide("REMOVER FRAME", C_RED, new View.OnClickListener() { public void onClick(View v) {
            if (a.mpts.length <= 1) { I18nUi.toast(c, "A ANO precisa de ao menos um frame", android.widget.Toast.LENGTH_SHORT).show(); return; }
            remove(a);
        } });
    }

    // ---- Som ----

    private void pgSom(final Ano a) {
        pageHead("Som", C_RED);
        final AttackData ad = view.attackData();
        if (ad == null || !(c instanceof android.app.Activity)) { note("Nada carregado."); return; }
        final Ano.Mpt m = sprite();
        final int cur = (m.flags & 8) != 0 ? m.se : -1;
        SoundPlayer sp = view.soundPlayer();
        int seMax = 0;
        if (sp != null) for (java.io.File f : sp.commonFiles()) {
            int cn = SoundPlayer.commonNumber(f);
            if (SoundIds.selectable(cn)) seMax = Math.max(seMax, SoundIds.idOfCommon(cn));
        }
        final int sm = seMax, wc = CharSounds.list(ad.attacker.dir).length;
        stopSoundCard();
        soundCard = SoundDialog.embed((android.app.Activity) c, view, ad.attacker.dir, cur, new Runnable() { public void run() {
            onChanged.run();
            show(type, idx, flag, occ);
        } });
        LinearLayout row = line();
        TextView minus = Stepper.sideButton(c, "−"), plus = Stepper.sideButton(c, "+");
        minus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setSound(FrameTools.stepSound(cur, -1, sm, wc)); } });
        plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setSound(FrameTools.stepSound(cur, 1, sm, wc)); } });
        row.addView(minus, new LinearLayout.LayoutParams(dp(48), dp(52)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.setMargins(dp(6), 0, dp(6), 0);
        row.addView(soundCard.cardView(), cp);
        row.addView(plus, new LinearLayout.LayoutParams(dp(48), dp(52)));
        int lastChar = 80 + Math.max(0, Math.min(20, wc) - 1);
        note(sm >= 100
                ? "− e + passam só pelos sons que existem: 0 → sons comuns (1 a 79) → sons do personagem (80 a " + lastChar + ") → sons comuns novos (100 a " + sm + "). O som toca uma vez, quando o frame começa."
                : "− e + passam só pelos sons que existem: 0 → sons comuns (1 a " + Math.min(79, sm) + ") → sons do personagem (80 a " + lastChar + "). O som toca uma vez, quando o frame começa.");
        wide("ESCOLHER", C_BLUE, new View.OnClickListener() { public void onClick(View v) { pickSound(cur); } });
        wide("REMOVER ÁUDIO", C_RED, new View.OnClickListener() { public void onClick(View v) {
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 8, false); n.se = -1; } });
        } });
    }

    private void setSound(final int id) {
        editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 8, true); n.se = Math.max(0, Math.min(SoundIds.MAX_ID, id)); } });
        view.previewSe(id);
    }

    // ---- Movimento ----

    private final TextView[] totalTv = new TextView[2];

    /** Movimento: duas secoes independentes, SPEED X e SPEED Y (como Hitbox/Hurtbox); o que e do trecho inteiro aparece nas duas. */
    private void pgMover(final Ano a) {
        pageHead("Movimento", C_GREEN);
        totalTv[0] = totalTv[1] = null;
        head("SPEED X");
        moveAxis(a, 0);
        head("SPEED Y");
        moveAxis(a, 1);
    }

    private void moveAxis(final Ano a, final int axis) {
        final int f = idx;
        final Ano.Mpt[] mp = a.mpts;
        final Ano.Mpt m = mp[f];
        final boolean keeps = FrameTools.keeps(mp, f);
        final double[] rec = FrameTools.received(mp, f);
        final double[] start = FrameTools.startSpeed(mp, f);
        final boolean accelBefore = FrameTools.showAccelAxis(m, axis);
        boolean own = (m.flags & 4) != 0 && (m.moveMask & (1 << axis)) != 0;
        double ownV = own ? (axis == 0 ? m.speedX : m.speedY) / FrameTools.ONE : 0;
        double shown = keeps ? (own ? ownV - rec[axis] : 0) : ownV;
        lab(keeps ? "velocidade (soma à recebida)" : "velocidade  (px por tick)");
        put(new Stepper(c).range(-999, 999).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            final double abs = keeps ? rec[axis] + v : v;
            final Ano.Mpt r = FrameTools.setSpeed(sprite(), axis, abs, v != 0);
            edit(new Mut() { public void apply(Ano.Mpt n) { copyMove(r, n); } });
            if (FrameTools.showAccelAxis(sprite(), axis) != accelBefore || keeps) show(type, idx, flag, occ); else refreshMoveTotal(a);
        } }).value(shown));
        if (keeps) {
            LinearLayout rl = line();
            TextView t = new I18nTextView(c);
            t.setText(FrameTools.px(rec[axis]) + " recebido do frame anterior, total: " + FrameTools.px(start[axis]));
            t.setTextColor(C_RECV);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            rl.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (rec[axis] != 0) rl.addView(btn("Remover", false, new View.OnClickListener() { public void onClick(View v) {
                Ano.Mpt[] out = FrameTools.zeroReceivedAxis(cur().mpts, f, axis);
                if (out != null) replaceMpts(out, f);
            } }));
        }
        totalTv[axis] = note("");
        refreshMoveTotal(a);
        if (FrameTools.showAccelAxis(m, axis)) {
            lab(axis == 0 ? "aceleração x  (px por tick²)" : "aceleração y");
            put(new Stepper(c).range(-99, 99).step(0.1).keyboard(new Stepper.OnValue() { public void on(final double v) {
                final Ano.Mpt r = FrameTools.setAccel(sprite(), axis, v);
                edit(new Mut() { public void apply(Ano.Mpt n) { copyMove(r, n); } });
                refreshMoveTotal(a);
            } }).value((axis == 0 ? m.accelX : m.accelY) / FrameTools.ONE));
            note("Soma na velocidade atual a cada tick, apenas neste frame (o frame seguinte recebe a velocidade já somada, não a aceleração).");
        }

        int head = FrameOps.moveHeadOf(mp, f);
        if (head >= 0) {
            final int h = head;
            final int last = FrameOps.moveRunEnd(mp, h);
            final int maxLen = FrameOps.nextMoveHead(mp, h) - h;
            lab("duração do movimento — frame inicial");
            put(new Stepper(c).range(1, mp.length).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
                Ano.Mpt[] out = FrameTools.moveRunTo(cur().mpts, h, (int) v - 1);
                if (out == null) { I18nUi.toast(c, "Não cabe: bate em outra velocidade ou passa do último frame", android.widget.Toast.LENGTH_SHORT).show(); show(type, idx, flag, occ); return; }
                replaceMpts(out, (int) v - 1);
            } }).value(h + 1));
            note("Frame em que o movimento começa.");
            lab("duração (frames)");
            put(new Stepper(c).range(1, Math.max(1, maxLen)).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
                view.replaceMpts(FrameOps.setMoveRun(cur().mpts, h, h + (int) v - 1));
                refresh();                       // reconstroi: a outra secao (X/Y) mostra a mesma duracao
            } }).value(last - h + 1));
            note("Quantos frames seguidos mantêm a velocidade (até o próximo movimento: " + maxLen + ").");
        }
        check("manter velocidade", FrameTools.keepsNext(mp, f), new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                if (on == FrameTools.keepsNext(cur().mpts, f)) return;
                Ano.Mpt[] out = FrameTools.setKeepNext(cur().mpts, f, on);
                if (out == null) {
                    I18nUi.toast(c, on ? "Não há frame seguinte" : "Nada para desligar", android.widget.Toast.LENGTH_SHORT).show();
                    show(type, idx, flag, occ);
                    return;
                }
                replaceMpts(out, f);      // reconstroi a gaveta: o outro eixo mostra o mesmo valor
            }
        });
        note("Mantém a velocidade do frame atual no próximo frame (o jogo só zera a velocidade num frame sem o bit 64).");
        if (FrameTools.axisOwn(m, axis)) {
            wide("REMOVER SPEED", C_RED, new View.OnClickListener() { public void onClick(View v) {
                Ano.Mpt[] o = cur().mpts.clone();
                o[f] = FrameTools.clearAxis(o[f], axis);
                if ((o[f].flags & 4) == 0 && FrameTools.keeps(o, f + 1)) {   // o frame ficou sem movimento nenhum: o trecho que vinha dele tambem sai
                    Ano.Mpt[] r = FrameTools.removeReceived(o, f + 1);
                    if (r != null) o = r;
                }
                replaceMpts(o, f);
            } });
        }
    }

    private void refreshMoveTotal(Ano a0) {
        Ano a = cur();
        if (a == null || idx < 0 || idx >= a.mpts.length) return;
        int head = FrameOps.moveHeadOf(a.mpts, idx);
        int from = head >= 0 ? head : idx, to = head >= 0 ? FrameOps.moveRunEnd(a.mpts, head) : idx;
        double[] t = FrameTools.totalPixels(a.mpts, from, to);
        for (int k = 0; k < 2; k++) {
            if (totalTv[k] == null) continue;
            totalTv[k].setText("Total " + (k == 0 ? "X" : "Y") + ": " + FrameTools.px(t[k]) + " px em " + (int) t[2] + " ticks"
                    + (to > from ? " (frames " + (from + 1) + " a " + (to + 1) + ")" : ""));
        }
    }

    /** Copia os campos de movimento de {@code from} para {@code to}. */
    private static void copyMove(Ano.Mpt from, Ano.Mpt to) {
        to.flags = (to.flags & ~4) | (from.flags & 4);
        to.moveMask = from.moveMask;
        to.speedX = from.speedX; to.speedY = from.speedY; to.accelX = from.accelX; to.accelY = from.accelY;
    }

    // ---- Efeitos ----

    private void pgEfeitos(final Ano a) {
        pageHead("Efeitos", C_GRAY);
        Ano.Mpt m = sprite();
        final Ano sa = cur();
        if (FrameOps.styleSig(m) != 0) {
            final int first = FrameOps.styleRunStart(sa.mpts, idx);
            int last = FrameOps.styleRunEnd(sa.mpts, idx);
            lab("duração do efeito (frames)");
            put(new Stepper(c).range(1, Math.max(1, sa.mpts.length - first)).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
                view.replaceMpts(FrameOps.setStyleRun(cur().mpts, first, first + (int) v - 1));
                refresh();
            } }).value(last - first + 1));
        }
        LinearLayout l = line();
        l.addView(styleChip("↔ Flip X", ObjModel.FLIP_H, m));
        l.addView(styleChip("↕ Flip Y", ObjModel.FLIP_V, m));
        note("Flip vale em relação à direção do personagem.");
        boolean interp = ObjModel.optField(m, 2) != 0;
        final boolean isLast = idx + 1 >= sa.mpts.length;
        line().addView(btn((interp ? "● " : "○ ") + "Interpolar para o frame " + ObjModel.interpTarget(sa.mpts.length, idx), interp, new View.OnClickListener() { public void onClick(View v) {
            setOpt(2, ObjModel.optField(sprite(), 2) != 0 ? 0 : 1);
            show(type, idx, flag, occ);
        } }));
        note("Interpolação: este frame suaviza (posição do centro, rotação, alpha e zoom) até chegar no próximo frame. Vale só para o frame que tem a marca: o frame de antes não interpola para ele. Não faz efeito num frame sem tempo.");
        if (isLast) note("Último frame: o jogo interpola em direção ao frame 1, mesmo sem LOOP.").setTextColor(C_AMBER);
    }

    /** Abre a lista de sprites do personagem do atacante para trocar a imagem do frame (com "+ ADICIONAR" na propria lista). */
    private void chooseImage() {
        AttackData ad = view.attackData();
        if (ad == null || !(c instanceof android.app.Activity)) return;
        Ano.Mpt cur = sprite();
        SpriteListScreen.show((android.app.Activity) c, ad.attacker.dir.getName(), ad.attacker, cur == null ? -1 : cur.image, new SpriteListScreen.Picker() {
            @Override public void onPick(final int image) {
                edit(new Mut() { public void apply(Ano.Mpt n) { n.image = image; } });
                show(type, idx, flag, occ);
            }
            @Override public void onPickFrames(int[] images, int[] delaysMs) {
                Ano an = cur();
                if (an == null || images.length == 0 || !FrameOps.ok(an.mpts, idx)) return;
                int[] ticks = new int[images.length];
                for (int k = 0; k < ticks.length; k++) ticks[k] = SpriteGroups.ticks(k < delaysMs.length ? delaysMs[k] : 100);
                final int nIns = images.length;
                replaceMptsBusy(FrameOps.insertSprites(an.mpts, idx, images, ticks), idx + 1, "Adicionando " + nIns + " quadros", new Runnable() {
                    @Override public void run() {
                        tl.select(TimelineView.T_SPRITE, idx, -1, -1);
                        I18nUi.toast(c, nIns + " sprite(s) inseridas depois do frame " + (idx) + " (sem hitboxes: use ALL para copiar do frame anterior)", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, new Runnable() { @Override public void run() { view.refreshAfterExternalEdit(); tl.invalidate(); onChanged.run(); } });
    }

    // ---- ALL: aplicar as coisas deste frame em outros frames ----

    private static int allMode = 0, allN = 1, allMask = FrameOps.A_DEFAULT;
    private static final String[] ALL_NAMES = {"Posição x/y (centro)", "Hitboxes", "Hurtboxes", "Animações (efeitos e projéteis)", "Sons", "Flip (espelhar)", "Zoom", "Rotação",
            "Transparência (alpha)", "Ações especiais", "Estilo (manter velocidade...)", "Velocidade", "Duração (tempo)", "Imagem (sprite)"};
    private static final int[] ALL_BITS = {FrameOps.A_POS, FrameOps.A_HIT, FrameOps.A_HURT, FrameOps.A_ANIM, FrameOps.A_SOUND, FrameOps.A_FLIP, FrameOps.A_ZOOM, FrameOps.A_ROT,
            FrameOps.A_ALPHA, FrameOps.A_ACTION, FrameOps.A_STYLE, FrameOps.A_MOVE, FrameOps.A_TIME, FrameOps.A_IMAGE};

    private void secAll(final Ano a) {
        note("Aplique as coisas deste frame (" + (idx + 1) + ") nos outros frames desta animação.");
        head("FRAMES");
        LinearLayout r = line();
        String[] md = {"próximos N", "N anteriores", "todos desta ANO", "esta sprite (nesta ANO)", "esta sprite (todas as ANOs)"};
        for (int k = 0; k < 5; k++) {
            final int kk = k;
            if (k == 3) r = line();
            r.addView(btn((allMode == k ? "● " : "○ ") + md[k], allMode == k, new View.OnClickListener() { public void onClick(View v) {
                allMode = kk;
                show(type, idx, flag, occ);
            } }));
        }
        if (allMode < 2) {
            num(line(), "N", allN, 1, new Setter() { public void set(double v) {
                allN = Math.max(1, Math.min(999, (int) v));
                show(type, idx, flag, occ);
            } });
        }
        if (!FrameOps.ok(a.mpts, idx)) { note("Selecione um sprite para copiar o que ele tem para outros frames."); return; }
        int[] rg = FrameOps.targetRange(a.mpts.length, idx, allMode, allN);
        int count = 0;
        for (int f = rg[0]; f <= rg[1]; f++) if (f != idx) count++;
        if (allMode >= 3) {
            int img = a.mpts[idx].image;
            count = FrameOps.countSprite(a.mpts, idx, img);
            int anos = count > 0 ? 1 : 0;
            if (allMode == 4) {
                Dac dd = view.packDac(2);
                count = 0; anos = 0;
                if (dd != null) for (int i = 0; i < dd.size(); i++) {
                    Ano oa = dd.getAno(i);
                    if (oa == null || !oa.present) continue;
                    int cn = FrameOps.countSprite(oa.mpts, oa.index == a.index ? idx : -1, img);
                    if (cn > 0) { count += cn; anos++; }
                }
            }
            note("Sprite " + img + (allMode == 4 ? ": " + count + " outro(s) frame(s) em " + anos + " ANO(s)" : ": " + count + " outro(s) frame(s) nesta ANO")
                    + (count == 0 ? " (nenhum frame para atingir)" : "") + ".");
        } else
        note(count == 0 ? "Não há frames nesse intervalo." : "Vai atingir " + count + " frame(s): " + (rg[0] + 1) + (rg[1] > rg[0] ? " a " + (rg[1] + 1) : "")
                + (rg[0] <= idx && idx <= rg[1] && allMode == 2 ? " (menos este)" : "") + ".");
        head("COPIAR");
        LinearLayout row = null;
        for (int k = 0; k < ALL_NAMES.length; k++) {
            if (k == 9) head("TUDO MAIS");
            final int bit = ALL_BITS[k];
            if (k % 2 == 0 || k == 9) row = line();
            boolean on = (allMask & bit) != 0;
            row.addView(btn((on ? "☑ " : "☐ ") + ALL_NAMES[k], on, new View.OnClickListener() { public void onClick(View v) {
                allMask ^= bit;
                show(type, idx, flag, occ);
            } }));
        }
        LinearLayout q = line();
        q.addView(btn("MARCAR TUDO", false, new View.OnClickListener() { public void onClick(View v) { allMask = FrameOps.A_ALL; show(type, idx, flag, occ); } }));
        q.addView(btn("BÁSICO", false, new View.OnClickListener() { public void onClick(View v) { allMask = FrameOps.A_DEFAULT; show(type, idx, flag, occ); } }));
        q.addView(btn("LIMPAR", false, new View.OnClickListener() { public void onClick(View v) { allMask = 0; show(type, idx, flag, occ); } }));
        note("Cada coisa marcada substitui a do frame de destino pela deste frame; se este frame não tem aquilo, o destino também fica sem. "
                + "Hitboxes iguais em frames seguidos viram um objeto só na timeline. Imagem, duração e velocidade ficam desmarcadas de propósito. Transições e dano (opções do frame) estão presos aos hits e não são copiados.");
        note("Use o APLICAR do topo para copiar nos " + count + " frame(s).");
    }

    /** Aba ALL: chamado pelo APLICAR do topo; copia as coisas marcadas deste frame nos frames escolhidos. */
    private void applyAllTab() {
        if (section != S_ALL || allMask == 0) return;
        Ano an = cur();
        if (an == null || !spriteSelected(an)) return;
        if (allMode >= 3) { applySpriteTab(an); return; }
        int[] t = FrameOps.targetRange(an.mpts.length, idx, allMode, allN);
        int n = 0;
        for (int f = Math.max(0, t[0]); f <= Math.min(an.mpts.length - 1, t[1]); f++) if (f != idx) n++;
        if (n == 0) return;
        final int nAp = n;
        replaceMptsBusy(FrameOps.applyAll(an.mpts, idx, t[0], t[1], allMask), idx, "Aplicando em " + n + " frame(s)", new Runnable() {
            @Override public void run() { I18nUi.toast(c, "Aplicado em " + nAp + " frame(s)", android.widget.Toast.LENGTH_SHORT).show(); }
        });
    }

    /** ALL por sprite: aplica nos frames com a mesma imagem (nesta ANO, ou em todas as ANOs do personagem). */
    /** A gaveta esta num sprite (sprite, som, velocidade ou estilo) e o frame dele existe? Objetos, links e transicoes tem idx -1. */
    private boolean spriteSelected(Ano an) {
        boolean spriteType = type == TimelineView.T_SPRITE || type == TimelineView.T_SOUND || type == TimelineView.T_MOVE || type == TimelineView.T_STYLE;
        return spriteType && an != null && FrameOps.ok(an.mpts, idx);
    }

    private void applySpriteTab(final Ano an) {
        if (!spriteSelected(an)) return;
        final Ano.Mpt src = an.mpts[idx];
        final java.util.ArrayList<Ano> out = new java.util.ArrayList<Ano>();
        int frames = 0;
        if (allMode == 3) {
            if (FrameOps.countSprite(an.mpts, idx, src.image) > 0) {
                frames = FrameOps.countSprite(an.mpts, idx, src.image);
                out.add(new Ano(an.index, true, an.flags, an.priority, an.links, FrameOps.applySprite(an.mpts, idx, src, allMask)));
            }
        } else {
            Dac dd = view.packDac(2);
            if (dd != null) for (int i = 0; i < dd.size(); i++) {
                Ano oa = dd.getAno(i);
                if (oa == null || !oa.present || oa.mpts == null) continue;
                int skip = oa.index == an.index ? idx : -1;
                int cn = FrameOps.countSprite(oa.mpts, skip, src.image);
                if (cn == 0) continue;
                frames += cn;
                out.add(new Ano(oa.index, true, oa.flags, oa.priority, oa.links, FrameOps.applySprite(oa.mpts, skip, src, allMask)));
            }
        }
        if (out.isEmpty()) { I18nUi.toast(c, "Nenhum outro frame com essa sprite", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final int nf = frames, na = out.size();
        if (!(c instanceof android.app.Activity)) { view.replaceAnosAsync(out, null); return; }
        final BusyDialog busy = BusyDialog.show((android.app.Activity) c, "Aplicando em " + nf + " frame(s)");
        busy.set("Recalculando a animacao...", 0, 0);
        view.replaceAnosAsync(out, new Runnable() { public void run() {
            show(type, idx, flag, occ);
            onChanged.run();
            busy.dismiss();
            I18nUi.toast(c, "Aplicado em " + nf + " frame(s) de " + na + " ANO(s)", android.widget.Toast.LENGTH_SHORT).show();
        } });
    }


    // ---- mover sprite + animacoes ligadas (links) ----
    /** 0 = nao sincroniza, 1 = so o frame atual, 2 = todos os frames da ANO filha. */






    private void refreshTitle() {
        Ano a = cur();
        if (a == null || idx < 0 || idx >= a.mpts.length) return;
        title.setText("SPRITE " + (idx + 1) + "/" + a.mpts.length + "  ·  " + ObjModel.seconds(FrameOps.span(a.mpts[idx])));
    }


    private interface DurSet { void apply(int frames); }

    /** Campo DURACAO em frames completos: a sprite e absoluta, o item so escolhe por quantos frames dura. */
    private void durationField(Ano a, int first, int frames, int maxFrames, final DurSet set) {
        int ticks = 0;
        int[] st = FrameOps.starts(a.mpts);
        for (int f = first; f < first + frames && f < a.mpts.length; f++) ticks += FrameOps.span(a.mpts[f]);
        final int max = Math.max(1, maxFrames);
        num(line(), "duracao", frames, 1, new Setter() { public void set(double v) {
            set.apply(Math.max(1, Math.min(max, (int) Math.round(v))));
        } });
        note("em frames completos (de 1 a " + max + "): " + frames + (frames == 1 ? " frame" : " frames") + " = " + ObjModel.timeText(ticks)
                + ". O tempo de cada frame se muda na sprite.");
    }




    private TextView styleChip(String label, final int bitMask, Ano.Mpt m) {
        final boolean on = ObjModel.spriteBit(m, bitMask);
        return btn(on ? "● " + label : "○ " + label, on, new View.OnClickListener() { public void onClick(View v) {
            Ano.Mpt cm = sprite();
            if (cm == null) return;
            view.changeMpt(idx, ObjModel.setSpriteBit(cm, bitMask, !ObjModel.spriteBit(cm, bitMask)));
            show(type, idx, flag, occ);
            onChanged.run();
        } });
    }

    private void pickSound(final int currentSe) {
        AttackData ad = view.attackData();
        if (ad == null || !(c instanceof android.app.Activity)) return;
        SoundDialog.show((android.app.Activity) c, view, ad.attacker.dir, currentSe, new SoundDialog.Choose() { public void on(final int se) {
            editAndRebuild(new Mut() { public void apply(Ano.Mpt n) { bit(n, 8, true); n.se = Math.max(0, Math.min(SoundIds.MAX_ID, se)); } });
            view.previewSe(se);
        } });
    }



    private void setOpt(int field, int value) {
        Ano.Mpt m = sprite();
        if (m == null) return;
        view.changeMpt(idx, ObjModel.setOptField(m, field, value));
        onChanged.run();
    }

    private void swap(Ano a, int dir) {
        int j = idx + dir;
        if (!FrameOps.ok(a.mpts, idx) || j < 0 || j >= a.mpts.length) return;
        Ano.Mpt[] mp = a.mpts.clone();
        Ano.Mpt tmp = mp[idx]; mp[idx] = mp[j]; mp[j] = tmp;
        replaceMpts(mp, j);
    }

    private void duplicate(Ano a) {
        if (!FrameOps.ok(a.mpts, idx)) return;
        Ano.Mpt[] mp = FrameOps.duplicate(a.mpts, idx);
        replaceMpts(mp, idx + 1);
        tl.select(TimelineView.T_SPRITE, idx, -1, -1);
    }

    private void remove(Ano a) {
        if (!FrameOps.ok(a.mpts, idx)) return;
        Ano.Mpt[] mp = FrameOps.delete(a.mpts, idx);
        if (mp == null) return;
        replaceMpts(mp, Math.min(idx, mp.length - 1));
        tl.select(TimelineView.T_SPRITE, idx, -1, -1);
    }

    // ---- objetos ----

    private ObjModel.Obj curObj() {
        Ano a = cur();
        if (a == null) return null;
        int pat = Math.max(0, view.currentPat());
        ObjModel.Obj best = null;
        int bd = Integer.MAX_VALUE;
        for (ObjModel.Obj o : ObjModel.objects(a.mpts)) {
            if (o.flag != flag || o.occ != occ) continue;
            int dd = pat < o.f0 ? o.f0 - pat : pat > o.f1 ? pat - o.f1 : 0;
            if (dd < bd) { bd = dd; best = o; }
        }
        return best;
    }

    private int patIn(ObjModel.Obj o) { return Math.max(o.f0, Math.min(o.f1, view.currentPat())); }

    /** Frame da box mostrado no menu (ultimo frame do ponteiro em que ela existia). */
    private int boxPat = -1;

    private static boolean isBoxFlag(int fl) {
        int k = ObjModel.kindOf(fl);
        return k == ObjModel.HITBOX || k == ObjModel.HURTBOX;
    }

    private void object(Ano a) {
        ObjModel.Obj o;
        int pat;
        if (isBoxFlag(flag)) {
            // box: o frame mostrado e o do ponteiro se ela existe nele; senao o ultimo que foi mostrado (nunca a box seguinte)
            int p = Math.max(0, view.currentPat());
            o = ObjModel.find(ObjModel.objects(a.mpts), flag, occ, p);
            pat = p;
            if (o == null && boxPat >= 0) { o = ObjModel.find(ObjModel.objects(a.mpts), flag, occ, boxPat); pat = boxPat; }
            if (o == null) { o = curObj(); pat = o == null ? 0 : patIn(o); }
            boxPat = pat;
        } else {
            o = curObj();
            pat = o == null ? 0 : patIn(o);
        }
        if (o == null) { title.setText(""); return; }
        title.setTextColor(ObjModel.KIND_COLORS[o.kind]);
        String nm = o.kind == ObjModel.EFFECT ? "EFEITO" : o.kind == ObjModel.ACTION ? (o.behind ? ObjModel.actionName(ObjModel.ACT_BEHIND) : ObjModel.actionName(o.flag)).toUpperCase(java.util.Locale.US) : ObjModel.KIND_NAMES[o.kind].toUpperCase(java.util.Locale.US);
        int t0 = FrameOps.starts(a.mpts)[o.f0], t1 = FrameOps.starts(a.mpts)[o.f1] + FrameOps.span(a.mpts[o.f1]);
        title.setText(nm + "  ·  " + ObjModel.seconds(t0).replace("s", "") + "–" + ObjModel.seconds(t1));
        if (o.kind != ObjModel.HITBOX && o.kind != ObjModel.HURTBOX && o.kind != ObjModel.PROJ) {       // box e projetil tem o proprio "inicio e duracao"
            durationField(a, o.f0, o.f1 - o.f0 + 1, a.mpts.length - o.f0, new DurSet() { public void apply(int n) {
                ObjModel.Obj oo = curObj();
                if (oo == null) return;
                view.replaceMpts(ObjModel.trim(cur().mpts, oo, oo.f0, oo.f0 + n - 1));
                refresh();
            } });
            if (o.f1 > o.f0) note("Frames conectados (" + (o.f0 + 1) + "–" + (o.f1 + 1) + "): mudar aqui muda em todos. Para editar um frame separado, selecione o objeto e use DIVIDIR na divisa de frames mais proxima.");
        }
        switch (o.kind) {
            case ObjModel.HITBOX: case ObjModel.HURTBOX: box(a, o, pat); break;
            case ObjModel.PROJ: projectile(a, o, pat); break;
            case ObjModel.EFFECT: effect(a, o, pat); break;
            default: action(a, o, pat); break;
        }
        if (o.kind != ObjModel.HITBOX && o.kind != ObjModel.HURTBOX) keyInfo(a, o, pat);
    }

    /** Botao para remover o objeto (sem keyframes: os valores mudam so entre sprites). */
    private void keyInfo(Ano a, final ObjModel.Obj o, final int pat) {
        LinearLayout l = line();
        l.addView(btn("✕ remover objeto", false, new View.OnClickListener() { public void onClick(View v) {
            view.replaceMpts(ObjModel.remove(cur().mpts, o));
            tl.clearSelection();
            onClose.run();
            onChanged.run();
        } }));
    }

    private void editCoords(final ObjModel.Obj o, final int pat, final int field, final int val) {
        Ano a = cur();
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        if (h == null) return;
        int x = h.x, y = h.y, w = h.width, hh = h.height;
        if (field == 0) x = val; else if (field == 1) y = val; else if (field == 2) w = val; else hh = val;
        Ano.Mpt[] n = ObjModel.setCoordsRange(a.mpts, o, o.f0, o.f1, x, y, w, hh);      // conectado: todos os frames do objeto
        if (n == null) return;
        view.replaceMpts(n, "obj:" + a.index + ":" + o.flag + ":" + o.occ + ":" + field + ":" + pat);
        onChanged.run();
        // atualiza a timeline
        tl.invalidate();
    }

    private Setter coord(final ObjModel.Obj o, final int pat, final int field) {
        return new Setter() { public void set(double v) { editCoords(o, pat, field, (int) v); } };
    }

    // ---- transicao (SEQ / END) dentro do menu de Hitbox ----

    private boolean focusOn;
    private ScrollView bodyScrollRef;

    /** Rola o menu ate o fim (a secao de sequencia fica la). */
    private void scrollBodyToEnd() {
        if (bodyScrollRef == null) return;
        bodyScrollRef.post(new Runnable() { public void run() { bodyScrollRef.fullScroll(View.FOCUS_DOWN); } });
    }
    private int focusFlag, focusOcc;

    /** Clique no marcador SEQ/END da timeline: abre o menu da hitbox daquele frame, com a secao de transicao no topo. */
    private boolean openSeqAsHitbox(Ano a, int i) {
        java.util.List<SeqMark> ms = view.sequenceMarks();
        if (i < 0 || i >= ms.size()) return false;
        SeqMark m = ms.get(i);
        if (m.incoming || (m.kind != SeqMark.SEQ && m.kind != SeqMark.END && m.kind != SeqMark.HIT)) return false;
        if (m.kind == SeqMark.HIT) {                       // SEQ_PROJETIL: abre o menu do projetil (o ultimo lancado ate este frame, ou o primeiro)
            ObjModel.Obj pick = null;
            for (ObjModel.Obj o : ObjModel.objects(a.mpts)) {
                if (o.kind != ObjModel.PROJ) continue;
                if (pick == null || (o.f0 <= m.pat && o.f0 >= pick.f0)) pick = o;
            }
            if (pick == null) return false;
            focusOn = true; focusFlag = pick.flag; focusOcc = pick.occ;
            view.seekToPatKeep(m.pat);
            tl.select(TimelineView.T_OBJ, -1, pick.flag, pick.occ);
            show(TimelineView.T_OBJ, -1, pick.flag, pick.occ);
            return true;
        }
        for (ObjModel.Obj o : ObjModel.objects(a.mpts)) {
            if (o.kind != ObjModel.HITBOX || m.pat < o.f0 || m.pat > o.f1) continue;
            focusOn = true; focusFlag = o.flag; focusOcc = o.occ;
            view.seekToPatKeep(m.pat);
            tl.select(TimelineView.T_OBJ, -1, o.flag, o.occ);
            show(TimelineView.T_OBJ, -1, o.flag, o.occ);
            return true;
        }
        return false;
    }

    private static String anoText(int v) { return v == 0 ? "sem" : "ANO " + v; }

    /**
     * Botao "+ Transicao" / "Editar Transicao". Fora de uma ANO de SEQ: edita a SEQ (chao e ar). Dentro da ANO de SEQ: edita a END
     * (so existe ali: a END dispara num novo hit enquanto o atacante esta na ANO da SEQ). Na ANO de END nao ha transicao propria.
     */
    private void transitionBlock(Ano a, final ObjModel.Obj hitObj) {
        AttackData ad = view.attackData();
        head("Transição");
        if (ad == null || ad.move == null || ad.move.generic) { note("Este ataque não tem dados de golpe (HDAT 4): sem transição."); return; }
        final CharData.Move mv = ad.move;
        final int cur = a.index;
        boolean seqC = mv.animSeqChao != 0 && cur == mv.animSeqChao, seqA = mv.animSeqAr != 0 && cur == mv.animSeqAr;
        boolean endHere = (mv.animEndChao != 0 && cur == mv.animEndChao) || (mv.animEndAr != 0 && cur == mv.animEndAr);
        if (!seqC && !seqA && endHere) {
            note("Esta ANO é o fim da sequência (END): não tem transição própria.");
            line().addView(btn("⇢ VER FLUXO", false, new View.OnClickListener() {
                public void onClick(View v) { if (c instanceof android.app.Activity) FlowDialog.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { show(type, idx, flag, occ); onChanged.run(); } }); }
            }));
            return;
        }
        final int kind = (seqC || seqA) ? SeqMark.END : SeqMark.SEQ;
        // variantes que valem aqui: SEQ = chao e ar; END = so a variante cuja SEQ e esta ANO
        final boolean wantGround = kind == SeqMark.SEQ || seqC, wantAir = kind == SeqMark.SEQ || seqA;
        String nm = kind == SeqMark.SEQ ? "Seq" : "End";
        int vg = kind == SeqMark.SEQ ? mv.animSeqChao : mv.animEndChao, va = kind == SeqMark.SEQ ? mv.animSeqAr : mv.animEndAr;
        String st = "";
        final boolean any0 = (wantGround && vg != 0) || (wantAir && va != 0);
        if (wantGround) st += nm + " chão: " + anoText(vg);
        if (wantAir) st += (st.isEmpty() ? "" : "   ·   ") + nm + " ar: " + anoText(va);
        TextView cur0 = note("Transição atual: " + (any0 ? st : "nenhuma"));
        cur0.setTextColor(any0 ? LayoutManager.TEXT : LayoutManager.DIM);
        cur0.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        if (kind == SeqMark.END) note("Esta ANO é o destino da SEQ: a END dispara num novo hit enquanto o atacante está aqui.");
        else note("A SEQ dispara quando um hit conecta nesta ANO. Chão e ar são definidos separadamente (o jogo escolhe pela posição do atacante).");
        boolean any = (wantGround && vg != 0) || (wantAir && va != 0);
        final boolean fg = wantGround, fa = wantAir;
        LinearLayout r = line();
        r.addView(btn((any ? "✎ Mudar ANO destino" : "+ Transição") + (kind == SeqMark.END ? " END" : ""), true, new View.OnClickListener() {
            public void onClick(View v) { transitionDialog(kind, cur, fg, fa); }
        }));
        final Ano ca0 = cur();
        final boolean blk0 = hitObj != null && ca0 != null && ObjModel.hasFlagRange(ca0.mpts, hitObj.f0, hitObj.f1, 38);
        if (hitObj != null && kind == SeqMark.SEQ && (any || blk0)) {       // so oferece bloquear se o golpe tem SEQ (ou se ja esta bloqueado)
            final Ano ca = cur();
            final boolean blk = ca != null && ObjModel.hasFlagRange(ca.mpts, hitObj.f0, hitObj.f1, 38);
            note("Bloquear sequência (flag 38) impede a SEQ de disparar quando este hit conecta.");
            line().addView(btn(blk ? "✕ DESBLOQUEAR SEQUÊNCIA" : "+ BLOQUEAR SEQUÊNCIA", blk, new View.OnClickListener() {
                public void onClick(View v) {
                    Ano cu = cur();
                    if (cu == null) return;
                    replaceMpts(ObjModel.setFlagRange(cu.mpts, hitObj.f0, hitObj.f1, 38, !blk), idx);
                    onChanged.run();
                }
            }));
        }
        r.addView(btn("⇢ VER FLUXO", false, new View.OnClickListener() {
            public void onClick(View v) { if (c instanceof android.app.Activity) FlowDialog.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { show(type, idx, flag, occ); onChanged.run(); } }); }
        }));
    }

    private android.widget.EditText ano255(int v) {
        android.widget.EditText e = new android.widget.EditText(c);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setText(v == 0 ? "" : String.valueOf(v));
        e.setHint(I18n.tr("0 = sem"));
        e.setTextColor(LayoutManager.TEXT);
        e.setHintTextColor(LayoutManager.DIM);
        e.setSingleLine(true);
        return e;
    }

    private void transitionDialog(final int kind, final int curAno, final boolean wantGround, final boolean wantAir) {
        final CharData.Move mv = view.attackData().move;
        final String nm = kind == SeqMark.SEQ ? "Seq" : "End";
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(8), dp(16), dp(4));
        TextView info = new I18nTextView(c);
        info.setText(kind == SeqMark.SEQ ? "Para qual ANO o golpe vai quando um hit conecta (0 = nenhuma). Aceita qualquer ANO do DAC (campo de 16 bits)."
                : "Para qual ANO o golpe vai num novo hit durante a SEQ (0 = nenhuma). Aceita qualquer ANO do DAC (campo de 16 bits).");
        info.setTextColor(LayoutManager.DIM);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        col.addView(info);
        final android.widget.EditText eg = ano255(kind == SeqMark.SEQ ? mv.animSeqChao : mv.animEndChao);
        final android.widget.EditText ea = ano255(kind == SeqMark.SEQ ? mv.animSeqAr : mv.animEndAr);
        if (wantGround) { col.addView(tvLabel(nm + " Chão")); col.addView(eg); }
        if (wantAir) { col.addView(tvLabel(nm + " Ar")); col.addView(ea); }
        final android.app.AlertDialog dlg = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(kind == SeqMark.SEQ ? "Transição (SEQ)" : "Transição (END)").setView(col)
                .setNegativeButton("CANCELAR", null).setPositiveButton("SALVAR", null).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button pos = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
        if (pos != null) {
            pos.setTextColor(LayoutManager.ACCENT);
            pos.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                int g = wantGround ? parse255(eg) : -1, ar = wantAir ? parse255(ea) : -1;
                if (g == curAno || ar == curAno) { I18nUi.toast(c, "A transição não pode apontar para a própria ANO.", Toast.LENGTH_SHORT).show(); return; }
                if (wantGround && wantAir && ((g == 0) != (ar == 0))) {
                    // so um dos dois definido: pergunta o que fazer com o outro
                    dlg.dismiss();
                    askOther(kind, g, ar);
                    return;
                }
                dlg.dismiss();
                applyTransition(kind, wantGround ? g : -1, wantAir ? ar : -1);
            } });
        }
    }

    private TextView tvLabel(String s) {
        TextView t = new I18nTextView(c);
        t.setText(s);
        t.setTextColor(LayoutManager.TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private static int parse255(android.widget.EditText e) {
        try { return Math.max(0, Math.min(CharData.Move.MAX, Integer.parseInt(e.getText().toString().trim()))); } catch (Exception x) { return 0; }
    }

    /** Definiu so chao ou so ar: avisa e deixa copiar para o outro ou manter sem transicao. */
    private void askOther(final int kind, final int g, final int ar) {
        final String nm = kind == SeqMark.SEQ ? "Seq" : "End";
        final boolean groundSet = g != 0;
        final String set = groundSet ? "chão" : "ar", other = groundSet ? "ar" : "chão";
        final int v = groundSet ? g : ar;
        android.app.AlertDialog dlg = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Só " + nm + " " + set + " definida")
                .setMessage("Você definiu " + nm + " " + set + " (ANO " + v + "), mas não definiu " + nm + " " + other + ". "
                        + "Quando o atacante estiver no " + other + ", o hit não vai trocar de ANO.\n\nQuer usar a mesma ANO no " + other + " também?")
                .setPositiveButton("USAR A MESMA NO " + other.toUpperCase(java.util.Locale.US), new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { applyTransition(kind, v, v); }
                })
                .setNeutralButton("DEIXAR SEM " + nm.toUpperCase(java.util.Locale.US) + " NO " + other.toUpperCase(java.util.Locale.US), new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface x, int w) { applyTransition(kind, g, ar); }
                })
                .setNegativeButton("VOLTAR", null).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button b1 = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE), b2 = dlg.getButton(android.app.AlertDialog.BUTTON_NEUTRAL);
        if (b1 != null) b1.setTextColor(LayoutManager.ACCENT);
        if (b2 != null) b2.setTextColor(LayoutManager.ACCENT);
    }

    /** g / ar = -1: nao mexe naquela variante. */
    private void applyTransition(final int kind, final int g, final int ar) {
        view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) {
            if (g >= 0) setMoveField(mv, kind, false, 0, g);
            if (ar >= 0) setMoveField(mv, kind, true, 0, ar);
        } });
        show(type, idx, flag, occ);
        onChanged.run();
    }

    /** Stepper de uma coordenada da box (conectado: edita todos os frames dela); {@code upd} redesenha a previa. */
    private Stepper coordStep(final ObjModel.Obj o, final int pat, final int field, int value, final Runnable upd) {
        return new Stepper(c).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
            editCoords(o, pat, field, (int) v);
            upd.run();
        } }).value(value);
    }

    /** Menu de Hitbox / Hurtbox: troca de tipo, inicio e duracao, previa, coordenadas, remover e (hitbox) dano, reacao e transicao. */
    private void box(final Ano a, final ObjModel.Obj o, final int pat) {
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        // 1. Hitbox | Hurtbox
        LinearLayout t = line();
        t.addView(btn("Hurtbox (corpo)", o.kind == ObjModel.HURTBOX, convert(o, 1)));
        t.addView(btn("Hitbox (ataque)", o.kind == ObjModel.HITBOX, convert(o, 2)));
        // 2. frame de inicio e duracao (frames completos)
        final int n = o.f1 - o.f0 + 1;
        lab("FRAME DE INÍCIO");
        put(new Stepper(c).range(1, Math.max(1, a.mpts.length - n + 1)).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
            moveBox(o, (int) v - 1);
        } }).value(o.f0 + 1));
        if (o.kind != ObjModel.HITBOX) {                 // Hitbox e sempre de um Frame so: nao ha duracao a mudar
            lab("DURAÇÃO (frames)");
            put(new Stepper(c).range(1, Math.max(1, a.mpts.length - o.f0)).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
                ObjModel.Obj oo = ObjModel.find(ObjModel.objects(cur().mpts), o.flag, o.occ, o.f0);     // a box mostrada, nao a mais proxima do ponteiro
                if (oo == null) return;
                view.replaceMpts(ObjModel.trim(cur().mpts, oo, oo.f0, oo.f0 + (int) v - 1));
                refresh();
            } }).value(n));
        }
        int ticks = 0;
        for (int f = o.f0; f <= o.f1; f++) ticks += FrameOps.span(a.mpts[f]);
        note("Frames " + (o.f0 + 1) + " a " + (o.f1 + 1) + " = " + ObjModel.timeText(ticks)
                + ". Mover o início leva a box inteira (a duração fica; na hitbox, o dano e a reação vão junto); se cair em cima de outra box igual, ela ganha uma faixa própria. O tempo de cada frame se muda na sprite.");
        if (o.kind == ObjModel.HITBOX) note("Hitbox é sempre uma por Frame: o hit se repete a cada Frame, então cada Frame tem a sua própria hitbox (e o próprio dano e reação).");
        if (n > 1) note("Frames conectados: mudar x, y, largura ou altura muda em todos. Para editar um frame separado, use DIVIDIR na divisa de frames mais próxima.");
        // 3. previa do sprite com as boxes
        final AnimPreview pv = new AnimPreview(c);
        pv.setShowHits(true);
        pv.setStaticFrame(pat);                       // parada no frame mostrado, sem reproduzir
        pv.setOnlyHit(o.flag, o.occ);                 // so esta box: hurtbox sem a hitbox e vice-versa
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-1, dp(170));
        pl.setMargins(dp(4), dp(8), dp(4), dp(4));
        body.addView(pv, pl);
        final Runnable upd = new Runnable() { public void run() {
            Ano cu = cur();
            if (cu == null) return;
            pv.set(view.packDac(2), view.packSprites(2), cu.index, false);
        } };
        upd.run();
        // 4. x, y, largura, altura
        LinearLayout r1 = line();
        r1.addView(axisLabel("x"));
        stepIn(r1, coordStep(o, pat, 0, h.x, upd));
        r1.addView(axisLabel("y"));
        stepIn(r1, coordStep(o, pat, 1, h.y, upd));
        LinearLayout r2 = line();
        r2.addView(axisLabel("larg."));
        stepIn(r2, coordStep(o, pat, 2, h.width, upd));
        r2.addView(axisLabel("alt."));
        stepIn(r2, coordStep(o, pat, 3, h.height, upd));
        keyInfo(a, o, pat);     // remover fica junto da box, antes de dano/reacao/transicao
        if (o.kind == ObjModel.HURTBOX) {
            final int hx = h.x, hy = h.y, hw = h.width, hh = h.height;
            LinearLayout ra = line();
            ra.addView(btn("Aplicar a todas as Hurtboxes (neste ANO)", false, new View.OnClickListener() { public void onClick(View v) { applyHurtboxes(false, hx, hy, hw, hh); } }));
            LinearLayout rb = line();
            rb.addView(btn("Aplicar a todas as Hurtboxes (todos os ANOs)", false, new View.OnClickListener() { public void onClick(View v) { applyHurtboxes(true, hx, hy, hw, hh); } }));
            note("Copia a posição e o tamanho desta hurtbox para todas as outras hurtboxes do ANO (ou de todos os ANOs do personagem). Desfazer volta tudo de uma vez.");
        }
        if (o.kind == ObjModel.HITBOX) {
            head("Dano e reacao (deste sprite)");
            Ano.Mpt m = a.mpts[pat];
            final int p2 = pat;
            lab("DANO");
            put(new Stepper(c).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { optSetter(p2, 0).set(v); } })
                    .value(ObjModel.optField(m, 0)));
            note("Dano e reação são do sprite (frame) sob o ponteiro e acompanham a hitbox ao mudar o frame de início (cada frame leva os seus) e ao mudar a duração (os frames novos copiam o da borda).");
            reactionBlock(p2);
            transitionBlock(a, o);
            if (focusOn) scrollBodyToEnd();
        }
    }

    /** Copia posicao/tamanho de uma hurtbox para todas as outras (deste ANO ou de todos os ANOs do DAC do atacante). */
    private void applyHurtboxes(final boolean all, final int x, final int y, final int w, final int h) {
        Ano a = cur();
        if (a == null) return;
        if (!all) {
            Ano.Mpt[] out = ObjModel.setAllCoords(a.mpts, 1, x, y, w, h);
            int n = ObjModel.countChanged(a.mpts, out);
            if (n == 0) { I18nUi.toast(c, "Todas as hurtboxes deste ANO ja estao assim", android.widget.Toast.LENGTH_SHORT).show(); return; }
            view.replaceMpts(out);
            refresh();
            I18nUi.toast(c, n + " frame(s) alterado(s) neste ANO", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        AttackData ad = view.attackData();
        if (ad == null) return;
        final Dac dac = ad.attacker.dac;
        final java.util.ArrayList<Ano> list = new java.util.ArrayList<Ano>();
        int frames = 0;
        for (int i = 0; i < dac.size(); i++) {
            Ano an = dac.getAno(i);
            if (an == null || !an.present || an.mpts == null) continue;
            Ano.Mpt[] out = ObjModel.setAllCoords(an.mpts, 1, x, y, w, h);
            int n = ObjModel.countChanged(an.mpts, out);
            if (n == 0) continue;
            frames += n;
            list.add(new Ano(an.index, true, an.flags, an.priority, an.links, out));
        }
        if (list.isEmpty()) { I18nUi.toast(c, "Todas as hurtboxes de todos os ANOs ja estao assim", android.widget.Toast.LENGTH_SHORT).show(); return; }
        final int nf = frames, na = list.size();
        new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Aplicar a todos os ANOs?")
                .setMessage("A posição e o tamanho desta hurtbox vão para as hurtboxes de " + nf + " frame(s) em " + na + " ANO(s). Desfazer volta tudo de uma vez. Depois use SALVAR > todos os ANOs (ou tudo) para gravar.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("APLICAR", new android.content.DialogInterface.OnClickListener() { public void onClick(android.content.DialogInterface d, int wh) {
                    if (!(c instanceof android.app.Activity)) { view.replaceAnosAsync(list, null); return; }
                    final BusyDialog busy = BusyDialog.show((android.app.Activity) c, "Aplicando em " + nf + " frame(s)");
                    busy.set("Recalculando a animacao...", 0, 0);
                    view.replaceAnosAsync(list, new Runnable() { public void run() {
                        show(type, idx, flag, occ);
                        onChanged.run();
                        busy.dismiss();
                        I18nUi.toast(c, "Aplicado em " + nf + " frame(s) de " + na + " ANO(s)", android.widget.Toast.LENGTH_SHORT).show();
                    } });
                } }).show();
    }

    /** Muda o frame de inicio da box (leva a box inteira); nao recusa colisao. */
    private void moveBox(ObjModel.Obj o, int nf0) {
        Ano a = cur();
        if (a == null || nf0 == o.f0) return;
        Ano.Mpt[] mv = ObjModel.move(a.mpts, o, nf0);
        if (mv == a.mpts) return;
        view.replaceMpts(mv);
        ObjModel.Obj now = ObjModel.locate(cur().mpts, o.flag, Math.max(0, Math.min(nf0, cur().mpts.length - 1)));
        if (now != null) {
            flag = now.flag;
            occ = now.occ;
            tl.select(TimelineView.T_OBJ, -1, flag, occ);
            view.seekToPat(now.f0);
        }
        refresh();
    }

    private static final String[] GROUPS = {"normal (efeito 0, som 3, empurra)", "som alternativo (efeito 0, som 4, empurra)",
            "forte (efeito 1, som 6, empurra)", "leve (meio hitstop, sem empurrar)", "sem efeito, som nem hitstop"};

    /** Miniplayer da reacao (OPT 1) + escolha por previas + editor dos passos. */
    private void reactionBlock(final int pat) {
        Ano a = cur();
        if (a == null || pat < 0 || pat >= a.mpts.length) return;
        final int value = ObjModel.optField(a.mpts[pat], 1);
        final Opt1 op = new Opt1(value);
        head("Reacao do oponente");
        LinearLayout l = line();
        ReactionPreview rp = new ReactionPreview(c, view);
        rp.setValue(value);
        l.addView(rp, new LinearLayout.LayoutParams(dp(112), dp(112)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        l.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView info = new I18nTextView(c);
        info.setText(op.valid ? (op.fromChar ? "reacao do personagem " + op.type : "reacao do jogo " + op.type) + "\n" + GROUPS[op.group] : "valor invalido (" + value + ")");
        info.setTextColor(LayoutManager.TEXT);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        info.setPadding(dp(6), 0, 0, dp(2));
        col.addView(info);
        LinearLayout r1 = new LinearLayout(c);
        r1.addView(btn("\u25C0", false, new View.OnClickListener() { public void onClick(View v) { cycleReaction(pat, value, -1); } }));
        r1.addView(btn("\u25B6", false, new View.OnClickListener() { public void onClick(View v) { cycleReaction(pat, value, 1); } }));
        r1.addView(btn("ESCOLHER", true, new View.OnClickListener() { public void onClick(View v) { pickReaction(pat, value); } }));
        col.addView(r1);
        LinearLayout r2 = new LinearLayout(c);
        r2.addView(btn(op.fromChar ? "EDITAR REAÇÃO" : "VER REAÇÃO", false, new View.OnClickListener() { public void onClick(View v) {
            if (!op.valid) return;
            new ReactionScreen(c, view, op.index, new Runnable() { public void run() { onChanged.run(); } }).show();
        } }));
        r2.addView(btn("efeito/som", false, new View.OnClickListener() { public void onClick(View v) { pickEffectSound(pat, value); } }));
        col.addView(r2);
        if (op.valid && !op.fromChar) note("Tabelas do jogo (gamedata) sao fixas: nao podem ser editadas.");
    }

    /**
     * Grade (no estilo do app) com os 5 jeitos de efeito/som/empurrao/hitstop do hit: cada cartao toca a REACAO ATUAL com o efeito daquele grupo;
     * tocar num cartao o seleciona e toca o som dele; o atual vem destacado. VOLTAR descarta, APLICAR grava o grupo escolhido (a reacao nao muda).
     */
    private void pickEffectSound(final int pat, final int value) {
        final int current = Math.max(0, Math.min(4, value / 50)), reaction = value >= 0 ? value % 50 : 0;
        final int[] sel = {current};
        final LinearLayout[] cells = new LinearLayout[5];
        final ReactionPreview[] previews = new ReactionPreview[5];
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(6), dp(8), dp(6));
        TextView hint = new I18nTextView(c);
        hint.setText("A reação atual com o efeito e o som de cada opção. Toque numa para ouvir; o atual está destacado.");
        hint.setTextColor(LayoutManager.DIM);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        hint.setPadding(dp(2), 0, dp(2), dp(6));
        col.addView(hint);
        final Runnable paint = new Runnable() { public void run() {
            for (int g = 0; g < 5; g++) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(g == current ? 0xFF1E3A66 : LayoutManager.PANEL_HI);
                bg.setCornerRadius(dp(8));
                if (g == sel[0]) bg.setStroke(dp(2), LayoutManager.ACCENT); else bg.setStroke(dp(1), 0xFF3A4150);
                cells[g].setBackground(bg);
            }
        } };
        LinearLayout row = null;
        for (int g = 0; g < 5; g++) {
            if (g % 2 == 0) { row = new LinearLayout(c); col.addView(row, new LinearLayout.LayoutParams(-1, -2)); }
            final int group = g;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(4), dp(4), dp(4), dp(6));
            ReactionPreview rp = new ReactionPreview(c, view);
            rp.setValue(g * 50 + reaction);
            previews[g] = rp;
            int side = Math.max(dp(96), c.getResources().getDisplayMetrics().widthPixels / 2 - dp(46));
            cell.addView(rp, new LinearLayout.LayoutParams(side, side));
            TextView t = new I18nTextView(c);
            t.setText((g == current ? "\u2713 " : "") + Opt1.GROUP_TITLES[g] + (g == current ? "  (atual)" : "") + "\n" + Opt1.groupDetail(g));
            t.setTextColor(LayoutManager.TEXT);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(3), 0, 0);
            cell.addView(t);
            cell.setClickable(true);
            cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                sel[0] = group;
                paint.run();
                for (int k = 0; k < 5; k++) previews[k].setSound(k == group);      // so a destacada toca (a propria previa traz o som do grupo)
                previews[group].replay();
            } });
            cells[g] = cell;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(cell, lp);
        }
        paint.run();
        previews[sel[0]].setSound(true);
        ScrollView sv = new ScrollView(c);
        sv.addView(col);
        final android.app.AlertDialog dlg = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Efeito, som e empurrao")
                .setView(sv)
                .setNegativeButton("VOLTAR", null)
                .setPositiveButton("APLICAR", new android.content.DialogInterface.OnClickListener() { public void onClick(android.content.DialogInterface d, int w) {
                    if (sel[0] != current) applyReaction(pat, sel[0] * 50 + reaction);
                } }).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button ok = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
        if (ok != null) ok.setTextColor(LayoutManager.ACCENT);
    }

    private void applyReaction(int pat, int value) {
        Ano a = cur();
        if (a == null) return;
        view.changeMpt(pat, ObjModel.setOptField(a.mpts[pat], 1, value));
        show(type, idx, flag, occ);
        onChanged.run();
    }

    private void cycleReaction(int pat, int value, int dir) {
        int group = Math.max(0, Math.min(4, value / 50)), idx2 = value >= 0 ? value % 50 : 0;
        for (int k = 0; k < 50; k++) {
            idx2 = (idx2 + dir + 50) % 50;
            if (view.hasReaction(idx2)) break;
        }
        applyReaction(pat, group * 50 + idx2);
    }

    private void pickReaction(final int pat, final int value) {
        final ReactionPickState st = new ReactionPickState(value);
        final int group = st.group;
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        TextView hint = new I18nTextView(c);
        hint.setText("Toque numa reação para ver e ouvir (só a destacada toca). CONFIRMAR grava; VOLTAR fecha sem mudar nada.");
        hint.setTextColor(LayoutManager.DIM);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        hint.setPadding(dp(2), 0, dp(2), dp(6));
        col.addView(hint);
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        final LinearLayout[] cells = new LinearLayout[50];
        final ReactionPreview[] previews = new ReactionPreview[50];
        final Runnable paint = new Runnable() { public void run() {
            for (int k = 0; k < 50; k++) {
                if (cells[k] == null || previews[k] == null) continue;
                GradientDrawable g = new GradientDrawable();
                boolean on = st.audible(k);
                g.setColor(on ? 0xFF1E3A66 : 0x00000000);
                g.setCornerRadius(dp(6));
                if (on) g.setStroke(dp(2), LayoutManager.ACCENT);
                cells[k].setBackground(g);
            }
        } };
        LinearLayout row = null;
        int n = 0;
        for (int i = 0; i < 50; i++) {
            final boolean empty = i >= 30 && ReactionSlots.isEmpty(view.charReaction(i - 30));      // slot do personagem sem passos: da para criar uma reacao nele
            if (!empty && !view.hasReaction(i)) continue;
            if (n % 3 == 0) { row = new LinearLayout(c); col.addView(row); }
            n++;
            final int index = i;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(2), dp(2), dp(4));
            TextView lab = new I18nTextView(c);
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            lab.setTextColor(LayoutManager.DIM);
            lab.setGravity(Gravity.CENTER);
            if (empty) {
                TextView plus = new I18nTextView(c);
                plus.setText("＋\nvazio");
                plus.setGravity(Gravity.CENTER);
                plus.setTextColor(LayoutManager.DIM);
                plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                GradientDrawable eg = new GradientDrawable();
                eg.setColor(0xFF12151B);
                eg.setStroke(dp(1), LayoutManager.PANEL_HI);
                eg.setCornerRadius(dp(8));
                plus.setBackground(eg);
                cell.addView(plus, new LinearLayout.LayoutParams(dp(92), dp(92)));
                lab.setText("personagem " + (i - 30) + " · adicionar");
                lab.setTextColor(C_BLUE);
            } else {
                ReactionPreview rp = new ReactionPreview(c, view);
                rp.setValue(group * 50 + i);
                rp.setSound(st.audible(i));
                previews[i] = rp;
                cell.addView(rp, new LinearLayout.LayoutParams(dp(92), dp(92)));
                lab.setText(i < 30 ? "jogo " + i : "personagem " + (i - 30));
                cells[i] = cell;
            }
            cell.addView(lab);
            cell.setClickable(true);
            cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                if (empty) { addReactionDialog(pat, value, index - 30, dlg[0]); return; }
                int old = st.selected();
                st.select(index);
                if (previews[old] != null) previews[old].setSound(false);
                previews[index].setSound(true);
                paint.run();
                previews[index].replay();                        // toca de novo, agora com o som
            } });
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        paint.run();
        ScrollView sv = new ScrollView(c);
        sv.addView(col);
        dlg[0] = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Escolher reacao").setView(sv)
                .setNegativeButton("VOLTAR", null)
                .setPositiveButton("CONFIRMAR", new android.content.DialogInterface.OnClickListener() { public void onClick(android.content.DialogInterface d, int w) {
                    if (st.changed()) applyReaction(pat, st.result());
                } }).create();
        dlg[0].show();
        styleDialog(dlg[0]);
        android.widget.Button ok = dlg[0].getButton(android.app.AlertDialog.BUTTON_POSITIVE);
        if (ok != null) ok.setTextColor(LayoutManager.ACCENT);
    }

    // ---- slot vazio de reacao do personagem: criar copiando, importando ou em branco ----

    private void addReactionDialog(final int pat, final int value, final int slot, final android.app.AlertDialog parent) {
        String[] items = {"Copiar de uma reação do personagem", "Copiar da game data (reações globais 0 a 29)", "Importar de outro personagem", "Em branco (1 passo)"};
        android.app.AlertDialog d2 = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Adicionar reação no slot " + slot + " (personagem)")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) {
                        if (which == 0) pickSourceGrid(pat, value, slot, parent, false);
                        else if (which == 1) pickSourceGrid(pat, value, slot, parent, true);
                        else if (which == 2) importReactionFromCharacter(pat, value, slot, parent);
                        else fillSlot(pat, value, slot, ReactionTable.blank(), parent);
                    }
                }).setNegativeButton("VOLTAR", null).create();
        d2.show();
        styleDialog(d2);
    }

    /** Grade com previa das reacoes do personagem (game = false) ou do jogo (game = true) para usar como base do slot. */
    private void pickSourceGrid(final int pat, final int value, final int slot, final android.app.AlertDialog parent, final boolean game) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        final android.app.AlertDialog[] d3 = new android.app.AlertDialog[1];
        LinearLayout row = null;
        int n = 0;
        for (int k = 0; k < (game ? 30 : CharData.REACTION_COUNT); k++) {
            if (!game && k == slot) continue;
            final ReactionTable src = game ? view.gameReaction(k) : view.charReaction(k);
            if (ReactionSlots.isEmpty(src)) continue;
            if (n % 3 == 0) { row = new LinearLayout(c); col.addView(row); }
            n++;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(2), dp(2), dp(4));
            cell.addView(candidatePlayer(src, slot, dp(92)));
            TextView lab = new I18nTextView(c);
            lab.setText((game ? "jogo " : "personagem ") + k + "\n" + src.rows + (src.rows == 1 ? " passo" : " passos"));
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            lab.setTextColor(LayoutManager.DIM);
            lab.setGravity(Gravity.CENTER);
            cell.addView(lab);
            cell.addView(useButton(new Runnable() { public void run() { d3[0].dismiss(); fillSlot(pat, value, slot, src, parent); } }));
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        if (n == 0) { I18nUi.toast(c, game ? "A game data não tem reações" : "O personagem não tem outra reação para copiar", android.widget.Toast.LENGTH_SHORT).show(); return; }
        ScrollView sv = new ScrollView(c);
        sv.addView(col);
        d3[0] = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(game ? "Base: reação do jogo" : "Base: reação do personagem").setView(sv).setNegativeButton("VOLTAR", null).create();
        d3[0].show();
        styleDialog(d3[0]);
    }

    /** Escolhe outro personagem (pastas charNN de assets) e uma reacao dele (lida do 000.bin/000.bin.txt dele) para usar no slot. */
    private void importReactionFromCharacter(final int pat, final int value, final int slot, final android.app.AlertDialog parent) {
        AttackData ad = view.attackData();
        if (ad == null) return;
        java.io.File root = ad.attacker.dir.getParentFile();
        java.io.File[] fs = root == null ? null : root.listFiles();
        final java.util.ArrayList<java.io.File> chars = new java.util.ArrayList<java.io.File>();
        if (fs != null) for (java.io.File f : fs) if (f.isDirectory() && f.getName().matches("char\\d{2}") && !f.equals(ad.attacker.dir)) chars.add(f);
        java.util.Collections.sort(chars);
        if (chars.isEmpty()) { I18nUi.toast(c, "Nenhum outro personagem em assets", android.widget.Toast.LENGTH_SHORT).show(); return; }
        String[] names = new String[chars.size()];
        for (int i = 0; i < names.length; i++) names[i] = chars.get(i).getName();
        android.app.AlertDialog d4 = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Importar de qual personagem?")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { pickImportedReaction(pat, value, slot, parent, chars.get(which)); }
                }).setNegativeButton("VOLTAR", null).create();
        d4.show();
        styleDialog(d4);
    }

    private void pickImportedReaction(final int pat, final int value, final int slot, final android.app.AlertDialog parent, java.io.File dir) {
        final CharData other;
        try { other = ReactionSlots.readChar(dir); }
        catch (Exception e) { I18nUi.toast(c, "Erro ao ler " + dir.getName() + ": " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show(); return; }
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        final android.app.AlertDialog[] d5 = new android.app.AlertDialog[1];
        int n = 0;
        for (int k = 0; k < CharData.REACTION_COUNT; k++) {
            final ReactionTable src = other.reaction(k);
            if (ReactionSlots.isEmpty(src)) continue;
            n++;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setPadding(dp(8), dp(6), dp(8), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF1B2029);
            g.setCornerRadius(dp(6));
            cell.setBackground(g);
            TextView t1 = new I18nTextView(c);
            t1.setText("Reação " + k + " de " + dir.getName());
            t1.setTextColor(LayoutManager.TEXT);
            t1.setTypeface(Typeface.DEFAULT_BOLD);
            t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            cell.addView(t1);
            TextView t2 = new I18nTextView(c);
            t2.setText(ReactionSlots.summary(src));
            t2.setTextColor(LayoutManager.DIM);
            t2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            cell.addView(t2);
            cell.addView(candidatePlayer(src, slot, dp(120)));
            cell.addView(useButton(new Runnable() { public void run() { d5[0].dismiss(); fillSlot(pat, value, slot, src, parent); } }));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(3), 0, dp(3));
            col.addView(cell, lp);
        }
        if (n == 0) { I18nUi.toast(c, dir.getName() + " não tem reações do personagem", android.widget.Toast.LENGTH_SHORT).show(); return; }
        ScrollView sv = new ScrollView(c);
        sv.addView(col);
        d5[0] = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Importar de " + dir.getName()).setView(sv).setNegativeButton("VOLTAR", null).create();
        d5[0].show();
        styleDialog(d5[0]);
    }

    /** Reproducao em laco de {@code src} como se estivesse no slot (candidata); tocar na previa pausa / retoma. */
    private View candidatePlayer(ReactionTable src, int slot, int size) {
        final ReactionPreview rp = new ReactionPreview(c, view);
        rp.setValue(30 + slot);
        rp.setOverride(slot, src);
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(rp, new LinearLayout.LayoutParams(size, size));
        final TextView pp = btn("⏸ PAUSAR", false, null);
        View.OnClickListener toggle = new View.OnClickListener() { public void onClick(View v) {
            rp.setPaused(!rp.isPaused());
            pp.setText(rp.isPaused() ? "▶ TOCAR" : "⏸ PAUSAR");
        } };
        pp.setOnClickListener(toggle);
        rp.setOnClickListener(toggle);
        box.addView(pp);
        return box;
    }

    private View useButton(final Runnable use) {
        return btn("USAR", true, new View.OnClickListener() { public void onClick(View v) { use.run(); } });
    }

    /** Grava a copia no slot (desfazivel) e faz o hit apontar para ele. */
    private void fillSlot(int pat, int value, final int slot, ReactionTable src, android.app.AlertDialog parent) {
        final ReactionTable copy = src.copy();
        view.editReaction(slot, new Runnable() { public void run() {
            ReactionTable t = view.charReaction(slot);
            if (t != null) t.restoreFrom(copy);
        } });
        if (parent != null) parent.dismiss();
        I18nUi.toast(c, "Reação do personagem " + slot + " criada (" + copy.rows + (copy.rows == 1 ? " passo" : " passos") + "). Salve para gravar no 000.bin.txt.", android.widget.Toast.LENGTH_LONG).show();
        applyReaction(pat, Math.max(0, Math.min(4, value / 50)) * 50 + 30 + slot);
    }

    private Setter optSetter(final int pat, final int field) {
        return new Setter() { public void set(double v) {
            Ano a = cur();
            if (a == null) return;
            view.changeMpt(pat, ObjModel.setOptField(a.mpts[pat], field, (int) v));
            onChanged.run();
        } };
    }

    private View.OnClickListener convert(final ObjModel.Obj o, final int newFlag) {
        return new View.OnClickListener() { public void onClick(View v) {
            if (o.flag == newFlag) return;
            view.replaceMpts(ObjModel.setFlag(cur().mpts, o, newFlag));
            int nocc = ObjModel.count(cur().mpts[o.f0], newFlag) - 1;
            flag = newFlag;
            occ = Math.max(0, nocc);
            tl.select(TimelineView.T_OBJ, -1, flag, occ);
            refresh();
        } };
    }

    // ---- projetil ----

    /** A ANO e uma animacao de projetil do golpe (principal, +1/+2, reacoes ou sub-projetil)? Ai o hit flag 0 gera sub-projetil. */
    private static boolean isProjectileAno(int ano, CharData.Move mv) {
        int[] base = {mv.projNormal, mv.projAbaixo, mv.projAcima};
        for (int b : base) if (b > 0 && ano >= b && ano <= b + 2) return true;
        int[] other = {mv.projAoAcertar, mv.projChao, mv.projGlobal, mv.subId, mv.subAoAcertar, mv.subChao};
        for (int o2 : other) if (o2 > 0 && o2 == ano) return true;
        return false;
    }

    /** Golpe cujo projetil a tela edita: o proprio golpe (modo golpe) ou o dono do ANO (modo ANO); null se nenhum golpe usa o ANO. */
    private CharData.Move projectileMove() {
        CharData.Move mv = view.moveData();
        if (mv == null) return null;
        if (!mv.generic) return mv;
        return view.moveOwner();
    }

    /** Edita o golpe do projetil (no modo ANO, o golpe real do HDAT 4) e atualiza a simulacao. */
    private void editProjMove(CharData.Move mv, Runnable change) { view.editMoveOf(mv, change); }

    /** Tela do projetil: inicio e duracao, ramificacao, ANO, posicao e velocidade, perseguicao e sequencia (igual no modo golpe e no modo ANO). */
    private void projectile(final Ano a, final ObjModel.Obj o, final int pat) {
        final CharData.Move mv = projectileMove();
        if (mv == null) {
            note("Nenhum golpe do HDAT 4 usa este ANO, então não há projétil associado para editar (a ANIM_INICIAL, a SEQ ou um campo de projétil de algum golpe precisa apontar para ele).");
            return;
        }
        if (view.moveData() != null && view.moveData().generic) note("Modo ANO: as mudanças de animação, perseguição e sequência valem para o golpe " + java.util.Arrays.asList(view.attackData().attacker.data.moves).indexOf(mv) + " (dono deste ANO).");
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);

        // 1. inicio e duracao
        head("Início e duração");
        final int n = o.f1 - o.f0 + 1;
        lab("FRAME DE INÍCIO");
        put(new Stepper(c).range(1, Math.max(1, a.mpts.length - n + 1)).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
            moveBox(o, (int) v - 1);
        } }).value(o.f0 + 1));
        lab("DURAÇÃO (frames)");
        put(new Stepper(c).range(1, Math.max(1, a.mpts.length - o.f0)).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
            ObjModel.Obj oo = ObjModel.find(ObjModel.objects(cur().mpts), o.flag, o.occ, o.f0);
            if (oo == null) return;
            view.replaceMpts(ObjModel.trim(cur().mpts, oo, oo.f0, oo.f0 + (int) v - 1));
            refresh();
        } }).value(n));
        int ticks = 0;
        for (int f = o.f0; f <= o.f1; f++) ticks += FrameOps.span(a.mpts[f]);
        note("Frames " + (o.f0 + 1) + " a " + (o.f1 + 1) + " = " + ObjModel.timeText(ticks) + ". Cada frame em que o hit de projétil (flag 0) está ativo lança um projétil.");

        // 2. ramificacao
        line().addView(btn("🌿 RAMIFICAÇÃO DO PROJÉTIL", true, new View.OnClickListener() { public void onClick(View v) {
            if (c instanceof android.app.Activity) ProjectileTree.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { onChanged.run(); } });
        } }));
        note("Mostra o caminho completo: ANIM_INICIAL → projétil (+ANO+1/+2 com 3 projéteis) → reações (acerto, chão, abaixo, acima, global) → sub-projétil, e é onde essas animações se escolhem.");

        // 3. ANO do projetil
        head("ANO do projétil");
        put(new Stepper(c).range(0, CharData.Move.MAX).step(1).tap(new Runnable() { public void run() { pickProjectile(mv); } })
                .onChange(new Stepper.OnValue() { public void on(final double v) {
                    editProjMove(mv, new Runnable() { public void run() { mv.projNormal = (int) v; } });
                    show(type, idx, flag, occ);
                    onChanged.run();
                } }).value(mv.projNormal));
        note("Segure − ou + para percorrer os ANOs; toque no número para escolher na grade de animações.");
        final Ano pa = view.anoAt(mv.projNormal);
        if (pa != null && pa.present) {
            AnimPreview pv = new AnimPreview(c);
            pv.set(view.packDac(2), view.packSprites(2), mv.projNormal);
            LinearLayout l = line();
            l.addView(pv, new LinearLayout.LayoutParams(dp(84), dp(84)));
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            l.addView(col, new LinearLayout.LayoutParams(-2, -2));
            col.addView(btn("✎ EDITAR ANIMACAO", true, new View.OnClickListener() { public void onClick(View v) {
                if (nav != null) nav.openAno(mv.projNormal, true);
            } }));
        } else {
            note("Esta ANO esta vazia ou nao existe.");
        }

        // 4. posicao e velocidade
        head("Posição e velocidade");
        // jogo (md 969): projetil principal nasce em x do atacante + x do hit; se cair ATRAS do atacante, vai para 480 px a frente.
        // Sub-projeteis (hit flag 0 numa ANO de projetil) nao tem essa regra; com ATK_FLAGS 32/64 o x/y do hit e ignorado.
        final boolean mainSpawn = !isProjectileAno(a.index, mv) && (mv.flags & (32 | 64)) == 0;
        LinearLayout xy = line();
        xy.addView(axisLabel("x"));
        if (mainSpawn) {
            stepIn(xy, new Stepper(c).range(0, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { editCoords(o, pat, 0, (int) v); } }).value(Math.max(0, h.x)));
        } else {
            stepIn(xy, new Stepper(c).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { editCoords(o, pat, 0, (int) v); } }).value(h.x));
        }
        xy.addView(axisLabel("y"));
        stepIn(xy, new Stepper(c).range(-32768, 32767).step(1).keyboard(new Stepper.OnValue() { public void on(double v) { editCoords(o, pat, 1, (int) v); } }).value(h.y));
        if (mainSpawn) note("x fica entre 0 e à frente do atacante: com x negativo (atrás dele) o jogo lança o projétil a 480 px de distância.");
        else if ((mv.flags & (32 | 64)) != 0) note("Com as flags de nascer no oponente (32/64) o x/y deste ponto é ignorado.");
        note("y: se o projétil ficar abaixo do chão o jogo o puxa para o chão a cada tick.");
        if (pa != null && pa.present && pa.mpts.length > 0) {
            Ano.Mpt f0 = pa.mpts[0];
            double sp = (f0.flags & 4) != 0 && (f0.moveMask & 1) != 0 ? f0.speedX / 65536.0 : 0;
            final int anoIdx = pa.index;
            lab("VELOCIDADE (px/tick)");
            put(new Stepper(c).range(-9999, 9999).step(1).keyboard(new Stepper.OnValue() { public void on(double v) {
                Ano cp = view.anoAt(anoIdx);
                if (cp == null) return;
                Ano.Mpt[] nm = cp.mpts.clone();
                Ano.Mpt m0 = nm[0].copy();
                m0.flags |= 4;
                m0.moveMask |= 1;
                m0.speedX = (int) (v * 65536.0);
                m0.normalize();
                nm[0] = m0;
                view.replaceAnoAt(new Ano(cp.index, true, cp.flags, cp.priority, cp.links, nm));
                onChanged.run();
            } }).value(sp));
            note("Velocidade horizontal inicial (px/tick) do primeiro sprite do projetil.");
        }

        // 5. perseguicao
        head("Perseguição");
        final boolean homing = mv.homing == 0;
        line().addView(btn(homing ? "● persegue o oponente" : "○ persegue o oponente", homing, new View.OnClickListener() { public void onClick(View v) {
            editProjMove(mv, new Runnable() { public void run() { mv.homing = homing ? 1 : 0; } });
            show(type, idx, flag, occ);
            onChanged.run();
        } }));
        if (homing) {
            lab("VELOCIDADE DE GIRO");
            put(new Stepper(c).range(0, CharData.Move.MAX).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
                editProjMove(mv, new Runnable() { public void run() { mv.homingSpeed = (int) v; } });
                onChanged.run();
            } }).value(mv.homingSpeed));
        }
        lab("REPETIÇÕES (MAX_REPETICOES)");
        put(new Stepper(c).range(0, CharData.Move.MAX).step(1).keyboard(new Stepper.OnValue() { public void on(final double v) {
            editProjMove(mv, new Runnable() { public void run() { mv.maxRep = (int) v; } });
            onChanged.run();
        } }).value(mv.maxRep));
        note("Repetições do projétil: usa a janela 512 do frame, então o agarrão fica indisponível.");

        // 6. sequencia
        projSeqBlock(mv);
        if (focusOn) scrollBodyToEnd();
    }

    /** SEQ_PROJETIL (ANIM_AO_ACERTAR do BIN): fim do menu do projetil. */
    private void projSeqBlock(final CharData.Move mv) {
        head("Sequência do projétil (SEQ_PROJETIL)");
        note("SEQ_PROJETIL: " + anoText(mv.animAoAcertar));
        note("Quando o primeiro acerto de cada projétil conecta, o atacante troca para esta ANO (vale para o golpe todo). A SEQ vem logo depois, a não ser que o primeiro frame desta ANO tenha uma hitbox flag 38. Aceita qualquer ANO do DAC (campo de 16 bits).");
        LinearLayout r = line();
        final boolean any = mv.animAoAcertar != 0;
        r.addView(btn(any ? "✎ Editar SEQ_PROJETIL" : "+ SEQ_PROJETIL", true, new View.OnClickListener() { public void onClick(View v) { projSeqDialog(mv); } }));
        r.addView(btn("⇢ VER FLUXO", false, new View.OnClickListener() {
            public void onClick(View v) { if (c instanceof android.app.Activity) FlowDialog.show((android.app.Activity) c, view, nav, new Runnable() { public void run() { show(type, idx, flag, occ); onChanged.run(); } }); }
        }));
    }

    private void projSeqDialog(final CharData.Move mv) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(8), dp(16), dp(4));
        TextView info = new I18nTextView(c);
        info.setText("Para qual ANO o atacante vai quando o projétil acerta (0 = nenhuma). Aceita qualquer ANO do DAC (campo de 16 bits).");
        info.setTextColor(LayoutManager.DIM);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        col.addView(info);
        final android.widget.EditText e = ano255(mv.animAoAcertar);
        col.addView(tvLabel("SEQ_PROJETIL"));
        col.addView(e);
        final android.app.AlertDialog dlg = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("SEQ_PROJETIL").setView(col)
                .setNegativeButton("CANCELAR", null).setPositiveButton("SALVAR", null).create();
        dlg.show();
        styleDialog(dlg);
        android.widget.Button pos = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
        if (pos != null) {
            pos.setTextColor(LayoutManager.ACCENT);
            pos.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                final int val = parse255(e);
                dlg.dismiss();
                editProjMove(mv, new Runnable() { public void run() { mv.animAoAcertar = val; } });
                show(type, idx, flag, occ);
                onChanged.run();
            } });
        }
    }

    private void projField(String name, final CharData.Move mv, final int f) {
        int v;
        switch (f) {
            case 0: v = mv.projAoAcertar; break;
            case 1: v = mv.projChao; break;
            case 2: v = mv.projAbaixo; break;
            case 3: v = mv.projAcima; break;
            case 4: v = mv.projGlobal; break;
            case 5: v = mv.subId; break;
            case 6: v = mv.subAoAcertar; break;
            case 7: v = mv.subChao; break;
            default: v = mv.maxRep; break;
        }
        num(line(), name, v, 1, new Setter() { public void set(final double x) {
            view.editMove(new Runnable() { public void run() {
                int iv = (int) x;
                switch (f) {
                    case 0: mv.projAoAcertar = iv; break;
                    case 1: mv.projChao = iv; break;
                    case 2: mv.projAbaixo = iv; break;
                    case 3: mv.projAcima = iv; break;
                    case 4: mv.projGlobal = iv; break;
                    case 5: mv.subId = iv; break;
                    case 6: mv.subAoAcertar = iv; break;
                    case 7: mv.subChao = iv; break;
                    default: mv.maxRep = iv; break;
                }
            } });
            onChanged.run();
        } });
    }

    /** Lista de ANOs do personagem com a previa animada de cada uma. */
    private void pickProjectile(final CharData.Move mv) {
        final Dac dac = view.packDac(2);
        if (dac == null) return;
        final int[] chosen = {-1};
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        LinearLayout grid = animGrid(dac, view.packSprites(2), 0, dac.size() - 1, "ANO ", mv.projNormal, new AnimPick() { public void on(int ano) {
            chosen[0] = ano;
            dlg[0].dismiss();
            editProjMove(mv, new Runnable() { public void run() { mv.projNormal = chosen[0]; } });
            show(type, idx, flag, occ);
            onChanged.run();
        } });
        dlg[0] = dialog("Animacao do projetil", grid);
    }

    // ---- efeitos ----

    private interface AnimPick { void on(int ano); }

    private android.app.AlertDialog dialog(String title, View content) {
        ScrollView sv = new ScrollView(c);
        sv.addView(content);
        android.app.AlertDialog dlg = new I18nBuilder(c, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title).setView(sv).setNegativeButton("FECHAR", null).create();
        dlg.show();
        styleDialog(dlg);
        return dlg;
    }

    /** Mesmas cores do resto do app (fundo do painel, botao de destaque). */
    private void styleDialog(android.app.AlertDialog dlg) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        dlg.getWindow().setBackgroundDrawable(bg);
        android.widget.Button b = dlg.getButton(android.app.AlertDialog.BUTTON_NEGATIVE);
        if (b != null) b.setTextColor(LayoutManager.ACCENT);
        int tid = c.getResources().getIdentifier("alertTitle", "id", "android");
        View tv = tid == 0 ? null : dlg.findViewById(tid);
        if (tv instanceof TextView) ((TextView) tv).setTextColor(LayoutManager.TEXT);
    }

    /** Grade de previas animadas (4 por linha) das ANOs presentes em [first, last] do DAC. */
    private LinearLayout animGrid(Dac dac, SpriteCache sp, int first, int last, String prefix, int selectedAno, final AnimPick pick) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout row = null;
        int n = 0;
        for (int a = first; a <= last; a++) {
            Ano an = dac.getAno(a);
            if (an == null || !an.present || an.mpts.length == 0) continue;
            if (n % 4 == 0) {
                row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(row);
            }
            n++;
            final int ano = a;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(2), dp(2), dp(4));
            GradientDrawable g = new GradientDrawable();
            g.setColor(a == selectedAno ? 0xFF1E3A66 : 0x00000000);
            g.setCornerRadius(dp(6));
            cell.setBackground(g);
            AnimPreview pv = new AnimPreview(c);
            pv.set(dac, sp, a);
            cell.addView(pv, new LinearLayout.LayoutParams(dp(68), dp(68)));
            TextView lab = new I18nTextView(c);
            lab.setText(prefix + a);
            lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            lab.setTextColor(LayoutManager.DIM);
            lab.setGravity(Gravity.CENTER);
            cell.addView(lab);
            cell.setClickable(true);
            cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pick.on(ano); } });
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        if (n == 0) {
            TextView none = new I18nTextView(c);
            none.setText("Nenhuma animacao disponivel neste pacote.");
            none.setTextColor(LayoutManager.DIM);
            col.addView(none);
        }
        return col;
    }

    private void effect(Ano a, final ObjModel.Obj o, int pat) {
        final int pack = ObjModel.fxPack(o.flag);
        final int ano = ObjModel.fxAno(o.flag);
        LinearLayout l = line();
        AnimPreview pv = new AnimPreview(c);
        pv.set(view.packDac(pack), view.packSprites(pack), ano);
        l.addView(pv, new LinearLayout.LayoutParams(dp(92), dp(92)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        l.addView(col, new LinearLayout.LayoutParams(-2, -2));
        TextView nm = new I18nTextView(c);
        nm.setText(ObjModel.fxLabel(o.flag) + "  ·  " + ObjModel.fxPackName(pack, ano));
        nm.setTextColor(LayoutManager.TEXT);
        nm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        nm.setPadding(dp(6), 0, 0, dp(2));
        col.addView(nm);
        col.addView(btn("TROCAR EFEITO", true, new View.OnClickListener() { public void onClick(View v) { pickEffect(o); } }));
        if (pack == 2) col.addView(btn("✎ EDITAR EFEITO", false, new View.OnClickListener() { public void onClick(View v) {
            if (nav != null) nav.openEffect(ano);
        } }));
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        num(line(), "x", h.x, 1, coord(o, pat, 0));
        num(line(), "y", h.y, 1, coord(o, pat, 1));
        note("O efeito nasce junto com este objeto, na posicao relativa ao personagem, e some quando o objeto termina.");
    }

    private void pickEffect(final ObjModel.Obj o) {
        LinearLayout all = new LinearLayout(c);
        all.setOrientation(LinearLayout.VERTICAL);
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        // grupos: EFFECT, CHARF, auras do personagem (ANO 201..208) e efeitos do personagem (209+)
        int[][] groups = {
            {0, ObjModel.fxAno(ObjModel.FX_GENERAL_FIRST), ObjModel.fxAno(ObjModel.FX_GENERAL_LAST)},
            {1, ObjModel.fxAno(ObjModel.FX_CHARF_FIRST), ObjModel.fxAno(ObjModel.FX_CHARF_LAST)},
            {2, ObjModel.fxAno(ObjModel.FX_CHAR_FIRST), 208},
            {2, 209, ObjModel.fxAno(ObjModel.FX_CHAR_LAST)}};
        for (int gi = 0; gi < groups.length; gi++) {
            final int pk = groups[gi][0];
            int a0 = groups[gi][1], a1 = groups[gi][2];
            TextView h = head(ObjModel.fxPackName(pk, a0));
            body.removeView(h);
            all.addView(h);
            Dac dac = view.packDac(pk);
            if (dac == null) {
                TextView none = new I18nTextView(c);
                none.setText("pacote nao carregado");
                none.setTextColor(LayoutManager.DIM);
                none.setPadding(dp(6), 0, 0, dp(6));
                all.addView(none);
                continue;
            }
            all.addView(animGrid(dac, view.packSprites(pk), a0, a1, "", o.flag >= 0 && ObjModel.fxPack(o.flag) == pk ? ObjModel.fxAno(o.flag) : -1, new AnimPick() { public void on(int ano) {
                dlg[0].dismiss();
                int nf = ObjModel.fxFlag(pk, ano);
                Ano cu = cur();
                if (cu == null) return;
                view.replaceMpts(ObjModel.setFlag(cu.mpts, o, nf));
                int nocc = ObjModel.count(cur().mpts[o.f0], nf) - 1;
                flag = nf;
                occ = Math.max(0, nocc);
                tl.select(TimelineView.T_OBJ, -1, flag, occ);
                refresh();
            } }));
        }
        dlg[0] = dialog("Escolher efeito", all);
    }

    // ---- acoes especiais ----

    private String describe(int f) {
        switch (f) {
            case 3: case 4: case 5: return "Faz o fundo tremer enquanto o objeto existe. Escolha a intensidade.";
            case 20: return "Dispara uma cutscene: a linha EVENTO do HDAT 13 do personagem (ANO, duracao, camera, stun). X/y e o ponto onde a cena nasce (espelhado pelo lado do objeto).";
            case 26: return "O defensor (CPU ou jogador) nao consegue defender enquanto este golpe esta ativo.";
            case 27: return "Enquanto ativo, o golpe nao pode ser cancelado.";
            case 28: return "O dano deste golpe ignora o ataque e a defesa.";
            case 30: case 31: return "Aproxima a camera enquanto o item estiver ativo. Frames = tempo da transicao ate o zoom; a duracao e a do proprio item na timeline.";
            case 32: return "O personagem toma dano proprio (quantidade em DANO do sprite).";
            case 33: return "Controla a trava cinematica dos golpes 9 a 12 (o jogo trava tudo e da zoom na camera): x/y = centro da camera a partir da posicao do personagem (x espelha com o flip), zoom % e duracao da trava em ticks. Sem esta acao a trava dura 120 ticks com zoom de 200%. A volta ao zoom normal leva sempre 12 ticks. Fica no frame 0 do ANO inicial do golpe. Precisa do patch no jogo.";
            case 34: return "Cura vida do personagem (quantidade em DANO do sprite).";
            case 37: return "Os acertos deste golpe nao contam no combo.";
            case 38: return "Bloqueia a sequencia: impede encadear o proximo golpe.";
            case 39: return "Teleporta o personagem ate o oponente, com deslocamento (x espelha com o flip, como em Puxar oponente). Com x e y em 0 vai exatamente ate a posicao dele. O deslocamento precisa do patch no jogo.";
            case 40: return "Puxa o oponente ate o personagem, com deslocamento.";
            case ObjModel.VF_WINDOW: return describeWindow();
            case ObjModel.VF_SCENE: return "Esconde as camadas do cenario (fundo) enquanto este objeto estiver ativo e a camera passa para a prioridade 1 (tela limpa dos golpes especiais). Tambem desliga o impacto na parede dos dois lutadores. A preview do editor nao desenha o cenario.";
            case ObjModel.VF_WALL: return "Impacto na parede: toca o som 6, zera o cancelamento do oponente e cria a poeira de impacto na borda da tela. Precisa ter um ataque que jogue o oponente na parede (o jogo ignora o frame se o personagem nao estiver batendo na parede). Disponivel so nas ANOs de reacao do gamedata com velocidade/aceleracao X.";
            default:
                if (ObjModel.isDust(f)) return "Poeira / fumaca: cria um efeito de fumaca na posicao do personagem (vira para o lado em que ele olha). Escolha o tipo abaixo (1 a 15). Tipos 1-5: pacote bobj ANOs 10-14; 6-7: effect ANOs 78-79; 8-15: effect ANOs 70-77. Cada frame com a flag cria um novo efeito.";
                return "Acao sem nome conhecido.";
        }
    }

    private String describeWindow() {
        AttackData ad = view.attackData();
        switch (ObjModel.windowUseOf(ad == null ? null : ad.move, ad == null ? -1 : ad.moveIndex)) {
            case ObjModel.WIN_GRAB:
                return "Tentar agarrão: nos frames deste objeto, no ANO inicial do golpe, o personagem vai para o lado do oponente (na altura dele) e segue para o ANO seguinte (ANIM_INICIAL + 1), sem esperar o ANO inicial acabar. Com a flag 8 vale mesmo sem acertar; com a 128 só se o oponente estiver em reação de dor deste golpe.";
            case ObjModel.WIN_REPEAT:
                return "O frame com essa função permite repetir o lançamento do projétil. A repetição alterna sempre entre os ANOs 40 e 41."
                        + (ad != null && ad.moveIndex == 3 ? " No golpe 3 (no ar), em teste a repetição só funcionou com a janela maior: estenda este objeto por mais frames." : "");
            case ObjModel.WIN_CONFLICT:
                return "Conflito: este golpe tem agarrão (flag 8/128) e repetição de projétil (MAX_REPETICOES > 0), e os dois usam a mesma janela 512. Escolha um dos dois nas OPÇÕES do golpe.";
            default:
                return "Janela 512 (cancel). Neste golpe nenhuma opção a usa; ela é só preservada.";
        }
    }

    private void action(Ano a, final ObjModel.Obj o, int pat) {
        note(ObjModel.isBehindNew(o) ? "Teleporta o PERSONAGEM para tras do oponente: vai ate a posicao dele (flag 39), vira o sprite (Flip X) e a speed X do frame o leva para o outro lado, na distancia abaixo. O oponente nao e movido. Hit, Flip X e speed X pertencem a este item: ao remove-lo os tres saem. Vale em um frame so; se ele tem mais de 1 tick a distancia se reparte pelos ticks."
                : o.behind ? "Formato antigo: puxa o OPONENTE para o x negativo (atras do personagem) e vira o sprite (Flip X); o oponente aparece do outro lado do mapa. Apague e adicione de novo para usar o formato atual (o personagem vai ate o oponente)."
                : describe(o.flag));
        int f = o.flag;
        if (f == ObjModel.VF_WINDOW) {
            AttackData wd = view.attackData();
            if (wd != null && wd.move != null && ObjModel.windowUseOf(wd.move, wd.moveIndex) == ObjModel.WIN_REPEAT)
                projField("Quantidade máxima de repetições", wd.move, 8);
            if (wd != null && wd.move != null && ObjModel.windowUseOf(wd.move, wd.moveIndex) == ObjModel.WIN_GRAB)
                grabDistanceField();
            return;
        }
        if (f == ObjModel.VF_SCENE || f == ObjModel.VF_WALL) return;
        if (ObjModel.isDust(f)) {
            head("Tipo de poeira");
            int cur = f - ObjModel.VF_DUST;
            LinearLayout row = null;
            for (int t = 1; t <= 15; t++) {
                if ((t - 1) % 5 == 0) { row = new LinearLayout(c); row.setOrientation(LinearLayout.HORIZONTAL); body.addView(row); }
                row.addView(dustCell(o, t, t == cur), new LinearLayout.LayoutParams(0, -2, 1f));
            }
            note(dustSource(cur) + ". Tipos 1 a 5 usam a pasta bobj do cenário; se ela não existe em assets, nada é desenhado (como no jogo sem esse pacote). O jogo usa a ANO + 80 quando o personagem está virado.");
            return;
        }
        Ano.Hit h = ObjModel.find(a.mpts[pat], o.flag, o.occ);
        if (f >= 3 && f <= 5) {
            LinearLayout l = line();
            String[] nm = {"leve", "medio", "forte"};
            for (int k = 0; k < 3; k++) l.addView(btn(nm[k], f == 3 + k, convertAction(o, 3 + k)));
        } else if (f == 20) {
            num(line(), "evento", h.width, 1, coord(o, pat, 2));
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
            AttackData ad20 = view.attackData();
            if (ad20 != null && ad20.attacker != null) note(CutsceneInfo.describe(ad20.attacker.data, h.width, h.x, h.y, isProjectileAno(a.index, ad20.move)));
            final Setter evSet = coord(o, pat, 2);
            line().addView(btn("EDITAR EVENTOS (HDAT 13)", true, new View.OnClickListener() { public void onClick(View v) {
                if (!(c instanceof android.app.Activity)) return;
                CutsceneScreen.show((android.app.Activity) c, view, ObjModel.find(cur().mpts[pat], o.flag, o.occ) == null ? 0 : ObjModel.find(cur().mpts[pat], o.flag, o.occ).width, new CutsceneScreen.Use() {
                    public void on(int ev) { evSet.set(ev); }
                });
            } }));
        } else if (f == 30 || f == 31) {
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
            num(line(), "zoom %", h.width, 1, coord(o, pat, 2));
            num(line(), "frames", h.height, 1, coord(o, pat, 3));
        } else if (ObjModel.isBehindNew(o)) {
            num(line(), "distância (px)", ObjModel.behindDistance(a.mpts[pat]), 1, new Setter() { public void set(double v) {
                view.replaceMpts(ObjModel.setBehindDistance(cur().mpts, o.f0, (int) v));
                show(type, idx, flag, occ);
            } });
            AttackData bd = view.attackData();
            if (bd != null && bd.move != null && (bd.move.flags & 16) == 0)
                note("Dica: o jogo separa os dois corpos quando eles se sobrepõem e empurra o oponente. Ligue \"Personagens se atravessam\" em GOLPE SET para ele ficar parado.").setTextColor(C_AMBER);
        } else if (f == 33) {
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
            num(line(), "zoom %", h.width, 1, coord(o, pat, 2));
            num(line(), "duração da trava (ticks)", h.height, 1, coord(o, pat, 3));
            AttackData ad33 = view.attackData();
            if (ad33 != null && ad33.move != null && !ad33.move.generic && !(ad33.moveIndex >= 9 && ad33.moveIndex <= 12))
                note("Só vale em golpes com trava cinemática (golpes 9 a 12 do HDAT 4).").setTextColor(C_AMBER);
        } else if (f == 39 && !o.behind) {
            num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
        } else if (f == 32 || f == 34) {
            num(line(), "quantidade", ObjModel.optField(a.mpts[pat], 0), 1, optSetter(pat, 0));
        } else if (f == 40) {
            if (o.behind) {         // Teleportar atras: o x e sempre negativo (so aqui; o Puxar oponente comum nao tem limite)
                final Setter xs = coord(o, pat, 0);
                num(line(), "x", h.x, 1, new Setter() { public void set(double v) {
                    if (v >= 0) { I18nUi.toast(c, "No Teleportar atras o x precisa ser negativo", android.widget.Toast.LENGTH_SHORT).show(); v = -1; }
                    xs.set(v);
                    show(type, idx, flag, occ);
                } });
            } else num(line(), "x", h.x, 1, coord(o, pat, 0));
            num(line(), "y", h.y, 1, coord(o, pat, 1));
        }
        line().addView(btn("trocar acao", false, new View.OnClickListener() { public void onClick(View v) {
            final String[] names = new String[ObjModel.ACTION_FLAGS.length];
            for (int i = 0; i < names.length; i++) names[i] = ObjModel.actionName(ObjModel.ACTION_FLAGS[i]);
            new I18nBuilder(c).setTitle("Acao especial").setItems(names, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface dlg, int which) { convertAction(o, ObjModel.ACTION_FLAGS[which]).onClick(null); }
            }).show();
        } }));
    }

    /** "bobj 12" / "effect 78": de onde vem a arte da poeira do tipo. */
    static String dustSource(int type) {
        int pack = ObjModel.dustPack(type);
        return pack < 0 ? "" : (pack == 0 ? "bobj " : "effect ") + ObjModel.dustAno(type);
    }

    /** Cartao do tipo de poeira: previa animada (bobj ou effect), numero do tipo e de onde vem; o atual vem destacado. */
    private View dustCell(final ObjModel.Obj o, final int type, boolean current) {
        LinearLayout cell = new LinearLayout(c);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(dp(2), dp(2), dp(2), dp(4));
        GradientDrawable g = new GradientDrawable();
        g.setColor(current ? 0xFF1E3A66 : 0x00000000);
        g.setCornerRadius(dp(6));
        if (current) g.setStroke(dp(2), LayoutManager.ACCENT);
        cell.setBackground(g);
        int pack = ObjModel.dustPack(type);
        Dac dac = view.packDac(pack == 0 ? 3 : 0);
        Ano an = dac == null ? null : dac.getAno(ObjModel.dustAno(type));
        if (an != null && an.present && an.mpts.length > 0) {
            AnimPreview pv = new AnimPreview(c);
            pv.set(dac, view.packSprites(pack == 0 ? 3 : 0), ObjModel.dustAno(type));
            cell.addView(pv, new LinearLayout.LayoutParams(dp(60), dp(60)));
        } else {
            TextView e = new I18nTextView(c);
            e.setText(pack == 0 && dac == null ? "sem bobj" : "vazio");
            e.setGravity(Gravity.CENTER);
            e.setTextColor(LayoutManager.DIM);
            e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            e.setBackgroundColor(0xFF0D0F13);
            cell.addView(e, new LinearLayout.LayoutParams(dp(60), dp(60)));
        }
        TextView lab = new I18nTextView(c);
        lab.setText(type + " · " + dustSource(type));
        lab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        lab.setTextColor(current ? LayoutManager.ACCENT : LayoutManager.DIM);
        lab.setGravity(Gravity.CENTER);
        cell.addView(lab);
        cell.setClickable(true);
        cell.setOnClickListener(convertAction(o, ObjModel.VF_DUST + type));
        return cell;
    }

    private View.OnClickListener convertAction(final ObjModel.Obj o, final int newFlag) { return convert(o, newFlag); }

    // ---- sequencia ----

    private static int moveField(CharData.Move mv, int kind, boolean air, int which) {
        switch (kind) {
            case SeqMark.SEQ: return air ? mv.animSeqAr : mv.animSeqChao;
            case SeqMark.END: return air ? mv.animEndAr : mv.animEndChao;
            case SeqMark.HIT: return mv.animAoAcertar;
            default: return which == 0 ? mv.pousoErrar : mv.pousoAcertar;
        }
    }

    private static void setMoveField(CharData.Move mv, int kind, boolean air, int which, int x) {
        switch (kind) {
            case SeqMark.SEQ: if (air) mv.animSeqAr = x; else mv.animSeqChao = x; break;
            case SeqMark.END: if (air) mv.animEndAr = x; else mv.animEndChao = x; break;
            case SeqMark.HIT: mv.animAoAcertar = x; break;
            default: if (which == 0) mv.pousoErrar = x; else mv.pousoAcertar = x;
        }
    }

    private void moveNum(String label, final SeqMark m, final int which) {
        num(line(), label, moveField(view.attackData().move, m.kind, m.air, which), 1, new Setter() { public void set(final double v) {
            final int x = Math.max(0, Math.min(CharData.Move.MAX, (int) v));
            view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) { setMoveField(mv, m.kind, m.air, which, x); } });
            show(type, idx, flag, occ);
            onChanged.run();
        } });
    }

    /** Campo da distancia do agarrao (HDAT 3, byte 5): usado no menu da janela "Tentar agarrao" e no da marca na faixa de transicao. */
    private void grabDistanceField() {
        final AttackData ad = view.attackData();
        if (ad == null) return;
        num(line(), "Distância do agarrão (px)", ad.attacker.data.pullDistance(), 1, new Setter() { public void set(double v) {
            view.setPullDistance((int) Math.max(0, Math.min(255, v)));
            show(type, idx, flag, occ);
            onChanged.run();
        } });
    }

    private void grabPanel(final SeqMark m) {
        note("Agarrão (flag 8 ou 128 do GOLPE SET): no fim do ANO inicial — ou no 1º frame com a janela 512 (\"Tentar agarrão\") — o atacante vai para o lado do oponente e segue para o ANO " + m.target + " (ANIM_INICIAL + 1). A distância vem do HDAT 3 do personagem e vale para todos os golpes dele.");
        grabDistanceField();
        LinearLayout r = line();
        final int tgt = m.target;
        r.addView(btn("✎ EDITAR ANO " + tgt, true, new View.OnClickListener() { public void onClick(View v) { if (nav != null) nav.openAno(tgt, false); } }));
    }

    private void seqPanel(final Ano a) {
        java.util.List<SeqMark> ms = view.sequenceMarks();
        if (idx < 0 || idx >= ms.size() || view.attackData() == null) { title.setText("TRANSICAO"); note("Sem marcador aqui."); return; }
        final SeqMark m = ms.get(idx);
        final int kind = m.kind;
        if (m.incoming) {
            title.setText("ENTRADA  ·  " + m.label().substring(2));
            note("Esta ANO foi alcançada no tick " + m.tick + " pela troca " + new String[]{"SEQ", "END", "SEQ_PROJETIL (ao acertar)", "POUSO", "QUEDA", "AGARRAR"}[kind]
                    + ", vinda da ANO " + m.fromAno + " (frame " + (m.fromPat + 1) + "). A causa está na timeline daquela ANO.");
            final int fa = m.fromAno;
            LinearLayout rl = line();
            rl.addView(btn("✎ IR PARA ANO " + fa, true, new View.OnClickListener() { public void onClick(View v) { if (nav != null) nav.openAno(fa, false); } }));
            return;
        }
        title.setTextColor(TimelineView.markColor(m));
        title.setText(m.title() + "  ·  frame " + (m.pat + 1) + (kind == SeqMark.LAND || kind == SeqMark.FALL || kind == SeqMark.GRAB ? "" : (m.air ? "  ·  no ar" : "  ·  no chao")) + (m.projectile ? "  ·  projetil" : ""));
        if (kind == SeqMark.GRAB) { grabPanel(m); return; }
        switch (kind) {
            case SeqMark.SEQ: note("Se o hit conectar aqui, o golpe segue para a ANO abaixo (ANIM_SEQ do BIN). Aceita qualquer ANO do DAC (campo de 16 bits)."); break;
            case SeqMark.END: note("Hit durante a sequencia: leva a ANO abaixo (ANIM_END do BIN). Aceita qualquer ANO do DAC (campo de 16 bits)."); break;
            case SeqMark.HIT: note("SEQ_PROJETIL: o primeiro acerto do projetil troca o atacante para esta ANO (ANIM_AO_ACERTAR do BIN, vale para o golpe todo). Aceita qualquer ANO do DAC (campo de 16 bits)."); break;
            case SeqMark.LAND: note("Onde o atacante toca o chao. ANO do pouso ao errar / ao acertar (0 = pouso padrao, ANO 13). Aceita qualquer ANO do DAC (campo de 16 bits)."); break;
            default: note("O atacante terminou a animacao no ar e cai: o jogo toca a ANO 89 (fixa, nao editavel)."); break;
        }
        if (m.real) note("Esta troca acontece de fato na simulacao (tick " + m.tick + ").");
        if (m.blocked) note("BLOQUEADA: este frame tem a flag 38, entao a troca nao dispara.");
        if (kind == SeqMark.FALL) return;
        if (kind == SeqMark.LAND) { moveNum("errar", m, 0); moveNum("acertar", m, 1); }
        else moveNum("ANO", m, 0);
        LinearLayout r = line();
        final int pat = m.pat;
        r.addView(btn("✎ EDITAR ANO", true, new View.OnClickListener() { public void onClick(View v) {
            CharData.Move mv = view.attackData().move;
            int t = moveField(mv, kind, m.air, 0);
            if (kind == SeqMark.LAND && t == 0) t = 13;
            if (nav != null && t > 0) nav.openAno(t, false);
        } }));
        if (kind == SeqMark.LAND) {
            r.addView(btn("EDITAR (acertar)", false, new View.OnClickListener() { public void onClick(View v) {
                int t = view.attackData().move.pousoAcertar;
                if (t == 0) t = 13;
                if (nav != null) nav.openAno(t, false);
            } }));
            r.addView(btn("PADRAO (13)", false, new View.OnClickListener() { public void onClick(View v) {
                view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) { mv.pousoErrar = 0; mv.pousoAcertar = 0; } });
                show(type, idx, flag, occ);
                onChanged.run();
            } }));
            return;
        }
        r.addView(btn(m.blocked ? "DESBLOQUEAR SEQUÊNCIA" : "BLOQUEAR SEQUÊNCIA", m.blocked, new View.OnClickListener() { public void onClick(View v) {
            Ano cu = cur();
            if (cu == null || pat >= cu.mpts.length) return;
            Ano.Mpt n = cu.mpts[pat].copy();
            java.util.ArrayList<Ano.Hit> hl = new java.util.ArrayList<Ano.Hit>();
            boolean had = false;
            for (Ano.Hit h : n.hits) { if (h.flag == 38) had = true; else hl.add(h); }
            if (!had) { Ano.Hit h = new Ano.Hit(); h.flag = 38; hl.add(h); n.flags |= 0x10; }
            else if (hl.isEmpty()) n.flags &= ~0x10;
            n.hits = hl.toArray(new Ano.Hit[0]);
            n.normalize();
            view.changeMpt(pat, n);
            show(type, idx, flag, occ);
            onChanged.run();
        } }));
        r.addView(btn("APAGAR", false, new View.OnClickListener() { public void onClick(View v) {
            view.editMove(new AttackView.MoveEdit() { public void apply(CharData.Move mv) {
                if (kind == SeqMark.SEQ) { mv.animSeqAr = 0; mv.animSeqChao = 0; }
                else if (kind == SeqMark.END) { mv.animEndAr = 0; mv.animEndChao = 0; }
                else mv.animAoAcertar = 0;
            } });
            onClose.run();
            onChanged.run();
        } }));
    }

    // ---- links (animacao ligada) ----

    private void link(final Ano a) {
        if (idx < 0 || idx >= a.links.length) { note("Esta ANO nao tem animacoes ligadas."); return; }
        final Ano.Link l = a.links[idx];
        note("Uma animacao ligada toca junto com esta, sincronizada.");
        num(line(), "ANO", l.getAno(), 1, linkSetter(a, 2));
        LinearLayout e = line();
        e.addView(btn("✎ EDITAR ANIMACAO", true, new View.OnClickListener() { public void onClick(View v) { if (nav != null) nav.openAno(l.getAno(), false); } }));
        num(line(), "base x", l.baseX, 1, linkSetter(a, 0));
        num(line(), "base y", l.baseY, 1, linkSetter(a, 1));
        LinearLayout r = line();
        r.addView(btn("nao herda a posicao (0,0)", l.spawnPos(), new View.OnClickListener() { public void onClick(View v) { linkFlag(a, 0x1000); } }));
        r.addView(btn("segue o personagem", l.syncXY(), new View.OnClickListener() { public void onClick(View v) { linkFlag(a, 0x4000); } }));
        r.addView(btn("sincroniza sprites", l.syncMpt(), new View.OnClickListener() { public void onClick(View v) { linkFlag(a, 0x8000); } }));
    }

    private Setter linkSetter(final Ano a, final int field) {
        return new Setter() { public void set(double v) {
            Ano.Link[] n = a.links.clone();
            Ano.Link o = n[idx];
            int x = (int) v;
            if (field == 0) n[idx] = new Ano.Link(x, o.baseY, o.flags);
            else if (field == 1) n[idx] = new Ano.Link(o.baseX, x, o.flags);
            else n[idx] = new Ano.Link(o.baseX, o.baseY, (o.flags & ~0xFFF) | (x & 0xFFF));
            applyLinks(a, n, idx);
        } };
    }

    private void linkFlag(Ano a, int bitMask) {
        Ano.Link[] n = a.links.clone();
        Ano.Link o = n[idx];
        n[idx] = new Ano.Link(o.baseX, o.baseY, o.flags ^ bitMask);
        applyLinks(a, n, idx);
    }

    private void applyLinks(Ano a, Ano.Link[] n, int sel) {
        int fl = n.length > 0 ? (a.flags | 2) : (a.flags & ~2);
        view.replaceAno(new Ano(a.index, true, fl, a.priority, n, a.mpts));
        idx = n.length == 0 ? -1 : Math.min(sel, n.length - 1);
        if (idx < 0) { onClose.run(); onChanged.run(); return; }
        show(type, idx, flag, occ);
        onChanged.run();
    }
}
