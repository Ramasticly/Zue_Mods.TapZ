package com.zue.attackeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/**
 * Timeline baseada em sprite (estilo editor de video).
 * - A ANO e a duracao total; o tempo e mostrado em segundos (60 ticks = 1 s).
 * - Cada SPRITE e um clipe amarelo. Tocar nele expande a timeline: audio, velocidade, estilo (espelhar...),
 *   e os objetos (hitbox, hurtbox, projetil, efeitos, acoes especiais) ligados a ela, cada um em sua linha.
 * - Um objeto que se mantem entre sprites vira uma linha unica; as mudancas de posicao/tamanho acontecem so entre sprites (sem marcas na linha).
 * - O ponteiro fica fixo no centro; arrastar a timeline "scrubba". Arraste na vertical para rolar as linhas.
 * - No fim da ANO ficam o botao de LOOP e o de adicionar sprite.
 */
public final class TimelineView extends View {
    public static final int T_NONE = -1, T_SPRITE = 0, T_OBJ = 1, T_SOUND = 2, T_MOVE = 3, T_STYLE = 4, T_LINK = 5, T_SEQ = 6;

    private static final int R_SPRITE = 0, R_SUMMARY = 1, R_AUDIO = 2, R_MOVE = 3, R_STYLE = 4, R_OBJ = 5, R_LINK = 6, R_SEQ = 7;
    private static final int C_SPRITE = 0xFFE5C100, C_AUDIO = 0xFF3D8BFF, C_MOVE = 0xFF3DDC84, C_STYLE = 0xFFFF9A3C, C_LINK = 0xFF2EC4C4;
    private static final float VIEW_DP = 188, RULER_DP = 14, SPRITE_DP = 40, ROW_DP = 22, SUM_DP = 10;

    public interface Listener {
        /** type: T_*; idx: sprite/som/link/velocidade/estilo; flag/occ: objeto. */
        void onSelect(int type, int idx, int flag, int occ);
        void onScrub(int pat, int elapsed);
        /** Toque num clipe [t0, t1): o ponteiro so se mexe se estiver antes (vai ao inicio) ou depois (vai ao fim) dele. */
        void onClip(int t0, int t1);
        /** Aparou o fim do sprite: nova duracao em ticks. */
        void onResize(int frame, int newTime);
        /**
         * Puxou a borda de um objeto (T_OBJ), de um trecho de velocidade (T_MOVE) ou de estilo (T_STYLE): novo intervalo em
         * ticks [t0, t1), sempre em divisoes de sprite. fromFrame = frame onde o item comecava.
         */
        void onTrimRun(int type, int flag, int occ, int fromFrame, int t0, int t1);
        void onLoop(boolean on);
        void onAddSprite();
        /** Toque numa celula vazia (som, velocidade, estilo) de um sprite. */
        void onEmpty(int type, int frame, int axis);
    }

    private static final class Row {
        int type, kind, link, lane;
        float h;
        String label;
        int color;
        ObjModel.Obj obj;
        java.util.List<ObjModel.Obj> group = new java.util.ArrayList<ObjModel.Obj>();
        float top;
    }

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Rect sr = new Rect();
    private final Path path = new Path();
    private final ScaleGestureDetector scaler;
    private final List<Row> rows = new ArrayList<Row>();
    private Listener listener;
    private SpriteCache sprites;

    private Ano ano;
    private int pat = -1, elapsed;
    private int[] start = new int[0];
    private int total;
    private List<ObjModel.Obj> objs = new ArrayList<ObjModel.Obj>();
    private boolean loop, expanded;
    private int selType = T_NONE, selIdx = -1, selFlag = -1, selOcc = -1;
    private float ppt;
    private float scrollY, contentH, desiredH;
    /** Filtro de categorias visiveis: 0 sprites, 1 hitbox, 2 hurtbox, 3 projetil, 4 efeito, 5 acao, 6 som, 7 velocidade, 8 estilo, 9 links. */
    public static final String[] FILTER_NAMES = {"Imagens (sprites)", "Hitboxes", "Hurtboxes", "Projeteis", "Efeitos", "Acoes especiais", "Sons", "Velocidade", "Estilo (espelhar, transformacao)", "Animacoes ligadas", "Transicoes (sequencia, fim, hit)"};
    private final boolean[] show = {true, true, true, true, true, true, true, true, true, true, true};
    static final int C_SEQ = 0xFFFF5D8F, C_END = 0xFFC9869B, C_HIT = 0xFFFF8A66, C_LAND = 0xFF6CB6FF, C_FALL = 0xFFB69CFF, C_FROM = 0xFFC25CD6, C_GRAB = 0xFFFFC857;
    static int markColor(SeqMark m) {
        if (m.incoming) return C_FROM;
        switch (m.kind) { case SeqMark.SEQ: return C_SEQ; case SeqMark.END: return C_END; case SeqMark.HIT: return C_HIT; case SeqMark.LAND: return C_LAND; case SeqMark.GRAB: return C_GRAB; default: return C_FALL; }
    }

    /** Retangulo do marcador i: a largura inteira do frame dele (marcas simultaneas ficam em faixas diferentes). */
    private void markRect(int i, float top, float bottom, RectF out) {
        SeqMark m = seqMarks.get(i);
        float l = xOf(start[m.pat]) + 1, rr = Math.max(xOf(start[m.pat]) + 14 * d, xOf(start[m.pat] + span(m.pat)) - 1);
        out.set(l, top, rr, bottom);
    }
    private List<SeqMark> seqMarks = new ArrayList<SeqMark>();
    private int[] seqLane = new int[0];
    private int seqLaneCount;
    public void setSeqMarks(List<SeqMark> m) {
        seqMarks = m == null ? new ArrayList<SeqMark>() : m;
        int before = seqLaneCount;
        seqLane = seqLanes(seqMarks);
        seqLaneCount = laneCount(seqLane);
        if (ano != null && before != seqLaneCount) { buildRows(); invalidate(); }
    }

    /** Faixa de cada marca: marcas do mesmo frame (pat) vao para faixas diferentes, na ordem; frames diferentes reusam a faixa 0. */
    static int[] seqLanes(List<SeqMark> marks) {
        int[] lane = new int[marks.size()];
        java.util.Map<Integer, Integer> perPat = new java.util.HashMap<Integer, Integer>();
        for (int i = 0; i < lane.length; i++) {
            Integer n = perPat.get(Integer.valueOf(marks.get(i).pat));
            lane[i] = n == null ? 0 : n.intValue();
            perPat.put(Integer.valueOf(marks.get(i).pat), Integer.valueOf(lane[i] + 1));
        }
        return lane;
    }

    /** Quantas faixas as marcas pedem (0 se nao ha marcas). */
    static int laneCount(int[] lane) {
        int n = 0;
        for (int l : lane) n = Math.max(n, l + 1);
        return n;
    }

    /** Altura maxima permitida pela area visivel da pagina (0 = sem limite): evita linhas escondidas fora da tela. */
    private int maxHeightPx;
    public void setMaxHeightPx(int px) {
        if (px == maxHeightPx) return;
        maxHeightPx = px;
        buildRows();
        invalidate();
    }
    private float cap() {
        float c = VIEW_DP * d;
        if (maxHeightPx > 0) c = Math.min(c, Math.max(maxHeightPx, 96f * d));
        if (laneLimit > 0) c = Math.min(c, laneHeightPx(laneLimit));
        return c;
    }

    /** Faixas visiveis por vez (0 = sem limite): a faixa das sprites conta como uma; as demais rolam. */
    private int laneLimit;
    public static final int LANES_MIN = 2, LANES_MAX = 6;
    public void setLaneLimit(int n) {
        n = n <= 0 ? 0 : Math.max(LANES_MIN, Math.min(LANES_MAX, n));
        if (n == laneLimit) return;
        laneLimit = n;
        buildRows();
        invalidate();
    }
    private float laneHeightPx(int n) {
        return (RULER_DP + (show[0] ? SPRITE_DP : ROW_DP) + (n - 1) * ROW_DP + 3) * d;
    }

    /** Quantas faixas cabem conforme a fracao 0..1 de quanto o menu subiu: 6 com o menu baixo, 2 com ele no maximo. */
    public static int lanesFor(float frac) {
        float f = Math.max(0f, Math.min(1f, frac));
        return Math.round(LANES_MAX - f * (LANES_MAX - LANES_MIN));
    }

    public boolean isShown(int cat) { return show[cat]; }
    public void setShown(int cat, boolean on) {
        if (show[cat] == on) return;
        show[cat] = on;
        scrollY = 0;
        buildRows();
        invalidate();
    }
    public void showAll() {
        for (int i = 0; i < show.length; i++) show[i] = true;
        scrollY = 0;
        buildRows();
        invalidate();
    }
    private boolean sawSound;

    private static final int M_NONE = 0, M_SCRUB = 1, M_RESIZE = 2, M_TRIM_L = 3, M_TRIM_R = 4, M_VSCROLL = 5, M_PARENT = 6, M_RESIZE_L = 7;
    private int mode;
    private float downX, downY, lastX, lastY;
    private boolean moved, scaling;
    private float dragTick;
    private int resizeFrame;
    private float resizeDx;
    private int trimT0, trimT1, trimOrig0, trimOrig1, trimType, trimFrom;

    /** Tempo no formato 0.Ns/N ticks. */
    static String timeText(int ticks) {
        return ObjModel.timeText(ticks);
    }

    public TimelineView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        ppt = 4.5f * d;
        t.setTextSize(9.5f * d);
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector g) {
                ppt = Math.max(0.8f * d, Math.min(20f * d, ppt * g.getScaleFactor()));
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener l) { listener = l; }
    public void setSprites(SpriteCache s) { sprites = s; }
    public boolean isExpanded() { return expanded; }
    public int selectedType() { return selType; }
    public int selectedIndex() { return selIdx; }
    public int selectedFlag() { return selFlag; }
    public int selectedOcc() { return selOcc; }
    public List<ObjModel.Obj> objects() { return objs; }

    public void clearSelection() { selType = T_NONE; selIdx = -1; selFlag = -1; selOcc = -1; invalidate(); }
    public void select(int type, int idx, int flag, int occ) {
        selType = type; selIdx = idx; selFlag = flag; selOcc = occ;
        if (type != T_NONE) setExpanded(true);
        invalidate();
    }
    public void setExpanded(boolean e) {
        if (expanded == e) return;
        expanded = e;
        scrollY = 0;
        buildRows();
        invalidate();
    }

    /** Objeto selecionado: o de mesma (flag, occ) que contem o frame do ponteiro; senao o mais proximo. */
    public ObjModel.Obj selectedObj() {
        if (selType != T_OBJ) return null;
        ObjModel.Obj best = null;
        int bd = Integer.MAX_VALUE;
        for (ObjModel.Obj o : objs) {
            if (o.flag != selFlag || o.occ != selOcc) continue;
            int dd = pat < o.f0 ? o.f0 - pat : pat > o.f1 ? pat - o.f1 : 0;
            if (dd < bd) { bd = dd; best = o; }
        }
        return best;
    }

    /** Tick (inteiro) do ponteiro, na ANO atual. */
    public int playheadTick() {
        if (mode == M_SCRUB) return (int) dragTick;
        if (pat < 0 || pat >= start.length) return 0;
        return start[pat] + elapsed + over;
    }

    /** Ticks alem do fim da ANO (transicao travada: so fisica); o ponteiro segue andando depois do ultimo sprite. */
    private int over;
    public void setOver(int o) { over = 0; }   // a timeline ignora a fisica pos-ano

    @Override protected void onMeasure(int ws, int hs) {
        setMeasuredDimension(MeasureSpec.getSize(ws), Math.round(desiredH > 0 ? Math.min(desiredH, cap()) : cap()));
    }

    /** Estado atual da ANO; chamado a cada tick. */
    public void setState(Ano a, int curPat, int curElapsed, boolean playing) {
        ano = a;
        pat = curPat;
        elapsed = curElapsed;
        if (ano == null) {
            start = new int[0]; total = 0; objs = new ArrayList<ObjModel.Obj>(); rows.clear(); invalidate(); return;
        }
        start = FrameOps.starts(ano.mpts);
        total = FrameOps.total(ano.mpts);
        objs = ObjModel.objects(ano.mpts);
        loop = ObjModel.loops(ano.mpts);
        if (selType == T_OBJ && selectedObj() == null) clearSelection();
        if ((selType == T_SPRITE || selType == T_MOVE || selType == T_STYLE) && selIdx >= ano.mpts.length) clearSelection();
        if (selType == T_SOUND && (selIdx >= ano.mpts.length || (ano.mpts[selIdx].flags & 8) == 0)) clearSelection();
        if (selType == T_LINK && selIdx >= ano.links.length) clearSelection();
        if (selType == T_SEQ && selIdx >= seqMarks.size()) clearSelection();
        buildRows();
        invalidate();
    }

    // ---- linhas ----

    private Row row(int type, float hDp, String label, int color) {
        Row r = new Row();
        r.type = type;
        r.h = hDp * d;
        r.label = label;
        r.color = color;
        rows.add(r);
        return r;
    }

    private void buildRows() {
        rows.clear();
        if (ano == null) return;
        row(R_SPRITE, show[0] ? SPRITE_DP : 0, "SPRITES", C_SPRITE);
        boolean anySound = false, anyMove = false, anyStyle = false;
        for (Ano.Mpt m : ano.mpts) {
            if ((m.flags & 8) != 0) anySound = true;
            if ((m.flags & 4) != 0) anyMove = true;
            if (FrameOps.styleSig(m) != 0) anyStyle = true;
        }
        seqLane = seqLanes(seqMarks);
        seqLaneCount = laneCount(seqLane);
        sawSound = anySound;
        if (!expanded) {
            for (int k = 0; k < 5; k++) {
                boolean has = false;
                for (ObjModel.Obj o : objs) if (o.kind == k) has = true;
                if (has && show[k + 1]) { Row r = row(R_SUMMARY, SUM_DP, ObjModel.KIND_NAMES[k], ObjModel.KIND_COLORS[k]); r.kind = k; }
            }
            if (anySound && show[6]) { Row r = row(R_SUMMARY, SUM_DP, "Audio", C_AUDIO); r.kind = 5; }
            if (anyMove && show[7]) { Row r = row(R_SUMMARY, SUM_DP, "Velocidade", C_MOVE); r.kind = 6; }
            if (ano.links.length > 0 && show[9]) { Row r = row(R_SUMMARY, SUM_DP, "Links", C_LINK); r.kind = 7; }
            if (!seqMarks.isEmpty() && show[10]) { Row r = row(R_SUMMARY, SUM_DP, "Transicoes", C_SEQ); r.kind = 8; }
        } else {
            // so faixas com uso; sons, velocidades e estilos nao coexistem no mesmo frame, entao uma faixa de cada basta
            if (anySound && show[6]) row(R_AUDIO, ROW_DP, "Audio", C_AUDIO);
            if (anyMove && show[7]) {          // uma faixa por eixo (so a visualizacao; o menu continua o mesmo)
                row(R_MOVE, ROW_DP, "Velocidade X", C_MOVE).lane = 0;
                row(R_MOVE, ROW_DP, "Velocidade Y", C_MOVE).lane = 1;
            }
            if (anyStyle && show[8]) row(R_STYLE, ROW_DP, "Estilo", C_STYLE);
            java.util.Map<Integer, Row> objRows = new java.util.HashMap<Integer, Row>();
            for (ObjModel.Obj o : objs) {
                if (!show[o.kind + 1]) continue;
                Row r = objRows.get(ObjModel.laneFlag(o) * 256 + o.occ);
                if (r == null) {
                    r = row(R_OBJ, ROW_DP, ObjModel.nameOf(o), ObjModel.KIND_COLORS[o.kind]);
                    r.obj = o;
                    objRows.put(ObjModel.laneFlag(o) * 256 + o.occ, r);
                }
                r.group.add(o);    // objetos separados (valores diferentes) da mesma flag dividem a linha
            }
            for (int k = 0; show[10] && k < seqLaneCount; k++) row(R_SEQ, ROW_DP, k == 0 ? "Transicoes" : "Transicoes " + (k + 1), C_SEQ).lane = k;
            for (int i = 0; show[9] && i < ano.links.length; i++) {
                Row r = row(R_LINK, ROW_DP, "Link " + (i + 1), C_LINK);
                r.link = i;
            }
        }
        float y = RULER_DP * d;
        Row first = rows.get(0);
        first.top = y;
        y += first.h;
        float bodyTop = y;
        float yy = bodyTop;
        for (int i = 1; i < rows.size(); i++) yy += rows.get(i).h;
        contentH = yy - bodyTop;
        float viewH = cap() - bodyTop;
        float want = Math.min(cap(), bodyTop + contentH + 3 * d);
        if (Math.abs(want - desiredH) > 0.5f) { desiredH = want; requestLayout(); }
        float maxScroll = Math.max(0, contentH - viewH);
        if (scrollY > maxScroll) scrollY = maxScroll;
        if (scrollY < 0) scrollY = 0;
        y = bodyTop - scrollY;
        for (int i = 1; i < rows.size(); i++) { rows.get(i).top = y; y += rows.get(i).h; }
    }

    private float bodyTop() { return (RULER_DP + (show[0] ? SPRITE_DP : 0)) * d; }

    // ---- geometria ----

    private float gutter() { return 58f * d; }
    private float contentW() { return Math.max(1f, getWidth() - gutter()); }
    private float playTick() {
        if (mode == M_SCRUB) return dragTick;
        if (pat < 0 || pat >= start.length) return 0;
        return start[pat] + elapsed + over;
    }
    private float xOf(float tick) { return gutter() + contentW() / 2f + (tick - playTick()) * ppt; }
    private float tickAt(float x) { return playTick() + (x - gutter() - contentW() / 2f) / ppt; }
    private int span(int i) { return FrameOps.span(ano.mpts[i]); }

    private Row rowAt(float y) {
        if (y < RULER_DP * d) return null;
        Row first = rows.isEmpty() ? null : rows.get(0);
        if (first != null && y < first.top + first.h) return first;
        if (y < bodyTop()) return null;
        for (int i = 1; i < rows.size(); i++) {
            Row r = rows.get(i);
            if (y >= r.top && y < r.top + r.h) return r;
        }
        return null;
    }

    // ---- desenho ----

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF12151A);
        float g = gutter();
        if (ano == null || rows.isEmpty()) {
            t.setColor(0xFF4A505E);
            I18nUi.drawText(c, "sem ANO", g + 8 * d, 60 * d, t);
            return;
        }
        float W = getWidth(), H = getHeight();
        c.save();
        c.clipRect(g, 0, W, H);
        drawRuler(c, g, W, H);
        // fora da ANO escurece
        p.setColor(0x88000000);
        c.drawRect(g, RULER_DP * d, Math.min(W, xOf(0)), H, p);
        // sprite atual
        if (pat >= 0 && pat < start.length) {
            p.setColor(0x16FFFFFF);
            c.drawRect(xOf(start[pat]), RULER_DP * d, xOf(start[pat] + span(pat)), H, p);
        }
        if (show[0]) { drawSprites(c); drawEnd(c); }
        c.save();
        c.clipRect(g, bodyTop(), W, H);
        for (int i = 1; i < rows.size(); i++) {
            Row r = rows.get(i);
            if (r.top + r.h < bodyTop() || r.top > H) continue;
            switch (r.type) {
                case R_SUMMARY: drawSummary(c, r); break;
                case R_AUDIO: drawAudio(c, r); break;
                case R_MOVE: drawMove(c, r); break;
                case R_STYLE: drawStyle(c, r); break;
                case R_OBJ: drawObj(c, r); break;
                case R_SEQ: drawSeq(c, r); break;
                default: drawLink(c, r); break;
            }
        }
        c.restore();
        // ponteiro
        float px = g + contentW() / 2f;
        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(1.5f * d);
        c.drawLine(px, 0, px, H, p);
        path.reset();
        path.moveTo(px - 5 * d, 0);
        path.lineTo(px + 5 * d, 0);
        path.lineTo(px, 6 * d);
        path.close();
        c.drawPath(path, p);
        c.restore();
        // cabecalho das linhas
        p.setColor(0xFF0E1015);
        c.drawRect(0, 0, g, H, p);
        c.save();
        c.clipRect(0, bodyTop(), g, H);
        for (int i = 1; i < rows.size(); i++) {
            Row r = rows.get(i);
            if (r.top + r.h < bodyTop() || r.top > H) continue;
            float cy = r.top + r.h / 2f;
            t.setColor(r.color);
            t.setTextSize(r.type == R_SUMMARY ? 7.5f * d : 9f * d);
            c.drawText(clip(r.label, g - 8 * d), 4 * d, cy + 3f * d, t);
        }
        c.restore();
        t.setTextSize(9.5f * d);
        // numero da ANO atual no canto do cabecalho (acima de SPRITES)
        t.setColor(0xFFE6E8EC);
        t.setTextSize(11f * d);
        t.setFakeBoldText(true);
        c.drawText(clip("ANO " + ano.index, g - 8 * d), 4 * d, RULER_DP * d / 2f + 4 * d, t);
        t.setFakeBoldText(false);
        t.setTextSize(9.5f * d);
        Row f = rows.get(0);
        if (show[0]) {
            t.setColor(C_SPRITE);
            I18nUi.drawText(c, "SPRITES", 4 * d, f.top + f.h / 2f - 2 * d, t);
            t.setColor(0xFF6B7280);
            t.setTextSize(8f * d);
            I18nUi.drawText(c, expanded ? "toque p/ fechar" : "toque p/ abrir", 4 * d, f.top + f.h / 2f + 9 * d, t);
            t.setTextSize(9.5f * d);
        }
        drawTip(c);
        // rolagem
        float viewH = H - bodyTop();
        if (contentH > viewH + 1) {
            p.setColor(0x44FFFFFF);
            float bh = Math.max(14 * d, viewH * viewH / contentH);
            float by = bodyTop() + (viewH - bh) * (scrollY / Math.max(1f, contentH - viewH));
            rf.set(g - 3 * d, by, g - 1 * d, by + bh);
            c.drawRoundRect(rf, d, d, p);
        }
    }

    /** Duracao em tempo real enquanto o dedo puxa uma borda. */
    private void drawTip(Canvas c) {
        int ticks;
        if (mode == M_RESIZE) ticks = Math.max(1, Math.round(span(resizeFrame) + resizeDx / ppt));
        else if (mode == M_RESIZE_L) ticks = Math.max(1, Math.round(span(resizeFrame) - resizeDx / ppt));
        else if (mode == M_TRIM_L || mode == M_TRIM_R) ticks = trimT1 - trimT0;
        else return;
        String txt = timeText(ticks);
        t.setTextSize(10f * d);
        float w = t.measureText(txt) + 12 * d, h = 16 * d;
        float x = Math.max(gutter() + 2 * d, Math.min(getWidth() - w - 2 * d, lastX - w / 2f));
        rf.set(x, 2 * d, x + w, 2 * d + h);
        p.setColor(0xEE000000);
        c.drawRoundRect(rf, 5 * d, 5 * d, p);
        t.setColor(0xFFFFFFFF);
        I18nUi.drawText(c, txt, x + 6 * d, 2 * d + h / 2f + 3.5f * d, t);
        t.setTextSize(9.5f * d);
    }

    private String clip(String s, float w) {
        s = I18n.tr(s);
        if (t.measureText(s) <= w) return s;
        while (s.length() > 1 && t.measureText(s + "..") > w) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private void drawRuler(Canvas c, float g, float W, float H) {
        int[] steps = {1, 3, 6, 15, 30, 60, 120, 300, 600};
        int step = steps[steps.length - 1];
        for (int s : steps) { if (s * ppt >= 44f * d) { step = s; break; } }
        t.setColor(0xFF6B7280);
        p.setColor(0xFF2A2F3A);
        p.setStrokeWidth(1f);
        int t0 = Math.max(0, (int) Math.floor(tickAt(g) / step) * step), t1 = (int) tickAt(W) + 1;
        for (int tk = t0; tk <= Math.min(t1, total + 600); tk += step) {
            float x = xOf(tk);
            c.drawLine(x, RULER_DP * d - 4 * d, x, H, p);
            I18nUi.drawText(c, sec(tk), x + 2 * d, 10 * d, t);
        }
        // fim da ANO
        p.setColor(0xFF58606E);
        c.drawLine(xOf(total), RULER_DP * d - 4 * d, xOf(total), H, p);
    }

    private static String sec(int ticks) {
        double s = ticks / 60.0;
        String x = String.format(java.util.Locale.US, "%.2f", s);
        while (x.endsWith("0")) x = x.substring(0, x.length() - 1);
        if (x.endsWith(".")) x = x.substring(0, x.length() - 1);
        return x + "s";
    }

    private void drawSprites(Canvas c) {
        Row row = rows.get(0);
        float y = row.top, h = row.h;
        for (int i = 0; i < ano.mpts.length; i++) {
            float x0 = xOf(start[i]), w = span(i) * ppt;
            if (x0 + w < gutter() || x0 > getWidth()) continue;
            float dw = (mode == M_RESIZE && i == resizeFrame) ? resizeDx : 0f;
            float dl = (mode == M_RESIZE_L && i == resizeFrame) ? resizeDx : 0f;
            boolean sel = selType == T_SPRITE && selIdx == i;
            p.setColor(C_SPRITE);
            p.setAlpha(sel ? 255 : (i == pat ? 230 : 185));
            rf.set(x0 + dl + 1, y + 2 * d, x0 + Math.max(3f * d, w + dw) - 1, y + h - 2 * d);
            c.drawRoundRect(rf, 4 * d, 4 * d, p);
            p.setAlpha(255);
            c.save();
            c.clipRect(rf);
            float tx = rf.left + 3 * d;
            float box = h - 8 * d;
            if (sprites != null && ano.mpts[i].image >= 0 && rf.width() > box + 4 * d) {
                SpriteCache.Sprite sp = null;
                try { sp = sprites.get(ano.mpts[i].image); } catch (Exception ignored) { }
                if (sp != null && sp.bitmap != null) {
                    float sw = sp.src.width(), sh = sp.src.height();
                    float k = Math.min(box / Math.max(1f, sw), box / Math.max(1f, sh));
                    float dw2 = sw * k, dh2 = sh * k;
                    float cx = tx + box / 2f, cy = y + h / 2f;
                    p.setColor(0x33000000);
                    c.drawRect(tx, y + 4 * d, tx + box, y + 4 * d + box, p);
                    rf.set(cx - dw2 / 2f, cy - dh2 / 2f, cx + dw2 / 2f, cy + dh2 / 2f);
                    sr.set(sp.src);
                    c.drawBitmap(sp.bitmap, sr, rf, null);
                    tx += box + 3 * d;
                }
            }
            if (w > 20f * d) {
                t.setColor(0xFF1A1500);
                t.setFakeBoldText(true);
                int shown = span(i);
                if (mode == M_RESIZE_L && i == resizeFrame) shown = Math.max(1, Math.round(span(i) - dl / ppt));
                else if (mode == M_RESIZE && i == resizeFrame) shown = Math.max(1, Math.round(span(i) + dw / ppt));
                String tt = timeText(shown);
                if (rf.right - tx < t.measureText(tt) + 4 * d) tt = sec(shown);
                I18nUi.drawText(c, tt, tx, y + h / 2f - 1f * d, t);
                t.setFakeBoldText(false);
                t.setTextSize(8f * d);
                I18nUi.drawText(c, "img " + ano.mpts[i].image, tx, y + h / 2f + 10f * d, t);
                t.setTextSize(9.5f * d);
            }
            c.restore();
            rf.set(x0 + dl + 1, y + 2 * d, x0 + Math.max(3f * d, w + dw) - 1, y + h - 2 * d);
            if (sel) {
                outline(c, rf.left, rf.top, rf.right, rf.bottom);
                handle(c, rf.right - 3.5f * d, rf.top, rf.bottom);
                handle(c, rf.left + 1.5f * d, rf.top, rf.bottom);
            }
        }
    }

    /** Fim da ANO: botao de loop e de adicionar sprite. */
    private void drawEnd(Canvas c) {
        Row row = rows.get(0);
        float x = xOf(total) + 6 * d, y = row.top + 5 * d, h = row.h - 10 * d;
        if (x > getWidth()) return;
        rf.set(x, y, x + 56 * d, y + h);
        p.setColor(loop ? 0xFF2D7DF6 : 0xFF2A2F3A);
        c.drawRoundRect(rf, 6 * d, 6 * d, p);
        t.setColor(loop ? 0xFFFFFFFF : 0xFF9AA3B2);
        t.setFakeBoldText(true);
        I18nUi.drawText(c, "↻ LOOP", x + 6 * d, y + h / 2f + 3.5f * d, t);
        t.setFakeBoldText(false);
        rf.set(x + 62 * d, y, x + 62 * d + h, y + h);
        p.setColor(0xFF3A3416);
        c.drawRoundRect(rf, 6 * d, 6 * d, p);
        p.setColor(C_SPRITE);
        p.setStrokeWidth(2f * d);
        float cx = rf.centerX(), cy = rf.centerY();
        c.drawLine(cx - 6 * d, cy, cx + 6 * d, cy, p);
        c.drawLine(cx, cy - 6 * d, cx, cy + 6 * d, p);
    }

    private RectF loopRect() {
        Row row = rows.get(0);
        float x = xOf(total) + 6 * d, y = row.top + 5 * d, h = row.h - 10 * d;
        return new RectF(x, y, x + 56 * d, y + h);
    }

    private RectF addRect() {
        RectF l = loopRect();
        return new RectF(l.left + 62 * d, l.top, l.left + 62 * d + l.height(), l.bottom);
    }

    private void drawSummary(Canvas c, Row r) {
        float y = r.top + 2 * d, h = r.h - 4 * d;
        p.setColor(r.color);
        p.setAlpha(190);
        if (r.kind <= 4) {
            for (ObjModel.Obj o : objs) {
                if (o.kind != r.kind) continue;
                rf.set(xOf(start[o.f0]) + 1, y, xOf(start[o.f1] + span(o.f1)) - 1, y + h);
                c.drawRoundRect(rf, 2 * d, 2 * d, p);
            }
        } else if (r.kind == 7) {
            rf.set(xOf(0) + 1, y, xOf(total) - 1, y + h);
            c.drawRoundRect(rf, 2 * d, 2 * d, p);
        } else if (r.kind == 8) {
            for (SeqMark m : seqMarks) {
                if (m.pat < 0 || m.pat >= start.length) continue;
                p.setColor(markColor(m));
                rf.set(xOf(start[m.pat]) + 1, y, xOf(start[m.pat] + span(m.pat)) - 1, y + h);
                c.drawRoundRect(rf, 2 * d, 2 * d, p);
            }
        } else {
            for (int i = 0; i < ano.mpts.length; i++) {
                boolean on = r.kind == 5 ? (ano.mpts[i].flags & 8) != 0 : (ano.mpts[i].flags & 4) != 0;
                if (!on) continue;
                rf.set(xOf(start[i]) + 1, y, xOf(start[i] + span(i)) - 1, y + h);
                c.drawRoundRect(rf, 2 * d, 2 * d, p);
            }
        }
        p.setAlpha(255);
    }

    private void drawAudio(Canvas c, Row r) {
        stripe(c, r);
        for (int i = 0; i < ano.mpts.length; i++) {
            if ((ano.mpts[i].flags & 8) == 0) continue;
            boolean sel = selType == T_SOUND && selIdx == i;
            float x0 = xOf(start[i]), x1 = xOf(start[i] + span(i));
            p.setColor(C_AUDIO);
            p.setAlpha(sel ? 255 : 190);
            rf.set(x0 + 1, r.top + 3 * d, Math.max(x0 + 3 * d, x1 - 1), r.top + r.h - 3 * d);
            c.drawRoundRect(rf, 3 * d, 3 * d, p);
            p.setAlpha(255);
            c.save();
            c.clipRect(rf);
            t.setColor(0xFF2B0507);
            I18nUi.drawText(c, "som " + ano.mpts[i].se, Math.max(rf.left, gutter()) + 3 * d, r.top + r.h / 2f + 3.5f * d, t);
            c.restore();
            if (sel) outline(c, rf.left, rf.top, rf.right, rf.bottom);
        }
        hintCurrent(c, r, "+ som");
    }

    private boolean trimming(int type) {
        return (mode == M_TRIM_L || mode == M_TRIM_R) && trimType == type;
    }

    private void drawMove(Canvas c, Row r) {
        stripe(c, r);
        for (int i = 0; i < ano.mpts.length; i++) {
            Ano.Mpt m = ano.mpts[i];
            if (!FrameOps.isMoveHead(m)) continue;
            if ((FrameOps.moveAxes(ano.mpts, i) & (1 << r.lane)) == 0) continue;      // este trecho nao mexe neste eixo
            int j = FrameOps.moveRunEnd(ano.mpts, i);
            boolean sel = selType == T_MOVE && selIdx == i;
            float x0 = xOf(start[i]), x1 = xOf(start[j] + span(j));
            if (sel && trimming(T_MOVE)) x1 = xOf(trimT1);
            p.setColor(C_MOVE);
            p.setAlpha(sel ? 255 : 190);
            rf.set(x0 + 1, r.top + 3 * d, Math.max(x0 + 3 * d, x1 - 1), r.top + r.h - 3 * d);
            c.drawRoundRect(rf, 3 * d, 3 * d, p);
            p.setAlpha(255);
            c.save();
            c.clipRect(rf);
            t.setColor(0xFF03210F);
            I18nUi.drawText(c, moveLabel(m, r.lane), Math.max(rf.left, gutter()) + 3 * d, r.top + r.h / 2f + 3.5f * d, t);
            c.restore();
            if (sel) {
                outline(c, rf.left, rf.top, rf.right, rf.bottom);
                handle(c, rf.right - 3.5f * d, rf.top, rf.bottom);
            }
        }
        hintCurrent(c, r, r.lane == 0 ? "+ velocidade X" : "+ velocidade Y");
    }

    private String moveLabel(Ano.Mpt m, int axis) {
        StringBuilder b = new StringBuilder();
        if (axis == 0 && (m.moveMask & 1) != 0) b.append("x ").append(DacText.fix(m.speedX)).append(' ');
        if (axis == 1 && (m.moveMask & 2) != 0) b.append("y ").append(DacText.fix(m.speedY)).append(' ');
        if ((m.moveMask & (axis == 0 ? 4 : 8)) != 0) b.append("acel");
        return b.length() == 0 ? "vel" : b.toString().trim();
    }

    private void drawStyle(Canvas c, Row r) {
        stripe(c, r);
        for (int i = 0; i < ano.mpts.length; i++) {
            Ano.Mpt m = ano.mpts[i];
            if (FrameOps.styleSig(m) == 0 || FrameOps.styleRunStart(ano.mpts, i) != i) continue;
            int j = FrameOps.styleRunEnd(ano.mpts, i);
            StringBuilder b = new StringBuilder();
            if (ObjModel.spriteBit(m, ObjModel.FLIP_H)) b.append("↔ ");
            if (ObjModel.spriteBit(m, ObjModel.FLIP_V)) b.append("↕ ");
            if (ObjModel.spriteBit(m, ObjModel.KEEP_SPEED)) b.append("manter vel ");
            if ((m.flags & 0x80) != 0) b.append("transf.");
            boolean sel = selType == T_STYLE && selIdx >= i && selIdx <= j;
            float x0 = xOf(start[i]), x1 = xOf(start[j] + span(j));
            if (sel && trimming(T_STYLE)) x1 = xOf(trimT1);
            p.setColor(C_STYLE);
            p.setAlpha(sel ? 255 : 190);
            rf.set(x0 + 1, r.top + 3 * d, Math.max(x0 + 3 * d, x1 - 1), r.top + r.h - 3 * d);
            c.drawRoundRect(rf, 3 * d, 3 * d, p);
            p.setAlpha(255);
            c.save();
            c.clipRect(rf);
            t.setColor(0xFF2A1400);
            I18nUi.drawText(c, b.toString().trim(), Math.max(rf.left, gutter()) + 3 * d, r.top + r.h / 2f + 3.5f * d, t);
            c.restore();
            if (sel) {
                outline(c, rf.left, rf.top, rf.right, rf.bottom);
                handle(c, rf.right - 3.5f * d, rf.top, rf.bottom);
            }
        }
        hintCurrent(c, r, "+ estilo");
    }

    /** Dica "+ ..." na celula do sprite atual quando a linha esta vazia nele. */
    private void hintCurrent(Canvas c, Row r, String text) {
        if (pat < 0 || pat >= ano.mpts.length) return;
        Ano.Mpt m = ano.mpts[pat];
        boolean has = r.type == R_AUDIO ? (m.flags & 8) != 0
                : r.type == R_MOVE ? (FrameOps.moveAxes(ano.mpts, FrameOps.moveHeadOf(ano.mpts, pat)) & (1 << r.lane)) != 0
                : FrameOps.styleSig(m) != 0;
        if (has) return;
        float x0 = xOf(start[pat]), x1 = xOf(start[pat] + span(pat));
        t.setColor(0xFF5E6676);
        c.save();
        c.clipRect(x0, r.top, x1, r.top + r.h);
        I18nUi.drawText(c, text, x0 + 4 * d, r.top + r.h / 2f + 3.5f * d, t);
        c.restore();
    }

    private void stripe(Canvas c, Row r) {
        p.setColor(0xFF161A21);
        c.drawRect(gutter(), r.top, getWidth(), r.top + r.h - 1, p);
    }

    private void drawObj(Canvas c, Row r) {
        stripe(c, r);
        for (ObjModel.Obj g : r.group) drawObjSeg(c, r, g);
    }

    private ObjModel.Obj objAt(Row r, int frame) {
        for (ObjModel.Obj g : r.group) if (g.contains(frame)) return g;
        return null;
    }

    private void drawObjSeg(Canvas c, Row r, ObjModel.Obj o) {
        boolean sel = selType == T_OBJ && selFlag == o.flag && selOcc == o.occ && o.contains(pat);
        int f0 = o.f0, f1 = o.f1;
        float x0 = xOf(start[f0]), x1 = xOf(start[f1] + span(f1));
        if (sel && trimming(T_OBJ)) { x0 = xOf(trimT0); x1 = xOf(trimT1); }
        boolean here = pat >= f0 && pat <= f1;
        p.setColor(r.color);
        p.setAlpha(sel ? 255 : here ? 215 : 120);
        rf.set(x0 + 1, r.top + 3 * d, x1 - 1, r.top + r.h - 3 * d);
        c.drawRoundRect(rf, 4 * d, 4 * d, p);
        p.setAlpha(255);
        c.save();
        c.clipRect(rf);
        t.setColor(0xFF081018);
        I18nUi.drawText(c, objLabel(o), Math.max(rf.left, gutter()) + 14 * d, r.top + r.h / 2f + 3.5f * d, t);
        c.restore();
        if (sel) {
            outline(c, rf.left, rf.top, rf.right, rf.bottom);
            handle(c, rf.left + 1.5f * d, rf.top, rf.bottom);
            handle(c, rf.right - 3.5f * d, rf.top, rf.bottom);
        }
    }

    private String objLabel(ObjModel.Obj o) {
        if (o.kind == ObjModel.EFFECT) return "Efeito " + (ObjModel.fxPack(o.flag) + 1) + "." + (ObjModel.fxAno(o.flag));
        return ObjModel.nameOf(o);
    }

    private void drawSeq(Canvas c, Row r) {
        stripe(c, r);
        for (int i = 0; i < seqMarks.size(); i++) {
            SeqMark m = seqMarks.get(i);
            if (m.pat < 0 || m.pat >= start.length || i >= seqLane.length || seqLane[i] != r.lane) continue;
            boolean sel = selType == T_SEQ && selIdx == i;
            p.setColor(m.blocked ? 0xFF5E6676 : markColor(m));
            p.setAlpha(sel ? 255 : 210);
            markRect(i, r.top + 3 * d, r.top + r.h - 3 * d, rf);
            c.drawRoundRect(rf, 4 * d, 4 * d, p);
            p.setAlpha(255);
            c.save();
            c.clipRect(rf);
            t.setColor(0xFF1A0A10);
            t.setFakeBoldText(true);
            I18nUi.drawText(c, m.label(), Math.max(rf.left, gutter()) + 3 * d, r.top + r.h / 2f + 3.5f * d, t);
            t.setFakeBoldText(false);
            c.restore();
            if (sel || m.real) outline(c, rf.left, rf.top, rf.right, rf.bottom);
        }
    }

    private void drawLink(Canvas c, Row r) {
        stripe(c, r);
        Ano.Link l = ano.links[r.link];
        boolean sel = selType == T_LINK && selIdx == r.link;
        p.setColor(C_LINK);
        p.setAlpha(sel ? 255 : 170);
        rf.set(xOf(0) + 1, r.top + 3 * d, xOf(total) - 1, r.top + r.h - 3 * d);
        c.drawRoundRect(rf, 4 * d, 4 * d, p);
        p.setAlpha(255);
        c.save();
        c.clipRect(rf);
        t.setColor(0xFF06222A);
        I18nUi.drawText(c, "animação ligada: ANO " + l.getAno(), Math.max(rf.left, gutter()) + 4 * d, r.top + r.h / 2f + 3.5f * d, t);
        c.restore();
        if (sel) outline(c, rf.left, rf.top, rf.right, rf.bottom);
    }

    private void handle(Canvas c, float x, float top, float bottom) {
        p.setColor(0xFFFFFFFF);
        c.drawRoundRect(x, top + 3 * d, x + 2.5f * d, bottom - 3 * d, d, d, p);
    }

    private void outline(Canvas c, float l, float tp, float r, float b) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.6f * d);
        p.setColor(0xFFFFFFFF);
        rf.set(l, tp, r, b);
        c.drawRoundRect(rf, 3 * d, 3 * d, p);
        p.setStyle(Paint.Style.FILL);
    }

    // ---- toque ----

    private int frameAt(float x) {
        float tk = tickAt(x);
        for (int i = 0; i < start.length; i++) if (tk >= start[i] && tk < start[i] + span(i)) return i;
        return -1;
    }

    private float playheadTickRaw() {
        if (pat < 0 || pat >= start.length) return 0;
        return start[pat] + elapsed + over;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (ano == null || rows.isEmpty()) return true;
        scaler.onTouchEvent(e);
        if (scaler.isInProgress()) { scaling = true; if (mode == M_SCRUB) mode = M_NONE; return true; }
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                downX = lastX = x;
                downY = lastY = y;
                moved = false;
                scaling = false;
                mode = M_NONE;
                if (x >= gutter()) startEdit(x, y);
                else if (y > bodyTop()) mode = M_VSCROLL;
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (scaling) return true;
                float dx = x - lastX, dy = y - lastY;
                if (Math.abs(x - downX) > 6 * d || Math.abs(y - downY) > 6 * d) moved = true;
                lastX = x;
                lastY = y;
                if (mode == M_RESIZE) {
                    resizeDx += dx;
                    float minDx = -(span(resizeFrame) * ppt) + ppt;
                    if (resizeDx < minDx) resizeDx = minDx;
                } else if (mode == M_RESIZE_L) {
                    resizeDx += dx;
                    if (resizeDx < 0) resizeDx = 0;                          // so corta (diminui) pelo comeco
                    float maxDx = (span(resizeFrame) - 1) * ppt;
                    if (resizeDx > maxDx) resizeDx = maxDx;
                } else if (mode == M_TRIM_R) {
                    trimT1 = snapTick(Math.round(tickAt(x)), trimT0 + 1, trimLimit());
                } else if (mode == M_TRIM_L) {
                    trimT0 = snapTick(Math.round(tickAt(x)), 0, trimT1 - 1);
                } else if (mode == M_VSCROLL) {
                    scrollY -= dy;
                    buildRows();
                } else if (moved && mode != M_PARENT) {
                    if (mode == M_NONE) {
                        // trava a direcao no primeiro movimento: vertical ganha com folga (angulo > ~35 graus)
                        float ax = Math.abs(x - downX), ay = Math.abs(y - downY);
                        if (ay > ax * 0.7f) {
                            boolean scrollable = downY > bodyTop() && contentH > getHeight() - bodyTop() + 1;
                            if (scrollable) mode = M_VSCROLL;
                            else {                       // nada para rolar aqui: a rolagem da pagina assume
                                mode = M_PARENT;
                                getParent().requestDisallowInterceptTouchEvent(false);
                                return true;
                            }
                        } else {
                            mode = M_SCRUB;
                            dragTick = playheadTickRaw();
                        }
                    }
                    if (mode == M_VSCROLL) {
                        scrollY -= dy;
                        buildRows();
                    } else if (mode == M_SCRUB) {
                        dragTick = Math.max(0f, Math.min(Math.max(0, total - 1), dragTick - dx / ppt));
                        scrub();
                    }
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
                finish(x, y);
                return true;
            case MotionEvent.ACTION_CANCEL:
                mode = M_NONE;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    /** A sprite e absoluta: as bordas dos itens so assentam nas divisoes de sprite (o limite mais proximo dentro de [lo, hi]). */
    private int snapTick(int tk, int lo, int hi) {
        int best = -1;
        for (int i = 0; i <= start.length; i++) {
            int b = i < start.length ? start[i] : total;
            if (b < lo || b > hi) continue;
            if (best < 0 || Math.abs(b - tk) < Math.abs(best - tk)) best = b;
        }
        return best < 0 ? Math.max(lo, Math.min(hi, tk)) : best;
    }

    /** Maior tick que a borda direita do item sendo aparado pode alcancar. */
    private int trimLimit() {
        if (trimType == T_MOVE) {
            int nh = FrameOps.nextMoveHead(ano.mpts, trimFrom);
            return nh < ano.mpts.length ? start[nh] : total;
        }
        return total;
    }

    private void beginTrim(boolean right, int type, int from, int t0, int t1) {
        mode = right ? M_TRIM_R : M_TRIM_L;
        trimType = type;
        trimFrom = from;
        trimT0 = trimOrig0 = t0;
        trimT1 = trimOrig1 = t1;
    }

    /** Comeca uma edicao (aparar / dividir pela borda) se o dedo caiu na borda do item selecionado. */
    private void startEdit(float x, float y) {
        Row r = rowAt(y);
        if (r == null) return;
        float slop = 14f * d;
        if (r.type == R_SPRITE && selType == T_SPRITE && selIdx >= 0 && selIdx < start.length) {
            float right = xOf(start[selIdx] + span(selIdx)), left = xOf(start[selIdx]);
            float dr = Math.abs(x - right), dl = Math.abs(x - left);
            if (dr < slop && dr <= dl) {
                mode = M_RESIZE;
                resizeFrame = selIdx;
                resizeDx = 0;
            } else if (dl < slop && span(selIdx) > 1) {
                mode = M_RESIZE_L;
                resizeFrame = selIdx;
                resizeDx = 0;
            }
        } else if (r.type == R_OBJ && selType == T_OBJ && r.obj != null && r.obj.flag == selFlag && r.obj.occ == selOcc && objAt(r, pat) != null) {
            ObjModel.Obj o = objAt(r, pat);
            float l = xOf(start[o.f0]), rr = xOf(start[o.f1] + span(o.f1));
            int t0 = start[o.f0], t1 = start[o.f1] + span(o.f1);
            if (Math.abs(x - rr) < slop) beginTrim(true, T_OBJ, o.f0, t0, t1);
            else if (Math.abs(x - l) < slop) beginTrim(false, T_OBJ, o.f0, t0, t1);
        } else if (r.type == R_MOVE && selType == T_MOVE && selIdx >= 0 && selIdx < ano.mpts.length && FrameOps.isMoveHead(ano.mpts[selIdx])) {
            int j = FrameOps.moveRunEnd(ano.mpts, selIdx);
            if (Math.abs(x - xOf(start[j] + span(j))) < slop) beginTrim(true, T_MOVE, selIdx, start[selIdx], start[j] + span(j));
        } else if (r.type == R_STYLE && selType == T_STYLE && selIdx >= 0 && selIdx < ano.mpts.length && FrameOps.styleSig(ano.mpts[selIdx]) != 0) {
            int a = FrameOps.styleRunStart(ano.mpts, selIdx), j = FrameOps.styleRunEnd(ano.mpts, selIdx);
            if (Math.abs(x - xOf(start[j] + span(j))) < slop) beginTrim(true, T_STYLE, a, start[a], start[j] + span(j));
        }
    }

    private void scrub() {
        int tk = (int) dragTick;
        int fr = 0;
        for (int i = 0; i < start.length; i++) if (tk >= start[i]) fr = i;
        if (listener != null && start.length > 0) listener.onScrub(fr, Math.max(0, tk - start[fr]));
    }

    private void send(int type, int idx, int flag, int occ) {
        selType = type; selIdx = idx; selFlag = flag; selOcc = occ;
        if (listener != null) listener.onSelect(type, idx, flag, occ);
    }

    private void finish(float x, float y) {
        int m = mode;
        mode = M_NONE;
        if (m == M_RESIZE) {
            int newTime = Math.max(1, Math.min(255, Math.round(span(resizeFrame) + resizeDx / ppt)));
            resizeDx = 0;
            if (listener != null) listener.onResize(resizeFrame, newTime);
        } else if (m == M_RESIZE_L) {
            int newTime = Math.max(1, Math.min(255, Math.round(span(resizeFrame) - resizeDx / ppt)));
            resizeDx = 0;
            if (listener != null) listener.onResize(resizeFrame, newTime);
        } else if (m == M_TRIM_L || m == M_TRIM_R) {
            if (listener != null && (trimT0 != trimOrig0 || trimT1 != trimOrig1))
                listener.onTrimRun(trimType, selFlag, selOcc, trimFrom, trimT0, trimT1);
        } else if (m == M_SCRUB || m == M_VSCROLL || m == M_PARENT) {
            // nada
        } else if (!moved && !scaling) {
            tap(x, y);
        }
        invalidate();
    }

    private void tap(float x, float y) {
        Row r = rowAt(y);
        if (r == null || x < gutter()) {
            if (x < gutter() && r != null && r.type == R_SPRITE) { setExpanded(!expanded); }
            return;
        }
        int f = frameAt(x);
        switch (r.type) {
            case R_SPRITE: {
                if (loopRect().contains(x, y)) { if (listener != null) listener.onLoop(!loop); return; }
                if (addRect().contains(x, y)) { if (listener != null) listener.onAddSprite(); return; }
                if (f < 0) { clearSelection(); if (listener != null) listener.onSelect(T_NONE, -1, -1, -1); return; }
                if (selType == T_SPRITE && selIdx == f) {      // segundo toque: recolhe
                    setExpanded(!expanded);
                    if (!expanded) { clearSelection(); if (listener != null) listener.onSelect(T_NONE, -1, -1, -1); }
                    else send(T_SPRITE, f, -1, -1);
                    return;
                }
                if (!expanded) {      // fechada: leva o ponteiro ate o sprite e expande, sem abrir a edicao
                    setExpanded(true);
                    if (listener != null) listener.onClip(start[f], start[f] + span(f));
                    return;
                }
                send(T_SPRITE, f, -1, -1);
                return;
            }
            case R_SUMMARY: {
                if (f < 0) return;
                if (!expanded) {
                    setExpanded(true);
                    if (listener != null) listener.onClip(start[f], start[f] + span(f));
                    return;
                }
                send(T_SPRITE, f, -1, -1);
                return;
            }
            case R_AUDIO: case R_MOVE: case R_STYLE: {
                if (f < 0) return;
                Ano.Mpt mp = ano.mpts[f];
                int type = r.type == R_AUDIO ? T_SOUND : r.type == R_MOVE ? T_MOVE : T_STYLE;
                int sendIdx = f;
                boolean has;
                if (r.type == R_AUDIO) has = (mp.flags & 8) != 0;
                else if (r.type == R_MOVE) {
                    sendIdx = FrameOps.moveHeadOf(ano.mpts, f);
                    has = sendIdx >= 0 && (FrameOps.moveAxes(ano.mpts, sendIdx) & (1 << r.lane)) != 0;
                    if (!has && sendIdx >= 0) has = true;      // o trecho existe mas nao usa este eixo: abre o menu dele (la se liga o eixo)
                }
                else has = FrameOps.styleSig(mp) != 0;
                if (has) send(type, sendIdx, -1, -1);
                else if (listener != null) listener.onEmpty(type, f, r.type == R_MOVE ? r.lane : 0);
                return;
            }
            case R_SEQ: {
                if (f < 0) return;
                RectF mr = new RectF();
                int first = -1;
                for (int i = 0; i < seqMarks.size(); i++) {
                    if (seqMarks.get(i).pat != f || i >= seqLane.length || seqLane[i] != r.lane) continue;
                    if (first < 0) first = i;
                    markRect(i, -1e6f, 1e6f, mr);
                    if (x >= mr.left && x <= mr.right) { send(T_SEQ, i, -1, -1); return; }
                }
                if (first >= 0) send(T_SEQ, first, -1, -1);
                return;
            }
            case R_OBJ: {
                ObjModel.Obj o = f < 0 ? null : objAt(r, f);
                if (o == null) return;
                send(T_OBJ, -1, o.flag, o.occ);
                if (listener != null) listener.onClip(start[o.f0], start[o.f1] + span(o.f1));
                return;
            }
            default:
                send(T_LINK, r.link, -1, -1);
        }
    }
}
