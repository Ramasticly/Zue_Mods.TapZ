package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Ordem dos botoes do menu superior. O primeiro da lista fica fixo no inicio da linha (fora da rolagem); o resto desliza.
 * Java puro (testado sem Android). Os ids sao fixos e independem do texto do botao, que muda ("TEMPO: NORMAL" ...).
 */
final class ToolbarOrder {
    private ToolbarOrder() { }

    static final String SAVE = "save", CHAR = "char", SPRITES = "spr", LINKS = "links", MOVE = "opt", HITBOX = "hit", TIME = "time",
            CENTER = "ctr", LAND = "land", LOCK = "lock", FLIP = "flip", HIDE = "hide", GHOST = "ghost", SCREEN = "scr";

    /** Ordem de fabrica: SALVAR fixo no inicio. O AJUDA fica na barra de titulo (fora deste menu). */
    static List<String> defaults() {
        return new ArrayList<String>(Arrays.asList(SAVE, CHAR, SPRITES, LINKS, MOVE, HITBOX, TIME, CENTER, LAND, LOCK, FLIP, HIDE, GHOST, SCREEN));
    }

    /**
     * Texto salvo ("id,id,...") + ordem de fabrica => ordem valida: ids desconhecidos e repetidos saem, ids que faltam
     * (botao novo numa versao futura) entram no fim, na ordem de fabrica. saved nulo/vazio => ordem de fabrica.
     */
    static List<String> restore(String saved, List<String> defaults) {
        List<String> out = new ArrayList<String>();
        if (saved != null && saved.length() > 0) {
            for (String id : saved.split(",")) {
                id = id.trim();
                if (defaults.contains(id) && !out.contains(id)) out.add(id);
            }
        }
        for (String id : defaults) if (!out.contains(id)) out.add(id);
        return out;
    }

    static String save(List<String> order) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < order.size(); i++) b.append(i > 0 ? "," : "").append(order.get(i));
        return b.toString();
    }

    /**
     * Tira o item de {@code from} e o poe em {@code to} (indice na lista final): arrastar para tras fica antes do alvo,
     * para frente fica depois dele. Indices fora da lista sao presos as pontas. Devolve uma copia.
     */
    static List<String> move(List<String> order, int from, int to) {
        List<String> out = new ArrayList<String>(order);
        if (out.isEmpty() || from < 0 || from >= out.size()) return out;
        if (to < 0) to = 0;
        if (to > out.size() - 1) to = out.size() - 1;
        String id = out.remove(from);
        out.add(to, id);
        return out;
    }
}
