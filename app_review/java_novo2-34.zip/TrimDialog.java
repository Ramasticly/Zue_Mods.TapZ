package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** Corte preciso de um som: forma de onda com duas alcas arrastaveis, campos em segundos e passos de 10 / 100 ms. */
final class TrimDialog {
    interface Done { void on(byte[] wav); }

    private static final int MIN = AudioConvert.RATE / 20;      // trecho minimo: 50 ms

    private final Activity a;
    private final byte[] wav;
    private final short[] pcm;
    private final Done done;
    private final float d;
    private int start, end;                                    // em amostras
    private Wave wave;
    private EditText eStart, eEnd;
    private TextView info, playBtn;
    private AudioTrack track;
    private Dialog dlg;
    private boolean editing;
    /** Ponteiro de reproducao (amostra absoluta); -1 ate a primeira reproducao. Fica onde a reproducao parou. */
    private int playPos = -1;
    private int playBase;

    private TrimDialog(Activity a, byte[] wav, int startSample, int endSample, Done done) {
        this.a = a;
        this.wav = wav;
        this.pcm = AudioConvert.pcmOf(wav);
        this.done = done;
        this.d = a.getResources().getDisplayMetrics().density;
        this.start = Math.max(0, Math.min(startSample, pcm.length - MIN));
        this.end = Math.max(start + MIN, Math.min(endSample, pcm.length));
    }

    /** Abre o corte; {@code startSample}/{@code endSample} sao a selecao inicial. */
    static void show(Activity a, byte[] wav, int startSample, int endSample, Done done) {
        TrimDialog t = new TrimDialog(a, wav, startSample, endSample, done);
        if (t.pcm.length < MIN * 2) { I18nUi.toast(a, "Som curto demais para cortar.", Toast.LENGTH_SHORT).show(); return; }
        t.open();
    }

    private int dp(int v) { return Math.round(v * d); }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new I18nTextView(a);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = tv(s, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(LayoutManager.PANEL_HI);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    private static String sec(int sample) { return String.format(Locale.US, "%.3f", sample / (double) AudioConvert.RATE); }

    private void open() {
        dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(LayoutManager.PANEL);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        box.setPadding(dp(14), dp(14), dp(14), dp(10));

        box.addView(tv("Cortar som", 17, LayoutManager.TEXT, true));
        info = tv("", 12, LayoutManager.DIM, false);
        info.setPadding(0, dp(2), 0, dp(8));
        box.addView(info);

        wave = new Wave();
        box.addView(wave, new LinearLayout.LayoutParams(-1, dp(120)));

        eStart = field();
        eEnd = field();
        box.addView(handleBlock("INICIO (s)", eStart, true));
        box.addView(handleBlock("FIM (s)", eEnd, false));

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(10), 0, 0);
        playBtn = button("▶  OUVIR TRECHO", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { togglePlay(); } });
        row.addView(playBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(row);

        LinearLayout foot = new LinearLayout(a);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setPadding(0, dp(8), 0, 0);
        foot.addView(button("CANCELAR", LayoutManager.DIM, new View.OnClickListener() { public void onClick(View v) { dlg.dismiss(); } }),
                new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(8), 0, 0, 0);
        foot.addView(button("CORTAR", LayoutManager.ACCENT, new View.OnClickListener() { public void onClick(View v) { apply(); } }), lp);
        box.addView(foot);

        dlg.setContentView(box);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface x) { stopTrack(); }
        });
        refresh();
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            dlg.getWindow().setLayout(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.94f), android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private EditText field() {
        final EditText e = new EditText(a);
        e.setTextColor(LayoutManager.TEXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        e.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent ev) { commitFields(); return false; }
        });
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) { if (!has) commitFields(); }
        });
        return e;
    }

    private LinearLayout handleBlock(String title, EditText e, final boolean isStart) {
        LinearLayout b = new LinearLayout(a);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(0, dp(8), 0, 0);
        b.addView(tv(title, 11, LayoutManager.DIM, true));
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        int[] steps = {-100, -10, 0, 10, 100};
        for (final int s : steps) {
            if (s == 0) { r.addView(e, new LinearLayout.LayoutParams(0, -2, 1.3f)); continue; }
            TextView t = button((s > 0 ? "+" : "−") + Math.abs(s), LayoutManager.TEXT, new View.OnClickListener() { public void onClick(View v) {
                move(isStart, s * AudioConvert.RATE / 1000);
            } });
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            r.addView(t, lp);
        }
        b.addView(r);
        return b;
    }

    /** Move uma das alcas por {@code delta} amostras, respeitando o trecho minimo. */
    private void move(boolean isStart, int delta) {
        stopTrack();
        if (isStart) start = Math.max(0, Math.min(start + delta, end - MIN));
        else end = Math.max(start + MIN, Math.min(end + delta, pcm.length));
        refresh();
    }

    private void commitFields() {
        if (editing) return;
        try {
            int s = (int) Math.round(Double.parseDouble(eStart.getText().toString().replace(',', '.')) * AudioConvert.RATE);
            int e = (int) Math.round(Double.parseDouble(eEnd.getText().toString().replace(',', '.')) * AudioConvert.RATE);
            e = Math.max(MIN, Math.min(e, pcm.length));
            s = Math.max(0, Math.min(s, e - MIN));
            start = s;
            end = e;
        } catch (NumberFormatException ignored) { }
        refresh();
    }

    private void refresh() {
        editing = true;
        eStart.setText(sec(start));
        eEnd.setText(sec(end));
        editing = false;
        info.setText(String.format(Locale.US, "Trecho: %.3f s de %.3f s", (end - start) / (double) AudioConvert.RATE, pcm.length / (double) AudioConvert.RATE));
        wave.invalidate();
    }

    private void apply() {
        commitFields();
        stopTrack();
        byte[] out = AudioConvert.slice(wav, start, end);
        dlg.dismiss();
        done.on(out);
    }

    // ---- ouvir o trecho (AudioTrack estatico: toca exatamente o recorte)

    private void togglePlay() {
        commitFields();
        if (track != null) { stopTrack(); return; }
        playFrom(start);
    }

    /** Toca de {@code from} ate o fim do trecho. */
    private void playFrom(int from) {
        from = Math.max(start, Math.min(from, end - MIN));
        final int len = end - from;
        try {
            @SuppressWarnings("deprecation")
            final AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, AudioConvert.RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, len * 2, AudioTrack.MODE_STATIC);
            t.write(pcm, from, len);
            t.setNotificationMarkerPosition(len);
            t.setPlaybackPositionUpdateListener(new AudioTrack.OnPlaybackPositionUpdateListener() {
                @Override public void onMarkerReached(AudioTrack x) { if (track == x) stopTrack(); }
                @Override public void onPeriodicNotification(AudioTrack x) { }
            }, new Handler(Looper.getMainLooper()));
            track = t;
            playBase = from;
            playPos = from;
            playBtn.setText("■  PARAR");
            wave.invalidate();
            t.play();
        } catch (Exception e) {
            stopTrack();
        }
    }

    private void stopTrack() {
        AudioTrack t = track;
        track = null;
        if (t != null) {
            try { playPos = Math.min(end, playBase + Math.max(0, t.getPlaybackHeadPosition())); } catch (Exception ignored) { }
            try { t.stop(); } catch (Exception ignored) { }
            try { t.release(); } catch (Exception ignored) { }
        }
        if (playBtn != null) playBtn.setText("▶  OUVIR TRECHO");
        if (wave != null) wave.invalidate();
    }

    // ---- forma de onda

    private final class Wave extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path path = new android.graphics.Path();
        private float[] peaks;
        private int bins;
        private int drag;                                       // 1 = inicio, 2 = fim

        Wave() { super(a); }

        private void build(int w) {
            bins = Math.max(1, w);
            peaks = new float[bins];
            for (int i = 0; i < pcm.length; i++) {
                int b = (int) ((long) i * bins / pcm.length);
                float v = Math.abs(pcm[i]) / 32768f;
                if (v > peaks[b]) peaks[b] = v;
            }
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (peaks == null || bins != w) build(w);
            c.drawColor(0xFF0D0F13);
            float xs = start / (float) pcm.length * w, xe = end / (float) pcm.length * w;
            p.setColor(0x334C8DFF);
            c.drawRect(xs, 0, xe, h, p);
            float mid = h / 2f;
            for (int x = 0; x < w; x++) {
                boolean in = x >= xs && x <= xe;
                p.setColor(in ? 0xFF6AA1FF : 0xFF4A505E);
                float a2 = Math.max(1f, peaks[x] * mid * 0.95f);
                c.drawLine(x, mid - a2, x, mid + a2, p);
            }
            p.setColor(LayoutManager.ACCENT);
            p.setStrokeWidth(dp(2));
            c.drawLine(xs, 0, xs, h, p);
            c.drawLine(xe, 0, xe, h, p);
            p.setStrokeWidth(1f);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(xs, dp(8), dp(6), p);
            c.drawCircle(xe, h - dp(8), dp(6), p);
            AudioTrack t = track;
            if (t != null) {
                try { playPos = Math.min(end, playBase + Math.max(0, t.getPlaybackHeadPosition())); } catch (Exception ignored) { }
                postInvalidateOnAnimation();
            }
            if (playPos >= 0) {                                  // ponteiro de reproducao
                float xp = playPos / (float) pcm.length * w;
                p.setColor(0xFFFFC94C);
                p.setStrokeWidth(dp(2));
                c.drawLine(xp, 0, xp, h, p);
                p.setStrokeWidth(1f);
                path.reset();
                path.moveTo(xp - dp(6), 0);
                path.lineTo(xp + dp(6), 0);
                path.lineTo(xp, dp(9));
                path.close();
                c.drawPath(path, p);
            }
        }

        private void movePlayhead(int sample) {
            playPos = Math.max(start, Math.min(sample, end));
            invalidate();
        }

        @Override public boolean onTouchEvent(MotionEvent ev) {
            int w = getWidth();
            if (w <= 0) return false;
            float x = Math.max(0, Math.min(ev.getX(), w));
            int sample = Math.round(x / w * pcm.length);
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    // o ponteiro de reproducao tem prioridade quando o toque cai em cima dele (e nao em cima de uma alca de corte:
                    // depois de colar uma alca no ponteiro, ela continua podendo ser puxada)
                    float xs0 = start / (float) pcm.length * w, xe0 = end / (float) pcm.length * w;
                    if (playPos >= 0 && Math.abs(x - playPos / (float) pcm.length * w) <= 18f * d
                            && Math.abs(x - xs0) > 18f * d && Math.abs(x - xe0) > 18f * d) {
                        drag = 3;
                        stopTrack();
                        movePlayhead(sample);
                        return true;
                    }
                    drag = Math.abs(sample - start) <= Math.abs(sample - end) ? 1 : 2;
                    // fim: cai na alca do fim se o toque esta depois do meio do trecho
                    if (sample > start && sample < end) drag = sample - start < end - sample ? 1 : 2;
                    // fall through
                case MotionEvent.ACTION_MOVE:
                    if (drag == 3) { movePlayhead(sample); return true; }
                    stopTrack();
                    // leve atracao pelo ponteiro de reproducao (~12 dp): ajuda a cortar exatamente onde parou de ouvir
                    if (playPos >= 0 && Math.abs(sample - playPos) <= 12f * d / w * pcm.length) sample = playPos;
                    if (drag == 1) start = Math.max(0, Math.min(sample, end - MIN));
                    else if (drag == 2) end = Math.max(start + MIN, Math.min(sample, pcm.length));
                    refresh();
                    return true;
                default:
                    if (drag == 3 && ev.getActionMasked() == MotionEvent.ACTION_UP) playFrom(playPos);   // solta: toca a partir do ponteiro
                    drag = 0;
                    return true;
            }
        }
    }
}
