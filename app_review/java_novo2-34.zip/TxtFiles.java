package com.zue.attackeditor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Acha os TXT de um pacote: {@code *.dac.txt}, {@code *.bin.txt}, {@code *.cnv.txt} com QUALQUER nome (o extrator do jogo grava {@code 000.ext.txt}, mas varios mods gravam
 * com outros nomes). O app so le TXT: sem o TXT o pacote nao abre ({@link Missing}). Em cada pasta so deve haver um TXT de cada tipo; se houver mais de um, vale o
 * {@code 000.} ou o primeiro por nome (como o compilador, que ordena por nome). Java puro.
 */
final class TxtFiles {
    private TxtFiles() { }

    /** O TXT que o pacote precisa nao existe na pasta. */
    static final class Missing extends IOException {
        final File dir;
        final String ext;
        Missing(File dir, String ext) {
            super("Falta o arquivo *." + ext + ".txt em " + (dir == null ? "?" : dir.getPath()) + " (o app le so TXT, de qualquer nome; o binario nao e lido)");
            this.dir = dir;
            this.ext = ext;
        }
    }

    /** {@code name} e um TXT do tipo {@code ext} (dac, bin, cnv)? Ignora a caixa e arquivos temporarios. */
    static boolean isKind(String name, String ext) {
        String n = name.toLowerCase(Locale.US);
        return n.endsWith("." + ext + ".txt") && n.length() > ext.length() + 5 && !n.startsWith(".");
    }

    /** Todos os TXT do tipo na pasta, em ordem de nome (o 000. primeiro). */
    static List<File> all(File dir, String ext) {
        List<File> out = new ArrayList<File>();
        File[] fs = dir == null ? null : dir.listFiles();
        if (fs == null) return out;
        for (File f : fs) if (f.isFile() && isKind(f.getName(), ext)) out.add(f);
        Collections.sort(out, new java.util.Comparator<File>() {
            @Override public int compare(File a, File b) {
                boolean za = a.getName().startsWith("000."), zb = b.getName().startsWith("000.");
                if (za != zb) return za ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        return out;
    }

    /** O TXT do tipo na pasta ou null. */
    static File find(File dir, String ext) {
        List<File> l = all(dir, ext);
        return l.isEmpty() ? null : l.get(0);
    }

    /** Como {@link #find}, mas {@link Missing} se nao houver. */
    static File require(File dir, String ext) throws Missing {
        File f = find(dir, ext);
        if (f == null) throw new Missing(dir, ext);
        return f;
    }

    /** Aviso quando ha mais de um TXT do tipo (so um e usado); null se esta tudo certo. */
    static String duplicates(File dir, String ext) {
        List<File> l = all(dir, ext);
        if (l.size() < 2) return null;
        return "Ha " + l.size() + " arquivos *." + ext + ".txt em " + dir.getName() + "; o app usa " + l.get(0).getName() + ".";
    }

    /** "x.cnv.txt" -> "x.cnv" (o nome do binario correspondente, so como identificador: nunca e lido). */
    static File withoutTxt(File txt) {
        String n = txt.getName();
        return n.toLowerCase(Locale.US).endsWith(".txt") ? new File(txt.getParentFile(), n.substring(0, n.length() - 4)) : txt;
    }

    /** O arquivo inteiro como UTF-8. */
    static String read(File f) throws IOException {
        return new String(GameData.readAll(f), "UTF-8");
    }
}
