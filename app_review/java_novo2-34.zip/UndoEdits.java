package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Fabricas de {@link UndoHistory.Edit} para as edicoes do app (Java puro). Cada uma guarda o estado ANTERIOR ao reverter le o estado
 * ATUAL antes de restaurar e devolve a edicao inversa: e isso que permite refazer.
 */
final class UndoEdits {
    private UndoEdits() { }

    /** Uma ANO do DAC volta a ser {@code ano}. */
    static UndoHistory.Edit swapAno(final Dac dac, final int idx, final Ano ano) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() {
                Ano cur = dac.getAno(idx);
                dac.setAno(idx, ano);
                return swapAno(dac, idx, cur);
            }
        };
    }

    /** Varias ANOs do DAC voltam a ser {@code anos} (cada uma no proprio indice). */
    static UndoHistory.Edit swapAnos(final Dac dac, final List<Ano> anos) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() {
                List<Ano> cur = new ArrayList<Ano>();
                for (Ano a : anos) { cur.add(dac.getAno(a.index)); dac.setAno(a.index, a); }
                return swapAnos(dac, cur);
            }
        };
    }

    /** Frames {@code pats} da ANO (trocados no proprio array) voltam a ser {@code vals}. */
    static UndoHistory.Edit swapMpts(final Ano ano, final int[] pats, final Ano.Mpt[] vals) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() {
                Ano.Mpt[] cur = new Ano.Mpt[pats.length];
                for (int i = 0; i < pats.length; i++) { cur[i] = ano.mpts[pats[i]]; ano.mpts[pats[i]] = vals[i]; }
                return swapMpts(ano, pats, cur);
            }
        };
    }

    /** O golpe (HDAT 4) volta a ter os campos de {@code before}; {@code sync} roda depois (copia generica do modo ANO). */
    static UndoHistory.Edit swapMove(final CharData.Move mv, final CharData.Move before, final Runnable sync) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() {
                CharData.Move cur = mv.copy();
                mv.copyFrom(before);
                if (sync != null) sync.run();
                return swapMove(mv, cur, sync);
            }
        };
    }

    /** A tabela de reacao volta a ter o conteudo de {@code before}. */
    static UndoHistory.Edit swapReaction(final ReactionTable t, final ReactionTable before) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() {
                ReactionTable cur = t.copy();
                t.restoreFrom(before);
                return swapReaction(t, cur);
            }
        };
    }

    /** A distancia do agarrao (HDAT 3) volta a ser {@code px}. */
    static UndoHistory.Edit swapPull(final CharData cd, final int px) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() {
                int cur = cd.pullDistance();
                cd.setPullDistance(px);
                return swapPull(cd, cur);
            }
        };
    }
}
