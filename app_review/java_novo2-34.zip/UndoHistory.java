package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Desfazer/refazer em dois niveis (Java puro, testado sem Android).
 * Nivel 1, a SESSAO (um menu aberto): cada mudanca e um passo; desfazer/refazer valem so dentro do menu, do primeiro passo ao ultimo.
 * Nivel 2, a pilha EXTERNA: ao APLICAR, os passos vigentes da sessao viram UMA entrada (desfazer externo desfaz o menu inteiro).
 * Mudanca nova apaga o refazer do escopo em que foi feita. Com uma sessao aberta, desfazer/refazer agem nela; senao, na externa.
 * Uma {@link Edit} faz a troca de estado e devolve a edicao inversa, entao desfazer e refazer sao o mesmo mecanismo.
 */
final class UndoHistory {
    interface Edit { Edit revert(); }

    /** Varias edicoes em ordem de aplicacao; reverter desfaz da ultima para a primeira e devolve o grupo inverso. */
    static final class Group implements Edit {
        private final List<Edit> edits;
        Group(List<Edit> edits) { this.edits = edits; }
        int size() { return edits.size(); }
        @Override public Edit revert() {
            List<Edit> out = new ArrayList<Edit>(edits.size());
            for (int i = edits.size() - 1; i >= 0; i--) out.add(edits.get(i).revert());
            return new Group(out);
        }
    }

    static final long MERGE_MS = 4000;

    private final List<Edit> undo = new ArrayList<Edit>(), redo = new ArrayList<Edit>();
    private List<Edit> sUndo, sRedo;               // != null enquanto ha sessao
    private String lastKey;
    private long lastMs;

    boolean inSession() { return sUndo != null; }

    /** Quantos passos ha para desfazer no escopo ativo. */
    int count() { return sUndo != null ? sUndo.size() : undo.size(); }
    int redoCount() { return sRedo != null ? sRedo.size() : redo.size(); }
    boolean canUndo() { return count() > 0; }
    boolean canRedo() { return redoCount() > 0; }

    /** Proxima mudanca nunca se funde com a anterior. */
    void breakMerge() { lastKey = null; }

    /** Registra uma mudanca ja feita. Mesma chave em ate 4 s funde com a anterior (o desfazer volta ao estado antes da primeira). */
    void push(String key, long now, Edit e) {
        List<Edit> u = sUndo != null ? sUndo : undo, r = sRedo != null ? sRedo : redo;
        r.clear();
        if (key != null && key.equals(lastKey) && now - lastMs < MERGE_MS && !u.isEmpty()) { lastMs = now; return; }
        lastKey = key;
        lastMs = now;
        u.add(e);
    }

    /** Abre uma sessao (menu); se ja ha uma, mantem. */
    void begin() {
        if (sUndo != null) return;
        sUndo = new ArrayList<Edit>();
        sRedo = new ArrayList<Edit>();
        lastKey = null;
    }

    /** APLICAR: os passos vigentes da sessao viram uma entrada externa (sessao vazia nao cria nada). O refazer da sessao se perde. */
    boolean commit() {
        if (sUndo == null) return false;
        boolean any = !sUndo.isEmpty();
        if (any) {
            undo.add(new Group(new ArrayList<Edit>(sUndo)));
            redo.clear();
        }
        sUndo = null;
        sRedo = null;
        lastKey = null;
        return any;
    }

    /** Fechar sem aplicar: desfaz o que restou na sessao e a descarta. Devolve quantos passos desfez. */
    int discard() {
        if (sUndo == null) return 0;
        int n = 0;
        for (int i = sUndo.size() - 1; i >= 0; i--) { sUndo.get(i).revert(); n++; }
        sUndo = null;
        sRedo = null;
        lastKey = null;
        return n;
    }

    boolean undo() {
        List<Edit> u = sUndo != null ? sUndo : undo, r = sRedo != null ? sRedo : redo;
        if (u.isEmpty()) return false;
        r.add(u.remove(u.size() - 1).revert());
        lastKey = null;
        return true;
    }

    boolean redo() {
        List<Edit> u = sUndo != null ? sUndo : undo, r = sRedo != null ? sRedo : redo;
        if (r.isEmpty()) return false;
        u.add(r.remove(r.size() - 1).revert());
        lastKey = null;
        return true;
    }
}
