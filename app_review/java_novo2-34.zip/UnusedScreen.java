package com.zue.attackeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * OTIMIZAR > Remover Sprites nao usadas: lista as sprites que nenhum Frame do DAC usa; o usuario marca as que quer remover (nenhuma vem marcada) e elas sao
 * excluidas (copia bruta antes, recorte apagado da folha, sprites seguintes renumeradas). Sprites de GIF aparecem fixas: so saem por "Otimizar GIF".
 */
final class UnusedScreen {
    private static final int BG = 0xFF14171C, CARD = 0xFF1F2430, TEXT = 0xFFE6E8EC, DIM = 0xFF8A93A6, ACCENT = 0xFF4C8DFF, OK = 0xFF7CE08A, RED = 0xFFFF6B6B;
    private static final int RED_BG = 0xFF4A1F24, GREEN_BG = 0xFF1F4A2B, ROW_MARKED = 0xFF3A1F24;

    private final Activity a;
    private final CharAssets ca;
    private final SpriteLib lib;
    private final Runnable applied;
    private final List<UnusedSprites.Item> items;
    private final TreeSet<Integer> marked = new TreeSet<Integer>();
    private final Map<Integer, LinearLayout> rows = new HashMap<Integer, LinearLayout>();
    private final Map<Integer, TextView> chips = new HashMap<Integer, TextView>();
    private final Map<Integer, Bitmap> thumbs = new HashMap<Integer, Bitmap>();
    private Dialog dialog;
    private TextView count, ok, toggleAll;

    private UnusedScreen(Activity a, CharAssets ca, SpriteLib lib, List<UnusedSprites.Item> items, Runnable applied) {
        this.a = a; this.ca = ca; this.lib = lib; this.items = items; this.applied = applied;
    }

    /** Abre a lista (ou avisa que toda sprite tem uso). */
    static void show(Activity a, CharAssets ca, SpriteLib lib, Runnable applied) {
        boolean[] has = new boolean[lib.count()];
        for (int i = 0; i < has.length; i++) has[i] = lib.has(i);
        List<UnusedSprites.Item> items = UnusedSprites.find(ca.dac, lib.count(), has, lib.groups);
        if (items.isEmpty()) { SpriteListScreen.toast(a, "Nenhuma sprite sem uso: todas aparecem em algum Frame do DAC."); return; }
        new UnusedScreen(a, ca, lib, items, applied).build();
    }

    private int dp(int v) { return SpriteListScreen.dp(a, v); }

    private TextView colored(String s, int fill, int stroke, int textColor, View.OnClickListener c) {
        TextView t = SpriteListScreen.button(a, s, c);
        t.setTextColor(textColor);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(1), stroke);
        g.setCornerRadius(dp(8));
        t.setBackground(g);
        return t;
    }

    private int markable() {
        int n = 0;
        for (UnusedSprites.Item it : items) if (!it.inGif) n++;
        return n;
    }

    private void build() {
        dialog = new Dialog(a, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(0, dp(12), 0, 0);
        dialog.setContentView(root);
        TextView ti = SpriteListScreen.text(a, "Sprites não usadas", 16, TEXT, true);
        ti.setPadding(dp(14), 0, dp(14), dp(2));
        root.addView(ti);
        TextView hint = SpriteListScreen.text(a, items.size() + " sprite(s) sem nenhum uso em nenhuma ANO do DAC. Marque as que quer REMOVER (toque na linha). "
                + "As sprites seguintes serão renumeradas.", 11, DIM, false);
        hint.setPadding(dp(14), 0, dp(14), dp(6));
        root.addView(hint);
        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), 0, dp(14), dp(4));
        count = SpriteListScreen.text(a, "", 13, ACCENT, true);
        bar.addView(count, new LinearLayout.LayoutParams(0, -2, 1f));
        toggleAll = SpriteListScreen.button(a, "MARCAR TODAS", new View.OnClickListener() { @Override public void onClick(View v) { toggleAll(); } });
        bar.addView(toggleAll);
        root.addView(bar);
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (UnusedSprites.Item it : items) list.addView(row(it), rowParams());
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout foot = new LinearLayout(a);
        foot.setPadding(dp(12), dp(8), dp(12), dp(12));
        foot.addView(colored("CANCELAR", RED_BG, RED, RED, new View.OnClickListener() { @Override public void onClick(View v) { dialog.dismiss(); } }));
        ok = colored("REMOVER MARCADAS", GREEN_BG, OK, OK, new View.OnClickListener() { @Override public void onClick(View v) { confirm(); } });
        foot.addView(ok, SpriteListScreen.lpm(a, 8));
        root.addView(foot);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) {
                for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
                thumbs.clear();
            }
        });
        counts();
        dialog.show();
    }

    private LinearLayout.LayoutParams rowParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(8), dp(3), dp(8), dp(3));
        return p;
    }

    private View row(final UnusedSprites.Item it) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(6), dp(8), dp(6));
        row.setBackgroundColor(CARD);
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0D0F13);
        Bitmap tb = it.empty ? null : thumb(it.index);
        if (tb != null) iv.setImageBitmap(tb);
        iv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { SpriteListScreen.previewSprite(a, lib, it.index); } });      // previa flutuante
        row.addView(iv, new LinearLayout.LayoutParams(dp(56), dp(56)));
        int[] ls = it.empty ? null : lib.logicalSize(it.index);
        Cnv.Entry e = ca.cnv.byImage(it.index);
        TextView t = new I18nTextView(a);
        t.setTextSize(12);
        t.setTextColor(it.empty ? DIM : TEXT);
        t.setPadding(dp(10), 0, dp(6), 0);
        t.setText("SPR_" + it.index + "\n" + (it.empty || ls == null ? "(vazia)" : ls[0] + "×" + ls[1] + " · folha " + (e == null ? 0 : e.source)));
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView chip = SpriteListScreen.text(a, it.inGif ? "Sprite de Gif" : "MANTER", 11, it.inGif ? DIM : OK, true);
        chip.setPadding(dp(8), dp(4), dp(8), dp(4));
        chips.put(Integer.valueOf(it.index), chip);
        row.addView(chip);
        if (it.inGif) {
            final String gifName = lib.groups.at(it.index) == null ? "" : lib.groups.at(it.index).name;
            TextView q = SpriteListScreen.text(a, "?", 14, ACCENT, true);          // "?" clicavel: sprite de GIF so sai por Otimizar GIF
            q.setGravity(Gravity.CENTER);
            q.setPadding(dp(10), dp(4), dp(10), dp(4));
            q.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { gifHelp(gifName); } });
            row.addView(q);
        } else {
            row.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { flip(it.index); } });
        }
        rows.put(Integer.valueOf(it.index), row);
        return row;
    }

    private Bitmap thumb(int idx) {
        Bitmap tb = thumbs.get(Integer.valueOf(idx));
        if (tb == null) {
            Bitmap full = lib.cut(idx);
            if (full != null) {
                float s = Math.min(1f, 96f / Math.max(full.getWidth(), full.getHeight()));
                tb = s >= 1f ? full : Bitmap.createScaledBitmap(full, Math.max(1, (int) (full.getWidth() * s)), Math.max(1, (int) (full.getHeight() * s)), true);
                if (tb != full) full.recycle();
                thumbs.put(Integer.valueOf(idx), tb);
            }
        }
        return tb;
    }

    private void gifHelp(String gifName) {
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Sprite de Gif")
                .setMessage("As sprites de um Gif só podem ser removidas pela função \"Otimizar Gif\".\n\nToque em " + gifName + " na lista de Sprites e, em seguida, em Otimizar Gif.")
                .setPositiveButton("OK", null).show();
    }

    private void flip(int idx) {
        Integer k = Integer.valueOf(idx);
        if (!marked.remove(k)) marked.add(k);
        paint(idx);
        counts();
    }

    private void toggleAll() {
        boolean all = marked.size() == markable();
        marked.clear();
        if (!all) for (UnusedSprites.Item it : items) if (!it.inGif) marked.add(Integer.valueOf(it.index));
        for (UnusedSprites.Item it : items) paint(it.index);
        counts();
    }

    private void paint(int idx) {
        LinearLayout row = rows.get(Integer.valueOf(idx));
        TextView chip = chips.get(Integer.valueOf(idx));
        if (row == null || chip == null || lib.groups.at(idx) != null) return;
        boolean rem = marked.contains(Integer.valueOf(idx));
        row.setBackgroundColor(rem ? ROW_MARKED : CARD);
        chip.setText(rem ? "REMOVER" : "MANTER");
        chip.setTextColor(rem ? RED : OK);
    }

    private void counts() {
        count.setText(marked.size() + " marcada(s) de " + markable());
        toggleAll.setText(marked.size() == markable() && markable() > 0 ? "LIMPAR" : "MARCAR TODAS");
        toggleAll.setEnabled(markable() > 0);
        ok.setEnabled(!marked.isEmpty());
        ok.setAlpha(marked.isEmpty() ? 0.4f : 1f);
    }

    private void confirm() {
        final int n = marked.size();
        if (n == 0) return;
        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remover sprites não usadas")
                .setMessage("Remover " + n + " sprite(s) que nenhum Frame do DAC usa? As sprites seguintes serão renumeradas (CNV, grupos de GIF e todos os Frames do DAC). "
                        + "Antes é feita uma cópia bruta do personagem inteiro (DAC, CNV, Bin, áudios, PNGs e GIFs) em Backups/PreOptim/, que ocupa o mesmo espaço do personagem. "
                        + "O recorte de cada sprite removida é APAGADO da folha PNG (fica transparente) e folhas PNG que ficarem sem sprites são apagadas da pasta.")
                .setNegativeButton("VOLTAR", null)
                .setPositiveButton("SIM, REMOVER", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { dialog.dismiss(); apply(); }
                }).show();
    }

    private void apply() {
        final BusyDialog busy = BusyDialog.show(a, "Removendo sprites não usadas");
        busy.set("Copiando o personagem...", 0, 0);
        final java.util.Set<Integer> del = new java.util.HashSet<Integer>(marked);
        new Thread(new Runnable() {
            @Override public void run() {
                String out;
                boolean changedAny = false;
                try {
                    File bk = PreOptimBackup.run(ca.dir, new java.util.Date(), new Saver.CopyProgress() {
                        @Override public void on(String file, int d, int total) { busy.set("Copiando o personagem\n" + file, d, total); }
                    });
                    busy.set("Removendo...", 0, 0);
                    int[] map = lib.removeShift(del);
                    TreeSet<Integer> changed = new TreeSet<Integer>(SpriteRenumber.remapDac(ca.dac, map));
                    SpriteMassDialogs.renumbered(ca, map);
                    String saved = SpriteMassDialogs.persist(ca, changed);
                    changedAny = true;
                    out = del.size() + " sprite(s) removida(s); as sprites seguintes foram renumeradas (" + changed.size() + " ANO(s) reescrita(s)).\n\nCópia bruta do personagem: "
                            + bk.getPath() + (saved.isEmpty() ? "" : "\n" + SpriteMassDialogs.lastPersist);
                } catch (Throwable t) {
                    out = "Erro ao remover sprites não usadas: " + t;
                }
                busy.dismiss();
                final String text = out;
                final boolean ch = changedAny;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (ch) applied.run();
                        ScrollView s = new ScrollView(a);
                        TextView tv = SpriteListScreen.text(a, text, 13, TEXT, false);
                        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
                        s.addView(tv);
                        new I18nBuilder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Sprites não usadas").setView(s).setPositiveButton("OK", null).show();
                    }
                });
            }
        }).start();
    }
}
