package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;

/** Sprites sem nenhum uso no DAC (nenhum Frame de nenhuma ANO presente aponta para elas): a lista do OTIMIZAR > Remover Sprites nao usadas. Java puro. */
final class UnusedSprites {
    private UnusedSprites() { }

    /** Uma sprite sem uso. {@code empty}: sem desenho no CNV; {@code inGif}: faz parte de um GIF (fica fixa: so sai por "Otimizar GIF"). */
    static final class Item {
        final int index;
        final boolean empty, inGif;
        Item(int index, boolean empty, boolean inGif) { this.index = index; this.empty = empty; this.inGif = inGif; }
    }

    /** {@code used[i]} = algum Frame de uma ANO presente usa a imagem {@code i} (imagens fora de 0..count-1 e -1 sao ignoradas). */
    static boolean[] used(Dac dac, int count) {
        boolean[] u = new boolean[Math.max(0, count)];
        if (dac == null) return u;
        for (int i = 0; i < dac.size(); i++) {
            Ano a = dac.getAno(i);
            if (a == null || !a.present || a.mpts == null) continue;
            for (Ano.Mpt m : a.mpts) if (m.image >= 0 && m.image < u.length) u[m.image] = true;
        }
        return u;
    }

    /** As sprites {@code 0..count-1} sem uso, em ordem. {@code hasDrawing[i]} diz se a sprite tem desenho; {@code groups} pode ser null. */
    static List<Item> find(Dac dac, int count, boolean[] hasDrawing, SpriteGroups groups) {
        boolean[] u = used(dac, count);
        List<Item> out = new ArrayList<Item>();
        for (int i = 0; i < u.length; i++) {
            if (u[i]) continue;
            boolean drawn = hasDrawing != null && i < hasDrawing.length && hasDrawing[i];
            out.add(new Item(i, !drawn, groups != null && groups.at(i) != null));
        }
        return out;
    }
}
