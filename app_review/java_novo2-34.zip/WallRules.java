package com.zue.attackeditor;

/**
 * Regra da coluna WALL de um passo de reacao (md 876 / 877 e a camera md 19 do jogo). So o 2 e o 3 fazem a "parede": quando o oponente encosta na borda,
 * o jogo salta para a reacao COMP do passo e marca a batida. Qualquer outro valor vale como 0 (o 1 so mexe na camera depois de uma batida). Java puro.
 */
final class WallRules {
    private WallRules() { }

    static final int OFF = 0, CAMERA = 1, MAP = 2, SCREEN = 3;

    /** Os modos que o editor oferece, na ordem do seletor. */
    static final int[] MODES = {OFF, MAP, SCREEN, CAMERA};

    /** O valor ativa a parede (salto para o COMP ao encostar na borda)? */
    static boolean triggers(int wall) { return wall == MAP || wall == SCREEN; }

    /** O valor que o jogo realmente usa: 0..3 como estao; o resto vale 0. */
    static int effective(int wall) { return wall >= 0 && wall <= 3 ? wall : OFF; }

    /** Nome curto do modo (botao do seletor). */
    static String name(int wall) {
        switch (effective(wall)) {
            case MAP: return "Borda do mapa (2)";
            case SCREEN: return "Borda da tela (3)";
            case CAMERA: return "Câmera segue (1)";
            default: return "Desligado (0)";
        }
    }

    /** O que o valor faz, para a tabela do personagem ({@code charSrc}) ou do jogo (so leitura). */
    static String describe(int wall, boolean charSrc) {
        switch (effective(wall)) {
            case MAP:
                return "Borda do mapa: ao encostar na borda da tela que também é o limite do mapa, o jogo salta para a próxima reação (COMP) e marca a batida na parede. O pouso deste passo vira quique (reação 12 do jogo).";
            case SCREEN:
                return charSrc
                        ? "Borda da tela: em qualquer borda da tela (a câmera não precisa estar no fim do mapa) o jogo salta para a próxima reação (COMP) e a câmera de deslocamento acompanha o oponente. O pouso deste passo vira quique (reação 12 do jogo)."
                        : "Nas reações do jogo o 3 age como o 2 (limite do mapa); só liga a câmera de deslocamento.";
            case CAMERA:
                return "Câmera segue: não cria sequência. Só depois de uma batida na parede (parede forçada de cena) a câmera passa a seguir o oponente.";
            default:
                return wall == OFF
                        ? "Desligado: sem sequência por parede. O COMP deste passo só vale ao pousar."
                        : "Valor " + wall + ": o jogo trata como 0 (desligado). Só 2 e 3 ativam a parede.";
        }
    }
}
