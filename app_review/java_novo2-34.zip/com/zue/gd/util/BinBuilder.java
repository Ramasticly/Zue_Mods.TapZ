package com.zue.gd.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * CAMADA DE COMPATIBILIDADE do Attack Editor (nao e o BinBuilder do compilador, que o jogo ja tem): so o que os extratores copiados sem alteracao usam.
 * {@link #buildHdatBlock} confere, na extracao, se o texto detalhado de um HDAT volta aos mesmos bytes; aqui quem compila e o leitor de TXT do app
 * (ExtractorBridge -> BinTxt). Onde o app nao sabe compilar o formato o resultado difere e o extrator grava $RAW (sempre exato e aceito pelo compilador).
 * Para ter o formato detalhado em todos os HDATs, troque este arquivo pelo BinBuilder real do compilador (as assinaturas sao as mesmas).
 */
final class BinBuilder {
    private BinBuilder() { }

    static final String QUOTED_TEXT = "\"([^\"\\\\]*+(?:\\\\.[^\"\\\\]*+)*+)\"\\s*,";

    static byte[] buildHdatBlock(String hdatBlock, int xsize, int ysize) throws IOException {
        return com.zue.attackeditor.ExtractorBridge.buildHdatBlock(hdatBlock);
    }

    /** Igual ao BinBuilder do compilador: desfaz o escape de um $T_N e codifica em cs; \xHH vira o byte HH cru. */
    static byte[] encodeText(String s, Charset cs) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(s.length() * 2);
        StringBuilder pending = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(i + 1);
                if (n == 'x' && i + 3 < s.length() && isHex(s.charAt(i + 2)) && isHex(s.charAt(i + 3))) {
                    byte[] e = pending.toString().getBytes(cs);
                    out.write(e, 0, e.length);
                    pending.setLength(0);
                    out.write(Integer.parseInt(s.substring(i + 2, i + 4), 16));
                    i += 3;
                    continue;
                }
                if (n == 'n') { pending.append('\n'); i++; continue; }
                if (n == 'r') { pending.append('\r'); i++; continue; }
                if (n == '"' || n == '\\') { pending.append(n); i++; continue; }
            }
            pending.append(c);
        }
        byte[] e = pending.toString().getBytes(cs);
        out.write(e, 0, e.length);
        return out.toByteArray();
    }

    private static boolean isHex(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }
}
