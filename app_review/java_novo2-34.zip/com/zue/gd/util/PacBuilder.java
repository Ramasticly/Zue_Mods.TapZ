package com.zue.gd.util;

/**
 * CAMADA DE COMPATIBILIDADE do Attack Editor (nao e do compilador): os extratores copiados sem alteracao so precisam deste simbolo do PacBuilder.
 * {@code isApp = false}: o PacExtractor grava em {@code assets/<pack>/} (o que o jogo e o app leem), nao em CHARS/SYSTEM.
 */
public final class PacBuilder {
    private PacBuilder() { }

    public static volatile boolean isApp = false;
}
