package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Zoom de camera das hitboxes 30/31 como o md 29 do jogo: alvo em tela (T, W), passos inteiros << 7, volta em 12 ticks, 90 % de longe. */
public class ActionZoomTest {
    static BattleSim make(int w, int frames, int dist, int t0) throws Exception {
        A[] a = new A[45];
        for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(5)).mpt(new M().time(5));
        M f0 = new M().time(t0);
        if (frames >= 0) f0.hit(30, 20, -40, w, frames);
        a[40] = new A().mpt(f0).mpt(new M().time(60));
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        BattleSim.cinematic = false;
        BattleSim.edgeMode = 1;
        return new BattleSim(dac(a), ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, dist, 0, 0);
    }

    public static void main(String[] args) throws Exception {
        BattleSim s = make(150, 10, 120, 30);
        int sx = (s.attackerX() * 65536 + (20 << 16) - s.screenLeft()) >> 16, sy = ((s.attackerY() - 40) * 65536 - s.screenTop()) >> 16;
        int tx = (240 - sx) * 150 / 100, ty = (160 - sy) * 150 / 100;
        check("tick 0 (o frame da hitbox ja roda ao criar): 1/10 do caminho em ponto fixo << 7 (W 100 -> 105)", s.zoomW(), 105);
        check("tick 0: Tx = passo inteiro do md 29", s.zoomTx(), ((tx << 7) / 10) >> 7);
        s.step();
        check("tick 1: 2/10 (W 110)", s.zoomW(), 110);
        for (int i = 0; i < 8; i++) s.step();
        check("10 ticks (FRAMES da hitbox): chega exato em W 150 e T = (240 - x, 160 - y) * 150 %", s.zoomW() + ":" + s.zoomTx() + ":" + s.zoomTy(), "150:" + tx + ":" + ty);
        float[] zr = s.zoomRect();
        check("retangulo amarelo: 480 / 1,5 = 320 px, centrado no ponto do hit", zr != null && Math.abs(zr[2] - zr[0] - 320f) < 0.01f && Math.abs((zr[0] + zr[2]) / 2 - (s.attackerX() + 20)) < 1f, true);
        for (int i = 0; i < 40; i++) s.step();                 // o frame 0 (30 ticks) acaba: sem a hitbox, volta a 100 % em 12 ticks
        check("depois do frame da hitbox volta a 100 % / T 0", s.zoomW() + ":" + s.zoomTx() + ":" + s.zoomTy() + ":" + (s.zoomRect() == null), "100:0:0:true");

        BattleSim k = make(100, 10, 120, 30);
        for (int i = 0; i < 12; i++) k.step();
        check("W 100 na hitbox: o alvo atual continua (sem zoom)", k.zoomW() + ":" + k.zoomActive(), "100:false");

        BattleSim z0 = make(150, 0, 120, 30);
        for (int i = 0; i < 12; i++) z0.step();
        check("FRAMES 0: o md 29 ignora a hitbox", z0.zoomW(), 100);

        BattleSim far = make(150, -1, 420, 30);
        for (int i = 0; i < 16; i++) far.step();
        check("lutadores a mais de 320 px: 90 % em 16 ticks", far.zoomW(), 90);

        // camadas fora da faixa da camera na vista do mundo (NORMAL/CHAR): vao para o retangulo amarelo com escala 1/z
        BattleSim.cinematic = true;
        float[] wv = s.worldViewXform(400);
        check("sem zoom: Frente nao muda", wv == null, true);
        BattleSim q = make(200, 4, 120, 30);
        for (int i = 0; i < 6; i++) q.step();
        float[] f = q.worldViewXform(400), r = q.zoomRect();
        float sl = q.screenLeft() / 65536f, st = q.screenTop() / 65536f;
        check("Frente com zoom 200 %: escala 0,5", f != null && Math.abs(f[0] - 0.5f) < 1e-4f, true);
        check("Frente: o canto (0, 0) da tela cai no canto do retangulo amarelo", f != null && Math.abs(sl * f[0] + f[2] - r[0]) < 0.01f && Math.abs(st * f[1] + f[3] - r[1]) < 0.01f, true);
        check("Frente: o canto (480, 320) cai no outro canto", f != null && Math.abs((sl + 480f) * f[0] + f[2] - r[2]) < 0.01f && Math.abs((st + 320f) * f[1] + f[3] - r[3]) < 0.01f, true);
        check("Meio (200) e Fundo (17) dentro da faixa: ja acompanham o mundo", (q.worldViewXform(200) == null) + ":" + (q.worldViewXform(17) == null) + ":" + (q.worldViewXform(328) != null), "true:true:true");
        GameScreen plain = GameScreen.plain();
        float[] m = q.gameXform(plain, 200);
        check("TELA: o ponto do hit vai para o meio da tela (240, 160) com 200 %", Math.abs((q.attackerX() + 20) * m[0] + m[2] - 240f) < 1.1f && Math.abs((q.attackerY() - 40) * m[1] + m[3] - 160f) < 1.1f, true);
        BattleSim.cinematic = true;
        System.out.println("ActionZoomTest fails=" + fails);
    }
}
