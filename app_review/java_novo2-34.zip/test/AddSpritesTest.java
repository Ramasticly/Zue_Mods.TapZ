package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Adicionar Sprite da timeline com varias: um Frame por sprite, mesmo time, padrao da sprite (absoluto), clamp de time. */
public class AddSpritesTest {
    static Ano.Mpt mpt(int image, int time) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags = 0x20; m.time = time; m.normalize();
        return m;
    }

    public static void main(String[] args) throws Exception {
        Ano.Mpt[] base = {mpt(0, 4), mpt(1, 5), mpt(2, 6)};
        SpriteDefaults.Store st = new SpriteDefaults.Store();
        st.setSizes(new SpriteDefaults.Store.Sizes() { public int[] logical(int sp) { return sp == 10 ? new int[]{40, 60} : sp == 11 ? new int[]{20, 30} : null; } });
        SpriteDefaults.Def d11 = new SpriteDefaults.Def();
        d11.zx = 150; d11.zy = 150; d11.midX = -15; d11.midY = -45; d11.rot = 3;
        st.set(11, d11);
        Ano.Mpt[] r = AddSprites.insert(base, 0, new int[]{10, 11}, 7, st);
        check("2 sprites entram depois do frame 0: 5 frames", r.length, 5);
        check("ordem: base, 10, 11, depois o resto", r[0].image + "," + r[1].image + "," + r[2].image + "," + r[3].image + "," + r[4].image, "0,10,11,1,2");
        check("todos os novos com time 7", r[1].time == 7 && r[2].time == 7, true);
        check("o frame de antes e os de depois ficam como estavam", r[0].time == 4 && r[3].time == 5 && r[4].time == 6, true);
        SpriteDefaults.Def a = SpriteDefaults.read(r[1]), b = SpriteDefaults.read(r[2]);
        check("sprite 10 (sem padrao guardado) nasce com o automatico: zoom 100, MID (-20,-60)", a.zx == 100 && a.midX == -20 && a.midY == -60, true);
        check("sprite 11 nasce com o padrao guardado: zoom 150, MID (-15,-45), rot 3", b.zx == 150 && b.zy == 150 && b.midX == -15 && b.midY == -45 && b.rot == 3, true);
        // absoluto: um Frame base com zoom/rotacao proprios nao contamina os novos
        Ano.Mpt tweaked = mpt(0, 4);
        SpriteDefaults.Def td = new SpriteDefaults.Def();
        td.zx = 300; td.zy = 300; td.rot = 90; td.flipH = true;
        Ano.Mpt[] r2 = AddSprites.insert(new Ano.Mpt[]{SpriteDefaults.write(tweaked, td)}, 0, new int[]{10}, 6, st);
        SpriteDefaults.Def n = SpriteDefaults.read(r2[1]);
        check("padrao absoluto: o zoom/rot/flip do frame base nao passam para o novo", n.zx == 100 && n.rot == 0 && !n.flipH, true);
        // time fora dos limites
        check("time 0 vira 1 e 999 vira 255", AddSprites.insert(base, 2, new int[]{10}, 0, st)[3].time + "," + AddSprites.insert(base, 2, new int[]{10}, 999, st)[3].time, "1,255");
        check("no ultimo frame tambem insere no fim", AddSprites.insert(base, 2, new int[]{10, 11}, 6, st).length, 5);
        check("nada marcado / frame invalido: lista igual", AddSprites.insert(base, 0, new int[0], 6, st) == base && AddSprites.insert(base, 9, new int[]{10}, 6, st) == base, true);
        check("a lista original nao muda", base.length == 3 && base[0].time == 4, true);
        check("clampTime", AddSprites.clampTime(-3) + "," + AddSprites.clampTime(7) + "," + AddSprites.clampTime(300), "1,7,255");

        // ---- modos
        Centralize.Sizes sz = new Centralize.Sizes() { public int[] logical(int sp) { return sp == 10 ? new int[]{40, 60} : sp == 11 ? new int[]{20, 30} : sp == 12 ? new int[]{50, 100} : null; } };
        // ordem da selecao (11 antes de 10) vale
        Ano.Mpt[] ord = AddSprites.insert(base, 0, new int[]{11, 10}, new AddSprites.Spec(AddSprites.Mode.DEFAULT, 6, null), st, sz, -1);
        check("a ordem dos frames novos e a da selecao (11, 10)", ord[1].image + "," + ord[2].image, "11,10");
        // CENTRAR: mantem o zoom do padrao (150% da 11) e centra
        Ano.Mpt[] ce = AddSprites.insert(base, 0, new int[]{11, 10}, new AddSprites.Spec(AddSprites.Mode.CENTER, 6, null), st, sz, 200);
        SpriteDefaults.Def c11 = SpriteDefaults.read(ce[1]), c10 = SpriteDefaults.read(ce[2]);
        check("CENTRAR sprite 11: zoom 150 fica, MID (-15,-45), rot 3 fica", c11.zx == 150 && c11.midX == -15 && c11.midY == -45 && c11.rot == 3, true);
        check("CENTRAR sprite 10 (sem padrao): zoom 100, MID (-20,-60)", c10.zx == 100 && c10.midX == -20 && c10.midY == -60, true);
        SpriteDefaults.Def moved = new SpriteDefaults.Def();
        moved.zx = 200; moved.zy = 200; moved.midX = 7; moved.midY = 9;
        st.set(12, moved);
        SpriteDefaults.Def c12 = SpriteDefaults.read(AddSprites.insert(base, 0, new int[]{12}, new AddSprites.Spec(AddSprites.Mode.CENTER, 6, null), st, sz, 200)[1]);
        check("CENTRAR: o zoom 200 do padrao fica e o MID vira (-50,-200)", c12.zx + "," + c12.midX + "," + c12.midY, "200,-50,-200");
        st.set(12, null);
        // REESCALAR: altura 120 de referencia
        Ano.Mpt[] re = AddSprites.insert(base, 0, new int[]{10, 11}, new AddSprites.Spec(AddSprites.Mode.RESCALE, 6, null), st, sz, 120);
        SpriteDefaults.Def r10 = SpriteDefaults.read(re[1]), r11 = SpriteDefaults.read(re[2]);
        check("REESCALAR sprite 10 (60 de altura -> 120): zoom 200, MID (-40,-120)", r10.zx + "," + r10.zy + "," + r10.midX + "," + r10.midY, "200,200,-40,-120");
        check("REESCALAR sprite 11 (30 -> 120): zoom 400, MID (-40,-120), rot 3 do padrao fica", r11.zx + "," + r11.midX + "," + r11.midY + "," + r11.rot, "400,-40,-120,3");
        SpriteDefaults.Def rn = SpriteDefaults.read(AddSprites.insert(base, 0, new int[]{10}, new AddSprites.Spec(AddSprites.Mode.RESCALE, 6, null), st, sz, -1)[1]);
        check("REESCALAR sem referencia cai em CENTRAR (zoom 100, MID -20,-60)", rn.zx + "," + rn.midX + "," + rn.midY, "100,-20,-60");
        // PADRAO
        SpriteDefaults.Def pd = SpriteDefaults.read(AddSprites.insert(base, 0, new int[]{11}, new AddSprites.Spec(AddSprites.Mode.DEFAULT, 6, null), st, sz, 120)[1]);
        check("PADRAO = o guardado", pd.equals(d11), true);
        // DEFINIR
        AddSprites.Define df = new AddSprites.Define();
        Ano.Mpt[] de = AddSprites.insert(base, 0, new int[]{10, 11}, new AddSprites.Spec(AddSprites.Mode.DEFINE, 9, df), st, sz, 120);
        SpriteDefaults.Def e10 = SpriteDefaults.read(de[1]), e11 = SpriteDefaults.read(de[2]);
        check("DEFINIR padrao: centrada por sprite, zoom 100, rot 0, alpha 100%, ignora o padrao guardado", e10.midX + "," + e10.midY + "," + e11.midX + "," + e11.midY + "," + e11.zx + "," + e11.rot + "," + e11.alpha, "-20,-60,-10,-30,100,0,0");
        check("DEFINIR time 9 e sem caixas", de[1].time + "," + de[1].hits.length + "," + de[2].hits.length + "," + (de[1].flags & 0x10), "9,0,0,0");
        df.posCentered = false; df.midX = -5; df.midY = -7; df.zx = 80; df.zy = 90; df.rot = 15; df.alphaPct = 50;
        df.hit.on = true; df.hit.x = 1; df.hit.y = 2; df.hit.w = 30; df.hit.h = 40;
        df.hurt.on = true; df.hurt.x = -10; df.hurt.y = -20; df.hurt.w = 20; df.hurt.h = 50;
        Ano.Mpt[] dg = AddSprites.insert(base, 0, new int[]{10, 11}, new AddSprites.Spec(AddSprites.Mode.DEFINE, 6, df), st, sz, 120);
        SpriteDefaults.Def g10 = SpriteDefaults.read(dg[1]);
        check("DEFINIR fixo: MID (-5,-7), zoom 80x90, rot 15, alpha bruto 127 (alpha final 128)", g10.midX + "," + g10.midY + "," + g10.zx + "," + g10.zy + "," + g10.rot + "," + g10.alpha, "-5,-7,80,90,15,127");
        check("DEFINIR: hurtbox (flag 1) e hitbox (flag 2) nos DOIS frames novos", dg[1].hits.length + "," + dg[1].hits[0].flag + "," + dg[1].hits[1].flag + "," + dg[2].hits.length + "," + ((dg[2].flags & 0x10) != 0), "2,1,2,2,true");
        check("DEFINIR: valores das caixas", dg[2].hits[1].x + "," + dg[2].hits[1].y + "," + dg[2].hits[1].width + "," + dg[2].hits[1].height + "|" + dg[2].hits[0].x + "," + dg[2].hits[0].height, "1,2,30,40|-10,50");
        check("so os Frames adicionados ganham as caixas", dg[0].hits.length + "," + dg[3].hits.length + "," + dg[4].hits.length, "0,0,0");
        df.hurt.on = false;
        check("so hitbox ligada: uma caixa de flag 2", AddSprites.insert(base, 0, new int[]{10}, new AddSprites.Spec(AddSprites.Mode.DEFINE, 6, df), st, sz, 120)[1].hits.length + "", "1");
        check("alpha 100% = 0 bruto e 0% = 255", new AddSprites.Define().alphaRaw() + "," + alphaOf(0), "0,255");
        check("lista original continua intacta", base[1].hits.length == 0 && base.length == 3, true);
        check("ida e volta ms <-> ticks: time N em ticks vira o mesmo N", SpriteGroups.ticks(Math.round(7 * 1000f / 60f)) + "," + SpriteGroups.ticks(Math.round(1 * 1000f / 60f)) + "," + SpriteGroups.ticks(Math.round(255 * 1000f / 60f)), "7,1,255");
    }

    static int alphaOf(int pct) { AddSprites.Define d = new AddSprites.Define(); d.alphaPct = pct; return d.alphaRaw(); }
}
