package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Adicionar Sprite da timeline com varias: um Frame por sprite, mesmo time, padrao da sprite (absoluto), clamp de time. */
public class AddSpritesTest {
    static Ano.Mpt mpt(int image, int time) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags = 0x20; m.time = time; m.normalize();
        return m;
    }

    public static void main(String[] args) throws Exception {
        Ano.Mpt[] base = {mpt(0, 4), mpt(1, 5), mpt(2, 6)};
        SpriteDefaults.Store st = new SpriteDefaults.Store();
        st.setSizes(new SpriteDefaults.Store.Sizes() { public int[] logical(int sp) { return sp == 10 ? new int[]{40, 60} : sp == 11 ? new int[]{20, 30} : null; } });
        SpriteDefaults.Def d11 = new SpriteDefaults.Def();
        d11.zx = 150; d11.zy = 150; d11.midX = -15; d11.midY = -45; d11.rot = 3;
        st.set(11, d11);
        Ano.Mpt[] r = AddSprites.insert(base, 0, new int[]{10, 11}, 7, st);
        check("2 sprites entram depois do frame 0: 5 frames", r.length, 5);
        check("ordem: base, 10, 11, depois o resto", r[0].image + "," + r[1].image + "," + r[2].image + "," + r[3].image + "," + r[4].image, "0,10,11,1,2");
        check("todos os novos com time 7", r[1].time == 7 && r[2].time == 7, true);
        check("o frame de antes e os de depois ficam como estavam", r[0].time == 4 && r[3].time == 5 && r[4].time == 6, true);
        SpriteDefaults.Def a = SpriteDefaults.read(r[1]), b = SpriteDefaults.read(r[2]);
        check("sprite 10 (sem padrao guardado) nasce com o automatico: zoom 100, MID (-20,-60)", a.zx == 100 && a.midX == -20 && a.midY == -60, true);
        check("sprite 11 nasce com o padrao guardado: zoom 150, MID (-15,-45), rot 3", b.zx == 150 && b.zy == 150 && b.midX == -15 && b.midY == -45 && b.rot == 3, true);
        // absoluto: um Frame base com zoom/rotacao proprios nao contamina os novos
        Ano.Mpt tweaked = mpt(0, 4);
        SpriteDefaults.Def td = new SpriteDefaults.Def();
        td.zx = 300; td.zy = 300; td.rot = 90; td.flipH = true;
        Ano.Mpt[] r2 = AddSprites.insert(new Ano.Mpt[]{SpriteDefaults.write(tweaked, td)}, 0, new int[]{10}, 6, st);
        SpriteDefaults.Def n = SpriteDefaults.read(r2[1]);
        check("padrao absoluto: o zoom/rot/flip do frame base nao passam para o novo", n.zx == 100 && n.rot == 0 && !n.flipH, true);
        // time fora dos limites
        check("time 0 vira 1 e 999 vira 255", AddSprites.insert(base, 2, new int[]{10}, 0, st)[3].time + "," + AddSprites.insert(base, 2, new int[]{10}, 999, st)[3].time, "1,255");
        check("no ultimo frame tambem insere no fim", AddSprites.insert(base, 2, new int[]{10, 11}, 6, st).length, 5);
        check("nada marcado / frame invalido: lista igual", AddSprites.insert(base, 0, new int[0], 6, st) == base && AddSprites.insert(base, 9, new int[]{10}, 6, st) == base, true);
        check("a lista original nao muda", base.length == 3 && base[0].time == 4, true);
        check("clampTime", AddSprites.clampTime(-3) + "," + AddSprites.clampTime(7) + "," + AddSprites.clampTime(300), "1,7,255");
        check("ida e volta ms <-> ticks: time N em ticks vira o mesmo N", SpriteGroups.ticks(Math.round(7 * 1000f / 60f)) + "," + SpriteGroups.ticks(Math.round(1 * 1000f / 60f)) + "," + SpriteGroups.ticks(Math.round(255 * 1000f / 60f)), "7,1,255");
    }
}
