package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** TBRHelp.md (Ajuda de IA): conteudo, exemplos que o parser do app le de volta, limites iguais ao validador e determinismo. */
public class AiHelpTest {
    static boolean distinct(int[] a) { java.util.Set<Integer> s = new HashSet<Integer>(); for (int x : a) if (x < 0 || x > 46 || x % 2 != 0 || !s.add(x)) return false; return true; }

    public static void main(String[] args) throws Exception {
        String doc = AiHelp.build("java_novo2-34");
        String again = AiHelp.build("java_novo2-34");
        check("determinístico: duas geracoes iguais", doc.equals(again), true);
        int bytes = doc.getBytes("UTF-8").length;
        check("tamanho entre 30 KB e 400 KB (" + bytes + " bytes)", bytes > 30 * 1024 && bytes < 400 * 1024, true);
        check("sem marcadores soltos ({{ }}) nem TODO", !doc.contains("{{") && !doc.contains("}}") && !doc.contains("TODO") && !doc.contains("%s"), true);
        check("cercas ``` balanceadas", countOf(doc, "\n```") % 2 == 0 || countOf(doc, "```") % 2 == 0, true);

        // idioma e instrucoes para a IA
        check("diz que o arquivo esta em ingles por conveniencia e nao e o idioma do usuario", doc.contains("written in English only because that is convenient for you") && doc.contains("**not necessarily the user's language**"), true);
        check("manda responder no idioma do usuario", doc.contains("always answer in the user's language"), true);
        check("contrato de saida e checklist presentes", doc.contains("## 12. OUTPUT CONTRACT") && doc.contains("## 9. Validation checklist"), true);
        check("pede os arquivos certos (000.dac.txt, 000.bin.txt, 000.cnv.txt)", doc.contains("`000.dac.txt`, `000.bin.txt`, `000.cnv.txt`"), true);
        check("diz que a IA nao cria PNG/WAV", doc.contains("cannot create or edit **images (PNG) or sounds (WAV)**"), true);

        // secoes numeradas existem uma vez
        List<String> secs = AiHelp.sectionTitles(doc);
        Set<String> uniq = new HashSet<String>(secs);
        check("titulos de secao unicos", secs.size(), uniq.size());
        String[] want = {"0. READ THIS FIRST", "1. What the app is", "2. Files and folders", "3. Text formats", "4. What to ask the user", "5. Data dictionary",
                "6. How a move works", "7. Limits", "8. Recipes", "9. Validation checklist", "10. How to test", "11. Screens and buttons", "12. OUTPUT CONTRACT",
                "13. Saving", "14. FAQ", "Appendix A"};
        boolean allSecs = true;
        StringBuilder missing = new StringBuilder();
        for (String w : want) {
            boolean found = false;
            for (String s : secs) found |= s.startsWith(w);
            if (!found) { allSecs = false; missing.append(w).append("; "); }
        }
        check("todas as secoes 0..14 e o anexo existem " + missing, allSecs, true);
        check("indice (Contents) lista as secoes", doc.contains("- 5. Data dictionary") && doc.contains("- Appendix A"), true);

        // exemplos: o app le de volta o que escreveu no documento
        String ano = block(doc, "DAC_ACT_ {\n");
        String inner = ano.substring(ano.indexOf("$ANO_5"), ano.lastIndexOf("// ... the other ANOs ...")).trim();
        inner = inner.substring(0, inner.lastIndexOf("},") + 2);
        Ano parsed = DacText.parseAno(inner, 5, null);
        check("exemplo de ANO: relido pelo parser do app (3 frames, 1 link, prio 3)", parsed.mpts.length + ":" + parsed.links.length + ":" + parsed.priority, "3:1:3");
        check("exemplo de ANO: reescrever da o mesmo texto", DacText.ano(parsed, -1).replaceAll("\\s+", "").equals(inner.replaceAll("\\s+", "")), true);
        check("exemplo de frame: velocidade, aceleracao, WACTFLAG 64, OPT de dano 12 e reacao 52", parsed.mpts[1].moveMask == 5 && parsed.mpts[1].wActFlag == 64 && parsed.mpts[1].optData[0] == 12 && parsed.mpts[1].optData[1] == 52, true);

        CharData.Move mv = new CharData.Move();
        String golpe = AiHelp.sampleGolpe();
        DacText.parseMove(golpe, mv);
        check("exemplo de golpe: relido (ANIM_INICIAL 5, projetil 21, SEQ chao 6, END 7)", mv.animInicial + ":" + mv.projNormal + ":" + mv.animSeqChao + ":" + mv.animEndChao, "5:21:6:7");
        check("exemplo de golpe esta no documento", doc.contains(golpe), true);
        String react = AiHelp.sampleReaction();
        check("exemplo de reacao tem $info, $REACAO_DANO_3 e 2 linhas $FR_", react.contains("$HDAT_17") && react.contains("$REACAO_DANO_3") && react.contains("$FR_1") && !react.contains("$FR_2") && react.contains("$ROW: 2"), true);
        Cnv cnv = Cnv.fromTxt(AiHelp.sampleCnv(), true);
        check("exemplo de CNV relido (2 entradas)", cnv != null && cnv.toTxt().contains("$SPR_1") && !cnv.toTxt().contains("$SPR_2"), true);

        // tudo que o app define aparece no documento
        boolean keys = true;
        StringBuilder lost = new StringBuilder();
        for (String k : DacText.MOVE_KEYS) if (!doc.contains("`" + k + "`")) { keys = false; lost.append(k).append(' '); }
        check("todos os campos do HDAT 4 estao no dicionario " + lost, keys, true);
        check("uma descricao por campo do HDAT 4", AiHelp.MOVE_DOC.length, DacText.MOVE_KEYS.length);
        boolean docs = true;
        for (String s : AiHelp.MOVE_DOC) docs &= s.length() > 10;
        check("descricoes dos campos nao vazias", docs, true);
        check("bits do ATK_FLAGS (1,2,4,8,16,32,64,128)", doc.contains("| 1 | GROUND_ONLY") && doc.contains("| 128 | GRAB_HIT") && doc.contains("| 16 | GHOST"), true);

        check("limites impressos = GameRules", doc.contains("| Boxes (`$HITS`) per frame | " + GameRules.MAX_HITS + " |") && doc.contains("| Links per ANO | " + GameRules.MAX_LINKS + " |")
                && doc.contains("| Frames (`$MPT`) per ANO | " + GameRules.MAX_MPTS + " |") && doc.contains("| `$TIME` per frame | " + GameRules.MAX_TIME + " |")
                && doc.contains("(reaction code) with a hitbox | " + GameRules.MAX_OPT1 + " "), true);
        check("grupos de reacao vem da classe Opt1 (efeito/som/empurrao/hitstop)", doc.contains("| 2 | strong | 100–149 | 1 | se_06 | yes | normal |") && doc.contains("| 3 | light | 150–199 | 0 | se_03 | no | half (melee) |")
                && doc.contains("| 4 | no effect | 200–249 | none | none | no | none |"), true);
        check("flags dos hits do jogo (0 projetil, 38 bloquear seq, 71-125 ANO 201+)", doc.contains("| 38 | **Block the sequence**") && doc.contains("`201 + (f − 71)`"), true);
        check("reacao: colunas (14) e unidades", doc.contains("`DUR_C`") && doc.contains("`COMP`") && doc.contains("`VOZ`") && doc.contains("Unit **1 = 0.1 px per tick**"), true);
        check("diz onde ficam os arquivos (assets/charNN, TBRE/Chars, TBRE/Backups)", doc.contains("assets/") && doc.contains("TBRE/") && doc.contains("Chars/charNN/") && doc.contains("Backups/"), true);

        // anexo: toda secao da ajuda do app esta, literalmente
        boolean appendix = true;
        StringBuilder gone = new StringBuilder();
        for (HelpText.Chapter ch : HelpText.chapters()) {
            for (HelpText.Section s : ch.sections) if (!doc.contains("#### " + s.title + "\n\n" + s.body)) { appendix = false; gone.append(s.title).append("; "); }
        }
        check("anexo A tem todas as secoes da ajuda do app " + gone, appendix, true);
        check("botoes do menu superior citados", doc.contains("`SALVAR`") && doc.contains("`FR-PREVIEW`") && doc.contains("`HIDE-EFF`") && doc.contains("`TRANSIÇÃO`"), true);

        // secao 15: regras internas do motor, com rotulos de confianca
        check("secao 15 existe e esta no indice", secs.contains("15. Engine internals — answers to the questions an AI asked about the combat system") && doc.contains("- 15. Engine internals"), true);
        int s15 = doc.indexOf("\n## 15. "), s15end = doc.indexOf("\n## Appendix A");
        check("secao 15 fica entre a 14 e o anexo A", doc.indexOf("\n## 14. ") < s15 && s15 < s15end, true);
        String sec15 = doc.substring(s15, s15end);
        boolean allSub = true;
        StringBuilder noSub = new StringBuilder();
        for (int i = 1; i <= 13; i++) if (!sec15.contains("\n### 15." + i + " ")) { allSub = false; noSub.append(i).append(' '); }
        check("subsecoes 15.1 a 15.13 presentes " + noSub, allSub, true);
        check("legenda dos rotulos CODE / DOC / INFERRED / UNKNOWN", sec15.contains("[CODE") && sec15.contains("[DOC") && sec15.contains("[INFERRED") && sec15.contains("[UNKNOWN"), true);
        boolean tagged = true;
        StringBuilder untagged = new StringBuilder();
        String[] parts = sec15.split("\n### 15\\.");
        for (int i = 1; i < parts.length; i++) if (!(parts[i].contains("[CODE") || parts[i].contains("[DOC") || parts[i].contains("[INFERRED") || parts[i].contains("[UNKNOWN"))) { tagged = false; untagged.append(i).append(' '); }
        check("cada subsecao tem pelo menos um rotulo de confianca " + untagged, tagged, true);
        check("tabela nome da pergunta -> nome real (PlayerAttack, AttackEnd, CommonNormal, CheckOptFlag)", sec15.contains("PlayerAttack") && sec15.contains("AttackEnd") && sec15.contains("CommonNormal") && sec15.contains("CheckOptFlag") && sec15.contains("does not exist"), true);
        check("correcao ABAIXO/ACIMA: o atacante, nao o oponente", sec15.contains("**attacker** is ≥ 51 px lower") && !doc.substring(0, s15).contains("opponent far below") && !doc.contains("opponent far above"), true);
        check("MOVE_BYTE tem um offset distinto e par por campo", AiHelp.MOVE_BYTE.length == DacText.MOVE_KEYS.length && distinct(AiHelp.MOVE_BYTE), true);
        check("tabela do HDAT 4 tem a coluna de offset em bytes (offsets reais do registro)", doc.contains("| # | byte offset | `$KEY` | Meaning |") && doc.contains("| 3 | 34 | `PROJETIL_ANIM_ABAIXO`"), true);
        check("bits do WACTFLAG: 1 repete, 16/32 espelham", doc.contains("**1 = loop back to the first frame") && doc.contains("**16 / 32 = flip X / flip Y**"), true);
        check("exemplos de validacao e o que nao da para reproduzir", sec15.contains("validation tests") && sec15.contains("cannot be reproduced"), true);

        // citacoes jogo:N apontam para linhas que existem no codigo do jogo (se o arquivo estiver ao lado)
        java.util.regex.Matcher cm = java.util.regex.Pattern.compile("jogo:(\\d+)(?:-(\\d+))?").matcher(doc);
        int cites = 0, badRange = 0, maxLine = 0;
        while (cm.find()) {
            cites++;
            int a = Integer.parseInt(cm.group(1)), b = cm.group(2) == null ? a : Integer.parseInt(cm.group(2));
            if (b < a) badRange++;
            maxLine = Math.max(maxLine, b);
        }
        check("citacoes jogo:N existem (" + cites + ") e nenhum intervalo e invertido", cites >= 120 && badRange == 0, true);
        java.io.File game = null;
        for (String path : new String[]{"../TCBManajer.java", "../../TCBManajer.java", "../../../TCBManajer.java", "/home/user/Zue_Mods.TapZ/TCBManajer.java"})
            if (new java.io.File(path).isFile()) { game = new java.io.File(path); break; }
        if (game == null) System.out.println("(TCBManajer.java nao encontrado: citacoes jogo:N nao conferidas contra o codigo)");
        else {
            java.util.List<String> src = java.nio.file.Files.readAllLines(game.toPath(), java.nio.charset.Charset.forName("UTF-8"));
            check("todas as citacoes jogo:N cabem no arquivo do jogo (" + maxLine + " <= " + src.size() + ")", maxLine <= src.size(), true);
            String[][] defs = {{"boolean CommonNormal", "CommonNormal"}, {"CheckOptFlag", "CheckOptFlag"}, {"StartPlayerAttack", "StartPlayerAttack"}, {"_ActReqMain", "_ActReqMain"},
                    {"DamageChange", "DamageChange"}, {"void AttackEnd", "AttackEnd"}, {"PlayerTail", "PlayerTail"}, {"DamageEnd", "DamageEnd"}, {"CheckObjHit", "CheckObjHit"}, {"BulletAction", "BulletAction"}};
            StringBuilder gone2 = new StringBuilder();
            StringBuilder all = new StringBuilder();
            for (String l : src) all.append(l).append('\n');
            for (String[] d : defs) if (!all.toString().contains(d[0]) || !sec15.contains(d[1])) gone2.append(d[0]).append("; ");
            check("nomes reais do motor existem no codigo do jogo e na secao 15 " + gone2, gone2.length(), 0);
            // cada \"jogo:N\" colado a um nome de metodo do jogo (CommonNormal, StartPlayerAttack...) aponta para linha dentro de um metodo com esse nome nas proximidades
            java.util.regex.Matcher mm = java.util.regex.Pattern.compile("`(CheckOptFlag|CheckObjHit|DamageChange|DamageEnd|AttackEnd)`[^`\\n]{0,25}?jogo:(\\d+)").matcher(sec15);
            int checked = 0, wrong = 0;
            StringBuilder wrongList = new StringBuilder();
            while (mm.find()) {
                int line = Integer.parseInt(mm.group(2));
                boolean near = false;
                for (int k = Math.max(1, line - 400); k <= Math.min(src.size(), line + 40) && !near; k++) near = src.get(k - 1).contains(mm.group(1));
                checked++;
                if (!near) { wrong++; wrongList.append(mm.group(1)).append("@").append(line).append(' '); }
            }
            check("citacoes de metodos do jogo (" + checked + ") caem perto do metodo citado " + wrongList, wrong, 0);
        }
        check("nome do arquivo", AiHelp.FILE_NAME, "TBRHelp.md");

        System.out.println("AiHelpTest fails=" + BattleTest.fails);
    }

    static int countOf(String s, String sub) {
        int n = 0, i = 0;
        while ((i = s.indexOf(sub, i)) >= 0) { n++; i += sub.length(); }
        return n;
    }

    /** O bloco de codigo (entre cercas) que contem {@code marker}. */
    static String block(String doc, String marker) {
        int at = doc.indexOf(marker);
        int a = doc.lastIndexOf("```", at);
        int z = doc.indexOf("```", at);
        return doc.substring(doc.indexOf('\n', a) + 1, z);
    }
}
