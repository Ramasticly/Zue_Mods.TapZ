package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** TBRHelp.md (Ajuda de IA): conteudo, exemplos que o parser do app le de volta, limites iguais ao validador e determinismo. */
public class AiHelpTest {
    public static void main(String[] args) throws Exception {
        String doc = AiHelp.build("java_novo2-34");
        String again = AiHelp.build("java_novo2-34");
        check("determinístico: duas geracoes iguais", doc.equals(again), true);
        int bytes = doc.getBytes("UTF-8").length;
        check("tamanho entre 30 KB e 400 KB (" + bytes + " bytes)", bytes > 30 * 1024 && bytes < 400 * 1024, true);
        check("sem marcadores soltos ({{ }}) nem TODO", !doc.contains("{{") && !doc.contains("}}") && !doc.contains("TODO") && !doc.contains("%s"), true);
        check("cercas ``` balanceadas", countOf(doc, "\n```") % 2 == 0 || countOf(doc, "```") % 2 == 0, true);

        // idioma e instrucoes para a IA
        check("diz que o arquivo esta em ingles por conveniencia e nao e o idioma do usuario", doc.contains("written in English only because that is convenient for you") && doc.contains("**not necessarily the user's language**"), true);
        check("manda responder no idioma do usuario", doc.contains("always answer in the user's language"), true);
        check("contrato de saida e checklist presentes", doc.contains("## 12. OUTPUT CONTRACT") && doc.contains("## 9. Validation checklist"), true);
        check("pede os arquivos certos (000.dac.txt, 000.bin.txt, 000.cnv.txt)", doc.contains("`000.dac.txt`, `000.bin.txt`, `000.cnv.txt`"), true);
        check("diz que a IA nao cria PNG/WAV", doc.contains("cannot create or edit **images (PNG) or sounds (WAV)**"), true);

        // secoes numeradas existem uma vez
        List<String> secs = AiHelp.sectionTitles(doc);
        Set<String> uniq = new HashSet<String>(secs);
        check("titulos de secao unicos", secs.size(), uniq.size());
        String[] want = {"0. READ THIS FIRST", "1. What the app is", "2. Files and folders", "3. Text formats", "4. What to ask the user", "5. Data dictionary",
                "6. How a move works", "7. Limits", "8. Recipes", "9. Validation checklist", "10. How to test", "11. Screens and buttons", "12. OUTPUT CONTRACT",
                "13. Saving", "14. FAQ", "Appendix A"};
        boolean allSecs = true;
        StringBuilder missing = new StringBuilder();
        for (String w : want) {
            boolean found = false;
            for (String s : secs) found |= s.startsWith(w);
            if (!found) { allSecs = false; missing.append(w).append("; "); }
        }
        check("todas as secoes 0..14 e o anexo existem " + missing, allSecs, true);
        check("indice (Contents) lista as secoes", doc.contains("- 5. Data dictionary") && doc.contains("- Appendix A"), true);

        // exemplos: o app le de volta o que escreveu no documento
        String ano = block(doc, "DAC_ACT_ {\n");
        String inner = ano.substring(ano.indexOf("$ANO_5"), ano.lastIndexOf("// ... the other ANOs ...")).trim();
        inner = inner.substring(0, inner.lastIndexOf("},") + 2);
        Ano parsed = DacText.parseAno(inner, 5, null);
        check("exemplo de ANO: relido pelo parser do app (3 frames, 1 link, prio 3)", parsed.mpts.length + ":" + parsed.links.length + ":" + parsed.priority, "3:1:3");
        check("exemplo de ANO: reescrever da o mesmo texto", DacText.ano(parsed, -1).replaceAll("\\s+", "").equals(inner.replaceAll("\\s+", "")), true);
        check("exemplo de frame: velocidade, aceleracao, WACTFLAG 64, OPT de dano 12 e reacao 52", parsed.mpts[1].moveMask == 5 && parsed.mpts[1].wActFlag == 64 && parsed.mpts[1].optData[0] == 12 && parsed.mpts[1].optData[1] == 52, true);

        CharData.Move mv = new CharData.Move();
        String golpe = AiHelp.sampleGolpe();
        DacText.parseMove(golpe, mv);
        check("exemplo de golpe: relido (ANIM_INICIAL 5, projetil 21, SEQ chao 6, END 7)", mv.animInicial + ":" + mv.projNormal + ":" + mv.animSeqChao + ":" + mv.animEndChao, "5:21:6:7");
        check("exemplo de golpe esta no documento", doc.contains(golpe), true);
        String react = AiHelp.sampleReaction();
        check("exemplo de reacao tem $info, $REACAO_DANO_3 e 2 linhas $FR_", react.contains("$HDAT_17") && react.contains("$REACAO_DANO_3") && react.contains("$FR_1") && !react.contains("$FR_2") && react.contains("$ROW: 2"), true);
        Cnv cnv = Cnv.fromTxt(AiHelp.sampleCnv(), true);
        check("exemplo de CNV relido (2 entradas)", cnv != null && cnv.toTxt().contains("$SPR_1") && !cnv.toTxt().contains("$SPR_2"), true);

        // tudo que o app define aparece no documento
        boolean keys = true;
        StringBuilder lost = new StringBuilder();
        for (String k : DacText.MOVE_KEYS) if (!doc.contains("`" + k + "`")) { keys = false; lost.append(k).append(' '); }
        check("todos os campos do HDAT 4 estao no dicionario " + lost, keys, true);
        check("uma descricao por campo do HDAT 4", AiHelp.MOVE_DOC.length, DacText.MOVE_KEYS.length);
        boolean docs = true;
        for (String s : AiHelp.MOVE_DOC) docs &= s.length() > 10;
        check("descricoes dos campos nao vazias", docs, true);
        check("bits do ATK_FLAGS (1,2,4,8,16,32,64,128)", doc.contains("| 1 | GROUND_ONLY") && doc.contains("| 128 | GRAB_HIT") && doc.contains("| 16 | GHOST"), true);

        check("limites impressos = GameRules", doc.contains("| Boxes (`$HITS`) per frame | " + GameRules.MAX_HITS + " |") && doc.contains("| Links per ANO | " + GameRules.MAX_LINKS + " |")
                && doc.contains("| Frames (`$MPT`) per ANO | " + GameRules.MAX_MPTS + " |") && doc.contains("| `$TIME` per frame | " + GameRules.MAX_TIME + " |")
                && doc.contains("(reaction code) with a hitbox | " + GameRules.MAX_OPT1 + " "), true);
        check("grupos de reacao vem da classe Opt1 (efeito/som/empurrao/hitstop)", doc.contains("| 2 | strong | 100–149 | 1 | se_06 | yes | normal |") && doc.contains("| 3 | light | 150–199 | 0 | se_03 | no | half (melee) |")
                && doc.contains("| 4 | no effect | 200–249 | none | none | no | none |"), true);
        check("flags dos hits do jogo (0 projetil, 38 bloquear seq, 71-125 ANO 201+)", doc.contains("| 38 | **Block the sequence**") && doc.contains("`201 + (f − 71)`"), true);
        check("reacao: colunas (14) e unidades", doc.contains("`DUR_C`") && doc.contains("`COMP`") && doc.contains("`VOZ`") && doc.contains("Unit **1 = 0.1 px per tick**"), true);
        check("diz onde ficam os arquivos (assets/charNN, TBRE/Chars, TBRE/Backups)", doc.contains("assets/") && doc.contains("TBRE/") && doc.contains("Chars/charNN/") && doc.contains("Backups/"), true);

        // anexo: toda secao da ajuda do app esta, literalmente
        boolean appendix = true;
        StringBuilder gone = new StringBuilder();
        for (HelpText.Chapter ch : HelpText.chapters()) {
            for (HelpText.Section s : ch.sections) if (!doc.contains("#### " + s.title + "\n\n" + s.body)) { appendix = false; gone.append(s.title).append("; "); }
        }
        check("anexo A tem todas as secoes da ajuda do app " + gone, appendix, true);
        check("botoes do menu superior citados", doc.contains("`SALVAR`") && doc.contains("`FR-PREVIEW`") && doc.contains("`HIDE-EFF`") && doc.contains("`TRANSIÇÃO`"), true);
        check("nome do arquivo", AiHelp.FILE_NAME, "TBRHelp.md");

        System.out.println("AiHelpTest fails=" + BattleTest.fails);
    }

    static int countOf(String s, String sub) {
        int n = 0, i = 0;
        while ((i = s.indexOf(sub, i)) >= 0) { n++; i += sub.length(); }
        return n;
    }

    /** O bloco de codigo (entre cercas) que contem {@code marker}. */
    static String block(String doc, String marker) {
        int at = doc.indexOf(marker);
        int a = doc.lastIndexOf("```", at);
        int z = doc.indexOf("```", at);
        return doc.substring(doc.indexOf('\n', a) + 1, z);
    }
}
