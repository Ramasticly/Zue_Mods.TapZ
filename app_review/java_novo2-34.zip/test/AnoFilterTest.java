package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Filtros da grade: reordenam sem esconder; os que casam vem primeiro. */
public class AnoFilterTest {
    public static void main(String[] args) throws Exception {
        A[] a = new A[12];
        a[0] = new A().mpt(new M().time(5).img(1));                                            // 5 ticks, 1 frame
        a[1] = new A().mpt(new M().time(10).img(1).hit(2, 0, 0, 10, 10)).mpt(new M().time(10).img(1));   // hitbox, 20 ticks, 2 frames
        a[2] = new A().mpt(new M().time(3).img(1)).mpt(new M().time(3).img(1)).mpt(new M().time(3).img(1)).mpt(new M().time(3).img(1));   // 12 ticks, 4 frames
        a[3] = new A().mpt(new M().time(60).img(1).hit(0, 0, 0, 0, 0));                        // projetil, 60 ticks, 1 frame
        a[4] = new A().mpt(new M().time(5).img(1).hit(71, 0, 0, 0, 0));                        // aponta para o efeito do personagem (ANO 201)
        a[5] = new A().mpt(new M().time(5).img(1));
        a[6] = new A().mpt(new M().time(5).img(1));
        for (int i = 7; i < 12; i++) a[i] = new A().mpt(new M().time(5).img(1));
        Dac d = dac(a);
        byte[] m0 = move(new int[]{2, 5}), m1 = move(new int[]{2, 6}), both = new byte[m0.length + m1.length];
        System.arraycopy(m0, 0, both, 0, m0.length); System.arraycopy(m1, 0, both, m0.length, m1.length);
        CharData cd = chr(both, new byte[][] {});
        cd.moves[0].animInicial = 5; cd.moves[1].animInicial = 6;

        AnoFilter.Result def = AnoFilter.apply(AnoFilter.DEFAULT, d, cd);
        check("Padrao: ordem numerica, ninguem com moldura", def.order.toString() + ":" + def.matches, "[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]:0");
        AnoFilter.Result atk = AnoFilter.apply(AnoFilter.ATTACK, d, cd);
        check("Ataque: hitbox e projetil no topo, o resto embaixo (nada some)", atk.order.toString() + ":" + atk.matches, "[1, 3, 0, 2, 4, 5, 6, 7, 8, 9, 10, 11]:2");
        check("Ataque: moldura so nos que casam", atk.matched[1] && atk.matched[3] && !atk.matched[0], true);
        AnoFilter.Result tm = AnoFilter.apply(AnoFilter.TIME, d, cd);
        check("Tempo: mais ticks primeiro", tm.order.subList(0, 4).toString(), "[3, 1, 2, 0]");
        AnoFilter.Result fr = AnoFilter.apply(AnoFilter.FRAMES, d, cd);
        check("Frames: mais Frames (nao ticks) primeiro", fr.order.subList(0, 3).toString(), "[2, 1, 0]");
        AnoFilter.Result mv = AnoFilter.apply(AnoFilter.MOVES, d, cd);
        check("Golpes: ANOs de golpes do BIN primeiro", mv.order.subList(0, 2).toString() + ":" + mv.matches, "[5, 6]:2");
        AnoFilter.Result fx = AnoFilter.apply(AnoFilter.EFFECTS, new_dac_with_effect(), cd);
        check("Efeitos: ANO 201 (efeito do personagem) no topo", fx.order.get(0).intValue(), 201);
        AnoFilter.Result im = AnoFilter.apply(AnoFilter.IMPORTANCE, d, cd);
        check("Importancia: com as notas manuais (AnoNotes) todos os ANOs 0 a 11 tem info; a ordem do fim continua por numero", im.order.subList(8, 12).toString() + ":" + im.matches, "[8, 9, 10, 11]:12");
        check("todos os filtros mantem todas as ANOs", AnoFilter.apply(AnoFilter.TIME, d, cd).order.size() + AnoFilter.apply(AnoFilter.EFFECTS, d, cd).order.size(), 24);
        System.out.println("AnoFilterTest fails=" + fails);
    }

    static Dac new_dac_with_effect() throws Exception {
        A[] a = new A[205];
        for (int i = 0; i < a.length; i++) a[i] = new A().mpt(new M().time(5).img(1));
        return dac(a);
    }
}
