package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Qual golpe renderizar para ver um ANO inteiro no editor de cutscenes. */
public class AnoMovesTest {
    public static void main(String[] args) throws Exception {
        A[] a = new A[50];
        for (int i = 0; i < 50; i++) a[i] = new A().mpt(new M().time(1));
        // ANO 45 tem a flag 20 (evento 3); o golpe 1 termina no ANO 45 (animSeqChao) e o golpe 0 comeca no 40
        a[45] = new A().mpt(new M().time(2).hit(20, 5, -10, 3, 0));
        Dac dac = dac(a);
        // golpe de 48 bytes: +2 = ANIM_INICIAL; +4 = ANIM_SEQ_CHAO? usamos CharData para ler os campos de verdade
        CharData cd = chr(concat(move(new int[]{2, 40}), move(new int[]{2, 41}, new int[]{14, 45})), new byte[][] {});
        int se = cd.moves[1].animSeqChao;
        int target = se > 0 ? se : 45;
        check("ANO que e ANIM_INICIAL de um golpe: o proprio golpe", AnoMoves.moveFor(cd, dac, 40), 0);
        check("ANO que nenhum golpe usa: -1 (toca sozinho)", AnoMoves.moveFor(cd, dac, 33), -1);
        if (se > 0) check("ANO referenciado por um golpe (SEQ): o golpe dono", AnoMoves.moveFor(cd, dac, se), 1);
        check("sem dados: -1", AnoMoves.moveFor(null, dac, 40), -1);
        check("usersOf acha as ANOs com o evento (so a 45 usa o 3)", CutsceneEdit.users(CutsceneEdit.all(dac), 3).toString() + CutsceneEdit.users(CutsceneEdit.all(dac), 4).toString(), "[45][]");
        System.out.println("AnoMovesTest fails=" + fails + " (seq=" + se + ", target=" + target + ")");
    }

    static byte[] concat(byte[] x, byte[] y) { byte[] r = new byte[x.length + y.length]; System.arraycopy(x, 0, r, 0, x.length); System.arraycopy(y, 0, r, x.length, y.length); return r; }
}
