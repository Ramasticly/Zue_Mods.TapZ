package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Notas manuais das ANOs (AnoNotes) no (i) da grade. */
public class AnoNotesTest {
    public static void main(String[] args) throws Exception {
        int[] seeded = {0, 1, 2, 3, 4, 5, 19, 6, 7, 11, 12, 10, 13, 8, 9, 89, 84, 85, 15, 72, 20, 68, 67, 69, 25, 24, 73, 23};
        boolean allOk = true;
        for (int a : seeded) {
            List<AttackInfo.Line> l = AnoNotes.lines(a);
            if (l.size() != 1 || l.get(0).text.isEmpty() || l.get(0).src != AttackInfo.CODE) allOk = false;
        }
        check("as 28 ANOs semeadas tem uma linha azul cada", allOk, true);
        check("ANO 0", AnoNotes.lines(0).get(0).text, "Idle Chão");
        check("ANO 19 (voo trás)", AnoNotes.lines(19).get(0).text, "Voo Trás ←");
        check("ANO sem nota = lista vazia", AnoNotes.lines(57).isEmpty() && !AnoNotes.has(57), true);
        check("has", AnoNotes.has(2), true);

        CharData cd = chr(move(new int[]{2, 40}), new byte[][] {});
        check("anoInfo usa a nota", AttackInfo.anoInfo(cd, 2), "Super Dash Frente →→→");
        check("a nota vence o nome antigo (ANO 2 nao e mais 'Esquiva rapida')", String.valueOf(AttackInfo.anoInfo(cd, 2)).contains("Esquiva"), false);
        check("ANO sem nota e sem nome antigo = null", AttackInfo.anoInfo(cd, 57), null);
        check("sem nota usa o nome antigo (teleporte 87)", AttackInfo.anoInfo(cd, 87), "Teleporte (some)");
        check("ANO 18 e 22 nao tem mais o texto errado", AttackInfo.anoInfo(cd, 18) == null && AttackInfo.anoInfo(cd, 22) == null, true);
        check("combo A continua (ANO 30)", String.valueOf(AttackInfo.anoInfo(cd, 30)).contains("• A → ANO 32"), true);
        System.out.println("AnoNotesTest fails=" + fails);
    }
}
