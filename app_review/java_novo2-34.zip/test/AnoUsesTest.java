package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** EDITAR NOS USOS: todos os lugares que usam um ANO do personagem. */
public class AnoUsesTest {
    static String kinds(java.util.List<AnoUses.Use> l) {
        StringBuilder b = new StringBuilder();
        for (AnoUses.Use u : l) b.append(u.kind).append('@').append(u.host).append(u.move >= 0 ? "/g" + u.move : "").append(u.pat >= 0 ? "/f" + u.pat : "").append(u.flipped ? "/v" : "").append(u.field != null ? "/" + u.field : "").append(' ');
        return b.toString().trim();
    }

    public static void main(String[] args) throws Exception {
        A[] a = new A[210];
        for (int i = 0; i < a.length; i++) a[i] = new A().mpt(new M().time(1));
        a[40] = new A().mpt(new M().time(5).hit(20, 0, 0, 0, 0)).mpt(new M().time(5).hit(71, 0, 0, 5, 5)).mpt(new M().time(5).hit(71, 0, 0, 5, 5));
        a[50] = new A().mpt(new M().time(5)).mpt(new M().time(5).hit(20, 0, 0, 1, 0));
        Dac dac = dac(a);
        Ano p = dac.getAno(60);
        dac.setAno(60, new Ano(60, true, p.flags, p.priority, new Ano.Link[] {new Ano.Link(0, 0, 201), new Ano.Link(5, 5, 201)}, p.mpts));
        // eventos: 0 = ALVO 1, ANIM 45 / FLIP 46; 1 = ALVO 0 (effect) ANIM 45 -> nao conta; golpes: 0 (ANO 40) com projetil 47 e SEQ 48; 1 (ANO 50) com triplo (flags 4) e agarrado 49
        byte[][] t = new byte[40][];
        int[] cols = new int[40], rows = new int[40];
        for (int i = 0; i < 40; i++) t[i] = new byte[0];
        byte[] m0 = move(new int[] {2, 40}, new int[] {4, 47}, new int[] {10, 48});
        byte[] m1 = move(new int[] {0, 4}, new int[] {2, 50}, new int[] {4, 52}, new int[] {24, 49});
        t[4] = AnoMovesTest.concat(m0, m1); cols[4] = 48; rows[4] = 2;
        Buf ev = new Buf();
        for (int v : new int[] {1, 0, 0, 45, 46, 0, 0, 0, 0, 0, 0, 45, 45, 0, 0, 0}) ev.u16(v);
        t[13] = ev.get(); cols[13] = 8; rows[13] = 2;
        CharData ch = CharData.read(hdat(t, cols, rows));

        check("ANO 201: link do ANO 60 (uma vez) e animacao da flag 71 no frame 1 do ANO 40 (so a 1a vez)", kinds(AnoUses.find(ch, dac, 201)), "1@40/f1 0@60");
        check("ANIM_ID da cutscene (ALVO 1) no frame 0 do ANO 40; o evento do effect (ALVO 0) no ANO 50 nao conta", kinds(AnoUses.find(ch, dac, 45)), "2@40/f0");
        check("ANIM_FLIP: marcado como virado", kinds(AnoUses.find(ch, dac, 46)), "2@40/f0/v");
        check("projetil e SEQ do golpe 0", kinds(AnoUses.find(ch, dac, 47)) + " | " + kinds(AnoUses.find(ch, dac, 48)), "3@40/g0/PROJETIL_ANIM_NORMAL | 4@40/g0/ANIM_SEQ_CHAO");
        check("triplo (ATK_FLAGS 4): +1 e +2 do projetil", kinds(AnoUses.find(ch, dac, 53)) + " | " + kinds(AnoUses.find(ch, dac, 54)), "3@50/g1/PROJETIL_ANIM_NORMAL + 1 | 3@50/g1/PROJETIL_ANIM_NORMAL + 2");
        check("oponente agarrado", kinds(AnoUses.find(ch, dac, 49)), "5@50/g1/OPONENTE_ANIM_SENDO_AGARRADO");
        check("ANIM_INICIAL e uso do proprio golpe", kinds(AnoUses.find(ch, dac, 40)), "4@40/g0/ANIM_INICIAL");
        check("ANO sem uso: lista vazia", AnoUses.find(ch, dac, 33).size(), 0);
        check("sem CharData: so links e flags", kinds(AnoUses.find(null, dac, 201)), "1@40/f1 0@60");
        java.util.List<AnoUses.Use> u = AnoUses.find(ch, dac, 201);
        check("origem: destaca o uso cujo host e o ANO de onde se veio", AnoUses.originIndex(u, 60) + ":" + AnoUses.originIndex(u, 40) + ":" + AnoUses.originIndex(u, 99) + ":" + AnoUses.originIndex(u, -1), "1:0:-1:-1");
        check("rotulos", u.get(0).label() + " | " + u.get(1).label(), "Animação da flag 71 · ANO 40 · frame 2 | Link do ANO 60");
        check("rotulo do projetil e da cutscene virada", AnoUses.find(ch, dac, 47).get(0).label() + " | " + AnoUses.find(ch, dac, 46).get(0).label(),
                "Projétil do GOLPE_00 (PROJETIL_ANIM_NORMAL) | Cutscene do evento 0 · ANO 40 · frame 1 · virado");

        // dados reais (fixtures), se existirem: os usos achados batem com o que anosOfMove alcanca
        java.io.File fd = new java.io.File("../app/test/fixtures/char.dac.txt");
        if (!fd.exists()) fd = new java.io.File("test/fixtures/char.dac.txt");
        if (fd.exists()) {
            Dac rd = Dac.fromTxt(new String(java.nio.file.Files.readAllBytes(fd.toPath()), "UTF-8"));
            int withLinks = 0;
            for (int i = 0; i < rd.size(); i++) {
                Ano an = rd.getAno(i);
                if (an == null || !an.present) continue;
                for (Ano.Link l : an.links) if (!AnoUses.find(null, rd, l.getAno()).isEmpty()) { withLinks++; break; }
            }
            check("dados reais: todo ANO que e link de alguem tem pelo menos um uso", withLinks > 0, true);
        }
        System.out.println("AnoUsesTest fails=" + fails);
    }
}
