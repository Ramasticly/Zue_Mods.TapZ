package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** EDITAR da tela ANIM das cutscenes: zoom/posicao somados em todos os frames (ou num so). */
public class AnoXformTest {
    static Ano.Mpt frame(boolean mid, int mx, int my, boolean raz, int zx, int zy) {
        Ano.Mpt m = new Ano.Mpt();
        m.flags = 0x20;
        m.time = 5;
        m.image = 3;
        if (mid) { m.flags |= 1; m.midX = mx; m.midY = my; }
        if (raz) { m.flags |= 0x80; m.xZoom = zx; m.yZoom = zy; }
        m.normalize();
        return m;
    }

    static String vals(Ano a, int p) { int[] v = AnoXform.valuesAt(a, p); return v[0] + "," + v[1] + "," + v[2] + "," + v[3]; }

    public static void main(String[] args) throws Exception {
        Ano.Link[] links = {new Ano.Link(4, -6, 77)};
        Ano a = new Ano(242, true, 0, 0, links, new Ano.Mpt[] {
            frame(true, 48, 182, true, 100, 300),
            frame(false, 0, 0, false, 0, 0),
            frame(true, -10, 5, true, 150, 150),
        });
        check("valores do frame: zoom X/Y e posicao (MID)", vals(a, 0), "100,300,48,182");
        check("frame sem MID nem RAZ: 100,100 e 0,0", vals(a, 1), "100,100,0,0");
        check("frame inexistente: null", AnoXform.valuesAt(a, 7) == null, true);
        check("Unir zoom: marcado so quando X = Y", AnoXform.uniteOf(a, 0) + ":" + AnoXform.uniteOf(a, 1) + ":" + AnoXform.uniteOf(a, 2), "false:true:true");

        // soma em todos os frames
        Ano b = AnoXform.addDelta(a, -1, 20, 20, 10, -4);
        check("todos: frame 0 soma", vals(b, 0), "120,320,58,178");
        check("todos: frame sem MID/RAZ ganha os dois com o padrao + diferenca", vals(b, 1) + ":" + ((b.mpts[1].flags & 0x81) == 0x81), "120,120,10,-4:true");
        check("todos: frame 2 soma", vals(b, 2), "170,170,0,1");
        check("original intacto (copia)", vals(a, 0) + "|" + vals(a, 1), "100,300,48,182|100,100,0,0");
        check("links e outros campos intactos", (b.links == a.links) + ":" + b.mpts[0].image + ":" + b.mpts[0].time + ":" + b.index, "true:3:5:242");
        check("RAZ criado tem hasRaz e alpha 255", b.mpts[1].hasRaz + ":" + b.mpts[1].alpha, "true:255");

        // so num frame
        Ano c = AnoXform.addDelta(a, 2, 0, 0, 3, 0);
        check("apenas nesse frame: so o 2 muda", vals(c, 0) + "|" + vals(c, 1) + "|" + vals(c, 2), "100,300,48,182|100,100,0,0|150,150,-7,5");
        check("so posicao nao cria RAZ", (c.mpts[1].flags & 0x80) + ":" + (c.mpts[2].flags & 0x80), "0:128");

        // RAZ que volta ao neutro sai
        Ano d = AnoXform.addDelta(a, 2, -50, -50, 0, 0);
        check("zoom de volta a 100 x 100 sem rotacao/alpha: tira o RAZ", ((d.mpts[2].flags & 0x80) == 0) + ":" + d.mpts[2].hasRaz + ":" + vals(d, 2), "true:false:100,100,-10,5");
        // limites
        Ano e = AnoXform.addDelta(a, -1, -500, 99999, 0, 0);
        check("zoom limitado a 1..9999", vals(e, 0) + "|" + vals(e, 2), "1,9999,48,182|1,9999,-10,5");

        // resumo para o SALVAR
        check("nada mudou: change null", AnoXform.change(a, a) == null && !AnoXform.differs(a, a), true);
        AnoXform.Change ch = AnoXform.change(a, b);
        check("mudanca igual em todos: delta e contagem", ch.changed + "/" + ch.total + ":" + ch.delta[0] + "," + ch.delta[1] + "," + ch.delta[2] + "," + ch.delta[3], "3/3:20,20,10,-4");
        AnoXform.Change cc = AnoXform.change(a, c);
        check("so um frame: 1 de 3", cc.changed + "/" + cc.total + ":" + (cc.delta != null), "1/3:true");
        AnoXform.Change ce = AnoXform.change(a, e);
        check("frames com diferencas distintas (limite): delta null", ce.changed + ":" + (ce.delta == null), "3:true");
        check("sinal: +10, −4, 0", AnoXform.sign(10) + AnoXform.sign(-4) + AnoXform.sign(0), "+10−40");

        System.out.println("AnoXformTest fails=" + fails);
    }
}
