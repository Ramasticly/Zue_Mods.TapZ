package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Cor do (i) da grade: verde = definido no Bin, azul = regra fixa do jogo; golpes sempre verdes. */
public class AttackInfoTest {
    public static void main(String[] args) throws Exception {
        CharData cd = chr(move(new int[]{2, 40}), new byte[][] {});
        check("ANO so com regra fixa (nota) = azul", AttackInfo.infoIsBin(cd, 2, true), false);
        check("ANO so com nome fixo do jogo = azul", AttackInfo.infoIsBin(cd, 87, true), false);
        check("ANO com papel em um golpe (ANIM_INICIAL) = verde", AttackInfo.infoIsBin(cd, 40, true), true);
        check("ANO normal A (so codigo, combo) = azul", AttackInfo.infoIsBin(cd, 30, true), false);
        check("golpe (modo GOLPES) = sempre verde", AttackInfo.infoIsBin(cd, 0, false), true);
        check("sem dados do personagem = azul na ANO", AttackInfo.infoIsBin(null, 2, true), false);
        // ANO com as duas fontes (papel no Bin + nota fixa) = verde
        CharData cd2 = chr(move(new int[]{2, 2}), new byte[][] {});
        check("ANO com papel no Bin E nota fixa = verde", AttackInfo.infoIsBin(cd2, 2, true), true);
        System.out.println("AttackInfoTest fails=" + fails);
    }
}
