package com.zue.attackeditor;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;

public class AudioTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    static byte[] wav(int rate, int ch, int bits, int frames) {
        int bytes = bits / 8, dl = frames * ch * bytes;
        ByteBuffer b = ByteBuffer.allocate(44 + dl).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt(36 + dl).put("WAVE".getBytes()).put("fmt ".getBytes()).putInt(16).putShort((short) 1)
                .putShort((short) ch).putInt(rate).putInt(rate * ch * bytes).putShort((short) (ch * bytes)).putShort((short) bits)
                .put("data".getBytes()).putInt(dl);
        for (int i = 0; i < frames; i++) for (int c = 0; c < ch; c++) {
            double v = Math.sin(2 * Math.PI * 440 * i / rate) * 0.5;
            if (bits == 16) b.putShort((short) (v * 32767)); else b.put((byte) (128 + v * 127));
        }
        return b.array();
    }

    public static void main(String[] args) throws Exception {
        File dir = Files.createTempDirectory("snd").toFile();
        File st = new File(dir, "in.wav");
        Files.write(st.toPath(), wav(44100, 2, 16, 44100));            // 1 s, estereo, 44.1 kHz
        byte[] out = AudioConvert.toGameWav(st);
        ByteBuffer b = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
        check("RIFF/WAVE", out[0] == 'R' && out[8] == 'W');
        check("mono 16 bits 22050 Hz", b.getShort(22) == 1 && b.getInt(24) == 22050 && b.getShort(34) == 16 && b.getInt(28) == 44100);
        check("cabecalho de 44 bytes (data em 36)", out[36] == 'd' && out[39] == 'a' && b.getInt(40) == out.length - 44);
        check("1 s vira 22050 amostras", (out.length - 44) / 2 == 22050);
        int peak = 0;
        for (int i = 44; i < out.length; i += 2) peak = Math.max(peak, Math.abs(b.getShort(i)));
        check("amplitude preservada (~16000)", peak > 14000 && peak < 18000);
        File m8 = new File(dir, "in8.wav");
        Files.write(m8.toPath(), wav(8000, 1, 8, 8000));               // 8 bits, 8 kHz: amplia
        byte[] o8 = AudioConvert.toGameWav(m8);
        check("8 kHz 8 bits -> 22050 amostras", (o8.length - 44) / 2 == 22050);
        check("silencio reconhecido", AudioConvert.isSilent(AudioConvert.silentWav().length) && !AudioConvert.isSilent(out.length));
        check("duracao", Math.abs(AudioConvert.seconds(out.length) - 1.0) < 0.001);
        // arquivo de amostra do usuario (ja no formato do jogo): nao muda de tamanho
        File sample = new File("/root/.claude/uploads/5670ec5f-2b92-55ae-9670-f544ea580895/2a86ce7f-033.wav");
        if (sample.isFile()) {
            byte[] o = AudioConvert.toGameWav(sample);
            check("amostra do jogo: mesmo tamanho", o.length == sample.length());
        }
        byte[] cut = AudioConvert.slice(out, 5000, 15000);
        check("corte: 10000 amostras, cabecalho valido", (cut.length - 44) / 2 == 10000 && AudioConvert.pcmOf(cut)[0] == AudioConvert.pcmOf(out)[5000]
                && ByteBuffer.wrap(cut).order(ByteOrder.LITTLE_ENDIAN).getInt(40) == 20000);
        check("corte limitado ao tamanho", (AudioConvert.slice(out, 20000, 99999).length - 44) / 2 == 2050);
        // pasta de personagem: folhas 000..002, wavs 003..
        File ch = new File(dir, "char");
        ch.mkdir();
        for (int i = 0; i < 3; i++) Files.write(new File(ch, String.format("%03d.png", i)).toPath(), new byte[]{1});
        check("primeiro numero livre = 3", CharSounds.nextNumber(ch) == 3);
        File n1 = CharSounds.add(ch, st);
        File n2 = CharSounds.add(ch, st);
        check("wavs 003 e 004", n1.getName().equals("003.wav") && n2.getName().equals("004.wav") && CharSounds.list(ch).length == 2);
        CharSounds.mute(n1);
        check("mutar mantem o arquivo e a ordem", n1.isFile() && CharSounds.list(ch).length == 2 && CharSounds.list(ch)[0].equals(n1) && AudioConvert.isSilent(n1.length()));
        CharSounds.replace(n1, st);
        check("substituir", n1.length() == out.length);
        check("mutado e vazio, os outros nao", CharSounds.emptySounds(ch).isEmpty());
        CharSounds.mute(n2);
        check("vazio detectado (som 81)", CharSounds.emptySounds(ch).size() == 1 && CharSounds.emptySounds(ch).contains(Integer.valueOf(81)));
        CharSounds.replace(n2, st);
        for (int i = 2; i < CharSounds.MAX; i++) CharSounds.add(ch, st);
        check("20 sons", CharSounds.list(ch).length == 20);
        boolean blocked = false;
        try { CharSounds.add(ch, st); } catch (java.io.IOException e) { blocked = true; }
        check("limite de 20 bloqueia", blocked && CharSounds.list(ch).length == 20);
        // vazios no fim sao apagados; no meio continuam
        File ch2 = new File(dir, "char2");
        ch2.mkdir();
        File w1 = CharSounds.add(ch2, st), w2 = CharSounds.add(ch2, st), w3 = CharSounds.add(ch2, st);
        CharSounds.mute(w2);
        check("vazio no meio nao e apagado", CharSounds.trimTrailing(ch2) == 0 && CharSounds.list(ch2).length == 3);
        CharSounds.mute(w3);
        check("vazios no fim apagados (w3 e w2)", CharSounds.trimTrailing(ch2) == 2 && CharSounds.list(ch2).length == 1 && w1.isFile() && !w2.exists() && !w3.exists());
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }
}
