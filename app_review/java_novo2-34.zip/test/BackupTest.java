package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Date;

/** Copia bruta do personagem antes de OTIMIZAR: tudo (DAC, CNV, Bin, txt, audios, PNG/GIF, subpastas, salvos/), identica byte a byte, sem sobrescrever. */
public class BackupTest {
    static void put(File f, byte[] data) throws Exception {
        f.getParentFile().mkdirs();
        FileOutputStream o = new FileOutputStream(f);
        try { o.write(data); } finally { o.close(); }
    }

    static byte[] read(File f) throws Exception {
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        java.io.FileInputStream in = new java.io.FileInputStream(f);
        try { byte[] buf = new byte[4096]; int n; while ((n = in.read(buf)) > 0) b.write(buf, 0, n); } finally { in.close(); }
        return b.toByteArray();
    }

    static boolean same(File a, File b) throws Exception {
        File[] ka = a.listFiles(), kb = b.listFiles();
        if (ka == null || kb == null || ka.length != kb.length) return false;
        Arrays.sort(ka); Arrays.sort(kb);
        for (int i = 0; i < ka.length; i++) {
            if (!ka[i].getName().equals(kb[i].getName()) || ka[i].isDirectory() != kb[i].isDirectory()) return false;
            if (ka[i].isDirectory()) { if (!same(ka[i], kb[i])) return false; }
            else if (!Arrays.equals(read(ka[i]), read(kb[i]))) return false;
        }
        return true;
    }

    public static void main(String[] args) throws Exception {
        File tb = new File(System.getProperty("java.io.tmpdir"), "backup_test_tapbattle");
        Saver.deleteTree(tb);
        File src = new File(tb, "assets/char07");
        byte[] bin = new byte[70000];
        for (int i = 0; i < bin.length; i++) bin[i] = (byte) (i * 31 + 7);
        put(new File(src, "000.dac"), bin);
        put(new File(src, "000.bin"), new byte[]{1, 2, 3, 0, (byte) 255});
        put(new File(src, "000.cnv"), new byte[]{9, 9});
        put(new File(src, "000.dac.txt"), "DAC texto".getBytes("UTF-8"));
        put(new File(src, "000.bin.txt"), "BIN texto".getBytes("UTF-8"));
        put(new File(src, "000.cnv.txt"), "CNV texto".getBytes("UTF-8"));
        put(new File(src, "000.png"), new byte[]{(byte) 0x89, 'P', 'N', 'G', 0, 1, 2});
        put(new File(src, "001.png"), new byte[]{(byte) 0x89, 'P', 'N', 'G', 3, 4});
        put(new File(src, "anim.gif"), new byte[]{'G', 'I', 'F', '8', '9', 'a', 5});
        put(new File(src, "002.wav"), new byte[]{'R', 'I', 'F', 'F', 0, 0});
        put(new File(src, "sons/003.wav"), new byte[]{1, 2, 3});
        put(new File(src, "salvos/velho.txt"), "pasta antiga".getBytes("UTF-8"));
        put(new File(src, "vazio.bin"), new byte[0]);

        final int[] last = new int[2];
        Date t = new Date(1700000000000L);
        File bk = PreOptimBackup.run(src, t, new Saver.CopyProgress() { public void on(String f, int done, int total) { last[0] = done; last[1] = total; } });
        check("pasta de backup em TBRE/Backups/PreOptim/AAAAMMDD_HHMMSS_charNN", bk.getParentFile().getPath().endsWith("backup_test_tapbattle/TBRE/Backups/PreOptim") && bk.getName().matches("\\d{8}_\\d{6}_char07"), true);
        check("cópia bruta idêntica byte a byte (dac, bin, cnv, txt, png, gif, wav, subpastas, salvos/, arquivo vazio)", same(src, bk), true);
        check("progresso chegou ao fim (13 arquivos)", last[0] + "/" + last[1], "13/13");
        check("o original não mudou", read(new File(src, "000.dac")).length, 70000);

        File bk2 = PreOptimBackup.run(src, t, null);
        check("segunda cópia no mesmo segundo vira _2 e não sobrescreve a primeira", bk2.getName().equals(bk.getName() + "_2") && bk.isDirectory() && same(src, bk2), true);
        // arquivos de apoio (grupos de GIF etc.) ficam em TBRE/utils/charNN e voltam no backup, na subpasta utils/
        put(new File(tb, "TBRE/utils/char07/sprite_grupos.json"), "{\"grupos\":[]}".getBytes("UTF-8"));
        File bkU = PreOptimBackup.run(src, new Date(1700000100000L), null);
        check("o backup leva TBRE/utils/charNN na subpasta utils/", new String(read(new File(bkU, "utils/sprite_grupos.json")), "UTF-8"), "{\"grupos\":[]}");
        check("e a pasta do char original nao ganha arquivo de apoio nem .tmp", new File(src, "sprite_grupos.json").exists() || new File(src, "000.dac.tmp").exists(), false);
        File bk3 = PreOptimBackup.run(src, t, null);
        check("terceira vira _3", bk3.getName(), bk.getName() + "_3");

        // alterar o original depois do backup: a copia guarda o estado antigo
        put(new File(src, "000.png"), new byte[]{0});
        check("o backup guarda o estado de antes", Arrays.equals(read(new File(bk, "000.png")), new byte[]{(byte) 0x89, 'P', 'N', 'G', 0, 1, 2}), true);

        // falhas
        boolean thrown = false;
        try { PreOptimBackup.run(new File(tb, "assets/nao_existe"), t, null); } catch (java.io.IOException e) { thrown = true; }
        check("origem inexistente: erro", thrown, true);
        File root = new File(tb, "TBRE/Backups/PreOptim");
        int before = root.list().length;
        thrown = false;
        try { PreOptimBackup.run(new File(tb, "assets/nao_existe"), t, null); } catch (java.io.IOException e) { thrown = true; }
        check("origem inexistente não deixa pasta pela metade", root.list().length, before);
        check("a copia comum de personagem continua pulando salvos/", copyHasSalvos(src), false);
    }

    static boolean copyHasSalvos(File src) throws Exception {
        File dst = new File(System.getProperty("java.io.tmpdir"), "backup_test_comum");
        Saver.deleteTree(dst);
        Saver.copyChar(src, dst, false, null);
        boolean has = new File(dst, "salvos").exists();
        Saver.deleteTree(dst);
        return has;
    }
}
