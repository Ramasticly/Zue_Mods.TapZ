package com.zue.attackeditor;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class BattleTest {
    static int fails = 0;
    static void check(String name, Object got, Object want) {
        boolean ok = got == null ? want == null : got.equals(want);
        System.out.println((ok ? "OK   " : "FAIL ") + name + " got=" + got + (ok ? "" : " want=" + want));
        if (!ok) fails++;
    }

    static class Buf {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        Buf u8(int v) { o.write(v & 255); return this; }
        Buf u16(int v) { u8(v); u8(v >> 8); return this; }
        Buf i32(int v) { u16(v); u16(v >> 16); return this; }
        Buf bytes(byte[] b) { o.write(b, 0, b.length); return this; }
        int size() { return o.size(); }
        byte[] get() { return o.toByteArray(); }
    }

    // ---------- DAC ----------
    static class M {
        int img = 1, time = -1, speedX = 0, speedY = 0, se = -1, act = 0; boolean move; int[][] hits = new int[0][]; int opt1 = -1; int dmg = 5; int optFlag = 0; boolean interp; int[] raz;
        M interp() { interp = true; if (opt1 < 0) opt1 = 0; return this; }
        M raz(int... r) { raz = r; return this; }
        M dmg(int d) { dmg = d; return this; }
        M optFlag(int f) { optFlag = f; if (opt1 < 0) opt1 = 0; return this; }
        M img(int i) { img = i; return this; }
        M time(int t) { time = t; return this; }
        M speedX(int s) { move = true; speedX = s; return this; }
        M speedY(int s) { move = true; speedY = s; return this; }
        /** caixa {flag,x,y,w,h} */
        M hit(int... h) { int[][] n = new int[hits.length + 1][]; System.arraycopy(hits, 0, n, 0, hits.length); n[hits.length] = h; hits = n; return this; }
        M opt1(int v) { opt1 = v; return this; }
        M se(int v) { se = v; return this; }
        M act(int v) { act = v; return this; }
        byte[] build() {
            int f = 0;
            if (time >= 0) f |= 0x20;
            if (move) f |= 4;
            if (se >= 0) f |= 8;
            if (act != 0) f |= 2;
            if (hits.length > 0) f |= 0x10;
            if (opt1 >= 0) f |= 0x40;
            if (raz != null) f |= 0x80;
            Buf b = new Buf().u8(f);
            if (time >= 0) b.u8(time);
            b.u16(img);
            if (act != 0) b.u16(act);
            if (se >= 0) b.u8(se);
            if (move) { b.u8(speedY != 0 ? 3 : 1); b.i32(speedX); if (speedY != 0) b.i32(speedY); }
            if (hits.length > 0) { b.u8(hits.length); for (int[] h : hits) b.u8(h[0]).u8(h[1]).u8(h[2]).u8(h[3]).u8(h[4]); }
            if (opt1 >= 0) { b.u16(optFlag); b.u8(dmg).u8(opt1).u8(interp ? 1 : 0).u8(0); }
            if (raz != null) { for (int v : raz) b.u16(v); }
            return b.get();
        }
    }
    static class A {
        List<M> mpts = new ArrayList<M>(); boolean loop;
        A mpt(M m) { mpts.add(m); return this; }
        byte[] build() {
            Buf b = new Buf().u8(0).u8(mpts.size());
            int n = mpts.size();
            byte[][] bodies = new byte[n][];
            for (int i = 0; i < n; i++) bodies[i] = mpts.get(i).build();
            int off = 0;
            for (int i = 0; i < n; i++) { b.u16(off); off += bodies[i].length; }
            for (int i = 0; i < n; i++) b.bytes(bodies[i]);
            return b.get();
        }
    }
    static Dac dac(A... anos) throws Exception {
        int count = anos.length, tableOffset = 8, dataOffset = (8 + count * 2 + 3) & ~3;
        Buf ent = new Buf(); int[] ptr = new int[count];
        for (int i = 0; i < count; i++) { while (ent.size() % 4 != 0) ent.u8(0); ptr[i] = ent.size() / 4; ent.bytes(anos[i].build()); }
        Buf all = new Buf().u16(0).u16(count).u16(tableOffset).u16(dataOffset);
        for (int i = 0; i < count; i++) all.u16(ptr[i]);
        while (all.size() < dataOffset) all.u8(0);
        all.bytes(ent.get());
        return Dac.read(all.get());
    }

    // ---------- HDAT ----------
    static byte[] hdat(byte[][] tables, int[] cols, int[] rows) {
        int n = tables.length;
        Buf b = new Buf().u16(n);
        int off = 2 + n * 8;
        for (int i = 0; i < n; i++) { b.i32(off).u16(cols[i]).u16(rows[i]); off += tables[i].length; }
        for (int i = 0; i < n; i++) b.bytes(tables[i]);
        return b.get();
    }
    /** linha de reacao: dc, da, ano, xs, ys, xa, ya, xsA, ysA, xaA, yaA, comp, wall, voz */
    static byte[] react(int[]... rows) {
        Buf b = new Buf();
        for (int[] r : rows) for (int i = 0; i < 14; i++) b.u8(i < r.length ? r[i] : 0);
        return b.get();
    }
    static byte[] move(int[]... pairs) {   // {offset, value} em um golpe de 48 bytes
        byte[] m = new byte[48];
        for (int[] p : pairs) { m[p[0]] = (byte) p[1]; m[p[0] + 1] = (byte) (p[1] >> 8); }
        return m;
    }

    static GameData gd(byte[][] reactionsByType) throws Exception {
        byte[][] t = new byte[40][];
        int[] cols = new int[40], rows = new int[40];
        for (int i = 0; i < 40; i++) { t[i] = new byte[0]; }
        for (int i = 0; i < reactionsByType.length; i++) {
            if (reactionsByType[i] == null) continue;
            t[10 + i] = reactionsByType[i]; cols[10 + i] = 14; rows[10 + i] = reactionsByType[i].length / 14;
        }
        return GameData.fromBytes(hdat(t, cols, rows), "test");
    }
    static CharData chr(byte[] moves, byte[][] reactionsByType) throws Exception {
        byte[][] t = new byte[40][];
        int[] cols = new int[40], rows = new int[40];
        for (int i = 0; i < 40; i++) t[i] = new byte[0];
        t[4] = moves; cols[4] = 48; rows[4] = moves.length / 48;
        for (int i = 0; i < reactionsByType.length; i++) {
            if (reactionsByType[i] == null) continue;
            t[14 + i] = reactionsByType[i]; cols[14 + i] = 14; rows[14 + i] = reactionsByType[i].length / 14;
        }
        return CharData.read(hdat(t, cols, rows));
    }

    /** Camadas sem as 2 sombras do chao (OWNER_SHADOW). */
    static int nl(BattleSim s) { int n = 0; for (BattleSim.Layer l : s.layers()) if (l.owner != BattleSim.OWNER_SHADOW) n++; return n; }

    public static void main(String[] a) throws Exception {
        check("preset sem gamedata perto", PosPresets.distance(null, 0, 0), 60);
        check("preset sem gamedata medio", PosPresets.distance(null, 1, 1), 120);
        check("preset sem gamedata longe", PosPresets.distance(null, 2, 2), 180);
        // ---- Opt1 ----
        Opt1 o0 = new Opt1(0), o3 = new Opt1(153), o4 = new Opt1(200), oc = new Opt1(80), ob = new Opt1(250), o2 = new Opt1(101);
        check("opt 0 tipo", o0.type, 0);
        check("opt 0 efeito/som", o0.effectAno + "/" + o0.sound, "0/3");
        check("opt 153 grupo/tipo", o3.group + "/" + o3.type, "3/3");
        check("opt 153 hitstop metade", o3.hitstopMode, 1);
        check("opt 153 empurra", o3.pushes, false);
        check("opt 200 sem efeito/som/hitstop", o4.effectAno + "/" + o4.sound + "/" + o4.hitstopMode, "-1/-1/2");
        check("opt 80 char tipo 0", oc.fromChar + "/" + oc.type, "true/0");
        check("opt 101 efeito Ano 1 / se_06", o2.effectAno + "/" + o2.sound, "1/6");
        check("opt 250 invalido", ob.valid, false);

        // ---- tabelas ----
        // GD tipo 3: 2 linhas. L0: ano 20, vel X = 10 (=1px/tick), dur 4/4. L1: ano 21, dur 3/3
        GameData g = gd(new byte[][] { null, null, null,
            react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0},
                  new int[]{3, 3, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        check("gd tipo3 linhas", g.reaction(3).rows, 2);
        check("gd ano linha0", g.reaction(3).s8(0, 2), 20);
        // char: HDAT4 com 1 golpe: animInicial 40, projNormal 30, projAoAcertar 31
        CharData ch = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{6, 31}), new byte[][] {});
        check("char golpes", ch.moves.length, 1);
        check("char animInicial", ch.moves[0].animInicial, 40);
        check("char projNormal", ch.moves[0].projNormal, 30);

        // ---- atacante: ANO 40, frame0 sem hit (time 2), frame1 hitbox ate x=60 (time 3, opt1 3), frame2 idle (time 2)
        // projetil ANO 30 anda +2px/tick (speed 2<<16), hitbox flag2 na frame; ANO 31 impacto (3 ticks)
        A atkA = new A()
            .mpt(new M().time(2))
            .mpt(new M().time(3).hit(2, 20, -40, 40, 20).opt1(3))
            .mpt(new M().time(2));
        // oponente: ANO 0 idle com hurtbox em x=-10..10; ANO 20/21 reacao
        A idle = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        A r20 = new A().mpt(new M().time(30).hit(1, -10, -60, 20, 60));
        A r21 = new A().mpt(new M().time(30));
        // dac do atacante precisa ter ANOs 0..40: preenche com vazios
        A[] atkAnos = new A[41];
        for (int i = 0; i < 41; i++) atkAnos[i] = new A().mpt(new M().time(1));
        atkAnos[40] = atkA;
        Dac atkDac = dac(atkAnos);
        A[] defAnos = new A[25];
        for (int i = 0; i < 25; i++) defAnos[i] = new A().mpt(new M().time(1));
        defAnos[0] = idle; defAnos[20] = r20; defAnos[21] = r21;
        Dac defDac = dac(defAnos);
        A[] fxAnos = { new A().mpt(new M().time(4)), new A().mpt(new M().time(4)) };
        Dac fxDac = dac(fxAnos);

        BattleSim s = new BattleSim(atkDac, ch, ch.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        // opponent em x=30 olhando para a esquerda; hurtbox em 20..40; hitbox do atacante 20..60 => encosta
        // sombra (task 936): effect ANO 15, no chao sob cada personagem, na x deles
        A[] fx16 = new A[16];
        for (int i = 0; i < 16; i++) fx16[i] = new A().mpt(new M().time(4));
        BattleSim sh = new BattleSim(atkDac, ch, ch.moves[0], false, defDac, dac(fx16), g, 30, 0, 0);
        int nSh = 0; boolean shOk = true;
        for (BattleSim.Layer l : sh.layers()) if (l.owner == BattleSim.OWNER_SHADOW) {
            nSh++;
            AttackSim.Obj r = l.sim.root();
            shOk &= r.y == 8 * 65536 && r.alpha == 128;
        }
        check("duas sombras no chao", nSh + ":" + shOk, "2:true");
        sh = new BattleSim(atkDac, ch, ch.moves[0], false, defDac, dac(fx16), g, 30, 40, 0);
        int shY = 0; for (BattleSim.Layer l : sh.layers()) if (l.owner == BattleSim.OWNER_SHADOW) shY = l.sim.root().y;
        check("sombra fica no chao com o atacante voando", shY, 8 * 65536);
        // pouso antes do fim da animacao (aviso vermelho no editor)
        A[] landAnos = new A[41];
        for (int i = 0; i < 41; i++) landAnos[i] = new A().mpt(new M().time(1));
        landAnos[40] = new A().mpt(new M().time(60).speedY(4 * 65536).hit(2, 20, -40, 40, 20)).mpt(new M().time(60)).mpt(new M().time(60));
        Dac landDac = dac(landAnos);
        BattleSim lnd1 = new BattleSim(landDac, ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        lnd1.measureLength();
        check("pousou no meio da animacao", lnd1.measuredLandedEarly(), true);
        check("tick do pouso medido (40px a 4px/tick)", lnd1.measuredLandTick() > 0 && lnd1.measuredLandTick() < 60, true);
        // TRANSICAO: TRAVADA ignora o pouso: sem tick de pouso, o ANO segue ate o fim
        BattleSim.lockFromTick = 0;
        BattleSim.landingOn = false;
        BattleSim lk = new BattleSim(landDac, ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        int lkLen = lk.measureLength();
        check("travado: sem pouso medido", lk.measuredLandTick(), -1);
        check("travado: sem aviso de pouso", lk.measuredLandedEarly(), false);
        for (int i = 0; i < 100; i++) lk.step();
        check("travado: segue no ANO 40", lk.attacker().root().ano.index, 40);
        check("travado: chao continua valendo", lk.attacker().root().y <= 0, true);
        // travado + POUSO religado: o pouso volta a trocar de ANO
        BattleSim.landingOn = true;
        BattleSim lk2 = new BattleSim(landDac, ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        lk2.measureLength();
        check("travado + pouso ligado: pouso medido", lk2.measuredLandTick() > 0, true);
        BattleSim.lockFromTick = -1;
        // pouso desligado sem travar: tambem nao troca
        BattleSim.landingOn = false;
        BattleSim lk3 = new BattleSim(landDac, ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        lk3.measureLength();
        check("pouso off: sem pouso medido", lk3.measuredLandTick(), -1);
        for (int m = 0; m < 2; m++) {
            BattleSim.landingOn = false; BattleSim.extendTime = m == 1; BattleSim.attackStop = m == 1;
            BattleSim pz = new BattleSim(landDac, ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
            check("pouso off (estendido=" + (m == 1) + "): timeline cobre a ANO inteira", pz.measureLength() >= 180 && pz.measuredLandTick() == -1, true);
        }
        BattleSim.extendTime = false; BattleSim.attackStop = false;
        BattleSim.landingOn = true;
        // pousa no meio mas sem hit/projetil pendente: nao e golpe cortado
        A[] noHitAnos = landAnos.clone();
        noHitAnos[40] = new A().mpt(new M().time(60).speedY(4 * 65536)).mpt(new M().time(60)).mpt(new M().time(60));
        BattleSim lnd2 = new BattleSim(dac(noHitAnos), ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        lnd2.measureLength();
        check("sem hitbox nem projetil nao avisa", lnd2.measuredLandedEarly(), false);
        A[] lateAnos = landAnos.clone();
        lateAnos[40] = new A().mpt(new M().time(60).speedY(4 * 65536)).mpt(new M().time(60)).mpt(new M().time(60).hit(2, 20, -40, 40, 20));
        BattleSim lnd3 = new BattleSim(dac(lateAnos), ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        lnd3.measureLength();
        check("hitbox que nao chegou a ser usada avisa", lnd3.measuredLandedEarly(), true);
        A[] hitAnos = landAnos.clone();
        hitAnos[40] = new A().mpt(new M().time(60).speedY(4 * 65536).hit(2, 20, -10, 40, 20).opt1(3)).mpt(new M().time(60)).mpt(new M().time(60));
        A[] noYAnos = landAnos.clone();
        noYAnos[40] = new A().mpt(new M().time(60).hit(2, 20, -40, 40, 20)).mpt(new M().time(60)).mpt(new M().time(60));
        BattleSim lnd5 = new BattleSim(dac(noYAnos), ch, ch.moves[0], false, defDac, fxDac, g, 200, 40, 0);
        lnd5.measureLength();
        check("sem yspeed/yaccel nao avisa", lnd5.measuredLandedEarly(), false);
        BattleSim lnd4 = new BattleSim(dac(hitAnos), ch, ch.moves[0], false, defDac, fxDac, g, 30, 40, 0);
        lnd4.measureLength();
        check("acertou o oponente nao avisa", lnd4.measuredLandedEarly(), false);
        A[] stayAnos = landAnos.clone();
        stayAnos[40] = new A().mpt(new M().time(60)).mpt(new M().time(60)).mpt(new M().time(60));
        BattleSim lb = new BattleSim(dac(stayAnos), ch, ch.moves[0], false, defDac, fxDac, g, 200, 0, 0);
        lb.measureLength();
        check("sem queda nao avisa", lb.measuredLandedEarly(), false);
        check("sem pouso: tick -1", lb.measuredLandTick(), -1);
        check("t0 oponente livre", s.defenderInDamage(), false);
        s.step();                           // frame 0 ainda (time 2)
        check("t1 sem hit ainda", s.defenderInDamage(), false);
        s.step();                           // o frame 1 (hitbox) carrega no tick em que o tempo zera
        s.step();                           // o hit e detectado no inicio do tick seguinte (PlayerTail do jogo)
        check("hit detectado", s.defenderInDamage(), true);
        check("hitstop atacante", s.hitstopAttacker(), 9);
        check("hitstop defensor", s.hitstopDefender(), 9);
        check("efeito criado", nl(s), 3);       // oponente, atacante, 1 efeito
        List<BattleSim.Snd> sn = s.drainSounds();
        check("som de hit se_03", sn.size() == 1 && sn.get(0).common && sn.get(0).id == 3, true);
        int pat0 = s.attacker().root().pat;
        // durante o hitstop o atacante nao avanca
        for (int i = 0; i < 8; i++) s.step();
        check("atacante congelado", s.attacker().root().pat, pat0);
        // oponente: primeira linha tocou no tick seguinte ao hit
        check("oponente em reacao gd3", s.describeDefender().startsWith("reacao gamedata 3"), true);
        for (int i = 0; i < 3; i++) s.step();
        check("hitstop acabou", s.hitstopAttacker(), 0);
        // oponente deve ter se movido: vel 10 -> 128 unid = 1px/tick, facing left (flip) => x aumenta? flip recua x
        // (so verifica que o efeito terminou e a reacao avancou)
        for (int i = 0; i < 40; i++) s.step();
        check("oponente voltou ao livre", s.defenderInDamage(), false);
        check("nao rehit no mesmo frame", s.lastHit().contains("golpe"), true);

        // ---- hit uma vez por frame: golpe com 2 frames de hitbox seguidos => 2 hits
        A atk2 = new A().mpt(new M().time(2).hit(2, 20, -40, 40, 20).opt1(3))
                        .mpt(new M().time(2).hit(2, 20, -40, 40, 20).opt1(3));
        atkAnos[40] = atk2;
        BattleSim s2 = new BattleSim(dac(atkAnos), ch, ch.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        int hits = 0; boolean prev = s2.defenderInDamage();
        int fxMax = 0;
        for (int i = 0; i < 40; i++) {
            int before = s2.drainSounds().size();
            s2.step();
            for (BattleSim.Snd x : s2.drainSounds()) if (x.common && x.id == 3) hits++;
        }
        // contagem inclui o hit do tick 0 (reset ja armou o frame 0 e detect roda no step 1)
        check("2 frames de hitbox = 2 hits", hits, 2);

        // ---- projetil: frame 0 do atacante com hitbox flag 0 => spawn de ANO 30
        A atk3 = new A().mpt(new M().time(2).hit(0, 10, -30, 4, 4)).mpt(new M().time(40));
        atkAnos[40] = atk3;
        A proj = new A().mpt(new M().time(60).speedX(2 << 16).hit(2, 0, -30, 16, 20).opt1(3));
        A hitAnim = new A().mpt(new M().time(3));
        atkAnos[30] = proj; atkAnos[31] = hitAnim;
        // flags 32 (nasce no oponente) x 64 (embaixo do oponente): so diferem quando o oponente esta no ar
        int[] pyAt = new int[2];
        for (int q = 0; q < 2; q++) {
            CharData chq = chr(move(new int[]{0, q == 0 ? 32 : 64}, new int[]{2, 40}, new int[]{4, 30}, new int[]{6, 31}), new byte[][] {});
            BattleSim.oppHeightPx = 20;
            BattleSim sq2 = new BattleSim(dac(atkAnos), chq, chq.moves[0], false, defDac, fxDac, g, 120, 0, 0);
            BattleSim.oppHeightPx = 0;
            for (BattleSim.Layer l : sq2.layers()) if (l.owner == BattleSim.OWNER_PROJECTILE) pyAt[q] = l.sim.root().y;
        }
        check("flag 32: projetil na altura do oponente (20 px)", pyAt[0], -20 * 65536);
        check("flag 64: projetil no chao embaixo do oponente", pyAt[1], 0);
        BattleSim s3 = new BattleSim(dac(atkAnos), ch, ch.moves[0], false, defDac, fxDac, g, 120, 0, 0);
        check("projetil spawnado", s3.projectileCount(), 1);
        int tHit = -1;
        for (int i = 0; i < 80 && tHit < 0; i++) {
            s3.step();
            if (s3.defenderInDamage()) tHit = i;
        }
        check("projetil acertou", tHit > 0, true);
        check("projetil sofre hitstop/2", s3.hitstopDefender() > 0, true);
        for (int i = 0; i < 60; i++) s3.step();
        check("projetil morreu apos a anim de impacto", s3.projectileCount(), 0);

        // ---- reacao encadeada: tipo 5 (ar -> comp 3 ao tocar o chao); y speed -> sobe e cai
        GameData g2 = gd(new byte[][] { null, null, null,
            react(new int[]{2, 2, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}),
            null,
            react(new int[]{255, 255, 20, 0, -40, 0, 10, 0, 0, 0, 0, 3, 0, 0}) });
        A atk4 = new A().mpt(new M().time(2).hit(2, 20, -40, 40, 20).opt1(5)).mpt(new M().time(40));
        atkAnos[40] = atk4;
        BattleSim s4 = new BattleSim(dac(atkAnos), ch, ch.moves[0], false, defDac, fxDac, g2, 30, 0, 0);
        boolean wasAir = false, landed = false;
        for (int i = 0; i < 200; i++) {
            s4.step();
            String d = s4.describeDefender();
            if (d.contains("gamedata 5")) {
                // estar no ar (y negativo) so e visivel pelas camadas
                int y = s4.layers().get(0).sim.root().y;
                if (y < 0) wasAir = true;
            }
            if (wasAir && d.contains("gamedata 3")) landed = true;
        }
        check("saltou no ar", wasAir, true);
        check("ao tocar o chao encadeou para tipo 3", landed, true);

        // ---- ANIM_SEQ / ANIM_END / flag 38
        CharData chS = chr(move(new int[]{2, 40}, new int[]{10, 41}, new int[]{12, 42}), new byte[][] {});
        A[] sq = new A[43];
        for (int i = 0; i < 43; i++) sq[i] = new A().mpt(new M().time(1));
        sq[41] = new A().mpt(new M().time(6));
        sq[42] = new A().mpt(new M().time(30));
        // sem flag 38: hit no frame 1 => troca para 41
        sq[40] = new A().mpt(new M().time(2)).mpt(new M().time(4).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(20));
        BattleSim q1 = new BattleSim(dac(sq), chS, chS.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        for (int i = 0; i < 6; i++) q1.step();
        check("trocou para ANIM_SEQ", q1.attacker().root().ano.index, 41);
        for (int i = 0; i < 40 && q1.attacker().root().ano.index == 41; i++) q1.step();
        check("SEQ terminada sem novo hit nao toca END", q1.attacker().root().ano.index != 42, true);
        // END so toca num novo hit confirmado durante a SEQ
        sq[41] = new A().mpt(new M().time(2)).mpt(new M().time(6).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(20));
        BattleSim q3 = new BattleSim(dac(sq), chS, chS.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        for (int i = 0; i < 40 && q3.attacker().root().ano.index != 42; i++) q3.step();
        check("novo hit durante a SEQ toca END", q3.attacker().root().ano.index, 42);
        sq[41] = new A().mpt(new M().time(6));
        BattleSim.endOnSeqFinish = true;
        BattleSim q4 = new BattleSim(dac(sq), chS, chS.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        for (int i = 0; i < 40 && q4.attacker().root().ano.index != 42; i++) q4.step();
        check("endOnSeqFinish toca END ao fim da SEQ", q4.attacker().root().ano.index, 42);
        BattleSim.endOnSeqFinish = false;
        // flag 38 no frame do hit: nao troca; frame seguinte sem 38 e com hitbox: troca
        sq[40] = new A().mpt(new M().time(2))
                .mpt(new M().time(2).hit(2, 20, -40, 40, 20).hit(38, 0, 0, 1, 1).opt1(3))
                .mpt(new M().time(2).hit(2, 20, -40, 40, 20).opt1(3))
                .mpt(new M().time(20));
        BattleSim q2 = new BattleSim(dac(sq), chS, chS.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        for (int i = 0; i < 4; i++) q2.step();
        check("flag 38 impede troca", q2.attacker().root().ano.index, 40);
        for (int i = 0; i < 16; i++) q2.step();
        check("troca no frame seguinte sem 38", q2.attacker().root().ano.index, 41);

        // TRANSICAO: TRAVADA desde o tick 0: hit nao troca para a SEQ
        sq[40] = new A().mpt(new M().time(2)).mpt(new M().time(4).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(20));
        BattleSim.lockFromTick = 0;
        BattleSim q5 = new BattleSim(dac(sq), chS, chS.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        for (int i = 0; i < 30; i++) q5.step();
        check("travado: hit nao troca para SEQ", q5.attacker().root().ano.index, 40);
        check("travado: nenhuma troca registrada", q5.transitions().size(), 0);
        BattleSim.lockFromTick = -1;

        // ---- AO_ACERTAR -> SEQ, sprite de agarrar
        CharData chG = chr(move(new int[]{2, 40}, new int[]{10, 41}, new int[]{12, 42}, new int[]{32, 43}, new int[]{24, 44}), new byte[][] {});
        A[] gq = new A[45];
        for (int i = 0; i < 45; i++) gq[i] = new A().mpt(new M().time(1));
        gq[40] = new A().mpt(new M().time(2)).mpt(new M().time(4).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(20));
        gq[41] = new A().mpt(new M().time(30));
        gq[42] = new A().mpt(new M().time(5));
        gq[43] = new A().mpt(new M().time(3));
        gq[44] = new A().mpt(new M().time(60));
        BattleSim g1 = new BattleSim(dac(gq), chG, chG.moves[0], false, defDac, fxDac, g, 30, 0, 0);
        for (int i = 0; i < 6; i++) g1.step();
        check("melee vai direto para a SEQ (AO_ACERTAR so em projetil)", g1.attacker().root().ano.index, 41);
        check("agarrar fica sem imagem durante o hitstop (o md 941 refaz o _SetAct e pausa)", nl(g1), 2);
        boolean grabShown = false;
        for (int i = 0; i < 40 && !grabShown; i++) { g1.step(); grabShown = nl(g1) >= 3; }
        check("sprite de agarrar aparece depois do hitstop, com o defensor em dano", grabShown, true);
        for (int i = 0; i < 80 && nl(g1) >= 3; i++) g1.step();
        check("agarrar some quando o defensor sai do estado de dano", nl(g1), 2);

        // projetil acertando: AO_ACERTAR e, se houver SEQ, ela assume na mesma hora
        CharData chP = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{32, 43}), new byte[][] {});
        A[] pq = new A[45];
        for (int i = 0; i < 45; i++) pq[i] = new A().mpt(new M().time(1));
        pq[40] = new A().mpt(new M().time(2).hit(0, 10, -30, 4, 4)).mpt(new M().time(60));
        pq[30] = new A().mpt(new M().time(60).speedX(2 << 16).hit(2, 0, -30, 16, 20).opt1(3));
        pq[43] = new A().mpt(new M().time(30));
        BattleSim p1 = new BattleSim(dac(pq), chP, chP.moves[0], false, defDac, fxDac, g, 40, 0, 0);
        for (int i = 0; i < 40 && p1.attacker().root().ano.index != 43; i++) p1.step();
        check("projetil acertou: atacante toca AO_ACERTAR", p1.attacker().root().ano.index, 43);
        boolean projHit = false;
        BattleSim p2 = new BattleSim(dac(pq), chP, chP.moves[0], false, defDac, fxDac, g, 40, 0, 0);
        for (BattleSim.HitEvent he : p2.probeHits(40)) if (he.kind == 2 && he.target == 43 && he.projectile) projHit = true;
        check("sonda: acerto de projetil marca ANIM_AO_ACERTAR", projHit, true);

        // pouso: cai com velocidade Y > 0, toca ANO 13 + se_12 quando POUSO e 0
        A[] lq = new A[45];
        for (int i = 0; i < 45; i++) lq[i] = new A().mpt(new M().time(1));
        lq[40] = new A().mpt(new M().time(60));
        lq[13] = new A().mpt(new M().time(20));
        CharData chL = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim l1 = new BattleSim(dac(lq), chL, chL.moves[0], false, defDac, fxDac, g, 300, 40, 0);
        boolean se12 = false;
        for (int i = 0; i < 30; i++) { l1.attacker().root().speedY = 5 << 16; l1.step(); for (BattleSim.Snd x : l1.drainSounds()) if (x.common && x.id == 12) se12 = true; if (l1.attacker().root().ano.index == 13) break; }
        check("pouso padrao ANO 13", l1.attacker().root().ano.index, 13);
        check("pouso toca se_12", se12, true);

        // ---- auras (flags 10-17 / 41-70 / 71-125) e chao
        A[] au = new A[260];
        for (int i = 0; i < 260; i++) au[i] = new A().mpt(new M().time(1));
        au[40] = new A().mpt(new M().time(3).hit(71, 5, -10, 0, 0).hit(41, 0, 0, 0, 0).hit(10, 0, 0, 0, 0)).mpt(new M().time(5));
        au[201] = new A().mpt(new M().time(50));
        A[] fxA = new A[60];
        for (int i = 0; i < 60; i++) fxA[i] = new A().mpt(new M().time(50));
        A[] cfA = new A[40];
        for (int i = 0; i < 40; i++) cfA[i] = new A().mpt(new M().time(50));
        CharData chA = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim b1 = new BattleSim(dac(au), chA, chA.moves[0], false, defDac, dac(fxA), g, 300, 0, 0);
        b1.setCharfDac(dac(cfA));
        check("3 auras no frame com as flags", nl(b1), 5);   // oponente, atacante, 3 auras
        for (int i = 0; i < 4; i++) b1.step();
        check("auras somem com o frame", nl(b1), 2);
        // chao: atacante no ar com gravidade nao passa de y = 0
        A fall = new A().mpt(new M().time(60).speedX(0));
        BattleSim b2 = new BattleSim(dac(au), chA, chA.moves[0], false, defDac, null, g, 300, 40, 0);
        check("atacante comeca no ar", b2.attacker().root().y < 0, true);
        for (int i = 0; i < 30; i++) { b2.attacker().root().speedY = 5 << 16; b2.step(); }
        check("atacante parou no chao", b2.attacker().root().y <= 0, true);

        // ---- flags 39 / 40 (teleporte)
        A[] tp = new A[45];
        for (int i = 0; i < 45; i++) tp[i] = new A().mpt(new M().time(1));
        tp[40] = new A().mpt(new M().time(5).hit(40, 25, -3, 0, 0)).mpt(new M().time(5));
        CharData chT = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim t1 = new BattleSim(dac(tp), chT, chT.moves[0], false, defDac, fxDac, g, 200, 0, 0);
        check("flag 40 leva o oponente para x+25", t1.opponentX() - (t1.attacker().root().x >> 16), 25);
        BattleSim t2 = new BattleSim(dac(tp), chT, chT.moves[0], true, defDac, fxDac, g, 200, 0, 0);
        check("flag 40 espelha com o flip", t2.opponentX() - (t2.attacker().root().x >> 16), -25);
        tp[40] = new A().mpt(new M().time(5).hit(39, 0, 0, 0, 0)).mpt(new M().time(5));
        BattleSim t3 = new BattleSim(dac(tp), chT, chT.moves[0], false, defDac, fxDac, g, 200, 0, 0);
        // o _SetXY do atacante ja passou quando a flag 39 muda PlayerXPos: so aparece no PlayerTail do tick seguinte
        check("flag 39: o atacante ainda esta no lugar no tick do frame", t3.attacker().root().x >> 16, -80);
        t3.step();
        check("flag 39 leva o atacante ao oponente", t3.attacker().root().x >> 16, 120);   // oponente nasce a +120 (spawn do jogo)

        // ---- SE do DAC: id-1 para < 80; 80 = primeiro audio do personagem
        A[] sa = new A[45];
        for (int i = 0; i < 45; i++) sa[i] = new A().mpt(new M().time(1));
        sa[40] = new A().mpt(new M().time(3).se(8)).mpt(new M().time(3).se(81)).mpt(new M().time(3));
        CharData chS2 = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim se1 = new BattleSim(dac(sa), chS2, chS2.moves[0], false, defDac, fxDac, g, 200, 0, 5);
        List<BattleSim.Snd> sl = se1.drainSounds();
        check("dac 8 toca se_07", sl.size() == 1 && sl.get(0).common && sl.get(0).id == 7, true);
        for (int i = 0; i < 4; i++) se1.step();
        sl = se1.drainSounds();
        check("dac 81 e o 2o audio do personagem", sl.size() == 1 && !sl.get(0).common && sl.get(0).id == 1 && sl.get(0).owner == 0, true);

        // ---- duracao = ticks do ANO atual; loop so com wActFlag 1
        A[] ml = new A[45];
        for (int i = 0; i < 45; i++) ml[i] = new A().mpt(new M().time(1));
        ml[40] = new A().mpt(new M().time(4)).mpt(new M().time(4)).mpt(new M().time(4));
        CharData chM = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim m1 = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        int len1 = m1.measureLength();
        check("duracao do ANO sem loop (12 ticks)", len1 >= 11 && len1 <= 13, true);
        check("ANO sem wActFlag 1 nao repete", m1.loops(), false);
        ml[40] = new A().mpt(new M().time(4)).mpt(new M().time(4)).mpt(new M().time(4).act(1));
        BattleSim m2 = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        int len2 = m2.measureLength();
        check("ANO com wActFlag 1 repete", m2.loops(), true);
        check("duracao do ciclo (12 ticks)", len2 >= 11 && len2 <= 13, true);

        // ---- diagonal para baixo comecando no chao: pousa (ANO 13) em vez de seguir para a frente
        A[] dg = new A[45];
        for (int i = 0; i < 45; i++) dg[i] = new A().mpt(new M().time(1));
        dg[40] = new A().mpt(new M().time(60).speedX(3 << 16).speedY(2 << 16));
        dg[13] = new A().mpt(new M().time(20));
        CharData chD = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim d1 = new BattleSim(dac(dg), chD, chD.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        for (int i = 0; i < 6 && d1.attacker().root().ano.index != 13; i++) d1.step();
        check("diagonal a partir do chao pousa na ANO 13", d1.attacker().root().ano.index, 13);
        int x13 = d1.attacker().root().x;
        for (int i = 0; i < 5; i++) d1.step();
        check("depois de pousar nao anda mais", d1.attacker().root().x, x13);

        // ---- ANO generico (modo ANOS): pousa em y>0 mesmo sem velocidade vertical para baixo
        A[] gg = new A[45];
        for (int i = 0; i < 45; i++) gg[i] = new A().mpt(new M().time(1));
        gg[40] = new A().mpt(new M().time(60).speedX(3 << 16));
        gg[13] = new A().mpt(new M().time(20));
        CharData chGen = chr(move(new int[]{2, 40}), new byte[][] {});
        CharData.Move gm = CharData.blank(40);
        BattleSim gen1 = new BattleSim(dac(gg), chGen, gm, false, defDac, fxDac, g, 300, 0, 0);
        gen1.attacker().root().y = 3 << 16;
        gen1.step();
        check("ANO generico abaixo do chao pousa na 13", gen1.attacker().root().ano.index, 13);

        // ---- teto da tela: 240 px acima do chao
        A[] cc = new A[45];
        for (int i = 0; i < 45; i++) cc[i] = new A().mpt(new M().time(1));
        cc[40] = new A().mpt(new M().time(60).speedY(-(100 << 16)));
        CharData chC = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim c1 = new BattleSim(dac(cc), chC, chC.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        for (int i = 0; i < 5; i++) c1.step();
        check("atacante nao passa do teto", c1.attacker().root().y >= -15728640, true);

        // ---- bordas: parede do mapa, limite de tela e rolagem da camera
        A[] ed = new A[45];
        for (int i = 0; i < 45; i++) ed[i] = new A().mpt(new M().time(1));
        ed[40] = new A().mpt(new M().time(200).speedX(-(4 << 16)));      // anda para tras (esquerda)
        CharData chE = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim.edgeMode = 1;
        BattleSim e1 = new BattleSim(dac(ed), chE, chE.moves[0], false, defDac, fxDac, g, 100, 0, 0);
        check("camera comeca centrada na origem", Math.abs(e1.screenLeft() + e1.screenRight()) <= 65536, true);
        check("atacante a distancia 100 do oponente (x = 20)", e1.attacker().root().x, 20 * 65536);
        check("oponente fica no spawn do jogo (+120)", e1.opponentX(), 120);
        BattleSim e2 = new BattleSim(dac(ed), chE, chE.moves[0], true, defDac, fxDac, g, 640, 0, 0);
        check("distancia 640 e puxada para dentro da tela", Math.abs(e2.opponentX() - e2.attacker().root().x) <= 480 * 65536, true);
        BattleSim.edgeMode = 1;
        A[] ew = new A[45];
        for (int i = 0; i < 45; i++) ew[i] = new A().mpt(new M().time(1));
        ew[40] = new A().mpt(new M().time(200).speedX(3 << 16));
        CharData chW = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim e3 = new BattleSim(dac(ew), chW, chW.moves[0], false, defDac, fxDac, g, 200, 0, 0);
        int cl0 = e3.screenLeft();
        for (int i = 0; i < 120; i++) e3.step();
        check("camera rola quando o lutador anda para a direita", e3.screenLeft() > cl0, true);
        check("lutador continua dentro da tela", e3.attacker().root().x <= e3.screenRight(), true);
        BattleSim.edgeMode = 0;

        // ---- formato texto do DAC / HDAT 4 (abas e editor)
        BattleSim it = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        it.step();
        AttackSim.Obj ir = it.attacker().root();
        String at = InfoText.ano(ir);
        check("aba ano comeca em $ANO", at.startsWith("$ANO_"), true);
        check("aba ano marca o frame atual", at.indexOf(InfoText.MARK) >= 0, true);
        String ft = InfoText.frame(ir);
        check("aba frame", ft.startsWith("$MPT_"), true);
        check("frame ida e volta", DacText.mpt(DacText.parseMpt(ft), ir.pat, "").equals(ft), true);
        String ano0 = DacText.ano(ir.ano, -1);
        check("ano ida e volta", DacText.ano(DacText.parseAno(ano0, ir.ano.index, ir.ano), ir.ano.index == 0 ? -1 : -1).equals(ano0), true);
        check("move ida e volta", InfoText.move(new AttackData(null, null, null, null, 0, chM.moves[0])).startsWith("$GOLPE_0:{"), true);
        CharData.Move mvE = chM.moves[0].copy();
        DacText.parseMove("$GOLPE_0:{ $ANIM_INICIAL: 77, $HOMING: 3 }", mvE);
        check("editar golpe", mvE.animInicial == 77 && mvE.homing == 3 && mvE.projNormal == chM.moves[0].projNormal, true);
        boolean threw = false;
        try { DacText.parseMpt("$MPT_0:{ $TIME: 4, $FOO: 1 }"); } catch (DacText.ParseError e) { threw = true; }
        check("erro de campo desconhecido", threw, true);
        check("fixed -0.6", DacText.fix(-39321), "-0.6");
        check("fixed 14", DacText.fix(14 * 65536), "14");

        // ---- timeline: primeiro tick de cada frame e copia profunda
        BattleSim ftl = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        int a0 = ftl.firstTickOf(ftl.attacker().root().ano.index, 0, 200);
        int a1 = ftl.firstTickOf(ftl.attacker().root().ano.index, 1, 200);
        check("firstTickOf frame 0", a0, 0);
        check("firstTickOf frame 1 > 0", a1 > 0, true);
        Ano.Mpt cm = ftl.attacker().root().mpts[0].copy();
        cm.image = 99;
        check("copia nao altera original", ftl.attacker().root().mpts[0].image != 99, true);

        // ---- operacoes de edicao estilo editor de video
        Ano.Mpt[] om = new Ano.Mpt[3];
        for (int q = 0; q < 3; q++) { om[q] = new Ano.Mpt(); om[q].flags = 0x20; om[q].time = 10; om[q].image = q; om[q].normalize(); }
        check("total", FrameOps.total(om), 30);
        FrameOps.Split sp = FrameOps.splitAt(om, 14);
        check("dividir cria frame", sp != null && sp.changed && sp.mpts.length == 4 && sp.index == 2, true);
        check("dividir mantem o total", FrameOps.total(sp.mpts), 30);
        check("dividir: metades 4+6", sp.mpts[1].time == 4 && sp.mpts[2].time == 6 && sp.mpts[2].image == 1, true);
        check("dividir no limite nao muda", FrameOps.splitAt(om, 10).changed, false);
        check("duplicar", FrameOps.duplicate(om, 0).length, 4);
        check("apagar", FrameOps.delete(om, 1).length, 2);
        check("nao apaga o ultimo", FrameOps.delete(new Ano.Mpt[]{om[0]}, 0) == null, true);
        FrameOps.Split ks = FrameOps.addKey(om, FrameOps.SOM, 5);
        check("keyframe divide e marca", ks != null && ks.mpts.length == 4 && FrameOps.has(FrameOps.SOM, ks.mpts[ks.index]), true);
        Ano.Mpt[] km = FrameOps.moveKey(ks.mpts, FrameOps.SOM, ks.index, 3);
        check("mover keyframe", km != null && FrameOps.has(FrameOps.SOM, km[3]) && !FrameOps.has(FrameOps.SOM, km[ks.index]), true);
        Ano.Mpt[] hm = FrameOps.addHit(om, 1);
        java.util.List<FrameOps.Run> hr = FrameOps.hitRuns(hm);
        check("hitbox vira clipe", hr.size() == 1 && hr.get(0).f0 == 1 && hr.get(0).f1 == 1, true);
        Ano.Mpt[] hm2 = FrameOps.setRunRange(hm, hr.get(0), 0, 2);
        java.util.List<FrameOps.Run> hr2 = FrameOps.hitRuns(hm2);
        check("estender clipe de hitbox", hr2.size() == 1 && hr2.get(0).f0 == 0 && hr2.get(0).f1 == 2, true);
        check("encolher clipe de hitbox", FrameOps.hitRuns(FrameOps.setRunRange(hm2, hr2.get(0), 1, 1)).get(0).f0, 1);
        check("apagar clipe", FrameOps.hitRuns(FrameOps.deleteRun(hm2, hr2.get(0))).size(), 0);

        // ---- modelo de objetos (timeline por sprite)
        {
            Ano.Mpt[] o_ob = new Ano.Mpt[4];
            for (int q = 0; q < 4; q++) { o_ob[q] = new Ano.Mpt(); o_ob[q].flags = 0x20; o_ob[q].time = 6; o_ob[q].image = q; o_ob[q].normalize(); }
            o_ob = ObjModel.add(o_ob, 1, 3, ObjModel.defaultHit(2));                 // hitbox nos frames 1..3
            o_ob = ObjModel.add(o_ob, 0, 1, ObjModel.defaultHit(1));                 // hurtbox 0..1
            o_ob = ObjModel.add(o_ob, 2, 2, ObjModel.defaultHit(12));                // efeito no frame 2
            java.util.List<ObjModel.Obj> o_os = ObjModel.objects(o_ob);
            check("objetos: 3", o_os.size(), 3);
            ObjModel.Obj o_hb = null, o_ef = null;
            for (ObjModel.Obj o : o_os) { if (o.flag == 2) o_hb = o; if (o.flag == 12) o_ef = o; }
            check("hitbox f1..f3", o_hb.f0 == 1 && o_hb.f1 == 3, true);
            check("tipos", o_hb.kind == ObjModel.HITBOX && o_ef.kind == ObjModel.EFFECT, true);
            // valores diferentes = objeto separado (so um frame editado)
            Ano.Mpt[] o_e1 = ObjModel.setCoordsRange(o_ob, o_hb, 2, 2, 5, 6, 7, 8);
            java.util.List<ObjModel.Obj> o_l1 = ObjModel.objects(o_e1);
            ObjModel.Obj o_s1 = ObjModel.find(o_l1, 2, 0, 1), o_s2 = ObjModel.find(o_l1, 2, 0, 2), o_s3 = ObjModel.find(o_l1, 2, 0, 3);
            check("valor diferente separa em tres", o_s1.f1 == 1 && o_s2.f0 == 2 && o_s2.f1 == 2 && o_s3.f0 == 3, true);
            // editar o objeto inteiro mexe em todos os frames conectados
            Ano.Mpt[] o_e2 = ObjModel.setCoordsRange(o_ob, o_hb, o_hb.f0, o_hb.f1, 9, 9, 9, 9);
            ObjModel.Obj o_w = ObjModel.find(ObjModel.objects(o_e2), 2, 0, 1);
            check("conectado: todos iguais", o_w.f0 == 1 && o_w.f1 == 3 && ObjModel.find(o_e2[3], 2, 0).x == 9, true);
            // dividir (cut) sem mudar valores: separa so na edicao
            Ano.Mpt[] o_c = o_e2.clone();
            o_c[2] = o_e2[2].copy();
            ObjModel.find(o_c[2], 2, 0).cut = true;
            java.util.List<ObjModel.Obj> o_lc = ObjModel.objects(o_c);
            check("dividir cria dois objetos", ObjModel.find(o_lc, 2, 0, 1).f1 == 1 && ObjModel.find(o_lc, 2, 0, 2).f0 == 2, true);
            check("cut sobrevive a copia do sprite", ObjModel.find(o_c[2].copy(), 2, 0).cut, true);
            // aparar
            Ano.Mpt[] o_t1 = ObjModel.trim(o_ob, o_hb, 2, 3);
            check("aparar esquerda", ObjModel.find(ObjModel.objects(o_t1), 2, 0, 2).f0, 2);
            Ano.Mpt[] o_t2 = ObjModel.trim(o_ob, o_hb, 0, 3);
            check("estender esquerda", ObjModel.find(ObjModel.objects(o_t2), 2, 0, 0).f0, 0);
            check("remover objeto", ObjModel.objects(ObjModel.remove(o_ob, o_hb)).size(), 2);
            Ano.Mpt[] o_sf = ObjModel.setFlag(o_ob, o_ef, 41);
            check("trocar efeito", ObjModel.find(ObjModel.objects(o_sf), 41, 0, 2) != null, true);
            check("mapeamento de efeito", ObjModel.fxAno(10) + "," + ObjModel.fxAno(41) + "," + ObjModel.fxAno(71), "50,3,201");
            check("mapeamento inverso", ObjModel.fxFlag(1, 3) + "," + ObjModel.fxFlag(0, 51) + "," + ObjModel.fxFlag(2, 201), "41,11,71");
            // dois hits com a mesma flag = dois objetos
            Ano.Mpt[] o_two = ObjModel.add(o_ob, 1, 1, ObjModel.defaultHit(2));
            check("duas hitboxes no mesmo frame", ObjModel.objects(o_two).size(), 4);
            // loop preserva wActFlag 2
            Ano.Mpt[] o_lp = o_ob.clone();
            o_lp[3] = o_lp[3].copy(); o_lp[3].flags |= 2; o_lp[3].wActFlag = 2; o_lp[3].normalize();
            Ano.Mpt[] o_lp2 = ObjModel.setLoop(o_lp, true);
            check("loop liga sem perder fim", ObjModel.loops(o_lp2) && (o_lp2[3].wActFlag & 2) != 0, true);
            check("loop desliga e mantem fim", !ObjModel.loops(ObjModel.setLoop(o_lp2, false)) && (ObjModel.setLoop(o_lp2, false)[3].wActFlag & 2) != 0, true);
            Ano.Mpt o_fl = ObjModel.setSpriteBit(o_ob[0], ObjModel.FLIP_H, true);
            check("espelhar liga/desliga", ObjModel.spriteBit(o_fl, 16) && !ObjModel.spriteBit(ObjModel.setSpriteBit(o_fl, 16, false), 16), true);
            check("dano do sprite", ObjModel.optField(ObjModel.setOptField(o_ob[0], 0, 33), 0), 33);
            check("segundos", ObjModel.seconds(30), "0.50s");
        }

        // ---- posicao: distancia grande faz o atacante recuar (dentro da borda); reacao de previa
        {
            int oldEdge = BattleSim.edgeMode;
            BattleSim.edgeMode = 1;
            BattleSim near = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 120, 0, 0);
            check("dist 120: oponente em +120 e atacante em 0", near.attackerX() == 0 && near.opponentX() == 120, true);
            BattleSim far = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            check("dist 400: oponente na borda e atacante recua", far.opponentX() - far.attackerX() == 400 && far.attackerX() < 0, true);
            BattleSim huge = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 640, 0, 0);
            check("dist enorme: ambos dentro da borda", huge.attackerX() >= -240 && huge.opponentX() <= 240, true);
            // camera vertical (md 19/3): atacante a 144 px de altura, oponente no chao => offset -72, iBackYPos -35 (golpe 4 do log do jogo)
            BattleSim cy = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 104, 144, 0);
            cy.step();
            check("camera Y: topo da tela sobe 35 px", cy.screenTop(), (-240 - 35) * 65536);
            BattleSim cg = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 104, 0, 0);
            cg.step();
            check("camera Y no chao: topo em -240", cg.screenTop(), -240 * 65536);
            BattleSim zf = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            for (int i = 0; i < 17; i++) zf.step();
            float[] zr = zf.zoomRect();
            check("lutadores a mais de 320 px: zoom out 90% (retangulo maior que 480)", zr != null && zr[2] - zr[0] > 520f && zr[2] - zr[0] < 540f, true);
            BattleSim zn = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 240, 0, 0);
            for (int i = 0; i < 17; i++) zn.step();
            check("distancia 240: sem zoom", zn.zoomRect() == null, true);
            BattleSim.edgeMode = oldEdge;
            BattleSim rv = new BattleSim(dac(ml), chM, CharData.blank(0), false, defDac, fxDac, g, 100, 0, 0);
            rv.forceHit(0);
            check("forceHit registra o acerto", rv.lastHit().length() > 0, true);
        }

        {
            byte[] rb = new byte[14 * 2];
            rb[2] = 5; rb[14 + 2] = 7;
            ReactionTable rt = new ReactionTable(rb, 0);
            ReactionTable snap = rt.copy();
            rt.insertRow(0);
            check("reacao: inserir passo copia o anterior", rt.rows == 3 && rt.s8(1, 2) == 5 && rt.s8(2, 2) == 7, true);
            rt.set(1, 2, -9);
            check("reacao: editar byte com sinal", rt.s8(1, 2), -9);
            rt.removeRow(0);
            check("reacao: remover passo", rt.rows == 2 && rt.s8(0, 2) == -9, true);
            rt.restoreFrom(snap);
            check("reacao: desfazer restaura", rt.rows == 2 && rt.s8(0, 2) == 5, true);
        }

        // ---- tempo estendido: sem nada acontecendo apos o ANO, o tamanho e o mesmo; atacante nao se move depois do fim
        BattleSim.extendTime = true;
        ml[40] = new A().mpt(new M().time(4)).mpt(new M().time(4)).mpt(new M().time(4));
        BattleSim x1 = new BattleSim(dac(ml), chM, chM.moves[0], false, defDac, fxDac, g, 300, 0, 0);
        int lx = x1.measureLength();
        check("tempo estendido sem reacao = duracao do ANO", lx >= 11 && lx <= 13, true);
        for (int i = 0; i < 40; i++) x1.step();
        check("atacante segue vivo e parado apos o fim", x1.attacker().root() != null && x1.attacker().root().isDone(), true);
        // fim estendido espera o pouso: atacante no ar nao fica congelado
        chM.flies = false;
        A[] ml2 = java.util.Arrays.copyOf(ml, 100);
        ml2[89] = new A().mpt(new M().time(4));
        ml2[13] = new A().mpt(new M().time(4));
        for (int q = 0; q < ml2.length; q++) if (ml2[q] == null) ml2[q] = new A().mpt(new M().time(4));
        BattleSim x2 = new BattleSim(dac(ml2), chM, chM.moves[0], false, defDac, fxDac, g, 300, 80, 0);
        int l2 = x2.measureLength();
        for (int i = 0; i < 300; i++) x2.step();
        check("estendido: atacante pousou", x2.attacker().root() != null && (x2.attacker().root().y >= 0 || x2.attacker().root().ano.index == 89), true);
        check("estendido: espera o pouso (>ANO)", l2 > lx, true);
        chM.flies = true;
        BattleSim.extendTime = false;

        // ---- tempo estendido com projetil ativo: espera a colisao/desaparecimento
        {
            BattleSim.extendTime = true;
            A[] pa = atkAnos.clone();
            pa[40] = new A().mpt(new M().time(2).hit(0, 10, -30, 4, 4)).mpt(new M().time(10));
            pa[30] = new A().mpt(new M().time(250).speedX(1 << 16).hit(2, 0, -30, 16, 20).opt1(3));
            BattleSim px = new BattleSim(dac(pa), ch, ch.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            int lp = px.measureLength();
            for (int i = 0; i < lp; i++) px.step();
            check("estendido+projetil: nada ativo no fim", px.projectileCount() + 0, 0);
            check("estendido+projetil: durou mais que o ANO", lp > 60, true);
            BattleSim.extendTime = false;
        }

        // ---- projetil: acabou a animacao, o projetil some (confirmado no jogo)
        {
            A[] pa = atkAnos.clone();
            pa[40] = new A().mpt(new M().time(2).hit(0, 10, -30, 4, 4)).mpt(new M().time(40));
            pa[30] = new A().mpt(new M().time(4).speedX(2 << 16).hit(2, 0, -30, 16, 20).opt1(3));
            BattleSim ph = new BattleSim(dac(pa), ch, ch.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            for (int i = 0; i < 20; i++) ph.step();
            check("projetil some apos fim da animacao", ph.projectileCount(), 0);
        }

        // ---- tempo estendido: depois do ANO, o atacante volta ao ANO 0 (idle); a timeline fica no ANO que acabou
        {
            A[] pi = atkAnos.clone();
            pi[0] = new A().mpt(new M().time(8));
            pi[40] = new A().mpt(new M().time(5));
            BattleSim.extendTime = true;
            BattleSim si = new BattleSim(dac(pi), ch, ch.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            for (int i = 0; i < 30; i++) si.step();
            check("fisica: atacante em idle (ANO 0)", si.attacker().root().ano.index, 0);
            check("fisica: timeline segue no ANO do golpe", si.timelineAtk().root().ano.index, 40);
            BattleSim.lockFromTick = 0;
            BattleSim sLk = new BattleSim(dac(pi), ch, ch.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            for (int i = 0; i < 30; i++) sLk.step();
            check("fisica com trava: sem idle", sLk.attacker().root().ano.index, 40);
            BattleSim.lockFromTick = -1;
            BattleSim.extendTime = false;
        }

        // ---- edicao por bordas: dividir objetos, duplicar, trechos de velocidade e estilo
        {
            // hit (flag 2) e projetil (flag 0) num sprite de 20 ticks, seguido de outro de 10
            Ano.Mpt[] e = dac(new A().mpt(new M().time(20).hit(2, 0, 0, 8, 8).hit(0, 0, 0, 0, 0).se(3).speedX(5 << 16).opt1(2))
                    .mpt(new M().time(10))).getAno(0).mpts;
            FrameOps.Split spl = FrameOps.splitAt(e, 8);
            check("dividir: 3 frames", spl.mpts.length, 3);
            check("dividir: 1a metade mantem projetil", ObjModel.count(spl.mpts[0], 0), 1);
            check("dividir: 2a metade nao repete projetil", ObjModel.count(spl.mpts[1], 0), 0);
            check("dividir: 2a metade mantem hitbox", ObjModel.count(spl.mpts[1], 2), 1);
            // aparar a hitbox ate o tick 8 (dentro do sprite): ela fica so na 1a metade
            Ano.Mpt[] two = spl.mpts;
            ObjModel.Obj hb = ObjModel.find(ObjModel.objects(two), 2, 0, 0);
            Ano.Mpt[] cut = ObjModel.trim(two, hb, 0, 0);
            check("aparar: hitbox so no 1o pedaco", ObjModel.count(cut[1], 2) + "/" + ObjModel.count(cut[0], 2), "0/1");

            // duplicar sprite: nao leva hits, som, velocidade nem opcoes
            Ano.Mpt[] dup = FrameOps.duplicate(e, 0);
            check("duplicar sprite: copia sem hits", ObjModel.count(dup[1], 2) + ObjModel.count(dup[1], 0), 0);
            check("duplicar sprite: copia sem som/velocidade/opcoes", ((dup[1].flags & (8 | 4 | 0x40 | 0x10)) == 0), true);
            check("duplicar sprite: mantem imagem e tempo", dup[1].image + "/" + dup[1].time, e[0].image + "/" + e[0].time);

            // trecho de velocidade: estende para 3 frames e encolhe de volta
            Ano.Mpt[] mv = dac(new A().mpt(new M().time(5).speedX(4 << 16)).mpt(new M().time(5)).mpt(new M().time(5)).mpt(new M().time(5))).getAno(0).mpts;
            check("velocidade: trecho inicial", FrameOps.moveRunEnd(mv, 0), 0);
            Ano.Mpt[] ext = FrameOps.setMoveRun(mv, 0, 2);
            check("velocidade: estendido ate 2", FrameOps.moveRunEnd(ext, 0), 2);
            check("velocidade: frame 3 fora", FrameOps.moveHeadOf(ext, 3), -1);
            check("velocidade: frame 2 pertence ao trecho", FrameOps.moveHeadOf(ext, 2), 0);
            Ano.Mpt[] back = FrameOps.setMoveRun(ext, 0, 0);
            check("velocidade: encolhido", FrameOps.moveRunEnd(back, 0) + "/" + (back[1].wActFlag & 64) + "/" + (back[2].wActFlag & 64), "0/0/0");

            // estilo: espelhar H no frame 0, estende ate 2 e encolhe
            Ano.Mpt[] st = dac(new A().mpt(new M().time(5).act(ObjModel.FLIP_H)).mpt(new M().time(5)).mpt(new M().time(5))).getAno(0).mpts;
            Ano.Mpt[] se2 = FrameOps.setStyleRun(st, 0, 2);
            check("estilo: estendido", FrameOps.styleRunEnd(se2, 0), 2);
            check("estilo: encolhido", FrameOps.styleRunEnd(FrameOps.setStyleRun(se2, 0, 0), 0), 0);
            check("tempo: formato", ObjModel.timeText(30) + " | " + ObjModel.timeText(1), "0.5s/30 ticks | 0.02s/1 tick");
        }

        // ---- F-GHOST: copia do combate no inicio do frame vizinho
        {
            A[] pg = atkAnos.clone();
            pg[40] = new A().mpt(new M().time(10).speedX(2 << 16)).mpt(new M().time(10)).mpt(new M().time(10));
            BattleSim bg = new BattleSim(dac(pg), ch, ch.moves[0], false, defDac, fxDac, g, 400, 0, 0);
            int[] gft = bg.firstTicks(40, 3, 100);
            BattleSim gh1 = bg.copyAt(gft[1]);
            BattleSim gh2 = bg.copyAt(gft[0]);
            check("ghost: inicia no tick do frame 1", gft[1], 10);
            check("ghost: o frame seguinte mostra o deslocamento da velocidade", gh1.attacker().root().x > gh2.attacker().root().x, true);
            check("ghost: copia nao mexe no combate original", bg.attacker().root().x, 0);
        }

        // ---- sequencia: marcadores de hit calculados por sondagem e limite de 255 do BIN
        {
            CharData.Move mseq = ch.moves[0].copy();
            mseq.animSeqChao = 41;
            A[] aq = new A[60];
            for (int i = 0; i < 60; i++) aq[i] = new A().mpt(new M().time(1));
            aq[40] = new A().mpt(new M().time(2).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(2).hit(2, 20, -40, 40, 20).opt1(3));
            BattleSim bsq = new BattleSim(dac(aq), ch, mseq, false, defDac, fxDac, g, 30, 0, 0);
            List<BattleSim.HitEvent> ev = bsq.probeHits(40);
            check("sequencia: ha marcadores", ev.size() >= 1, true);
            check("sequencia: tipo SEQ para a ANO 41", ev.get(0).kind + "/" + ev.get(0).target, "0/41");
            check("sequencia: sonda nao troca de ANO no combate original", bsq.attacker().root().ano.index, 40);
            mseq.animSeqChao = 999; mseq.homingSpeed = 40000;
            mseq.clamp();
            check("HDAT 4: campos de 16 bits (999 passa, acima de 32767 corta)", mseq.animSeqChao + "/" + mseq.homingSpeed, "999/32767");
            CharData.Move mh = ch.moves[0].copy();
            mh.animSeqChao = 0; mh.animEndChao = 0; mh.animSeqAr = 0; mh.animEndAr = 0; mh.animAoAcertar = 41;
            BattleSim bsh = new BattleSim(dac(aq), ch, mh, false, defDac, fxDac, g, 30, 0, 0);
            boolean hasHit = false;
            for (BattleSim.HitEvent he : bsh.probeHits(40)) if (he.kind == 2 && he.target == 41) hasHit = true;
            check("transicoes: hit corpo a corpo NAO marca ANIM_AO_ACERTAR (so o acerto de projetil)", hasHit, false);
        }

        // ---- salvar: textos legiveis (golpe + ANOs alcancados), binarios intocados
        {
            Dac sd = dac(atkAnos);
            String mt = Saver.moveText(sd, ch, ch.moves[0], 0);
            check("salvar golpe: bloco $GOLPE_0", mt.contains("$GOLPE_0:{"), true);
            check("salvar golpe: ANO inicial 40", mt.contains("$ANO_40: {"), true);
            check("salvar golpe: ANO do projetil 30", mt.contains("$ANO_30: {"), true);
            check("salvar golpe: ANO de impacto 31", mt.contains("$ANO_31: {"), true);
            java.io.File td = new java.io.File(System.getProperty("java.io.tmpdir"), "salvar_test_char");
            td.mkdirs();
            java.io.File f1 = Saver.saveAno(td, sd, 40);
            String back = new String(java.nio.file.Files.readAllBytes(f1.toPath()), "UTF-8");
            check("salvar ano: arquivo no formato DAC_ACT_", back.startsWith("DAC_ACT_ {") && back.contains("$ANO_40: {"), true);
            Saver.saveAllAnos(td, sd);
            check("salvar todos os anos: 000.dac.txt em salvos/", new java.io.File(td, "salvos/000.dac.txt").isFile(), true);
            check("salvar nao cria binarios", new java.io.File(td, "000.dac").exists(), false);
        }

        // ---- salvar no Runtime: troca blocos nos .txt de origem mantendo o resto
        {
            Dac sd = dac(atkAnos);
            java.io.File rd = new java.io.File(System.getProperty("java.io.tmpdir"), "runtime_test_char");
            rd.mkdirs();
            Saver.write(new java.io.File(rd, "000.dac.txt"), "DAC_ACT_ {\n   // cabecalho que deve ficar\n   $ANO_4: {\n      $MPTS:{ }\n   },\n   $ANO_40: {\n      $MPTS:{ }\n   },\n}\n");
            Saver.write(new java.io.File(rd, "000.bin.txt"), "BIN_CNV_ {$COUNT: 1,\n   $HDAT_4:{$info:{$COL: 24, $ROW: 1, $SZ: &00000030},\n      $ATRIBUTOS_DE_GOLPE:{\n         $GOLPE_0:{\n            // --- GOLPE ---\n            $ATK_FLAGS: 9,\n            $ANIM_INICIAL: 1,\n            $PROJETIL_ANIM_NORMAL: 7\n         },\n      },\n   },\n   $HDAT_14:{$info:{$COL: 14, $ROW: 1, $SZ: &0000000E},\n      $REACAO_DANO_0:{\n      // dicionario\n         $FR_0: {$DUR_C: 1, $DUR_A: 1, $ANO: 1, $XSPEED: 0, $YSPEED: 0, $XACCEL: 0, $YACCEL: 0, $XSPEED_A: 0, $YSPEED_A: 0, $XACCEL_A: 0, $YACCEL_A: 0, $COMP: 0, $WALL: 0, $VOZ: 0},\n      },\n   },\n}\n");
            String res = Saver.saveRuntime(rd, sd, ch, java.util.Collections.singletonList(Integer.valueOf(40)), java.util.Collections.singletonList(Integer.valueOf(0)), false);
            String dt = Saver.readText(new java.io.File(rd, "000.dac.txt"));
            String bt = Saver.readText(new java.io.File(rd, "000.bin.txt"));
            check("runtime: ANO 40 trocado, ANO 4 e cabecalho intactos", dt.contains("// cabecalho que deve ficar") && dt.contains("$MPT_0:{") && dt.indexOf("$ANO_4: {\n      $MPTS:{ }") > 0, true);
            check("runtime: golpe atualizado, comentario mantido", bt.contains("// --- GOLPE ---") && bt.contains("$ANIM_INICIAL: " + ch.moves[0].animInicial) && bt.contains("$PROJETIL_ANIM_NORMAL: " + ch.moves[0].projNormal), true);
            check("runtime: resumo", res.startsWith("1 ANO(s)") || res.contains("ANO(s)"), true);
            ReactionTable rt0 = new ReactionTable(new byte[14 * 2], 0);
            rt0.set(1, 2, -5);
            boolean[] fl = new boolean[1];
            String pr = Saver.patchReaction(bt, rt0, 0, fl);
            check("runtime: reacao ganha linha e mantem dicionario", fl[0] && pr.contains("$FR_1: {") && pr.contains("// dicionario") && pr.contains("$ROW: 2") && pr.contains("$ANO: -5"), true);
        }

        // ---- distancia grande: o atacante recua e os links (sem sync de XY) vao junto
        {
            A[] la = java.util.Arrays.copyOf(atkAnos, 60);
            for (int q = 0; q < la.length; q++) if (la[q] == null) la[q] = new A().mpt(new M().time(4));
            la[40] = new A().mpt(new M().time(30));
            la[41] = new A().mpt(new M().time(30));
            Dac ld = dac(la);
            Ano p40 = ld.getAno(40);
            ld.setAno(40, new Ano(40, true, p40.flags | 2, p40.priority, new Ano.Link[]{new Ano.Link(0, 0, 41 | 0x8000)}, p40.mpts));
            BattleSim.edgeMode = 1;
            BattleSim ls1 = new BattleSim(ld, ch, ch.moves[0], false, defDac, fxDac, g, 100, 0, 0);
            BattleSim ls2 = new BattleSim(ld, ch, ch.moves[0], false, defDac, fxDac, g, 440, 0, 0);
            AttackSim.Obj[] k1 = ls1.attacker().children(), k2 = ls2.attacker().children();
            int off1 = k1[0].x - ls1.attacker().root().x, off2 = k2[0].x - ls2.attacker().root().x;
            check("link acompanha o atacante ao aumentar a distancia", off1 == off2, true);
        }

        // ---- ordem de desenho global: parte do atacante com prio alta fica atras do oponente (mao da ANO 378)
        {
            A[] la = java.util.Arrays.copyOf(atkAnos, 60);
            for (int q = 0; q < la.length; q++) if (la[q] == null) la[q] = new A().mpt(new M().time(4));
            la[40] = new A().mpt(new M().time(30));
            la[41] = new A().mpt(new M().time(30));
            la[42] = new A().mpt(new M().time(30));
            Dac ld = dac(la);
            Ano p40 = ld.getAno(40), p41 = ld.getAno(41), p42 = ld.getAno(42);
            ld.setAno(41, new Ano(41, true, p41.flags, 65, p41.links, p41.mpts));          // mao: prio 65 -> atras do oponente
            ld.setAno(42, new Ano(42, true, p42.flags, -3, p42.links, p42.mpts));          // dedos: prio -3 -> na frente
            ld.setAno(40, new Ano(40, true, p40.flags | 2, p40.priority, new Ano.Link[]{new Ano.Link(0, 0, 41 | 0x8000), new Ano.Link(0, 0, 42 | 0x8000)}, p40.mpts));
            BattleSim lo = new BattleSim(ld, ch, ch.moves[0], false, defDac, fxDac, g, 60, 0, 0);
            java.util.List<BattleSim.Layer> lay = lo.layers();
            int iHand = -1, iOpp = -1, iBody = -1, iFing = -1;
            for (int q = 0; q < lay.size(); q++) {
                BattleSim.Layer ly = lay.get(q);
                if (ly.owner == BattleSim.OWNER_DEFENDER && iOpp < 0) iOpp = q;
                if (ly.owner == BattleSim.OWNER_ATTACKER && ly.only != null) {
                    if (ly.only.ano.index == 41) iHand = q;
                    if (ly.only.ano.index == 40) iBody = q;
                    if (ly.only.ano.index == 42) iFing = q;
                }
            }
            check("camadas: mao atras do oponente", iHand >= 0 && iHand < iOpp, true);
            check("camadas: corpo e dedos na frente do oponente", iBody > iOpp && iFing > iOpp, true);
        }

        // ---- vida: HP/ataque/defesa vem do HDAT 3, escala de combo do HDAT 5 do gamedata
        {
            byte[] h3a = new byte[18]; h3a[11] = 100; h3a[12] = (byte) 150;          // atacante: ataque 150
            byte[] h3d = new byte[18]; h3d[11] = 100; h3d[12] = 100; h3d[14] = 10;    // defensor: HP 100, defesa 10
            byte[][] ta = new byte[40][], td2 = new byte[40][], tg = new byte[40][];
            int[] ca = new int[40], ra = new int[40], cdc = new int[40], cdr = new int[40], cg = new int[40], rg = new int[40];
            for (int i = 0; i < 40; i++) { ta[i] = new byte[0]; td2[i] = new byte[0]; tg[i] = new byte[0]; }
            ta[3] = h3a; ca[3] = 18; ra[3] = 1; ta[4] = move(new int[]{2, 40}); ca[4] = 48; ra[4] = 1;
            td2[3] = h3d; cdc[3] = 18; cdr[3] = 1; td2[4] = move(new int[]{2, 40}); cdc[4] = 48; cdr[4] = 1;
            CharData ca1 = CharData.read(hdat(ta, ca, ra));
            CharData cd1 = CharData.read(hdat(td2, cdc, cdr));
            check("HP do HDAT 3", cd1.hp(0), 100);
            check("ataque do HDAT 3", ca1.attackMul(0), 150);
            check("defesa do HDAT 3", cd1.defenceMul(0), 10);
            Buf h5 = new Buf(); for (int i = 0; i < 14; i++) h5.u16(100); for (int i = 0; i < 14; i++) h5.u16(i == 0 ? 50 : (i == 1 ? 25 : 100));
            tg[5] = h5.get(); cg[5] = 28; rg[5] = 2;
            int[] tys = {0, 2, 3};
            for (int ty = 0; ty < 30; ty++) { tg[10 + ty] = react(new int[]{20, 20, 20}); cg[10 + ty] = 14; rg[10 + ty] = 1; }
            GameData gl = GameData.fromBytes(hdat(tg, cg, rg), "vida");
            check("escala de combo idx0", gl.comboScale(0), 50);
            check("escala de combo idx1", gl.comboScale(1), 25);
            A[] aa = new A[41]; for (int i = 0; i < 41; i++) aa[i] = new A().mpt(new M().time(1));
            aa[40] = new A().mpt(new M().time(1))
                .mpt(new M().time(1).hit(2, 20, -40, 40, 20).opt1(0).dmg(20))
                .mpt(new M().time(30));
            A[] dd = new A[25]; for (int i = 0; i < 25; i++) dd[i] = new A().mpt(new M().time(30));
            dd[0] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
            Dac dA = dac(aa), dD = dac(dd), dFx = dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)));
            BattleSim lvA = new BattleSim(dA, ca1, ca1.moves[0], false, dD, dFx, gl, 30, 0, 0);
            lvA.setOpponentChar(cd1);
            for (int i = 0; i < 4; i++) lvA.step();
            check("dano com ataque, defesa e escala de combo (150*20/100=30; *90/100=27; 50% = 13)", lvA.lastDamage(), 13);
            check("vida do oponente", lvA.lifeOpponent(), 87);
            check("combo conta quando o efeito e Ano 0/1", lvA.comboCount(), 1);
            aa[40] = new A().mpt(new M().time(1)).mpt(new M().time(1).hit(2, 20, -40, 40, 20).opt1(0).dmg(255)).mpt(new M().time(30));
            BattleSim lvK = new BattleSim(dac(aa), ca1, ca1.moves[0], false, dD, dFx, gl, 30, 0, 0);
            lvK.setOpponentChar(cd1);
            for (int i = 0; i < 4; i++) lvK.step();
            check("KO: vida zerada", lvK.lifeOpponent(), 0);
            check("KO: dano limitado a vida restante", lvK.totalDamage(), 100);
            aa[40] = new A().mpt(new M().time(1).hit(32, 0, 0, 1, 1).opt1(0).dmg(30)).mpt(new M().time(5));
            BattleSim lvS = new BattleSim(dac(aa), ca1, ca1.moves[0], false, dD, dFx, gl, 30, 0, 0);
            lvS.setOpponentChar(cd1);
            lvS.step();
            check("auto-dano flag 32", lvS.lifeAttacker(), 70);
        }

        // ---- trava no modo ANO (golpe generico cujo ANO inicial e o de uma linha 9-12)
        {
            byte[] mv = new byte[48 * 13];
            mv[9 * 48 + 2] = 40;
            CharData chN = chr(mv, new byte[][] {});
            A[] na = new A[45];
            for (int i = 0; i < 45; i++) na[i] = new A().mpt(new M().time(5));
            BattleSim n1 = new BattleSim(dac(na), chN, CharData.blank(40), false, defDac, fxDac, g, 300, 0, 0);
            n1.setSpecialType(-1);
            check("trava no modo ANO", n1.cinematicActive(), true);
            BattleSim n2 = new BattleSim(dac(na), chN, CharData.blank(41), false, defDac, fxDac, g, 300, 0, 0);
            n2.setSpecialType(-1);
            check("ANO comum sem trava", n2.cinematicActive(), false);
        }

        // ---- CHAR OBJ: tamanho do corpo (HDAT 3) e gravacao/leitura no 000.bin.txt
        {
            CharData cb = chr(move(new int[]{2, 40}), new byte[][] {});
            cb.setBody(61, 90);
            check("corpo: largura par", cb.bodyWidth() + "/" + cb.halfWidth + "/" + cb.bodyHeight(), "60/30/90");
            String txt = "x {\n  $STATUS_BASE_E_FISICA:{\n    $LARGURA: 10,\n    $ALTURA: 20,\n    $OUTRO: 1\n  },\n  $ALTURA: 7\n}";
            String out = Saver.patchBody(txt, cb);
            check("patchBody", out.contains("$LARGURA: 30,") && out.contains("$ALTURA: 90,") && out.contains("$ALTURA: 7"), true);
            java.io.File tf = java.io.File.createTempFile("bin", ""); tf.deleteOnExit();
            java.io.File tt = new java.io.File(tf.getPath() + ".txt"); tt.deleteOnExit();
            java.io.FileOutputStream fo = new java.io.FileOutputStream(tt); fo.write(out.getBytes("UTF-8")); fo.close();
            CharData c2 = chr(move(new int[]{2, 40}), new byte[][] {});
            CharAssets.applyBinTxt(c2, tf);
            check("corpo lido do .txt", c2.bodyWidth() + "/" + c2.bodyHeight(), "60/90");
        }

        // ---- cutscene da flag 20 (task 996, HDAT 13)
        {
            A[] ca = new A[45];
            for (int i = 0; i < 45; i++) ca[i] = new A().mpt(new M().time(1));
            ca[40] = new A().mpt(new M().time(10).hit(20, 5, -10, 0, 0)).mpt(new M().time(20));
            A[] cf = new A[30];
            for (int i = 0; i < 30; i++) cf[i] = new A().mpt(new M().time(50));
            byte[][] tt = new byte[40][]; int[] cvc = new int[40], cvr = new int[40];
            for (int i = 0; i < 40; i++) tt[i] = new byte[0];
            tt[4] = move(new int[]{2, 40}); cvc[4] = 48; cvr[4] = 1;
            Buf ev = new Buf();
            int[] row = {0, 1, 0, 20, 21, 0, 1, 0};
            for (int v : row) ev.u16(v);
            tt[13] = ev.get(); cvc[13] = 8; cvr[13] = 1;
            CharData chV = CharData.read(hdat(tt, cvc, cvr));
            BattleSim v1 = new BattleSim(dac(ca), chV, chV.moves[0], false, defDac, dac(cf), g, 300, 0, 0);
            v1.step(); v1.step();
            check("cutscene criada", v1.cutsceneCount(), 1);
            check("cutscene vira camada", nl(v1), 3);
            for (int i = 0; i < 12; i++) v1.step();
            check("cutscene termina por sync", v1.cutsceneCount(), 0);
            BattleSim.cutscenes = false;
            BattleSim v2 = new BattleSim(dac(ca), chV, chV.moves[0], false, defDac, dac(cf), g, 300, 0, 0);
            v2.step();
            check("cutscene desligada", v2.cutsceneCount(), 0);
            BattleSim.cutscenes = true;
            // cutscene presa a camera (cam 2): fica no canto da tela JA rolada, sem atraso de um tick
            A[] csa = ca.clone();
            csa[40] = new A().mpt(new M().time(100).speedX(20 * 65536).hit(20, 0, 0, 0, 0)).mpt(new M().time(20));
            Buf ev2 = new Buf();
            int[] row2 = {0, 0, 0, 20, 21, 2, 0, 0};
            for (int v : row2) ev2.u16(v);
            byte[][] tt2 = tt.clone(); tt2[13] = ev2.get();
            CharData chCam = CharData.read(hdat(tt2, cvc, cvr));
            BattleSim.edgeMode = 1;
            BattleSim scam = new BattleSim(dac(csa), chCam, chCam.moves[0], false, defDac, dac(cf), g, 300, 0, 0);
            boolean lockOk = true; int moved = 0;
            int left0 = scam.screenLeft();
            for (int i = 0; i < 59; i++) {
                scam.step();
                for (BattleSim.Layer l : scam.layers())
                    if (l.owner == BattleSim.OWNER_EFFECT && l.sim.root() != null) {
                        lockOk &= l.sim.root().x == scam.screenLeft() && l.sim.root().y == -15728640;
                        moved++;
                    }
            }
            check("camera rolou durante a cutscene", scam.screenLeft() != left0, true);
            check("cutscene da camera acompanha a tela sem atraso", lockOk && moved > 0, true);
        }

        // ---- travamento cinematico (md 923/926)
        {
            A[] cz = new A[45];
            for (int i = 0; i < 45; i++) cz[i] = new A().mpt(new M().time(5)).mpt(new M().time(5));
            CharData chZ = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim.cinematic = true;
            BattleSim z1 = new BattleSim(dac(cz), chZ, chZ.moves[0], false, defDac, fxDac, g, 300, 0, 0);
            z1.setSpecialType(9);
            check("trava ativa", z1.cinematicActive(), true);
            for (int i = 0; i < 100; i++) z1.step();
            check("atacante parado na trava", z1.attacker().root().pat, 0);
            for (int i = 0; i < 40; i++) z1.step();
            check("trava acabou", z1.cinematicActive(), false);
            check("atacante andou depois", z1.attacker().root().pat > 0, true);
            z1.setSpecialType(1);
            check("golpe 1 sem trava", z1.cinematicActive(), false);
            BattleSim.cinematic = false;
            z1.setSpecialType(9);
            check("trava desligada", z1.cinematicActive(), false);
            BattleSim.cinematic = true;
        }

        // ---- agarrao (ATK_FLAGS 8 / 128): o atacante vai para o oponente no fim do ANO inicial ou num frame com 512
        for (int mode = 0; mode < 5; mode++) {
            int fl = mode == 3 ? 128 : mode == 4 ? 0 : 8;
            boolean with512 = mode == 0;
            CharData cg = chr(move(new int[]{0, fl}, new int[]{2, 40}), new byte[][] {});
            A[] gAnos = new A[43];
            for (int i = 0; i < 43; i++) gAnos[i] = new A().mpt(new M().time(1));
            M f0 = new M().time(5);
            if (with512) f0.optFlag(512);
            gAnos[40] = new A().mpt(f0).mpt(new M().time(5));
            gAnos[41] = new A().mpt(new M().time(30));
            BattleSim gs = new BattleSim(dac(gAnos), cg, cg.moves[0], false, defDac, fxDac, g, 100, 0, 0);
            int pulledAt = -1;
            for (int t = 0; t < 40 && pulledAt < 0; t++) {
                gs.step();
                if (gs.attacker().root() != null && gs.attacker().root().ano.index == 41) pulledAt = gs.ticks();
            }
            if (mode == 0) { check("agarrao 8 com frame 512 puxa logo", pulledAt > 0 && pulledAt <= 2, true);
                int ox = 0; try { java.lang.reflect.Field fo = BattleSim.class.getDeclaredField("oppX"); fo.setAccessible(true); ox = fo.getInt(gs); } catch (Exception ex) { }
                check("agarrao: atacante vai para o oponente (distancia 0; a separacao de corpos do md 19 os afasta uma largura de corpo)", Math.abs(gs.attacker().root().x - ox) >> 16, 60); }
            else if (mode == 1) check("agarrao 8 sem 512 puxa no fim do ANO (10 ticks)", pulledAt >= 9 && pulledAt <= 11, true);
            else if (mode == 2) check("agarrao 8 sem acertar tambem puxa", pulledAt > 0, true);
            else if (mode == 3) check("agarrao 128 sem hit nao puxa", pulledAt, -1);
            else check("sem flag de agarrao nao puxa", pulledAt, -1);
        }
        {   // flag 128: so puxa se o golpe acertou e o oponente esta em reacao
            CharData c128 = chr(move(new int[]{0, 128}, new int[]{2, 40}), new byte[][] {});
            A[] hA = new A[43];
            for (int i = 0; i < 43; i++) hA[i] = new A().mpt(new M().time(1));
            hA[40] = new A().mpt(new M().time(2)).mpt(new M().time(3).hit(2, 20, -40, 40, 20).opt1(3).optFlag(512)).mpt(new M().time(6));
            hA[41] = new A().mpt(new M().time(30));
            BattleSim hs128 = new BattleSim(dac(hA), c128, c128.moves[0], false, defDac, fxDac, g, 30, 0, 0);
            int pull128 = -1;
            for (int zq = 0; zq < 60 && pull128 < 0; zq++) {
                hs128.step();
                if (System.getenv("DBG") != null) { try { java.lang.reflect.Field f1 = BattleSim.class.getDeclaredField("inDamage"); f1.setAccessible(true); java.lang.reflect.Field f2 = BattleSim.class.getDeclaredField("hitConfirmed"); f2.setAccessible(true); System.out.println("t" + hs128.ticks() + " ano=" + hs128.attacker().root().ano.index + " pat=" + hs128.attacker().root().pat + " done=" + hs128.attacker().root().isDone() + " inDmg=" + f1.getBoolean(hs128) + " conf=" + f2.getBoolean(hs128) + " " + hs128.lastHit()); } catch (Exception ex) { } }
                if (hs128.attacker().root() != null && hs128.attacker().root().ano.index == 41) pull128 = hs128.ticks();
            }
            check("agarrao 128 puxa depois de acertar", pull128 > 0, true);
            BattleSim h13 = new BattleSim(dac(hA), c128, c128.moves[0], false, defDac, fxDac, g, 30, 0, 0);
            h13.setSpecialType(13);
            boolean p13 = false;
            for (int zq = 0; zq < 60 && !p13; zq++) { h13.step(); p13 = h13.attacker().root() != null && h13.attacker().root().ano.index == 41; }
            check("agarrao 128 nao funciona do golpe 13 em diante", p13, false);
        }
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
        System.exit(fails == 0 ? 0 : 1);
    }
}
