package com.zue.attackeditor;

import java.io.File;
import static com.zue.attackeditor.BattleTest.*;

/** Leitura so de TXT: 000.bin.txt real (HDAT 3, 4, 7, 13, 14-33), 000.dac.txt real (todas as ANOs), CNV, gamedata sintetica e erros. */
public class BinTxtTest {
    static File fixture(String n) {
        File f = new File("../app/test/fixtures/" + n);
        if (!f.isFile()) f = new File("app/test/fixtures/" + n);
        return f.isFile() ? f : null;
    }

    public static void main(String[] args) throws Exception {
        File fb = fixture("char.bin.txt"), fd = fixture("char.dac.txt"), fc = fixture("char.cnv.txt");
        if (fb != null) {
            String txt = TxtFiles.read(fb);
            check("detecta o formato BIN_CNV_", BinTxt.isBin(txt), true);
            CharData cd = CharData.fromTxt(txt);
            check("19 golpes", cd.moves.length, 19);
            check("HDAT 3: largura 28 (byte 56) / pode voar / altura 64 / agarre 50", cd.bodyWidth() + "," + cd.flies + "," + cd.bodyHeight() + "," + cd.pullDistance() + "," + cd.halfWidth, "56,true,64,50,28");
            check("HDAT 3: vida 100, ATK 1000/10, DEF 0", cd.hp(0) >= 100 || cd.hp(0) == 100, true);
            // reacoes: a REACAO_DANO_0 tem 4 passos, a 1 tem 5, 2..5 tem 2, a 6 e 7 tem 1
            check("reacoes 0..7 (passos)", cd.reaction(0).rows + "," + cd.reaction(1).rows + "," + cd.reaction(2).rows + "," + cd.reaction(6).rows + "," + cd.reaction(7).rows, "4,5,2,1,1");
            check("reacoes 13..19 vazias (HDAT 27..33 sem dados)", ReactionSlots.isEmpty(cd.reaction(13)) && ReactionSlots.isEmpty(cd.reaction(19)), true);
            check("reacao 12 tem 4 passos", cd.reaction(12).rows, 4);
            check("HDAT 13: 22 eventos", cd.eventRows(), 22);
            // o 1o golpe real bate com o texto
            int[] b = Saver.findBlock(txt, "GOLPE_0");
            CharData.Move m0 = new CharData.Move();
            DacText.parseMove(txt.substring(b[0], b[2] + 1), m0);
            check("golpe 0 igual ao parseMove do bloco", m0.flags + "," + m0.animInicial + "," + m0.pousoErrar, cd.moves[0].flags + "," + cd.moves[0].animInicial + "," + cd.moves[0].pousoErrar);
            // ida e volta com o Saver: trocar o golpe e ler de novo
            CharData.Move edited = cd.moves[2];
            edited.animInicial = 123;
            boolean[] f = new boolean[1];
            String patched = Saver.patchMove(txt, edited, 2, f);
            check("patchMove achou o bloco", f[0], true);
            check("ida e volta: o golpe editado volta com ANIM_INICIAL 123", CharData.fromTxt(patched).moves[2].animInicial, 123);
        } else System.out.println("(sem fixtures: char.bin.txt)");

        if (fd != null) {
            Dac dac = Dac.fromTxt(TxtFiles.read(fd));
            check("DAC: 368 ANOs ($ANO_367 e a ultima)", dac.size(), 368);
            check("ANO 0 presente com 5 frames e 1 link", dac.getAno(0).present + "," + dac.getAno(0).mpts.length + "," + dac.getAno(0).links.length, "true,5,1");
            check("ANO 0 frame 0: time 1, img 0, MID (-30,-119)", dac.getAno(0).mpts[0].time + "," + dac.getAno(0).mpts[0].image + "," + dac.getAno(0).mpts[0].midX + "," + dac.getAno(0).mpts[0].midY, "1,0,-30,-119");
            check("ANO 367 com 1 frame (img 96)", dac.getAno(367).mpts.length + "," + dac.getAno(367).mpts[0].image, "1,96");
            check("sem avisos de leitura", dac.getWarnings().toString(), "[]");
        } else System.out.println("(sem fixtures: char.dac.txt)");

        if (fc != null) {
            Cnv c = Cnv.fromTxt(TxtFiles.read(fc), true);
            check("CNV: SPR_0 e SPR_1 lidos (folha 2)", c != null && c.byImage(0) != null && c.byImage(0).source == 2 && c.byImage(1).source == 2, true);
        }

        // gamedata sintetica no formato BIN_CNV_ (reacoes GD, combo, IA)
        StringBuilder g = new StringBuilder("BIN_CNV_ {$COUNT: 40,\n");
        g.append("   $HDAT_2:{$info:{$COL: 2, $ROW: 3, $SZ: &00000006},\n      $DISTANCIAS_IA:{\n         $LINHA_0: [10, 11],\n         $LINHA_1: [20, 21],\n         $LINHA_2: [30, 31],\n      },\n   },\n");
        g.append("   $HDAT_5:{$info:{$COL: 3, $ROW: 2, $SZ: &0000000C},\n      $MULTIPLICADOR_COMBO:{\n         $LINHA_0: [100, 90, 80],\n         $LINHA_1: [100, -5, 50],\n      },\n   },\n");
        g.append("   $HDAT_10:{$info:{$COL: 14, $ROW: 2, $SZ: &0000001C},\n      $REACAO_DANO_GD_0:{\n         $FR_0: {$DUR_C: 5, $DUR_A: 6, $ANO: 7, $XSPEED: -3, $YSPEED: 0, $XACCEL: 0, $YACCEL: 0, $XSPEED_A: 0, $YSPEED_A: 0, $XACCEL_A: 0, $YACCEL_A: 0, $COMP: 13, $WALL: 2, $VOZ: 4},\n");
        g.append("         $FR_1: {$DUR_C: 255, $DUR_A: 255, $ANO: -8, $XSPEED: 0, $YSPEED: 0, $XACCEL: 0, $YACCEL: 0, $XSPEED_A: 0, $YSPEED_A: 0, $XACCEL_A: 0, $YACCEL_A: 0, $COMP: 0, $WALL: 0, $VOZ: 0},\n      },\n   },\n");
        for (int i = 11; i < 40; i++) g.append("   $HDAT_" + i + ":{$info:{$COL: 14, $ROW: 1, $SZ: &0000000E},\n      $REACAO_DANO_GD_" + (i - 10) + ":{\n         $FR_0: {$DUR_C: 1, $DUR_A: 1, $ANO: " + i + ", $COMP: 0, $WALL: 0},\n      },\n   },\n");
        g.append("}\n");
        GameData gd = GameData.fromTxt(g.toString(), "gamedata.dac.txt");
        check("gamedata TXT: reacao 0 com 2 passos, ANO 7, COMP 13, WALL 2, X -3", gd.reaction(0).rows + "," + gd.reaction(0).s8(0, 2) + "," + gd.reaction(0).u8(0, 11) + "," + gd.reaction(0).u8(0, 12) + "," + gd.reaction(0).s8(0, 3), "2,7,13,2,-3");
        check("gamedata TXT: ANO negativo e 255", gd.reaction(0).s8(1, 2) + "," + gd.reaction(0).u8(1, 0), "-8,255");
        check("gamedata TXT: reacao 29 e a 39a tabela", gd.reaction(29).rows + "," + gd.reaction(29).s8(0, 2), "1,39");
        check("gamedata TXT: combo (short, -5)", gd.comboScale(1), -5);
        check("gamedata TXT: distancia da IA linha 1 col 1", gd.cpuDist(1, true), 21);
        check("nome da fonte", gd.sourceName, "gamedata.dac.txt");

        // ---- verificacao cruzada: os bytes do BinTxt contra os do BinBuilder REAL do compilador (gerados offline: *.hdat)
        String[][] pares = {{"char.bin.txt", "char.hdat"}, {"gamedata.dac.txt", "gamedata.hdat"}};
        for (String[] par : pares) {
            File ft = fixture(par[0]), fh = fixture(par[1]);
            if (ft == null || fh == null) { System.out.println("(sem fixtures: " + par[0] + ")"); continue; }
            byte[] mine = BinTxt.compile(TxtFiles.read(ft));
            byte[] real = java.nio.file.Files.readAllBytes(fh.toPath());
            HdatTable tm = HdatTable.parse(mine), tr = HdatTable.parse(real);
            boolean isChar = par[0].startsWith("char");
            StringBuilder diff = new StringBuilder(), appDiff = new StringBuilder();
            for (int h = 0; h < Math.max(tm.size(), tr.size()); h++) {
                boolean same = tm.cols(h) == tr.cols(h) && tm.rows(h) == tr.rows(h) && java.util.Arrays.equals(tm.bytes(h), tr.bytes(h));
                if (same) continue;
                diff.append(h).append(' ');
                if (!isChar || h == 3 || h == 4 || h == 7 || h == 13 || (h >= 14 && h <= 33)) appDiff.append(h).append(' ');
            }
            // os HDATs que o app edita (char: 3, 4, 7, 13, 14-33; gamedata: todos os que decodifica) saem IGUAIS aos do BinBuilder real; os outros (textos, cartas...) o app nao decodifica
            check(par[0] + ": HDATs que o app usa iguais ao BinBuilder real (diferentes: " + appDiff.toString().trim() + ")", appDiff.length() == 0, true);
            if (!isChar) check(par[0] + ": arquivo inteiro igual byte a byte", java.util.Arrays.equals(mine, real), true);
            else System.out.println("(char.bin.txt: HDATs que o app nao decodifica e ficam vazios na memoria: " + diff.toString().trim() + ")");
        }
        File fgd = fixture("gamedata.dac.txt");
        if (fgd != null) {
            GameData real = GameData.fromTxt(TxtFiles.read(fgd), "gamedata.dac.txt");
            check("gamedata do extrator real: IA perto/medio (linhas nomeadas)", real.cpuDist(1, false) + "," + real.cpuDist(1, true) + "," + real.cpuDist(2, true), "20,21,31");
            check("gamedata do extrator real: escala de combo (short, 2a linha, 2o combo = -5)", real.comboScale(1) + "," + real.comboScale(0), "-5,90");
            check("gamedata do extrator real: 30 reacoes, a 5a (t=5) com COMP 11", real.reaction(5).u8(0, 11) + "," + real.reaction(0).rows + "," + real.reaction(29).rows, "11,1,3");
        }

        // GameData.load: pasta gamedata (qualquer caixa) com *.dac.txt de nome qualquer; nenhum binario existe
        java.io.File root = java.nio.file.Files.createTempDirectory("gdroot").toFile();
        java.io.File gdir = new java.io.File(root, "GameData");
        gdir.mkdirs();
        boolean miss = false;
        try { GameData.load(root); } catch (TxtFiles.Missing e) { miss = e.getMessage().contains("*.dac.txt"); }
        check("sem gamedata em TXT: erro claro dizendo qual TXT falta", miss, true);
        java.nio.file.Files.write(new java.io.File(gdir, "gamedata").toPath(), new byte[]{1, 2, 3, 4});     // um binario ao lado nao conta
        java.nio.file.Files.write(new java.io.File(gdir, "meu_mod.DAC.txt").toPath(), g.toString().getBytes("UTF-8"));
        GameData lg = GameData.load(root);
        check("gamedata lida de meu_mod.DAC.txt (nome qualquer, caixa mista)", lg.sourceName + "," + lg.reaction(0).rows + "," + lg.cpuDist(1, true), "meu_mod.DAC.txt,2,21");

        // erros claros
        boolean t1 = false;
        try { BinTxt.compile("DAC_ACT_ { $ANO_0: {} }"); } catch (java.io.IOException e) { t1 = e.getMessage().contains("$COUNT"); }
        check("texto sem $COUNT: erro claro", t1, true);
        boolean t2 = false;
        try { Dac.fromTxt("BIN_CNV_ {$COUNT: 1}"); } catch (java.io.IOException e) { t2 = e.getMessage().contains("$ANO_n"); }
        check("DAC sem ANOs: erro claro", t2, true);
        check("isBin: DAC e CNV nao sao", BinTxt.isBin("DAC_ACT_ {\n $ANO_0: {}\n}") + "," + BinTxt.isBin("CNV_TXT_ {\n}"), "false,false");
    }
}
