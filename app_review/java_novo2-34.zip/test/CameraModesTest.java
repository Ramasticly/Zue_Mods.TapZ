package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Modos de camera compartilhados (principal e previa da reacao). */
public class CameraModesTest {
    public static void main(String[] args) throws Exception {
        A[] atk = new A[45];
        for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(5).img(1));
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).img(1));
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20}) });
        BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4))), g, 120, 0, 0);
        check("NORMAL nao enquadra nada", CameraModes.bounds(CameraModes.NORMAL, s) == null && CameraModes.bounds(1, null) == null, true);
        float[] t = CameraModes.bounds(CameraModes.SCREEN, s);
        check("TELA: 480 x 320 a partir de screenLeft / screenTop", (t[2] - t[0]) + ":" + (t[3] - t[1]) + ":" + (t[0] == s.screenLeft() / 65536f) + ":" + (t[1] == s.screenTop() / 65536f), "480.0:320.0:true:true");
        float[] c = CameraModes.bounds(CameraModes.CHAR, s);
        float ax = s.attackerX(), ox = s.opponentX();
        check("CHAR: contem os dois personagens com 50 px de margem + corpo (30)", c[0] == Math.min(ax, ox) - 80f && c[2] == Math.max(ax, ox) + 80f && c[3] == 30f && c[1] < 0f, true);
        check("rotulos do botao", CameraModes.label(0) + "|" + CameraModes.label(1) + "|" + CameraModes.label(2), "CENTRO: NORMAL|CENTRO: TELA|CENTRO: CHAR");
        System.out.println("CameraModesTest fails=" + fails);
    }
}
