package com.zue.attackeditor;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import static com.zue.attackeditor.BattleTest.*;

/** SpriteBlock (marcadas seguidas) e Centralize (zoom pela altura do Parado, MID com os pes no chao). */
public class CenterTest {
    static Dac dac(Ano... anos) throws Exception {
        java.lang.reflect.Constructor<Dac> c = Dac.class.getDeclaredConstructor(Ano[].class, java.util.List.class);
        c.setAccessible(true);
        return c.newInstance((Object) anos, new java.util.ArrayList<String>());
    }

    static Ano.Mpt mpt(int image, int zoom) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.time = 2; m.flags = 0x20;
        if (zoom != 100) { m.flags |= 0x80; m.xZoom = zoom; m.yZoom = zoom; }
        m.normalize();
        return m;
    }

    static TreeSet<Integer> set(Integer... v) { return new TreeSet<Integer>(java.util.Arrays.asList(v)); }

    public static void main(String[] args) throws Exception {
        // ---- bloco de marcadas seguidas
        check("vazio: sem bloco", SpriteBlock.contiguous(set()) == null, true);
        check("uma so: bloco de 1", java.util.Arrays.toString(SpriteBlock.contiguous(set(7))), "[7, 1]");
        check("seguidas 3,4,5: bloco 3 + 3", java.util.Arrays.toString(SpriteBlock.contiguous(set(5, 3, 4))), "[3, 3]");
        check("com espaco (3,4,6): sem bloco", SpriteBlock.contiguous(set(3, 4, 6)) == null, true);
        check("0 e 1 seguidas", java.util.Arrays.toString(SpriteBlock.contiguous(set(0, 1))), "[0, 2]");

        // ---- Centralizar
        Dac d = dac(new Ano(0, true, 0, 0, null, new Ano.Mpt[]{mpt(0, 150), mpt(1, 100)}), new Ano(1, true, 0, 0, null, new Ano.Mpt[]{mpt(2, 100), mpt(3, 100), mpt(2, 100)}));
        final int[][] size = {{40, 80}, {30, 60}, {20, 40}, {50, 50}};          // logicos de cada imagem
        Centralize.Sizes sz = new Centralize.Sizes() { public int[] logical(int i) { return i >= 0 && i < size.length ? size[i] : null; } };
        check("altura de referencia = altura da 1a sprite do Parado x o zoom dela (80 x 150% = 120)", Centralize.refHeight(d, sz), 120.0);
        check("sem Parado: -1", Centralize.refHeight(dac(), sz) + "," + Centralize.refHeight(null, sz), "-1.0,-1.0");
        Centralize.Plan p = Centralize.plan(120.0, 20, 40);
        check("sprite 20x40: zoom 300%, MID (-30, -120): centrada e com os pes no chao", p.zoom + "," + p.midX + "," + p.midY, "300,-30,-120");
        Centralize.Plan q = Centralize.plan(120.0, 50, 50);
        check("sprite 50x50: zoom 240%, MID (-60, -120)", q.zoom + "," + q.midX + "," + q.midY, "240,-60,-120");
        check("sprite maior que a referencia: zoom diminui (80 -> 120: 150%)", Centralize.plan(120.0, 40, 80).zoom, 150);
        check("zoom nunca abaixo de 1", Centralize.plan(1.0, 10, 100000).zoom >= 1, true);
        check("a altura na tela fica igual a de referencia", Math.abs(p.zoom / 100.0 * 40 - 120.0) < 1e-9 && -p.midY == 120, true);

        Map<Integer, Centralize.Plan> plans = new HashMap<Integer, Centralize.Plan>();
        plans.put(Integer.valueOf(2), p);
        int[] cnt = new int[1];
        TreeSet<Integer> ch = Centralize.applyToFrames(d, plans, cnt);
        check("so os Frames da sprite 2 mudam (2 frames na ANO 1)", cnt[0] + ":" + ch, "2:[1]");
        Ano.Mpt f = d.getAno(1).mpts[0], other = d.getAno(1).mpts[1];
        SpriteDefaults.Def r = SpriteDefaults.read(f);
        check("Frame centralizado: zoom 300 X e Y, MID (-30,-120)", r.zx == 300 && r.zy == 300 && r.midX == -30 && r.midY == -120, true);
        check("os outros Frames nao mudam", SpriteDefaults.read(other).isNeutral() && other.image == 3, true);
        // rotacao, alpha e flip do Frame ficam
        Ano.Mpt rot = mpt(2, 100);
        rot.flags |= 0x80; rot.rot = 25; rot.alphaRaw = 40; rot.xZoom = 100; rot.yZoom = 100; rot.normalize();
        Dac d2 = dac(new Ano(0, true, 0, 0, null, new Ano.Mpt[]{rot}));
        Centralize.applyToFrames(d2, plans, null);
        SpriteDefaults.Def r2 = SpriteDefaults.read(d2.getAno(0).mpts[0]);
        check("rotacao 25 e alpha 40 continuam", r2.rot == 25 && r2.alpha == 40 && r2.zx == 300, true);
        // padrao
        SpriteDefaults.Def base = new SpriteDefaults.Def();
        base.rot = 5; base.flipH = true;
        SpriteDefaults.Def nd = Centralize.toDef(base, p);
        check("padrao: zoom e MID da conta, rotacao e flip da base", nd.zx == 300 && nd.zy == 300 && nd.midX == -30 && nd.midY == -120 && nd.rot == 5 && nd.flipH, true);
    }
}
