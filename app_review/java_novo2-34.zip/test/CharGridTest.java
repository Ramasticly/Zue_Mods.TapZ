package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Grade de escolha de personagens: nomes, ANO da previa (76, senao 0), destaque do atual, rolagem inicial e quais previas descarregar. */
public class CharGridTest {
    public static void main(String[] args) throws Exception {
        List<File> dirs = Arrays.asList(new File("/x/char00"), new File("/x/char01"), new File("/x/char07"));
        List<String> names = CharGrid.names(dirs);
        check("nomes das pastas", names.toString(), "[char00, char01, char07]");
        check("nome -> indice", CharGrid.indexOf(names, "char07") + ":" + CharGrid.indexOf(names, "char99"), "2:-1");
        check("o atual vem destacado", CharGrid.isCurrent(1, 1) + ":" + CharGrid.isCurrent(0, 1), "true:false");
        check("rotulo do atual", CharGrid.label("char01", true), "✓ char01  (atual)");
        check("rotulo dos outros", CharGrid.label("char01", false), "char01");

        // ANO da previa
        A[] a = new A[90];
        for (int i = 0; i < 90; i++) a[i] = new A();
        a[0].mpt(new M().time(5));
        check("sem ANO 76 cai para a 0", CharGrid.previewAno(dac(a)), 0);
        a[76].mpt(new M().time(5));
        check("com ANO 76 usa a 76", CharGrid.previewAno(dac(a)), 76);
        A[] e = new A[90];
        for (int i = 0; i < 90; i++) e[i] = new A();
        check("sem 76 nem 0: sem previa", CharGrid.previewAno(dac(e)), -1);
        check("sem DAC: sem previa", CharGrid.previewAno(null), -1);
        A[] small = new A[10];
        for (int i = 0; i < 10; i++) small[i] = new A();
        small[0].mpt(new M().time(5));
        check("DAC pequeno (so ate a 9): usa a 0", CharGrid.previewAno(dac(small)), 0);

        // rolagem inicial: a linha do atual com uma de folga
        check("rolagem: atual no inicio = 0", CharGrid.scrollTo(0, 30) + ":" + CharGrid.scrollTo(2, 30), "0:0");
        check("rolagem: atual na linha 5 mostra a linha 4", CharGrid.scrollTo(15, 30), 12);
        check("rolagem: indice invalido = 0", CharGrid.scrollTo(-1, 30) + ":" + CharGrid.scrollTo(99, 30), "0:0");

        // descarregar previas
        List<Boolean> att = new ArrayList<Boolean>();
        for (int i = 0; i < CharGrid.KEEP; i++) att.add(Boolean.TRUE);
        check("dentro do limite nada sai", CharGrid.evict(att), -1);
        att.add(Boolean.FALSE);
        check("passou do limite: sai a mais antiga fora da tela", CharGrid.evict(att), CharGrid.KEEP);
        att.set(3, Boolean.FALSE);
        check("a mais antiga fora da tela, nao a mais antiga", CharGrid.evict(att), 3);
        List<Boolean> all = new ArrayList<Boolean>();
        for (int i = 0; i < CharGrid.KEEP + 2; i++) all.add(Boolean.TRUE);
        check("tudo na tela: nada sai (nunca libera o que se ve)", CharGrid.evict(all), -1);
        System.out.println("CharGridTest fails=" + fails);
    }
}
