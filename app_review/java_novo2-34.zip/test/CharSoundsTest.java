package com.zue.attackeditor;

import java.io.File;
import static com.zue.attackeditor.BattleTest.*;

/** Sons do personagem: vazio por conteudo (nao por tamanho), excluir = mutar, vazios no fim, numeracao e cache. */
public class CharSoundsTest {
    static File tmp() throws Exception {
        File d = File.createTempFile("snd", "");
        d.delete();
        d.mkdirs();
        return d;
    }

    static byte[] tone(int n) {
        short[] p = new short[n];
        for (int i = 0; i < n; i++) p[i] = (short) (i % 2 == 0 ? 3000 : -3000);
        return AudioConvert.encode(p);
    }

    static void del(File d) { File[] f = d.listFiles(); if (f != null) for (File x : f) x.delete(); d.delete(); }

    public static void main(String[] args) throws Exception {
        File dir = tmp();
        try {
            // vazio por CONTEUDO: um som curto de verdade (100 amostras = 244 bytes, bem abaixo dos 926 de antes) nao e vazio
            File shortTone = new File(dir, "002.wav");
            SpriteLib.writeAtomic(shortTone, tone(100));
            check("som curto com conteudo NAO e vazio", CharSounds.isEmpty(shortTone), false);
            File silent = new File(dir, "003.wav");
            SpriteLib.writeAtomic(silent, AudioConvert.silentWav());
            check("silencio gerado e vazio", CharSounds.isEmpty(silent), true);
            File hdrOnly = new File(dir, "004.wav");
            SpriteLib.writeAtomic(hdrOnly, new byte[44]);
            check("so cabecalho e vazio", CharSounds.isEmpty(hdrOnly), true);
            File zeros = new File(dir, "005.wav");
            SpriteLib.writeAtomic(zeros, AudioConvert.encode(new short[20000]));
            check("tudo zero (grande) e vazio", CharSounds.isEmpty(zeros), true);
            short[] late = new short[20000];
            late[19999] = 5;
            File lateF = new File(dir, "006.wav");
            SpriteLib.writeAtomic(lateF, AudioConvert.encode(late));
            check("uma amostra diferente de zero no fim do arquivo: nao vazio", CharSounds.isEmpty(lateF), false);

            // ids dos vazios (som do jogo = 80 + indice na ordem dos nomes): 002 tom, 003 silencio, 004 vazio, 005 zeros, 006 tom
            check("emptySounds: 81, 82, 83", new java.util.TreeSet<Integer>(CharSounds.emptySounds(dir)).toString(), "[81, 82, 83]");

            // excluir = mutar: continua na lista, vira vazio e o cache nao segura o valor antigo
            check("antes de mutar: nao vazio", CharSounds.isEmpty(shortTone), false);
            CharSounds.mute(shortTone);
            check("depois de mutar: vazio (cache esquecido)", CharSounds.isEmpty(shortTone), true);
            check("o arquivo continua na lista", CharSounds.list(dir).length, 5);
            CharSounds.replaceBytes(shortTone, tone(200));
            check("substituir por um tom: deixa de ser vazio", CharSounds.isEmpty(shortTone), false);

            // vazios no FIM sao apagados; os do meio ficam
            int n = CharSounds.trimTrailing(dir);
            check("trimTrailing: o ultimo (006) tem som, nada a apagar", n, 0);
            CharSounds.mute(lateF);
            check("apos mutar o ultimo: apaga so os vazios finais (006, 005, 004, 003)", CharSounds.trimTrailing(dir), 4);
            check("sobra 002", CharSounds.list(dir).length + ":" + CharSounds.list(dir)[0].getName(), "1:002.wav");

            // numeracao do proximo: depois do maior NNN de png/wav
            SpriteLib.writeAtomic(new File(dir, "000.png"), new byte[]{1});
            SpriteLib.writeAtomic(new File(dir, "001.png"), new byte[]{1});
            check("nextNumber = maior + 1", CharSounds.nextNumber(dir), 3);
            File added = CharSounds.addBytes(dir, tone(50));
            check("addBytes cria 003.wav no fim", added.getName() + "," + CharSounds.list(dir).length, "003.wav,2");
            check("o novo ja nasce nao vazio", CharSounds.isEmpty(added), false);

            // limite de 20
            for (int i = CharSounds.list(dir).length; i < CharSounds.MAX; i++) CharSounds.addBytes(dir, tone(20));
            boolean threw = false;
            try { CharSounds.addBytes(dir, tone(20)); } catch (java.io.IOException e) { threw = true; }
            check("limite de 20 sons por personagem", threw, true);
        } finally {
            del(dir);
        }
    }
}
