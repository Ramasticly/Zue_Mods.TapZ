package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Aviso da trava cinematica no botao +1 tick: trava o numero do tick, conta o que falta e libera. */
public class CineNoticeTest {
    public static void main(String[] args) throws Exception {
        CineNotice n = new CineNotice();
        check("sem trava: inativo e tick real", n.active() + ":" + n.shownTick(7), "false:7");
        n.afterStep(1, 121);
        check("entrou na trava: ativo, 121 faltam, tick travado em 1", n.active() + ":" + n.left() + ":" + n.shownTick(1), "true:121:1");
        n.afterStep(2, 120);
        n.afterStep(3, 119);
        check("andando na trava: o numero continua no 1", n.shownTick(3) + ":" + n.left(), "1:119");
        n.afterStep(4, 0);
        check("acabou: libera e mostra o tick real", n.active() + ":" + n.shownTick(4), "false:4");
        n.afterStep(10, 5);
        n.clear();
        check("clear (pular / buscar na linha do tempo) libera", n.active() + ":" + n.shownTick(12), "false:12");
        n.afterStep(20, 1);
        check("texto no singular e menciona PULAR e o zoom", n.text().contains("mais 1 tick ") && n.text().contains("PULAR") && n.text().contains("200%"), true);
        n.afterStep(21, 3);
        check("texto no plural", n.text().contains("mais 3 ticks"), true);
        System.out.println("CineNoticeTest fails=" + fails);
    }
}
