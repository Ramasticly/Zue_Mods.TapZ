package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Compensar o zoom da trava: frame 0 de 1 tick em 50 %, o resto na escala original; so nos slots 9-12; liga/desliga; confere na simulacao. */
public class CineZoomCompTest {
    static Ano.Mpt f(int time) { Ano.Mpt m = new Ano.Mpt(); m.flags = 0x20; m.hasTime = true; m.time = time; return m; }

    public static void main(String[] args) throws Exception {
        check("escala = 100 / 200 = 50 %", CineZoomComp.scalePercent(), 50);
        check("so golpes 9 a 12 do HDAT 4", CineZoomComp.applies(9, false) + ":" + CineZoomComp.applies(12, false) + ":" + CineZoomComp.applies(8, false) + ":" + CineZoomComp.applies(13, false) + ":" + CineZoomComp.applies(10, true), "true:true:false:false:false");

        Ano.Mpt[] m = {f(5), f(5), f(3)};
        check("antes: desligado", CineZoomComp.isOn(m), false);
        Ano.Mpt[] on = CineZoomComp.apply(m);
        check("liga: frame 0 dividido (1 tick + 4), total 4 frames", on.length + ":" + FrameTools.ticks(on[0]) + ":" + FrameTools.ticks(on[1]), "4:1:4");
        check("frame 0 em 50 %, o resto na escala normal", on[0].xZoom + ":" + on[0].yZoom + ":" + ((on[1].flags & 0x80) == 0) + ":" + ((on[2].flags & 0x80) == 0), "50:50:true:true");
        check("o tempo total nao muda", FrameTools.ticks(on[0]) + FrameTools.ticks(on[1]) + FrameTools.ticks(on[2]) + FrameTools.ticks(on[3]), 13);
        check("ligado", CineZoomComp.isOn(on), true);
        check("ligar de novo nao muda", CineZoomComp.apply(on) == on, true);
        check("o original nao e alterado", m.length + ":" + ((m[0].flags & 0x80) == 0), "3:true");
        Ano.Mpt[] off = CineZoomComp.remove(on);
        check("desliga: frame 0 volta a escala normal e sem RAZ", off[0].xZoom + ":" + ((off[0].flags & 0x80) == 0) + ":" + CineZoomComp.isOn(off), "100:true:false");

        // frame 0 ja com 1 tick: nao divide
        Ano.Mpt[] one = {f(1), f(4)};
        Ano.Mpt[] on1 = CineZoomComp.apply(one);
        check("frame 0 de 1 tick: nao divide", on1.length + ":" + on1[0].xZoom, "2:50");
        // frame 0 com rotacao: mantem; frame seguinte com zoom 80 => 40
        Ano.Mpt a = f(1); a.flags |= 0x80; a.rot = 30; a.xZoom = 100; a.yZoom = 100;
        Ano.Mpt b = f(4); b.flags |= 0x80; b.xZoom = 80; b.yZoom = 80;
        Ano.Mpt[] r = CineZoomComp.apply(new Ano.Mpt[] {a, b});
        check("rotacao preservada e zoom relativo ao frame seguinte (80 -> 40)", r[0].rot + ":" + r[0].xZoom + ":" + CineZoomComp.isOn(r), "30:40:true");
        Ano.Mpt[] ro = CineZoomComp.remove(r);
        check("desligar mantem a rotacao e volta a 80", ro[0].rot + ":" + ro[0].xZoom + ":" + ((ro[0].flags & 0x80) != 0), "30:80:true");

        // simulacao: sob a trava o atacante aparece em 50 % no frame 0 e em 100 % depois
        A[] atk = new A[41];
        for (int i = 0; i < 41; i++) atk[i] = new A().mpt(new M().time(1));
        atk[40] = new A().mpt(new M().time(5)).mpt(new M().time(5)).mpt(new M().time(5));
        Dac base = dac(atk);
        Ano.Mpt[] comp = CineZoomComp.apply(base.getAno(40).mpts);
        Dac d2 = base.copyWith(40, new Ano(40, true, 0, 0, new Ano.Link[0], comp));
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        BattleSim.cinematic = true;
        BattleSim s = new BattleSim(d2, ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4))), gd(new byte[][] {}), 400, 0, 0);
        s.setSpecialType(9);
        for (int i = 0; i < 20; i++) s.step();
        check("durante a trava: atacante em 50 % e camera em 200 %", s.attacker().root().xZoom + ":" + (s.zoomRect() != null), "50:true");
        while (s.cinematicActive()) s.step();
        for (int i = 0; i < 3; i++) s.step();
        check("depois da trava o sprite volta a 100 %", s.attacker().root().xZoom, 100);
        System.out.println("CineZoomCompTest fails=" + fails);
    }
}
