package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Flag 33 = controle da trava cinematica: x/y = centro da camera (x espelhado pelo flip), width = zoom %, height = duracao da trava em ticks; a volta fica em 12 ticks. */
public class CinematicFlag33Test {
    static BattleSim make(boolean left, int[] hit33, int hitFrame) throws Exception {
        A[] cz = new A[45];
        for (int i = 0; i < 45; i++) cz[i] = new A().mpt(new M().time(5)).mpt(new M().time(5));
        if (hit33 != null) {
            M f0 = new M().time(5), f1 = new M().time(5);
            if (hitFrame == 0) f0.hit(hit33); else f1.hit(hit33);
            cz[40] = new A().mpt(f0).mpt(f1);
        }
        CharData chZ = chr(move(new int[]{2, 40}), new byte[][] {});
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        BattleSim.cinematic = true;
        BattleSim s = new BattleSim(dac(cz), chZ, chZ.moves[0], left, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, 120, 0, 0);
        s.setSpecialType(9);
        return s;
    }

    static boolean near(float a, float b) { return Math.abs(a - b) < 0.5f; }

    public static void main(String[] args) throws Exception {
        // sem a flag: padrao do jogo (120 ticks + 2, zoom 200 %)
        BattleSim d = make(false, null, 0);
        check("sem flag 33: trava de 122 ticks", d.cinematicLeft(), 122);

        // com a flag: duracao 30 => 32 ticks; zoom 150 % (retangulo 320 px); centro = dono + (10, -20)
        BattleSim s = make(false, new int[]{33, 10, -20, 150, 30}, 0);
        check("duracao da trava = height + 2", s.cinematicLeft(), 32);
        float ax = s.attackerX(), ay = s.attackerY();
        for (int i = 0; i < 8; i++) s.step();
        float[] z = s.zoomRect();
        check("zoom 150 %: retangulo de 320 px", z != null && near(z[2] - z[0], 320f), true);
        check("centro x = dono + 10", z != null && near((z[0] + z[2]) / 2, ax + 10f), true);
        check("centro y = dono - 20", z != null && near((z[1] + z[3]) / 2, ay - 20f), true);
        while (s.cinematicActive()) s.step();
        check("a trava acabou depois dos ticks configurados", s.cinematicActive(), false);
        for (int i = 0; i < 14; i++) s.step();
        check("volta ao zoom normal em 12 ticks", s.zoomRect() == null, true);

        // dono virado (a direita do oponente): x espelha
        BattleSim r = make(true, new int[]{33, 10, -20, 150, 30}, 0);
        float rx = r.attackerX();
        for (int i = 0; i < 8; i++) r.step();
        float[] zr = r.zoomRect();
        check("virado: centro x = dono - 10", zr != null && near((zr[0] + zr[2]) / 2, rx - 10f), true);

        // duracao 0 vale 1 tick; zoom 0 volta ao padrao
        BattleSim m = make(false, new int[]{33, 0, 0, 0, 0}, 0);
        check("duracao 0 vira 1 tick (+2)", m.cinematicLeft(), 3);

        // a flag fora do frame 0 nao conta (o jogo so carrega o frame 0 no md 923)
        BattleSim late = make(false, new int[]{33, 10, -20, 150, 30}, 1);
        check("hit 33 no frame 1 nao muda a trava", late.cinematicLeft(), 122);

        // trava longa
        BattleSim lg = make(false, new int[]{33, 0, 0, 200, 200}, 0);
        check("duracao 200 => 202 ticks", lg.cinematicLeft(), 202);

        // modelo/UI
        boolean has = false;
        for (int f : ObjModel.ACTION_FLAGS) if (f == 33) has = true;
        check("33 esta no menu +", has, true);
        check("nome da acao", ObjModel.actionName(33), "Controle da trava cinematica");
        Ano.Hit dh = ObjModel.defaultHit(33);
        check("hit novo: zoom 200 e trava 120", dh.width + ":" + dh.height + ":" + dh.x + ":" + dh.y, "200:120:0:0");
        check("hit 33 fica so no frame 0 ao dividir", FrameOps.oneShot(33), true);
        System.out.println("CinematicFlag33Test fails=" + fails);
    }
}
