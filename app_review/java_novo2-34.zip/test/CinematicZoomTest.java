package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Zoom de camera da trava cinematica (md 29 / iCameraLock): 200 % em 4 ticks centrado no dono, volta a 100 % em 12 ticks depois da trava. */
public class CinematicZoomTest {
    static BattleSim make(boolean left, int dist, boolean cine) throws Exception {
        A[] cz = new A[45];
        for (int i = 0; i < 45; i++) cz[i] = new A().mpt(new M().time(5)).mpt(new M().time(5));
        CharData chZ = chr(move(new int[]{2, 40}), new byte[][] {});
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        BattleSim.cinematic = cine;
        BattleSim s = new BattleSim(dac(cz), chZ, chZ.moves[0], left, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, dist, 0, 0);
        s.setSpecialType(9);
        return s;
    }

    public static void main(String[] args) throws Exception {
        BattleSim s = make(false, 120, true);
        check("trava ativa e com 122 ticks", s.cinematicActive() + ":" + s.cinematicLeft(), "true:122");
        // atacante a esquerda do oponente (olha para a direita): o dono NAO esta a direita => centro 40 px para a esquerda dele
        float ax = s.attackerX();
        for (int i = 0; i < 6; i++) s.step();
        float[] z = s.zoomRect();
        check("depois de 4+ ticks o zoom e 200 % (retangulo de 240 px)", z != null && Math.abs((z[2] - z[0]) - 240f) < 0.5f, true);
        check("centro x = dono -40 (dono a esquerda do oponente)", z != null && Math.abs((z[0] + z[2]) / 2 - (ax - 40f)) < 0.5f, true);
        check("centro y = y do dono - 48", z != null && Math.abs((z[1] + z[3]) / 2 - (s.attackerY() - 48f)) < 0.5f, true);
        for (int i = 0; i < 60; i++) s.step();
        float[] z2 = s.zoomRect();
        check("durante a trava o zoom se mantem", z2 != null && Math.abs((z2[2] - z2[0]) - 240f) < 0.5f, true);
        while (s.cinematicActive()) s.step();
        for (int i = 0; i < 14; i++) s.step();
        check("12 ticks depois da trava volta a 100 % (sem retangulo)", s.zoomRect() == null, true);

        // dono a direita do oponente (olha para a esquerda): centro 40 px para a direita dele
        BattleSim r = make(true, 120, true);
        float rx = r.attackerX();
        for (int i = 0; i < 6; i++) r.step();
        float[] zr = r.zoomRect();
        check("dono a direita: centro x = dono +40", zr != null && Math.abs((zr[0] + zr[2]) / 2 - (rx + 40f)) < 0.5f, true);

        // trava desligada: sem zoom
        BattleSim off = make(false, 120, false);
        for (int i = 0; i < 20; i++) off.step();
        check("trava desligada: sem zoom", off.zoomRect() == null, true);
        BattleSim.cinematic = true;
        System.out.println("CinematicZoomTest fails=" + fails);
    }
}
