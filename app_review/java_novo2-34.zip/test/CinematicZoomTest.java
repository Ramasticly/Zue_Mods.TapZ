package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Zoom de camera da trava cinematica (md 29 / iCameraLock): 200 % em 4 ticks centrado no dono, volta a 100 % em 12 ticks depois da trava. */
public class CinematicZoomTest {
    static BattleSim make(boolean left, int dist, boolean cine) throws Exception {
        A[] cz = new A[45];
        for (int i = 0; i < 45; i++) cz[i] = new A().mpt(new M().time(5)).mpt(new M().time(5));
        CharData chZ = chr(move(new int[]{2, 40}), new byte[][] {});
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        BattleSim.cinematic = cine;
        BattleSim s = new BattleSim(dac(cz), chZ, chZ.moves[0], left, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, dist, 0, 0);
        s.setSpecialType(9);
        return s;
    }

    public static void main(String[] args) throws Exception {
        BattleSim s = make(false, 120, true);
        check("trava ativa e com 122 ticks", s.cinematicActive() + ":" + s.cinematicLeft(), "true:122");
        // atacante a esquerda do oponente (olha para a direita): o dono NAO esta a direita => centro 40 px para a esquerda dele
        float ax = s.attackerX();
        for (int i = 0; i < 6; i++) s.step();
        float[] z = s.zoomRect();
        check("depois de 4+ ticks o zoom e 200 % (retangulo de 240 px)", z != null && Math.abs((z[2] - z[0]) - 240f) < 0.5f, true);
        check("centro x = dono -40 (dono a esquerda do oponente)", z != null && Math.abs((z[0] + z[2]) / 2 - (ax - 40f)) < 0.5f, true);
        check("centro y = y do dono - 48", z != null && Math.abs((z[1] + z[3]) / 2 - (s.attackerY() - 48f)) < 0.5f, true);
        for (int i = 0; i < 60; i++) s.step();
        float[] z2 = s.zoomRect();
        check("durante a trava o zoom se mantem", z2 != null && Math.abs((z2[2] - z2[0]) - 240f) < 0.5f, true);
        while (s.cinematicActive()) s.step();
        for (int i = 0; i < 14; i++) s.step();
        check("12 ticks depois da trava volta a 100 % (sem retangulo)", s.zoomRect() == null, true);

        // dono a direita do oponente (olha para a esquerda): centro 40 px para a direita dele
        BattleSim r = make(true, 120, true);
        float rx = r.attackerX();
        for (int i = 0; i < 6; i++) r.step();
        float[] zr = r.zoomRect();
        check("dono a direita: centro x = dono +40", zr != null && Math.abs((zr[0] + zr[2]) / 2 - (rx + 40f)) < 0.5f, true);

        // 3.6: a tela do jogo durante a trava (GameScreen): camera na menor chave dos lutadores - 3; Meio entra no zoom, Fundo e Frente nao
        BattleSim gsim = make(false, 120, true);
        for (int i = 0; i < 6; i++) gsim.step();
        java.util.List<BattleSim.Layer> gl = gsim.layers();
        int minKey = Integer.MAX_VALUE;
        for (BattleSim.Layer l : gl) if (l.owner == BattleSim.OWNER_ATTACKER || l.owner == BattleSim.OWNER_DEFENDER) minKey = Math.min(minKey, l.key);
        check("na trava a camera fica na menor chave dos lutadores - 3", gsim.cameraStart(), minKey - 3);
        GameScreen plain = GameScreen.plain();
        float[] zr2 = gsim.zoomRect();
        float cxw = (zr2[0] + zr2[2]) / 2, cyw = (zr2[1] + zr2[3]) / 2;
        float[] mm = gsim.gameXform(plain, 200);
        check("Meio na trava: o centro do zoom vai para o meio da tela (240, 160) com 200 %", Math.abs(cxw * mm[0] + mm[2] - 240f) < 0.6f && Math.abs(cyw * mm[1] + mm[3] - 160f) < 0.6f && Math.abs(mm[0] - 2f) < 0.01f, true);
        float[] mf = gsim.gameXform(plain, 400), mb = gsim.gameXform(plain, 17);
        float sl = gsim.screenLeft() / 65536f, st = gsim.screenTop() / 65536f;
        check("Frente e Fundo na trava: 1:1, so o mundo menos a camera", mf[0] == 1f && mb[0] == 1f && Math.abs(mf[2] + sl) < 0.01f && Math.abs(mb[3] + st) < 0.01f, true);
        BattleSim calm = make(false, 120, false);
        calm.step();
        check("sem trava: camera na prioridade 9", calm.cameraStart(), 9);
        float[] m9 = calm.gameXform(GameScreen.of(2400, 1080), 200);
        check("sem zoom num 20:9 o Meio ainda estica 1,48 (fGS)", Math.abs(m9[0] - 711f / 480f) < 0.01f, true);
        BattleSim.cinematic = true;

        // trava desligada: sem zoom
        BattleSim off = make(false, 120, false);
        for (int i = 0; i < 20; i++) off.step();
        check("trava desligada: sem zoom", off.zoomRect() == null, true);
        BattleSim.cinematic = true;
        System.out.println("CinematicZoomTest fails=" + fails);
    }
}
