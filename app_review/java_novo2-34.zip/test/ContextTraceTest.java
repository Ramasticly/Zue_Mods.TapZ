package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** EDITAR NOS USOS: onde o ANO alvo esta, tick a tick, na simulacao do ANO/golpe que o usa (BattleSim.traceAno). */
public class ContextTraceTest {
    static final int PX = 65536;

    static BattleSim sim(Dac atk, CharData ch) throws Exception {
        BattleSim.edgeMode = 1;
        BattleSim.cutscenes = true;
        return new BattleSim(atk, ch, ch.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 300, 0, 0);
    }

    static String at(BattleSim.Trace t, int tick) { return t.pat[tick] + "/" + t.elapsed[tick]; }

    public static void main(String[] args) throws Exception {
        // ANO 40 (golpe): frames de 10, 10 e 40 ticks; link para o ANO 44 (2 frames de 5); frame 1 com a flag 71 (aura = ANO 201); frame 0 com a cutscene do evento 0
        A[] a = new A[210];
        for (int i = 0; i < a.length; i++) a[i] = new A().mpt(new M().time(1));
        a[40] = new A().mpt(new M().time(10).hit(20, 0, 0, 0, 0)).mpt(new M().time(10).hit(71, 4, -8, 10, 10)).mpt(new M().time(40));
        a[44] = new A().mpt(new M().time(5)).mpt(new M().time(5));
        a[45] = new A().mpt(new M().time(6)).mpt(new M().time(6)).mpt(new M().time(30));
        a[201] = new A().mpt(new M().time(3)).mpt(new M().time(50));
        Dac dac = dac(a);
        Ano p40 = dac.getAno(40);
        dac.setAno(40, new Ano(40, true, p40.flags, p40.priority, new Ano.Link[] {new Ano.Link(0, 0, 44)}, p40.mpts));
        // evento 0: ALVO 1 (pack do personagem), ANIM 45, FLIP 46, ate o ANO acabar
        CharData ch = CutsceneTest.chrEv(new int[] {1, 0, 0, 45, 46, 0, 0, 0});
        BattleSim s = sim(dac, ch);

        BattleSim.Trace tl = s.traceAno(44, 120);
        check("link: aparece no tick 0, frame 0 com 0 ticks decorridos", tl.first + ":" + at(tl, 0), "0:0/0");
        check("link: ticks decorridos contam dentro do frame", at(tl, 4), "0/4");
        check("link: frame 1 comeca no tick 5", at(tl, 5), "1/0");

        BattleSim.Trace ta = s.traceAno(201, 120);
        check("aura da flag 71 (ANO 201): nasce no frame 1 do golpe (tick 10)", ta.first + ":" + at(ta, 10), "10:0/0");
        check("aura: antes de nascer nao esta na tela", ta.pat[9], -1);
        check("aura: frame 1 depois de 3 ticks", at(ta, 13), "1/0");

        BattleSim.Trace tc = s.traceAno(45, 120);
        check("cutscene ALVO 1 (ANIM 45): no tick 0, frame 0", tc.first + ":" + at(tc, 0), "0:0/0");
        check("cutscene: frame 1 no tick 6", at(tc, 6), "1/0");
        check("cutscene (ate o ANO acabar): continua enquanto o ANO do golpe nao muda; parada no ultimo frame", tc.last >= 59 && tc.pat[tc.last] == 2, true);
        BattleSim.Trace tf = s.traceAno(46, 120);
        check("ANIM_FLIP com o atacante virado para a direita: nao aparece", tf.first + ":" + tf.last, "-1:-1");

        BattleSim.Trace tr = s.traceAno(40, 120);
        check("o proprio ANO do golpe: o lutador, do tick 0", tr.first + ":" + at(tr, 0) + ":" + at(tr, 15), "0:0/0:1/5");
        check("ANO que ninguem usa: nunca aparece", s.traceAno(30, 60).first, -1);

        // projetil: golpe com PROJETIL_ANIM_NORMAL 47 e flag 0 no frame 1 do ANO 41
        A[] b = new A[60];
        for (int i = 0; i < b.length; i++) b[i] = new A().mpt(new M().time(1));
        b[41] = new A().mpt(new M().time(4)).mpt(new M().time(4).hit(0, 10, -20, 0, 0)).mpt(new M().time(30));
        b[47] = new A().mpt(new M().time(8).speedX(2 * PX)).mpt(new M().time(40).speedX(2 * PX));
        Dac dp = dac(b);
        CharData cp = chr(move(new int[] {2, 41}, new int[] {4, 47}), new byte[][] {});
        BattleSim sp = new BattleSim(dp, cp, cp.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 300, 0, 0);
        BattleSim.Trace tp = sp.traceAno(47, 120);
        check("projetil: aparece depois do frame da flag 0 (tick >= 4)", tp.first >= 4 && tp.first <= 6, true);
        if (tp.first >= 0) check("projetil: comeca no frame 0", tp.pat[tp.first], 0);
        System.out.println("ContextTraceTest fails=" + fails + " (proj first=" + tp.first + ")");
    }
}
