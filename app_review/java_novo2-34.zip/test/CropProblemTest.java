package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Motivo exato de um recorte do CNV falhar: folha inexistente, PNG ilegivel, fora da folha, passa da borda, vazio. */
public class CropProblemTest {
    static Cnv.Entry e(int src, int x, int y, int w, int h) throws Exception {
        return Cnv.read(Cnv.encode(src, x, y, w, h), false).byImage(0);
    }

    public static void main(String[] args) throws Exception {
        check("recorte certo", CropProblem.reason(e(0, 10, 20, 30, 40), 2, "000.png", 1, 512, 512), null);
        check("sem entrada", CropProblem.reason(null, 2, "000.png", 1, 512, 512), "sem entrada no CNV");
        check("recorte vazio", CropProblem.reason(e(0, 0, 0, 0, 5), 2, "000.png", 1, 512, 512).startsWith("recorte vazio"), true);
        check("coordenada negativa", CropProblem.reason(e(0, -3, 4, 5, 5), 1, "000.png", 1, 512, 512).startsWith("coordenada negativa (x -3, y 4)"), true);

        String no = CropProblem.reason(e(18, 0, 0, 10, 10), 2, null, 19, 0, 0);
        check("folha inexistente cita o $src, a quantidade e que e indice", no.contains("$src:18") && no.contains("19 folha(s) PNG") && no.contains("indices 0 a 18") && no.contains("indice na lista"), true);
        check("pasta sem nenhum PNG", CropProblem.reason(e(0, 0, 0, 10, 10), 2, null, 0, 0, 0).contains("0 folha(s) PNG)") && !CropProblem.reason(e(0, 0, 0, 10, 10), 2, null, 0, 0, 0).contains("indices 0 a"), true);
        check("PNG ilegivel", CropProblem.reason(e(2, 0, 0, 10, 10), 2, "002.png", 3, 0, 0), "PNG ilegivel: 002.png");

        CropProblem out = CropProblem.check(e(0, 300, 0, 10, 10), 2, "019.png", 19, 512, 512);
        check("fora da folha e fatal, com os numeros dobrados", out.fatal + ":" + out.text, "true:recorte fora da folha 019.png (512x512): x 600..620, y 0..20 (CNV x2)");
        CropProblem edge = CropProblem.check(e(0, 240, 0, 30, 10), 2, "000.png", 1, 512, 512);
        check("passa da borda e so aviso", edge.fatal + ":" + edge.text, "false:recorte passa da borda da folha 000.png (512x512): x 480..540, y 0..20 (CNV x2)");
        check("escala 1 nao mostra o multiplicador", CropProblem.reason(e(0, 600, 0, 10, 10), 1, "000.png", 1, 512, 512).contains("CNV x"), false);
        check("exatamente na borda e valido", CropProblem.reason(e(0, 246, 0, 10, 10), 2, "000.png", 1, 512, 512), null);
        System.out.println("CropProblemTest fails=" + fails);
    }
}
