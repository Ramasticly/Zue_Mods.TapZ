package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** HDAT 13 (cutscenes) editavel: modelo (set/add/remove/clear/snapshot) e ida e volta do texto $ROTEIRO_CUTSCENE com um 000.bin.txt real (26 eventos). */
public class CutsceneEditTest {
    static final String SAMPLE =
        "   $HDAT_13:{$info:{$COL: 8, $ROW: 26, $SZ: &000001A0},\n" +
        "      $ROTEIRO_CUTSCENE:{\n" +
        "         // Ativado por hitbox flag=20. O 3º valor da hitbox (COORDS) é o índice do evento.\n" +
        "         // $ALVO: 0=effect.pac | 1=char.pac do player | outro valor=ranura 2\n" +
        "         // $DURACAO: 0 ou valor negativo = até mudar a animação; N positivo = limite de frames\n" +
        "         // $FLAG: 0=nada | 1=PlayerState do atacante | 2=PlayerState do oponente se Life<=0\n" +
        "\n" +
        "         $EVT_00: { $ALVO:0, $DURACAO:1, $Z_LAYER:1, $ANIM_ID:145, $ANIM_FLIP:145, $CAM_MODE:1, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_01: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:146, $ANIM_FLIP:146, $CAM_MODE:2, $TRAVAR_VIT:0, $FLAG:1 },\n" +
        "         $EVT_02: { $ALVO:0, $DURACAO:1, $Z_LAYER:2, $ANIM_ID:148, $ANIM_FLIP:148, $CAM_MODE:1, $TRAVAR_VIT:1, $FLAG:0 },\n" +
        "         $EVT_03: { $ALVO:1, $DURACAO:1, $Z_LAYER:2, $ANIM_ID:280, $ANIM_FLIP:280, $CAM_MODE:1, $TRAVAR_VIT:1, $FLAG:0 },\n" +
        "         $EVT_04: { $ALVO:1, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:2 },\n" +
        "         $EVT_05: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:67, $ANIM_FLIP:68, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_06: { $ALVO:2, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:40, $ANIM_FLIP:40, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_07: { $ALVO:2, $DURACAO:0, $Z_LAYER:2, $ANIM_ID:42, $ANIM_FLIP:41, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_08: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:143, $ANIM_FLIP:144, $CAM_MODE:1, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_09: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:355, $ANIM_FLIP:355, $CAM_MODE:1, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_10: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:3 },\n" +
        "         $EVT_11: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:7 },\n" +
        "         $EVT_12: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:6 },\n" +
        "         $EVT_13: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:4 },\n" +
        "         $EVT_14: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:9 },\n" +
        "         $EVT_15: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:5 },\n" +
        "         $EVT_16: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:8 },\n" +
        "         $EVT_17: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:3 },\n" +
        "         $EVT_18: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:9, $ANIM_FLIP:9, $CAM_MODE:2, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_19: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:0, $ANIM_FLIP:0, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:13 },\n" +
        "         $EVT_20: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:136, $ANIM_FLIP:136, $CAM_MODE:1, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_21: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:127, $ANIM_FLIP:127, $CAM_MODE:2, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_22: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:118, $ANIM_FLIP:120, $CAM_MODE:2, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_23: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:120, $ANIM_FLIP:118, $CAM_MODE:2, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_24: { $ALVO:0, $DURACAO:0, $Z_LAYER:1, $ANIM_ID:122, $ANIM_FLIP:122, $CAM_MODE:2, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "         $EVT_25: { $ALVO:0, $DURACAO:0, $Z_LAYER:0, $ANIM_ID:422, $ANIM_FLIP:423, $CAM_MODE:0, $TRAVAR_VIT:0, $FLAG:0 },\n" +
        "      },\n" +
        "   },\n";

    static String bin(String hdat13) { return "BIN_ {\n   $HDAT_3:{ $info:{$COL: 1, $ROW: 1} },\n" + hdat13 + "   $HDAT_14:{$info:{$COL: 14, $ROW: 0}},\n}\n"; }

    public static void main(String[] args) throws Exception {
        String text = bin(SAMPLE);
        int[][] ev = CutsceneText.parse(text);
        check("le os 26 eventos do texto real", ev == null ? -1 : ev.length, 26);
        check("EVT_03 = char do player, anim 280, trava o oponente", ev[3][0] + ":" + ev[3][3] + ":" + ev[3][6], "1:280:1");
        check("EVT_22 = anim 118 e espelhada 120, cam 2", ev[22][3] + ":" + ev[22][4] + ":" + ev[22][5], "118:120:2");
        check("comentarios nao viram eventos (so \"$EVT\" de verdade)", ev[25][3], 422);

        // carrega num CharData
        CharData cd = CutsceneTest.chrEv(new int[]{0, 1, 2, 3, 4, 5, 6, 7});
        check("antes: 1 linha do binario", cd.eventRows() + ":" + cd.eventField(0, 6), "1:3");
        cd.loadEvents(ev);
        check("depois do texto: 26 linhas, 8 colunas, nao editado", cd.eventRows() + "x" + cd.eventCols() + ":" + cd.eventsEdited(), "26x8:false");
        check("campos pelos deslocamentos do jogo", cd.eventField(0, CharData.EV_ANIM) + ":" + cd.eventField(5, CharData.EV_ANIM_FLIP) + ":" + cd.eventField(19, CharData.EV_FLAG), "145:68:13");
        check("hasEvent 25 sim, 26 nao", cd.hasEvent(25) + ":" + cd.hasEvent(26), "true:false");

        // texto -> texto sem editar: igual (comentarios preservados)
        String same = CutsceneText.patch(text, cd, new boolean[1]);
        check("regravar sem mudar nao muda o texto", same.equals(text), true);

        // editar
        cd.setEventField(3, CharData.EV_ANIM, 281);
        cd.setEventField(3, CharData.EV_STUN, 0);
        check("editado", cd.eventsEdited() + ":" + cd.eventField(3, CharData.EV_ANIM) + ":" + cd.eventField(3, CharData.EV_STUN), "true:281:0");
        String t1 = CutsceneText.patch(text, cd, new boolean[1]);
        check("o texto traz a linha nova", t1.contains("$EVT_03: { $ALVO:1, $DURACAO:1, $Z_LAYER:2, $ANIM_ID:281, $ANIM_FLIP:280, $CAM_MODE:1, $TRAVAR_VIT:0, $FLAG:0 },"), true);
        check("os comentarios continuam", t1.contains("// $DURACAO: 0 ou valor negativo") && t1.contains("// Ativado por hitbox flag=20."), true);
        check("o resto do arquivo nao muda", t1.startsWith("BIN_ {\n   $HDAT_3:{ $info:{$COL: 1, $ROW: 1} },\n") && t1.endsWith("   $HDAT_14:{$info:{$COL: 14, $ROW: 0}},\n}\n"), true);
        int[][] back = CutsceneText.parse(t1);
        check("ida e volta: le o que gravou", back[3][3] + ":" + back.length, "281:26");

        // novo evento (copia do 3) e $ROW/$SZ
        int nid = cd.addEvent(3);
        cd.setEventField(nid, CharData.EV_ANIM, 500);
        check("novo evento no fim", nid + ":" + cd.eventRows() + ":" + cd.eventField(nid, CharData.EV_ALVO), "26:27:1");
        String t2 = CutsceneText.patch(text, cd, new boolean[1]);
        check("$ROW 27 e $SZ = 27 * 8 * 2 = 0x1B0", t2.contains("$ROW: 27") && t2.contains("$SZ: &000001B0") && t2.contains("$COL: 8"), true);
        check("o evento 26 foi escrito", t2.contains("$EVT_26: { $ALVO:1, $DURACAO:1, $Z_LAYER:2, $ANIM_ID:500,"), true);
        check("volta com 27 linhas", CutsceneText.parse(t2).length, 27);
        // tirar o ultimo
        check("remover o ultimo", cd.removeLastEvent() + ":" + cd.eventRows(), "true:26");
        String t3 = CutsceneText.patch(t2, cd, new boolean[1]);
        check("depois de remover: 26 e $SZ 0x1A0 de novo", t3.contains("$ROW: 26") && t3.contains("$SZ: &000001A0") && !t3.contains("$EVT_26"), true);
        // zerar uma linha
        cd.clearEvent(4);
        check("zerar a linha 4", cd.eventField(4, CharData.EV_ALVO) + ":" + cd.eventField(4, CharData.EV_FLAG), "0:0");
        // desfazer
        CharData.EventsSnap snap = cd.snapshotEvents();
        cd.setEventField(0, CharData.EV_ANIM, 1);
        cd.restoreEvents(snap);
        check("restaurar a foto desfaz a edicao", cd.eventField(0, CharData.EV_ANIM), 145);
        // texto sem HDAT_13
        boolean[] f = new boolean[1];
        String none = CutsceneText.patch("BIN_ {\n  $HDAT_3:{ },\n}\n", cd, f);
        check("sem $HDAT_13 no arquivo: nada muda e avisa", f[0] + ":" + none.equals("BIN_ {\n  $HDAT_3:{ },\n}\n"), "false:true");
        // $HDAT_13 sem o bloco do roteiro: e criado
        String bare = "BIN_ {\n   $HDAT_13:{$info:{$COL: 8, $ROW: 0, $SZ: &00000000}},\n}\n";
        String made = CutsceneText.patch(bare, cd, new boolean[1]);
        check("cria o $ROTEIRO_CUTSCENE quando falta", CutsceneText.parse(made) != null && CutsceneText.parse(made).length == 26 && made.contains("$ROW: 26"), true);
        // eventos que os hits usam
        Ano.Mpt m = new Ano.Mpt();
        m.hits = new Ano.Hit[] { hit20(7), hit20(12) };
        m.flags |= 0x10;
        Ano a1 = new Ano(3, true, 0, 0, new Ano.Link[0], new Ano.Mpt[] {m});
        check("quem usa o evento 7 / 12 / 8", CutsceneEdit.users(new Ano[] {a1}, 7).toString() + CutsceneEdit.users(new Ano[] {a1}, 12) + CutsceneEdit.users(new Ano[] {a1}, 8), "[3][3][]");
        System.out.println("CutsceneEditTest fails=" + fails);
    }

    static Ano.Hit hit20(int ev) { Ano.Hit h = new Ano.Hit(); h.flag = 20; h.width = ev; return h; }
}
