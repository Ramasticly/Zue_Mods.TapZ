package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Campos fixos/ignorados e modos de posicao do editor de cutscenes (regras do md 996 do jogo). */
public class CutsceneFieldsTest {
    /** ALVO, DURACAO, Z, ANIM, ANIM_FLIP, CAM, STUN, FLAG */
    static int[] row(int alvo, int dur, int z, int anim, int flip, int cam, int stun, int flag) { return new int[] {alvo, dur, z, anim, flip, cam, stun, flag}; }

    public static void main(String[] args) throws Exception {
        // sem animacao
        int[] none = row(0, 0, 0, 0, 0, 0, 0, 2);
        check("sem animacao: ALVO fixo", CutsceneFields.fixed(none, 4, CharData.EV_ALVO) != null, true);
        check("sem animacao: ANIM_FLIP e Z_LAYER fixos", (CutsceneFields.fixed(none, 4, CharData.EV_ANIM_FLIP) != null) + ":" + (CutsceneFields.fixed(none, 4, CharData.EV_Z) != null), "true:true");
        check("sem animacao e FLAG 2: CAM_MODE fixo", CutsceneFields.fixed(none, 4, CharData.EV_CAM) != null, true);
        check("sem animacao: DURACAO, TRAVAR_VIT, FLAG e ANIM_ID livres", CutsceneFields.fixed(none, 4, CharData.EV_DURACAO) + ":" + CutsceneFields.fixed(none, 4, CharData.EV_STUN) + ":" + CutsceneFields.fixed(none, 4, CharData.EV_FLAG) + ":" + CutsceneFields.fixed(none, 4, CharData.EV_ANIM), "null:null:null:null");
        // com animacao
        int[] world = row(0, 0, 1, 67, 68, 0, 0, 0);
        check("com animacao nenhum campo e fixo", CutsceneFields.fixed(world, 5, CharData.EV_ALVO) + CutsceneFields.fixed(world, 5, CharData.EV_ANIM_FLIP) + CutsceneFields.fixed(world, 5, CharData.EV_Z) + CutsceneFields.fixed(world, 5, CharData.EV_CAM) + CutsceneFields.fixed(world, 5, CharData.EV_DURACAO), "nullnullnullnullnull");
        // FLAG 3
        int[] cam3 = row(0, 5, 0, 0, 0, 0, 0, 3);
        check("FLAG 3: DURACAO ignorada; CAM_MODE conta (cam 0 salta)", (CutsceneFields.fixed(cam3, 10, CharData.EV_DURACAO) != null) + ":" + CutsceneFields.fixed(cam3, 10, CharData.EV_CAM), "true:null");
        // posicao: segue o mundo
        CutsceneFields.Pos pw = CutsceneFields.position(world, 5, 30, -40);
        check("cam 0 + animacao: segue o mundo, X e Y editaveis com os valores do hit", pw.mode.startsWith("Segue o mundo") + ":" + pw.xEdit + ":" + pw.yEdit + ":" + pw.xShown + ":" + pw.yShown + ":" + pw.xNote + ":" + pw.yNote, "true:true:true:30:-40:null:null");
        // segue a tela
        int[] screen = row(0, 0, 1, 145, 145, 1, 0, 0);
        CutsceneFields.Pos ps = CutsceneFields.position(screen, 0, 30, -40);
        check("cam != 0 + animacao: segue a tela, X/Y fixos em 0 e nao editam", ps.mode.startsWith("Segue a tela") + ":" + ps.xEdit + ":" + ps.yEdit + ":" + ps.xShown + ":" + ps.yShown, "true:false:false:0:0");
        check("texto do fixo: fixo em 0 para este modo/evento", ps.xNote.startsWith("fixo em 0 para este modo/evento") && ps.yNote.startsWith("fixo em 0 para este modo/evento"), true);
        CutsceneFields.Pos p8 = CutsceneFields.position(row(0, 0, 1, 143, 144, 1, 0, 0), 8, 5, 5);
        check("eventos 8 e 9 com cam != 0: so no 1o tick vai a (0, 0)", p8.mode.contains("1º tick") && !p8.xEdit, true);
        // FLAG 3 sem animacao: so o X da camera
        CutsceneFields.Pos p3 = CutsceneFields.position(cam3, 10, 80, 20);
        check("FLAG 3 sem animacao: segue a camera, so o X edita; Y fixo", p3.camera.startsWith("Segue a câmera") + ":" + p3.xEdit + ":" + p3.yEdit + ":" + p3.xShown + ":" + p3.yShown, "true:true:false:80:0");
        CutsceneFields.Pos p3s = CutsceneFields.position(row(0, 0, 0, 0, 0, 0, 1, 3), 10, 80, 20);
        check("FLAG 3 + TRAVAR_VIT: o X vira o estado do alvo, fixo", p3s.xEdit + ":" + p3s.xShown + ":" + (p3s.xNote != null), "false:0:true");
        // FLAG 3 com animacao no mundo
        CutsceneFields.Pos p3w = CutsceneFields.position(row(0, 0, 1, 40, 40, 0, 0, 3), 10, 7, 9);
        check("FLAG 3 + animacao no mundo: X e Y editam (o X tambem e o alvo da camera)", p3w.xEdit + ":" + p3w.yEdit + ":" + p3w.mode.contains("Segue o mundo") + ":" + (p3w.camera != null), "true:true:true:true");
        // sem animacao e sem FLAG 3: nada usa a posicao
        CutsceneFields.Pos pn = CutsceneFields.position(none, 4, 9, 9);
        check("sem animacao e FLAG != 3: posicao nao usada", pn.mode.contains("não é usada") + ":" + pn.xEdit + ":" + pn.yEdit, "true:false:false");
        check("isEmpty", CutsceneFields.isEmpty(new int[8]) + ":" + CutsceneFields.isEmpty(none) + ":" + CutsceneFields.isEmpty(null), "true:false:true");

        // colar / zerar / duplicar sobre o modelo
        String text = CutsceneEditTest.bin(CutsceneEditTest.SAMPLE);
        CharData cd = CharData.fromTxt("BIN_CNV_ {$COUNT: 15,\n   $HDAT_4:{$info:{$COL: 48, $ROW: 1, $SZ: &00000030}, $RAW:B[" + zeros(48) + "]},\n" + CutsceneEditTest.SAMPLE + "}");
        int[] src = cd.eventRow(3);
        CharData.EventsSnap before = cd.snapshotEvents();
        check("colar: evento 7 vira cópia do 3", cd.setEventRow(7, src) + ":" + java.util.Arrays.toString(cd.eventRow(7)).equals(java.util.Arrays.toString(src)) + ":" + cd.eventsEdited(), "true:true:true");
        check("colar em evento inexistente = false", cd.setEventRow(99, src), false);
        cd.restoreEvents(before);
        check("desfazer do colar", java.util.Arrays.toString(cd.eventRow(7)).equals(java.util.Arrays.toString(src)), false);
        cd.clearEvent(5);
        check("zerar: linha vazia e a quantidade de eventos nao muda", CutsceneFields.isEmpty(cd.eventRow(5)) + ":" + cd.eventRows(), "true:26");
        int novo = cd.addEvent(3);
        check("duplicar: nova linha no fim igual a original", novo + ":" + java.util.Arrays.toString(cd.eventRow(novo)).equals(java.util.Arrays.toString(src)), "26:true");
        System.out.println("CutsceneFieldsTest fails=" + fails);
    }

    static String zeros(int n) { StringBuilder b = new StringBuilder(); for (int i = 0; i < n; i++) b.append(i > 0 ? ", " : "").append("&00"); return b.toString(); }
}
