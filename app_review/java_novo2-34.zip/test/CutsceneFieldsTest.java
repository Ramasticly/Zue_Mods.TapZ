package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Campos fixos/ignorados e modos de posicao do editor de cutscenes (regras do md 996 do jogo). */
public class CutsceneFieldsTest {
    /** ALVO, DURACAO, Z, ANIM, ANIM_FLIP, CAM, STUN, FLAG */
    static int[] row(int alvo, int dur, int z, int anim, int flip, int cam, int stun, int flag) { return new int[] {alvo, dur, z, anim, flip, cam, stun, flag}; }

    public static void main(String[] args) throws Exception {
        // sem animacao
        int[] none = row(0, 0, 0, 0, 0, 0, 0, 2);
        check("sem animacao: ALVO fixo", CutsceneFields.fixed(none, 4, CharData.EV_ALVO) != null, true);
        check("sem animacao: ANIM_FLIP e Z_LAYER fixos", (CutsceneFields.fixed(none, 4, CharData.EV_ANIM_FLIP) != null) + ":" + (CutsceneFields.fixed(none, 4, CharData.EV_Z) != null), "true:true");
        check("sem animacao e FLAG 2: CAM_MODE fixo", CutsceneFields.fixed(none, 4, CharData.EV_CAM) != null, true);
        check("sem animacao: DURACAO, TRAVAR_VIT, FLAG e ANIM_ID livres", CutsceneFields.fixed(none, 4, CharData.EV_DURACAO) + ":" + CutsceneFields.fixed(none, 4, CharData.EV_STUN) + ":" + CutsceneFields.fixed(none, 4, CharData.EV_FLAG) + ":" + CutsceneFields.fixed(none, 4, CharData.EV_ANIM), "null:null:null:null");
        // com animacao
        int[] world = row(0, 0, 1, 67, 68, 0, 0, 0);
        check("com animacao nenhum campo e fixo", CutsceneFields.fixed(world, 5, CharData.EV_ALVO) + CutsceneFields.fixed(world, 5, CharData.EV_ANIM_FLIP) + CutsceneFields.fixed(world, 5, CharData.EV_Z) + CutsceneFields.fixed(world, 5, CharData.EV_CAM) + CutsceneFields.fixed(world, 5, CharData.EV_DURACAO), "nullnullnullnullnull");
        // FLAG 3
        int[] cam3 = row(0, 5, 0, 0, 0, 0, 0, 3);
        check("FLAG 3: DURACAO ignorada; CAM_MODE conta (cam 0 salta)", (CutsceneFields.fixed(cam3, 10, CharData.EV_DURACAO) != null) + ":" + CutsceneFields.fixed(cam3, 10, CharData.EV_CAM), "true:null");
        // posicao: segue o mundo
        CutsceneFields.Pos pw = CutsceneFields.position(world, 5, 30, -40);
        check("cam 0 + animacao: segue o mundo, X e Y editaveis com os valores do hit", pw.mode.startsWith("Segue o mundo") + ":" + pw.xEdit + ":" + pw.yEdit + ":" + pw.xShown + ":" + pw.yShown + ":" + pw.xNote + ":" + pw.yNote, "true:true:true:30:-40:null:null");
        // segue a tela
        int[] screen = row(0, 0, 1, 145, 145, 1, 0, 0);
        CutsceneFields.Pos ps = CutsceneFields.position(screen, 0, 30, -40);
        check("cam != 0 + animacao: segue a tela, X/Y fixos em 0 e nao editam", ps.mode.startsWith("Segue a tela") + ":" + ps.xEdit + ":" + ps.yEdit + ":" + ps.xShown + ":" + ps.yShown, "true:false:false:0:0");
        check("texto do fixo: fixo em 0 para este modo/evento", ps.xNote.startsWith("fixo em 0 para este modo/evento") && ps.yNote.startsWith("fixo em 0 para este modo/evento"), true);
        CutsceneFields.Pos p8 = CutsceneFields.position(row(0, 0, 1, 143, 144, 1, 0, 0), 8, 5, 5);
        check("eventos 8 e 9 com cam != 0: so no 1o tick vai a (0, 0)", p8.mode.contains("1º tick") && !p8.xEdit, true);
        // FLAG 3 sem animacao: so o X da camera
        CutsceneFields.Pos p3 = CutsceneFields.position(cam3, 10, 80, 20);
        check("FLAG 3 sem animacao: segue a camera, so o X edita; Y fixo", p3.camera.startsWith("Segue a câmera") + ":" + p3.xEdit + ":" + p3.yEdit + ":" + p3.xShown + ":" + p3.yShown, "true:true:false:80:0");
        CutsceneFields.Pos p3s = CutsceneFields.position(row(0, 0, 0, 0, 0, 0, 1, 3), 10, 80, 20);
        check("FLAG 3 + TRAVAR_VIT: o X vira o estado do alvo, fixo", p3s.xEdit + ":" + p3s.xShown + ":" + (p3s.xNote != null), "false:0:true");
        // FLAG 3 com animacao no mundo
        CutsceneFields.Pos p3w = CutsceneFields.position(row(0, 0, 1, 40, 40, 0, 0, 3), 10, 7, 9);
        check("FLAG 3 + animacao no mundo: X e Y editam (o X tambem e o alvo da camera)", p3w.xEdit + ":" + p3w.yEdit + ":" + p3w.mode.contains("Segue o mundo") + ":" + (p3w.camera != null), "true:true:true:true");
        // sem animacao e sem FLAG 3: nada usa a posicao
        CutsceneFields.Pos pn = CutsceneFields.position(none, 4, 9, 9);
        check("sem animacao e FLAG != 3: posicao nao usada", pn.mode.contains("não é usada") + ":" + pn.xEdit + ":" + pn.yEdit, "true:false:false");
        check("isEmpty", CutsceneFields.isEmpty(new int[8]) + ":" + CutsceneFields.isEmpty(none) + ":" + CutsceneFields.isEmpty(null), "true:false:true");

        // colar / zerar / duplicar sobre o modelo
        String text = CutsceneEditTest.bin(CutsceneEditTest.SAMPLE);
        CharData cd = CharData.fromTxt("BIN_CNV_ {$COUNT: 15,\n   $HDAT_4:{$info:{$COL: 48, $ROW: 1, $SZ: &00000030}, $RAW:B[" + zeros(48) + "]},\n" + CutsceneEditTest.SAMPLE + "}");
        int[] src = cd.eventRow(3);
        CharData.EventsSnap before = cd.snapshotEvents();
        check("colar: evento 7 vira cópia do 3", cd.setEventRow(7, src) + ":" + java.util.Arrays.toString(cd.eventRow(7)).equals(java.util.Arrays.toString(src)) + ":" + cd.eventsEdited(), "true:true:true");
        check("colar em evento inexistente = false", cd.setEventRow(99, src), false);
        cd.restoreEvents(before);
        check("desfazer do colar", java.util.Arrays.toString(cd.eventRow(7)).equals(java.util.Arrays.toString(src)), false);
        cd.clearEvent(5);
        check("zerar: linha vazia e a quantidade de eventos nao muda", CutsceneFields.isEmpty(cd.eventRow(5)) + ":" + cd.eventRows(), "true:26");
        int novo = cd.addEvent(3);
        check("duplicar: nova linha no fim igual a original", novo + ":" + java.util.Arrays.toString(cd.eventRow(novo)).equals(java.util.Arrays.toString(src)), "26:true");

        // ---- 3.5: camadas, camera, duracao, FLAG em grupos, avisos
        check("camadas normais: Fundo = Z_LAYER 1 (17), Meio = 0 (200), Frente = 2 (400)", java.util.Arrays.toString(CutsceneFields.layerOrder(5)), "[1, 0, 2]");
        check("camadas dos eventos 8 e 9: Fundo = 0 (10), Meio = 1 (19/21), Frente = 2", java.util.Arrays.toString(CutsceneFields.layerOrder(8)) + java.util.Arrays.toString(CutsceneFields.layerOrder(9)), "[0, 1, 2][0, 1, 2]");
        check("indice da camada guardada (evento comum)", CutsceneFields.layerIndexOf(5, 1) + ":" + CutsceneFields.layerIndexOf(5, 0) + ":" + CutsceneFields.layerIndexOf(5, 2) + ":" + CutsceneFields.layerIndexOf(5, 7) + ":" + CutsceneFields.layerIndexOf(5, -1), "0:1:2:2:2");
        check("indice da camada guardada (evento 8)", CutsceneFields.layerIndexOf(8, 0) + ":" + CutsceneFields.layerIndexOf(8, 1) + ":" + CutsceneFields.layerIndexOf(8, 2), "0:1:2");
        check("ajuda das camadas", CutsceneFields.layerHelp(5, 1) + "|" + CutsceneFields.layerHelp(5, 2), "na frente dos lutadores|na frente de tudo");
        check("nomes das camadas", String.join("/", CutsceneFields.LAYER_NAMES), "Fundo/Meio/Frente");
        check("camera: 3 comportamentos (0 mundo, 1 canto + tela cheia, 2 e acima so canto)", CutsceneFields.camName(0) + "|" + CutsceneFields.camName(1) + "|" + CutsceneFields.camName(2) + "|" + CutsceneFields.camName(9), "Segue o mundo (no golpe)|Canto da tela + tela cheia|Canto da tela|Canto da tela");
        check("ordem da lista de camera: mundo, canto, canto + tela cheia", java.util.Arrays.toString(CutsceneFields.CAM_VALUES), "[0, 2, 1]");
        check("ajuda da camera 1 cita a tela cheia; dos eventos 8/9 cita o 1o tick", CutsceneFields.camHelp(1, 5).contains("tela cheia") + ":" + CutsceneFields.camHelp(2, 8).contains("1º tick") + ":" + CutsceneFields.camHelp(2, 5).contains("1º tick"), "true:true:false");
        check("duracao <= 0 = ate o ANO acabar; N = N MPTs", CutsceneFields.durationLabel(0) + "|" + CutsceneFields.durationLabel(-5) + "|" + CutsceneFields.durationLabel(1) + "|" + CutsceneFields.durationLabel(6), "Até o ANO acabar|Até o ANO acabar|Dura 1 MPT|Dura 6 MPTs");
        // FLAG em grupos: cobrem 0..15 uma vez cada (7/8 como caixas; 9 = as duas)
        boolean[] seen = new boolean[16];
        for (CutsceneFields.FlagGroup g : CutsceneFields.flagGroups()) for (CutsceneFields.FlagOpt o : g.opts) seen[o.value] = true;
        seen[9] = true;
        boolean all = true;
        for (boolean b : seen) all &= b;
        check("os grupos de FLAG cobrem os valores 0 a 15 (9 pelas duas caixas)", all, true);
        check("grupos: Luta, Camera, Paredes, Sem limite (caixas), Prender, Teleportar", CutsceneFields.flagGroups().length + ":" + CutsceneFields.flagGroups()[3].boxes + ":" + CutsceneFields.flagGroups()[0].boxes, "6:true:false");
        check("caixas <-> FLAG: 7 oponente, 8 dono, 9 os dois, nenhuma = 0", CutsceneFields.flagOfBoxes(true, false) + ":" + CutsceneFields.flagOfBoxes(false, true) + ":" + CutsceneFields.flagOfBoxes(true, true) + ":" + CutsceneFields.flagOfBoxes(false, false), "7:8:9:0");
        check("FLAG -> bits das caixas", CutsceneFields.boxesOf(7) + ":" + CutsceneFields.boxesOf(8) + ":" + CutsceneFields.boxesOf(9) + ":" + CutsceneFields.boxesOf(3), "1:2:3:0");
        check("ajuda da FLAG 0 e 3", CutsceneFields.flagHelp(0) + "|" + CutsceneFields.flagHelp(3).contains("camera") + "|" + CutsceneFields.flagHelp(3).contains("câmera"), "nada|true|false".replace("true|false", "true|false"));
        // avisos
        java.util.List<String> w3 = CutsceneFields.warnings(row(0, 5, 0, 0, 0, 0, 1, 3), 10, false);
        check("FLAG 3 + camera 0 + travar: 3 avisos (duracao, camera salta, estado nunca devolvido)", w3.size() + ":" + w3.get(0).contains("DURAÇÃO") + ":" + w3.get(1).contains("nunca aparece") + ":" + w3.get(2).contains("nunca devolve"), "3:true:true:true");
        check("evento vazio avisa que nao faz nada", CutsceneFields.warnings(new int[8], 4, false).get(0).contains("não faz nada"), true);
        check("sem avisos num evento normal (animacao, Meio no mundo, sem FLAG)", CutsceneFields.warnings(row(0, 0, 0, 67, 68, 0, 0, 0), 5, false).size(), 0);
        // 3.6: como o jogo desenha a camada
        check("zKey igual ao _SetObj do md 996", CutsceneFields.zKey(5, 0) + ":" + CutsceneFields.zKey(5, 1) + ":" + CutsceneFields.zKey(5, 2) + ":" + CutsceneFields.zKey(8, 0) + ":" + CutsceneFields.zKey(8, 1) + ":" + CutsceneFields.zKey(9, 1) + ":" + CutsceneFields.zKey(5, -3), "200:17:400:10:19:21:400");
        check("Meio no canto da tela avisa que estica e amplia no jogo", CutsceneFields.warnings(row(0, 0, 0, 67, 67, 2, 0, 0), 5, false).get(0).contains("esticada"), true);
        java.util.List<String> wf = CutsceneFields.warnings(row(0, 0, 2, 67, 67, 2, 0, 0), 5, false);
        check("Frente avisa do 1:1 com faixas", wf.size() == 1 && wf.get(0).contains("1:1"), true);
        check("eventos 8/9 no Fundo sem tela cheia avisam que ficam atras do cenario", CutsceneFields.warnings(row(0, 0, 0, 143, 144, 2, 0, 0), 8, false).toString().contains("atrás do cenário"), true);
        check("8/9 no Fundo com tela cheia (camera 1): sem esse aviso", CutsceneFields.warnings(row(0, 0, 0, 143, 144, 1, 0, 0), 8, false).toString().contains("atrás do cenário"), false);
        check("Fundo comum: escapa do zoom na trava", CutsceneFields.warnings(world, 5, false).toString().contains("escapa do zoom"), true);
        check("sem animacao: nenhum aviso de camada", CutsceneFields.warnings(row(0, 0, 0, 0, 0, 2, 0, 1), 5, false).toString().contains("esticada"), false);
        check("travar em ANO de projetil avisa", CutsceneFields.warnings(row(0, 0, 0, 40, 40, 0, 1, 0), 5, true).get(0).contains("projétil"), true);
        check("camera 1 avisa da tela cheia; FLAG 13 avisa do 1o tick", CutsceneFields.warnings(screen, 0, false).get(0).contains("Tela cheia") + ":" + CutsceneFields.warnings(row(0, 0, 0, 0, 0, 0, 0, 13), 19, false).get(0).contains("1º tick"), "true:true");
        System.out.println("CutsceneFieldsTest fails=" + fails);
    }

    static String zeros(int n) { StringBuilder b = new StringBuilder(); for (int i = 0; i < n; i++) b.append(i > 0 ? ", " : "").append("&00"); return b.toString(); }
}
