package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/**
 * Cutscenes da flag 20 (task md 996 do jogo, tabela HDAT 13): posicao (_SetXY antes do _ActReq), duracao (morre sem ser
 * desenhada no tick do fim), mapas de camera/teleporte e stun (md 925). Cada expectativa vem do TCBManajer.java do jogo.
 */
public class CutsceneTest {
    static final int PX = 65536;

    /** Personagem com 1 golpe (ANO 40) e a tabela HDAT 13 dada (linha = {alvo, sync, z, animN, animF, cam, stun, mapa}). */
    static CharData chrEv(int[]... rows) throws Exception {
        byte[][] t = new byte[40][];
        int[] cols = new int[40], rowsN = new int[40];
        for (int i = 0; i < 40; i++) t[i] = new byte[0];
        t[4] = move(new int[]{2, 40});
        cols[4] = 48;
        rowsN[4] = 1;
        Buf ev = new Buf();
        for (int[] r : rows) for (int v : r) ev.u16(v);
        t[13] = ev.get();
        cols[13] = 8;
        rowsN[13] = rows.length;
        return CharData.read(hdat(t, cols, rowsN));
    }

    /** Dac do atacante: ANO 40 = frame 0 (10 ticks) com os hits dados, frame 1 (10 ticks), frame 2 (40 ticks). */
    static Dac atkDac(int[]... hits) throws Exception {
        A[] a = new A[45];
        for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
        M m0 = new M().time(10);
        for (int[] h : hits) m0.hit(h);
        a[40] = new A().mpt(m0).mpt(new M().time(10)).mpt(new M().time(40));
        return dac(a);
    }

    /** Pack effect: ANO 20/21 = cutscene de 50 ticks que anda 3 px/tick; ANO 22 tem um link (ANO 23) que anda 2 px/tick. */
    static Dac fxDac() throws Exception {
        A[] a = new A[30];
        for (int i = 0; i < 30; i++) a[i] = new A().mpt(new M().time(50));
        a[20] = new A().mpt(new M().time(50).speedX(3 * PX));
        a[21] = new A().mpt(new M().time(50).speedX(3 * PX));
        a[23] = new A().mpt(new M().time(50).speedX(2 * PX));
        Dac d = dac(a);
        Ano p = d.getAno(22);
        d.setAno(22, new Ano(22, true, p.flags, p.priority, new Ano.Link[]{new Ano.Link(0, 0, 23)}, p.mpts));
        return d;
    }

    /** Oponente: ANO 0 com 4 frames de 3 ticks (para ver se ele congela) e hurtbox. */
    static Dac defDac() throws Exception {
        A[] a = new A[25];
        for (int i = 0; i < 25; i++) a[i] = new A().mpt(new M().time(30));
        a[0] = new A().mpt(new M().time(3).hit(1, -10, -60, 20, 60)).mpt(new M().time(3)).mpt(new M().time(3)).mpt(new M().time(3));
        return dac(a);
    }

    static BattleSim sim(CharData ch, Dac atk, Dac fx) throws Exception {
        BattleSim.edgeMode = 1;
        BattleSim.cutscenes = true;
        return new BattleSim(atk, ch, ch.moves[0], false, defDac(), fx, gd(new byte[][] {}), 300, 0, 0);
    }

    static int fxLayers(BattleSim s) {
        int n = 0;
        for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_EFFECT) n++;
        return n;
    }

    static AttackSim.Obj fxRoot(BattleSim s) {
        for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_EFFECT && l.only == null) return l.sim.root();
        for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_EFFECT) return l.sim.root();
        return null;
    }

    public static void main(String[] args) throws Exception {
        // ---- posicao: _SetXY(ancora) antes do _ActReq => raiz = ancora + 1 tick de velocidade, nunca acumula
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 0, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 5, -10, 0, 0}), fxDac());
            int ax = s.attacker().root().x;
            check("cutscene nasce no frame 0 (1a execucao da task)", s.cutsceneCount(), 1);
            check("1a execucao: raiz exatamente na ancora", fxRoot(s).x - ax - 5 * PX, 0);
            check("1a execucao: y da ancora", fxRoot(s).y, s.attacker().root().y - 10 * PX);
            s.step();
            check("2a execucao: ancora + 1 tick de velocidade", fxRoot(s).x - ax - 5 * PX, 3 * PX);
            for (int i = 0; i < 5; i++) s.step();
            check("raiz nao acumula velocidade (re-pino a cada tick)", fxRoot(s).x - ax - 5 * PX, 3 * PX);
        }

        // ---- links da cutscene voltam para a raiz a cada _SetXY (nao acumulam)
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 22, 22, 0, 0, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 5, -10, 0, 0}), fxDac());
            int ax = s.attacker().root().x;
            for (int i = 0; i < 6; i++) s.step();
            AttackSim.Obj kid = null;
            for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_EFFECT && l.sim.children().length > 0) kid = l.sim.children()[0];
            check("cutscene tem o link", kid != null, true);
            if (kid != null) check("link anda so a velocidade de 1 tick a partir da ancora", kid.x - ax - 5 * PX, 2 * PX);
        }

        // ---- duracao: a task morre no tick em que o ANO passa do sync e _KillObj tira o objeto antes do desenho
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 0, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            for (int i = 0; i < 9; i++) s.step();
            check("viva ate o tick anterior ao fim", s.cutsceneCount() + ":" + fxLayers(s), "1:1");
            s.step();
            check("no tick do fim ja nao e desenhada", s.cutsceneCount() + ":" + fxLayers(s), "0:0");
        }

        // ---- stun (md 925): o alvo congela a partir do tick seguinte e so volta quando a cutscene morre
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 1, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            AttackSim.Obj o = s.opponent().root();
            check("oponente no frame 0 ao nascer a cutscene", o.pat, 0);
            for (int i = 0; i < 10; i++) s.step();
            o = s.opponent().root();
            check("oponente congelado durante a cutscene (10 ticks)", o.pat + ":" + o.time, "0:3");
            for (int i = 0; i < 3; i++) s.step();
            o = s.opponent().root();
            check("volta 1 tick depois da morte da task", o.pat, 1);
        }

        // ---- so o 1o stun devolve o md do alvo (work[7] != 925)
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 1, 0}, new int[]{0, 2, 0, 20, 21, 0, 1, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}, new int[]{20, 0, 0, 1, 0}), fxDac());
            check("duas cutscenes", s.cutsceneCount(), 2);
            for (int i = 0; i < 13; i++) s.step();
            check("a 1a morreu (sync 1), a 2a continua", s.cutsceneCount(), 1);
            check("o 1o stun devolveu o oponente mesmo com a 2a viva", s.opponent().root().pat, 1);
        }

        // ---- mapa 3 com camera livre (cam 0): salta direto e a task morre no mesmo tick (nunca aparece)
        {
            CharData ch = chrEv(new int[]{0, 0, 0, 20, 21, 0, 0, 3});
            BattleSim.edgeMode = 1;
            BattleSim s0 = new BattleSim(atkDac(), ch, ch.moves[0], false, defDac(), fxDac(), gd(new byte[][] {}), 300, 0, 0);
            int mapLeft0 = s0.mapLeft();
            BattleSim s = sim(ch, atkDac(new int[]{20, 5, -10, 0, 0}), fxDac());
            int want = s0.attacker().root().x + 5 * PX;           // work[10] = PlayerXPos do atacante + x do hit (a cena sem flag 20 mostra onde ele nasce)
            check("mapa 3 cam 0: tela salta para o alvo no mesmo tick", s.screenLeft(), want);
            check("mapa 3 cam 0: a cutscene nunca aparece", s.cutsceneCount() + ":" + fxLayers(s), "0:0");
            // o md 19 roda depois da cutscene no mesmo tick: o atacante (5 px fora da tela) e levado para dentro do limite de tela (jogo:29064-29090)
            check("mapa 3 cam 0: o atacante entra no limite de tela do md 19", s.attacker().root().x - s.screenLeft(), 30 * PX);
            check("mapa 3 so mexe em iBackXPos (o mapa/base fica)", s.mapLeft() - mapLeft0, want - s0.screenLeft());
        }

        // ---- mapa 3 com cam != 0: a camera anda 10 px por tick ate o alvo e a task morre no tick seguinte ao chegar
        {
            CharData ch = chrEv(new int[]{0, 0, 0, 20, 21, 2, 0, 3});
            BattleSim s = sim(ch, atkDac(new int[]{20, 5, -10, 0, 0}), fxDac());
            int want = s.attacker().root().x + 5 * PX;
            int start = sim(ch, atkDac(), fxDac()).screenLeft();      // mesma cena sem a flag 20
            check("mapa 3 cam 2: 1a execucao ja anda 10 px", s.screenLeft() - start, 10 * PX);
            for (int i = 0; i < 5; i++) s.step();
            check("mapa 3 cam 2: ainda viva a caminho", s.cutsceneCount(), 1);
            s.step();
            check("mapa 3 cam 2: chegou (corta no alvo)", s.screenLeft(), want);
            check("mapa 3 cam 2: ainda desenhada no tick da chegada", s.cutsceneCount(), 1);
            s.step();
            check("mapa 3 cam 2: morre no tick seguinte", s.cutsceneCount(), 0);
        }

        // ---- mapa 10: o oponente fica preso a borda esquerda todo tick (ScreenEdgeOff reafirmado a cada tick)
        {
            CharData ch = chrEv(new int[]{0, 2, 0, 20, 21, 0, 0, 10});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            boolean ok = true;
            for (int i = 0; i < 15; i++) {
                s.step();
                ok &= s.opponentX() * PX == s.screenLeft() - 120 * PX;
            }
            check("mapa 10: oponente fora da tela, preso ao x do mapa em todos os ticks", ok, true);
        }

        // ---- mapa 13: o atacante vai para a borda, mas so aparece no tick seguinte (PlayerXPos mudou depois do _SetXY)
        {
            CharData ch = chrEv(new int[]{0, 2, 0, 20, 21, 0, 0, 13});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            check("mapa 13: no tick do frame o atacante ainda nao se mexeu", s.attacker().root().x, -180 * PX);
            s.step();
            check("mapa 13: no tick seguinte aparece na borda esquerda", s.attacker().root().x, s.screenLeft() - 120 * PX);
            s.step();
            check("mapa 13: fica la (ScreenEdgeOff do atacante)", s.attacker().root().x, s.screenLeft() - 120 * PX);
        }

        // ---- eventos 8/9 com cam != 0: _SetXY(0, 0) so no 1o tick; depois o objeto anda sozinho em coordenadas de tela
        {
            int[] z = {0, 0, 0, 0, 0, 0, 0, 0};
            CharData ch = chrEv(z, z, z, z, z, z, z, z, new int[]{0, 0, 0, 20, 21, 2, 0, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 8, 0}), fxDac());
            check("evento 8 no frame 0", s.cutsceneCount(), 1);
            check("evento 8: 1a execucao no canto da tela", fxRoot(s).x, s.screenLeft());
            for (int i = 0; i < 4; i++) s.step();
            check("evento 8: anda 3 px/tick em coordenadas de tela", fxRoot(s).x - s.screenLeft(), 12 * PX);
        }

        // ---- trava cinematica (md 923/926): o oponente (md 925) so e solto pela task 924, 10 ticks depois do fim da trava
        {
            CharData ch = chrEv(new int[]{0, 0, 0, 20, 21, 0, 0, 0});
            BattleSim.cinematic = true;
            BattleSim s = sim(ch, atkDac(), fxDac());
            s.setSpecialType(9);
            for (int i = 0; i < 122; i++) s.step();
            check("trava acabou", s.cinematicActive(), false);
            check("oponente parado durante a trava", s.opponent().root().pat + ":" + s.opponent().root().time, "0:3");
            // task 924: o atacante ainda esta em md 928 no 1o tick depois da trava (nao conta); depois 10 ticks e solta no seguinte
            for (int i = 0; i < 11; i++) s.step();
            check("oponente continua parado 11 ticks depois da trava", s.opponent().root().pat + ":" + s.opponent().root().time, "0:3");
            s.step();
            check("e anda no 12o", s.opponent().root().time, 2);
        }

        // ---- flag 20 num ANO de PROJETIL (md 971 chama CheckOptFlag): a cutscene vive enquanto o projetil existir
        {
            byte[][] t = new byte[40][];
            int[] cols = new int[40], rowsN = new int[40];
            for (int i = 0; i < 40; i++) t[i] = new byte[0];
            t[4] = move(new int[]{2, 40}, new int[]{4, 30});
            cols[4] = 48;
            rowsN[4] = 1;
            Buf ev = new Buf();
            for (int v : new int[]{0, 0, 0, 20, 21, 0, 0, 0}) ev.u16(v);
            t[13] = ev.get();
            cols[13] = 8;
            rowsN[13] = 1;
            CharData ch = CharData.read(hdat(t, cols, rowsN));
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(2).hit(0, 30, -40, 0, 0)).mpt(new M().time(60));
            a[30] = new A().mpt(new M().time(8).hit(20, 0, 0, 0, 0)).mpt(new M().time(8));
            BattleSim s = sim(ch, dac(a), fxDac());
            check("sem cutscene antes do projetil existir", s.cutsceneCount(), 0);
            s.step();
            check("cutscene criada pelo projetil", s.cutsceneCount(), 1);
            for (int i = 0; i < 6; i++) s.step();
            check("viva com o projetil", s.cutsceneCount(), 1);
            for (int i = 0; i < 30; i++) s.step();
            check("morre quando o projetil morre", s.cutsceneCount(), 0);
        }

        // ---- flag 20 num ANO do OPONENTE (HDAT 13 do oponente): o stun cai no ATACANTE
        {
            CharData ch = chrEv();
            CharData och = chrEv(new int[]{0, 1, 0, 20, 21, 0, 1, 0});
            A[] d = new A[25];
            for (int i = 0; i < 25; i++) d[i] = new A().mpt(new M().time(30));
            d[0] = new A().mpt(new M().time(3).hit(1, -10, -60, 20, 60).hit(20, 0, 0, 0, 0)).mpt(new M().time(3)).mpt(new M().time(3));
            BattleSim.edgeMode = 1;
            BattleSim.cutscenes = true;
            BattleSim s = new BattleSim(atkDac(), ch, ch.moves[0], false, dac(d), fxDac(), gd(new byte[][] {}), 300, 0, 0);
            s.setOpponentChar(och);
            check("cutscene do oponente criada", s.cutsceneCount(), 1);
            for (int i = 0; i < 12; i++) s.step();
            // a cutscene dura 3 ticks (sync 1 frame do oponente, de 3 ticks): o atacante fica parado nos ticks 1-3 e anda nos 9 seguintes
            check("atacante congelado enquanto dura (md 925)", s.attacker().root().pat + ":" + s.attacker().root().time, "0:1");
            s.step();
            check("e volta a andar depois", s.attacker().root().pat, 1);
        }

        // ---- OPT 2048 fora de uma parede aborta CheckOptFlag: a flag 20 nao dispara
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 0, 0});
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(10).hit(20, 0, 0, 0, 0).optFlag(2048)).mpt(new M().time(10));
            BattleSim s = sim(ch, dac(a), fxDac());
            check("flag 20 com OPT 2048 nao dispara", s.cutsceneCount(), 0);
        }

        // ---- mapa 5: a camera passa a centralizar o alvo (iBackXOffset) em passos de 12 px por tick
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 0, 5});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            int start = sim(ch, atkDac(), fxDac()).screenLeft();
            for (int i = 0; i < 5; i++) s.step();
            check("mapa 5: 12 px por tick desde o tick 0 (a camera roda depois da cutscene no 1o tick do jogo)", s.screenLeft() - start, 72 * PX);
        }

        // ---- ordem de desenho: tudo junto por (prio - iActPrio); evento 8 (z 10) fica sob a sombra (17), z 200 sobre os lutadores
        {
            int[] z = {0, 0, 0, 0, 0, 0, 0, 0};
            CharData ch = chrEv(new int[]{0, 0, 0, 20, 21, 2, 0, 0}, z, z, z, z, z, z, z, new int[]{0, 0, 0, 20, 21, 2, 0, 0});
            BattleSim s8 = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            int iCut = -1, iShadow = -1, iBody = -1, n = 0;
            for (BattleSim.Layer l : s8.layers()) {
                if (l.owner == BattleSim.OWNER_EFFECT && iCut < 0) iCut = n;
                if (l.owner == BattleSim.OWNER_SHADOW && iShadow < 0) iShadow = n;
                if (l.owner == BattleSim.OWNER_ATTACKER && iBody < 0) iBody = n;
                n++;
            }
            check("cutscene z 200 desenhada depois do corpo e da sombra", iCut > iBody && iBody > iShadow, true);
            BattleSim s7 = sim(ch, atkDac(new int[]{20, 0, 0, 8, 0}), fxDac());
            iCut = -1; iShadow = -1; n = 0;
            for (BattleSim.Layer l : s7.layers()) {
                if (l.owner == BattleSim.OWNER_EFFECT && iCut < 0) iCut = n;
                if (l.owner == BattleSim.OWNER_SHADOW && iShadow < 0) iShadow = n;
                n++;
            }
            check("evento 8 (z 10) fica sob a sombra (z 17)", iCut >= 0 && iCut < iShadow, true);
        }

        // ---- bobj: ALVO >= 2 usa o pack bobjNN; sem a pasta nada e desenhado
        {
            CharData ch = chrEv(new int[]{2, 1, 0, 20, 21, 0, 0, 0});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            check("sem bobj nada e desenhado", s.cutsceneCount() + ":" + s.lastHit().contains("bobj"), "1:true");
            for (BattleSim.Layer l : s.layers()) check("nenhuma camada de bobj", l.owner == BattleSim.OWNER_BOBJ, false);
            s.setBobjDac(fxDac());
            int n = 0;
            for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_BOBJ) n++;
            check("com bobj a cutscene entra como OWNER_BOBJ", n, 1);
        }

        // ---- painel do evento e Saver
        {
            CharData ch = chrEv(new int[]{0, 12, 0, 20, 21, 2, 1, 3}, new int[]{1, 0, 0, 22, 23, 0, 0, 0});
            String t = CutsceneInfo.describe(ch, 0, 0, 0);
            check("painel: pack, duracao, stun e flag", t.contains("effect.pac") && t.contains("12 frame") && t.contains("Congela") && t.contains("FLAG 3"), true);
            check("painel: stun do FLAG 3 avisa que nunca solta", t.contains("nunca e desfeito"), true);
            check("painel: id inexistente", CutsceneInfo.describe(ch, 9, 0, 0).contains("nao existe"), true);
            check("painel: x/y ignorados com cam != 0", CutsceneInfo.describe(chrEv(new int[]{0, 5, 0, 20, 21, 2, 0, 0}), 0, 4, 0).contains("ignora o x/y"), true);
            check("painel: cam 0 usa o x/y (sem aviso)", CutsceneInfo.describe(chrEv(new int[]{0, 5, 0, 20, 21, 0, 0, 0}), 0, 4, 0).contains("ignora"), false);
            check("painel: linhas do HDAT 13", ch.eventRows() + "x" + ch.eventCols(), "2x8");
            check("evento 1 le o ALVO 1", ch.eventField(1, 0), 1);
            Dac d = atkDac(new int[]{20, 0, 0, 1, 0});
            java.util.TreeSet<Integer> anos = Saver.anosOfMove(d, ch.moves[0], ch);
            check("Saver inclui as ANOs da cutscene do pack do personagem", anos.contains(22) && anos.contains(23), true);
            check("Saver sem o personagem nao as conhece", Saver.anosOfMove(d, ch.moves[0]).contains(22), false);
        }

        // ---- mapa 2: o alvo derrotado some (com sombra) para sempre
        {
            CharData ch = chrEv(new int[]{0, 1, 0, 20, 21, 0, 0, 2});
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(2).hit(2, 20, -40, 60, 30).opt1(3).dmg(250)).mpt(new M().time(20).hit(20, 0, 0, 0, 0)).mpt(new M().time(30));
            BattleSim.edgeMode = 1;
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) }), 60, 0, 0);
            boolean seen = false;
            for (int i = 0; i < 3; i++) {
                s.step();
                for (BattleSim.Layer l : s.layers()) seen |= l.owner == BattleSim.OWNER_DEFENDER;
            }
            check("oponente derrotado no 1o hit", s.opponentDead(), true);
            for (int i = 0; i < 10; i++) s.step();
            boolean still = false;
            for (BattleSim.Layer l : s.layers()) still |= l.owner == BattleSim.OWNER_DEFENDER || l.owner == BattleSim.OWNER_SHADOW && l.sim.root().x == s.opponentX() * PX;
            check("mapa 2: alvo derrotado nao e mais desenhado", seen && !still, true);
        }

        // ---- oponente em stun (md 925): o PlayerTail pula so o _ActReq; o _SetXY continua levando-o para a posicao logica
        {
            CharData ch = chrEv(new int[]{0, 2, 0, 20, 21, 0, 1, 10});
            BattleSim s = sim(ch, atkDac(new int[]{20, 0, 0, 0, 0}), fxDac());
            for (int i = 0; i < 4; i++) s.step();
            check("stun + mapa 10: oponente desenhado na posicao logica (borda esquerda)", s.opponent().root().x, s.opponentX() * PX);
            check("e ela e a borda da tela", s.opponentX() * PX, s.screenLeft() - 120 * PX);
        }

        System.out.println("CutsceneTest fails=" + BattleTest.fails);
    }
}
