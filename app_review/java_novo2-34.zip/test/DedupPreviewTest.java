package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** COMPARAR (fase/legenda/duracao) e VER ANOS (ANOs afetadas e DAC de previa sem tocar no real). */
public class DedupPreviewTest {
    static SpriteDedup.Sig sig(int idx, int[] px, int w, int h) { return SpriteDedup.sig(idx, px, w, h, w, h); }

    public static void main(String[] args) throws Exception {
        // ---- compare
        check("fase: 0-399 ms = a que fica, 400-799 = a comparada, 800 volta", DedupCompare.phaseAt(0, 400) + "" + DedupCompare.phaseAt(399, 400) + DedupCompare.phaseAt(400, 400) + DedupCompare.phaseAt(799, 400) + DedupCompare.phaseAt(800, 400), "00110");
        check("fase com 200 ms", DedupCompare.phaseAt(450, 200) + "" + DedupCompare.phaseAt(650, 200), "01");
        check("tempo negativo ou duracao 0 nao quebra", DedupCompare.phaseAt(-5, 400) + "" + DedupCompare.phaseAt(100, 0), "00");
        check("padrao 400 ms", DedupCompare.DEFAULT_MS, 400);
        check("ciclo de duracoes 200 > 400 > 800 > 1200 > 200", DedupCompare.nextDuration(200) + ":" + DedupCompare.nextDuration(400) + ":" + DedupCompare.nextDuration(800) + ":" + DedupCompare.nextDuration(1200) + ":" + DedupCompare.nextDuration(333), "400:800:1200:200:400");
        check("legenda: SPR_0(mantida) e depois SPR_7(removida)", DedupCompare.caption(0, 0, 7, true) + "|" + DedupCompare.caption(1, 0, 7, true), "SPR_0(mantida)|SPR_7(removida)");
        check("legenda: com a chave em MANTER, SPR_7(mantida)", DedupCompare.caption(1, 0, 7, false), "SPR_7(mantida)");
        check("a chave inverte", DedupCompare.toggled(false) + ":" + DedupCompare.toggled(true), "true:false");

        // ---- VER ANOS
        int[] big = SpriteScaleTest.art(3, 64, 64, 4);
        int[] small = SpriteScaleTest.boxResize(big, 64, 64, 32, 32);
        SpriteDedup.Sig K = sig(0, big, 64, 64), R = sig(1, small, 32, 32);
        SpriteDedup.Match m = SpriteDedup.best(R, K, 80);
        check("a copia casa com a grande", m != null, true);
        SpriteDedup.Choice c = new SpriteDedup.Choice();
        c.removed = R; c.kept = K; c.match = m;
        // ANO 0 usa R (frames 1 e 3) e K (frame 2); ANO 1 so K; ANO 2 so R; ANO 3 vazia de sprites do grupo (imagem 9)
        Dac d = dac(new A().mpt(new M().time(4).img(1)).mpt(new M().time(4).img(0)).mpt(new M().time(4).img(1)),
                new A().mpt(new M().time(4).img(0)),
                new A().mpt(new M().time(4).img(1)),
                new A().mpt(new M().time(4).img(9)));
        List<Integer> group = Arrays.asList(Integer.valueOf(0), Integer.valueOf(1));
        check("ANOs que usam as sprites do grupo", DedupPreview.affected(d, group).toString(), "[0, 1, 2]");
        check("ANOs que usam so a removida", DedupPreview.affected(d, Arrays.asList(Integer.valueOf(1))).toString(), "[0, 2]");
        check("linha da ANO 0", DedupPreview.line(d, 0, group), "Ano 0 · SPR_0, SPR_1 (Frames 1, 2, 3)");
        DedupPreview.Result pr = DedupPreview.preview(d, Arrays.asList(c));
        check("previa: ANOs 0 e 2 mudam, 1 e 3 nao", pr.changedAnos.toString(), "[0, 2]");
        check("previa: ANO 0 passa a usar so a sprite 0", pr.dac.getAno(0).mpts[0].image + "," + pr.dac.getAno(0).mpts[1].image + "," + pr.dac.getAno(0).mpts[2].image, "0,0,0");
        Ano.Mpt n = pr.dac.getAno(0).mpts[0];
        check("previa: o frame ganhou zoom 50% (a grande cobre o espaco da pequena)", n.xZoom + ":" + n.yZoom, "50:50");
        check("o DAC real nao mudou", d.getAno(0).mpts[0].image + "," + d.getAno(2).mpts[0].image, "1,1");
        check("ANOs que nao mudam sao as mesmas", pr.dac.getAno(1) == d.getAno(1) && pr.dac.getAno(3) == d.getAno(3), true);
        check("sem sprites removidas a previa e identica", DedupPreview.preview(d, new ArrayList<SpriteDedup.Choice>()).dac.getAno(0).mpts[0].image, 1);

        // ANO filha de link: sem trocar Flip. Relacao espelhada nao tem solucao -> a sprite fica e a ANO nao muda
        int[] mir = SpriteVerifyTest.variant(3, 64, 64, 2);     // so para ter outro desenho; abaixo usamos a espelhada de verdade
        int[] flipped = new int[big.length];
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) flipped[y * 64 + x] = big[y * 64 + (63 - x)];
        SpriteDedup.Sig Rf = sig(1, flipped, 64, 64);
        SpriteDedup.Match mf = SpriteDedup.best(Rf, K, 80);
        check("a espelhada casa com g=1 (espelho horizontal)", mf != null && mf.g == 1, true);
        SpriteDedup.Choice cf = new SpriteDedup.Choice();
        cf.removed = Rf; cf.kept = K; cf.match = mf;
        Dac d2 = dac(new A().mpt(new M().time(4).img(0)), new A().mpt(new M().time(4).img(1)));
        Ano a0 = d2.getAno(0);
        Dac d3 = d2.copyWith(0, new Ano(0, true, a0.flags, a0.priority, new Ano.Link[]{new Ano.Link(0, 0, 1)}, a0.mpts));      // ANO 1 e filha da ANO 0
        DedupPreview.Result pf = DedupPreview.preview(d3, Arrays.asList(cf));
        check("ANO filha de link: espelho nao se resolve com Flip, a sprite fica (skipped) e a ANO nao muda", pf.skipped.contains(Integer.valueOf(1)) && pf.dac.getAno(1).mpts[0].image == 1 && pf.changedAnos.isEmpty(), true);
        Dac d4 = dac(new A().mpt(new M().time(4).img(0)), new A().mpt(new M().time(4).img(1)));
        DedupPreview.Result pf2 = DedupPreview.preview(d4, Arrays.asList(cf));
        check("fora de link o espelho vira Flip X", pf2.skipped.isEmpty() && pf2.dac.getAno(1).mpts[0].image == 0 && pf2.dac.getAno(1).mpts[0].wActFlag != 0, true);
    }
}
