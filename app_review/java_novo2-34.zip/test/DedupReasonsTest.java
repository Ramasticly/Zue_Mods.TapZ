package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** Por que sprites marcadas nao sairam: codigos de SpriteXform, motivo registrado pelo apply, lista da tela pos-remocao. */
public class DedupReasonsTest {
    static SpriteDedup.Sig sig(int idx, int[] px, int w, int h) { return SpriteDedup.sig(idx, px, w, h, w, h); }

    public static void main(String[] args) throws Exception {
        // ---- nomes
        check("1 sprite", DedupReasons.names(Arrays.asList(3)), "SPR_3");
        check("2 sprites", DedupReasons.names(Arrays.asList(3, 7)), "SPR_3 e 7");
        check("3 sprites", DedupReasons.names(Arrays.asList(3, 7, 9)), "SPR_3, 7 e 9");
        check("4 sprites", DedupReasons.names(Arrays.asList(3, 7, 9, 12)), "SPR_3, 7, 9 e 12");

        // ---- codigos de SpriteXform.whyNot
        Ano.Mpt plain = new Ano.Mpt();
        plain.image = 1;
        double[] rot30 = SpriteVerifyTest.rotMap(30);
        Ano.Mpt squashed = plain.copy();
        squashed.flags |= 0x80; squashed.hasRaz = true; squashed.xZoom = 100; squashed.yZoom = 50; squashed.rot = 0;
        check("esticada so num lado + mapa girado 30: eixos nao ortogonais", SpriteXform.whyNot(squashed, 40, 40, 40, 40, rot30, true), SpriteXform.WHY_ORTHO);
        check("zoom que daria 0 (3 px -> 1000 px): zoom fora do limite ou erro", SpriteXform.whyNot(plain, 3, 3, 1000, 1000, SpriteXform.G[0], true) == SpriteXform.WHY_ZOOM || SpriteXform.whyNot(plain, 3, 3, 1000, 1000, SpriteXform.G[0], true) == SpriteXform.WHY_ERROR, true);
        check("erro de posicao: 40 px -> 3000 px (zoom 1% e inteiro demais)", SpriteXform.whyNot(plain, 40, 40, 3000, 3000, SpriteXform.G[0], true), SpriteXform.WHY_ERROR);
        check("espelho sem poder trocar Flip (ANO filha de link): WHY_FLIP", SpriteXform.whyNot(plain, 40, 40, 40, 40, SpriteXform.G[1], false), SpriteXform.WHY_FLIP);
        check("o mesmo espelho com Flip liberado: tem solucao", SpriteXform.whyNot(plain, 40, 40, 40, 40, SpriteXform.G[1], true), SpriteXform.WHY_NONE);
        check("sem flip e sem mudar nada: tem solucao", SpriteXform.whyNot(plain, 40, 40, 40, 40, SpriteXform.G[0], false), SpriteXform.WHY_NONE);

        // ---- apply registra o primeiro Frame que falhou
        int[] big = SpriteScaleTest.art(3, 64, 64, 4);
        int[] flipped = new int[big.length];
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) flipped[y * 64 + x] = big[y * 64 + (63 - x)];
        SpriteDedup.Sig K = sig(0, big, 64, 64), R = sig(1, flipped, 64, 64);
        SpriteDedup.Match m = SpriteDedup.best(R, K, 80);
        SpriteDedup.Choice c = new SpriteDedup.Choice();
        c.removed = R; c.kept = K; c.match = m;
        Dac d = dac(new A().mpt(new M().time(4).img(0)), new A().mpt(new M().time(4).img(0)).mpt(new M().time(4).img(1)));
        Ano a0 = d.getAno(0);
        d = d.copyWith(0, new Ano(0, true, a0.flags, a0.priority, new Ano.Link[]{new Ano.Link(0, 0, 1)}, a0.mpts));          // ANO 1 e filha da ANO 0
        SpriteDedup.Result res = SpriteDedup.apply(d, Arrays.asList(c));
        SpriteDedup.Reason why = res.reasons.get(Integer.valueOf(1));
        check("a sprite espelhada em ANO filha de link fica", res.removedSprites.isEmpty() && res.skipped.contains(Integer.valueOf(1)), true);
        check("motivo: FLIP, ANO 1, Frame 2 (o Frame que usa a sprite)", why != null && why.code == SpriteXform.WHY_FLIP && why.ano == 1 && why.frame == 2, true);

        // ---- lista da tela: sem substituta + Frame sem solucao + numeros novos
        SpriteDedup.Result r2 = new SpriteDedup.Result();
        r2.removedSprites.add(Integer.valueOf(2));
        r2.skipped.add(Integer.valueOf(5));
        r2.reasons.put(Integer.valueOf(5), new SpriteDedup.Reason(SpriteXform.WHY_FLIP, 4, 1));
        int[] map = SpriteRenumber.map(10, new boolean[]{false, false, true, false, false, false, false, false, false, false});
        List<DedupReasons.Entry> es = DedupReasons.notRemoved(Arrays.asList(2, 5, 8), r2, map);
        check("a removida (2) nao entra; ficam 5 e 8", es.size(), 2);
        check("numeros novos pela renumeracao (5 -> 4, 8 -> 7)", es.get(0).oldSprite + ">" + es.get(0).newSprite + "," + es.get(1).oldSprite + ">" + es.get(1).newSprite, "5>4,8>7");
        check("a 5 tem motivo do apply (FLIP); a 8 nao tinha substituta", es.get(0).code + "," + es.get(1).code, SpriteXform.WHY_FLIP + "," + DedupReasons.NO_REPLACEMENT);
        check("linha 'Foram mantidas' usa os numeros novos", DedupReasons.names(DedupReasons.newNumbers(es)), "SPR_4 e 7");
        String t = DedupReasons.explain(es.get(0));
        check("texto: nome novo e antigo, motivo em termos simples e onde", t.startsWith("SPR_4 (antes SPR_5): Ela aparece numa ANO que é usada como link") && t.endsWith("Onde: ANO 4, Frame 1."), true);
        check("sem substituta nao tem 'Onde'", DedupReasons.explain(es.get(1)).contains("Onde:"), false);
        check("nenhuma entrada quando tudo saiu", DedupReasons.notRemoved(Arrays.asList(2), r2, map).isEmpty(), true);
        List<String> bodies = new ArrayList<String>();
        for (int code : new int[]{SpriteXform.WHY_FLIP, SpriteXform.WHY_ORTHO, SpriteXform.WHY_ZOOM, SpriteXform.WHY_ERROR, SpriteXform.WHY_DEGENERATE, DedupReasons.NO_REPLACEMENT}) if (!bodies.contains(DedupReasons.body(code))) bodies.add(DedupReasons.body(code));
        check("cada motivo tem frase propria", bodies.size(), 6);

        // ---- selo da maior e rotulo da acao
        SpriteDedup.Group g = new SpriteDedup.Group();
        for (int idx : new int[]{5, 8, 9}) { SpriteDedup.Member mem = new SpriteDedup.Member(); mem.index = idx; g.members.add(mem); }
        DedupMarks mk = new DedupMarks(new ArrayList<SpriteDedup.Group>(Arrays.asList(g)));
        mk.set(g, 9, true);
        check("selos: maior = MANTER (FIXA), marcada = REMOVER, outra = MANTER", mk.chip(g, 5) + "|" + mk.chip(g, 9) + "|" + mk.chip(g, 8), "MANTER (FIXA)|REMOVER|MANTER");
        check("botao da comparacao e a acao: marcada -> MANTER, nao marcada -> REMOVER", DedupCompare.actionLabel(true) + "|" + DedupCompare.actionLabel(false), "MANTER|REMOVER");

        // ---- VER ANOS: o bit de loop continua depois da reescrita (ANTES e DEPOIS se comportam igual)
        int[] big2 = SpriteScaleTest.art(3, 64, 64, 4), small2 = SpriteScaleTest.boxResize(big2, 64, 64, 32, 32);
        SpriteDedup.Sig K2 = sig(0, big2, 64, 64), R2 = sig(1, small2, 32, 32);
        SpriteDedup.Choice c2 = new SpriteDedup.Choice();
        c2.removed = R2; c2.kept = K2; c2.match = SpriteDedup.best(R2, K2, 80);
        Dac dl = dac(new A().mpt(new M().time(4).img(1)).mpt(new M().time(4).img(1).act(1)), new A().mpt(new M().time(4).img(1)).mpt(new M().time(4).img(1)));
        check("antes: a ANO 0 tem loop e a 1 nao", ObjModel.loops(dl.getAno(0).mpts) + ":" + ObjModel.loops(dl.getAno(1).mpts), "true:false");
        DedupPreview.Result pr = DedupPreview.preview(dl, Arrays.asList(c2));
        check("depois: o loop continua so na ANO 0, mesmo com a imagem trocada", ObjModel.loops(pr.dac.getAno(0).mpts) + ":" + ObjModel.loops(pr.dac.getAno(1).mpts) + ":" + pr.dac.getAno(0).mpts[1].image, "true:false:0");
    }
}
