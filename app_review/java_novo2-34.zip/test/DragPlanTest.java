package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** Arrastar sprites: a linha sob o dedo sem contar a arrastada (subir funciona), unidades (GIF) e quem sobe/desce. */
public class DragPlanTest {
    public static void main(String[] args) throws Exception {
        // 6 linhas de 100 px (0-100, 100-200...)
        int[] tops = {0, 100, 200, 300, 400, 500}, bottoms = {100, 200, 300, 400, 500, 600};
        check("dedo no meio da linha 4, arrastada = 2: acha a 4", DragPlan.hit(tops, bottoms, 2, 450f), 4);
        check("SUBIR: arrastada = 4, dedo na linha 1: acha a 1 (antes devolvia a propria arrastada)", DragPlan.hit(tops, bottoms, 4, 150f), 1);
        check("a linha arrastada nunca e alvo: dedo sobre ela acha a vizinha mais proxima", DragPlan.hit(tops, bottoms, 3, 350f) == 2 || DragPlan.hit(tops, bottoms, 3, 350f) == 4, true);
        check("acima da primeira = a primeira; abaixo da ultima = a ultima", DragPlan.hit(tops, bottoms, 3, -40f) + ":" + DragPlan.hit(tops, bottoms, 3, 900f), "0:5");
        check("so a arrastada = -1", DragPlan.hit(new int[]{0}, new int[]{100}, 0, 50f), -1);
        check("divisor entre linhas (y = 100): vai para a de baixo", DragPlan.hit(tops, bottoms, 5, 100f), 1);

        // lista: 0 sprite 0 | 1 sprite 1 | 2 GIF aberto (cabecalho idx 2) | 3,4,5 quadros 2..4 | 6 GIF encolhido (idx 6..7) | 7 sprite 8
        final List<int[]> rows = new ArrayList<int[]>(Arrays.asList(new int[]{0, 0}, new int[]{0, 1}, new int[]{2, 2}, new int[]{0, 2}, new int[]{0, 3}, new int[]{0, 4}, new int[]{1, 6}, new int[]{0, 8}));
        DragPlan.Groups g = new DragPlan.Groups() {
            public int firstOf(int s) { return s >= 2 && s <= 4 ? 2 : s >= 6 && s <= 7 ? 6 : -1; }
            public int lastOf(int s) { return s >= 2 && s <= 4 ? 4 : s >= 6 && s <= 7 ? 7 : -1; }
        };
        check("unidade: sprite solta", Arrays.toString(DragPlan.unit(rows, 1, g)), "[1, 1]");
        check("unidade: GIF aberto inteiro (cabecalho + 3 quadros) a partir de um quadro", Arrays.toString(DragPlan.unit(rows, 4, g)), "[2, 5]");
        check("unidade: a partir do cabecalho", Arrays.toString(DragPlan.unit(rows, 2, g)), "[2, 5]");
        check("unidade: GIF encolhido", Arrays.toString(DragPlan.unit(rows, 6, g)), "[6, 6]");
        check("soltar descendo sobre um quadro do GIF aberto cai DEPOIS do GIF todo", DragPlan.insertionPos(rows, 4, 0, g), 6);
        check("soltar subindo sobre um quadro do GIF aberto cai ANTES do GIF todo", DragPlan.insertionPos(rows, 4, 7, g), 2);
        check("descendo sobre sprite solta: depois dela; subindo: antes", DragPlan.insertionPos(rows, 1, 0, g) + ":" + DragPlan.insertionPos(rows, 1, 7, g), "2:1");
        check("descendo, as do meio SOBEM: p0=0 e insercao antes da 4 -> linhas 1..3", Arrays.toString(DragPlan.shifted(0, 4)), "[1, 3, -1]");
        check("subindo, as do meio DESCEM: p0=5 e insercao antes da 2 -> linhas 2..4", Arrays.toString(DragPlan.shifted(5, 2)), "[2, 4, 1]");
        // arrastar ate o topo: dedo acima da primeira linha (lista no topo) = antes dela = SPR_0
        int topHit = DragPlan.hit(tops, bottoms, 4, -60f);
        check("acima da primeira linha: alvo e a linha 0 e a insercao e antes dela (vira SPR_0)", topHit + ":" + DragPlan.insertionPos(rows, topHit, 4, g), "0:0");
        check("ao subir ate o topo todas as do caminho descem uma linha", Arrays.toString(DragPlan.shifted(4, 0)), "[0, 3, 1]");
        // slot vermelho (origem) + azul (destino): as vizinhas NAO preenchem a origem
        check("descendo: da insercao ate o fim descem; as do meio ficam e a origem fica livre", Arrays.toString(DragPlan.pushed(0, 4)), "[4, " + Integer.MAX_VALUE + ", 1]");
        check("subindo: de insercao ate antes da origem descem; as de depois da origem ficam", Arrays.toString(DragPlan.pushed(5, 2)), "[2, 4, 1]");
        check("insercao colada na origem (antes dela ou logo depois): sem azul e ninguem se mexe", Arrays.toString(DragPlan.pushed(3, 3)) + Arrays.toString(DragPlan.pushed(3, 4)), "[0, -1, 0][0, -1, 0]");
        check("azul so quando a ordem muda", DragPlan.blueAt(3, 3) + "," + DragPlan.blueAt(3, 4) + "," + DragPlan.blueAt(3, 5) + "," + DragPlan.blueAt(3, 2), "false,false,true,true");
        boolean originMoves = false;
        for (int p0 = 0; p0 < 8; p0++) for (int ins = 0; ins <= 8; ins++) {
            int[] pu = DragPlan.pushed(p0, ins);
            if (pu[2] != 0 && p0 >= pu[0] && p0 <= pu[1]) originMoves = true;
        }
        check("a linha de origem nunca esta entre as que descem (o vermelho fica parado)", originMoves, false);
        // bloco de 3 linhas a partir da 4 (linhas 4,5,6)
        check("bloco descendo: da insercao ate o fim descem", Arrays.toString(DragPlan.pushed(4, 3, 9)), "[9, " + Integer.MAX_VALUE + ", 1]");
        check("bloco subindo: de insercao ate antes do bloco descem", Arrays.toString(DragPlan.pushed(4, 3, 1)), "[1, 3, 1]");
        check("bloco: insercao colada (4 ou 7) = sem azul e ninguem se mexe", DragPlan.blueAt(4, 3, 4) + "," + DragPlan.blueAt(4, 3, 7) + "," + Arrays.toString(DragPlan.pushed(4, 3, 7)), "false,false,[0, -1, 0]");
        check("bloco: insercao em 8 ou antes de 4 mostra o azul", DragPlan.blueAt(4, 3, 8) + "," + DragPlan.blueAt(4, 3, 3), "true,true");
        check("bloco de 1 = comportamento antigo", Arrays.toString(DragPlan.pushed(3, 1, 6)) + Arrays.toString(DragPlan.pushed(3, 6)), "[6, " + Integer.MAX_VALUE + ", 1][6, " + Integer.MAX_VALUE + ", 1]");
        check("soltar sobre o vermelho (origem) nao muda a ordem: insercao == origem -> sem azul", DragPlan.blueAt(4, 4), false);
        check("soltar no mesmo lugar (antes dela ou logo depois): ninguem se mexe", Arrays.toString(DragPlan.shifted(3, 3)) + Arrays.toString(DragPlan.shifted(3, 4)), "[0, -1, 0][0, -1, 0]");
    }
}
