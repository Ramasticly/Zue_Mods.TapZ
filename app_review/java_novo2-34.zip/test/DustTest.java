package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.List;

/** Poeira/fumaca (CheckOptFlag): tipo 1..15 da wOptFlag -> pacote/ANO, +80 quando virado, anel de 6, uma por frame, parada no mundo, filhas, parede. */
public class DustTest {
    static int count(BattleSim s, int owner) {
        int n = 0;
        for (BattleSim.Layer l : s.layers()) if (l.owner == owner && l.firstOfSim) n++;
        return n;
    }

    static Dac packWith(int total, int... longAnos) throws Exception {
        A[] a = new A[total];
        for (int i = 0; i < total; i++) a[i] = new A().mpt(new M().time(2));
        for (int k : longAnos) a[k] = new A().mpt(new M().time(120));
        return dac(a);
    }

    static BattleSim make(boolean left, M[] frames, Dac bobj, Dac fx) throws Exception {
        A[] atk = new A[41];
        for (int i = 0; i < 41; i++) atk[i] = new A().mpt(new M().time(1));
        A a = new A();
        for (M f : frames) a.mpt(f);
        atk[40] = a;
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], left, dac(def), fx, gd(new byte[][] {}), 400, 0, 0);
        if (bobj != null) s.setBobjDac(bobj);
        return s;
    }

    public static void main(String[] args) throws Exception {
        // ---- tabela tipo -> pacote / ANO (puro)
        StringBuilder t = new StringBuilder();
        for (int ty = 1; ty <= 15; ty++) t.append(ObjModel.dustPack(ty)).append(':').append(ObjModel.dustAno(ty)).append(' ');
        check("tipos 1-5 = bobj 10-14; 6-7 = effect 78-79; 8-15 = effect 70-77", t.toString().trim(),
                "0:10 0:11 0:12 0:13 0:14 1:78 1:79 1:70 1:71 1:72 1:73 1:74 1:75 1:76 1:77");
        check("tipo fora de 1..15 = nenhum", ObjModel.dustPack(0) + ":" + ObjModel.dustPack(16) + ":" + ObjModel.dustAno(0), "-1:-1:-1");
        check("tipo dos bits 12-15 da wOptFlag", ObjModel.dustTypeOf(4096 * 5 + 512) + ":" + ObjModel.dustTypeOf(2048), "5:0");

        // ---- tipo 3 (bobj ANO 12) numa unica frame: nasce uma fumaca do bobj
        Dac bobj = packWith(100, 12, 10, 11, 13, 14);
        Dac fx = packWith(260, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 150, 151, 158);
        BattleSim s = make(false, new M[] { new M().time(3).optFlag(4096 * 3), new M().time(30) }, bobj, fx);
        for (int i = 0; i < 3; i++) s.step();
        check("tipo 3: uma fumaca do bobj", count(s, BattleSim.OWNER_BOBJ) + ":" + count(s, BattleSim.OWNER_EFFECT), "1:0");

        // ---- tipo 8 (effect ANO 70) e virado (ANO +80 = 150)
        BattleSim e = make(false, new M[] { new M().time(3).optFlag(4096 * 8), new M().time(30) }, bobj, fx);
        for (int i = 0; i < 3; i++) e.step();
        check("tipo 8: fumaca do effect", count(e, BattleSim.OWNER_EFFECT) >= 1, true);
        BattleSim v = make(true, new M[] { new M().time(3).optFlag(4096 * 8), new M().time(30) }, bobj, fx);
        for (int i = 0; i < 3; i++) v.step();
        boolean alt = false;
        for (BattleSim.Layer l : v.layers()) if (l.owner == BattleSim.OWNER_EFFECT && l.sim.root() != null && l.sim.root().ano.index == 150) alt = true;
        check("virado: usa a ANO 150 (70 + 80)", alt, true);

        // ---- uma por frame: o frame com a flag dura 5 ticks e cria so uma
        BattleSim one = make(false, new M[] { new M().time(5).optFlag(4096 * 3), new M().time(30) }, bobj, fx);
        for (int i = 0; i < 5; i++) one.step();
        check("uma fumaca por frame carregado (nao uma por tick)", count(one, BattleSim.OWNER_BOBJ), 1);

        // ---- anel de 6: 8 frames seguidos com poeira longa => no maximo 6 vivas
        M[] many = new M[9];
        for (int i = 0; i < 8; i++) many[i] = new M().time(2).optFlag(4096 * 8);
        many[8] = new M().time(30);
        Dac fxLong = packWith(260, 70);
        BattleSim ring = make(false, many, bobj, fxLong);
        for (int i = 0; i < 17; i++) ring.step();
        int alive = 0;
        for (BattleSim.Layer l : ring.layers()) if (l.owner == BattleSim.OWNER_EFFECT && l.firstOfSim && l.sim.root() != null && l.sim.root().ano.index == 70) alive++;
        check("anel: no maximo 6 fumacas ao mesmo tempo", alive, 6);

        // ---- parada no mundo: o atacante anda e a fumaca fica no lugar
        BattleSim w = make(false, new M[] { new M().time(2).optFlag(4096 * 3), new M().time(40).speedX(3 << 16) }, packWith(100, 12), fx);
        for (int i = 0; i < 3; i++) w.step();
        int ax0 = w.attackerX(), x0 = -1;
        for (BattleSim.Layer l : w.layers()) if (l.owner == BattleSim.OWNER_BOBJ && l.sim.root() != null) x0 = l.sim.root().x;
        for (int i = 0; i < 20; i++) w.step();
        int x1 = -2;
        for (BattleSim.Layer l : w.layers()) if (l.owner == BattleSim.OWNER_BOBJ && l.sim.root() != null) x1 = l.sim.root().x;
        check("a fumaca fica parada no mundo enquanto o atacante anda", x0 == x1 && Math.abs(w.attackerX() - ax0) >= 30, true);

        // ---- sem o pacote: nada nasce e nada quebra
        BattleSim none = make(false, new M[] { new M().time(3).optFlag(4096 * 3), new M().time(30) }, null, fx);
        for (int i = 0; i < 4; i++) none.step();
        check("tipo 1-5 sem pasta bobj: nada nasce", count(none, BattleSim.OWNER_BOBJ), 0);

        // ---- fumacas filhas: a ANO 12 do bobj tem um hit flag 1 => nasce a ANO 71 do bobj
        A[] bo = new A[100];
        for (int i = 0; i < 100; i++) bo[i] = new A().mpt(new M().time(2));
        bo[12] = new A().mpt(new M().time(60).hit(1, 10, -5, 0, 0));
        bo[71] = new A().mpt(new M().time(60));
        BattleSim ch2 = make(false, new M[] { new M().time(3).optFlag(4096 * 3), new M().time(30) }, dac(bo), fx);
        for (int i = 0; i < 6; i++) ch2.step();
        check("filha: uma segunda fumaca do bobj (ANO 71) nasce da primeira", count(ch2, BattleSim.OWNER_BOBJ), 2);
        System.out.println("DustTest fails=" + fails);
    }
}
