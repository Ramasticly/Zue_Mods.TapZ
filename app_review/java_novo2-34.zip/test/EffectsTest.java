package com.zue.attackeditor;

public class EffectsTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    static short[] sine(double hz, double secs, double amp) {
        short[] s = new short[(int) (AudioConvert.RATE * secs)];
        for (int i = 0; i < s.length; i++) s[i] = (short) Math.round(amp * Math.sin(2 * Math.PI * hz * i / AudioConvert.RATE));
        return s;
    }

    /** Frequencia estimada pelos cruzamentos de zero (no miolo, sem as bordas). */
    static double freq(short[] s) {
        int a = s.length / 5, b = s.length - s.length / 5, z = 0;
        for (int i = a + 1; i < b; i++) if ((s[i - 1] < 0) != (s[i] < 0)) z++;
        return z / 2.0 / ((b - a) / (double) AudioConvert.RATE);
    }

    public static void main(String[] x) {
        short[] in = sine(440, 1.0, 10000);
        AudioEffects.Params p = new AudioEffects.Params();
        AudioEffects.Result r = AudioEffects.process(in, p);
        check("sem mudancas: igual", r.pcm.length == in.length && r.pcm[1000] == in[1000]);

        p = new AudioEffects.Params(); p.volume = 0.5f;
        r = AudioEffects.process(in, p);
        check("volume 50%", Math.abs(AudioEffects.peak(r.pcm) - 5000) < 5);

        p = new AudioEffects.Params(); p.volume = 3f;
        r = AudioEffects.process(sine(440, 0.2, 20000), p);
        check("volume alto nao da overflow (satura)", AudioEffects.peak(r.pcm) >= 32767);

        p = new AudioEffects.Params(); p.speed = 2f;
        r = AudioEffects.process(in, p);
        double f = freq(r.pcm);
        check("velocidade 2x sem unir: metade da duracao, mesmo tom (" + r.pcm.length + " amostras, " + f + " Hz)",
                Math.abs(r.pcm.length - in.length / 2) < 1200 && Math.abs(f - 440) < 25);

        p = new AudioEffects.Params(); p.speed = 0.5f;
        r = AudioEffects.process(in, p);
        f = freq(r.pcm);
        check("velocidade 0.5x sem unir: dobro da duracao, mesmo tom (" + r.pcm.length + ", " + f + ")",
                Math.abs(r.pcm.length - in.length * 2) < 2400 && Math.abs(f - 440) < 25);

        p = new AudioEffects.Params(); p.semitones = 12f;
        r = AudioEffects.process(in, p);
        f = freq(r.pcm);
        check("tom +12: oitava acima, mesma duracao (" + r.pcm.length + ", " + f + ")",
                Math.abs(r.pcm.length - in.length) < 1200 && Math.abs(f - 880) < 40);

        p = new AudioEffects.Params(); p.semitones = -12f;
        r = AudioEffects.process(in, p);
        f = freq(r.pcm);
        check("tom -12: oitava abaixo, mesma duracao (" + r.pcm.length + ", " + f + ")",
                Math.abs(r.pcm.length - in.length) < 1200 && Math.abs(f - 220) < 20);

        p = new AudioEffects.Params(); p.linked = true; p.speed = 2f;
        r = AudioEffects.process(in, p);
        f = freq(r.pcm);
        check("unidos 2x: metade da duracao e oitava acima (" + r.pcm.length + ", " + f + ")",
                Math.abs(r.pcm.length - in.length / 2) < 50 && Math.abs(f - 880) < 40);

        // igualar: alvo = RMS de um som de amplitude 8000
        double target = AudioEffects.activeRms(sine(300, 1.0, 8000));
        p = new AudioEffects.Params(); p.equalize = true; p.targetRms = target;
        r = AudioEffects.process(sine(440, 1.0, 2000), p);
        double got = AudioEffects.activeRms(r.pcm);
        check("igualar: RMS chega no alvo (" + Math.round(got) + " vs " + Math.round(target) + ")", Math.abs(got - target) / target < 0.02 && !r.limited);
        r = AudioEffects.process(sine(440, 1.0, 30000), p);
        check("igualar para baixo funciona", Math.abs(AudioEffects.activeRms(r.pcm) - target) / target < 0.02);
        short[] spike = sine(440, 1.0, 1000); spike[5000] = 8000;
        r = AudioEffects.process(spike, p);
        check("igualar limitado para nao estourar", r.limited && AudioEffects.peak(r.pcm) <= 32000);
        check("silencio: RMS 0", AudioEffects.activeRms(new short[1000]) == 0);
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHAS");
        if (fails > 0) System.exit(1);
    }
}
