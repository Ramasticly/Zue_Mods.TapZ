package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

/** PackCheck (quais packs faltam) e extracao REAL de um .pac sintetico pelos extratores copiados do compilador (ida e volta ate os leitores de TXT do app). */
public class ExtractorBridgeTest {
    static File r2dir(File tmp) { return new File(tmp, "real/assets"); }
    static void del(File f) { File[] k = f.listFiles(); if (k != null) for (File c : k) del(c); f.delete(); }
    static void touch(File f, String s) throws Exception { f.getParentFile().mkdirs(); java.nio.file.Files.write(f.toPath(), s.getBytes("UTF-8")); }

    /** DAC binario (mesmo formato do BattleTest.dac) com 2 ANOs de 1 frame. */
    static byte[] dacBytes() {
        A[] anos = {new A().mpt(new M().time(3)), new A().mpt(new M().time(5).hit(2, 1, 2, 3, 4))};
        int count = anos.length, tableOffset = 8, dataOffset = (8 + count * 2 + 3) & ~3;
        Buf ent = new Buf(); int[] ptr = new int[count];
        for (int i = 0; i < count; i++) { while (ent.size() % 4 != 0) ent.u8(0); ptr[i] = ent.size() / 4; ent.bytes(anos[i].build()); }
        Buf all = new Buf().u16(0).u16(count).u16(tableOffset).u16(dataOffset);
        for (int i = 0; i < count; i++) all.u16(ptr[i]);
        while (all.size() < dataOffset) all.u8(0);
        all.bytes(ent.get());
        return all.get();
    }

    static byte[] cnvBytes() throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int[][] e = {{0, 10, 20, 30, 40}, {0, 50, 60, 16, 16}};
        for (int[] r : e) { byte[] b = Cnv.encode(r[0], r[1], r[2], r[3], r[4]); o.write(b, 0, b.length); }
        return o.toByteArray();
    }

    static int tag(String t) { return ((t.charAt(0) & 255) << 24) | ((t.length() > 1 ? t.charAt(1) & 255 : 0) << 16) | ((t.length() > 2 ? t.charAt(2) & 255 : 0) << 8); }

    /** .pac no formato do PacExtractor: u16 count; 16 bytes por entrada (u32 offset, u32 tamanho, tipo "xxx\0" big endian, 4 bytes); dados. */
    static byte[] pac(String[] types, byte[][] data) {
        Buf b = new Buf().u16(types.length);
        int off = 0;
        for (int i = 0; i < types.length; i++) {
            int t = tag(types[i]);
            b.i32(off).i32(data[i].length).u8(t >>> 24).u8(t >>> 16).u8(t >>> 8).u8(0).i32(0);
            off += data[i].length;
        }
        for (byte[] d : data) b.bytes(d);
        return b.get();
    }

    public static void main(String[] args) throws Exception {
        File tmp = new File(System.getProperty("java.io.tmpdir"), "extractor_bridge_test");
        del(tmp);
        File root = new File(tmp, "Tap Battle/assets");
        root.mkdirs();

        // ---- PackCheck
        List<PackCheck.Item> p0 = PackCheck.scan(root);
        check("pasta vazia: gamedata e effect sao sempre exigidos, sem PAC", p0.size() + ":" + p0.get(0).name + ":" + p0.get(0).canExtract() + ":" + p0.get(1).name, "2:effect:false:gamedata");
        touch(new File(root, "char01/000.dac.txt"), "DAC_ACT_ {\n $ANO_0: {}\n}");
        touch(new File(root, "CHAR02.PAC"), "x");
        touch(new File(root, "charf01.pac"), "x");
        touch(new File(root, "char03_copia/000.dac.txt"), "x");           // nao e charNN: ignorada
        touch(new File(root, "gamedata/000.dac.txt"), "BIN_CNV_ {$COUNT: 1}");
        touch(new File(root, "effect/e.dac.txt"), "x");
        touch(new File(root, "effect/e.cnv.txt"), "x");
        List<PackCheck.Item> p1 = PackCheck.scan(root);
        StringBuilder sb = new StringBuilder();
        for (PackCheck.Item i : p1) sb.append(i.name).append('=').append(i.missing).append(i.canExtract() ? "+pac" : "").append(' ');
        check("char01 sem bin/cnv (sem PAC), char02 so com PAC, charf01 so com PAC; gamedata e effect ok", sb.toString().trim(),
                "char01=[*.bin.txt, *.cnv.txt] char02=[*.dac.txt, *.bin.txt, *.cnv.txt]+pac charf01=[*.dac.txt, *.cnv.txt]+pac");
        check("so os que tem PAC podem ser extraidos", PackCheck.extractable(p1).size(), 2);
        check("linha do alerta", p1.get(1).line(), "char02 — falta *.dac.txt, *.bin.txt, *.cnv.txt (CHAR02.PAC disponível para extrair)");
        check("assinatura estavel", PackCheck.signature(p1).equals(PackCheck.signature(PackCheck.scan(root))), true);
        del(new File(root, "char01")); new File(root, "CHAR02.PAC").delete(); new File(root, "charf01.pac").delete(); del(new File(root, "char03_copia"));
        check("tudo certo: nada a avisar", PackCheck.scan(root).size(), 0);

        // ---- extracao real: char01.pac -> assets/char01/ (pasta nao existe: igual ao jogo)
        byte[][] t = new byte[40][]; int[] cols = new int[40], rows = new int[40];
        for (int i = 0; i < 40; i++) t[i] = new byte[0];
        t[4] = move(new int[]{2, 1}, new int[]{0, 0}); cols[4] = 48; rows[4] = 1;
        t[14] = react(new int[]{6, 6, 3}, new int[]{9, 9, -4 & 255}); cols[14] = 14; rows[14] = 2;
        byte[] binB = hdat(t, cols, rows), dacB = dacBytes(), cnvB = cnvBytes();
        byte[] png = {(byte) 0x89, 'P', 'N', 'G', 0, 1, 2, 3};
        java.nio.file.Files.write(new File(root, "char01.pac").toPath(), pac(new String[] {"png", "bin", "cnv", "dac"}, new byte[][] {png, binB, cnvB, dacB}));
        List<PackCheck.Item> p2 = PackCheck.scan(root);
        check("char01 so com PAC: falta tudo e da para extrair", p2.size() + ":" + p2.get(p2.size() - 1).name + ":" + p2.get(p2.size() - 1).canExtract(), "1:char01:true");
        PackCheck.Item c1 = null;
        for (PackCheck.Item i : p2) if (i.name.equals("char01")) c1 = i;
        final int[] segs = {0};
        String msg = ExtractorBridge.extract(root, c1, new ExtractorBridge.Progress() { public void on(String p, String s, int i, int n) { segs[0]++; } });
        File d = new File(root, "char01");
        check("pasta extraida com os 3 TXT e a PNG", new File(d, "000.dac.txt").isFile() && new File(d, "000.bin.txt").isFile() && new File(d, "000.cnv.txt").isFile() && new File(d, "000.png").isFile(), true);
        check("progresso por segmento (4 entradas)", segs[0], 4);
        check("mensagem", msg, "char01: extraido de char01.pac");
        // volta pelos leitores de TXT do app (nenhum binario na pasta)
        check("nenhum binario na pasta", new File(d, "000.dac").exists() || new File(d, "000.bin").exists() || new File(d, "000.cnv").exists(), false);
        CharData cd = CharData.fromTxt(TxtFiles.read(TxtFiles.require(d, "bin")));
        check("golpe lido do TXT extraido (HDAT 4, ANIM_INICIAL = 1)", cd.moves.length + ":" + cd.moves[0].animInicial, "1:1");
        check("reacao 0 lida do TXT extraido", cd.reaction(0).rows + ":" + cd.reaction(0).s8(0, 2) + ":" + cd.reaction(0).s8(1, 2), "2:3:-4");
        Dac dc = Dac.fromTxt(TxtFiles.read(TxtFiles.require(d, "dac")));
        check("DAC lido do TXT extraido: 2 ANOs, a 2a com 1 hitbox", dc.size() + ":" + dc.getAno(1).mpts.length, "2:1");
        Cnv cv = CharAssets.readCnv(new File(d, "000.cnv"), true);
        check("CNV lido do TXT extraido: 2 sprites", cv.size() + ":" + cv.byImage(1).width, "2:16");
        check("tudo certo depois de extrair: char01 nao aparece mais", PackCheck.scan(root).size(), 0);

        // ---- pasta ja existe com TXT editado e faltando outro: extrai numa pasta temporaria e copia so o que falta (o editado nao e tocado)
        new File(d, "000.bin.txt").delete();
        touch(new File(d, "000.dac.txt"), "EDITADO PELO USUARIO");
        PackCheck.Item c2 = null;
        for (PackCheck.Item i : PackCheck.scan(root)) if (i.name.equals("char01")) c2 = i;
        check("so falta o bin.txt", String.valueOf(c2.missing), "[*.bin.txt]");
        String msg2 = ExtractorBridge.extract(root, c2, null);
        check("bin.txt voltou", new File(d, "000.bin.txt").isFile(), true);
        check("o dac.txt editado nao foi sobrescrito", new String(java.nio.file.Files.readAllBytes(new File(d, "000.dac.txt").toPath()), "UTF-8"), "EDITADO PELO USUARIO");
        check("mensagem do parcial", msg2, "char01: copiado 000.bin.txt de char01.pac");
        check("pasta temporaria apagada", new File(new File(root.getParentFile(), "TBRE"), "tmp").list() == null || new File(new File(root.getParentFile(), "TBRE"), "tmp").list().length == 0, true);

        // ---- camada de compatibilidade: HDAT 3/4/14 voltam byte a byte pelo BinTxt (formato detalhado, nao $RAW)
        String binTxt = TxtFiles.read(TxtFiles.require(d, "bin"));
        // (o golpe sintetico, com bytes que um golpe real nunca tem, cai em $RAW: so a amostra real abaixo vale para o HDAT 4)
        check("HDAT 14 em formato detalhado ($REACAO_DANO_0)", binTxt.contains("$REACAO_DANO_0"), true);

        // ---- amostra REAL: o char.hdat (binario que o BinBuilder real compilou do 000.bin.txt do usuario) extraido pela camada de compatibilidade
        File fh = BinTxtTest.fixture("char.hdat"), fo = BinTxtTest.fixture("char.bin.txt");
        if (fh != null && fo != null) {
            File r2 = new File(tmp, "real/assets");
            r2.mkdirs();
            java.nio.file.Files.write(new File(r2, "char05.pac").toPath(), pac(new String[] {"bin"}, new byte[][] {java.nio.file.Files.readAllBytes(fh.toPath())}));
            PackCheck.Item rc = null;
            for (PackCheck.Item i : PackCheck.scan(r2)) if (i.name.equals("char05")) rc = i;
            ExtractorBridge.extract(r2, rc, null);
            String got = TxtFiles.read(TxtFiles.require(new File(r2, "char05"), "bin")), orig = TxtFiles.read(fo);
            java.util.List<Integer> raw = new java.util.ArrayList<Integer>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\$HDAT_(\\d+):\\{[^\\n]*\\n\\s*//[^\\n]*\\n\\s*//[^\\n]*\\n\\s*\\$RAW").matcher(got);
            while (m.find()) raw.add(Integer.valueOf(m.group(1)));
            System.out.println("(extracao real do char.hdat: HDATs que cairam em $RAW pela camada de compatibilidade: " + raw + ")");
            for (int h : new int[] {3, 4, 7, 13, 14, 15, 20, 33}) check("amostra real: HDAT " + h + " sai em formato detalhado (como o extrator original)", raw.contains(Integer.valueOf(h)), false);
            CharData a = CharData.fromTxt(got), b = CharData.fromTxt(orig);
            check("amostra real: o TXT extraido le igual ao original (golpes, eventos, reacoes)", a.moves.length + ":" + a.eventRows() + ":" + a.reaction(0).rows, b.moves.length + ":" + b.eventRows() + ":" + b.reaction(0).rows);
        }

        // ---- 3.4a: reconferir depois de extrair + porta unica do alerta
        check("scanOne: char01 (extraido acima, completo) = null", PackCheck.scanOne(root, "char01") == null, true);
        check("scanOne: o .pac so tinha o bin: so falta dac e cnv (bin ja extraido nao conta); nome em maiusculas vale", String.valueOf(PackCheck.scanOne(r2dir(tmp), "CHAR05").missing), "[*.dac.txt, *.cnv.txt]");
        check("scanOne: pack inexistente e nao obrigatorio = null", PackCheck.scanOne(root, "char77") == null, true);
        List<PackCheck.Item> some = PackCheck.scan(root);
        check("lista de problemas e a mesma depois de extrair duas vezes o mesmo (nada novo)", PackCheck.signature(some).equals(PackCheck.signature(PackCheck.scan(root))), true);
        String sg = PackCheck.signature(some);
        check("gate: nada faltando = nao mostra", PackAlertGate.shouldShow(new java.util.ArrayList<PackCheck.Item>(), "", "", false, false), false);
        List<PackCheck.Item> one = new java.util.ArrayList<PackCheck.Item>();
        one.add(new PackCheck.Item("char01", new File(root, "char01"), null)); one.get(0).missing.add("*.dac.txt");
        String sg1 = PackCheck.signature(one);
        check("gate: algo faltando = mostra", PackAlertGate.shouldShow(one, sg1, "", false, false), true);
        check("gate: ja ha um alerta na tela = nunca abre outro (nem forcado)", PackAlertGate.shouldShow(one, sg1, "", true, false) + ":" + PackAlertGate.shouldShow(one, sg1, "", true, true), "false:false");
        check("gate: o mesmo alerta ja dispensado nao volta, salvo forcado (↻)", PackAlertGate.shouldShow(one, sg1, sg1, false, false) + ":" + PackAlertGate.shouldShow(one, sg1, sg1, false, true), "false:true");
        check("gate: mudou o que falta = mostra de novo", PackAlertGate.shouldShow(one, sg1, "outro;", false, false), true);

        // ---- sem PAC: erro claro
        boolean err = false;
        try { ExtractorBridge.extract(root, new PackCheck.Item("char09", new File(root, "char09"), null), null); } catch (java.io.IOException e) { err = e.getMessage().contains("sem char09.pac"); }
        check("sem .pac: erro claro", err, true);
        del(tmp);
        System.out.println("ExtractorBridgeTest fails=" + fails);
    }
}
