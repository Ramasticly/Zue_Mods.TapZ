package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Fidelidade com o jogo fora das cutscenes: separacao de corpos, SEQ/END pela altura, auras, tremor, zoom, agarrao e tabelas. */
public class FidelityTest {
    static final int PX = 65536;

    static Dac defDac() throws Exception {
        A[] d = new A[25];
        for (int i = 0; i < 25; i++) d[i] = new A().mpt(new M().time(30));
        d[0] = new A().mpt(new M().time(30).hit(1, -10, -60, 20, 60));
        return dac(d);
    }

    static Dac fxDac() throws Exception {
        A[] a = new A[80];
        for (int i = 0; i < 80; i++) a[i] = new A().mpt(new M().time(60));
        return dac(a);
    }

    public static void main(String[] args) throws Exception {
        BattleSim.edgeMode = 1;
        BattleSim.cutscenes = true;
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });

        // ---- tabelas do jogo
        check("seno: metade negativa nao e simetrica", GameTables.SIN[181] + ":" + GameTables.SIN[1], "-1:2");
        check("atan: eixo +x", GameTables.atan512(PX, 0), 0);
        check("atan: eixo +y", GameTables.atan512(0, PX), 128);
        check("atan: 45 graus", GameTables.atan512(PX, PX), 64);
        check("atan: |dx| < 1 px (truncado a 0 px)", GameTables.atan512(1000, PX), 128);

        // ---- separacao de corpos (md 19): quem anda para dentro do outro empurra; a flag 16 (fantasma) atravessa
        for (int ghost = 0; ghost < 2; ghost++) {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(120).speedX(2 * PX));
            CharData ch = chr(move(new int[]{0, ghost == 1 ? 16 : 0}, new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            int ox0 = s.opponentX();
            for (int i = 0; i < 60; i++) s.step();
            int dx = s.opponentX() - ox0;
            if (ghost == 0) check("corpo empurra o oponente", dx > 20, true);
            else check("fantasma (flag 16) atravessa sem empurrar", dx, 0);
            if (ghost == 0) check("e o atacante nao passa dele", s.attacker().root().x < s.opponentY() * 0 + s.opponentX() * PX, true);
        }

        // ---- SEQ/END escolhidos so pela altura (FLY nao conta)
        {
            for (int fly = 0; fly < 2; fly++) {
                BattleSim.flyMode = fly == 1;
                A[] a = new A[45];
                for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(30));
                a[40] = new A().mpt(new M().time(2).hit(2, 20, 30, 40, 30).opt1(3)).mpt(new M().time(60));
                CharData ch = chr(move(new int[]{2, 40}, new int[]{10, 41}, new int[]{14, 42}), new byte[][] {});
                BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 30, 40, 0);
                for (int i = 0; i < 8; i++) s.step();
                check("no ar vale SEQ de ar (fly " + fly + ")", s.attacker().root().ano.index, 42);
            }
            BattleSim.flyMode = false;
        }

        // ---- auras: char (71-125) herdam o flip do dono; charf (41-70) nunca viram
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(30).hit(41, 0, 0, 0, 0).hit(10, 0, 0, 0, 0));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], true, defDac(), fxDac(), g, 100, 0, 0);
            s.setCharfDac(dac(new A[]{new A().mpt(new M().time(30)), new A().mpt(new M().time(30)), new A().mpt(new M().time(30)), new A().mpt(new M().time(30))}));
            s.step();
            boolean charfFlip = false, fxFlip = false, any = false;
            for (BattleSim.Layer l : s.layers()) {
                if (l.owner == BattleSim.OWNER_AURA_CHARF) { any = true; charfFlip |= (l.sim.root().objFlags & 16) != 0; }
                if (l.owner == BattleSim.OWNER_AURA_EFFECT) fxFlip |= (l.sim.root().objFlags & 16) != 0;
            }
            check("aura charf existe e nao vira", any + ":" + charfFlip, "true:false");
            check("aura de effect vira com o dono", fxFlip, true);
        }

        // ---- tremor 3-5: re-armado a cada tick enquanto o frame existe
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(120).hit(3, 0, 0, 0, 0));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            for (int i = 0; i < 50; i++) s.step();
            check("tremor continua no tick 50 (nao decai em 12 ticks)", s.screenTop() != -15728640, true);
        }

        // ---- zoom 30/31: FRAMES = 0 e ignorado
        for (int fr = 0; fr < 2; fr++) {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(100).hit(30, 0, 0, 150, fr == 0 ? 0 : 10));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            for (int i = 0; i < 30; i++) s.step();
            check(fr == 0 ? "zoom com frames 0 e ignorado" : "zoom com frames 10 vale", s.zoomRect() != null, fr == 1);
        }

        // ---- agarrao: o objeto so nasce se o ANO que acertou esta entre 40 e 62
        for (int k = 0; k < 2; k++) {
            int ano = k == 0 ? 40 : 39;
            A[] a = new A[70];
            for (int i = 0; i < 70; i++) a[i] = new A().mpt(new M().time(30));
            a[ano] = new A().mpt(new M().time(2).hit(2, 20, -40, 40, 30).opt1(3)).mpt(new M().time(60));
            a[41] = new A().mpt(new M().time(60));
            a[55] = new A().mpt(new M().time(60));
            CharData ch = chr(move(new int[]{2, ano}, new int[]{10, 41}, new int[]{24, 55}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 30, 0, 0);
            for (int i = 0; i < 8; i++) s.step();
            int grabs = 0;
            for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_PROJECTILE) grabs++;
            check(k == 0 ? "ANO 40 acertou: agarrao nasce" : "ANO 39 acertou: sem agarrao", grabs > 0, k == 0);
        }

        System.out.println("FidelityTest fails=" + BattleTest.fails);
    }
}
