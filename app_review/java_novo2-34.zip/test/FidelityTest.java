package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Fidelidade com o jogo fora das cutscenes: separacao de corpos, SEQ/END pela altura, auras, tremor, zoom, agarrao e tabelas. */
public class FidelityTest {
    static final int PX = 65536;

    static Dac defDac() throws Exception {
        A[] d = new A[25];
        for (int i = 0; i < 25; i++) d[i] = new A().mpt(new M().time(30));
        d[0] = new A().mpt(new M().time(30).hit(1, -10, -60, 20, 60));
        return dac(d);
    }

    static Dac fxDac() throws Exception {
        A[] a = new A[80];
        for (int i = 0; i < 80; i++) a[i] = new A().mpt(new M().time(60));
        return dac(a);
    }

    public static void main(String[] args) throws Exception {
        BattleSim.edgeMode = 1;
        BattleSim.cutscenes = true;
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });

        // ---- tabelas do jogo
        check("seno: metade negativa nao e simetrica", GameTables.SIN[181] + ":" + GameTables.SIN[1], "-1:2");
        check("atan: eixo +x", GameTables.atan512(PX, 0), 0);
        check("atan: eixo +y", GameTables.atan512(0, PX), 128);
        check("atan: 45 graus", GameTables.atan512(PX, PX), 64);
        check("atan: |dx| < 1 px (truncado a 0 px)", GameTables.atan512(1000, PX), 128);

        // ---- separacao de corpos (md 19): quem anda para dentro do outro empurra; a flag 16 (fantasma) atravessa
        for (int ghost = 0; ghost < 2; ghost++) {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(120).speedX(2 * PX));
            CharData ch = chr(move(new int[]{0, ghost == 1 ? 16 : 0}, new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            int ox0 = s.opponentX();
            for (int i = 0; i < 60; i++) s.step();
            int dx = s.opponentX() - ox0;
            if (ghost == 0) check("corpo empurra o oponente", dx > 20, true);
            else check("fantasma (flag 16) atravessa sem empurrar", dx, 0);
            if (ghost == 0) check("e o atacante nao passa dele", s.attacker().root().x < s.opponentY() * 0 + s.opponentX() * PX, true);
        }

        // ---- SEQ/END escolhidos so pela altura (FLY nao conta)
        {
            for (int fly = 0; fly < 2; fly++) {
                BattleSim.flyMode = fly == 1;
                A[] a = new A[45];
                for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(30));
                a[40] = new A().mpt(new M().time(2).hit(2, 20, 30, 40, 30).opt1(3)).mpt(new M().time(60));
                CharData ch = chr(move(new int[]{2, 40}, new int[]{10, 41}, new int[]{14, 42}), new byte[][] {});
                BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 30, 40, 0);
                for (int i = 0; i < 8; i++) s.step();
                check("no ar vale SEQ de ar (fly " + fly + ")", s.attacker().root().ano.index, 42);
            }
            BattleSim.flyMode = false;
        }

        // ---- auras: char (71-125) herdam o flip do dono; charf (41-70) nunca viram
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(30).hit(41, 0, 0, 0, 0).hit(10, 0, 0, 0, 0));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], true, defDac(), fxDac(), g, 100, 0, 0);
            s.setCharfDac(dac(new A[]{new A().mpt(new M().time(30)), new A().mpt(new M().time(30)), new A().mpt(new M().time(30)), new A().mpt(new M().time(30))}));
            s.step();
            boolean charfFlip = false, fxFlip = false, any = false;
            for (BattleSim.Layer l : s.layers()) {
                if (l.owner == BattleSim.OWNER_AURA_CHARF) { any = true; charfFlip |= (l.sim.root().objFlags & 16) != 0; }
                if (l.owner == BattleSim.OWNER_AURA_EFFECT) fxFlip |= (l.sim.root().objFlags & 16) != 0;
            }
            check("aura charf existe e nao vira", any + ":" + charfFlip, "true:false");
            check("aura de effect vira com o dono", fxFlip, true);
        }

        // ---- tremor 3-5: re-armado a cada tick enquanto o frame existe
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(120).hit(3, 0, 0, 0, 0));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            for (int i = 0; i < 50; i++) s.step();
            check("tremor continua no tick 50 (nao decai em 12 ticks)", s.screenTop() != -15728640, true);
        }

        // ---- zoom 30/31: FRAMES = 0 e ignorado
        for (int fr = 0; fr < 2; fr++) {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(100).hit(30, 0, 0, 150, fr == 0 ? 0 : 10));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            for (int i = 0; i < 30; i++) s.step();
            check(fr == 0 ? "zoom com frames 0 e ignorado" : "zoom com frames 10 vale", s.zoomRect() != null, fr == 1);
        }

        // ---- agarrao: o objeto so nasce se o ANO que acertou esta entre 40 e 62
        for (int k = 0; k < 2; k++) {
            int ano = k == 0 ? 40 : 39;
            A[] a = new A[70];
            for (int i = 0; i < 70; i++) a[i] = new A().mpt(new M().time(30));
            a[ano] = new A().mpt(new M().time(2).hit(2, 20, -40, 40, 30).opt1(3)).mpt(new M().time(60));
            a[41] = new A().mpt(new M().time(60));
            a[55] = new A().mpt(new M().time(60));
            CharData ch = chr(move(new int[]{2, ano}, new int[]{10, 41}, new int[]{24, 55}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 30, 0, 0);
            int grabs = 0;
            for (int i = 0; i < 40; i++) {                       // o objeto fica invisivel durante o hitstop e aparece depois
                s.step();
                for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_PROJECTILE) grabs++;
            }
            check(k == 0 ? "ANO 40 acertou: agarrao nasce" : "ANO 39 acertou: sem agarrao", grabs > 0, k == 0);
        }

        // ---- projetil principal: nasce no PlayerTail (prio 13312 < 13569), a task so roda no tick seguinte (so carrega o frame 0) e anda a partir do outro
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(2).hit(0, 30, -40, 0, 0)).mpt(new M().time(60));
            a[30] = new A().mpt(new M().time(60).speedX(2 * PX));
            CharData ch = chr(move(new int[]{2, 40}, new int[]{4, 30}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            int x0 = s.projectileX(0);
            s.step();
            check("projetil: 1a execucao so carrega o frame 0 (nao anda)", s.projectileX(0) - x0, 0);
            s.step();
            check("projetil: anda a partir da 2a execucao", (s.projectileX(0) - x0) / PX, 2);
        }

        // ---- reset() limpa a camera vertical da execucao anterior
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(60));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim fresh = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 200, 0);
            BattleSim used = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 200, 0);
            for (int i = 0; i < 20; i++) used.step();
            used.reset();
            check("reset: screenTop volta ao de uma simulacao nova", used.screenTop(), fresh.screenTop());
        }

        // ---- SE do jogador 1: so valores >= 80 (ChrSePlay) recebem o deslocamento dos audios do jogador 0
        {
            A[] d = new A[25];
            for (int i = 0; i < 25; i++) d[i] = new A().mpt(new M().time(30));
            d[0] = new A().mpt(new M().time(30).se(8).hit(1, -10, -60, 20, 60));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, dac(d), fxDac(), g, 100, 0, 20);
            java.util.List<BattleSim.Snd> sl = s.drainSounds();
            boolean ok = false;
            for (BattleSim.Snd x : sl) if (x.common && x.id == 7) ok = true;
            check("SE comum do oponente nao leva o offset dos audios do atacante", ok, true);
        }

        // ---- melee so acerta com os dois vivos (md 935)
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(2).hit(2, 20, -40, 60, 30).opt1(3).dmg(250)).mpt(new M().time(2).hit(2, 20, -40, 60, 30).opt1(3).dmg(250)).mpt(new M().time(2).hit(2, 20, -40, 60, 30).opt1(3).dmg(250)).mpt(new M().time(40));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 60, 0, 0);
            for (int i = 0; i < 40; i++) s.step();
            check("oponente derrotado no 1o hit", s.opponentDead(), true);
            check("os frames seguintes nao acertam um oponente derrotado (combo 1)", s.comboCount(), 1);
        }

        // ---- flag 40 num ANO de projetil: CheckOptFlag usa o jogador dono (PlayerXPos[p]), nao a posicao do projetil
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(2).hit(0, 30, -40, 0, 0)).mpt(new M().time(60));
            a[30] = new A().mpt(new M().time(60).speedX(2 * PX).hit(40, 80, 0, 0, 0));
            CharData ch = chr(move(new int[]{2, 40}, new int[]{4, 30}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            s.step();
            check("flag 40 do projetil leva o oponente para o atacante + 80", s.opponentX() - (s.attacker().root().x >> 16), 80);
        }

        // ---- bit 4 do wActFlag vindo do dado do MPT nao prende o lutador (o PlayerTail o recalcula a cada tick)
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(3).act(4)).mpt(new M().time(3)).mpt(new M().time(40));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            for (int i = 0; i < 4; i++) s.step();
            check("frame com wActFlag 4 avanca", s.attacker().root().pat, 1);
        }

        // ---- zoom: o ultimo hit 30/31 do frame vale; FRAMES = 0 nele cancela o zoom do anterior
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(100).hit(30, 0, 0, 150, 10).hit(31, 0, 0, 150, 0));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, defDac(), fxDac(), g, 100, 0, 0);
            for (int i = 0; i < 30; i++) s.step();
            check("ultimo hit de zoom com frames 0 cancela", s.zoomRect() == null, true);
        }

        System.out.println("FidelityTest fails=" + BattleTest.fails);
    }
}
