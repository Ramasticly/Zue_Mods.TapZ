package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;

/** Seletor de arquivos: a linha "...↑" (subir uma pasta) existe em toda pasta menos na raiz. */
public class FilePickerTest {
    public static void main(String[] args) throws Exception {
        File root = new File("/storage/emulated/0");
        check("raiz nao tem a linha de subir", FilePicker.hasUpRow(root, root), false);
        check("subpasta tem", FilePicker.hasUpRow(new File(root, "Download"), root), true);
        check("subpasta funda tem", FilePicker.hasUpRow(new File(root, "Download/char05/sub"), root), true);
        check("pasta sem pai (raiz do sistema) nao tem", FilePicker.hasUpRow(new File("/"), root), false);
        check("pasta nula nao tem", FilePicker.hasUpRow(null, root), false);
        System.out.println("FilePickerTest fails=" + fails);
    }
}
