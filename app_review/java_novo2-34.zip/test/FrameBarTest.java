package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Faixa de Frame (mover), fim da timeline, onde entra o sprite do botao + e a faixa "efeito img". */
public class FrameBarTest {
    static Ano.Mpt mp(int image, int time) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags |= 0x20; m.time = time; m.normalize();
        return m;
    }

    static String imgs(Ano.Mpt[] m) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < m.length; i++) b.append(i == 0 ? "" : ",").append(m[i].image);
        return b.toString();
    }

    public static void main(String[] args) {
        Ano.Mpt[] a = {mp(0, 4), mp(1, 4), mp(2, 4)};          // ticks 0-3 | 4-7 | 8-11 (total 12)
        check("total 12", FrameOps.total(a), 12);

        // onde entra o sprite novo
        check("meio do frame 0 (tick 2): depois dele", FrameOps.insertIndexAt(a, 2), 1);
        check("tick 0 (inicio do frame 0): antes dele", FrameOps.insertIndexAt(a, 0), 0);
        check("tick 4 (divisa 0|1): no lugar da divisa", FrameOps.insertIndexAt(a, 4), 1);
        check("tick 5 (meio do frame 1)", FrameOps.insertIndexAt(a, 5), 2);
        check("tick 8 (divisa 1|2)", FrameOps.insertIndexAt(a, 8), 2);
        check("tick 11 (ultimo tick, meio do frame 2)", FrameOps.insertIndexAt(a, 11), 3);
        check("tick 12 (fim da timeline): anexa", FrameOps.insertIndexAt(a, 12), 3);

        Ano.Mpt[] mid = FrameOps.insertCopyAt(a, 1);
        check("insere no indice 1: 4 frames, copia do frame 0 no meio", imgs(mid), "0,0,1,2");
        Ano.Mpt[] first = FrameOps.insertCopyAt(a, 0);
        check("insere no indice 0: a copia fica antes do original", imgs(first), "0,0,1,2");
        Ano.Mpt[] end = FrameOps.insertCopyAt(a, 3);
        check("insere no fim: copia do ultimo", imgs(end), "0,1,2,2");
        // o original (com hits) continua depois da copia limpa quando entra no inicio
        Ano.Mpt[] h = {mp(0, 4), mp(1, 4)};
        h[0].hits = new Ano.Hit[]{new Ano.Hit()}; h[0].hits[0].flag = 2; h[0].flags |= 0x10;
        Ano.Mpt[] hf = FrameOps.insertCopyAt(h, 0);
        check("no inicio: copia sem hits, original com hit", hf[0].hits.length + ":" + hf[1].hits.length, "0:1");

        // mover o frame
        Ano.Mpt[] r = FrameOps.shift(a, 0, 1);
        check("mover o 0 para frente", imgs(r), "1,0,2");
        Ano.Mpt[] l = FrameOps.shift(a, 2, -1);
        check("mover o 2 para tras", imgs(l), "0,2,1");
        check("nao move o primeiro para tras nem o ultimo para frente", FrameOps.shift(a, 0, -1) == null && FrameOps.shift(a, 2, 1) == null, true);
        // frame sem TIME (ultimo) que vai para o meio ganha tempo, senao travaria a ANO
        Ano.Mpt[] nt = {mp(0, 4), mp(1, 4), new Ano.Mpt()};
        nt[2].image = 2; nt[2].normalize();
        Ano.Mpt[] mv = FrameOps.shift(nt, 2, -1);
        check("ex-ultimo sem tempo no meio passa a ter tempo", mv[1].hasTime && mv[1].time > 0, true);

        // faixa "efeito img": so flip / manter velocidade / interpolar; rotacao, alpha e zoom nao contam
        Ano.Mpt raz = mp(0, 4);
        raz.flags |= 0x80; raz.rot = 30; raz.xZoom = 150; raz.normalize();
        check("rotacao/zoom nao entram na faixa", FrameOps.styleSig(raz), 0L);
        Ano.Mpt fl = mp(0, 4);
        fl.flags |= 2; fl.wActFlag |= ObjModel.FLIP_H; fl.normalize();
        check("flip entra", FrameOps.styleSig(fl) != 0, true);
        Ano.Mpt ip = ObjModel.setOptField(mp(0, 4), 2, 1);
        check("interpolar entra", FrameOps.styleSig(ip) != 0, true);
        Ano.Mpt[] run = {fl, fl.copy(), mp(0, 4)};
        check("trecho do flip: frames 0-1", FrameOps.styleRunStart(run, 1) + "-" + FrameOps.styleRunEnd(run, 0), "0-1");
        System.out.println("FrameBarTest fails=" + fails);
    }
}
