package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Ver Frames: copiar, excluir e colar Frames de uma ANO. */
public class FrameClipTest {
    static Ano.Mpt mpt(int image, int time) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags = time > 0 ? 0x20 : 0; m.time = time; m.normalize();
        return m;
    }

    static String imgs(Ano.Mpt[] m) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < m.length; i++) b.append(i > 0 ? "," : "").append(m[i].image);
        return b.toString();
    }

    public static void main(String[] args) throws Exception {
        Ano.Mpt[] base = {mpt(10, 4), mpt(11, 5), mpt(12, 6), mpt(13, 0)};      // o ultimo nao tem TIME (fica parado)
        Ano.Hit h = new Ano.Hit();
        h.flag = 2; h.x = 1; h.y = 2; h.width = 3; h.height = 4;
        base[1].hits = new Ano.Hit[]{h};
        base[1].flags |= 0x10;
        Object owner = new Object();

        // normalizacao dos indices
        check("indices: fora da faixa, repetidos e fora de ordem", java.util.Arrays.toString(FrameClip.normalize(base, new int[]{3, 1, 1, -2, 9, 0})), "[0, 1, 3]");

        // copiar
        FrameClip c = FrameClip.copy(base, new int[]{2, 1}, owner, 5);
        check("copia na ordem da ANO (1, 2) e guarda de onde veio", c.frames.length + ":" + imgs(c.frames) + ":" + c.fromAno + ":" + (c.owner == owner), "2:11,12:5:true");
        check("copia profunda: hits independentes", c.frames[0].hits.length == 1 && c.frames[0].hits[0] != base[1].hits[0] && c.frames[0].hits[0].width == 3, true);
        check("copiar nada = null", FrameClip.copy(base, new int[0], owner, 0) == null && FrameClip.copy(base, new int[]{9}, owner, 0) == null, true);
        base[1].hits[0].width = 99;
        check("mudar o original depois nao muda a copia", c.frames[0].hits[0].width, 3);
        base[1].hits[0].width = 3;

        // excluir
        Ano.Mpt[] d = FrameClip.delete(base, new int[]{1, 2});
        check("excluir 1 e 2 sobra 10, 13", imgs(d), "10,13");
        check("a lista original nao muda", base.length, 4);
        check("nunca esvazia a ANO", FrameClip.delete(base, new int[]{0, 1, 2, 3}) == null, true);
        check("nada valido = null", FrameClip.delete(base, new int[]{7}) == null, true);
        check("excluir o ultimo", imgs(FrameClip.delete(base, new int[]{3})), "10,11,12");

        // colar: inicio, meio, fim
        FrameClip cl = FrameClip.copy(base, new int[]{0, 2}, owner, 0);
        check("colar no inicio (pos 0)", imgs(FrameClip.paste(base, 0, cl)), "10,12,10,11,12,13");
        check("colar entre o Frame 0 e o 1 (pos 1)", imgs(FrameClip.paste(base, 1, cl)), "10,10,12,11,12,13");
        Ano.Mpt[] end = FrameClip.paste(base, 4, cl);
        check("colar no fim (pos 4)", imgs(end), "10,11,12,13,10,12");
        check("o antigo ultimo frame (sem TIME) ganha tempo e os colados mantem o proprio", end[3].hasTime && end[3].time > 0 && end[4].time == 4 && end[5].time == 6, true);
        check("pos fora da faixa e ajustada", imgs(FrameClip.paste(base, 99, cl)) + "|" + imgs(FrameClip.paste(base, -3, cl)), "10,11,12,13,10,12|10,12,10,11,12,13");
        check("colar copias novas (independentes do clip)", FrameClip.paste(base, 0, cl)[0] != cl.frames[0], true);
        check("clip vazio / nulo = lista igual", FrameClip.paste(base, 1, null) == base, true);
        check("a lista original nao muda ao colar", base.length == 4 && base[3].image == 13, true);

        // frame colado no meio sem TIME vira com tempo (nao trava a animacao)
        FrameClip last = FrameClip.copy(base, new int[]{3}, owner, 0);
        Ano.Mpt[] mid = FrameClip.paste(base, 1, last);
        check("Frame sem TIME colado no meio ganha tempo", mid[1].hasTime && mid[1].time > 0 && mid[4].image == 13, true);

        // area de transferencia compartilhada
        FrameClip.current = cl;
        check("area de transferencia estatica", FrameClip.current == cl && FrameClip.current.owner == owner, true);
        FrameClip.current = null;
    }
}
