package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * Nenhum indice de frame fora do ANO (-2, -1, len, len+3...) pode derrubar o app: chama, por reflexao, TODA operacao estatica de
 * FrameOps / FrameTools / ObjModel que recebe a lista de frames (Ano.Mpt[]) com todas as combinacoes de indices ruins e exige zero excecao.
 */
public class FrameIndexRobustTest {
    static Ano.Mpt[] anoOf(int n) throws Exception {
        A a = new A();
        for (int i = 0; i < n; i++) a.mpt(new M().time(5 + i).speedX(i == 1 ? 2 << 16 : 0).hit(1, -5, -20, 10, 20).hit(2, 3, -10, 6, 6));
        return dac(a).getAno(0).mpts;
    }

    static Object[][] argSets(Class<?>[] pt, Ano.Mpt[] m, int[] idxs) {
        // cartesiano dos parametros inteiros/booleanos; o resto tem valor fixo
        List<Object[]> acc = new ArrayList<Object[]>();
        acc.add(new Object[pt.length]);
        for (int p = 0; p < pt.length; p++) {
            List<Object[]> next = new ArrayList<Object[]>();
            List<Object> vals = new ArrayList<Object>();
            Class<?> c = pt[p];
            if (c == Ano.Mpt[].class) vals.add(m);
            else if (c == int.class) for (int v : idxs) vals.add(Integer.valueOf(v));
            else if (c == boolean.class) { vals.add(Boolean.TRUE); vals.add(Boolean.FALSE); }
            else if (c == double.class) vals.add(Double.valueOf(1.5));
            else if (c == Ano.Mpt.class) vals.add(m[0]);
            else if (c == Ano.Hit.class) vals.add(ObjModel.defaultHit(2));
            else if (c == int[].class) vals.add(new int[]{1, 2});
            else if (c == ObjModel.Obj.class) {
                for (int f0 : idxs) for (int f1 : idxs) {
                    ObjModel.Obj o = new ObjModel.Obj();
                    o.kind = ObjModel.HITBOX; o.flag = 2; o.occ = 0; o.f0 = f0; o.f1 = f1; o.keys = new int[]{f0};
                    vals.add(o);
                }
            } else return null;           // tipo que este teste nao sabe montar (Run, Split...): fica de fora
            for (Object[] base : acc) for (Object v : vals) { Object[] n = base.clone(); n[p] = v; next.add(n); }
            acc = next;
        }
        return acc.toArray(new Object[0][]);
    }

    public static void main(String[] args) throws Exception {
        Class<?>[] classes = {FrameOps.class, FrameTools.class, ObjModel.class};
        TreeMap<String, String> bad = new TreeMap<String, String>();
        int calls = 0, methods = 0;
        for (int n : new int[]{1, 4}) {
            Ano.Mpt[] m = anoOf(n);
            int[] idxs = {-2, -1, 0, n - 1, n, n + 3};
            for (Class<?> cl : classes) {
                for (Method me : cl.getDeclaredMethods()) {
                    if (!Modifier.isStatic(me.getModifiers()) || Modifier.isPrivate(me.getModifiers())) continue;
                    Class<?>[] pt = me.getParameterTypes();
                    if (pt.length == 0 || pt[0] != Ano.Mpt[].class) continue;
                    Object[][] sets = argSets(pt, m, idxs);
                    if (sets == null) continue;
                    if (n == 1) methods++;
                    me.setAccessible(true);
                    for (Object[] as : sets) {
                        Ano.Mpt[] copy = m.clone();
                        as[0] = copy;
                        calls++;
                        try { me.invoke(null, as); }
                        catch (InvocationTargetException e) {
                            Throwable t = e.getCause();
                            if (t instanceof RuntimeException || t instanceof Error) {
                                String key = cl.getSimpleName() + "." + me.getName();
                                if (!bad.containsKey(key)) {
                                    StringBuilder sb = new StringBuilder(t.getClass().getSimpleName()).append(" n=").append(n).append(" args=");
                                    for (int i = 1; i < as.length; i++) {
                                        Object o = as[i];
                                        sb.append(o instanceof ObjModel.Obj ? "Obj[" + ((ObjModel.Obj) o).f0 + ".." + ((ObjModel.Obj) o).f1 + "]" : o instanceof int[] ? "int[]" : String.valueOf(o)).append(' ');
                                    }
                                    sb.append(" @ ").append(t.getStackTrace().length > 0 ? t.getStackTrace()[0].toString() : "");
                                    bad.put(key, sb.toString());
                                }
                            }
                        }
                        for (int i = 0; i < copy.length; i++) if (copy[i] != m[i]) { /* a operacao nao mexe no array recebido: sempre devolve copia */ break; }
                    }
                }
            }
        }
        for (java.util.Map.Entry<String, String> e : bad.entrySet()) System.out.println("EXCECAO " + e.getKey() + ": " + e.getValue());
        System.out.println("(" + methods + " metodos, " + calls + " chamadas)");
        check("nenhuma operacao de frame lanca excecao com indice invalido", bad.size(), 0);
        System.out.println("FrameIndexRobustTest fails=" + fails);
    }
}
