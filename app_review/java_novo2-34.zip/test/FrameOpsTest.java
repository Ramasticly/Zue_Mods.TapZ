package com.zue.attackeditor;

public class FrameOpsTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    static Ano.Mpt mpt(int image, int time) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags |= 0x20; m.time = time; m.normalize();
        return m;
    }

    static Ano.Hit hit(int flag, int x) {
        Ano.Hit h = new Ano.Hit(); h.flag = flag; h.x = x; h.y = 1; h.width = 10; h.height = 11; return h;
    }

    public static void main(String[] args) {
        Ano.Mpt[] a = new Ano.Mpt[5];
        for (int i = 0; i < 5; i++) a[i] = mpt(i, 4);
        Ano.Mpt s = a[1];
        s.flags |= 1; s.midX = 7; s.midY = -3;
        s.hits = new Ano.Hit[]{hit(2, 5), hit(1, 6), hit(0, 9), hit(12, 1)};
        s.flags |= 0x10;
        s.flags |= 8; s.se = 33;
        s.flags |= 2; s.wActFlag = ObjModel.FLIP_H | 1;
        s.flags |= 0x80; s.rot = 30; s.xZoom = 150; s.yZoom = 120; s.alphaRaw = 0;
        s.normalize();
        // alvo ja tem uma hurtbox e uma acao especial que devem sobreviver
        a[2].hits = new Ano.Hit[]{hit(1, 99), hit(26, 0)};
        a[2].flags |= 0x10;
        a[2].normalize();

        int[] r = FrameOps.targetRange(5, 1, 0, 2);
        check("proximos 2: frames 2..3", r[0] == 2 && r[1] == 3);
        r = FrameOps.targetRange(5, 1, 1, 3);
        check("anteriores limitados ao inicio: 0..0", r[0] == 0 && r[1] == 0);
        r = FrameOps.targetRange(5, 1, 2, 0);
        check("todos: 0..4", r[0] == 0 && r[1] == 4);
        r = FrameOps.targetRange(5, 4, 0, 3);
        check("proximos alem do fim: vazio", r[0] > r[1]);

        Ano.Mpt[] o = FrameOps.applyAll(a, 1, 2, 3, FrameOps.A_POS | FrameOps.A_HIT | FrameOps.A_SOUND | FrameOps.A_FLIP | FrameOps.A_ZOOM | FrameOps.A_ROT);
        Ano.Mpt t = o[2];
        check("posicao copiada", (t.flags & 1) != 0 && t.midX == 7 && t.midY == -3);
        check("hitbox copiada, hurtbox/acao do alvo mantidas (hurt nao marcado)", t.hits.length == 3 && count(t, 2) == 1 && count(t, 1) == 1 && count(t, 26) == 1 && count(t, 0) == 0);
        check("hitbox e copia, nao o mesmo objeto", t.hits[2].flag == 2 && t.hits[2] != s.hits[0] && t.hits[2].x == 5);
        check("som copiado", (t.flags & 8) != 0 && t.se == 33);
        check("flip copiado, 'fim' (bit 1) nao", ObjModel.spriteBit(t, ObjModel.FLIP_H) && (t.wActFlag & 1) == 0);
        check("rotacao e zoom copiados", (t.flags & 0x80) != 0 && t.rot == 30 && t.xZoom == 150 && t.yZoom == 120);
        check("imagem e tempo intactos", t.image == 2 && t.time == 4);
        check("frame 4 fora do alcance", o[4] == a[4] && o[0] == a[0]);
        check("o frame origem nao muda", o[1] == s);

        // hurtbox marcada substitui as do alvo
        o = FrameOps.applyAll(a, 1, 2, 2, FrameOps.A_HURT);
        check("hurtbox substituida", count(o[2], 1) == 1 && o[2].hits[o[2].hits.length - 1].x == 6 && count(o[2], 26) == 1);
        // animacoes = projetil + efeito
        o = FrameOps.applyAll(a, 1, 3, 3, FrameOps.A_ANIM);
        check("animacoes: projetil e efeito", count(o[3], 0) == 1 && count(o[3], 12) == 1 && count(o[3], 2) == 0);
        // acoes
        o = FrameOps.applyAll(a, 2, 3, 3, FrameOps.A_ACTION);
        check("acao especial copiada", count(o[3], 26) == 1);
        // origem sem o recurso apaga no alvo
        o = FrameOps.applyAll(a, 3, 1, 1, FrameOps.A_SOUND | FrameOps.A_POS | FrameOps.A_ROT | FrameOps.A_ZOOM | FrameOps.A_FLIP | FrameOps.A_HIT);
        check("origem vazia limpa o alvo", (o[1].flags & (8 | 1 | 0x80)) == 0 && count(o[1], 2) == 0 && o[1].hits.length == 3 && !ObjModel.spriteBit(o[1], ObjModel.FLIP_H) && (o[1].wActFlag & 1) == 1 && o[1].xZoom == 100);
        // zoom sem rotacao: so zoom muda
        a[3].flags |= 0x80; a[3].rot = 45; a[3].xZoom = 100; a[3].yZoom = 100; a[3].normalize();
        o = FrameOps.applyAll(a, 1, 3, 3, FrameOps.A_ZOOM);
        check("zoom copiado sem mexer na rotacao", o[3].rot == 45 && o[3].xZoom == 150);
        // tudo mais
        a[1].flags |= 4; a[1].moveMask = 1; a[1].speedX = 65536; a[1].normalize();
        o = FrameOps.applyAll(a, 1, 4, 4, FrameOps.A_MOVE | FrameOps.A_TIME | FrameOps.A_IMAGE);
        check("velocidade, tempo e imagem", (o[4].flags & 4) != 0 && o[4].speedX == 65536 && o[4].image == 1);

        // inserir sprites de uma animacao
        Ano.Mpt[] ins = FrameOps.insertSprites(a, 1, new int[]{70, 71, 72}, new int[]{3, 300, 0});
        check("inseridas depois do frame 1", ins.length == 8 && ins[1] == a[1] && ins[2].image == 70 && ins[4].image == 72 && ins[5] == a[2]);
        check("tempos limitados a 1..255", ins[2].time == 3 && ins[3].time == 255 && ins[4].time == 1);
        check("inseridas sem hits/som/velocidade, com centro e zoom", ins[2].hits.length == 0 && (ins[2].flags & (0x10 | 8 | 4)) == 0 && ins[2].midX == 7 && ins[2].xZoom == 150);
        Ano.Mpt jm = mpt(0, 4);
        check("janela 512 comeca desligada", !ObjModel.optFlagBit(jm, 512));
        Ano.Mpt jon = ObjModel.setOptFlagBit(jm, 512, true);
        check("janela 512 liga e marca o bloco OPT", ObjModel.optFlagBit(jon, 512) && (jon.flags & 0x40) != 0 && jon.hasOpt);
        jon.optFlag |= 4096;
        Ano.Mpt joff = ObjModel.setOptFlagBit(jon, 512, false);
        check("janela 512 desliga sem mexer nos outros bits", !ObjModel.optFlagBit(joff, 512) && (joff.optFlag & 4096) != 0);
        check("setOptFlagBit nao altera o original", ObjModel.optFlagBit(jon, 512));
        // ---- janela 512 como acao especial virtual (flag 512)
        Ano.Mpt[] wm = new Ano.Mpt[4];
        for (int i = 0; i < 4; i++) wm[i] = mpt(i, 4);
        wm[1] = ObjModel.setOptFlagBit(wm[1], 512, true);
        wm[2] = ObjModel.setOptFlagBit(wm[2], 512, true);
        CharData.Move gmv = new CharData.Move();
        gmv.flags = 8;
        java.util.List<ObjModel.Obj> woHidden = ObjModel.objects(wm);
        boolean hid = true;
        for (ObjModel.Obj q : woHidden) if (q.flag == ObjModel.VF_WINDOW) hid = false;
        check("fora de agarrao/repeticao a janela nao aparece na timeline", hid);
        ObjModel.setWindowContext(gmv, 5);
        java.util.List<ObjModel.Obj> wo = ObjModel.objects(wm);
        ObjModel.Obj wobj = null;
        for (ObjModel.Obj q : wo) if (q.flag == ObjModel.VF_WINDOW) wobj = q;
        check("janela 512 vira objeto de acao nos frames 1-2", wobj != null && wobj.kind == ObjModel.ACTION && wobj.f0 == 1 && wobj.f1 == 2);
        check("janela 512 conta e acha o hit virtual", ObjModel.count(wm[1], ObjModel.VF_WINDOW) == 1 && ObjModel.find(wm[1], ObjModel.VF_WINDOW, 0) != null && ObjModel.count(wm[0], ObjModel.VF_WINDOW) == 0);
        Ano.Mpt[] wext = ObjModel.trim(wm, wobj, 1, 3);
        check("estender a janela liga o bit no frame 3 sem criar hit real", ObjModel.optFlagBit(wext[3], 512) && (wext[3].flags & 0x10) == 0);
        Ano.Mpt[] wadd = ObjModel.add(wm, 0, 0, ObjModel.defaultHit(ObjModel.VF_WINDOW));
        check("adicionar a acao liga o bit no frame", ObjModel.optFlagBit(wadd[0], 512));
        Ano.Mpt[] wrem = ObjModel.remove(wm, wobj);
        check("remover a acao desliga o bit", !ObjModel.optFlagBit(wrem[1], 512) && !ObjModel.optFlagBit(wrem[2], 512));
        CharData.Move wmv = new CharData.Move();
        check("sem agarrao nem projetil: sem a acao no +", ObjModel.actionFlagsFor(wmv, 0).length == (ObjModel.ACTION_FLAGS.length + 2));
        wmv.flags = 8;
        check("golpe com agarrao oferece a acao", ObjModel.actionFlagsFor(wmv, 5).length == (ObjModel.ACTION_FLAGS.length + 2) + 1);
        ObjModel.setWindowContext(wmv, 5);
        check("nome: tentar agarrao", "Tentar agarrão".equals(ObjModel.actionName(ObjModel.VF_WINDOW)));
        wmv.flags = 0; wmv.projNormal = 30;
        check("golpe 0 com projetil oferece repeticao", ObjModel.actionFlagsFor(wmv, 0).length == (ObjModel.ACTION_FLAGS.length + 2) + 1);
        check("golpe 1 com projetil nao oferece", ObjModel.actionFlagsFor(wmv, 1).length == (ObjModel.ACTION_FLAGS.length + 2));
        wmv.projNormal = 0;
        check("golpe 0 sem projetil nao oferece repeticao", ObjModel.actionFlagsFor(wmv, 0).length == (ObjModel.ACTION_FLAGS.length + 2));
        wmv.projNormal = 30; wmv.flags = 8; wmv.maxRep = 3;
        check("agarrao + repeticao: conflito, nao oferece", ObjModel.actionFlagsFor(wmv, 0).length == (ObjModel.ACTION_FLAGS.length + 2));
        CharData.Move sq = new CharData.Move();
        sq.flags = 128; sq.animSeqChao = 50;
        check("128 em golpe com SEQ nao oferece Tentar agarrao", ObjModel.actionFlagsFor(sq, 5).length == (ObjModel.ACTION_FLAGS.length + 2));
        sq.flags = 8;
        check("8 em golpe com SEQ continua oferecendo", ObjModel.actionFlagsFor(sq, 5).length == (ObjModel.ACTION_FLAGS.length + 2) + 1);
        sq.flags = 128; sq.animSeqChao = 0;
        check("128 sem SEQ oferece", ObjModel.actionFlagsFor(sq, 5).length == (ObjModel.ACTION_FLAGS.length + 2) + 1);
        sq.animAoAcertar = 30;
        check("SEQ_PROJETIL tambem conta como sequencia", sq.hasSequence() && !sq.grabWorks());
        // ---- flags virtuais: 1024 cenario, 4096+t poeira, 2048 parede
        ObjModel.setCurAno(-1);
        Ano.Mpt[] vm = new Ano.Mpt[4];
        for (int i = 0; i < 4; i++) vm[i] = mpt(i, 4);
        vm[1] = ObjModel.setOptFlagBit(vm[1], 1024, true);
        vm[2] = ObjModel.setOptFlagBit(vm[2], 1024, true);
        vm[2] = ObjModel.setOptFlagBit(vm[2], 2048, true);
        int sceneObjs = 0, wallObjs = 0;
        for (ObjModel.Obj q : ObjModel.objects(vm)) { if (q.flag == ObjModel.VF_SCENE) sceneObjs++; if (q.flag == ObjModel.VF_WALL) wallObjs++; }
        check("1024 vira objeto 'Esconder cenario' nos frames 1-2", sceneObjs == 1);
        check("2048 fora de ANO de reacao fica oculta (bit preservado)", wallObjs == 0 && ObjModel.optFlagBit(vm[2], 2048));
        Ano.Mpt[] vd = ObjModel.add(vm, 0, 1, ObjModel.defaultHit(ObjModel.VF_DUST + 3));
        check("poeira tipo 3 grava bits 4096|8192", ObjModel.dustOf(vd[0]) == 3 && (vd[0].optFlag & 0xF000) == 0x3000);
        ObjModel.Obj dobj = null;
        for (ObjModel.Obj q : ObjModel.objects(vd)) if (ObjModel.isDust(q.flag)) dobj = q;
        check("poeira vira objeto nos frames 0-1", dobj != null && dobj.f0 == 0 && dobj.f1 == 1 && dobj.flag == ObjModel.VF_DUST + 3);
        Ano.Mpt[] vd2 = ObjModel.setFlag(vd, dobj, ObjModel.VF_DUST + 12);
        check("trocar tipo de poeira para 12 (bits 0xC000)", ObjModel.dustOf(vd2[0]) == 12 && ObjModel.dustOf(vd2[1]) == 12 && (vd2[0].optFlag & 0xF000) == 0xC000);
        Ano.Mpt[] vd3 = ObjModel.remove(vd2, ObjModel.objects(vd2).get(0).flag == ObjModel.VF_DUST + 12 ? ObjModel.objects(vd2).get(0) : dobj);
        check("remover poeira zera so os 4 bits da poeira", ObjModel.dustOf(vd3[0]) == 0 && ObjModel.optFlagBit(vd3[1], 1024) );
        check("+ oferece cenario e poeira", ObjModel.actionFlagsFor(null, -1).length == ObjModel.ACTION_FLAGS.length + 2);
        // ---- ALL por sprite
        Ano.Mpt[] sp = new Ano.Mpt[5];
        int[] imgs = {7, 8, 7, 9, 7};
        for (int i = 0; i < 5; i++) sp[i] = mpt(imgs[i], 2);
        sp[0] = ObjModel.add(sp, 0, 0, ObjModel.defaultHit(2))[0];
        check("conta frames com a mesma sprite (menos o proprio)", FrameOps.countSprite(sp, 0, 7) == 2 && FrameOps.countSprite(sp, -1, 7) == 3);
        Ano.Mpt[] spa = FrameOps.applySprite(sp, 0, sp[0], FrameOps.A_HIT);
        check("sprite igual recebe a hitbox", ObjModel.count(spa[2], 2) == 1 && ObjModel.count(spa[4], 2) == 1);
        check("outras sprites ficam intactas", ObjModel.count(spa[1], 2) == 0 && ObjModel.count(spa[3], 2) == 0);
        Ano.Mpt[] bm = new Ano.Mpt[5];
        for (int i = 0; i < 5; i++) bm[i] = mpt(1, 1);
        Ano.Mpt[] bm2 = ObjModel.setFlagRange(bm, 1, 3, 38, true);
        check("bloquear seq: 38 nos frames 1..3", ObjModel.hasFlagRange(bm2, 1, 3, 38) && count(bm2[0], 38) == 0 && count(bm2[4], 38) == 0);
        check("bloquear seq: nao duplica", count(ObjModel.setFlagRange(bm2, 1, 3, 38, true)[2], 38) == 1);
        Ano.Mpt[] bm3 = ObjModel.setFlagRange(bm2, 1, 3, 38, false);
        check("desbloquear remove tudo", !ObjModel.hasFlagRange(bm3, 1, 3, 38) && count(bm3[2], 38) == 0);
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }

    static int count(Ano.Mpt m, int flag) {
        int n = 0;
        if ((m.flags & 0x10) != 0) for (Ano.Hit h : m.hits) if (h.flag == flag) n++;
        return n;
    }
}
