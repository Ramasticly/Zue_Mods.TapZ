package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** FrameTools: velocidade recebida/total, tempo 0, manter velocidade, mover trecho, ids de som. */
public class FrameToolsTest {
    static final int P = 65536;

    static Ano.Mpt f(int time) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = 1;
        if (time > 0) { m.flags |= 0x20; m.time = time; }
        m.normalize();
        return m;
    }

    static Ano.Mpt speed(Ano.Mpt m, double sx, double sy, double ax, double ay) {
        Ano.Mpt c = m.copy();
        if (sx != 0) c = FrameTools.setSpeed(c, 0, sx, true);
        if (sy != 0) c = FrameTools.setSpeed(c, 1, sy, true);
        if (ax != 0) c = FrameTools.setAccel(c, 0, ax);
        if (ay != 0) c = FrameTools.setAccel(c, 1, ay);
        return c;
    }

    static Ano.Mpt keep(Ano.Mpt m) {
        Ano.Mpt c = m.copy();
        c.flags |= 2;
        c.wActFlag |= 64;
        c.normalize();
        return c;
    }

    static String s(double[] v) { return FrameTools.px(v[0]) + "/" + FrameTools.px(v[1]); }

    public static void main(String[] args) throws Exception {
        // frame 0: speed x=10, accel x=-1 por 4 ticks; frame 1 mantem; frame 2 mantem com speed proprio (substitui); frame 3 mantem sem nada
        Ano.Mpt[] m = {speed(f(4), 10, 0, -1, 0), keep(f(3)), keep(speed(f(2), 7, 0, 0, 0)), keep(f(5)), f(5)};
        check("inicio do frame 0", s(FrameTools.startSpeed(m, 0)), "10/0");
        check("fim do frame 0 = speed + accel*ticks (conta como SPEED)", s(FrameTools.endSpeed(m, 0)), "6/0");
        check("frame 1 recebe 6 (accel nao e herdada)", s(FrameTools.received(m, 1)) + ":" + FrameTools.keeps(m, 1), "6/0:true");
        check("frame 1 sem accel proprio: fim = 6", s(FrameTools.endSpeed(m, 1)), "6/0");
        check("frame 2 com speed proprio substitui a recebida", s(FrameTools.startSpeed(m, 2)) + " recebida " + s(FrameTools.received(m, 2)), "7/0 recebida 6/0");
        check("frame 3 recebe 7", s(FrameTools.received(m, 3)), "7/0");
        check("frame 4 sem 64 nao recebe", s(FrameTools.received(m, 4)) + ":" + FrameTools.keeps(m, 4), "0/0:false");
        // total: f0: 10+9+8+7=34, f1: 6*3=18, f2: 7*2=14, f3: 7*5=35
        double[] tot = FrameTools.totalPixels(m, 0, 3);
        check("total de pixels e ticks", FrameTools.px(tot[0]) + ":" + (int) tot[2], "101:14");
        check("total de um frame so", FrameTools.px(FrameTools.totalPixels(m, 0, 0)[0]), "34");
        check("frame sem tempo nao anda", FrameTools.px(FrameTools.totalPixels(new Ano.Mpt[]{speed(f(0), 5, 0, 0, 0)}, 0, 0)[0]), "0");

        // aceleracao so aparece com speed normal (ou accel existente)
        check("accel oculta sem speed", FrameTools.showAccel(f(3)) + ":" + FrameTools.showAccel(keep(f(3))), "false:false");
        check("accel aparece com speed proprio", FrameTools.showAccel(speed(f(3), 2, 0, 0, 0)), true);
        check("accel aparece se ja existe", FrameTools.showAccel(speed(f(3), 0, 0, 0.5, 0)), true);
        check("speed 0 explicito nao conta", FrameTools.showAccel(FrameTools.setSpeed(f(3), 0, 0, true)), false);

        // aceleracao por eixo (SPEED X / SPEED Y)
        check("accelAxis: speed x liga o accel x, nao o y", FrameTools.showAccelAxis(speed(f(3), 2, 0, 0, 0), 0) + ":" + FrameTools.showAccelAxis(speed(f(3), 2, 0, 0, 0), 1), "true:false");
        check("accelAxis: accel so em y", FrameTools.showAccelAxis(speed(f(3), 0, 0, 0, 0.5), 0) + ":" + FrameTools.showAccelAxis(speed(f(3), 0, 0, 0, 0.5), 1), "false:true");
        check("accelAxis: speed 0 explicito nao conta", FrameTools.showAccelAxis(FrameTools.setSpeed(f(3), 1, 0, true), 1), false);
        Ano.Mpt both = speed(f(3), 3, -2, 0.5, 0.25);
        Ano.Mpt noX = FrameTools.clearAxis(both, 0);
        check("clearAxis x: tira speed e accel de x", noX.speedX + ":" + noX.accelX + ":" + (noX.moveMask & 5), "0:0:0");
        check("clearAxis x: y fica", noX.speedY + ":" + noX.accelY + ":" + (noX.moveMask & 10) + ":" + ((noX.flags & 4) != 0), (int) (-2 * P) + ":" + (int) (0.25 * P) + ":10:true");
        Ano.Mpt none = FrameTools.clearAxis(noX, 1);
        check("clearAxis nos dois: o frame fica sem movimento (bit 4 limpo)", none.moveMask + ":" + ((none.flags & 4) != 0), "0:false");
        check("clearAxis nao mexe no original", both.speedX, (int) (3 * P));
        check("axisOwn", FrameTools.axisOwn(both, 0) + ":" + FrameTools.axisOwn(noX, 0) + ":" + FrameTools.axisOwn(noX, 1), "true:false:true");
        Ano.Mpt[] zr = FrameTools.zeroReceivedAxis(new Ano.Mpt[]{speed(f(3), 6, 2, 0, 0), keep(f(3))}, 1, 0);
        check("zeroReceivedAxis: x recebido vira 0, y continua", s(FrameTools.startSpeed(zr, 1)), "0/2");
        check("zeroReceivedAxis sem nada recebido no eixo = null", FrameTools.zeroReceivedAxis(new Ano.Mpt[]{speed(f(3), 6, 0, 0, 0), keep(f(3))}, 1, 1), null);
        Ano.Mpt[] tr = {speed(f(4), 5, -1, 0, 0), keep(f(3))};
        double[] tt = FrameTools.totalPixels(tr, 0, 1);
        check("total por eixo: x e y separados", FrameTools.px(tt[0]) + "/" + FrameTools.px(tt[1]), "35/-7");

        // setSpeed / apagar
        Ano.Mpt a = FrameTools.setSpeed(f(3), 1, -2.5, true);
        check("setSpeed y", a.speedY + ":" + a.moveMask + ":" + ((a.flags & 4) != 0), (int) (-2.5 * P) + ":2:true");
        Ano.Mpt b = FrameTools.setSpeed(a, 1, 0, false);
        check("apagar o unico campo desliga o MOVE", ((b.flags & 4) != 0) + ":" + b.moveMask, "false:0");

        // tempo 0 = sem TIME
        Ano.Mpt t0 = FrameTools.setTime(f(7), 0);
        check("tempo 0 apaga o TIME", ((t0.flags & 0x20) != 0) + ":" + t0.hasTime + ":" + t0.time, "false:false:0");
        Ano.Mpt t1 = FrameTools.setTime(t0, 300);
        check("tempo liga e limita a 255", ((t1.flags & 0x20) != 0) + ":" + t1.time, "true:255");
        check("segundos", FrameTools.seconds(18) + FrameTools.seconds(0), "0.3s0.0s");

        // manter velocidade no proximo frame
        Ano.Mpt[] k = {speed(f(4), 3, 0, 0, 0), f(4), f(4)};
        Ano.Mpt[] k2 = FrameTools.setKeepNext(k, 0, true);
        check("ligar mantem no frame 1", FrameTools.keeps(k2, 1) + ":" + FrameTools.keeps(k2, 2) + ":" + FrameTools.keepsNext(k2, 0), "true:false:true");
        Ano.Mpt[] k3 = FrameTools.setKeepNext(k2, 1, true);
        check("estender o trecho ate o frame 2", FrameTools.keeps(k3, 2), true);
        Ano.Mpt[] k4 = FrameTools.setKeepNext(k3, 0, false);
        check("desligar corta o trecho (frames 1 e 2 perdem o 64)", FrameTools.keeps(k4, 1) + ":" + FrameTools.keeps(k4, 2), "false:false");
        check("ultimo frame nao tem seguinte", FrameTools.setKeepNext(k, 2, true), null);
        Ano.Mpt[] rm = FrameTools.removeReceived(k3, 1);
        check("Remover recebida: frame 1 e 2 sem 64", FrameTools.keeps(rm, 1) + ":" + FrameTools.keeps(rm, 2) + ":" + FrameTools.keeps(rm, 0), "false:false:false");
        check("remover onde nao recebe", FrameTools.removeReceived(k, 1), null);

        // acrescimo sobre a recebida: grava absoluto
        Ano.Mpt[] r = FrameTools.setKeepNext(new Ano.Mpt[]{speed(f(4), 3, 0, 0, 0), f(4)}, 0, true);
        double rec = FrameTools.received(r, 1)[0];
        r[1] = FrameTools.setSpeed(r[1], 0, rec + 2, true);
        check("acrescimo +2 sobre 3 = 5 no frame 1", s(FrameTools.startSpeed(r, 1)) + ":" + (FrameTools.moveRunHeadOk(r, 1)), "5/0:true");

        // mover o inicio do trecho
        Ano.Mpt[] mv = {speed(f(4), 3, 0, 0, 0), keep(f(4)), f(4), f(4), f(4)};
        Ano.Mpt[] mo = FrameTools.moveRunTo(mv, 0, 2);
        check("trecho vai do frame 0 para o 2 (2 frames)", FrameTools.ownSpeed(mo[0]) + ":" + FrameTools.keeps(mo, 1) + ":" + FrameTools.ownSpeed(mo[2]) + ":" + FrameTools.keeps(mo, 3), "false:false:true:true");
        check("nao cabe: devolve null so quando bate em outra velocidade", FrameTools.moveRunTo(new Ano.Mpt[]{speed(f(4), 3, 0, 0, 0), keep(f(4)), f(4), speed(f(4), 1, 0, 0, 0)}, 0, 2), null);

        // ids de som: 0 -> se_max -> 80 -> 80 + wav - 1
        check("0 sobe para 1", FrameTools.stepSound(0, 1, 30, 5), 1);
        check("se_max pula para 80", FrameTools.stepSound(30, 1, 30, 5), 80);
        check("80 desce para se_max", FrameTools.stepSound(80, -1, 30, 5), 30);
        check("ultimo wav fica", FrameTools.stepSound(84, 1, 30, 5), 84);
        check("0 fica no 0 descendo", FrameTools.stepSound(0, -1, 30, 5), 0);
        check("id invalido (50) sobe para 80 e desce para 30", FrameTools.stepSound(50, 1, 30, 5) + ":" + FrameTools.stepSound(50, -1, 30, 5), "80:30");
        check("sem wavs: para no se_max", FrameTools.stepSound(30, 1, 30, 0), 30);
        check("quantidade de ids", FrameTools.soundIds(30, 5).size(), 36);

        System.out.println("FrameToolsTest fails=" + BattleTest.fails);
    }
}
