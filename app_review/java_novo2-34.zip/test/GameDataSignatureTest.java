package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;
import java.nio.file.Files;

/** Assinatura da game data: igual enquanto nada muda, diferente se um arquivo muda de tamanho/data/e novo; vazia sem pasta. */
public class GameDataSignatureTest {
    public static void main(String[] args) throws Exception {
        File root = Files.createTempDirectory("gds").toFile();
        File gd = new File(root, "gamedata");
        gd.mkdirs();
        File f = new File(gd, "a.bin");
        Files.write(f.toPath(), new byte[] {1, 2, 3});
        new File(root, "char00").mkdirs();
        Files.write(new File(new File(root, "char00"), "000.dac").toPath(), new byte[] {9});
        String s1 = GameDataSignature.of(root);
        check("assinatura nao vazia", s1.length() > 0, true);
        check("igual enquanto nada muda", GameDataSignature.of(root).equals(s1), true);
        check("pasta de personagem nao entra", s1.contains("char00"), false);
        check("sem mudanca: nao relê", GameDataSignature.changed(s1, GameDataSignature.of(root)), false);
        Files.write(f.toPath(), new byte[] {1, 2, 3, 4});
        check("arquivo maior: relê", GameDataSignature.changed(s1, GameDataSignature.of(root)), true);
        String s2 = GameDataSignature.of(root);
        Files.write(new File(gd, "b.bin").toPath(), new byte[] {7});
        check("arquivo novo: relê", GameDataSignature.changed(s2, GameDataSignature.of(root)), true);
        check("assinatura anterior vazia: nao mexe", GameDataSignature.changed("", s2), false);
        check("pasta ilegivel: assinatura vazia", GameDataSignature.of(new File(root, "nao-existe")), "");
        System.out.println("GameDataSignatureTest fails=" + fails);
    }
}
