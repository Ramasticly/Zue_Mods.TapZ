package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** GameRules: limites do jogo (hit[50], lnk[13], bytes do DAC, OPT 1, links de 1 nivel, quirk do _Hokan). */
public class GameRulesTest {
    static Ano.Hit hit(int flag) {
        Ano.Hit h = new Ano.Hit();
        h.flag = flag;
        return h;
    }

    static Ano.Mpt mpt(int hits, int flag) {
        Ano.Mpt m = new Ano.Mpt();
        m.hasTime = true;
        m.time = 5;
        m.image = 1;
        m.hits = new Ano.Hit[hits];
        for (int i = 0; i < hits; i++) m.hits[i] = hit(flag);
        return m;
    }

    static Dac base(int n) throws Exception {
        A[] a = new A[n];
        for (int i = 0; i < n; i++) a[i] = new A().mpt(new M().time(1));
        return dac(a);
    }

    static int count(List<GameRules.Issue> l, boolean fatal) {
        int n = 0;
        for (GameRules.Issue i : l) if (i.fatal == fatal) n++;
        return n;
    }

    public static void main(String[] args) throws Exception {
        Dac d = base(20);
        check("limpo: nada a avisar", GameRules.check(d, null, 0).size(), 0);
        check("limpo: resumo vazio", GameRules.summary(GameRules.check(d, null, 0)), "");

        // 10 caixas passam, 11 fecham o jogo (hit[50])
        d.setAno(3, new Ano(3, true, 0, 0, null, new Ano.Mpt[]{mpt(10, 1)}));
        check("10 caixas ok", GameRules.check(d, null, 0).size(), 0);
        d.setAno(3, new Ano(3, true, 0, 0, null, new Ano.Mpt[]{mpt(11, 1)}));
        check("11 caixas e fatal", count(GameRules.check(d, null, 0), true), 1);

        // 13 links passam, 14 fecham (lnk[13])
        Ano.Link[] l13 = new Ano.Link[13], l14 = new Ano.Link[14];
        for (int i = 0; i < 14; i++) { if (i < 13) l13[i] = new Ano.Link(0, 0, 4); l14[i] = new Ano.Link(0, 0, 4); }
        d = base(20);
        d.setAno(5, new Ano(5, true, 2, 0, l13, new Ano.Mpt[]{mpt(0, 1)}));
        check("13 links ok", GameRules.check(d, null, 0).size(), 0);
        d.setAno(5, new Ano(5, true, 2, 0, l14, new Ano.Mpt[]{mpt(0, 1)}));
        check("14 links e fatal", count(GameRules.check(d, null, 0), true), 1);

        // tempo e quantidade de frames em 1 byte
        d = base(20);
        Ano.Mpt slow = mpt(0, 1);
        slow.time = 300;
        d.setAno(6, new Ano(6, true, 0, 0, null, new Ano.Mpt[]{slow}));
        check("tempo 300 e fatal", count(GameRules.check(d, null, 0), true), 1);
        Ano.Mpt[] many = new Ano.Mpt[256];
        for (int i = 0; i < 256; i++) many[i] = mpt(0, 1);
        d.setAno(6, new Ano(6, true, 0, 0, null, many));
        check("256 frames e fatal", count(GameRules.check(d, null, 0), true), 1);

        // imagem fora do CNV: aviso (o jogo nao fecha, o frame fica sem desenho)
        d = base(20);
        Ano.Mpt far = mpt(0, 1);
        far.image = 9;
        d.setAno(7, new Ano(7, true, 0, 0, null, new Ano.Mpt[]{far}));
        List<GameRules.Issue> img = GameRules.check(d, null, 5);
        check("imagem fora do CNV e so aviso", count(img, false) + ":" + count(img, true), "1:0");
        check("sem CNV a checagem desliga", GameRules.check(d, null, 0).size(), 0);

        // OPT 1 acima de 249 com hitbox
        d = base(20);
        Ano.Mpt o = mpt(1, 2);
        o.hasOpt = true;
        o.optData[1] = 250;
        d.setAno(8, new Ano(8, true, 0, 0, null, new Ano.Mpt[]{o}));
        check("OPT 1 = 250 com hitbox e fatal", count(GameRules.check(d, null, 0), true), 1);
        o.optData[1] = 249;
        check("OPT 1 = 249 ok", GameRules.check(d, null, 0).size(), 0);

        // link de link e caixas em ANO de link: o jogo ignora
        d = base(20);
        d.setAno(9, new Ano(9, true, 2, 0, new Ano.Link[]{new Ano.Link(0, 0, 10)}, new Ano.Mpt[]{mpt(0, 1)}));
        d.setAno(10, new Ano(10, true, 2, 0, new Ano.Link[]{new Ano.Link(0, 0, 11)}, new Ano.Mpt[]{mpt(1, 2)}));
        d.setAno(11, new Ano(11, true, 0, 0, null, new Ano.Mpt[]{mpt(0, 1)}));
        List<GameRules.Issue> lk = GameRules.check(d, null, 0);
        check("link de link e caixa em link sao avisos", count(lk, false) + ":" + count(lk, true), "2:0");

        // quirk do _Hokan: o laco que pula as caixas do frame SEGUINTE usa o iHitNum do frame ATUAL; so le lixo se o seguinte tem caixas e rotacao/alfa/zoom
        d = base(20);
        Ano.Mpt a0 = mpt(1, 1), a1 = mpt(2, 1);
        a0.hasOpt = true;
        a0.optData[2] = 1;
        a1.hasRaz = true;
        d.setAno(12, new Ano(12, true, 0, 0, null, new Ano.Mpt[]{a0, a1}));
        check("seguinte com caixas + raz e contagem diferente e fatal", count(GameRules.check(d, null, 0), true), 1);
        a1.hits = new Ano.Hit[]{hit(1)};
        check("mesma contagem de caixas ok", GameRules.check(d, null, 0).size(), 0);
        a1.hits = new Ano.Hit[0];
        check("seguinte sem caixas: o jogo nao pula nada, ok", GameRules.check(d, null, 0).size(), 0);
        a1.hits = new Ano.Hit[]{hit(1), hit(1)};
        a1.hasRaz = false;
        a1.hasOpt = true;
        check("seguinte so com OPT (sem raz) nao le nada depois das caixas, ok", GameRules.check(d, null, 0).size(), 0);
        // o proximo do ultimo frame e o frame 0 (pat >= mpt => 0)
        Ano.Mpt b0 = mpt(2, 1), b1 = mpt(1, 1);
        b0.hasRaz = true;
        b1.hasOpt = true;
        b1.optData[2] = 1;
        d.setAno(13, new Ano(13, true, 0, 0, null, new Ano.Mpt[]{b0, b1}));
        check("interpolacao do ultimo frame olha o frame 0", count(GameRules.check(d, java.util.Arrays.asList(Integer.valueOf(13)), 0), true), 1);

        // so as ANOs pedidas
        d = base(20);
        d.setAno(3, new Ano(3, true, 0, 0, null, new Ano.Mpt[]{mpt(11, 1)}));
        check("filtro por ANOs", GameRules.check(d, java.util.Arrays.asList(Integer.valueOf(4)), 0).size() + ":" + GameRules.check(d, java.util.Arrays.asList(Integer.valueOf(3)), 0).size(), "0:1");
        check("resumo do fatal", GameRules.summary(GameRules.check(d, null, 0)).startsWith("O JOGO FECHA/ERRA: ANO 3 MPT 0"), true);

        System.out.println("GameRulesTest fails=" + BattleTest.fails);
    }
}
