package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Tela do jogo num celular: largura da area, esticamento da faixa da camera, zoom por camada (como o DrawExec do jogo). */
public class GameScreenTest {
    static float r2(float v) { return Math.round(v * 100f) / 100f; }

    public static void main(String[] args) throws Exception {
        GameScreen g20 = GameScreen.of(2400, 1080), g16 = GameScreen.of(1920, 1080), g32 = GameScreen.of(480, 320);
        check("20:9: area de 711 x 320, fGS 1,48", g20.scalW + ":" + r2(g20.fGS), "711:1.48");
        check("16:9: 569 x 320, fGS 1,19", g16.scalW + ":" + r2(g16.fGS), "569:1.19");
        check("3:2 (480 x 320): nada estica", g32.scalW + ":" + r2(g32.fGS), "480:1.0");
        check("em pe ou deitado da o mesmo (o jogo roda deitado)", GameScreen.of(1080, 2400).scalW, 711);
        check("janela visivel centrada em 240", r2(g20.visLeft()) + ":" + r2(g20.visRight()), "-115.5:595.5");
        // faixa da camera
        check("normal: camera na prioridade 9", GameScreen.cameraStart(false, 150, 130, 40, 0), 9);
        check("trava dos especiais: menor chave dos lutadores - 3", GameScreen.cameraStart(true, 150, 130, 40, 0), 127);
        check("ANO 61 de um lutador tambem baixa a camera", GameScreen.cameraStart(false, 150, 126, 61, 0), 123);
        check("Meio (200) e Fundo (17) dentro da faixa normal", GameScreen.inCamera(200, 9) + ":" + GameScreen.inCamera(17, 9), "true:true");
        check("Frente (400) e o efeito 328 nunca", GameScreen.inCamera(400, 9) + ":" + GameScreen.inCamera(328, 9), "false:false");
        check("na trava: Fundo (17, 10, 19, 21) escapa; Meio (200) entra", GameScreen.inCamera(17, 127) + ":" + GameScreen.inCamera(21, 127) + ":" + GameScreen.inCamera(200, 127), "false:false:true");
        // matrizes
        float[] mid = g20.matrix(200, 9, 100f, 240f, 160f);
        check("Meio sem zoom num 20:9: esticado 1,48 em volta de (240, 160)", r2(mid[0]) + ":" + r2(240f * mid[0] + mid[2]) + ":" + r2(0f * mid[0] + mid[2]), "1.48:240.0:-115.5");
        float[] front = g20.matrix(400, 9, 200f, 100f, 100f);
        check("Frente: sempre 1:1 (nem zoom nem esticar)", java.util.Arrays.toString(front), "[1.0, 1.0, 0.0, 0.0]");
        float[] p = GameScreen.plain().matrix(200, 9, 200f, 300f, 200f);
        check("zoom 200% num 480 x 320: o centro do zoom vai para o meio da tela", r2(300f * p[0] + p[2]) + ":" + r2(200f * p[1] + p[3]), "240.0:160.0");
        check("zoom 200% dobra o tamanho", String.valueOf(r2(p[0])), "2.0");
        float[] lockBack = g20.matrix(17, 127, 200f, 300f, 200f);
        check("na trava o Fundo fica 1:1 mesmo com o zoom de 200%", java.util.Arrays.toString(lockBack), "[1.0, 1.0, 0.0, 0.0]");
        System.out.println("GameScreenTest fails=" + fails);
    }
}
