package com.zue.attackeditor;

import java.util.Arrays;
import java.util.TreeSet;
import static com.zue.attackeditor.BattleTest.*;

/** Otimizar GIF: sprites vazias saem, os Frames do DAC passam a sprite que ficou e depois sao renumerados. */
public class GifOptimizeTest {
    static String imgs(Ano a) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.mpts.length; i++) b.append(i == 0 ? "" : ",").append(a.mpts[i].image);
        return b.toString();
    }

    public static void main(String[] args) throws Exception {
        // GIF nas sprites 3..7 (5 quadros); a 5 foi liberada (igual a 4) e a 7 ja era vazia
        boolean[] has = {true, true, false, true, false};
        TreeSet<Integer> del = GifOptimizer.toDelete(3, 5, has);
        check("saem as vazias: liberada (5) e a que ja era vazia (7)... e a 5? has[2] false = SPR_5; has[4] false = SPR_7", del.toString(), "[5, 7]");
        check("tudo com desenho: nada sai", GifOptimizer.toDelete(3, 2, new boolean[]{true, true}).isEmpty(), true);
        check("tamanho menor que o grupo: o que falta conta como vazio", GifOptimizer.toDelete(3, 3, new boolean[]{true}).toString(), "[4, 5]");

        // DAC: ANO 0 usa 3,4,5,6,7 e a sprite 9; ANO 1 usa 5 e 2
        Dac d = dac(new A().mpt(new M().time(2).img(3)).mpt(new M().time(2).img(4)).mpt(new M().time(2).img(5)).mpt(new M().time(2).img(6)).mpt(new M().time(2).img(7)).mpt(new M().time(2).img(9)),
                new A().mpt(new M().time(2).img(5)).mpt(new M().time(2).img(2)));
        // 1) a 5 foi liberada: quem a usava passa para a 4 (replaceUses) -- a 7 ja era vazia
        SpriteMass.replaceUses(d, new java.util.HashSet<Integer>(Arrays.asList(Integer.valueOf(5))), 4);
        check("liberada -> sprite que ficou", imgs(d.getAno(0)) + "|" + imgs(d.getAno(1)), "3,4,4,6,7,9|4,2");
        // 2) as vazias saem e todo o DAC e renumerado
        boolean[] rem = new boolean[12];
        for (Integer i : del) rem[i.intValue()] = true;
        int[] map = SpriteRenumber.map(12, rem);
        SpriteRenumber.remapDac(d, map);
        check("Frames renumerados (6 vira 5, 9 vira 7); a vazia 7 vira -1; 2 e 3 ficam", imgs(d.getAno(0)) + "|" + imgs(d.getAno(1)), "3,4,4,5,-1,7|4,2");

        // CNV: as entradas das removidas somem e as seguintes descem
        byte[] raw = new byte[12 * Cnv.ENTRY_SIZE];
        for (int i = 0; i < 12; i++) System.arraycopy(Cnv.encode(0, i * 10, 0, 8, 8), 0, raw, i * Cnv.ENTRY_SIZE, Cnv.ENTRY_SIZE);
        Cnv c = Cnv.read(raw, false);
        c.removeShift(rem);
        check("CNV com 10 entradas; a SPR_5 passou a ser o recorte que era da 6 (x 60)", c.size() + ":" + c.byImage(5).x, "10:60");

        // grupo: encolhe e mantem sequencia/atrasos
        SpriteGroups gr = new SpriteGroups();
        SpriteGroups.Group grp = new SpriteGroups.Group("g", 3, 5, new int[]{100, 110, 120, 130, 140});
        grp.seq = new int[]{3, 4, 4, 6, 3};
        gr.add(grp);
        gr.remap(map);
        SpriteGroups.Group ng = gr.list.get(0);
        check("o GIF encolhe de 5 para 3 sprites (3, 4, 5) e a sequencia segue", ng.first + ":" + ng.count + ":" + Arrays.toString(ng.seq), "3:3:[3, 4, 4, 5, 3]");

        // ---- GifTiming (Antes/Depois tocam em laco com os atrasos)
        int[] dl = {100, 200, 300};
        check("tempo total do GIF", GifTiming.total(dl), 600L);
        check("quadro em 0, 99, 100, 299, 300, 599 ms", GifTiming.frameAt(dl, 0) + "" + GifTiming.frameAt(dl, 99) + GifTiming.frameAt(dl, 100) + GifTiming.frameAt(dl, 299) + GifTiming.frameAt(dl, 300) + GifTiming.frameAt(dl, 599), "001122");
        check("em laco: 600 ms volta ao primeiro, 1000 ms cai no 3o", GifTiming.frameAt(dl, 600) + ":" + GifTiming.frameAt(dl, 1000), "0:2");
        check("sem quadros = -1; atraso 0 conta como 1 ms", GifTiming.frameAt(new int[0], 50) + ":" + GifTiming.total(new int[]{0, 0}), "-1:2");
    }
}
