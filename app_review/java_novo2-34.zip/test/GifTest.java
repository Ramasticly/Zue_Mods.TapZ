package com.zue.attackeditor;

import java.io.File;
import java.nio.file.Files;

public class GifTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    /** Compoe os quadros crus como o ImageImport faz (sem descarte especial alem de fundo/anterior). */
    static int[][] compose(GifDecoder g) {
        int[] cv = new int[g.width * g.height], prev = null;
        int[][] out = new int[g.frames.size()][];
        GifDecoder.Frame last = null;
        for (int i = 0; i < g.frames.size(); i++) {
            GifDecoder.Frame f = g.frames.get(i);
            if (last != null) {
                if (last.disposal == 2) for (int y = 0; y < last.h; y++) for (int x = 0; x < last.w; x++) set(cv, g, last.x + x, last.y + y, 0);
                else if (last.disposal == 3 && prev != null) cv = prev.clone();
            }
            if (f.disposal == 3) prev = cv.clone();
            for (int y = 0; y < f.h; y++) for (int x = 0; x < f.w; x++) { int c = f.argb[y * f.w + x]; if ((c >>> 24) != 0) set(cv, g, f.x + x, f.y + y, c); }
            out[i] = cv.clone();
            last = f;
        }
        return out;
    }

    static void set(int[] cv, GifDecoder g, int x, int y, int c) { if (x >= 0 && y >= 0 && x < g.width && y < g.height) cv[y * g.width + x] = c; }

    static boolean same(int[] a, byte[] ref, int off) {
        for (int i = 0; i < a.length; i++) {
            int r = ref[off + i * 4] & 255, gg = ref[off + i * 4 + 1] & 255, b = ref[off + i * 4 + 2] & 255, al = ref[off + i * 4 + 3] & 255;
            int v = (al << 24) | (r << 16) | (gg << 8) | b;
            if ((a[i] >>> 24) == 0 && al == 0) continue;
            if (a[i] != v) return false;
        }
        return true;
    }

    public static void main(String[] args) throws Exception {
        if (!new File("/tmp/g/gif/a.gif").isFile()) { System.out.println("sem GIFs de referencia: pulado"); return; }
        byte[] a = Files.readAllBytes(new File("/tmp/g/gif/a.gif").toPath());
        GifDecoder g = GifDecoder.decode(a, 100);
        check("animado: 5 quadros 40x30", g.frames.size() == 5 && g.width == 40 && g.height == 30);
        check("atrasos", g.frames.get(0).delayMs == 50 && g.frames.get(4).delayMs == 90);
        int[][] fr = compose(g);
        byte[] ref = Files.readAllBytes(new File("/tmp/g/gif/a.ref").toPath());
        boolean ok = true;
        for (int i = 0; i < fr.length; i++) ok &= same(fr[i], ref, i * 40 * 30 * 4);
        check("quadros compostos iguais ao PIL", ok);
        byte[] b = Files.readAllBytes(new File("/tmp/g/gif/b.gif").toPath());
        GifDecoder g2 = GifDecoder.decode(b, 100);
        check("entrelacado 200x150", g2.frames.size() == 1 && g2.width == 200);
        check("entrelacado igual ao PIL", same(compose(g2)[0], Files.readAllBytes(new File("/tmp/g/gif/b.ref").toPath()), 0));
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }
}
