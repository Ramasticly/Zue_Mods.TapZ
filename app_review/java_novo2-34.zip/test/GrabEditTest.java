package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Agarrao: distancia do HDAT 3 (byte 5) editavel, gravada e lida no 000.bin.txt; marca na faixa de transicao. */
public class GrabEditTest {
    public static void main(String[] args) throws Exception {
        CharData cb = chr(move(new int[]{2, 40}), new byte[][] {});
        cb.setPullDistance(80);
        check("setPullDistance", cb.pullDistance(), 80);
        cb.setPullDistance(300);
        check("limita a 255", cb.pullDistance(), 255);
        cb.setPullDistance(-5);
        check("nao fica negativa", cb.pullDistance(), 0);
        cb.setPullDistance(120);
        cb.setBody(60, 90);
        check("setBody nao mexe na distancia", cb.pullDistance(), 120);

        String txt = "x {\n  // $DISTANCIA_AGARRE — teleporte dos ATK_FLAGS 8 e 128\n  $STATUS_BASE_E_FISICA:{\n    $LARGURA: 10,\n    $ALTURA: 20,\n    $DISTANCIA_AGARRE: 80,\n    $PODE_VOAR: 1\n  }\n}";
        String out = Saver.patchBody(txt, cb);
        check("patchBody grava a distancia", out.contains("$DISTANCIA_AGARRE: 120,") && out.contains("$PODE_VOAR: 1") && out.contains("// $DISTANCIA_AGARRE —"), true);
        java.io.File tf = java.io.File.createTempFile("bin", ""); tf.deleteOnExit();
        java.io.File tt = new java.io.File(tf.getPath() + ".txt"); tt.deleteOnExit();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(tt); fo.write(out.getBytes("UTF-8")); fo.close();
        CharData c2 = chr(move(new int[]{2, 40}), new byte[][] {});
        TxtOverlay.applyBinTxt(c2, tf);
        check("distancia lida do .txt", c2.pullDistance(), 120);
        check("o resto do corpo tambem", c2.bodyWidth() + "/" + c2.bodyHeight(), "60/90");
        check("sem $DISTANCIA_AGARRE no bloco: nao muda", Saver.patchBody("x { $STATUS_BASE_E_FISICA:{ $LARGURA: 1, $ALTURA: 2 } }", cb).contains("DISTANCIA"), false);

        // a distancia vale na simulacao: o atacante vai para o lado do oponente a essa distancia
        SeqMark g = new SeqMark();
        g.kind = SeqMark.GRAB; g.target = 41;
        check("marca de agarrao: rotulo e titulo", g.label() + "|" + g.title(), "AGARRAR → 41|TENTAR AGARRAO");
        g.incoming = true; g.fromAno = 40; g.fromPat = 2;
        check("marca de entrada do agarrao", g.label(), "← AGARRAR 40·f3");
        check("cor propria do agarrao", TimelineView.markColor(g) != TimelineView.C_SEQ, true);
        check("textos do agarrao em EN/ES", I18n.trTo("AGARRAR → 41", I18n.EN) + "|" + I18n.trTo("TENTAR AGARRAO", I18n.ES), "GRAB → 41|INTENTAR AGARRE");
        System.out.println("GrabEditTest fails=" + fails);
    }
}
