package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Grade de ANOs: excluir (esvazia), copiar, colar, mover, aviso; usos da sprite; texto do (i) de ataque. */
public class GridOpsTest {
    static M mpt(int image) { return new M().time(4).img(image); }

    public static void main(String[] args) throws Exception {
        A[] a = new A[12];
        for (int i = 0; i < a.length; i++) a[i] = new A().mpt(mpt(i % 3)).mpt(mpt(5));
        a[3] = new A().mpt(new M().time(4).img(1).hit(2, 0, 0, 10, 10)).mpt(mpt(2));
        a[4] = new A().mpt(new M().time(4).img(1).hit(0, 0, 0, 0, 0));
        Dac d = dac(a);
        // golpe 1 (Especial 2): ANO inicial 7, ao acertar 8, SEQ chao 9, projetil 10
        byte[] m0 = move(new int[]{2, 40}), m1 = move(new int[]{2, 7}), both = new byte[m0.length + m1.length];
        System.arraycopy(m0, 0, both, 0, m0.length); System.arraycopy(m1, 0, both, m0.length, m1.length);
        CharData cd = chr(both, new byte[][] {});
        cd.moves[1].animInicial = 10; cd.moves[1].animAoAcertar = 11; cd.moves[1].animSeqChao = 5; cd.moves[1].projNormal = 50;

        AnoOps.Risk r3 = AnoOps.risk(d, cd, 3);
        check("hitbox", r3.hitbox + ":" + r3.projectile + ":" + r3.attack, "true:false:false");
        AnoOps.Risk r4 = AnoOps.risk(d, cd, 4);
        check("projetil", r4.hitbox + ":" + r4.projectile, "false:true");
        check("ANO de ataque do BIN", AnoOps.risk(d, cd, 10).attack, true);
        check("ANO comum sem risco", AnoOps.risk(d, cd, 1).any(), false);
        check("aviso lista as ANOs de risco", AnoOps.warning(d, cd, java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(3))).contains("ANO 3") &&
                !AnoOps.warning(d, cd, java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(3))).contains("ANO 1:"), true);

        // copiar / colar / mover / excluir
        AnoOps.Clip c = AnoOps.copy(d, 2);
        check("copia os 2 frames", c.mpts.length, 2);
        AnoOps.clear(d, 2);
        check("excluir: a ANO fica vazia mas continua existindo", AnoOps.isEmpty(d, 2) + ":" + (d.getAno(2) != null) + ":" + d.size(), "true:true:12");
        check("copiar ANO vazia = nada", AnoOps.copy(d, 2) == null, true);
        AnoOps.paste(d, 5, c);
        check("colar substitui os frames (2 frames, imagem do copiado)", d.getAno(5).mpts.length + ":" + d.getAno(5).mpts[0].image, "2:2");
        c.mpts[0].image = 99;
        check("a colagem e uma copia independente", d.getAno(5).mpts[0].image, 2);
        check("mover: o destino recebe e a origem fica vazia", AnoOps.move(d, 5, 6) + ":" + AnoOps.isEmpty(d, 5) + ":" + d.getAno(6).mpts[0].image, "true:true:2");
        check("mover ANO vazia nao faz nada", AnoOps.move(d, 5, 7), false);

        // usos da sprite
        Dac u = dac(new A().mpt(mpt(4)).mpt(mpt(1)).mpt(mpt(4)).mpt(mpt(4)).mpt(mpt(4)).mpt(mpt(9)), new A().mpt(mpt(1)), new A().mpt(mpt(4)).mpt(mpt(4)));
        check("uma linha por ANO", SpriteUses.text(u, 1), "Ano 0, Frame 2\nAno 1, Frame 1");
        check("varios frames: virgulas e 'e' no ultimo", SpriteUses.line(new int[]{0, 1, 3, 4, 5}), "Ano 0, Frames 1, 3, 4 e 5");
        check("dois frames", SpriteUses.line(SpriteUses.find(u, 4).get(1)), "Ano 2, Frames 1 e 2");
        check("sem uso = vazio", SpriteUses.text(u, 77), "");

        // (i) da ANO: textos simples, sem botao
        String info = AttackInfo.anoInfo(cd, 10);
        check("ANO inicial do golpe 1", info, "ANIM_INICIAL do Golpe 1");
        check("SEQ PROJ (ANIM_AO_ACERTAR)", AttackInfo.anoInfo(cd, 11), "SEQ PROJ do golpe 1");
        check("SEQ", AttackInfo.anoInfo(cd, 5), "SEQ do golpe 1");
        check("projetil", AttackInfo.anoInfo(cd, 50), "Projétil do golpe 1");
        check("ANO sem golpe e sem nome fixo: null", AttackInfo.anoInfo(cd, 60), null);
        check("ANO fixa do jogo", AttackInfo.anoInfo(cd, 0), "Parado (idle)");
        check("carga de ki", AttackInfo.anoInfo(cd, 84), "Carga de ki (início)");
        check("pouso padrao", AttackInfo.anoInfo(cd, 13), "Animação de pouso padrão");
        String a30 = AttackInfo.anoInfo(cd, 30), a32 = AttackInfo.anoInfo(cd, 32), a33 = AttackInfo.anoInfo(cd, 33);
        check("ANO 30: as 4 continuacoes da janela", a30.contains("1º golpe") && a30.contains("• A → ANO 32") && a30.contains("• A + frente → ANO 31") && a30.contains("• A + trás → ANO 37") && a30.contains("• A + baixo → ANO 36"), true);
        check("ANO 32: vem do 30 e continua no 33 (e com direcao)", a32.contains("Vem da ANO 30") && a32.contains("• A → ANO 33") && a32.contains("• A + baixo → ANO 36"), true);
        check("ANO 33: vem do 32, sem continuacao", a33.contains("Vem da ANO 32") && a33.contains("Sem continuação") && !a33.contains("•"), true);
        check("ANO 31 (A + frente): sem continuacao", AttackInfo.anoInfo(cd, 31).contains("Sem continuação"), true);
        check("fora de 29-39 nao fala de continuacao", !AttackInfo.anoInfo(cd, 84).contains("continuação"), true);
        java.util.List<AttackInfo.Line> l30 = AttackInfo.anoLines(cd, 30);
        check("ANO fixa do codigo = azul", l30.get(0).src, AttackInfo.CODE);
        java.util.List<AttackInfo.Line> l10 = AttackInfo.anoLines(cd, 10);
        check("papel vindo do BIN = verde", l10.get(0).src, AttackInfo.BIN);
        check("a info da ANO nao cita botao", !String.valueOf(AttackInfo.anoInfo(cd, 7)).contains("Botão"), true);
        cd.moves[1].pousoErrar = 61;
        check("pouso do golpe", AttackInfo.anoInfo(cd, 61), "Animação de pouso do golpe 1");

        // info do golpe: botao + sequencias
        String mi = AttackInfo.moveInfo(cd, 1);
        check("golpe 1 = X, no chao, com gesto e bloco Sequencias do BIN (sem pouso nem projetil)", mi.contains("GOLPE_01") && mi.contains("Botão X — no chão") && mi.contains("joystick: → ↓") && mi.contains("Sequências:") && !mi.contains("automáticas:")
                && mi.contains("SEQ (chão) → ANO 5") && mi.contains("SEQ PROJ → ANO 11") && !mi.contains("pouso") && !mi.contains("projétil"), true);
        java.util.List<AttackInfo.Line> ml = AttackInfo.moveLines(cd, 1);
        boolean seqBin = false, btnCode = false;
        for (AttackInfo.Line ln : ml) { if (ln.text.startsWith("• SEQ (chão)") && ln.src == AttackInfo.BIN) seqBin = true; if (ln.text.startsWith("Botão X") && ln.src == AttackInfo.CODE) btnCode = true; }
        check("SEQ do BIN = verde; botao = azul", seqBin && btnCode, true);
        check("sem repeticao nem agarrao: nenhuma linha (automatica)", !mi.contains("(automática)"), true);
        CharData.Move rm = cd.moves[0];
        rm.maxRep = 3; rm.flags = 8; rm.animInicial = 100; rm.animSeqChao = 0; rm.animSeqAr = 0; rm.animAoAcertar = 0; rm.oponenteAgarrado = 7;
        String mv0 = AttackInfo.moveInfo(cd, 0);
        check("golpe 0 com repeticao e agarrao: duas linhas fixas (automatica) e o agarrao do BIN", mv0.contains("repetição → ANO 42, alterna 40/41 (automática)") && mv0.contains("agarrão → ANO 101 (automática)") && mv0.contains("agarrão (oponente agarrado) → ANO 7"), true);
        rm.maxRep = 3; rm.flags = 0;
        check("repeticao so nos golpes 0/3/6", AttackInfo.moveInfo(cd, 1).contains("repetição"), false);
        check("agarrao fixo so se grabWorks", AttackInfo.moveInfo(cd, 0).contains("agarrão → ANO 101"), false);
        check("golpe 0 = Y; 2 = B; 9 = Z (100 de Synchro); 11 = IRA (AngryOn); 18 sem botao",
                AttackInfo.button(0).name + AttackInfo.button(2).name + AttackInfo.button(9).name + AttackInfo.button(11).name + (AttackInfo.button(18) == null), "YBZIRAtrue");
        check("icones: Y 330, X 333, B 336, Z 339, IRA 45", AttackInfo.button(0).hudAno + ":" + AttackInfo.button(1).hudAno + ":" + AttackInfo.button(2).hudAno + ":" + AttackInfo.button(9).hudAno + ":" + AttackInfo.button(11).hudAno, "330:333:336:339:45");
        check("Z gasta 100 e IRA exige AngryOn", AttackInfo.cost(9).contains("100") && AttackInfo.cost(11).contains("AngryOn"), true);
        System.out.println("GridOpsTest fails=" + fails);
    }
}
