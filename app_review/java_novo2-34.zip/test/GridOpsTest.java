package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Grade de ANOs: excluir (esvazia), copiar, colar, mover, aviso; usos da sprite; texto do (i) de ataque. */
public class GridOpsTest {
    static M mpt(int image) { return new M().time(4).img(image); }

    public static void main(String[] args) throws Exception {
        A[] a = new A[12];
        for (int i = 0; i < a.length; i++) a[i] = new A().mpt(mpt(i % 3)).mpt(mpt(5));
        a[3] = new A().mpt(new M().time(4).img(1).hit(2, 0, 0, 10, 10)).mpt(mpt(2));
        a[4] = new A().mpt(new M().time(4).img(1).hit(0, 0, 0, 0, 0));
        Dac d = dac(a);
        // golpe 1 (Especial 2): ANO inicial 7, ao acertar 8, SEQ chao 9, projetil 10
        byte[] m0 = move(new int[]{2, 40}), m1 = move(new int[]{2, 7}), both = new byte[m0.length + m1.length];
        System.arraycopy(m0, 0, both, 0, m0.length); System.arraycopy(m1, 0, both, m0.length, m1.length);
        CharData cd = chr(both, new byte[][] {});
        cd.moves[1].animInicial = 10; cd.moves[1].animAoAcertar = 11; cd.moves[1].animSeqChao = 5; cd.moves[1].projNormal = 50;

        AnoOps.Risk r3 = AnoOps.risk(d, cd, 3);
        check("hitbox", r3.hitbox + ":" + r3.projectile + ":" + r3.attack, "true:false:false");
        AnoOps.Risk r4 = AnoOps.risk(d, cd, 4);
        check("projetil", r4.hitbox + ":" + r4.projectile, "false:true");
        check("ANO de ataque do BIN", AnoOps.risk(d, cd, 10).attack, true);
        check("ANO comum sem risco", AnoOps.risk(d, cd, 1).any(), false);
        check("aviso lista as ANOs de risco", AnoOps.warning(d, cd, java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(3))).contains("ANO 3") &&
                !AnoOps.warning(d, cd, java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(3))).contains("ANO 1:"), true);

        // copiar / colar / mover / excluir
        AnoOps.Clip c = AnoOps.copy(d, 2);
        check("copia os 2 frames", c.mpts.length, 2);
        AnoOps.clear(d, 2);
        check("excluir: a ANO fica vazia mas continua existindo", AnoOps.isEmpty(d, 2) + ":" + (d.getAno(2) != null) + ":" + d.size(), "true:true:12");
        check("copiar ANO vazia = nada", AnoOps.copy(d, 2) == null, true);
        AnoOps.paste(d, 5, c);
        check("colar substitui os frames (2 frames, imagem do copiado)", d.getAno(5).mpts.length + ":" + d.getAno(5).mpts[0].image, "2:2");
        c.mpts[0].image = 99;
        check("a colagem e uma copia independente", d.getAno(5).mpts[0].image, 2);
        check("mover: o destino recebe e a origem fica vazia", AnoOps.move(d, 5, 6) + ":" + AnoOps.isEmpty(d, 5) + ":" + d.getAno(6).mpts[0].image, "true:true:2");
        check("mover ANO vazia nao faz nada", AnoOps.move(d, 5, 7), false);

        // usos da sprite
        Dac u = dac(new A().mpt(mpt(4)).mpt(mpt(1)).mpt(mpt(4)).mpt(mpt(4)).mpt(mpt(4)).mpt(mpt(9)), new A().mpt(mpt(1)), new A().mpt(mpt(4)).mpt(mpt(4)));
        check("uma linha por ANO", SpriteUses.text(u, 1), "Ano 0, Frame 2\nAno 1, Frame 1");
        check("varios frames: virgulas e 'e' no ultimo", SpriteUses.line(new int[]{0, 1, 3, 4, 5}), "Ano 0, Frames 1, 3, 4 e 5");
        check("dois frames", SpriteUses.line(SpriteUses.find(u, 4).get(1)), "Ano 2, Frames 1 e 2");
        check("sem uso = vazio", SpriteUses.text(u, 77), "");

        // (i) da ANO: textos simples, sem botao
        String info = AttackInfo.anoInfo(cd, 10);
        check("ANO inicial do golpe 1", info, "ANIM_INICIAL do Golpe 1");
        check("ao acertar", AttackInfo.anoInfo(cd, 11), "Ao acertar do golpe 1");
        check("SEQ", AttackInfo.anoInfo(cd, 5), "SEQ do golpe 1");
        check("projetil", AttackInfo.anoInfo(cd, 50), "Projétil do golpe 1");
        check("ANO sem golpe e sem nome fixo: null", AttackInfo.anoInfo(cd, 60), null);
        check("ANO fixa do jogo", AttackInfo.anoInfo(cd, 0), "Parado (idle)");
        check("carga de ki", AttackInfo.anoInfo(cd, 84), "Carga de ki (início)");
        check("pouso padrao", AttackInfo.anoInfo(cd, 13), "Animação de pouso padrão");
        check("ataque normal 30 com janela de combo", AttackInfo.anoInfo(cd, 30).contains("1º golpe") && AttackInfo.anoInfo(cd, 30).contains("Janela de combo"), true);
        check("ataque normal 33 sem janela", AttackInfo.anoInfo(cd, 33).contains("Janela"), false);
        check("a info da ANO nao cita botao", !String.valueOf(AttackInfo.anoInfo(cd, 7)).contains("Botão"), true);
        cd.moves[1].pousoErrar = 61;
        check("pouso do golpe", AttackInfo.anoInfo(cd, 61), "Animação de pouso do golpe 1");

        // info do golpe: botao + sequencias
        String mi = AttackInfo.moveInfo(cd, 1);
        check("golpe 1 = X, no chao, com gesto e sequencias", mi.contains("GOLPE_01") && mi.contains("Botão X — no chão") && mi.contains("joystick: → ↓") && mi.contains("ao acertar → ANO 11")
                && mi.contains("SEQ → ANO 5") && mi.contains("projétil → ANO 50"), true);
        check("golpe 0 = Y; 2 = B; 9 = Z (100 de Synchro); 11 = IRA (AngryOn); 18 sem botao",
                AttackInfo.button(0).name + AttackInfo.button(2).name + AttackInfo.button(9).name + AttackInfo.button(11).name + (AttackInfo.button(18) == null), "YBZIRAtrue");
        check("icones: Y 330, X 333, B 336, Z 339, IRA 45", AttackInfo.button(0).hudAno + ":" + AttackInfo.button(1).hudAno + ":" + AttackInfo.button(2).hudAno + ":" + AttackInfo.button(9).hudAno + ":" + AttackInfo.button(11).hudAno, "330:333:336:339:45");
        check("Z gasta 100 e IRA exige AngryOn", AttackInfo.cost(9).contains("100") && AttackInfo.cost(11).contains("AngryOn"), true);
        System.out.println("GridOpsTest fails=" + fails);
    }
}
