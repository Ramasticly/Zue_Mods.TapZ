package com.zue.attackeditor;

public class GroupsTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    public static void main(String[] a) {
        SpriteGroups g = new SpriteGroups();
        g.add(new SpriteGroups.Group("fogo \"1\".gif", 76, 3, new int[]{50, 60, 70}));
        g.add(new SpriteGroups.Group("x\\y.webp", 90, 2, new int[]{100, 100}));
        SpriteGroups r = new SpriteGroups();
        r.parse(g.toJson());
        check("json ida e volta", r.list.size() == 2 && r.list.get(0).name.equals("fogo \"1\".gif") && r.list.get(0).first == 76 && r.list.get(0).count == 3
                && r.list.get(0).delayMs[2] == 70 && r.list.get(1).name.equals("x\\y.webp"));
        check("at / startingAt", r.at(77) == r.list.get(0) && r.at(78) == r.list.get(0) && r.at(79) == null && r.startingAt(90) == r.list.get(1) && r.startingAt(91) == null);
        check("desfaz grupo tocado", r.dissolveTouching(91, 3) == 1 && r.list.size() == 1);
        check("ticks", SpriteGroups.ticks(100) == 6 && SpriteGroups.ticks(0) == 6 && SpriteGroups.ticks(1) == 1 && SpriteGroups.ticks(999999) == 255 && SpriteGroups.ticks(16) == 1);
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }
}
