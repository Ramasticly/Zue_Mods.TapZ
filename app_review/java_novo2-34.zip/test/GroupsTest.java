package com.zue.attackeditor;

public class GroupsTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    public static void main(String[] a) {
        SpriteGroups g = new SpriteGroups();
        g.add(new SpriteGroups.Group("fogo \"1\".gif", 76, 3, new int[]{50, 60, 70}));
        g.add(new SpriteGroups.Group("x\\y.webp", 90, 2, new int[]{100, 100}));
        SpriteGroups r = new SpriteGroups();
        r.parse(g.toJson());
        check("json ida e volta", r.list.size() == 2 && r.list.get(0).name.equals("fogo \"1\".gif") && r.list.get(0).first == 76 && r.list.get(0).count == 3
                && r.list.get(0).delayMs[2] == 70 && r.list.get(1).name.equals("x\\y.webp"));
        check("at / startingAt", r.at(77) == r.list.get(0) && r.at(78) == r.list.get(0) && r.at(79) == null && r.startingAt(90) == r.list.get(1) && r.startingAt(91) == null);
        check("desfaz grupo tocado", r.dissolveTouching(91, 3) == 1 && r.list.size() == 1);
        check("ticks", SpriteGroups.ticks(100) == 6 && SpriteGroups.ticks(0) == 6 && SpriteGroups.ticks(1) == 1 && SpriteGroups.ticks(999999) == 255 && SpriteGroups.ticks(16) == 1);
        // arquivos de apoio ficam em TBRE/utils/charNN, nunca no char; o que versoes antigas deixaram no char migra
        try {
            java.io.File root = new java.io.File(System.getProperty("java.io.tmpdir"), "groups_test_tapbattle");
            Saver.deleteTree(root);
            java.io.File ch = new java.io.File(root, "assets/char03");
            ch.mkdirs();
            SpriteGroups g1 = new SpriteGroups();
            g1.add(new SpriteGroups.Group("a", 4, 2, new int[]{100, 100}));
            java.io.File old = new java.io.File(ch, SpriteGroups.FILE);
            java.io.FileOutputStream fo = new java.io.FileOutputStream(old);
            fo.write(g1.toJson().getBytes("UTF-8"));
            fo.close();
            SpriteGroups l1 = SpriteGroups.load(ch);
            check("migra o arquivo antigo do char: grupo lido", l1.list.size() == 1 && l1.list.get(0).first == 4);
            check("e o arquivo antigo some do char, indo para TBRE/utils/charNN", !old.exists() && new java.io.File(root, "TBRE/utils/char03/" + SpriteGroups.FILE).isFile());
            l1.add(new SpriteGroups.Group("b", 9, 2, new int[]{50, 50}));
            l1.save(ch);
            check("salvar nao deixa json nem .tmp na pasta do char", !old.exists() && ch.list().length == 0);
            check("e relê de utils", SpriteGroups.load(ch).list.size() == 2);
            new SpriteGroups().save(ch);
            check("sem grupos apaga o arquivo de utils", !new java.io.File(root, "TBRE/utils/char03/" + SpriteGroups.FILE).exists());
        } catch (Exception e) { check("utils: " + e, false); }
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }
}
