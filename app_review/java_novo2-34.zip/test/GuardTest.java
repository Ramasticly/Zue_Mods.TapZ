package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** DEF (oponente defende): DamageChange com var15 == 2 / md 908 do jogo. */
public class GuardTest {
    static boolean noGuardAno;

    static BattleSim make(int atkAno, int opt1, int dmg, int extraFlag, int oppHeight) throws Exception {
        A[] atk = new A[Math.max(41, atkAno + 1)];
        for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(1));
        M hitM = new M().time(3).hit(2, 20, -40 - oppHeight, 40, 20).opt1(opt1).dmg(dmg);
        if (extraFlag > 0) hitM.hit(extraFlag, 0, 0, 1, 1);
        atk[atkAno] = new A().mpt(new M().time(2)).mpt(hitM).mpt(new M().time(40));
        A[] def = new A[90];
        for (int i = 0; i < 90; i++) def[i] = new A().mpt(new M().time(30).hit(1, -10, -60, 20, 60));
        def[0] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        if (noGuardAno) def[4] = new A();
        A[] fx = new A[5];
        for (int i = 0; i < 5; i++) fx[i] = new A().mpt(new M().time(4));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        CharData ch = chr(move(new int[]{2, atkAno}), new byte[][] {});
        int old = BattleSim.oppHeightPx;
        BattleSim.oppHeightPx = oppHeight;
        try { return new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(fx), g, 30, 0, 0); }
        finally { BattleSim.oppHeightPx = old; }
    }

    static int oppAno(BattleSim s) { return s.opponent().root().ano.index; }

    public static void main(String[] args) throws Exception {
        // ---- regressao: DEF desligado = comportamento atual (dano e reacao)
        BattleSim.defend = false;
        BattleSim off = make(40, 3, 20, 0, 0);
        for (int i = 0; i < 6; i++) off.step();
        check("DEF desligado: o golpe causa dano", off.lifeOpponent() < off.lifeAttacker() || off.totalDamage() > 0, true);
        check("DEF desligado: o oponente esta na reacao (ANO 20)", off.defenderInDamage() + ":" + oppAno(off), "true:20");

        BattleSim.defend = true;
        try {
            // ---- golpe com ANO >= 40: arranhao de 2, sem reacao
            BattleSim g = make(40, 3, 20, 0, 0);
            int hp = g.lifeOpponent();
            int x0 = g.opponentX();
            boolean sawSe = false, sawFx = false;
            for (int i = 0; i < 6; i++) {
                g.step();
                for (BattleSim.Snd sn : g.drainSounds()) if (sn.common && sn.id == 8) sawSe = true;
            }
            check("DEF: sem reacao de dano", g.defenderInDamage(), false);
            check("DEF: ANO de guarda 4 (em pe)", oppAno(g), 4);
            check("DEF: arranhao de 2 em golpe ANO >= 40", hp - g.lifeOpponent(), 2);
            check("DEF: o dano total e o do arranhao e o combo nao conta", g.totalDamage() + ":" + g.comboCount(), "2:0");
            check("DEF: toca o SE 8 de defesa", sawSe, true);
            check("DEF: descreve o hit como defendido", g.lastHit().contains("DEFENDIDO"), true);
            check("DEF: o texto diz a ANO de guarda usada", g.lastHit().contains("guarda ANO 4"), true);
            noGuardAno = true;
            BattleSim ng = make(40, 3, 20, 0, 0);
            for (int i = 0; i < 6; i++) ng.step();
            noGuardAno = false;
            check("DEF sem ANO 4 no DAC: defende (sem reacao), fica no idle e avisa", ng.defenderInDamage() + ":" + oppAno(ng) + ":" + ng.lastHit().contains("sem ANO 4 no DAC"), "false:0:true");
            // empurrao: 13 decai 2/tick => (13+11+9+7+5+3+1)/2 = 24,5 px para longe do atacante
            for (int i = 0; i < 20; i++) g.step();
            int dx = g.opponentX() - x0;
            check("DEF: empurrado ~24 px para longe do atacante", dx >= 23 && dx <= 26, true);
            check("DEF: depois do empurrao e do GuardCancelTime volta ao idle (ANO 0)", oppAno(g), 0);
            check("DEF: continua sem reacao", g.defenderInDamage(), false);

            // ---- golpe com ANO < 40: sem arranhao
            BattleSim l = make(30, 3, 20, 0, 0);
            int hpl = l.lifeOpponent();
            for (int i = 0; i < 6; i++) l.step();
            check("DEF: golpe de ANO < 40 nao tira vida", hpl - l.lifeOpponent(), 0);
            check("DEF: mesmo assim defende (ANO 4)", oppAno(l) + ":" + l.defenderInDamage(), "4:false");

            // ---- dano 0 nao arranha
            BattleSim z = make(40, 3, 0, 0, 0);
            int hpz = z.lifeOpponent();
            for (int i = 0; i < 6; i++) z.step();
            check("DEF: golpe sem dano nao arranha", hpz - z.lifeOpponent(), 0);

            // ---- flag 26: o inimigo nao defende
            BattleSim f26 = make(40, 3, 20, 26, 0);
            for (int i = 0; i < 6; i++) f26.step();
            check("DEF: flag 26 ignora a defesa (reacao normal)", f26.defenderInDamage() + ":" + oppAno(f26), "true:20");

            // ---- no ar: ANO 81
            BattleSim air = make(40, 3, 20, 0, 60);
            for (int i = 0; i < 6; i++) air.step();
            check("DEF no ar: ANO 81", oppAno(air) + ":" + air.defenderInDamage(), "81:false");

            // ---- grupo 4 (sem efeito, som nem hitstop): defende sem efeito/SE e sem hitstop
            BattleSim g4 = make(40, 203, 20, 0, 0);
            boolean se4 = false;
            for (int i = 0; i < 6; i++) { g4.step(); for (BattleSim.Snd sn : g4.drainSounds()) if (sn.common && sn.id == 8) se4 = true; }
            check("DEF grupo 4: defende, sem SE de defesa e sem hitstop", g4.defenderInDamage() + ":" + oppAno(g4) + ":" + se4 + ":" + g4.hitstopDefender(), "false:4:false:0");

            // ---- hitstop do grupo 0 vale (10 no atacante e no defensor)
            BattleSim hs = make(40, 3, 20, 0, 0);
            int maxHs = 0;
            for (int i = 0; i < 6; i++) { hs.step(); maxHs = Math.max(maxHs, hs.hitstopAttacker()); }
            check("DEF: o hitstop do OPT 1 continua", maxHs > 0, true);

            // ---- arranhao que mata: reacao de KO
            BattleSim kill = make(40, 3, 255, 0, 0);
            kill.setOpponentChar(null);
            // vida 1: so cabe ao proprio sim; usa muitos hits? aqui so garante que 2 de vida nunca fica negativa
            for (int i = 0; i < 6; i++) kill.step();
            check("DEF: vida nunca negativa", kill.lifeOpponent() >= 0, true);

            // ---- md 882: o golpe defendido tambem confirma o hit (vai para a ANIM_SEQ)
            CharData chS = chr(move(new int[]{2, 40}, new int[]{10, 41}, new int[]{12, 42}), new byte[][] {});
            A[] sq = new A[43];
            for (int i = 0; i < 43; i++) sq[i] = new A().mpt(new M().time(1));
            sq[41] = new A().mpt(new M().time(6));
            sq[42] = new A().mpt(new M().time(30));
            sq[40] = new A().mpt(new M().time(2)).mpt(new M().time(4).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(20));
            A[] def = new A[90];
            for (int i = 0; i < 90; i++) def[i] = new A().mpt(new M().time(30).hit(1, -10, -60, 20, 60));
            GameData gg = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
            BattleSim q = new BattleSim(dac(sq), chS, chS.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), gg, 30, 0, 0);
            for (int i = 0; i < 6; i++) q.step();
            check("DEF: golpe defendido confirma o hit e troca para ANIM_SEQ", q.attacker().root().ano.index + ":" + q.defenderInDamage(), "41:false");

            // ---- projetil tambem e defendido (arranhao so se o ANO do projetil >= 40; aqui o ANO 30 = sem arranhao)
            A[] pa = new A[41];
            for (int i = 0; i < 41; i++) pa[i] = new A().mpt(new M().time(1));
            pa[40] = new A().mpt(new M().time(2).hit(0, 10, -30, 4, 4)).mpt(new M().time(40));
            pa[30] = new A().mpt(new M().time(60).speedX(2 << 16).hit(2, 0, -30, 16, 20).opt1(3));
            pa[31] = new A().mpt(new M().time(3));
            CharData chP = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{6, 31}), new byte[][] {});
            BattleSim ps = new BattleSim(dac(pa), chP, chP.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), gg, 120, 0, 0);
            boolean guarded = false;
            for (int i = 0; i < 80; i++) { ps.step(); if (ps.defenderInDamage()) break; if (oppAno(ps) == 4) guarded = true; }
            check("DEF: o projetil tambem e defendido (ANO 4, sem reacao)", guarded + ":" + ps.defenderInDamage(), "true:false");
        } finally {
            BattleSim.defend = false;
        }

        // ---- ANOs em que o jogo deixa defender
        boolean ok = true;
        int[] yes = {0, 1, 2, 3, 4, 5, 10, 12, 13, 14, 19, 25, 80, 81};
        int[] no = {6, 7, 8, 9, 82, 83, 20, 21, 24, 26, 79, 84, 200};
        for (int a : yes) ok &= BattleSim.guardableAno(a);
        for (int a : no) ok &= !BattleSim.guardableAno(a);
        check("ANOs que defendem: 0-5, 10-19, 25 (e 13), 80 e 81; nao 6-9, 82, 83 nem 20+", ok, true);
        System.out.println("GuardTest fails=" + fails);
    }
}
