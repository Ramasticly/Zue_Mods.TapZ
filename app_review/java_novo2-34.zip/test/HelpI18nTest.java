package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** AJUDA em EN/ES: todo texto traduzido, numeros e identificadores preservados, busca nos tres idiomas e mensagem de compartilhamento. */
public class HelpI18nTest {
    /** Titulos que sao iguais em PT e EN (so identificadores) ou em PT e ES (cognatos). */
    static final Set<String> SAME = new HashSet<String>(java.util.Arrays.asList("SEQ_PROJETIL (ANIM_AO_ACERTAR)", "Hitbox / Hurtbox", "Barra de título", "MODO: GOLPES / ANO", "GOLPE SET (ATK_FLAGS)"));

    static List<String> all() {
        List<String> l = new ArrayList<String>();
        l.add(HelpText.REORDER_TIP);
        List<HelpText.Section> secs = new ArrayList<HelpText.Section>(HelpText.toolbar());
        for (HelpText.Chapter c : HelpText.chapters()) {
            l.add(c.title); l.add(c.summary);
            secs.addAll(c.sections);
        }
        for (HelpText.Section s : secs) { l.add(s.title); l.add(s.body); if (s.tags.length() > 0) l.add(s.tags); }
        return l;
    }

    static List<String> numbers(String s) {
        List<String> out = new ArrayList<String>();
        Matcher m = Pattern.compile("\\d+").matcher(s);
        while (m.find()) out.add(m.group());
        java.util.Collections.sort(out);
        return out;
    }

    static Set<String> idents(String s) {
        Set<String> out = new HashSet<String>();
        Matcher m = Pattern.compile("\\b(?!AAAA)[A-Z][A-Za-z0-9]*_[A-Za-z0-9_]+\\b|\\$[A-Z_0-9+]+|\\b(?:ANO|DAC|BIN|CNV|MPT|HDAT|OPT|SEQ|END|TBRHelp|ATK_FLAGS|BulletNum)\\b").matcher(s);
        while (m.find()) out.add(m.group());
        return out;
    }

    public static void main(String[] args) {
        int old = I18n.lang();
        List<String> texts = all();
        // os mesmos textos sao unicos ou repetidos; so interessa o conjunto
        Set<String> uniq = new HashSet<String>(texts);
        int untranslated = 0, emptyEs = 0, numBad = 0, idBad = 0;
        StringBuilder bad = new StringBuilder();
        for (String pt : uniq) {
            String en = I18n.trTo(pt, I18n.EN), es = I18n.trTo(pt, I18n.ES);
            boolean neutral = pt.length() < 30 && !pt.contains(" ") || pt.matches("[A-Z0-9 /_.\\-]+") || SAME.contains(pt);
            if (!neutral && (en.equals(pt) || (es.equals(pt) && pt.length() > 40))) { untranslated++; bad.append("[sem traducao] ").append(pt, 0, Math.min(40, pt.length())).append('\n'); }
            if (en.trim().isEmpty() || es.trim().isEmpty()) emptyEs++;
            if (!numbers(pt).equals(numbers(en)) || !numbers(pt).equals(numbers(es))) { numBad++; bad.append("[numeros] ").append(pt, 0, Math.min(40, pt.length())).append(' ').append(numbers(pt)).append(numbers(en)).append(numbers(es)).append('\n'); }
            Set<String> ip = idents(pt);
            if (!idents(en).containsAll(ip) || !idents(es).containsAll(ip)) { idBad++; bad.append("[identificadores] ").append(pt, 0, Math.min(40, pt.length())).append('\n'); }
        }
        if (bad.length() > 0) System.out.println(bad);
        check("todo texto da ajuda (" + uniq.size() + ") tem EN e ES (exceto termos neutros)", untranslated, 0);
        check("nenhuma traducao vazia", emptyEs, 0);
        check("numeros iguais em PT, EN e ES (limites, bits, ids)", numBad, 0);
        check("identificadores ($KEYS, SEQ_PROJETIL, ANO, DAC...) preservados", idBad, 0);

        // titulos de botao traduzidos de forma coerente com o resto da interface
        check("titulos EN: Movimento -> Movement, Salvar e backups -> Saving and backups", I18n.trTo("Movimento", I18n.EN).equals("Movement") && I18n.trTo("Salvar e backups", I18n.EN).equals("Saving and backups"), true);
        check("titulos ES: Reações -> Reacciones", I18n.trTo("Reações", I18n.ES), "Reacciones");
        check("PT continua sendo a fonte (trTo PT devolve igual)", I18n.trTo("Movimento", I18n.PT), "Movimento");

        // busca nos tres idiomas
        I18n.set(I18n.PT);
        check("EN: 'velocity' acha Movimento", found("velocity", "Movimento"), true);
        check("ES: 'velocidad' acha Movimento", found("velocidad", "Movimento"), true);
        check("EN: 'backup' acha SALVAR", found("backup", "SALVAR"), true);
        check("ES: 'respaldo' acha SALVAR", found("respaldo", "SALVAR"), true);
        check("EN: 'landing' acha POUSO", found("landing", "POUSO"), true);
        check("ES: 'aterrizaje' acha POUSO", found("aterrizaje", "POUSO"), true);
        check("EN: 'projectile' acha Tela do projétil", found("projectile", "Tela do projétil"), true);
        check("ES: 'proyectil' acha Tela do projétil", found("proyectil", "Tela do projétil"), true);
        check("EN: 'reaction' acha Editor de reações", found("reaction", "Editor de reações"), true);
        check("ES: 'reaccion' acha Editor de reações", found("reaccion", "Editor de reações"), true);
        check("EN com erro de digitacao: 'acelleration' acha Speed x Accel", found("acelleration", "Speed x Accel (velocidade e aceleração)"), true);
        I18n.set(I18n.EN);
        List<HelpText.Hit> hits = HelpText.search("speed");
        boolean sn = !hits.isEmpty();
        for (HelpText.Hit h : hits) if (!h.tab) sn &= h.snippet.length() > 0 && h.snippet.length() < 260 && I18n.tr(h.section.body).contains(h.snippet.replace("… ", "").replace(" …", "").trim());
        check("em EN o trecho da busca vem do texto em EN", sn, true);
        I18n.set(old);

        // mensagem que acompanha o MD no compartilhamento
        I18n.set(I18n.PT);
        String pt = AiHelp.shareMessage();
        I18n.set(I18n.EN);
        String en = AiHelp.shareMessage(), enTitle = AiHelp.chooserTitle();
        I18n.set(I18n.ES);
        String es = AiHelp.shareMessage(), esTitle = AiHelp.chooserTitle();
        I18n.set(old);
        check("mensagem PT cita o arquivo", pt.startsWith("Leia este arquivo (TBRHelp.md)"), true);
        check("mensagem EN", en, "Read this file (TBRHelp.md): it describes the Attack Editor app. Then answer my questions about how to create and edit attacks.");
        check("mensagem ES", es, "Lee este archivo (TBRHelp.md): describe la app Attack Editor. Después responde a mis preguntas sobre cómo crear y editar ataques.");
        check("titulo do compartilhar EN/ES", enTitle + "|" + esTitle, "Send TBRHelp.md to an AI|Enviar TBRHelp.md a una IA");
        // o arquivo nao muda com o idioma
        I18n.set(I18n.PT);
        String docPt = AiHelp.build("x");
        I18n.set(I18n.EN);
        String docEn = AiHelp.build("x");
        I18n.set(I18n.ES);
        String docEs = AiHelp.build("x");
        I18n.set(old);
        check("TBRHelp.md identico em PT, EN e ES", docPt.equals(docEn) && docPt.equals(docEs), true);
        check("anexo A do MD fica em PT (a ajuda do app literal)", docEn.contains("Primeiros passos") && !docEn.contains("Getting started"), true);
        System.out.println("HelpI18nTest fails=" + fails);
    }

    static boolean found(String q, String title) {
        for (HelpText.Hit h : HelpText.search(q)) if (h.section.title.equals(title)) return true;
        return false;
    }
}
