package com.zue.attackeditor;

import java.util.List;

/** Busca da AJUDA: aproximacao (erros de digitacao), correlacao (sinonimos/tags) e abas antes de textos. Java puro. */
public class HelpSearchTest {
    static int fails = 0, oks = 0;

    static void check(String name, Object got, Object want) {
        boolean ok = got == null ? want == null : got.equals(want);
        if (ok) { oks++; System.out.println("OK   " + name); }
        else { fails++; System.out.println("FAIL " + name + " got=" + got + " want=" + want); }
    }

    static String first(String q) {
        List<HelpText.Hit> h = HelpText.search(q);
        return h.isEmpty() ? "-" : h.get(0).section.title + (h.get(0).tab ? "[aba]" : "[txt]");
    }

    static boolean tabsBeforeTexts(String q) {
        boolean seenText = false;
        for (HelpText.Hit h : HelpText.search(q)) {
            if (!h.tab) seenText = true;
            else if (seenText) return false;
        }
        return true;
    }

    public static void main(String[] a) {
        check("distancia: insercao", HelpText.distance("sped", "speed"), 1);
        check("distancia: troca", HelpText.distance("spped", "speed"), 1);
        check("distancia: duplicada", HelpText.distance("spedd", "speed"), 1);
        check("distancia: transposicao conta 1", HelpText.distance("sequnecia", "sequencia"), 1);
        check("match: palavra curta so exata", HelpText.match("seg", "seq"), 0);
        check("match: prefixo", HelpText.match("veloc", "velocidade") > 60, true);

        for (String q : new String[] { "speed", "sped", "spped", "spedd", "speeed", "SPEED", "dash", "velocidade", "velocidde", "aceleracao" }) {
            String f = first(q);
            check("'" + q + "' poe a aba Movimento em primeiro", f, "Movimento[aba]");
        }
        check("correlacao: pixels", first("pixels"), "Movimento[aba]");
        check("correlacao: gravidade", first("gravidade").endsWith("[aba]"), true);

        check("erro: hitbx acha a aba HITBOX ou Hitbox/Hurtbox", first("hitbx").endsWith("[aba]") && HelpText.search("hitbx").get(0).section.title.toLowerCase().contains("hit"), true);
        check("erro: reaçao (sem til)", HelpText.search("reaçao").size() > 3, true);
        check("erro: sequnecia", HelpText.search("sequnecia").size() > 2, true);
        check("sequnecia: aba de transicao/sequencia vem primeiro", first("sequnecia").endsWith("[aba]"), true);
        check("combo leva as sequencias", HelpText.search("combo").size() > 0, true);
        check("editor de reacoes aparece para 'knockback'", first("knockback").endsWith("[aba]"), true);

        for (String q : new String[] { "speed", "reacao", "salvar", "sequencia", "hitbox", "som", "projetil", "tempo" })
            check("abas sempre antes dos textos: " + q, tabsBeforeTexts(q), true);
        boolean anyTab = false, anyText = false;
        for (HelpText.Hit h : HelpText.search("speed")) { anyTab |= h.tab; anyText |= !h.tab; }
        check("speed tem as duas faixas", anyTab && anyText, true);

        boolean sn = true, any = false;
        for (HelpText.Hit h : HelpText.search("limite")) if (!h.tab) { any = true; sn &= h.snippet.length() > 0 && h.snippet.length() < 220; }
        check("textos trazem trecho curto", any && sn, true);
        boolean tabNoSnippet = true;
        for (HelpText.Hit h : HelpText.search("speed")) if (h.tab) tabNoSnippet &= h.snippet.isEmpty();
        check("abas nao trazem trecho", tabNoSnippet, true);

        check("lixo nao acha nada", HelpText.search("xqzwkjv").size(), 0);
        check("palavra extra inexistente zera", HelpText.search("speed palavraqueNaoExiste").size(), 0);
        check("busca vazia", HelpText.search("   ").size(), 0);
        check("varias palavras exigem todas (speed accel)", HelpText.search("speed accel").size() > 0, true);
        check("bit 64 acha o capitulo speed", first("bit 64").length() > 1 && !first("bit 64").equals("-"), true);
        boolean inSpeed = false;
        for (HelpText.Hit h : HelpText.search("bit 64")) inSpeed |= h.chapter.id.equals("speed");
        check("bit 64 inclui o capitulo speed", inSpeed, true);
        check("palavra com underscore: SEQ_PROJETIL", HelpText.search("SEQ_PROJETIL").size() > 0, true);

        int tabs = 0;
        for (List<HelpText.Chapter> l = java.util.Collections.singletonList(null); l != null; l = null) {
            for (HelpText.Chapter ch : HelpText.chapters()) for (HelpText.Section s : ch.sections) if (s.tab) tabs++;
        }
        check("ha abas marcadas (menu superior 14 + paginas)", tabs >= 30, true);
        boolean toolbarTabs = true;
        for (HelpText.Section s : HelpText.toolbar()) toolbarTabs &= s.tab && s.tags.length() > 5;
        check("todo botao do menu superior e aba com tags", toolbarTabs, true);

        System.out.println("HelpSearchTest ok=" + oks + " fails=" + fails);
        if (fails > 0) System.exit(1);
    }
}
