package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Hitbox nunca une Frames: o hit se repete a cada Frame, entao ha sempre um objeto por Frame (hurtbox e o resto continuam unindo). */
public class HitboxPerFrameTest {

    static int count(List<ObjModel.Obj> l, int kind) {
        int n = 0;
        for (ObjModel.Obj o : l) if (o.kind == kind) n++;
        return n;
    }

    public static void main(String[] args) throws Exception {
        Ano.Mpt[] m = ObjMoveTest.frames(5);
        for (int f = 1; f <= 3; f++) ObjMoveTest.put(m, f, ObjMoveTest.hit(2, 5));
        for (int f = 0; f <= 3; f++) ObjMoveTest.put(m, f, ObjMoveTest.hit(1, 7));
        List<ObjModel.Obj> o = ObjModel.objects(m);
        check("3 frames iguais de hitbox = 3 objetos", count(o, ObjModel.HITBOX), 3);
        check("hurtbox igual continua um objeto so", count(o, ObjModel.HURTBOX), 1);
        boolean one = true;
        for (ObjModel.Obj x : o) if (x.kind == ObjModel.HITBOX && x.f0 != x.f1) one = false;
        check("cada hitbox ocupa um Frame so", one, true);

        // projetil/efeito/acao continuam unindo
        Ano.Mpt[] p = ObjMoveTest.frames(4);
        for (int f = 0; f <= 2; f++) ObjMoveTest.put(p, f, ObjMoveTest.hit(40, 5));
        check("acao igual continua unida", count(ObjModel.objects(p), ObjModel.ACTION), 1);

        // apagar / mover so mexem no Frame
        ObjModel.Obj mid = null;
        for (ObjModel.Obj x : o) if (x.kind == ObjModel.HITBOX && x.f0 == 2) mid = x;
        Ano.Mpt[] gone = ObjModel.remove(m, mid);
        List<ObjModel.Obj> og = ObjModel.objects(gone);
        check("apagar o do meio deixa 2 hitboxes", count(og, ObjModel.HITBOX), 2);
        check("frames 1 e 3 intactos, 2 sem hit", ObjModel.count(gone[1], 2) + ":" + ObjModel.count(gone[2], 2) + ":" + ObjModel.count(gone[3], 2), "1:0:1");
        Ano.Mpt[] mv = ObjModel.move(m, mid, 4);
        check("mover o do meio para o Frame 5", ObjModel.count(mv[2], 2) + ":" + ObjModel.count(mv[4], 2) + ":" + count(ObjModel.objects(mv), ObjModel.HITBOX), "0:1:3");

        // esticar copia para o Frame novo, que vira objeto proprio
        ObjModel.Obj last = null;
        for (ObjModel.Obj x : o) if (x.kind == ObjModel.HITBOX && x.f0 == 3) last = x;
        Ano.Mpt[] tr = ObjModel.trim(m, last, 3, 4);
        check("trim copia a hitbox, 4 objetos de um Frame", count(ObjModel.objects(tr), ObjModel.HITBOX) + ":" + ObjModel.count(tr[4], 2), "4:1");

        // editar valores de um Frame nao afeta os outros
        Ano.Mpt[] ed = m.clone();
        ed[2] = m[2].copy();
        ed[2].hits[ed[2].hits.length - 1].x = 99;
        check("hitbox diferente em um Frame: ainda 3 objetos", count(ObjModel.objects(ed), ObjModel.HITBOX), 3);
        System.out.println("HitboxPerFrameTest fails=" + fails);
    }
}
