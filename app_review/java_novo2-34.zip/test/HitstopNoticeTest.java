package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Aviso de hitstop do botao de tick: quanto falta, tick travado, some ao liberar; e o hitstop real do BattleSim. */
public class HitstopNoticeTest {
    public static void main(String[] args) throws Exception {
        HitstopNotice n = new HitstopNotice();
        check("sem hitstop: inativo e mostra o tick real", n.active() + ":" + n.shownTick(7), "false:7");
        n.afterStep(12, 10);
        check("entrou no congelamento: aviso com N e tick travado", n.active() + ":" + n.left() + ":" + n.shownTick(12), "true:10:12");
        n.afterStep(13, 9);
        check("proximo passo: N cai e o tick continua travado no primeiro", n.left() + ":" + n.shownTick(13), "9:12");
        n.afterStep(14, 1);
        check("ultimo tick congelado", n.left() + ":" + n.text().contains("mais 1 tick ") , "1:true");
        n.afterStep(15, 0);
        check("liberou: aviso some e o tick real volta", n.active() + ":" + n.shownTick(15), "false:15");
        n.afterStep(16, 5);
        n.clear();
        check("clear (timeline/barra/play) apaga o aviso", n.active() + ":" + n.shownTick(20), "false:20");

        // o hitstop real: golpe que acerta congela o atacante 10 ticks; o ponteiro (pat/time) nao anda neles
        A[] a = new A[45];
        for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
        a[40] = new A().mpt(new M().time(30).hit(2, -40, -40, 400, 100)).mpt(new M().time(5));
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim.edgeMode = 1;
        BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 20, 0, 0);
        // passo a passo (como o botao de tick): o que o aviso diria (hitstopAttacker depois do passo) e se o ponteiro andou
        StringBuilder trace = new StringBuilder();
        int firstLeft = -1, stalled = 0, afterRelease = -1;
        int prevTime = s.attacker().root().time;
        boolean hit = false;
        for (int t = 0; t < 60 && afterRelease < 0; t++) {
            s.step();
            int hs = s.hitstopAttacker(), time = s.attacker().root().time;
            boolean moved = time != prevTime;
            prevTime = time;
            if (!hit && hs > 0) { hit = true; firstLeft = hs; trace.append("hit:").append(hs).append(moved ? "m " : "s "); continue; }
            if (hit) {
                trace.append(hs).append(moved ? "m " : "s ");
                if (!moved) stalled++;
                else afterRelease = hs;
            }
        }
        System.out.println("INFO " + trace);
        check("o aviso mostra os ticks que faltam: iguais aos passos em que o ponteiro nao anda", firstLeft, stalled);
        check("liberou: o ponteiro volta a andar e o hitstop zerou", afterRelease, 0);
        System.out.println("HitstopNoticeTest fails=" + fails);
    }
}
