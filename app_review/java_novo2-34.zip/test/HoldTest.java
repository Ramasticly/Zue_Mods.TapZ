package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Botoes - / + pressionados: o passo cresce com as repeticoes (pulam mais numeros), nunca diminui e o toque simples vale 1. */
public class HoldTest {
    public static void main(String[] args) throws Exception {
        check("o toque (repeticao 0) vale 1", Hold.multiplier(0), 1);
        check("primeiras repeticoes valem 1", Hold.multiplier(1) + "," + Hold.multiplier(5), "1,1");
        check("depois passa a 5x", Hold.multiplier(6) + "," + Hold.multiplier(13), "5,5");
        check("depois 10x", Hold.multiplier(14) + "," + Hold.multiplier(23), "10,10");
        check("e por fim 25x", Hold.multiplier(24) + "," + Hold.multiplier(500), "25,25");
        boolean mono = true, min1 = true;
        for (int i = 1; i < 200; i++) { if (Hold.multiplier(i) < Hold.multiplier(i - 1)) mono = false; if (Hold.multiplier(i) < 1) min1 = false; }
        check("nunca diminui nem fica abaixo de 1", mono && min1, true);
        // rotacao em passos de 5: segurando por ~2 s o valor anda bem mais que 1 toque
        int v = 0;
        for (int rep = 0; rep < 30; rep++) v += 5 * Hold.multiplier(rep);
        check("30 repeticoes de 5 graus somam bem mais que 150", v > 800, true);
    }
}
