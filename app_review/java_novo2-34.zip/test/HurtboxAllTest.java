package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** "Aplicar a todas as Hurtboxes": copia x/y/largura/altura para todas as caixas de flag 1 sem tocar no resto. */
public class HurtboxAllTest {
    static Ano.Hit hit(Ano.Mpt m, int flag, int occ) { return ObjModel.find(m, flag, occ); }

    public static void main(String[] args) throws Exception {
        A[] a = SpawnDiagTest.anos();
        a[40] = new A()
                .mpt(new M().time(4).hit(1, -10, -60, 20, 60).hit(2, 5, -40, 30, 10))
                .mpt(new M().time(4).hit(1, -12, -58, 24, 58))
                .mpt(new M().time(4))
                .mpt(new M().time(4).hit(1, 0, 0, 5, 5).hit(1, 7, 7, 8, 8));
        Ano.Mpt[] mp = dac(a).getAno(40).mpts;
        Ano.Mpt[] out = ObjModel.setAllCoords(mp, 1, -8, -70, 16, 70);
        check("3 frames mudam (o sem hurtbox nao)", ObjModel.countChanged(mp, out), 3);
        check("frame sem hurtbox e o mesmo objeto", out[2] == mp[2], true);
        boolean all = true;
        for (Ano.Mpt m : out) for (Ano.Hit h : ObjModel.hitsOf(m)) if (h.flag == 1) all &= h.x == -8 && h.y == -70 && h.width == 16 && h.height == 70;
        check("toda hurtbox (inclusive as 2 do ultimo frame) ficou igual", all, true);
        Ano.Hit hb = hit(out[0], 2, 0);
        check("hitbox (flag 2) intacta", hb.x == 5 && hb.y == -40 && hb.width == 30 && hb.height == 10, true);
        check("o original nao foi alterado", hit(mp[0], 1, 0).x == -10 && hit(mp[3], 1, 1).width == 8, true);
        check("aplicar de novo nao muda nada", ObjModel.setAllCoords(out, 1, -8, -70, 16, 70) == out, true);
        check("sem a flag no ANO: mesmo array", ObjModel.setAllCoords(mp, 20, 1, 2, 3, 4) == mp, true);
        ObjModel.Obj merged = ObjModel.find(ObjModel.objects(out), 1, 0, 0);
        check("frames 1 e 2 viram um objeto so (valores iguais)", merged != null && merged.f0 == 0 && merged.f1 == 1, true);
        System.out.println("HurtboxAllTest fails=" + fails);
    }
}
