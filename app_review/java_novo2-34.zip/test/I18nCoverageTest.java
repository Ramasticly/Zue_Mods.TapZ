package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cobertura do catalogo de idiomas: toda literal de texto das telas (nos .java do app) precisa estar no catalogo (PT) ou na lista de ignoradas
 * (formatos, chaves, depuracao). Texto novo na interface sem traducao faz este teste falhar. Pula se nao achar as fontes.
 * Alem disso confere o catalogo: placeholders iguais nas 3 colunas, nada vazio, EN/ES diferentes do PT quando ha letras.
 */
public class I18nCoverageTest {
    static final Pattern LIT = Pattern.compile("\"((?:[^\"\\\\\\n]|\\\\.)*)\"");
    static final Pattern FMT = Pattern.compile("%(?:\\d+\\$)?[-+0# ]*\\d*(?:\\.\\d+)?[sdfx]");
    static final Pattern PLACE = Pattern.compile("\\{(\\d)\\}");

    static String unesc(String s) {
        Matcher m = Pattern.compile("\\\\u([0-9a-fA-F]{4})").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(m.group(1), 16))));
        m.appendTail(sb);
        return sb.toString().replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\").replace("\\'", "'").replace("\\t", "\t");
    }

    static String conv(String s) {
        Matcher m = FMT.matcher(s);
        StringBuffer sb = new StringBuffer();
        int n = 0;
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement("{" + (n++) + "}"));
        m.appendTail(sb);
        return sb.toString().replace("%%", "%");
    }

    static int placeholders(String s) {
        Matcher m = PLACE.matcher(s);
        int n = 0;
        while (m.find()) n++;
        return n;
    }

    static File sourceDir() {
        String[] c = {".", "..", "../app", "../..", "src"};
        for (String p : c) if (new File(p, "I18n.java").isFile()) return new File(p);
        return null;
    }

    static int letters(String s) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isLetter(s.charAt(i))) n++;
        return n;
    }

    public static void main(String[] args) throws Exception {
        // ---- catalogo coerente
        List<String[]> cat = I18n.entries();
        Set<String> keys = new HashSet<String>();
        boolean shape = true, ph = true, differs = true, dup = true;
        StringBuilder bad = new StringBuilder();
        for (String[] e : cat) {
            shape &= e.length == 3 && e[0].length() > 0 && e[1].length() > 0 && e[2].length() > 0;
            if (e.length < 3) continue;
            boolean same = placeholders(e[0]) == placeholders(e[1]) && placeholders(e[0]) == placeholders(e[2]);
            if (!same) { ph = false; bad.append(e[0]).append(" | "); }
            if (!keys.add(e[0])) { dup = false; bad.append("DUP ").append(e[0]).append(" | "); }
            if (e[1].equals(e[0]) && e[2].equals(e[0]) && letters(e[0]) > 0) differs = false;
        }
        check("catalogo: " + cat.size() + " entradas, nenhuma vazia", shape, true);
        check("catalogo: placeholders {n} iguais nas 3 colunas " + bad, ph, true);
        check("catalogo: sem chave repetida", dup, true);
        check("catalogo: nenhuma entrada igual nos 3 idiomas (seria inutil)", differs, true);

        File dir = sourceDir();
        if (dir == null) {
            check("cobertura: fontes nao encontradas, pulada", true, true);
            System.out.println("I18nCoverageTest fails=" + BattleTest.fails);
            return;
        }
        Set<String> ignored = new HashSet<String>(java.util.Arrays.asList(I18nIgnored.LITERALS));
        TreeSet<String> missing = new TreeSet<String>();
        int files = 0, lits = 0;
        File[] fs = dir.listFiles();
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            String n = f.getName();
            if (!n.endsWith(".java") || n.startsWith("I18n") || n.equals("HelpText.java") || n.equals("AiHelp.java") || n.equals("AiHelpDoc.java") || n.equals("AnoNotes.java")) continue;   // AnoNotes e editado a mao: texto novo la nao exige traducao
            files++;
            for (String line : Files.readAllLines(f.toPath(), Charset.forName("UTF-8"))) {
                String st = line.trim();
                if (st.startsWith("//") || st.startsWith("*") || st.startsWith("/*")) continue;
                Matcher m = LIT.matcher(line);
                while (m.find()) {
                    String s = unesc(m.group(1));
                    if (letters(s) < 3) continue;
                    lits++;
                    if (!keys.contains(conv(s)) && !ignored.contains(s)) missing.add(n + ": " + s);
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (String s : missing) { if (shown++ < 500) sb.append("\n   ").append(s.replace("\n", "\\n")); }
        check("cobertura: " + lits + " literais em " + files + " arquivos; sem traducao nem ignorar: " + missing.size() + sb, missing.isEmpty(), true);

        System.out.println("I18nCoverageTest fails=" + BattleTest.fails);
    }
}
