package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.List;

/** Idioma da interface: troca PT/EN/ES, texto exato, modelos {0}, fragmentos por palavra, termos neutros e PT intacto. */
public class I18nTest {
    static String[] e(String pt, String en, String es) { return new String[]{pt, en, es}; }

    public static void main(String[] args) throws Exception {
        List<String[]> cat = new ArrayList<String[]>();
        cat.add(e("AJUDA", "HELP", "AYUDA"));
        cat.add(e("Salvar", "Save", "Guardar"));
        cat.add(e("Salvar golpe atual", "Save current move", "Guardar golpe actual"));
        cat.add(e("Salvando em {0}", "Saving to {0}", "Guardando en {0}"));
        cat.add(e("{0} de {1}", "{0} of {1}", "{0} de {1}"));
        cat.add(e("Reação {0}", "Reaction {0}", "Reacción {0}"));
        cat.add(e("forte", "strong", "fuerte"));
        cat.add(e("Golpe", "Move", "Golpe"));
        cat.add(e("Som", "Sound", "Sonido"));
        cat.add(e("ANO", "ANO", "ANO"));
        cat.add(e("transição", "transition", "transición"));
        cat.add(e("Duração: {0} ticks", "Duration: {0} ticks", "Duración: {0} ticks"));
        cat.add(e("Tocar", "Play", "Reproducir"));
        I18n.useEntries(cat);
        try {
            I18n.set(I18n.PT);
            check("PT: nada muda", I18n.tr("Salvando em char01") + "|" + I18n.tr("AJUDA"), "Salvando em char01|AJUDA");
            check("PT: codigo", I18n.code(), "PT");

            I18n.set(I18n.EN);
            check("EN: texto exato", I18n.tr("AJUDA"), "HELP");
            I18n.set(I18n.ES);
            check("ES: texto exato", I18n.tr("AJUDA"), "AYUDA");
            I18n.set(I18n.EN);
            check("espacos nas pontas ficam", "[" + I18n.tr(" AJUDA ") + "]", "[ HELP ]");
            check("modelo {0}", I18n.tr("Salvando em char01"), "Saving to char01");
            check("modelo com dois grupos", I18n.tr("3 de 12"), "3 of 12");
            check("modelo traduz o grupo com letras", I18n.tr("Reação forte"), "Reaction strong");
            check("modelo vence o fragmento (nome com varias palavras)", I18n.tr("Salvando em minha pasta"), "Saving to minha pasta");
            check("mais longo primeiro: 'Salvar golpe atual'", I18n.tr("Salvar golpe atual"), "Save current move");
            check("fragmentos em texto concatenado", I18n.tr("Golpe 3 (forte)"), "Move 3 (strong)");
            check("fragmento so por palavra inteira (Somente nao vira Sonidoente)", I18n.tr("Somente leitura"), "Somente leitura");
            check("fragmento de palavra inteira com pontuacao", I18n.tr("Som: 5"), "Sound: 5");
            check("termo neutro igual nos tres idiomas", I18n.tr("ANO 5"), "ANO 5");
            check("so numeros e simbolos ficam", I18n.tr("12/40  Δ 3,0") + "|" + I18n.tr(""), "12/40  Δ 3,0|");
            check("null seguro", I18n.tr(null), null);
            check("acento e caixa respeitados como no catalogo (transição)", I18n.tr("Bloqueada a transição agora"), "Bloqueada a transition agora");
            check("modelo com numero", I18n.tr("Duração: 12 ticks"), "Duration: 12 ticks");
            I18n.set(I18n.ES);
            check("ES: modelo e fragmento", I18n.tr("Salvando em char02") + "|" + I18n.tr("Golpe 3 (forte)"), "Guardando en char02|Golpe 3 (fuerte)");
            check("ES: transição", I18n.tr("a transição"), "a transición");

            // idempotencia basica: traduzir de novo o que ja saiu em EN/ES nao estraga
            I18n.set(I18n.EN);
            String once = I18n.tr("Golpe 3 (forte)");
            check("traduzir o resultado de novo nao muda", I18n.tr(once), once);

            // troca de idioma limpa o cache
            I18n.set(I18n.PT);
            check("volta ao PT", I18n.tr("Golpe 3 (forte)"), "Golpe 3 (forte)");
            I18n.set(I18n.EN);
            check("cache nao vaza entre idiomas", I18n.tr("AJUDA"), "HELP");
            I18n.set(I18n.ES);
            check("EN->ES refaz", I18n.tr("AJUDA"), "AYUDA");

            // ciclo
            I18n.set(I18n.PT);
            int a = I18n.next(), b = I18n.next(), c = I18n.next();
            check("ciclo PT>EN>ES>PT", a + "" + b + "" + c, "120");
            check("fromCode", I18n.fromCode("en") + ":" + I18n.fromCode("ES") + ":" + I18n.fromCode("xx"), "1:2:0");
            check("trTo nao muda o idioma atual", I18n.trTo("AJUDA", I18n.ES) + ":" + I18n.code(), "AYUDA:PT");
        } finally {
            I18n.set(I18n.PT);
            I18n.useEntries(null);
        }
        // o catalogo real carrega e e coerente
        List<String[]> real = I18n.entries();
        boolean shape = !real.isEmpty();
        for (String[] r : real) shape &= r.length == 3 && r[0].length() > 0 && r[1].length() > 0 && r[2].length() > 0;
        check("catalogo real: toda entrada tem PT/EN/ES nao vazios", shape, true);
        System.out.println("I18nTest fails=" + BattleTest.fails);
    }
}
