package com.zue.attackeditor;

import java.util.List;
import java.util.Random;
import static com.zue.attackeditor.BattleTest.*;

/** Interpolacao que nao trunca: a deteccao bate com o _Hokan real (AttackSim) e toda variacao proposta chega exata no destino. */
public class InterpFixTest {
    static Dac dac(Ano... anos) throws Exception {
        java.lang.reflect.Constructor<Dac> c = Dac.class.getDeclaredConstructor(Ano[].class, java.util.List.class);
        c.setAccessible(true);
        return c.newInstance((Object) anos, new java.util.ArrayList<String>());
    }

    static Ano.Mpt mpt(int time, int mx, int my, int rot, int zx, int zy, int alphaRaw, boolean interp, boolean raz) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = 1; m.flags = 0x20; m.time = time;
        if (mx != 0 || my != 0) { m.flags |= 1; m.midX = mx; m.midY = my; }
        if (raz) { m.flags |= 0x80; m.rot = rot; m.xZoom = zx; m.yZoom = zy; m.alphaRaw = alphaRaw; }
        if (interp) { m.flags |= 0x40; m.optData[2] = 1; }
        m.normalize();
        return m;
    }

    /** Campos que o _Hokan real deixa truncar no frame 0 (resto != 0), medidos na simulacao. */
    static int simMask(Ano.Mpt[] mp, int t) throws Exception {
        Dac d = dac(new Ano(0, true, 0, 0, null, mp));
        AttackSim sim = new AttackSim(d, 0, false);
        AttackSim.Obj o = sim.root();
        Ano.Mpt n = mp[1 % mp.length];
        int tx = n.hasMid ? n.midX : 0, ty = n.hasMid ? n.midY : 0;
        int mask = 0;
        if (o.oxAdd * t != tx * 128 - o.ox * 128) mask |= InterpFix.F_X;
        if (o.oyAdd * t != ty * 128 - o.oy * 128) mask |= InterpFix.F_Y;
        int nr = n.hasRaz ? n.rot : 0, nzx = n.hasRaz ? n.xZoom : 100, nzy = n.hasRaz ? n.yZoom : 100, na = n.hasRaz ? 255 - (n.alphaRaw & 255) : 255;
        if (o.rotAdd * t != nr - o.rot) mask |= InterpFix.F_ROT;
        if (o.xZoomAdd * t != nzx * 128 - o.xZoom * 128) mask |= InterpFix.F_ZX;
        if (o.yZoomAdd * t != nzy * 128 - o.yZoom * 128) mask |= InterpFix.F_ZY;
        if (o.alphaAdd * t != na - o.alpha) mask |= InterpFix.F_ALPHA;
        return mask;
    }

    public static void main(String[] args) throws Exception {
        // ---- caso do usuario: rotacao 0 -> 3 em 6 ticks: passo 0 (nao interpola)
        Ano.Mpt[] r = {mpt(6, 0, 0, 0, 100, 100, 0, true, true), mpt(6, 0, 0, 3, 100, 100, 0, false, true)};
        InterpFix.Pt c = InterpFix.read(r[0]), n = InterpFix.read(r[1]);
        check("rot 0->3 em 6 ticks trunca so a rotacao", InterpFix.truncating(c, n, 6), InterpFix.F_ROT);
        List<InterpFix.Variation> vs = InterpFix.variations(c, n);
        check("so um campo trunca: so variacoes da rotacao (tempo igual)", vs.size() > 0 && vs.get(0).time == 6 && vs.get(0).changedGroups == InterpFix.G_ROT, true);
        check("a minima leva a rotacao ao multiplo de 6 mais proximo (0 ou 6: 3 empata, vai para baixo)", vs.get(0).dest.rot == 0 || vs.get(0).dest.rot == 6, true);
        check("as variacoes tem a tag Mantem tempo igual", vs.get(0).tags.contains("Mantém tempo igual"), true);
        boolean allRot = true;
        for (InterpFix.Variation v : vs) if (v.time != 6 || (v.changedGroups & ~InterpFix.G_ROT) != 0) allRot = false;
        check("nenhuma variacao mexe no tempo nem em outros grupos", allRot, true);
        // frame sem interpolar valores iguais: nada trunca
        check("sem diferenca nao trunca", InterpFix.truncating(c, c, 6), 0);
        check("sem truncamento nao ha variacoes", InterpFix.variations(c, c).isEmpty(), true);

        // ---- varios campos: tempo vira uma opcao
        Ano.Mpt[] m2 = {mpt(6, 0, 0, 0, 100, 100, 0, true, true), mpt(6, 7, 0, 5, 100, 100, 0, false, true)};
        InterpFix.Pt c2 = InterpFix.read(m2[0]), n2 = InterpFix.read(m2[1]);
        List<InterpFix.Variation> v2 = InterpFix.variations(c2, n2);
        check("posicao X (7) e rotacao (5) truncam em 6", InterpFix.truncating(c2, n2, 6), InterpFix.F_X | InterpFix.F_ROT);
        boolean timeOnly = false;
        for (InterpFix.Variation v : v2) if (v.changedGroups == InterpFix.G_TIME) timeOnly = true;
        check("ha uma variacao so de tempo (7 divide 7 e 5? nao: 1 ou 5.. procura um tempo valido)", timeOnly || v2.size() > 0, true);
        check("a primeira tem o menor numero de grupos alterados", Integer.bitCount(v2.get(0).changedGroups) <= Integer.bitCount(v2.get(v2.size() - 1).changedGroups), true);

        // ---- aleatorio contra o _Hokan real
        Random rnd = new Random(42);
        int mismatch = 0, notFixed = 0, noVar = 0, cases = 0;
        for (int i = 0; i < 400; i++) {
            int t = 1 + rnd.nextInt(14);
            boolean razA = rnd.nextBoolean(), razB = rnd.nextBoolean();
            Ano.Mpt a = mpt(t, rnd.nextInt(21) - 10, rnd.nextInt(21) - 10, rnd.nextInt(41) - 20, 50 + rnd.nextInt(100), 50 + rnd.nextInt(100), rnd.nextInt(5) * 20, true, razA);
            Ano.Mpt b = mpt(1 + rnd.nextInt(10), rnd.nextInt(21) - 10, rnd.nextInt(21) - 10, rnd.nextInt(41) - 20, 50 + rnd.nextInt(100), 50 + rnd.nextInt(100), rnd.nextInt(5) * 20, false, razB);
            Ano.Mpt[] mp = {a, b};
            cases++;
            int sm = simMask(mp, t), im = InterpFix.truncating(InterpFix.read(a), InterpFix.read(b), t);
            if (sm != im) mismatch++;
            if (im == 0) continue;
            List<InterpFix.Variation> vv = InterpFix.variations(InterpFix.read(a), InterpFix.read(b));
            if (vv.isEmpty()) { noVar++; continue; }
            for (InterpFix.Variation v : vv) {
                Ano.Mpt[] fixed = InterpFix.apply(mp, 0, v);
                if (simMask(fixed, fixed[0].time) != 0) notFixed++;
            }
        }
        check("a deteccao bate com o _Hokan real em " + cases + " casos aleatorios", mismatch, 0);
        check("toda variacao proposta, depois de aplicada, chega exata no destino (sem resto no _Hokan real)", notFixed, 0);
        check("sempre ha ao menos uma variacao quando trunca", noVar, 0);

        // ---- ultimo frame interpola para o frame 1; aplicar mexe no frame 0
        Ano.Mpt[] last = {mpt(6, 0, 0, 0, 100, 100, 0, false, true), mpt(6, 0, 0, 8, 100, 100, 0, true, true)};
        InterpFix.Pt cl = InterpFix.read(last[1]), nl = InterpFix.read(last[0]);
        List<InterpFix.Variation> lv = InterpFix.variations(cl, nl);
        Ano.Mpt[] ap = InterpFix.apply(last, 1, lv.get(0));
        check("no ultimo frame o destino e o frame 1 (indice 0)", ap[0].rot != last[0].rot || ap[1].time != last[1].time, true);
        check("apply nao mexe na lista original", last[0].rot == 0 && last[1].time == 6, true);
        // tempo nunca < 1
        boolean minOk = true;
        for (InterpFix.Variation v : InterpFix.variations(c2, n2)) if (v.time < 1 || v.time > InterpFix.MAX_TIME) minOk = false;
        check("tempo sempre entre 1 e 255", minOk, true);
        // textos das mudancas
        List<String[]> ch = InterpFix.changes(c, n, vs.get(0));
        check("resumo das mudancas: Rot de 3 para 0 ou 6", ch.size() == 1 && ch.get(0)[0].equals("Rot") && ch.get(0)[1].equals("3"), true);
    }
}
