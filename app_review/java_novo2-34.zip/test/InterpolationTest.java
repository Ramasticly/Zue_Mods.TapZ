package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Interpolacao (OPT d2): o frame COM a flag vai ate o proximo; o de antes nao interpola para ele; no ultimo frame o "proximo" e o frame 0. */
public class InterpolationTest {
    static int rotAfter(Dac d, int ticks) {
        AttackSim s = new AttackSim(d, 0, false);
        for (int i = 0; i < ticks; i++) s.step();
        return s.root().rot;
    }

    public static void main(String[] args) throws Exception {
        // frame 0 (sem rotacao) -> frame 1 (rotacao 450, com $RAZ); a flag no frame 0 faz o frame 0 caminhar para a rotacao do frame 1
        Dac withFlag = dac(new A().mpt(new M().time(10).interp()).mpt(new M().time(10).raz(450, 0, 100, 100)));
        int r5 = rotAfter(withFlag, 5);
        check("frame com a flag interpola para o proximo (rotacao sobe durante o frame 0)", r5 > 0 && r5 < 450, true);
        Dac noFlag = dac(new A().mpt(new M().time(10)).mpt(new M().time(10).raz(450, 0, 100, 100)));
        check("sem a flag o frame 0 nao se mexe", rotAfter(noFlag, 5), 0);
        // a flag no frame DE DEPOIS nao interpola o de antes para ele
        Dac flagAfter = dac(new A().mpt(new M().time(10)).mpt(new M().time(10).raz(450, 0, 100, 100).interp()).mpt(new M().time(10)));
        check("o frame de antes nao interpola para o que tem a flag", rotAfter(flagAfter, 5), 0);
        // ultimo frame com flag: o proximo e o frame 0 (volta ao inicio), mesmo sem LOOP
        Dac last = dac(new A().mpt(new M().time(10).raz(300, 0, 100, 100)).mpt(new M().time(10).interp()));
        int rl = rotAfter(last, 15);
        check("ultimo frame com flag interpola em direcao ao frame 1 (rotacao 300 do frame 0)", rl > 0 && rl < 300, true);
        // frame sem tempo nao interpola
        Dac zero = dac(new A().mpt(new M().interp()).mpt(new M().time(10).raz(450, 0, 100, 100)));
        check("frame sem tempo nao interpola", rotAfter(zero, 3), 0);
        check("proximo frame do ultimo = 1 (base 1)", ObjModel.interpTarget(5, 4) + ":" + ObjModel.interpTarget(5, 1), "1:3");
        System.out.println("InterpolationTest fails=" + fails);
    }
}
