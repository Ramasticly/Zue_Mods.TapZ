package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** CAMADA da ANO: maior = mais em cima (o $PRIO do jogo e o contrario). */
public class LayerOpsTest {
    static Ano ano(int flags, int prio) { return new Ano(7, true, flags, prio, new Ano.Link[0], new Ano.Mpt[] {new Ano.Mpt()}); }

    public static void main(String[] args) throws Exception {
        check("ANO sem $PRIO: camada 0", LayerOps.layerOf(ano(0, 0)), 0);
        check("$PRIO 5 (mais atras no jogo) = camada -5", LayerOps.layerOf(ano(4, 5)), -5);
        Ano up = LayerOps.setLayer(ano(0, 0), 3);
        check("camada 3 grava $PRIO -3 com o bit 4", up.priority + ":" + (up.flags & 4), "-3:4");
        check("camada de volta", LayerOps.layerOf(up), 3);
        Ano down = LayerOps.setLayer(up, -2);
        check("camada -2 grava $PRIO 2", down.priority + ":" + (down.flags & 4), "2:4");
        Ano zero = LayerOps.setLayer(down, 0);
        check("camada 0 limpa o $PRIO e o bit 4", zero.priority + ":" + (zero.flags & 4), "0:0");
        check("mantem indice, links e frames", zero.index + ":" + (zero.mpts == down.mpts) + ":" + (zero.links == down.links), "7:true:true");
        check("preserva os outros bits de flags", LayerOps.setLayer(ano(3, 0), 1).flags, 3 | 4);
        check("limite de cima: $PRIO -128", LayerOps.setLayer(ano(0, 0), 999).priority, -128);
        check("limite de baixo: $PRIO 127", LayerOps.setLayer(ano(0, 0), -999).priority, 127);
        check("clamp", LayerOps.clamp(500) + ":" + LayerOps.clamp(-500), "128:-127");
        System.out.println("LayerOpsTest fails=" + fails);
    }
}
