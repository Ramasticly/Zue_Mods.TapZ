package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.HashSet;
import java.util.Set;

/**
 * Hierarquia de links do jogo (_SetAct / _ActReq): so a RAIZ cria links; o link nao cria os dele (a tabela de links do link e pulada);
 * hits/OPT de um link nao valem. Animacoes disparadas por flag (efeito de hit, projetil...) sao raizes: mostram os proprios links.
 */
public class LinkHierarchyTest {
    static A[] anos(int n) {
        A[] a = new A[n];
        for (int i = 0; i < n; i++) a[i] = new A().mpt(new M().time(5).img(1));
        return a;
    }

    /** Poe links no ANO {@code idx} do DAC (os frames ficam como estao). */
    static void link(Dac d, int idx, int... targets) {
        Ano old = d.getAno(idx);
        Ano.Link[] ls = new Ano.Link[targets.length];
        for (int i = 0; i < targets.length; i++) ls[i] = new Ano.Link(0, 0, 0x4000 | targets[i]);
        d.setAno(idx, new Ano(idx, true, old.flags | 2, old.priority, ls, old.mpts));
    }

    static Set<Integer> shown(BattleSim s, int owner) {
        Set<Integer> out = new HashSet<Integer>();
        for (BattleSim.Layer l : s.layers()) if (l.owner == owner && l.only != null) out.add(Integer.valueOf(l.only.ano.index));
        return out;
    }

    static BattleSim battle(Dac atk, CharData ch, Dac fx, int dist) throws Exception {
        A[] def = new A[25];
        for (int i = 0; i < 25; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}) });
        BattleSim s = new BattleSim(atk, ch, ch.moves[0], false, dac(def), fx, g, dist, 0, 0);
        s.reset();
        return s;
    }

    public static void main(String[] args) throws Exception {
        // ---- link de link nunca nasce
        Dac d = dac(anos(20));
        link(d, 10, 11);
        link(d, 11, 12);
        AttackSim sim = new AttackSim(d, 10, false);
        boolean c12 = false;
        for (AttackSim.Obj o : sim.children()) if (o != null && o.ano.index == 12) c12 = true;
        check("ANO 10: so o link 11 nasce", sim.children().length + ":" + sim.children()[0].ano.index + ":" + c12, "1:11:false");
        AttackSim asLink = new AttackSim(d, 11, false);
        check("o mesmo ANO 11 como raiz mostra o proprio link 12", asLink.children().length + ":" + asLink.children()[0].ano.index, "1:12");
        link(d, 10, 11, 11, 11);
        check("varios links do mesmo ANO nascem (1 nivel)", new AttackSim(d, 10, false).children().length, 3);

        // ---- hit flag 0 / 39 dentro de um link nao vale; na raiz vale
        A[] a = anos(60);
        a[40] = new A().mpt(new M().time(30));
        a[31] = new A().mpt(new M().time(30).hit(0, 10, -30, 4, 4));
        a[30] = new A().mpt(new M().time(60).speedX(2 << 16));
        CharData ch = chr(move(new int[]{2, 40}, new int[]{4, 30}), new byte[][] {});
        Dac dl = dac(a);
        link(dl, 40, 31);
        BattleSim bl = battle(dl, ch, dac(anos(2)), 120);
        int most = 0;
        for (int i = 0; i < 20; i++) { bl.step(); most = Math.max(most, bl.projectileCount()); }
        check("flag 0 num link nao cria projetil", most, 0);
        a[40] = new A().mpt(new M().time(30).hit(0, 10, -30, 4, 4));
        BattleSim br = battle(dac(a), ch, dac(anos(2)), 120);
        most = 0;
        for (int i = 0; i < 20; i++) { br.step(); most = Math.max(most, br.projectileCount()); }
        check("flag 0 na raiz cria projetil (controle)", most >= 1, true);

        A[] t = anos(60);
        t[40] = new A().mpt(new M().time(30));
        t[31] = new A().mpt(new M().time(30).hit(39, 0, 0, 16, 16));
        Dac dt = dac(t);
        link(dt, 40, 31);
        BattleSim tl = battle(dt, ch, dac(anos(2)), 120);
        for (int i = 0; i < 12; i++) tl.step();
        int xLink = (int) tl.attackerX();
        t[40] = new A().mpt(new M().time(30).hit(39, 0, 0, 16, 16));
        BattleSim tr = battle(dac(t), ch, dac(anos(2)), 120);
        for (int i = 0; i < 12; i++) tr.step();
        check("flag 39 num link nao teleporta; na raiz teleporta", xLink + ":" + ((int) tr.attackerX() != 0), "0:true");

        // ---- projetil e efeito de hit sao raizes: mostram os proprios links, e so 1 nivel
        A[] p = anos(60);
        p[40] = new A().mpt(new M().time(40).hit(0, 10, -30, 4, 4));
        p[30] = new A().mpt(new M().time(60).speedX(1 << 16));
        Dac dp = dac(p);
        link(dp, 30, 32);
        link(dp, 32, 33);
        BattleSim bp = battle(dp, ch, dac(anos(2)), 400);
        for (int i = 0; i < 6; i++) bp.step();
        Set<Integer> ps = shown(bp, BattleSim.OWNER_PROJECTILE);
        check("projetil mostra o link 32 e nao o link do link (33)", ps.contains(Integer.valueOf(30)) + ":" + ps.contains(Integer.valueOf(32)) + ":" + ps.contains(Integer.valueOf(33)), "true:true:false");

        A[] h = anos(60);
        h[40] = new A().mpt(new M().time(3).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(30));
        CharData hc = chr(move(new int[]{2, 40}), new byte[][] {});
        Dac fx = dac(anos(5));
        link(fx, 0, 1);
        link(fx, 1, 2);
        BattleSim bh = battle(dac(h), hc, fx, 30);
        Set<Integer> fs = new HashSet<Integer>();
        for (int i = 0; i < 12; i++) { bh.step(); fs.addAll(shown(bh, BattleSim.OWNER_EFFECT)); }
        check("efeito de hit mostra o link 1 e nao o link do link (2)", fs.contains(Integer.valueOf(0)) + ":" + fs.contains(Integer.valueOf(1)) + ":" + fs.contains(Integer.valueOf(2)), "true:true:false");

        System.out.println("LinkHierarchyTest fails=" + BattleTest.fails);
    }
}
