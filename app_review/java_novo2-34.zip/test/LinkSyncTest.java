package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Efeitos presos ao personagem (auras) e links acompanham o pai no MESMO tick, mesmo quando a camera, a borda ou o empurrao mexem na raiz. */
public class LinkSyncTest {
    static AttackSim auraOf(BattleSim s, int owner) {
        for (BattleSim.Layer l : s.layers()) if (l.owner == owner) return l.sim;
        return null;
    }

    public static void main(String[] args) throws Exception {
        BattleSim.defend = false;
        A[] fx = new A[5];
        for (int i = 0; i < 5; i++) fx[i] = new A().mpt(new M().time(4));

        // ---- atacante que anda para cima do oponente (separacao de corpos + camera) com uma aura 71 (ANO 201 dele) a (10, -20)
        A[] atk = new A[210];
        for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(1).img(1));
        atk[40] = new A().mpt(new M().time(120).img(1).speedX(6 * 65536).hit(71, 10, -20, 0, 0));
        atk[201] = new A().mpt(new M().time(120).img(1));
        A[] def = new A[210];
        for (int i = 0; i < def.length; i++) def[i] = new A().mpt(new M().time(30).img(1));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        CharData ch = chr(move(new int[]{0, 0}, new int[]{2, 40}), new byte[][] {});
        BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(fx), g, 60, 0, 0);
        int bad = 0, seen = 0;
        for (int t = 0; t < 70; t++) {
            s.step();
            AttackSim a = auraOf(s, BattleSim.OWNER_AURA_CHAR);
            AttackSim.Obj r = s.attacker().root();
            if (a == null || a.root() == null || r == null) continue;
            seen++;
            if (a.root().x - r.x != 10 << 16 || a.root().y - r.y != -20 << 16) bad++;
        }
        check("a aura do atacante apareceu", seen > 40, true);
        check("a aura do atacante fica a (10, -20) da raiz em TODO tick (camera / separacao de corpos)", bad, 0);

        // ---- virado para a esquerda: o offset x espelha
        BattleSim f = new BattleSim(dac(atk), ch, ch.moves[0], true, dac(def), dac(fx), g, 60, 0, 0);
        int badF = 0;
        for (int t = 0; t < 40; t++) {
            f.step();
            AttackSim a = auraOf(f, BattleSim.OWNER_AURA_CHAR);
            AttackSim.Obj r = f.attacker().root();
            if (a == null || a.root() == null || r == null) continue;
            if (a.root().x - r.x != -(10 << 16)) badF++;
        }
        check("virado: offset x espelhado em todo tick", badF, 0);

        // ---- oponente com aura 71 apanhando (knockback): a aura anda junto com o corpo dele
        A[] atk2 = new A[41];
        for (int i = 0; i < atk2.length; i++) atk2[i] = new A().mpt(new M().time(1).img(1));
        atk2[40] = new A().mpt(new M().time(2).img(1)).mpt(new M().time(3).img(1).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(60).img(1));
        A[] def2 = new A[210];
        for (int i = 0; i < def2.length; i++) def2[i] = new A().mpt(new M().time(40).img(1).hit(1, -10, -60, 20, 60).hit(71, 4, -30, 0, 0));
        def2[201] = new A().mpt(new M().time(120).img(1));
        GameData g2 = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 8, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0}) });
        CharData ch2 = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim o = new BattleSim(dac(atk2), ch2, ch2.moves[0], false, dac(def2), dac(fx), g2, 30, 0, 0);
        int badO = 0, seenO = 0, moved = 0, x0 = o.opponentX();
        for (int t = 0; t < 40; t++) {
            o.step();
            AttackSim a = auraOf(o, BattleSim.OWNER_AURA_OPPCHAR);
            AttackSim.Obj r = o.opponent().root();
            if (o.opponentX() != x0) moved++;
            if (a == null || a.root() == null || r == null) continue;
            seenO++;
            int ox = (r.objFlags & 16) != 0 ? -(4 << 16) : (4 << 16);
            if (a.root().x - r.x != ox || a.root().y - r.y != -30 << 16) badO++;
        }
        System.out.println("DBG seenO=" + seenO + " moved=" + moved + " x0=" + x0 + " x=" + o.opponentX());
        check("a aura do oponente apareceu e o oponente foi empurrado", seenO > 10 && moved > 5, true);
        check("a aura do oponente acompanha o corpo dele em TODO tick (knockback)", badO, 0);

        // ---- prévia: tocar o chao leva os links junto
        A[] lk = new A[3];
        for (int i = 0; i < lk.length; i++) lk[i] = new A().mpt(new M().time(30).img(1));
        Dac d = dac(lk);
        AttackSim sim = new AttackSim(d, 0, false, 0, 0);
        AttackSim.Obj root = sim.root();
        root.y = 5 << 16;
        AnimPreview.groundSim(sim);
        check("groundSim limita a raiz ao chao", root.y, 0);
        System.out.println("LinkSyncTest fails=" + fails);
    }
}
