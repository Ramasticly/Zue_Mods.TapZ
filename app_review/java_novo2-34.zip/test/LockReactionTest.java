package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** TRANSICAO travada: a reacao em exibicao nao salta (COMP ao pousar, parede, 255 ticks, fim da tabela voando); destravada, salta. */
public class LockReactionTest {
    static boolean has(ReactionTrace t, int reason) {
        for (ReactionTrace.Seg s : t.segments) if (s.reason == reason) return true;
        return false;
    }

    /** Como ReactionTraceTest.sim, mas o jogo tem as reacoes 2, 3, 12 e 13 (destinos dos saltos). */
    static BattleSim sim(byte[][] charReactions, int oppHeight) throws Exception {
        A[] atk = new A[10];
        for (int i = 0; i < 10; i++) atk[i] = new A().mpt(new M().time(5));
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(3)).mpt(new M().time(3));
        CharData ch = chr(move(new int[]{0, 4}, new int[]{2, 3}), charReactions);
        byte[] r = react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0});
        GameData g = gd(new byte[][] { null, null, r, r, null, null, null, null, null, null, null, null, r, r });
        int old = BattleSim.oppHeightPx;
        BattleSim.oppHeightPx = oppHeight;
        try {
            BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, 200, 0, 0);
            s.reset();
            return s;
        } finally { BattleSim.oppHeightPx = old; }
    }

    static ReactionTrace trace(byte[][] rs, int height, int opt, boolean lock, int mapPos) throws Exception {
        int oldPos = BattleSim.mapPos;
        BattleSim.mapPos = mapPos;
        try {
            BattleSim s = sim(rs, height);
            BattleSim.lockReaction = lock;
            return ReactionTrace.record(s, opt, 600);
        } finally { BattleSim.lockReaction = false; BattleSim.mapPos = oldPos; }
    }

    public static void main(String[] args) throws Exception {
        byte[][] landing = new byte[1][];
        landing[0] = react(new int[]{255, 255, 5, 0, 0, 0, 0, 0, 40, 0, 0, 3, 0, 0});     // cai e, ao pousar, COMP 3 = reacao 3 do jogo
        ReactionTrace free = trace(landing, 60, 30, false, 0), lock = trace(landing, 60, 30, true, 0);
        check("sem trava: pousa e salta para a reacao 3 do jogo (COMP)", has(free, BattleSim.R_LAND), true);
        check("com a trava: o COMP nao age ao pousar", has(lock, BattleSim.R_LAND), false);
        boolean only = true;
        for (ReactionTrace.Seg s : lock.segments) only &= s.charSrc && s.type == 0;
        check("com a trava: so a tabela editada toca (uma reacao so)", only && lock.occurrences().size() == 1, true);
        check("com a trava a reacao termina (nao fica presa)", lock.ended, true);

        byte[][] open = new byte[3][];
        open[0] = react(new int[]{255, 255, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});          // 255 no ar sem cair: passa de 255 ticks
        open[2] = react(new int[]{4, 4, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});              // a reacao 2 (do personagem) para onde o jogo salta
        check("sem trava: passar de 255 ticks salta para a reacao 2 (R_OPEN)", has(trace(open, 60, 30, false, 0), BattleSim.R_OPEN), true);
        ReactionTrace o2 = trace(open, 60, 30, true, 0);
        check("com a trava: 255 ticks acabam a reacao (sem salto)", !has(o2, BattleSim.R_OPEN) && o2.ticks.size() <= 256 && o2.ended, true);

        byte[][] endAir = new byte[1][];
        endAir[0] = react(new int[]{6, 6, 3, 0, 0, 0, 0, 0, -10, 0, 0, 0, 0, 0});          // sobe 1 px/tick; voando: no fim da tabela cai na reacao 13
        check("sem trava: fim da tabela voando vai para a reacao 13 (R_END_AIR)", has(trace(endAir, 60, 30, false, 0), BattleSim.R_END_AIR), true);
        ReactionTrace e2 = trace(endAir, 60, 30, true, 0);
        check("com a trava: o fim da tabela termina a reacao", !has(e2, BattleSim.R_END_AIR) && e2.ticks.size() == 6 && e2.ended, true);

        // parede: oponente na borda direita (POS DIR) empurrado para a direita com WALL 2 e COMP 3
        byte[][] wall = new byte[1][];
        wall[0] = react(new int[]{60, 60, 3, -60, 0, 0, 0, -60, 0, 0, 0, 3, 2, 0});
        ReactionTrace wf = trace(wall, 0, 30, false, 3), wl = trace(wall, 0, 30, true, 3);
        check("sem trava: bate na parede e salta para o COMP", has(wf, BattleSim.R_WALL), true);
        check("com a trava: a parede nao age", has(wl, BattleSim.R_WALL) || wl.occurrences().size() != 1, false);
        System.out.println("LockReactionTest fails=" + fails);
    }
}
