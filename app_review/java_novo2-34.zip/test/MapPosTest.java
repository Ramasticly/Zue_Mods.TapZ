package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** POS ESQ / MEIO / DIR: o par de personagens vai para a borda esquerda, o meio ou a borda direita do mapa; so o x muda. */
public class MapPosTest {
    static BattleSim make(int mapPos, int oppHeight) throws Exception {
        int oldPos = BattleSim.mapPos, oldH = BattleSim.oppHeightPx;
        BattleSim.mapPos = mapPos;
        BattleSim.oppHeightPx = oppHeight;
        try {
            return ReactionTraceTest.sim(new byte[][]{ react(new int[]{20, 20, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) }, oppHeight);
        } finally { BattleSim.mapPos = oldPos; BattleSim.oppHeightPx = oldH; }
    }

    static BattleSim made(int mapPos, int oppHeight) throws Exception {
        int oldPos = BattleSim.mapPos, oldH = BattleSim.oppHeightPx;
        BattleSim.mapPos = mapPos;
        BattleSim.oppHeightPx = oppHeight;
        try {
            BattleSim s = make(mapPos, oppHeight);
            s.reset();
            return s;
        } finally { BattleSim.mapPos = oldPos; BattleSim.oppHeightPx = oldH; }
    }

    public static void main(String[] args) throws Exception {
        BattleSim p0 = made(0, 40), pl = made(1, 40), pm = made(2, 40), pr = made(3, 40);
        int d0 = p0.opponentX() - p0.attackerX();
        check("a distancia entre os dois nao muda (ESQ / MEIO / DIR)", (pl.opponentX() - pl.attackerX()) + ":" + (pm.opponentX() - pm.attackerX()) + ":" + (pr.opponentX() - pr.attackerX()), d0 + ":" + d0 + ":" + d0);
        check("a altura do oponente nao muda", pl.opponentY() + ":" + pm.opponentY() + ":" + pr.opponentY(), p0.opponentY() + ":" + p0.opponentY() + ":" + p0.opponentY());
        float ml = pl.mapLeft() / 65536f, mr = pr.mapRight() / 65536f;
        float lx = Math.min(pl.attackerX(), pl.opponentX()), rx = Math.max(pr.attackerX(), pr.opponentX());
        check("ESQ: o personagem mais a esquerda fica colado na borda esquerda do mapa (a menos do corpo)", lx - ml >= 0 && lx - ml < 120, true);
        check("DIR: o personagem mais a direita fica colado na borda direita do mapa", mr - rx >= 0 && mr - rx < 120, true);
        float mid = (pm.attackerX() + pm.opponentX()) / 2f, cx = (pm.mapLeft() + pm.mapRight()) / 2f / 65536f;
        check("MEIO: o par fica no centro do mapa", Math.abs(mid - cx) < 3f, true);
        check("padrao (0) nao encosta em nenhuma borda", Math.min(p0.attackerX(), p0.opponentX()) - p0.mapLeft() / 65536f > 120 && p0.mapRight() / 65536f - Math.max(p0.attackerX(), p0.opponentX()) > 120, true);
        check("ESQ e DIR deslocam em sentidos opostos em relacao ao padrao", pl.attackerX() < p0.attackerX() && pr.attackerX() > p0.attackerX(), true);
        System.out.println("MapPosTest fails=" + fails);
    }
}
