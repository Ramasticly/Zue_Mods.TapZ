package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Celulas de velocidade da timeline principal: uma por Frame (sem unir os que mantem), speed e accel do mesmo Frame em linhas separadas. */
public class MoveCellsTest {
    static MoveCells.Result build(Ano.Mpt[] m, int axis) {
        int[] st = FrameOps.starts(m), sp = new int[m.length];
        for (int i = 0; i < m.length; i++) sp[i] = FrameOps.span(m[i]);
        return MoveCells.build(m, axis, st, sp);
    }

    public static void main(String[] args) throws Exception {
        // frame 0: speed x 10; frames 1 e 2 mantem; frame 3: speed x 20 + accel x 2; frame 4 mantem; frame 5 sem nada
        Ano.Mpt[] m = {FrameToolsTest.speed(FrameToolsTest.f(4), 10, 0, 0, 0), FrameToolsTest.keep(FrameToolsTest.f(3)), FrameToolsTest.keep(FrameToolsTest.f(3)),
                FrameToolsTest.speed(FrameToolsTest.f(2), 20, 0, 2, 0), FrameToolsTest.keep(FrameToolsTest.f(5)), FrameToolsTest.f(5)};
        MoveCells.Result x = build(m, 0);
        check("x: uma celula por Frame que tem ou herda velocidade (0,1,2,3,4) + a accel do Frame 3", x.cells.size(), 6);
        check("Frame 0: velocidade propria, nao herdada", x.find(0, MoveCells.SPEED).inherited + ":" + x.find(0, MoveCells.SPEED).text, "false:x 10");
        check("Frames 1 e 2 mantem: celulas separadas com '=' (nao uma so unida)", x.find(1, MoveCells.SPEED).inherited + ":" + x.find(2, MoveCells.SPEED).inherited + ":" + x.find(1, MoveCells.SPEED).text + ":" + x.find(2, MoveCells.SPEED).text, "true:true:x =10:x =10");
        check("cada celula cobre so o proprio Frame (ticks)", x.find(1, MoveCells.SPEED).start + "-" + x.find(1, MoveCells.SPEED).end + ":" + x.find(2, MoveCells.SPEED).start + "-" + x.find(2, MoveCells.SPEED).end, "4-7:7-10");
        check("Frame 3: speed propria no lugar da herdada, e a accel", x.find(3, MoveCells.SPEED).text + ":" + x.find(3, MoveCells.ACCEL).text, "x 20:ax 2");
        check("Frame 3 tem speed + accel no mesmo Frame: 2 linhas (speed 0, accel 1)", x.lines + ":" + x.find(3, MoveCells.SPEED).line + ":" + x.find(3, MoveCells.ACCEL).line, "2:0:1");
        check("Frame 4 mantem a velocidade do Frame 3 (20 mais a accel)", x.find(4, MoveCells.SPEED) != null && x.find(4, MoveCells.SPEED).inherited, true);
        check("Frame 5 sem movimento: nenhuma celula", x.find(5, MoveCells.SPEED) == null && x.find(5, MoveCells.ACCEL) == null, true);
        check("celula achada pela linha", x.at(3, 1).kind + ":" + (x.at(0, 1) == null), MoveCells.ACCEL + ":true");

        // y: so o Frame que mantem e nao tem velocidade y nao ganha celula
        MoveCells.Result y = build(m, 1);
        check("y: sem velocidade y nenhuma celula", y.cells.size(), 0);

        // speed e accel em Frames diferentes dividem a linha
        Ano.Mpt[] d = {FrameToolsTest.f(3), FrameToolsTest.speed(FrameToolsTest.f(3), 0, 0, 0, 0)};
        Ano.Mpt a1 = FrameTools.setAccel(FrameToolsTest.f(3), 0, 1.5), s2 = FrameTools.setSpeed(FrameToolsTest.f(3), 0, 4, true);
        MoveCells.Result dv = build(new Ano.Mpt[]{a1, s2}, 0);
        check("accel no Frame 0 e speed no Frame 1: dividem a linha 0", dv.lines + ":" + dv.find(0, MoveCells.ACCEL).line + ":" + dv.find(1, MoveCells.SPEED).line, "1:0:0");
        System.out.println("MoveCellsTest fails=" + fails);
    }
}
