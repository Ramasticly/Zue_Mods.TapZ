package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Celulas de velocidade da timeline principal: uma por Frame (sem unir os que mantem), speed e accel do mesmo Frame em linhas separadas. */
public class MoveCellsTest {
    static MoveCells.Result build(Ano.Mpt[] m, int axis) {
        int[] st = FrameOps.starts(m), sp = new int[m.length];
        for (int i = 0; i < m.length; i++) sp[i] = FrameOps.span(m[i]);
        return MoveCells.build(m, axis, st, sp);
    }

    public static void main(String[] args) throws Exception {
        // frame 0: speed x 10; frames 1 e 2 mantem; frame 3: speed x 20 + accel x 2; frame 4 mantem; frame 5 sem nada
        Ano.Mpt[] m = {FrameToolsTest.speed(FrameToolsTest.f(4), 10, 0, 0, 0), FrameToolsTest.keep(FrameToolsTest.f(3)), FrameToolsTest.keep(FrameToolsTest.f(3)),
                FrameToolsTest.speed(FrameToolsTest.f(2), 20, 0, 2, 0), FrameToolsTest.keep(FrameToolsTest.f(5)), FrameToolsTest.f(5)};
        MoveCells.Result x = build(m, 0);
        check("x: so Frames com speed/accel PROPRIA geram celula (0 e 3) + a accel do 3; quem so mantem a velocidade nao e faixa", x.cells.size(), 3);
        check("Frame 0: velocidade propria", x.find(0, MoveCells.SPEED).text, "x 10");
        check("Frames 1, 2 e 4 (so mantem): nenhuma celula", x.find(1, MoveCells.SPEED) == null && x.find(2, MoveCells.SPEED) == null && x.find(4, MoveCells.SPEED) == null, true);
        check("cada celula cobre so o proprio Frame (ticks)", x.find(0, MoveCells.SPEED).start + "-" + x.find(0, MoveCells.SPEED).end + ":" + x.find(3, MoveCells.SPEED).start + "-" + x.find(3, MoveCells.SPEED).end, "0-4:10-12");
        check("Frame 3: speed propria e accel", x.find(3, MoveCells.SPEED).text + ":" + x.find(3, MoveCells.ACCEL).text, "x 20:ax 2");
        check("Frame 3 tem speed + accel no mesmo Frame: 2 linhas (speed 0, accel 1)", x.lines + ":" + x.find(3, MoveCells.SPEED).line + ":" + x.find(3, MoveCells.ACCEL).line, "2:0:1");
        check("Frame 5 sem movimento: nenhuma celula", x.find(5, MoveCells.SPEED) == null && x.find(5, MoveCells.ACCEL) == null, true);
        check("celula achada pela linha", x.at(3, 1).kind + ":" + (x.at(0, 1) == null), MoveCells.ACCEL + ":true");

        // y
        MoveCells.Result y = build(m, 1);
        check("y: sem velocidade y nenhuma celula", y.cells.size(), 0);

        // speed e accel em Frames diferentes dividem a linha
        Ano.Mpt[] d = {FrameToolsTest.f(3), FrameToolsTest.speed(FrameToolsTest.f(3), 0, 0, 0, 0)};
        Ano.Mpt a1 = FrameTools.setAccel(FrameToolsTest.f(3), 0, 1.5), s2 = FrameTools.setSpeed(FrameToolsTest.f(3), 0, 4, true);
        MoveCells.Result dv = build(new Ano.Mpt[]{a1, s2}, 0);
        check("accel no Frame 0 e speed no Frame 1: dividem a linha 0", dv.lines + ":" + dv.find(0, MoveCells.ACCEL).line + ":" + dv.find(1, MoveCells.SPEED).line, "1:0:0");
        System.out.println("MoveCellsTest fails=" + fails);
    }
}
