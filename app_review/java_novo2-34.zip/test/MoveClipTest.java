package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;

/** Colar golpe no MESMO personagem: ANOs no fim do DAC (numeros novos, imagens iguais), golpe renumerado na linha escolhida, reacao igual reaproveitada; trocar golpes; salvar acrescenta os ANOs novos. */
public class MoveClipTest {
    static void del(File f) { File[] k = f.listFiles(); if (k != null) for (File c : k) del(c); f.delete(); }

    public static void main(String[] args) throws Exception {
        A[] a = MoveTransplantTest.anos(30);
        a[10] = new A().mpt(new M().time(5).img(3).hit(2, 10, -30, 20, 20).opt1(32)).mpt(new M().time(5).img(7));
        a[11] = new A().mpt(new M().time(5).img(7).hit(2, 5, -30, 20, 20).opt1(31));
        Dac dac = dac(a);
        MoveTransplantTest.link(dac, 10, 13);
        byte[][] reacts = new byte[3][];
        reacts[1] = react(new int[]{10, 11, 12}, new int[]{20, 21, 22});
        reacts[2] = react(new int[]{77, 1, 2});
        // golpes: 0 (ANO 4), 1 = o golpe copiado (ANO inicial 10, SEQ 11), 2 = outro golpe, 3 e 6 especiais
        byte[][] rows = {move(new int[]{2, 4}), move(new int[]{2, 10}, new int[]{10, 11}), move(new int[]{2, 5}), move(new int[]{2, 6}), move(new int[]{2, 7}), move(new int[]{2, 8}), move(new int[]{2, 9}), move(new int[]{2, 12})};
        byte[] all = new byte[rows.length * 48];
        for (int i = 0; i < rows.length; i++) System.arraycopy(rows[i], 0, all, i * 48, 48);
        CharData cd = chr(all, reacts);
        CharData.Move clip = cd.moves[1].copy();

        // ---- colar sobre o golpe 2 (mesmo personagem)
        MoveTransplant.Plan p = MoveTransplant.build(dac, cd, clip, dac, cd, MoveTransplant.KEEP_IMAGES);
        check("os ANOs novos vao para o fim do DAC (numeros novos a partir de 30)", p.anoMap.toString(), "{10=30, 11=31, 13=32}");
        check("as imagens continuam as mesmas (mesmo CNV)", p.anos.get(0).mpts[0].image + ":" + p.anos.get(0).mpts[1].image + ":" + p.anos.get(1).mpts[0].image, "3:7:7");
        check("a reacao 1 e a 2 ja existem iguais: reaproveitadas, nada a gravar", p.reactionMap.toString() + ":" + p.reactionWrites.size(), "{1=1, 2=2}:0");
        check("nao ha o que perguntar ao usuario", MoveTransplant.needsChoice(dac, cd, clip, dac, cd, null).isEmpty(), true);
        int size0 = dac.size();
        MoveTransplant.applyInMemory(p, dac, cd, 2);
        check("o DAC cresceu e tem os ANOs novos", dac.size() + ":" + dac.getAno(30).present + ":" + dac.getAno(32).present, (size0 + 3) + ":true:true");
        check("a linha 2 do Bin virou o golpe colado, renumerado", cd.moves[2].animInicial + ":" + cd.moves[2].animSeqChao, "30:31");
        check("o golpe copiado (linha 1) nao mudou", cd.moves[1].animInicial + ":" + cd.moves[1].animSeqChao, "10:11");
        check("o link do ANO novo aponta para o ANO novo 32", dac.getAno(30).links[0].getAno(), 32);
        check("OPT 1 da hitbox mantem as reacoes (32 e 31)", dac.getAno(30).mpts[0].optData[1] + ":" + dac.getAno(31).mpts[0].optData[1], "32:31");
        check("o ANO original segue igual", dac.getAno(10).mpts[0].image, 3);

        // colar duas vezes: os ANOs vao para o novo fim
        MoveTransplant.Plan p2 = MoveTransplant.build(dac, cd, clip, dac, cd, MoveTransplant.KEEP_IMAGES);
        check("2a colagem: a partir do ANO 33", p2.anoMap.get(Integer.valueOf(10)).intValue(), 33);

        // ---- reacao sem igual: o plano grava num slot vazio
        byte[][] r2 = new byte[3][];
        r2[1] = reacts[1];
        r2[2] = reacts[2];
        CharData dstOther = chr(move(new int[]{2, 3}), new byte[][]{null, react(new int[]{1, 1, 1})});
        MoveTransplant.Plan pe = MoveTransplant.build(dac, cd, clip, dac, dstOther, MoveTransplant.KEEP_IMAGES);
        check("reacoes sem igual no destino: vao para slots vazios", pe.reactionWrites.size() + ":" + pe.reactionMap.size(), "2:2");

        // ---- salvar acrescenta os ANOs novos no .dac.txt
        File dir = new File(System.getProperty("java.io.tmpdir"), "moveclip_test");
        del(dir);
        dir.mkdirs();
        Dac before = dac(a);
        Saver.write(new File(dir, "000.dac.txt"), Saver.dacText(before, null));
        java.util.TreeSet<Integer> novos = new java.util.TreeSet<Integer>(java.util.Arrays.asList(Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(32)));
        String msg = Saver.saveRuntime(dir, dac, cd, novos, null, false);
        String txt = Saver.readText(new File(dir, "000.dac.txt"));
        check("SALVAR acrescenta os $ANO_30..32 que o arquivo nao tinha", Saver.findBlock(txt, "ANO_30") != null && Saver.findBlock(txt, "ANO_31") != null && Saver.findBlock(txt, "ANO_32") != null, true);
        check("e os originais continuam", Saver.findBlock(txt, "ANO_0") != null && Saver.findBlock(txt, "ANO_29") != null, true);
        check("sem 'bloco nao achado' para eles", msg.contains("nao achado"), false);
        int[] b30 = Saver.findBlock(txt, "ANO_30");
        Ano back = DacText.parseAno(txt.substring(b30[0], b30[2] + 1), 30, null);
        check("o bloco acrescentado le de volta igual (imagens e link)", back.mpts[0].image + ":" + back.links[0].getAno(), "3:32");
        String again = Saver.saveRuntime(dir, dac, cd, novos, null, false);
        String txt2 = Saver.readText(new File(dir, "000.dac.txt"));
        check("salvar de novo nao duplica os blocos", txt2.equals(txt), true);
        del(dir);

        // ---- TROCAR golpes: so as linhas do Bin
        check("0, 3 e 6 so trocam com eles mesmos (nao ha troca)", MoveSwap.canSwap(cd, 0, 1) + ":" + MoveSwap.canSwap(cd, 3, 6) + ":" + MoveSwap.canSwap(cd, 0, 3) + ":" + MoveSwap.canSwap(cd, 1, 3), "false:false:false:false");
        check("1 e 2 podem; 1 com 1 e indice fora, nao", MoveSwap.canSwap(cd, 1, 2) + ":" + MoveSwap.canSwap(cd, 1, 1) + ":" + MoveSwap.canSwap(cd, 1, 99) + ":" + MoveSwap.canSwap(cd, -1, 2) + ":" + MoveSwap.canSwap(null, 1, 2), "true:false:false:false:false");
        int a1 = cd.moves[1].animInicial, a2 = cd.moves[2].animInicial, f1 = cd.moves[1].flags, f2 = cd.moves[2].flags;
        check("trocar 1 e 2", MoveSwap.swap(cd, 1, 2), true);
        check("as linhas trocaram (ANO inicial e flags)", cd.moves[1].animInicial + ":" + cd.moves[2].animInicial + ":" + cd.moves[1].flags + ":" + cd.moves[2].flags, a2 + ":" + a1 + ":" + f2 + ":" + f1);
        check("trocar de novo volta ao que era", MoveSwap.swap(cd, 1, 2) && cd.moves[1].animInicial == a1 && cd.moves[2].animInicial == a2, true);
        check("troca invalida nao mexe", MoveSwap.swap(cd, 0, 1) + ":" + cd.moves[0].animInicial, "false:4");
        System.out.println("MoveClipTest fails=" + fails);
    }
}
