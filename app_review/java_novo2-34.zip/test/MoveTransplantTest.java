package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.List;

/** "Salvar este golpe em outro personagem": ANOs renumerados no fim do DAC, imagens novas, reacoes em slot livre, texto do destino. */
public class MoveTransplantTest {
    static A[] anos(int n) {
        A[] a = new A[n];
        for (int i = 0; i < n; i++) a[i] = new A().mpt(new M().time(5).img(1));
        return a;
    }

    static void link(Dac d, int idx, int... targets) {
        Ano old = d.getAno(idx);
        Ano.Link[] ls = new Ano.Link[targets.length];
        for (int i = 0; i < targets.length; i++) ls[i] = new Ano.Link(3, -4, 0x4000 | targets[i]);
        d.setAno(idx, new Ano(idx, true, old.flags | 2, old.priority, ls, old.mpts));
    }

    public static void main(String[] args) throws Exception {
        // ---- regra dos slots
        check("0 so substitui o 0", MoveTransplant.canReplace(0, 0) + ":" + MoveTransplant.canReplace(0, 1) + ":" + MoveTransplant.canReplace(0, 3), "true:false:false");
        check("3 so o 3 e 6 so o 6", MoveTransplant.canReplace(3, 3) + ":" + MoveTransplant.canReplace(3, 6) + ":" + MoveTransplant.canReplace(6, 6) + ":" + MoveTransplant.canReplace(6, 2), "true:false:true:false");
        check("os demais so em nao especiais", MoveTransplant.canReplace(2, 5) + ":" + MoveTransplant.canReplace(2, 0) + ":" + MoveTransplant.canReplace(2, 3) + ":" + MoveTransplant.canReplace(2, 6) + ":" + MoveTransplant.canReplace(7, 7), "true:false:false:false:true");

        // ---- origem: ANO 10 (golpe) com link 13 -> 14, projetil 20 (+1/+2 por ATK 4), SEQ 11, SEQ_PROJETIL 12; ANO 25 nao usado
        A[] sa = anos(30);
        sa[10] = new A().mpt(new M().time(5).img(3).hit(2, 10, -30, 20, 20).opt1(32)).mpt(new M().time(5).img(3)).mpt(new M().time(5).img(7)).mpt(new M().time(5).img(-1));
        sa[11] = new A().mpt(new M().time(5).img(7).hit(2, 5, -30, 20, 20).opt1(31));
        sa[20] = new A().mpt(new M().time(5).img(9).hit(72, 0, 0, 4, 4)).mpt(new M().time(5).img(5000));
        sa[21] = new A().mpt(new M().time(5).img(9));
        sa[22] = new A().mpt(new M().time(5).img(9));
        sa[25] = new A().mpt(new M().time(5).img(8));
        Dac sd = dac(sa);
        link(sd, 10, 13);
        link(sd, 13, 14);
        byte[][] sreact = new byte[3][];
        sreact[1] = react(new int[]{10, 11, 12}, new int[]{20, 21, 22});
        sreact[2] = react(new int[]{77, 1, 2});
        CharData src = chr(move(new int[]{0, 4}, new int[]{2, 10}, new int[]{4, 20}, new int[]{10, 11}, new int[]{32, 12}), sreact);
        CharData.Move m = src.moves[0];

        java.util.TreeSet<Integer> set = MoveTransplant.anosToCopy(sd, m);
        check("ANOs: golpe, SEQ, SEQ_PROJETIL, projetil +1/+2 e links (inclusive o link do link); o ANO 25 e a aura 72 nao", set.toString(), "[10, 11, 12, 13, 14, 20, 21, 22]");

        // ---- destino: DAC de 8 ANOs; reacao 1 igual a da origem, 5 presente e sem uso, 2 ausente
        Dac dd = dac(anos(8));
        byte[][] dreact = new byte[6][];
        dreact[1] = sreact[1];
        dreact[5] = react(new int[]{1, 2, 3});
        CharData dst = chr(move(new int[]{0, 4}, new int[]{2, 3}), dreact);

        final List<Integer> asked = new ArrayList<Integer>();
        MoveTransplant.Sprites spr = new MoveTransplant.Sprites() {
            int next = 100;
            public int add(int image) { asked.add(Integer.valueOf(image)); return image == 5000 ? -1 : next++; }
        };
        // so o slot 5 existe no .bin.txt do destino (o 2, vazio, nao tem bloco para receber a tabela)
        MoveTransplant.Plan p = MoveTransplant.build(sd, src, m, dd, dst, spr, new java.util.TreeSet<Integer>(java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(5))));
        check("ANOs novos vao para o fim do DAC do destino (8..15)", p.anoMap.toString(), "{10=8, 11=9, 12=10, 13=11, 14=12, 20=13, 21=14, 22=15}");
        check("golpe renumerado", p.move.animInicial + ":" + p.move.projNormal + ":" + p.move.animSeqChao + ":" + p.move.animAoAcertar + ":" + p.move.animSeqAr, "8:13:9:10:0");
        check("campos que nao sao ANO ficam", p.move.flags, m.flags);
        check("o golpe original nao muda", m.animInicial + ":" + m.projNormal, "10:20");
        check("cada imagem distinta pede um sprite uma vez so (3, 7, 1, 9, 5000; -1 nao pede)", asked.toString(), "[3, 7, 1, 9, 5000]");
        check("sprites realmente adicionados (a de 5000 nao tem desenho)", p.sprites, 4);
        Ano n8 = p.anos.get(0);
        check("ANO 10 virou 8 com as imagens novas (3 repete a mesma)", n8.index + ":" + n8.mpts[0].image + ":" + n8.mpts[1].image + ":" + n8.mpts[2].image + ":" + n8.mpts[3].image, "8:100:100:101:-1");
        check("link remapeado mantendo os bits e a posicao", n8.links[0].getAno() + ":" + n8.links[0].syncXY() + ":" + n8.links[0].baseX + ":" + n8.links[0].baseY, "11:true:3:-4");
        check("link do link tambem", p.anos.get(4).links.length == 1 && p.anos.get(4).index == 12 || p.anoMap.get(Integer.valueOf(13)).intValue() == 11, true);
        check("imagem sem desenho vira -1", p.anos.get(5).mpts[1].image, -1);
        check("projetil +1/+2 vizinhos continuam consecutivos", p.anoMap.get(Integer.valueOf(21)).intValue() - p.anoMap.get(Integer.valueOf(20)).intValue()
                + p.anoMap.get(Integer.valueOf(22)).intValue() - p.anoMap.get(Integer.valueOf(21)).intValue(), 2);
        check("reacao 1 igual no destino: fica no 1; reacao 2 vai para o slot livre 5", p.reactionMap.toString(), "{1=1, 2=5}");
        check("so a reacao nao igual e gravada, no slot 5", p.reactionWrites.size() == 1 && p.reactionWrites.containsKey(Integer.valueOf(5)), true);
        check("OPT 1 da hitbox remapeado (32 -> 35; 31 fica 31)", p.anos.get(0).mpts[0].optData[1] + ":" + p.anos.get(1).mpts[0].optData[1], "35:31");
        boolean warnAura = false;
        for (String w : p.warnings) if (w.contains("flags de animação")) warnAura = true;
        check("aviso de hitbox flag de animacao do personagem (72)", warnAura, true);

        // ---- textos do destino
        String dacT = MoveTransplant.appendAnos(Saver.dacText(dd, null), p.anos);
        check("ANOs novos no fim do .dac.txt", Saver.findBlock(dacT, "ANO_8") != null && Saver.findBlock(dacT, "ANO_15") != null && Saver.findBlock(dacT, "ANO_16") == null, true);
        check("os originais continuam", Saver.findBlock(dacT, "ANO_0") != null && Saver.findBlock(dacT, "ANO_7") != null, true);
        int[] b8 = Saver.findBlock(dacT, "ANO_8");
        Ano back = DacText.parseAno(dacT.substring(b8[0], b8[2] + 1), 8, null);
        check("o bloco novo le de volta igual", back.mpts.length + ":" + back.mpts[2].image + ":" + back.links[0].getAno(), "4:101:11");

        StringBuilder bin = new StringBuilder("BIN_CNV_ {\n");
        bin.append(DacText.move(dst.moves[0], 0)).append("\n");
        bin.append(Saver.reactionText(dst.reaction(5), 5));
        bin.append("}\n");
        List<String> warns = new ArrayList<String>();
        String bt = MoveTransplant.patchBin(bin.toString(), p, 0, warns);
        int[] gb = Saver.findBlock(bt, "GOLPE_0");
        check("golpe do destino trocado no HDAT 4", gb != null && bt.substring(gb[0], gb[2] + 1).replaceAll("\\s", "").contains("$ANIM_INICIAL:8,"), true);
        check("tabela de reacao gravada no slot 5", bt.contains("$DUR_C: 77"), true);
        check("sem bloco de reacao ausente nao ha aviso", warns.isEmpty(), true);
        // golpe inexistente no destino
        boolean threw = false;
        try { MoveTransplant.patchBin(bin.toString(), p, 9, warns); } catch (java.io.IOException e) { threw = true; }
        check("golpe sem bloco no .bin.txt do destino: erro", threw, true);

        // slot vazio gravavel e preferido ao cheio sem uso
        asked.clear();
        MoveTransplant.Plan pe = MoveTransplant.build(sd, src, m, dd, dst, spr);
        check("com o slot vazio 2 gravavel, a reacao 2 ocupa o proprio slot vazio (e nao o cheio 5)", pe.reactionMap.toString() + ":" + pe.reactionWrites.keySet(), "{1=1, 2=2}:[2]");

        // ---- gravacao: .txt trocados e backup em Tap Battle/TBRE/Backups/
        java.io.File tb = new java.io.File(System.getProperty("java.io.tmpdir"), "transplante_test_tapbattle");
        deleteAll(tb);
        java.io.File cdir = new java.io.File(tb, "assets/char01");
        cdir.mkdirs();
        String dac0 = Saver.dacText(dd, null), bin0 = bin.toString();
        Saver.write(new java.io.File(cdir, "000.dac.txt"), dac0);
        Saver.write(new java.io.File(cdir, "000.bin.txt"), bin0);
        Saver.write(new java.io.File(cdir, "000.cnv.txt"), "CNV_TXT_ {\n}\n");
        final boolean[] committed = new boolean[1];
        java.io.File bk = MoveTransplant.write(cdir, p, 0, new ArrayList<String>(), new MoveTransplant.Commit() {
            public void run() { committed[0] = true; }
        });
        check("gravacao: commit das sprites roda", committed[0], true);
        check("backup em Tap Battle/TBRE/Backups/", bk.getParentFile().getPath().endsWith("transplante_test_tapbattle/TBRE/Backups") && bk.getName().endsWith("_char01_transplante"), true);
        check("backup tem os 3 .txt originais", Saver.readText(new java.io.File(bk, "000.dac.txt")).equals(dac0) && Saver.readText(new java.io.File(bk, "000.bin.txt")).equals(bin0) && new java.io.File(bk, "000.cnv.txt").isFile(), true);
        check("nada de salvos/ dentro do personagem", new java.io.File(cdir, "salvos").exists(), false);
        check("000.dac.txt do destino com os ANOs novos", Saver.findBlock(Saver.readText(new java.io.File(cdir, "000.dac.txt")), "ANO_8") != null, true);
        check("000.bin.txt do destino com o golpe novo", Saver.readText(new java.io.File(cdir, "000.bin.txt")).replaceAll("\\s", "").contains("$ANIM_INICIAL:8,"), true);
        deleteAll(tb);

        // ---- reacoes sem slot livre: sobrescreve o mesmo numero com aviso
        byte[][] full = new byte[20][];
        for (int i = 0; i < 20; i++) full[i] = react(new int[]{i + 1, 0, 0});
        full[1] = sreact[1];
        Dac dfull = dac(anos(8));
        // todos os slots usados por ANOs do destino
        A[] ua = anos(20);
        for (int i = 0; i < 20; i++) ua[i] = new A().mpt(new M().time(5).hit(2, 0, 0, 4, 4).opt1(30 + i));
        Dac dUsed = dac(ua);
        CharData dstFull = chr(move(new int[]{0, 4}, new int[]{2, 3}), full);
        MoveTransplant.Plan q = MoveTransplant.build(sd, src, m, dUsed, dstFull, spr);
        check("sem slot livre: reacao 2 sobrescreve o slot 2 com aviso", q.reactionMap.get(Integer.valueOf(2)).intValue() == 2 && q.reactionWrites.containsKey(Integer.valueOf(2)), true);
        boolean warnOver = false;
        for (String w : q.warnings) if (w.contains("sobrescrita")) warnOver = true;
        check("aviso de sobrescrita", warnOver, true);

        // ---- limite de ANOs do destino
        Dac huge = dac(anos(4));
        boolean over = false;
        try { MoveTransplant.build(sd, src, m, new FakeSizeDac(4090).dac, dst, spr); } catch (java.io.IOException e) { over = true; }
        check("destino sem espaco (4095 e o maximo do link): erro", over, true);

        // ---- Dac cresce
        Dac g = dac(anos(3));
        g.growTo(6);
        check("Dac.growTo", g.size() + ":" + g.getAno(5).present + ":" + g.getAno(2).present, "6:false:true");

        System.out.println("MoveTransplantTest fails=" + BattleTest.fails);
    }

    static void deleteAll(java.io.File f) {
        java.io.File[] k = f.listFiles();
        if (k != null) for (java.io.File c : k) deleteAll(c);
        f.delete();
    }

    /** Dac com {@code n} ANOs (so para o teste do limite). */
    static final class FakeSizeDac {
        final Dac dac;
        FakeSizeDac(int n) throws Exception {
            Dac d = dac(anos(1));
            d.growTo(n);
            this.dac = d;
        }
    }
}
