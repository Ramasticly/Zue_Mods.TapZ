package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** ANO nova (CRIAR ANO / ANO vazia aberta): um frame IMG -1 de 6 ticks, entra no DAC e no texto; angulo do loading. */
public class NewAnoTest {
    public static void main(String[] args) throws Exception {
        Ano a = Ano.blank(5);
        check("ANO nova: presente, 1 frame, imagem -1, 6 ticks", a.index + ":" + a.present + ":" + a.mpts.length + ":" + a.mpts[0].image + ":" + FrameTools.ticks(a.mpts[0]), "5:true:1:-1:6");
        check("sem links", a.links.length, 0);
        A[] anos = new A[3];
        for (int i = 0; i < 3; i++) anos[i] = new A().mpt(new M().time(2));
        Dac d = dac(anos);
        int n = d.size();
        d.growTo(n + 1);
        check("crescer: ultimo + 1 e vazia", d.size() + ":" + d.getAno(n).present, (n + 1) + ":false");
        d.setAno(n, Ano.blank(n));
        check("depois de setAno fica presente com o frame", d.getAno(n).present + ":" + d.getAno(n).mpts.length, "true:1");
        String txt = DacText.ano(d.getAno(n), -1);
        check("o texto do .dac.txt traz a ANO nova", txt.contains("ANO_" + n), true);
        check("angulo do loading: 0 ate quase 360 e volta", AnimPreview.loadingAngle(0) + ":" + AnimPreview.loadingAngle(450) + ":" + (AnimPreview.loadingAngle(899) < 360f) + ":" + AnimPreview.loadingAngle(900), "0.0:180.0:true:0.0");
        System.out.println("NewAnoTest fails=" + fails);
    }
}
