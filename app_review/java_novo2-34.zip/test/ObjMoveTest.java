package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** ObjModel.move / locate: "Frame de inicio" do menu de Hitbox/Hurtbox (move a box inteira; colisao vira outra faixa) e as cores das faixas. */
public class ObjMoveTest {
    static Ano.Mpt mpt(int image) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags |= 0x20; m.time = 4; m.normalize();
        return m;
    }

    static Ano.Hit hit(int flag, int x) {
        Ano.Hit h = new Ano.Hit(); h.flag = flag; h.x = x; h.y = 1; h.width = 10; h.height = 11; return h;
    }

    static Ano.Mpt[] frames(int n) {
        Ano.Mpt[] m = new Ano.Mpt[n];
        for (int i = 0; i < n; i++) m[i] = mpt(i);
        return m;
    }

    static void put(Ano.Mpt[] m, int f, Ano.Hit... h) {
        Ano.Hit[] old = (m[f].flags & 0x10) != 0 ? m[f].hits : new Ano.Hit[0];
        Ano.Hit[] n = new Ano.Hit[old.length + h.length];
        System.arraycopy(old, 0, n, 0, old.length);
        System.arraycopy(h, 0, n, old.length, h.length);
        m[f].hits = n;
        m[f].flags |= 0x10;
        m[f].normalize();
    }

    static ObjModel.Obj find(Ano.Mpt[] m, int flag, int occ) {
        for (ObjModel.Obj o : ObjModel.objects(m)) if (o.flag == flag && o.occ == occ) return o;
        return null;
    }

    public static void main(String[] args) throws Exception {
        // hitbox (flag 2) nos frames 1-2 (valores diferentes em cada), hurtbox (flag 1) no frame 0
        Ano.Mpt[] m = frames(6);
        put(m, 0, hit(1, 50));
        put(m, 1, hit(2, 10));
        put(m, 2, hit(2, 20));
        ObjModel.Obj o = find(m, 2, 0);
        check("objeto inicial: 2 frames com valores diferentes sao 2 objetos", o != null && o.f0 == 1 && o.f1 == 1, true);
        // junta: mesmo valor nos dois frames
        m[2].hits[0].x = 10;
        o = find(m, 2, 0);
        check("objeto de 2 frames", o != null && o.f0 == 1 && o.f1 == 2, true);

        Ano.Mpt[] mv = ObjModel.move(m, o, 3);
        ObjModel.Obj n = ObjModel.locate(mv, 2, 3);
        check("mover: comeca no frame novo e mantem a duracao", n != null && n.f0 == 3 && n.f1 == 4, true);
        check("mover: some dos frames antigos", ObjModel.find(mv[1], 2, 0) == null && ObjModel.find(mv[2], 2, 0) == null, true);
        check("mover: mantem os valores do hit", ObjModel.find(mv[3], 2, 0).x == 10 && ObjModel.find(mv[4], 2, 0).width == 10, true);
        check("mover: hurtbox e outros frames intactos", ObjModel.find(mv[0], 1, 0).x == 50 && mv[5] == m[5], true);
        check("mover: nao altera a lista original", ObjModel.find(m[1], 2, 0) != null && ObjModel.find(m[3], 2, 0) == null, true);

        // limite do fim: 2 frames numa ANO de 6 => inicio maximo 4
        Ano.Mpt[] end = ObjModel.move(m, o, 99);
        ObjModel.Obj e = ObjModel.locate(end, 2, 4);
        check("mover: prende no fim da ANO", e != null && e.f0 == 4 && e.f1 == 5, true);
        Ano.Mpt[] start = ObjModel.move(m, o, -5);
        check("mover: prende no inicio", ObjModel.locate(start, 2, 0) != null && ObjModel.locate(start, 2, 0).f1 == 1, true);
        check("mover para o mesmo inicio nao muda", ObjModel.move(m, o, o.f0) == m, true);

        // mover para sobrepor o proprio trecho (1-2 -> 2-3): sem colisao consigo mesmo
        Ano.Mpt[] ov = ObjModel.move(m, o, 2);
        ObjModel.Obj on = ObjModel.locate(ov, 2, 2);
        check("mover sobrepondo o proprio trecho: 1 so objeto de 2 frames", on != null && on.f0 == 2 && on.f1 == 3 && on.occ == 0 && ObjModel.find(ov[1], 2, 0) == null, true);

        // colisao: outra hitbox igual (flag 2) nos frames 3-4; mover a primeira para la nao recusa e cria a segunda faixa
        Ano.Mpt[] c = frames(6);
        put(c, 1, hit(2, 10));
        put(c, 2, hit(2, 10));
        put(c, 3, hit(2, 99));
        put(c, 4, hit(2, 99));
        ObjModel.Obj first = find(c, 2, 0);
        ObjModel.Obj a0 = null;
        for (ObjModel.Obj k : ObjModel.objects(c)) if (k.flag == 2 && k.f0 == 1) a0 = k;
        check("colisao: objeto de origem achado", a0 != null && a0.f1 == 2, true);
        Ano.Mpt[] cm = ObjModel.move(c, a0, 3);
        check("colisao: nao recusa (devolve outro array)", cm != c, true);
        check("colisao: frame de destino tem 2 hitboxes (outra faixa)", ObjModel.count(cm[3], 2) == 2 && ObjModel.count(cm[4], 2) == 2, true);
        ObjModel.Obj moved = ObjModel.locate(cm, 2, 3);
        check("colisao: locate acha a movida na faixa seguinte (occ 1) com os valores dela", moved != null && moved.occ == 1 && ObjModel.find(cm[3], 2, 1).x == 10, true);
        check("colisao: a original continua na faixa 0", ObjModel.find(cm[3], 2, 0).x == 99, true);
        int lanes = 0;
        for (ObjModel.Obj k : ObjModel.objects(cm)) if (k.flag == 2) lanes = Math.max(lanes, k.occ + 1);
        check("colisao: a timeline passa a ter 2 faixas dessa flag", lanes, 2);

        // dano e reacao (OPT 0 e 1) acompanham a hitbox, cada frame leva o seu
        Ano.Mpt[] d = frames(6);
        put(d, 1, hit(2, 10));
        put(d, 2, hit(2, 10));
        d[1] = ObjModel.setOptField(ObjModel.setOptField(d[1], 0, 77), 1, 105);
        d[2] = ObjModel.setOptField(ObjModel.setOptField(d[2], 0, 66), 1, 72);
        ObjModel.Obj od = find(d, 2, 0);
        check("dano: objeto de 2 frames", od != null && od.f0 == 1 && od.f1 == 2, true);
        Ano.Mpt[] dm = ObjModel.move(d, od, 3);
        check("dano e reacao andam junto, cada frame com o seu",
                ObjModel.optField(dm[3], 0) == 77 && ObjModel.optField(dm[3], 1) == 105 && ObjModel.optField(dm[4], 0) == 66 && ObjModel.optField(dm[4], 1) == 72, true);
        check("dano e reacao somem do frame antigo e o bloco OPT vazio sai", ObjModel.optField(dm[1], 0) == 0 && ObjModel.optField(dm[1], 1) == 0 && (dm[1].flags & 0x40) == 0 && (dm[2].flags & 0x40) == 0, true);
        check("mover nao altera os frames originais", ObjModel.optField(d[1], 0) == 77, true);

        // outros campos do OPT (optFlag e dados 2-3) ficam; so dano/reacao saem
        Ano.Mpt[] f = frames(5);
        put(f, 1, hit(2, 10));
        f[1] = ObjModel.setOptField(ObjModel.setOptField(f[1], 0, 9), 1, 33);
        f[1].optData[2] = 4;
        f[1] = ObjModel.setOptFlagBit(f[1], 512, true);
        Ano.Mpt[] fm = ObjModel.move(f, find(f, 2, 0), 3);
        check("OPT: flags e dados 2-3 ficam no frame antigo", (fm[1].flags & 0x40) != 0 && fm[1].optData[2] == 4 && ObjModel.optFlagBit(fm[1], 512)
                && ObjModel.optField(fm[1], 0) == 0 && ObjModel.optField(fm[1], 1) == 0, true);
        check("OPT: destino recebe so dano e reacao", ObjModel.optField(fm[3], 0) == 9 && ObjModel.optField(fm[3], 1) == 33 && fm[3].optData[2] == 0 && !ObjModel.optFlagBit(fm[3], 512), true);

        // frame antigo com 2a hitbox: o valor fica (vale para ela tambem)
        Ano.Mpt[] g = frames(5);
        put(g, 1, hit(2, 10), hit(2, 50));
        g[1] = ObjModel.setOptField(ObjModel.setOptField(g[1], 0, 20), 1, 40);
        ObjModel.Obj g0 = null;
        for (ObjModel.Obj k : ObjModel.objects(g)) if (k.flag == 2 && k.occ == 0) g0 = k;
        Ano.Mpt[] gm = ObjModel.move(g, g0, 3);
        check("2a hitbox no frame antigo: dano e reacao ficam la e tambem vao", ObjModel.optField(gm[1], 0) == 20 && ObjModel.optField(gm[3], 0) == 20 && ObjModel.optField(gm[3], 1) == 40, true);

        // colisao: o destino ja tem hitbox com dano proprio, que e mantido
        Ano.Mpt[] h2 = frames(5);
        put(h2, 1, hit(2, 10));
        put(h2, 3, hit(2, 99));
        h2[1] = ObjModel.setOptField(ObjModel.setOptField(h2[1], 0, 11), 1, 22);
        h2[3] = ObjModel.setOptField(ObjModel.setOptField(h2[3], 0, 88), 1, 77);
        ObjModel.Obj h0 = null;
        for (ObjModel.Obj k : ObjModel.objects(h2)) if (k.flag == 2 && k.f0 == 1) h0 = k;
        Ano.Mpt[] hm = ObjModel.move(h2, h0, 3);
        check("colisao: o destino mantem o dano e a reacao dele; o antigo e limpo",
                ObjModel.optField(hm[3], 0) == 88 && ObjModel.optField(hm[3], 1) == 77 && ObjModel.optField(hm[1], 0) == 0 && ObjModel.count(hm[3], 2) == 2, true);

        // hurtbox nao mexe no OPT
        Ano.Mpt[] u = frames(5);
        put(u, 1, hit(1, 10));
        u[1] = ObjModel.setOptField(u[1], 0, 5);
        Ano.Mpt[] um = ObjModel.move(u, find(u, 1, 0), 3);
        check("hurtbox: o OPT nao anda", ObjModel.optField(um[1], 0) == 5 && ObjModel.optField(um[3], 0) == 0, true);

        // mover dentro do proprio trecho (1-2 -> 2-3): dano de cada frame segue a box
        Ano.Mpt[] w = frames(6);
        put(w, 1, hit(2, 10));
        put(w, 2, hit(2, 10));
        w[1] = ObjModel.setOptField(w[1], 0, 31);
        w[2] = ObjModel.setOptField(w[2], 0, 32);
        Ano.Mpt[] wm = ObjModel.move(w, find(w, 2, 0), 2);
        check("mover sobrepondo o proprio trecho: dano segue frame a frame", ObjModel.optField(wm[2], 0) == 31 && ObjModel.optField(wm[3], 0) == 32 && ObjModel.optField(wm[1], 0) == 0, true);

        // ---- duracao (trim): dano e reacao tambem sao copiados / zerados
        Ano.Mpt[] t = frames(8);
        put(t, 2, hit(2, 10));
        put(t, 3, hit(2, 10));
        t[2] = ObjModel.setOptField(ObjModel.setOptField(t[2], 0, 40), 1, 105);
        t[3] = ObjModel.setOptField(ObjModel.setOptField(t[3], 0, 41), 1, 106);
        ObjModel.Obj ot = find(t, 2, 0);
        Ano.Mpt[] tf = ObjModel.trim(t, ot, 2, 5);      // cresce para frente: copia o par da borda (frame 3)
        check("trim para frente copia o dano e a reacao da borda", ObjModel.optField(tf[4], 0) == 41 && ObjModel.optField(tf[5], 1) == 106 && ObjModel.optField(tf[3], 0) == 41, true);
        check("trim: hit nos frames novos", ObjModel.find(tf[4], 2, 0) != null && ObjModel.find(tf[5], 2, 0) != null && ObjModel.find(tf[6], 2, 0) == null, true);
        Ano.Mpt[] tb = ObjModel.trim(t, ot, 0, 3);      // cresce para tras: copia o par da borda (frame 2)
        check("trim para tras copia o dano e a reacao da borda", ObjModel.optField(tb[0], 0) == 40 && ObjModel.optField(tb[1], 1) == 105, true);
        Ano.Mpt[] ts = ObjModel.trim(t, ot, 2, 2);      // encolhe: o frame que sai perde dano e reacao
        check("trim encolhendo zera dano e reacao do frame que sai", ObjModel.optField(ts[3], 0) == 0 && ObjModel.optField(ts[3], 1) == 0 && (ts[3].flags & 0x40) == 0 && ObjModel.optField(ts[2], 0) == 40, true);
        check("trim nao altera a lista original", ObjModel.optField(t[3], 0) == 41 && ObjModel.optField(t[4], 0) == 0, true);

        // destino com hitbox propria (colisao) mantem o dano dele
        Ano.Mpt[] tc = frames(6);
        put(tc, 1, hit(2, 10));
        put(tc, 2, hit(2, 99));
        tc[1] = ObjModel.setOptField(tc[1], 0, 5);
        tc[2] = ObjModel.setOptField(tc[2], 0, 66);
        ObjModel.Obj o1 = null;
        for (ObjModel.Obj k : ObjModel.objects(tc)) if (k.flag == 2 && k.f0 == 1) o1 = k;
        Ano.Mpt[] tcm = ObjModel.trim(tc, o1, 1, 2);
        check("trim sobre outra hitbox: o destino mantem o dano dele", ObjModel.optField(tcm[2], 0) == 66 && ObjModel.count(tcm[2], 2) == 2, true);

        // hurtbox: o OPT nao muda
        Ano.Mpt[] th = frames(6);
        put(th, 1, hit(1, 10));
        th[1] = ObjModel.setOptField(th[1], 0, 5);
        Ano.Mpt[] thm = ObjModel.trim(th, find(th, 1, 0), 1, 3);
        check("trim de hurtbox nao copia dano", ObjModel.optField(thm[2], 0) == 0 && ObjModel.optField(thm[1], 0) == 5, true);

        // ---- avancar a simulacao ate um frame (previa parada)
        A[] aa = new A[1];
        aa[0] = new A().mpt(new M().time(5).img(1)).mpt(new M().time(5).img(2).hit(1, -10, -60, 20, 60)).mpt(new M().time(5).img(3).hit(2, 10, -50, 30, 20)).mpt(new M().time(5).img(4));
        Dac dd = dac(aa);
        AttackSim s0 = new AttackSim(dd, 0, false);
        check("advanceToPat chega ao frame pedido", AnimPreview.advanceToPat(s0, 2) && s0.root().pat == 2, true);
        check("no frame pedido as boxes sao as dele (so a hitbox)", s0.root().hits.length == 1 && s0.root().hits[0].flag == 2, true);
        AttackSim s1 = new AttackSim(dd, 0, false);
        check("advanceToPat no frame 0 nao anda", AnimPreview.advanceToPat(s1, 0) && s1.root().pat == 0, true);
        AttackSim s2 = new AttackSim(dd, 0, false);
        check("advanceToPat de frame inexistente devolve false e para no fim", !AnimPreview.advanceToPat(s2, 99), true);

        // cores das faixas: hitbox vermelha, audio azul (ver TimelineView.C_AUDIO)
        check("cor da faixa Hitbox = vermelho", ObjModel.KIND_COLORS[ObjModel.HITBOX], 0xFFE5484D);
        check("cor da faixa Hurtbox continua verde", ObjModel.KIND_COLORS[ObjModel.HURTBOX], 0xFF3DDC84);

        // GOLPE SET: a reacao do choque de hitbox (HDAT 3, byte 13) aparece como numero real
        check("reacao do choque: < 30 e do jogo", CharData.reactionName(5), "do jogo 5");
        check("reacao do choque: 30 ou mais e do personagem (N - 30)", CharData.reactionName(32) + "|" + CharData.reactionName(30) + "|" + CharData.reactionName(0), "do personagem 2|do personagem 0|do jogo 0");

        System.out.println("ObjMoveTest fails=" + BattleTest.fails);
    }
}
