package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Efeitos colocados nos frames do OPONENTE (flags 71-125 do personagem dele, ex.: na defesa, ANO 4) tambem sao criados e desenhados. */
public class OppEffectTest {
    static boolean hasOwner(BattleSim s, int owner) {
        for (BattleSim.Layer l : s.layers()) if (l.owner == owner) return true;
        return false;
    }

    public static void main(String[] args) throws Exception {
        BattleSim.defend = false;
        A[] atk = new A[41];
        for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(1));
        atk[40] = new A().mpt(new M().time(3)).mpt(new M().time(40));
        A[] def = new A[205];
        for (int i = 0; i < def.length; i++) def[i] = new A().mpt(new M().time(30).img(1));
        def[0] = new A().mpt(new M().time(30).img(1).hit(71, 5, -20, 0, 0));            // parado com um efeito do personagem dele (ANO 201)
        def[201] = new A().mpt(new M().time(30).img(1));
        A[] fx = new A[5];
        for (int i = 0; i < 5; i++) fx[i] = new A().mpt(new M().time(4));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(fx), g, 200, 0, 0);
        for (int i = 0; i < 4; i++) s.step();
        check("o efeito do personagem do oponente (flag 71 -> ANO 201 dele) aparece", hasOwner(s, BattleSim.OWNER_AURA_OPPCHAR), true);
        check("e nao e confundido com a aura do atacante", hasOwner(s, BattleSim.OWNER_AURA_CHAR), false);

        // sem a flag nao ha aura
        def[0] = new A().mpt(new M().time(30).img(1));
        BattleSim n = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(fx), g, 200, 0, 0);
        for (int i = 0; i < 4; i++) n.step();
        check("sem a flag: nenhuma aura do oponente", hasOwner(n, BattleSim.OWNER_AURA_OPPCHAR), false);

        // defesa (ANO 4) com o efeito: aparece enquanto o oponente defende
        BattleSim.defend = true;
        try {
            A[] atk2 = new A[41];
            for (int i = 0; i < atk2.length; i++) atk2[i] = new A().mpt(new M().time(1));
            atk2[40] = new A().mpt(new M().time(2)).mpt(new M().time(3).hit(2, 20, -40, 40, 20).opt1(3)).mpt(new M().time(40));
            def[0] = new A().mpt(new M().time(30).img(1).hit(1, -10, -60, 20, 60));
            def[4] = new A().mpt(new M().time(60).img(-1).hit(71, 0, -30, 0, 0)).mpt(new M().time(10));    // defesa sem sprite; o visual e o efeito
            CharData ch2 = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim d = new BattleSim(dac(atk2), ch2, ch2.moves[0], false, dac(def), dac(fx), g, 30, 0, 0);
            boolean seen = false;
            for (int i = 0; i < 12; i++) { d.step(); if (hasOwner(d, BattleSim.OWNER_AURA_OPPCHAR)) seen = true; }
            check("DEF: o efeito colocado na defesa (ANO 4) aparece", seen, true);
        } finally { BattleSim.defend = false; }
        System.out.println("OppEffectTest fails=" + fails);
    }
}
