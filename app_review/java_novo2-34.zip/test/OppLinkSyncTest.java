package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Corpo, links e auras do OPONENTE ficam colados em todo tick durante o deslocamento (knockback, guarda, camera, parede). */
public class OppLinkSyncTest {
    /** Primeiro tick em que algo do oponente fica fora do corpo; -1 = tudo certo. */
    static int seenAura, minY, travel;

    static String run(BattleSim s, int ticks, int auraOx, int auraOy) {
        int x0 = s.opponentX();
        for (int t = 0; t < ticks; t++) {
            s.step();
            AttackSim.Obj r = s.opponent().root();
            if (r == null) continue;
            minY = Math.min(minY, s.opponentY());
            travel = Math.max(travel, Math.abs(s.opponentX() - x0));
            for (AttackSim.Obj c : s.opponent().children()) {
                if (c != null && (c.x != r.x || c.y != r.y)) return "tick " + t + ": link do oponente em " + (c.x >> 16) + "," + (c.y >> 16) + " corpo em " + (r.x >> 16) + "," + (r.y >> 16);
            }
            for (BattleSim.Layer l : s.layers()) {
                if (l.owner != BattleSim.OWNER_AURA_OPPCHAR || l.only == null || l.sim.root() == null || l.sim.root() != l.only) continue;
                int ox = (r.objFlags & 16) != 0 ? -auraOx : auraOx;
                AttackSim.Obj a = l.sim.root();
                seenAura++;
                if (a.x - r.x != ox << 16 || a.y - r.y != auraOy << 16) return "tick " + t + ": aura em " + ((a.x - r.x) >> 16) + "," + ((a.y - r.y) >> 16) + " do corpo (esperado " + ox + "," + auraOy + ")";
                for (AttackSim.Obj c : l.sim.children()) if (c != null && (c.x != a.x || c.y != a.y)) return "tick " + t + ": link da aura fora da aura";
            }
        }
        return "";
    }

    public static void main(String[] args) throws Exception {
        BattleSim.defend = false;
        A[] fx = new A[5];
        for (int i = 0; i < 5; i++) fx[i] = new A().mpt(new M().time(4));
        for (int dist = 30; dist <= 200; dist += 85) for (int left = 0; left < 2; left++) for (int variant = 0; variant < 8; variant++) {
            A[] atk = new A[210];
            for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(1).img(1));
            atk[40] = new A().mpt(variant >= 6 ? new M().time(2).img(1).hit(variant == 6 ? 40 : 39, 30, 0, 0, 0) : new M().time(2).img(1).speedX(variant == 1 ? 3 << 16 : 0)).mpt(new M().time(3).img(1).hit(2, 20, -40, 250, 20).opt1(3)).mpt(new M().time(60).img(1));
            A[] def = new A[210];
            for (int i = 0; i < def.length; i++) def[i] = new A().mpt(new M().time(40).img(1).hit(1, -10, -60, 20, 60).hit(71, 4, -30, 0, 0));
            def[201] = new A().mpt(new M().time(120).img(1));
            def[150] = new A().mpt(new M().time(120).img(1));
            Dac dd = dac(def);
            for (int i = 0; i < 25; i++) LinkHierarchyTest.link(dd, i, 150);
            LinkHierarchyTest.link(dd, 201, 150);
            int[] row = variant == 2 ? new int[]{30, 30, 20, 8, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0} : new int[]{30, 30, 20, 12, 6, 6, 4, 0, 0, 0, 0, 0, 0, 0};
            byte[][] tabs = { null, null, null, react(row), react(new int[]{20, 20, 21, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) };
            if (variant >= 3) {            // lancado ao ar (sobe, cai, pousa em outro tipo); 4 = bate na parede (WALL 1), 5 = camera de deslocamento (WALL 3)
                tabs[3] = react(new int[]{30, 30, 20, 10, 0x80 | 0x4C, 0, 3, 0, 0, 0, 0, 4, variant == 4 ? 1 : variant == 5 ? 3 : 0, 0});
            }
            GameData g = gd(tabs);
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], left == 1, dd, dac(fx), g, dist, 0, 0);
            minY = 0; travel = 0;
            String res = run(s, 160, 4, -30);
            if (variant >= 3 && variant <= 5) check("o oponente foi lancado (variante " + variant + ")", minY < -5, true);
            if (variant < 6) check("o oponente andou (dist " + dist + " left " + left + " var " + variant + " travel " + travel + " minY " + minY + ")", travel > 10, true);
            check("oponente colado (dist " + dist + " left " + left + " var " + variant + ") " + res, res, "");
        }

        check("a aura do oponente foi vista", seenAura > 500, true);
        
        // ---- trava cinematica (md 926) e 1o tick: a camera / bordas mexem na raiz e os links / auras seguem, sem passar pelo fluxo normal
        for (int dist = 20; dist <= 400; dist += 60) for (int left = 0; left < 2; left++) {
            A[] atk = new A[210];
            for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(1).img(1));
            atk[40] = new A().mpt(new M().time(200).img(1).hit(71, 10, -20, 0, 0));
            atk[201] = new A().mpt(new M().time(200).img(1));
            Dac da = dac(atk);
            for (int i = 0; i < 41; i++) LinkHierarchyTest.link(da, i, 201);
            A[] def = new A[210];
            for (int i = 0; i < def.length; i++) def[i] = new A().mpt(new M().time(40).img(1).hit(1, -10, -60, 20, 60).hit(71, 4, -30, 0, 0));
            def[201] = new A().mpt(new M().time(120).img(1));
            def[150] = new A().mpt(new M().time(120).img(1));
            Dac dd = dac(def);
            for (int i = 0; i < 25; i++) LinkHierarchyTest.link(dd, i, 150);
            GameData g = gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20, 8, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0}) });
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(da, ch, ch.moves[0], left == 1, dd, dac(fx), g, dist, 0, 0);
            s.setSpecialType(9);
            String res = "";
            for (int t = 0; t < 140 && res.isEmpty(); t++) {
                AttackSim.Obj ra = s.attacker().root(), ro = s.opponent().root();
                if (ra != null) for (AttackSim.Obj c : s.attacker().children()) if (c != null && (c.x != ra.x || c.y != ra.y)) res = "tick " + t + ": link do atacante solto";
                if (ro != null) for (AttackSim.Obj c : s.opponent().children()) if (c != null && (c.x != ro.x || c.y != ro.y)) res = "tick " + t + ": link do oponente solto";
                for (BattleSim.Layer l : s.layers()) {
                    if (l.only == null || l.sim.root() != l.only) continue;
                    AttackSim.Obj base = l.owner == BattleSim.OWNER_AURA_CHAR ? ra : l.owner == BattleSim.OWNER_AURA_OPPCHAR ? ro : null;
                    if (base == null) continue;
                    int ox = l.owner == BattleSim.OWNER_AURA_CHAR ? 10 : 4, oy = l.owner == BattleSim.OWNER_AURA_CHAR ? -20 : -30;
                    if ((base.objFlags & 16) != 0) ox = -ox;
                    if (l.only.x - base.x != ox << 16 || l.only.y - base.y != oy << 16) res = "tick " + t + ": aura " + l.owner + " fora do dono";
                }
                s.step();
            }
            check("trava cinematica (dist " + dist + " left " + left + ") " + res, res, "");
        }

        // ---- aura com velocidade propria: fica no dono + offset + o passo DELE neste tick (o placeAuras so leva o deslocamento do dono)
        {
            A[] atk = new A[210];
            for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(1).img(1));
            atk[40] = new A().mpt(new M().time(200).img(1).hit(71, 10, -20, 0, 0));
            atk[201] = new A().mpt(new M().time(200).img(1).speedX(6 << 16));
            A[] def = new A[210];
            for (int i = 0; i < def.length; i++) def[i] = new A().mpt(new M().time(40).img(1).hit(1, -10, -60, 20, 60));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(fx), gd(new byte[][] { null, null, null, react(new int[]{30, 30, 20}) }), 150, 0, 0);
            int bad = 0, seen = 0;
            for (int t = 0; t < 30; t++) {
                s.step();
                AttackSim.Obj r = s.attacker().root();
                for (BattleSim.Layer l : s.layers()) {
                    if (l.owner != BattleSim.OWNER_AURA_CHAR || l.only == null || l.sim.root() != l.only) continue;
                    seen++;
                    if (l.only.x - r.x != (10 + 6) << 16) bad++;
                }
            }
            check("aura com speed 6: dono + 10 + 6 em todo tick (sem apagar a velocidade dela)", seen > 20 && bad == 0, true);
        }
        System.out.println("OppLinkSyncTest fails=" + fails);
    }
}
