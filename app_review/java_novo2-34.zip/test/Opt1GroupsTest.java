package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Textos da grade efeito/som da hitbox: efeito, som, empurrao e hitstop de cada grupo do OPT 1. */
public class Opt1GroupsTest {
    public static void main(String[] args) throws Exception {
        check("grupo 0: normal", Opt1.groupDetail(0), "efeito 0 · som 3 · empurra · hitstop 10");
        check("grupo 1: som alternativo", Opt1.groupDetail(1), "efeito 0 · som 4 · empurra · hitstop 10");
        check("grupo 2: forte", Opt1.groupDetail(2), "efeito 1 · som 6 · empurra · hitstop 10");
        check("grupo 3: leve (metade do hitstop, sem empurrar)", Opt1.groupDetail(3), "efeito 0 · som 3 · nao empurra · hitstop 5");
        check("grupo 4: nada", Opt1.groupDetail(4), "sem efeito · sem som · nao empurra · sem hitstop");
        check("grupo fora da faixa prende nas pontas", Opt1.groupDetail(-3) + "|" + Opt1.groupDetail(99), Opt1.groupDetail(0) + "|" + Opt1.groupDetail(4));
        check("5 titulos", Opt1.GROUP_TITLES.length, 5);
        check("o som do grupo vira o id do frame (se_03 = id 4)", SoundIds.idOfCommon(new Opt1(3 * 0 + 5).sound), 4);
        System.out.println("Opt1GroupsTest fails=" + fails);
    }
}
