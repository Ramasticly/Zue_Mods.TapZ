package com.zue.attackeditor;

public class OptimizeTest {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    static int[] frame(int w, int h, int color) { int[] a = new int[w * h]; java.util.Arrays.fill(a, color); return a; }

    static boolean distinct() {
        SpriteGroups.Group gr = new SpriteGroups.Group("x", 10, 3, new int[]{1, 1, 1, 1, 1, 1});
        gr.seq = new int[]{10, 11, 12, 12, 12, 11};
        return gr.frames() == 6 && gr.distinctSprites() == 3;
    }

    public static void main(String[] x) {
        int w = 40, h = 30;
        int[] f0 = frame(w, h, 0xFF204060);
        int[] f1 = frame(w, h, 0xFFAA0000);
        int[] f2 = f0.clone(); f2[7] = 0xFFFFFFFF;                  // 1 pixel muito diferente de f0
        int[] f3 = f0.clone();                                       // identico a f0
        int[] f4 = f0.clone(); for (int i = 0; i < 200; i++) f4[i] = 0xFF00FF00;   // ~17% diferente
        GifOptimizer.Sig[] s = {GifOptimizer.sig(f0, w, h), GifOptimizer.sig(f1, w, h), GifOptimizer.sig(f2, w, h), GifOptimizer.sig(f3, w, h), GifOptimizer.sig(f4, w, h)};
        check("identico = 100", GifOptimizer.score(s[0], s[3]) == 100);
        int sc2 = GifOptimizer.score(s[0], s[2]);
        check("1 pixel diferente < 100 e >= 99", sc2 == 99);
        check("cores muito diferentes = 0", GifOptimizer.score(s[0], s[1]) == 0);
        int sc4 = GifOptimizer.score(s[0], s[4]);
        check("17% diferente ~83%", sc4 >= 80 && sc4 <= 85);
        check("tamanho diferente = 0", GifOptimizer.score(s[0], GifOptimizer.sig(frame(10, 10, 0xFF204060), 10, 10)) == 0);
        int[] t1 = {0x00112233, 0xFF000000}, t2 = {0x00AABBCC, 0xFF000000};
        check("transparentes com RGB diferente sao identicos", GifOptimizer.score(GifOptimizer.sig(t1, 2, 1), GifOptimizer.sig(t2, 2, 1)) == 100);

        // animacao: parado, gira, parado de novo (quadro 0 = 3 = 5)
        GifOptimizer.Analysis an = new GifOptimizer.Analysis();
        an.n = 6;
        GifOptimizer.Sig[] g = {s[0], s[1], s[1], s[0], s[2], s[3]};
        an.valid = new boolean[]{true, true, true, true, true, true};
        an.sprite = new int[]{10, 11, 12, 13, 14, 15};
        an.score = new int[6][6];
        for (int i = 0; i < 6; i++) for (int j = 0; j < 6; j++) if (i != j) an.score[i][j] = GifOptimizer.score(g[i], g[j]);
        int[] r100 = GifOptimizer.match(an, 100);
        check("100%: so identicos (1=2, 0=3=5; 4 fica)", java.util.Arrays.equals(r100, new int[]{0, 1, 1, 0, 4, 0}));
        int[] r90 = GifOptimizer.match(an, 90);
        check("90%: o quadro com 1 pixel diferente tambem vai para o 0", java.util.Arrays.equals(r90, new int[]{0, 1, 1, 0, 0, 0}));
        check("contagem de removidos", GifOptimizer.removedCount(an, r100) == 3 && GifOptimizer.removedCount(an, r90) == 4);
        // ja otimizado: quadros 3 e 4 reaproveitam a sprite do quadro 1; nada a mais para remover
        GifOptimizer.Analysis ao = new GifOptimizer.Analysis();
        ao.n = 4; ao.valid = new boolean[]{true, true, true, true};
        ao.sprite = new int[]{10, 11, 10, 10};
        ao.score = new int[4][4];
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (i != j) ao.score[i][j] = ao.sprite[i] == ao.sprite[j] ? 100 : 0;
        int[] rr = GifOptimizer.match(ao, 100);
        check("ja otimizado: nenhuma sprite a remover, 2 distintas", GifOptimizer.removedCount(ao, rr) == 0 && GifOptimizer.distinctSprites(ao) == 2);
        // regressao do crash ao abrir "Otimizar GIF": a tela conta as sprites ANTES de qualquer match (first ainda nulo)
        GifOptimizer.Analysis fresh = new GifOptimizer.Analysis();
        fresh.n = 5; fresh.valid = new boolean[]{true, true, false, true, true};
        fresh.sprite = new int[]{10, 11, -1, 10, 12};
        fresh.score = new int[5][5];
        boolean threw = false; int cnt = -1, rem = -1;
        try { cnt = GifOptimizer.distinctSprites(fresh); rem = GifOptimizer.removedCount(fresh, new int[]{0, 1, -1, 0, 4}); } catch (RuntimeException e) { threw = true; }
        check("distinctSprites sem match antes nao lanca e conta sprites repetidas uma vez (vazio nao conta)", !threw && cnt == 3);
        check("removedCount sem match antes nao lanca (o quadro 3 ja usa a sprite do 0: nada a remover)", !threw && rem == 0);
        GifOptimizer.Analysis fresh2 = new GifOptimizer.Analysis();
        fresh2.n = 5; fresh2.valid = fresh.valid; fresh2.sprite = fresh.sprite; fresh2.score = new int[5][5];
        check("removedCount de uma Analysis nova = o mesmo de depois do match", GifOptimizer.removedCount(fresh2, new int[]{0, 1, -1, 0, 4}) == GifOptimizer.removedCount(fresh, new int[]{0, 1, -1, 0, 4}));
        check("distinctSprites do grupo", distinct());
        an.valid[2] = false;
        check("vazio fica -1", GifOptimizer.match(an, 100)[2] == -1);

        // grupo com seq: ida e volta no JSON
        SpriteGroups sg = new SpriteGroups();
        SpriteGroups.Group gr = new SpriteGroups.Group("giro.gif", 10, 3, new int[]{100, 80, 60, 40});
        gr.seq = new int[]{10, 11, 12, 10};
        sg.add(gr);
        SpriteGroups r = new SpriteGroups();
        r.parse(sg.toJson());
        SpriteGroups.Group b = r.list.get(0);
        check("seq no JSON", b.frames() == 4 && b.count == 3 && b.spriteAt(3) == 10 && b.delayAt(3) == 40 && b.last() == 12);
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHAS");
        if (fails > 0) System.exit(1);
    }
}
