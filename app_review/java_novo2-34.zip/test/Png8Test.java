package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** PNG de 8 bits com paleta: sem perda com ate 256 cores, quantizado acima disso, alpha em tRNS e arquivo menor. */
public class Png8Test {
    public static void main(String[] args) throws Exception {
        int w = 64, h = 48;
        // 5 cores + transparencia
        int[] few = new int[w * h];
        int[] cols = {0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0x80FFFFFF, 0xFF102030, 0x00000000};
        for (int i = 0; i < few.length; i++) few[i] = cols[(i / 7 + i / (w * 5)) % cols.length];
        Png8.Out o = Png8.encode(Png8.of(few, w, h));
        check("poucas cores: sem perda", o.lossless, true);
        check("paleta = so as cores usadas", o.colors, 6);
        Png8.Img back = Png8.decode(o.png);
        boolean same = back.w == w && back.h == h;
        for (int i = 0; i < few.length && same; i++) {
            int a = few[i], b = back.px[i];
            if ((a >>> 24) == 0) same = (b >>> 24) == 0; else same = a == b;
        }
        check("volta identica (alpha incluido; transparente total vale 0)", same, true);
        // assinatura PNG
        check("assinatura PNG", (o.png[0] & 255) == 0x89 && o.png[1] == 'P' && o.png[2] == 'N' && o.png[3] == 'G', true);

        // gradiente com milhares de cores: quantiza em ate 256 e fica perto
        int gw = 128, gh = 96;
        int[] grad = new int[gw * gh];
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) grad[y * gw + x] = 0xFF000000 | ((x * 2) << 16) | ((y * 2) << 8) | ((x + y) & 255);
        Png8.Out g = Png8.encode(Png8.of(grad, gw, gh));
        check("gradiente: reduzido a ate 256 cores", !g.lossless && g.colors <= 256 && g.colors > 32, true);
        Png8.Img gb = Png8.decode(g.png);
        double err = 0;
        for (int i = 0; i < grad.length; i++) {
            int a = grad[i], b = gb.px[i];
            err += Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) + Math.abs((a & 255) - (b & 255));
        }
        check("erro medio por canal pequeno (< 8)", err / (grad.length * 3.0) < 8.0, true);

        // folha de 32 bits (cru) x PNG de 8 bits: bem menor
        int raw = gw * gh * 4;
        check("PNG indexado menor que o ARGB cru", g.png.length < raw / 2, true);

        // alpha parcial vira tRNS e volta
        int[] soft = new int[16 * 16];
        for (int i = 0; i < soft.length; i++) soft[i] = (i % 4) * 60 << 24 | 0x336699;
        Png8.Img sb = Png8.decode(Png8.encode(Png8.of(soft, 16, 16)).png);
        boolean softOk = true;
        for (int i = 0; i < soft.length; i++) if ((soft[i] >>> 24) != (sb.px[i] >>> 24)) softOk = false;
        check("alpha parcial preservado", softOk, true);
        System.out.println("Png8Test fails=" + fails);
    }
}
