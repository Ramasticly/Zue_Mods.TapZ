package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Camera livre da previa (a mesma da principal): enquadramento inicial, mover, zoom no foco e limites. */
public class PreviewCamTest {
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-3; }

    public static void main(String[] args) throws Exception {
        PreviewCam c = new PreviewCam();
        c.recenter(1080f, 1080f, 2.75f);
        check("enquadramento: centro da largura, 55% da altura, escala = densidade", c.originX + "," + c.originY + "," + c.scale, "540.0,594.0,2.75");
        c.recenter(400f, 300f, 0.5f);
        check("densidade baixa: escala minima 1", c.scale, 1f);

        c.recenter(1000f, 1000f, 2f);
        c.pan(30f, -20f);
        check("mover soma o deslocamento a origem", c.originX + "," + c.originY, "530.0,530.0");

        c.recenter(1000f, 1000f, 2f);
        float wx = (700f - c.originX) / c.scale, wy = (300f - c.originY) / c.scale;      // ponto do mundo sob o dedo
        c.zoomAt(700f, 300f, 2f);
        check("zoom dobra a escala", c.scale, 4f);
        check("o ponto sob o foco continua no mesmo lugar da tela", near(c.originX + wx * c.scale, 700f) && near(c.originY + wy * c.scale, 300f), true);
        c.zoomAt(700f, 300f, 0.5f);
        check("zoom de ida e volta devolve a origem", near(c.originX, 500f) && near(c.originY, 550f) && near(c.scale, 2f), true);

        c.zoomAt(10f, 10f, 1000f);
        check("limite maximo 24", c.scale, 24f);
        c.zoomAt(10f, 10f, 0.00001f);
        check("limite minimo 0,5", c.scale, 0.5f);
        check("limites iguais aos da previa principal", PreviewCam.MIN_SCALE + "," + PreviewCam.MAX_SCALE, "0.5,24.0");
    }
}
