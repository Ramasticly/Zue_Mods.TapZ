package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Camera livre da previa (a mesma da principal): enquadramento inicial, mover, zoom no foco e limites. */
public class PreviewCamTest {
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-3; }

    public static void main(String[] args) throws Exception {
        PreviewCam c = new PreviewCam();
        c.recenter(1080f, 1080f, 2.75f);
        check("enquadramento: centro da largura, 55% da altura, escala = densidade", c.originX + "," + c.originY + "," + c.scale, "540.0,594.0,2.75");
        c.recenter(400f, 300f, 0.5f);
        check("densidade baixa: escala minima 1", c.scale, 1f);

        c.recenter(1000f, 1000f, 2f);
        c.pan(30f, -20f);
        check("mover soma o deslocamento a origem", c.originX + "," + c.originY, "530.0,530.0");

        c.recenter(1000f, 1000f, 2f);
        float wx = (700f - c.originX) / c.scale, wy = (300f - c.originY) / c.scale;      // ponto do mundo sob o dedo
        c.zoomAt(700f, 300f, 2f);
        check("zoom dobra a escala", c.scale, 4f);
        check("o ponto sob o foco continua no mesmo lugar da tela", near(c.originX + wx * c.scale, 700f) && near(c.originY + wy * c.scale, 300f), true);
        c.zoomAt(700f, 300f, 0.5f);
        check("zoom de ida e volta devolve a origem", near(c.originX, 500f) && near(c.originY, 550f) && near(c.scale, 2f), true);

        c.zoomAt(10f, 10f, 1000f);
        check("limite maximo 24", c.scale, 24f);
        c.zoomAt(10f, 10f, 0.00001f);
        check("limite minimo 0,5", c.scale, 0.5f);
        check("limites iguais aos da previa principal", PreviewCam.MIN_SCALE + "," + PreviewCam.MAX_SCALE, "0.5,24.0");

        // enquadramento: sprites pequenas aumentam, grandes diminuem, sempre centralizadas
        PreviewCam f = new PreviewCam();
        f.fitBox(1000f, 1000f, 0, 0, 40, 60, 0.25f);
        check("sprite pequena (40x60): cabe com 25% de folga pela altura (1000/75 = 13,33x)", near(f.scale, 13.3333), true);
        check("o centro da caixa vai para o centro da vista", near(f.originX + 20 * f.scale, 500) && near(f.originY + 30 * f.scale, 500), true);
        f.minScale = 0.02f;          // como a previa do Editar Frame
        f.fitBox(1000f, 1000f, 0, 0, 2000, 1000, 0.25f);
        check("sprite enorme (2000x1000): diminui (0,4x) e fica inteira na vista", near(f.scale, 0.4) && 2000 * f.scale <= 1000f / 1.25f + 1e-3, true);
        f.zoomAt(500f, 500f, 0.01f);
        check("a pinca nao sobe de volta para 0,5: o minimo da camera e 0,02", f.scale, 0.02f);
        f.minScale = PreviewCam.MIN_SCALE;
        f.fitBox(1000f, 1000f, 0, 0, 100000, 100000, 0.25f);
        check("limite minimo da escala", f.scale, PreviewCam.MIN_SCALE);
        f.fitBox(1000f, 1000f, 0, 0, 2, 2, 0.25f);
        check("sprite minuscula: limite maximo da escala", f.scale, PreviewCam.MAX_SCALE);
        f.fitBox(800f, 400f, -50, -100, 50, 0, 0.25f);
        check("caixa fora da ancora (-50..50, -100..0) tambem centraliza e a altura manda (400/125 = 3,2x)", near(f.scale, 3.2) && near(f.originX, 400) && near(f.originY, 200 + 50 * 3.2), true);
        f.fitBox(500f, 500f, 10, 10, 10, 10, 0.25f);
        check("caixa degenerada nao quebra (escala dentro dos limites)", f.scale >= PreviewCam.MIN_SCALE && f.scale <= PreviewCam.MAX_SCALE, true);
    }
}
