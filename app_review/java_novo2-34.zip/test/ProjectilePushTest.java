package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.Set;

/** Projetil empurra o oponente: escolha do slot (vazio, sem uso, atual com confirmacao, nenhum), velocidades copiadas do projetil e flags do atacante fora do projetil. */
public class ProjectilePushTest {
    static byte[] row() { return react(new int[]{6, 6, 3, 10, 5, 0, 0, 10, 5, 0, 0, 0, 0, 0}, new int[]{4, 4, 4, 20, 0, 0, 0, 20, 0, 0, 0, 7, 0, 0}); }

    static CharData withSlots(int filled) throws Exception {
        byte[][] rs = new byte[20][];
        for (int i = 0; i < filled; i++) rs[i] = react(new int[]{6, 6, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});
        return chr(move(new int[]{0, 4}, new int[]{2, 3}), rs);
    }

    public static void main(String[] args) throws Exception {
        // ---- escolha do slot
        CharData few = withSlots(3);
        Dac dac = dac(new A[]{
                new A().mpt(new M().time(3).img(1).hit(2, 0, 0, 10, 10).opt1(30)),            // usa o slot 0
                new A().mpt(new M().time(3).img(1).hit(2, 0, 0, 10, 10).opt1(31 + 50))        // usa o slot 1 (grupo 1)
        });
        Set<Integer> used = ProjectilePush.used(dac, few);
        check("slots usados pelas hitboxes dos ANOs (0 e 1; o 2 nao)", used.contains(0) + ":" + used.contains(1) + ":" + used.contains(2), "true:true:false");
        ProjectilePush.Choice c = ProjectilePush.chooseSlot(few, used, 30);
        check("ha slot vazio: o primeiro (3)", c.kind + ":" + c.slot, ProjectilePush.EMPTY + ":3");

        CharData full = withSlots(20);
        c = ProjectilePush.chooseSlot(full, used, 30);
        check("sem vazio: o primeiro que nada usa (2)", c.kind + ":" + c.slot, ProjectilePush.UNUSED + ":2");
        java.util.Set<Integer> all = new java.util.HashSet<Integer>();
        for (int i = 0; i < 20; i++) all.add(Integer.valueOf(i));
        c = ProjectilePush.chooseSlot(full, all, 35);
        check("tudo em uso e a atual e do personagem: edita a atual (5), pede confirmacao", c.kind + ":" + c.slot, ProjectilePush.CURRENT + ":5");
        c = ProjectilePush.chooseSlot(full, all, 4);
        check("tudo em uso e a atual e do jogo: nenhum", c.kind + ":" + c.slot, ProjectilePush.NONE + ":-1");
        java.util.Set<Integer> notCur = new java.util.HashSet<Integer>(all);
        notCur.remove(Integer.valueOf(7));
        c = ProjectilePush.chooseSlot(full, notCur, 37);
        check("o slot da propria hitbox atual nao conta como 'sem uso'", c.kind + ":" + c.slot, ProjectilePush.CURRENT + ":7");

        // COMP de outra tabela e reacao de choque tambem contam como uso
        byte[][] rs = new byte[20][];
        for (int i = 0; i < 20; i++) rs[i] = react(new int[]{6, 6, 3, 0, 0, 0, 0, 0, 0, 0, 0, i == 0 ? 33 : 0, 0, 0});
        Set<Integer> u2 = ProjectilePush.used(dac(new A[]{new A().mpt(new M().time(3).img(1))}), chr(move(new int[]{0, 4}, new int[]{2, 3}), rs));
        check("COMP 33 de outra tabela conta como uso do slot 3", u2.contains(3), true);

        // ---- velocidades
        ReactionTable t = new ReactionTable(row(), 0);
        boolean cut = ProjectilePush.apply(t, 3.0, -1.5, 0.2, 0.0);
        check("passo 0: vx 30, vy -15, accel x 2, y 0 (0,1 px) no chao e no ar", t.s8(0, 3) + ":" + t.s8(0, 4) + ":" + t.s8(0, 5) + ":" + t.s8(0, 6) + "|" + t.s8(0, 7) + ":" + t.s8(0, 8) + ":" + t.s8(0, 9) + ":" + t.s8(0, 10), "30:-15:2:0|30:-15:2:0");
        check("passos seguintes mantem (-1)", t.s8(1, 3) + ":" + t.s8(1, 4) + ":" + t.s8(1, 5) + ":" + t.s8(1, 6) + "|" + t.s8(1, 7), "-1:-1:-1:-1|-1");
        check("sem corte", cut, false);
        check("ANO, duracao e COMP do passo 1 ficam como estavam", t.s8(0, 2) + ":" + t.u8(0, 0) + ":" + t.u8(1, 11) + ":" + t.s8(1, 2), "3:6:7:4");
        ReactionTable t2 = new ReactionTable(row(), 0);
        check("velocidade acima de 12,7 px/tick e cortada em 127 e avisa", ProjectilePush.apply(t2, 20.0, 0, 0, 0) + ":" + t2.s8(0, 3), "true:127");
        check("-1 e -2 sao codigos: o valor evita (vx -0,1 vira 0; -0,2 vira -3)", ProjectilePush.units(-0.1, new boolean[1]) + ":" + ProjectilePush.units(-0.2, new boolean[1]), "0:-3");
        check("projetil parado nao tem o que copiar", ProjectilePush.still(0, 0, 0, 0) + ":" + ProjectilePush.still(0.5, 0, 0, 0), "true:false");

        // ---- flags que usam o atacante como base
        CharData.Move proj = new CharData.Move();
        proj.generic = true;
        proj.rootKind = CharData.Move.ROOT_PROJ;
        java.util.HashSet<Integer> pf = new java.util.HashSet<Integer>();
        for (int fl : ObjModel.actionFlagsFor(proj, 100)) pf.add(Integer.valueOf(fl));
        check("ANO de projetil: sem puxar oponente (40), teleportar (39), teleportar atras, auto-dano (32), 26, 28, 37, 38",
                pf.contains(40) + ":" + pf.contains(39) + ":" + pf.contains(ObjModel.ACT_BEHIND) + ":" + pf.contains(32) + ":" + pf.contains(26) + ":" + pf.contains(28) + ":" + pf.contains(37) + ":" + pf.contains(38), "false:false:false:false:false:false:false:false");
        check("ANO de projetil: ficam tremor, cena, zoom, poeira", pf.contains(3) + ":" + pf.contains(20) + ":" + pf.contains(30) + ":" + pf.contains(ObjModel.VF_DUST + 1), "true:true:true:true");
        CharData.Move norm = new CharData.Move();
        java.util.HashSet<Integer> nf = new java.util.HashSet<Integer>();
        for (int fl : ObjModel.actionFlagsFor(norm, 0)) nf.add(Integer.valueOf(fl));
        check("ANO normal (do atacante): todas continuam", nf.contains(40) + ":" + nf.contains(39) + ":" + nf.contains(32) + ":" + nf.contains(26), "true:true:true:true");
        check("usesAttackerBase", ObjModel.usesAttackerBase(40) + ":" + ObjModel.usesAttackerBase(20) + ":" + ObjModel.usesAttackerBase(ObjModel.ACT_BEHIND), "true:false:true");
        System.out.println("ProjectilePushTest fails=" + fails);
    }
}
