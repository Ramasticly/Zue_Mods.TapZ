package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Previa da reacao: a camera segue o oponente que voa e a voz da reacao (coluna 13) sai do drainSounds da simulacao. */
public class ReactionCameraTest {
    public static void main(String[] args) throws Exception {
        float viewH = 250f;
        // no chao: sem deslocamento
        check("no chao a camera nao sobe", ReactionCamera.targetY(0, viewH), 0f);
        check("ate ~90 px de altura o corpo cabe: sem deslocamento", ReactionCamera.targetY(-60, viewH), 0f);
        check("mais alto: o cenario desce o que falta", ReactionCamera.targetY(-300, viewH), 300f + ReactionCamera.BODY + ReactionCamera.MARGIN - 200f);
        check("x segue o oponente mais o lead", ReactionCamera.targetX(400, 30), 430f);
        check("suavizacao anda uma fracao", ReactionCamera.ease(0, 100), 25f);
        check("suavizacao encaixa quando chega perto", ReactionCamera.ease(99.9f, 100), 100f);

        // lancamento: sobe a 400 px e cai, indo para a direita; a camera tem que manter o corpo na area
        ReactionCamera cam = new ReactionCamera(30);
        cam.follow(100, 0, viewH, true);
        check("primeiro quadro: centrada no oponente", cam.x, 130f);
        boolean always = true, followedX = true;
        float maxY = 0, maxLag = 0;
        for (int t = 0; t < 120; t++) {
            float ox = 100 + t * 6f, oy = -(400f * 4 * t * (120 - t) / (120f * 120f));
            cam.follow(ox, oy, viewH, false);
            maxY = Math.max(maxY, cam.y);
            maxLag = Math.max(maxLag, Math.abs(cam.x - (ox + 30)));
            // tolera a defasagem da suavizacao: o corpo inteiro (100 px) cabe com folga na area de 250
            if (!(oy - ReactionCamera.BODY >= -ReactionCamera.GROUND_FRAC * viewH - cam.y - 60 && oy <= (1 - ReactionCamera.GROUND_FRAC) * viewH - cam.y + 60)) always = false;
        }
        check("lancamento: o corpo fica na area visivel o tempo todo", always, true);
        check("lancamento: o cenario desceu bastante no topo da trajetoria", maxY > 250f, true);
        check("lancamento: x defasa pouco (suavizacao)", maxLag < 30f, true);
        // depois de pousar volta ao chao
        for (int i = 0; i < 40; i++) cam.follow(820, 0, viewH, false);
        check("pousou: a camera volta ao chao e ao x", cam.y + ":" + (int) cam.x, "0.0:850");
        // snap (buscar na linha do tempo) vai direto
        cam.follow(0, -300, viewH, true);
        check("snap: direto ao alvo e o corpo cabe", cam.y == ReactionCamera.targetY(-300, viewH) && cam.contains(-300, viewH), true);

        // ---- voz: coluna 13 da tabela do personagem
        byte[][] rs = new byte[2][];
        rs[0] = react(new int[]{4, 4, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 5});        // voz 5 = se_4 comum
        rs[1] = react(new int[]{4, 4, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0});        // sem voz
        BattleSim v = ReactionTraceTest.sim(rs, 0);
        v.forceHit(30);
        v.drainSounds();
        boolean heard = false;
        for (int i = 0; i < 4 && !heard; i++) {
            v.step();
            for (BattleSim.Snd s : v.drainSounds()) if (s.common && s.id == 4) heard = true;
        }
        check("a voz da reacao (coluna 13 = 5) sai do drainSounds como se_4", heard, true);
        BattleSim q = ReactionTraceTest.sim(rs, 0);
        q.forceHit(31);
        q.drainSounds();
        boolean other = false;
        for (int i = 0; i < 4; i++) {
            q.step();
            for (BattleSim.Snd s : q.drainSounds()) if (s.id == 4 && s.common) other = true;
        }
        check("reacao sem voz nao toca a voz", other, false);
        System.out.println("ReactionCameraTest fails=" + fails);
    }
}
