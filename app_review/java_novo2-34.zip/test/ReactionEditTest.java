package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Arrastar a duracao de um passo na timeline de reacoes (regras puras). */
public class ReactionEditTest {
    public static void main(String[] args) throws Exception {
        ReactionTable t = new ReactionTable(react(new int[]{4, 9, 3}, new int[]{6, 255, 4}), 0);
        check("coluna de duracao: chao 0, ar 1", ReactionEdit.durColumn(false) + ":" + ReactionEdit.durColumn(true), "0:1");
        check("passo normal pode ser arrastado nos dois cenarios", ReactionEdit.canResize(t, 0, false) + ":" + ReactionEdit.canResize(t, 0, true), "true:true");
        check("255 (ate pousar) no ar trava a alca; no chao o mesmo passo (6) destrava", ReactionEdit.canResize(t, 1, true) + ":" + ReactionEdit.canResize(t, 1, false), "false:true");
        check("passo inexistente", ReactionEdit.canResize(t, 5, false) + ":" + ReactionEdit.canResize(t, -1, false) + ":" + ReactionEdit.canResize(null, 0, false), "false:false:false");

        // arrastar: 5 px/tick
        check("arrastar 10 px = +2 ticks", ReactionEdit.dragged(4, 10f, 5f), 6);
        check("arrastar para a esquerda reduz (-7,6 px = -1,52 tick, arredonda para -2)", ReactionEdit.dragged(4, -7.6f, 5f), 2);
        check("arredonda para o tick mais proximo", ReactionEdit.dragged(4, 2.4f, 5f) + ":" + ReactionEdit.dragged(4, 2.6f, 5f), "4:5");
        check("minimo 1 tick", ReactionEdit.dragged(4, -500f, 5f), 1);
        check("maximo 254 (255 e o ate pousar)", ReactionEdit.dragged(250, 500f, 5f), 254);
        check("zoom minimo nao divide por zero", ReactionEdit.dragged(4, 1f, 0f) >= 1, true);

        // gravacao
        int[] g = ReactionEdit.resize(t, 0, false, 12);
        int[] a = ReactionEdit.resize(t, 0, true, 300);
        check("resize no chao grava a coluna 0", g[0] + ":" + g[1], "0:12");
        check("resize no ar grava a coluna 1, limitado a 254", a[0] + ":" + a[1], "1:254");
        check("resize de passo travado nao grava", ReactionEdit.resize(t, 1, true, 9) == null, true);
        check("resize para 0 vira 1", ReactionEdit.resize(t, 0, false, 0)[1], 1);
        t.set(0, g[0], g[1]);
        check("aplicar na tabela", t.u8(0, 0) + ":" + t.u8(0, 1), "12:9");

        System.out.println("ReactionEditTest fails=" + BattleTest.fails);
    }
}
