package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Arrastar a duracao de um passo na timeline de reacoes (regras puras). */
public class ReactionEditTest {
    public static void main(String[] args) throws Exception {
        ReactionTable t = new ReactionTable(react(new int[]{4, 9, 3}, new int[]{6, 255, 4}), 0);
        check("coluna de duracao: chao 0, ar 1", ReactionEdit.durColumn(false) + ":" + ReactionEdit.durColumn(true), "0:1");
        check("passo normal pode ser arrastado nos dois cenarios", ReactionEdit.canResize(t, 0, false) + ":" + ReactionEdit.canResize(t, 0, true), "true:true");
        check("255 (ate pousar) no ar trava a alca; no chao o mesmo passo (6) destrava", ReactionEdit.canResize(t, 1, true) + ":" + ReactionEdit.canResize(t, 1, false), "false:true");
        check("passo inexistente", ReactionEdit.canResize(t, 5, false) + ":" + ReactionEdit.canResize(t, -1, false) + ":" + ReactionEdit.canResize(null, 0, false), "false:false:false");

        // arrastar: 5 px/tick
        check("arrastar 10 px = +2 ticks", ReactionEdit.dragged(4, 10f, 5f), 6);
        check("arrastar para a esquerda reduz (-7,6 px = -1,52 tick, arredonda para -2)", ReactionEdit.dragged(4, -7.6f, 5f), 2);
        check("arredonda para o tick mais proximo", ReactionEdit.dragged(4, 2.4f, 5f) + ":" + ReactionEdit.dragged(4, 2.6f, 5f), "4:5");
        check("minimo 1 tick", ReactionEdit.dragged(4, -500f, 5f), 1);
        check("maximo 254 (255 e o ate pousar)", ReactionEdit.dragged(250, 500f, 5f), 254);
        check("zoom minimo nao divide por zero", ReactionEdit.dragged(4, 1f, 0f) >= 1, true);

        // gravacao
        int[] g = ReactionEdit.resize(t, 0, false, 12);
        int[] a = ReactionEdit.resize(t, 0, true, 300);
        check("resize no chao grava a coluna 0", g[0] + ":" + g[1], "0:12");
        check("resize no ar grava a coluna 1, limitado a 254", a[0] + ":" + a[1], "1:254");
        check("resize de passo travado nao grava", ReactionEdit.resize(t, 1, true, 9) == null, true);
        check("resize para 0 vira 1", ReactionEdit.resize(t, 0, false, 0)[1], 1);
        t.set(0, g[0], g[1]);
        check("aplicar na tabela", t.u8(0, 0) + ":" + t.u8(0, 1), "12:9");


        // ---- corridas da faixa SPEED
        // velocidades (chao): p0 (10,0) | p1 (-1,-1) | p2 (-1,-1) | p3 (20,0) | p4 (-1,-1)
        ReactionTable rt = new ReactionTable(react(
                new int[]{4, 4, 1, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}, new int[]{4, 4, 2, -1, -1, 0, 0, -1, -1, 0, 0, 0, 0, 0},
                new int[]{4, 4, 3, -1, -1, 0, 0, -1, -1, 0, 0, 0, 0, 0}, new int[]{4, 4, 4, 20, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0},
                new int[]{4, 4, 5, -1, -1, 0, 0, -1, -1, 0, 0, 0, 0, 0}), 0);
        java.util.List<int[]> rs = ReactionRuns.runs(rt, false);
        check("corridas: 2 (passos 0-2 e 3-4)", rs.size() + ":" + rs.get(0)[0] + "-" + rs.get(0)[1] + ":" + rs.get(1)[0] + "-" + rs.get(1)[1], "2:0-3:3-5");
        check("corrida do passo 2 = 0; do passo 4 = 1", ReactionRuns.runOf(rt, false, 2) + ":" + ReactionRuns.runOf(rt, false, 4), "0:1");
        ReactionTable lead = new ReactionTable(react(new int[]{4, 4, 1, -1, -1, 0, 0, -1, -1, 0, 0, 0, 0, 0}, new int[]{4, 4, 2, 5, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0}), 0);
        check("passos iniciais que so mantem nao pertencem a corrida", ReactionRuns.runs(lead, false).size() + ":" + ReactionRuns.runOf(lead, false, 0), "1:-1");
        check("metade (-2) conta como velocidade propria", ReactionRuns.keeps(new ReactionTable(react(new int[]{4, 4, 1, -2, -1, 0, 0, -1, -1, 0, 0, 0, 0, 0}), 0), 0, false), false);

        ReactionTable ext = rt.copy();
        check("estender a corrida 0 ate o passo 4: a fronteira anda e a proxima mantem a velocidade 20", ReactionRuns.setRunEnd(ext, false, 0, 4)
                && ext.s8(3, 3) == -1 && ext.s8(4, 3) == 20 && ReactionRuns.runs(ext, false).get(1)[0] == 4, true);
        ReactionTable shr = rt.copy();
        check("encurtar a corrida 0 para 2 passos: o passo 2 passa a ter a velocidade 20", ReactionRuns.setRunEnd(shr, false, 0, 2)
                && shr.s8(2, 3) == 20 && shr.s8(3, 3) == -1 && ReactionRuns.runs(shr, false).size() == 2 && ReactionRuns.runs(shr, false).get(1)[0] == 2, true);
        ReactionTable lim = rt.copy();
        check("nao engole a proxima corrida (maximo: ate o ultimo passo dela)", ReactionRuns.setRunEnd(lim, false, 0, 99) && ReactionRuns.runs(lim, false).get(1)[0] == 4, true);
        ReactionTable one = rt.copy();
        ReactionRuns.setRunEnd(one, false, 0, 0);
        check("nao encolhe abaixo de 1 passo", ReactionRuns.runs(one, false).get(0)[1], 1);
        ReactionTable last = rt.copy();
        check("encurtar a ultima corrida abre uma corrida parada (0,0)", ReactionRuns.setRunEnd(last, false, 1, 4) && last.s8(4, 3) == 0 && last.s8(4, 4) == 0 && ReactionRuns.runs(last, false).size() == 3, true);
        check("a ultima corrida nao estende alem da tabela", ReactionRuns.setRunEnd(rt.copy(), false, 1, 9), false);
        ReactionTable air = rt.copy();
        ReactionRuns.setRunEnd(air, true, 0, 4);
        check("o ar tem as proprias corridas (colunas 7 e 8) e nao mexe no chao", air.s8(4, 7) == 20 && air.s8(4, 3) == -1 && ReactionRuns.runs(air, false).get(1)[0] == 3, true);
        ReactionTable rm = rt.copy();
        check("tirar a velocidade da corrida 1: o passo 3 volta a manter e a corrida some", ReactionRuns.removeRun(rm, false, 1) && ReactionRuns.runs(rm, false).size() == 1 && ReactionRuns.runs(rm, false).get(0)[1] == 5, true);
        ReactionTable st = rt.copy();
        check("criar corrida no passo que so mantinha: velocidade 0,0", ReactionRuns.startRun(st, false, 1) && st.s8(1, 3) == 0 && ReactionRuns.runs(st, false).size() == 3, true);
        check("criar corrida em passo que ja tem velocidade: nao faz nada", ReactionRuns.startRun(rt.copy(), false, 0), false);

        // ---- DIVIDIR
        ReactionTable sp = new ReactionTable(react(new int[]{8, 10, 7, 10, 0, 2, 0, 10, 0, 2, 0, 3, 2, 9}), 0);
        check("dividir o passo de 8 ticks no 3: 3 + 5, a duracao do ar (10) na mesma proporcao", ReactionEdit.split(sp, 0, false, 3) && sp.rows == 2
                && sp.u8(0, 0) == 3 && sp.u8(1, 0) == 5 && sp.u8(0, 1) + sp.u8(1, 1) == 10 && sp.u8(0, 1) == 4, true);
        check("2o passo: mesmo ANO, velocidade mantem, aceleracao igual, voz so no 1o", sp.s8(1, 2) + ":" + sp.s8(1, 3) + ":" + sp.s8(1, 4) + ":" + sp.s8(1, 5) + ":" + sp.s8(1, 13) + ":" + sp.s8(0, 13), "7:-1:-1:2:0:9");
        check("parede e proxima reacao ficam nos dois", sp.u8(0, 12) + ":" + sp.u8(1, 12) + ":" + sp.u8(0, 11) + ":" + sp.u8(1, 11), "2:2:3:3");
        check("dividir fora do passo nao faz nada", !ReactionEdit.split(sp.copy(), 0, false, 0) && !ReactionEdit.split(sp.copy(), 0, false, 3) && !ReactionEdit.split(sp.copy(), 5, false, 1), true);
        ReactionTable sa = new ReactionTable(react(new int[]{6, 255, 7, 0, 0, 0, 0, 0, 40, 0, 0, 0, 0, 0}), 0);
        check("ar com 'ate pousar' (255): o 1o ganha k e o 2o continua ate pousar", ReactionEdit.split(sa, 0, true, 10) && sa.u8(0, 1) == 10 && sa.u8(1, 1) == 255 && sa.u8(0, 0) + sa.u8(1, 0) == 6, true);
        check("dividir um passo de 1 tick nao existe", ReactionEdit.split(new ReactionTable(react(new int[]{1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}), 0), 0, false, 1), false);

        System.out.println("ReactionEditTest fails=" + BattleTest.fails);
    }
}
