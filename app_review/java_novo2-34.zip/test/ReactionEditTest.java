package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Arrastar a duracao de um passo na timeline de reacoes (regras puras). */
public class ReactionEditTest {
    public static void main(String[] args) throws Exception {
        ReactionTable t = new ReactionTable(react(new int[]{4, 9, 3}, new int[]{6, 255, 4}), 0);
        check("coluna de duracao: chao 0, ar 1", ReactionEdit.durColumn(false) + ":" + ReactionEdit.durColumn(true), "0:1");
        check("passo normal pode ser arrastado nos dois cenarios", ReactionEdit.canResize(t, 0, false) + ":" + ReactionEdit.canResize(t, 0, true), "true:true");
        check("255 (ate pousar) no ar trava a alca; no chao o mesmo passo (6) destrava", ReactionEdit.canResize(t, 1, true) + ":" + ReactionEdit.canResize(t, 1, false), "false:true");
        check("passo inexistente", ReactionEdit.canResize(t, 5, false) + ":" + ReactionEdit.canResize(t, -1, false) + ":" + ReactionEdit.canResize(null, 0, false), "false:false:false");

        // arrastar: 5 px/tick
        check("arrastar 10 px = +2 ticks", ReactionEdit.dragged(4, 10f, 5f), 6);
        check("arrastar para a esquerda reduz (-7,6 px = -1,52 tick, arredonda para -2)", ReactionEdit.dragged(4, -7.6f, 5f), 2);
        check("arredonda para o tick mais proximo", ReactionEdit.dragged(4, 2.4f, 5f) + ":" + ReactionEdit.dragged(4, 2.6f, 5f), "4:5");
        check("minimo 1 tick", ReactionEdit.dragged(4, -500f, 5f), 1);
        check("maximo 254 (255 e o ate pousar)", ReactionEdit.dragged(250, 500f, 5f), 254);
        check("zoom minimo nao divide por zero", ReactionEdit.dragged(4, 1f, 0f) >= 1, true);

        // gravacao
        int[] g = ReactionEdit.resize(t, 0, false, 12);
        int[] a = ReactionEdit.resize(t, 0, true, 300);
        check("resize no chao grava a coluna 0", g[0] + ":" + g[1], "0:12");
        check("resize no ar grava a coluna 1, limitado a 254", a[0] + ":" + a[1], "1:254");
        check("resize de passo travado nao grava", ReactionEdit.resize(t, 1, true, 9) == null, true);
        check("resize para 0 vira 1", ReactionEdit.resize(t, 0, false, 0)[1], 1);
        t.set(0, g[0], g[1]);
        check("aplicar na tabela", t.u8(0, 0) + ":" + t.u8(0, 1), "12:9");


        // ---- DIVIDIR
        ReactionTable sp = new ReactionTable(react(new int[]{8, 10, 7, 10, 0, 2, 0, 10, 0, 2, 0, 3, 2, 9}), 0);
        check("dividir o passo de 8 ticks no 3: 3 + 5, a duracao do ar (10) na mesma proporcao", ReactionEdit.split(sp, 0, false, 3) && sp.rows == 2
                && sp.u8(0, 0) == 3 && sp.u8(1, 0) == 5 && sp.u8(0, 1) + sp.u8(1, 1) == 10 && sp.u8(0, 1) == 4, true);
        check("2o passo: mesmo ANO, velocidade mantem, aceleracao igual, voz so no 1o", sp.s8(1, 2) + ":" + sp.s8(1, 3) + ":" + sp.s8(1, 4) + ":" + sp.s8(1, 5) + ":" + sp.s8(1, 13) + ":" + sp.s8(0, 13), "7:-1:-1:2:0:9");
        check("parede e proxima reacao ficam nos dois", sp.u8(0, 12) + ":" + sp.u8(1, 12) + ":" + sp.u8(0, 11) + ":" + sp.u8(1, 11), "2:2:3:3");
        check("dividir fora do passo nao faz nada", !ReactionEdit.split(sp.copy(), 0, false, 0) && !ReactionEdit.split(sp.copy(), 0, false, 3) && !ReactionEdit.split(sp.copy(), 5, false, 1), true);
        ReactionTable sa = new ReactionTable(react(new int[]{6, 255, 7, 0, 0, 0, 0, 0, 40, 0, 0, 0, 0, 0}), 0);
        check("ar com 'ate pousar' (255): o 1o ganha k e o 2o continua ate pousar", ReactionEdit.split(sa, 0, true, 10) && sa.u8(0, 1) == 10 && sa.u8(1, 1) == 255 && sa.u8(0, 0) + sa.u8(1, 0) == 6, true);
        check("dividir um passo de 1 tick nao existe", ReactionEdit.split(new ReactionTable(react(new int[]{1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}), 0), 0, false, 1), false);

        System.out.println("ReactionEditTest fails=" + BattleTest.fails);
    }
}
