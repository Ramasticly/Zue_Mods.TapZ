package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Previa da reacao no golpe real: acha o tick do hit, atacante preso no frame da hitbox e trace "primed" (tick 0 = hit). */
public class ReactionHitTest {
    static BattleSim sim(boolean hold, int holdType) throws Exception {
        A[] atk = new A[60];
        for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(5).img(1));
        // ANO 40: aproxima 2 ticks, frame 1 = hitbox (OPT 1 = 30 = reacao 0 do personagem), depois mais dois frames
        atk[40] = new A().mpt(new M().time(2).img(1)).mpt(new M().time(3).img(1).hit(2, 20, -40, 250, 20).opt1(30)).mpt(new M().time(4).img(1)).mpt(new M().time(30).img(1));
        atk[41] = new A().mpt(new M().time(50).img(1));
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(3).img(1).hit(1, -10, -60, 20, 60)).mpt(new M().time(3).img(1));
        byte[][] rs = new byte[1][];
        rs[0] = react(new int[]{6, 6, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}, new int[]{6, 6, 4, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0});
        // golpe 0: ANIM_INICIAL 40, SEQ (chao) 41
        CharData ch = chr(move(new int[]{2, 40}, new int[]{10, 41}), rs);
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}) });
        BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, 40, 0, 0);
        if (hold) s.setHoldAttackerAtHit(true, holdType, true);
        return s;
    }

    public static void main(String[] args) throws Exception {
        BattleSim.defend = false;
        int k = ReactionHit.ticksBeforeHit(sim(false, -1), 0, true, ReactionHit.MAX_TICKS);
        check("o golpe acerta a reacao 0 do personagem em poucos ticks", k >= 0 && k < 30, true);
        check("reacao que o golpe nunca usa: -1", ReactionHit.ticksBeforeHit(sim(false, -1), 5, true, 300), -1);
        check("mesmo numero na tabela do jogo e outra coisa (tipo 0 do jogo): -1", ReactionHit.ticksBeforeHit(sim(false, -1), 0, false, 300), -1);

        // antes do tick do hit o defensor ainda nao esta em dano; o proximo step aplica o hit
        BattleSim s = sim(true, 0);
        for (int i = 0; i < k; i++) s.step();
        check("logo antes do hit: sem dano e o atacante ainda no ANO 40", s.defenderInDamage() + ":" + s.attacker().root().ano.index, "false:40");
        s.step();
        check("o step seguinte aplica o hit", s.defenderInDamage(), true);
        int patAtHit = s.attacker().root().pat;
        for (int i = 0; i < 60; i++) s.step();
        check("hold: 60 ticks depois o atacante segue no mesmo frame da hitbox do ANO 40 (nada de SEQ/ANO 41)", s.attacker().root().ano.index + ":" + (s.attacker().root().pat == patAtHit) + ":" + (patAtHit == 1), "40:true:true");
        check("e o oponente cumpriu a reacao (acabou)", s.defenderInDamage(), false);

        BattleSim free = sim(false, -1);
        for (int i = 0; i < k + 1 + 60; i++) free.step();
        check("sem hold o atacante continua: ja saiu do frame (SEQ/fim)", free.attacker().root().ano.index != 40 || free.attacker().root().pat != 1, true);

        // hold so vale para a reacao pedida
        BattleSim other = sim(true, 7);
        for (int i = 0; i < k + 1 + 60; i++) other.step();
        check("hold de outra reacao (7) nao segura o atacante neste hit", other.attacker().root().ano.index != 40 || other.attacker().root().pat != 1, true);

        // trace primed: tick 0 = tick do hit
        BattleSim p = sim(true, 0);
        for (int i = 0; i < k; i++) p.step();
        ReactionTrace tr = ReactionTrace.recordPrimed(p, 420);
        check("trace primed: comeca na reacao 0 do personagem, passo 0, tempo 0, motivo inicio", tr.ticks.get(0).charSrc + ":" + tr.ticks.get(0).type + ":" + tr.ticks.get(0).row + ":" + tr.ticks.get(0).time + ":" + tr.segments.get(0).reason, "true:0:0:0:" + BattleSim.R_START);
        check("trace primed: 2 passos e a reacao acaba sozinha", tr.segments.size() >= 2 && tr.ended, true);
        boolean hs = false;
        for (BattleSim.DamageTick t : tr.ticks) hs |= t.hitstop;
        check("o hitstop do golpe real aparece no trace (a reacao so anda depois dele)", hs, true);
        check("trace primed: o hold manteve o atacante no frame da hitbox", p.attacker().root().ano.index + ":" + p.attacker().root().pat, "40:1");
        System.out.println("ReactionHitTest fails=" + fails);
    }
}
