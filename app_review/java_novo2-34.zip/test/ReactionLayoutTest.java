package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Geometria da timeline de reacoes (mesmas medidas da principal) e o hit-test pelas mesmas linhas do desenho. SPEED X / Y so aparecem com speed; sem faixa CURVA. */
public class ReactionLayoutTest {
    public static void main(String[] args) throws Exception {
        boolean[] all = {true, true, true, true, true};
        boolean[] none = new boolean[ReactionLayout.LANES];
        boolean[] some = new boolean[ReactionLayout.LANES];
        some[ReactionLayout.L_SPEEDX] = true;
        some[ReactionLayout.L_SEQ] = true;
        boolean[] both = new boolean[ReactionLayout.LANES];
        both[ReactionLayout.L_SPEEDX] = true;
        both[ReactionLayout.L_SPEEDY] = true;

        check("6 faixas (passos, speed x, speed y, voz, efeitos, seq), sem curva", ReactionLayout.LANES + ":" + ReactionLayout.NAMES.length, "6:6");
        List<ReactionLayout.Row> open = ReactionLayout.body(all, true, none);
        check("aberta sem nenhum dado: nenhuma faixa (so a dos passos); o botao ＋ cria", open.size(), 0);
        List<ReactionLayout.Row> openX = ReactionLayout.body(all, true, some);
        check("aberta com speed x e seq: so essas duas, na ordem", openX.size() + ":" + openX.get(0).lane + ":" + openX.get(1).lane, "2:" + ReactionLayout.L_SPEEDX + ":" + ReactionLayout.L_SEQ);
        boolean[] five = new boolean[ReactionLayout.LANES];
        for (int i = 1; i < five.length; i++) five[i] = true;
        List<ReactionLayout.Row> openXY = ReactionLayout.body(all, true, five);
        check("aberta com dados em todas: 5 linhas", openXY.size() + ":" + openXY.get(1).lane, "5:" + ReactionLayout.L_SPEEDY);
        int[] cnt = new int[ReactionLayout.LANES];
        java.util.Arrays.fill(cnt, 1);
        cnt[ReactionLayout.L_VOZ] = 2;
        List<ReactionLayout.Row> dup = ReactionLayout.body(all, true, five, cnt);
        check("itens sobrepostos na mesma faixa duplicam a faixa (VOZ e VOZ 2)", dup.size() + ":" + dup.get(2).lane + ":" + dup.get(2).sub + ":" + dup.get(3).lane + ":" + dup.get(3).sub, "6:3:0:3:1");
        check("fechada: um resumo por faixa mesmo com itens duplicados", ReactionLayout.body(all, false, five, cnt).size(), 5);
        check("stack: sem sobreposicao fica tudo na linha 0", java.util.Arrays.toString(ReactionLayout.stack(new int[][]{{0, 4}, {4, 7}, {9, 12}})), "[0, 0, 0]");
        check("stack: o que se sobrepoe vai para a linha de baixo e reaproveita linhas livres", java.util.Arrays.toString(ReactionLayout.stack(new int[][]{{0, 6}, {3, 8}, {6, 9}, {8, 10}})), "[0, 1, 0, 1]");
        check("altura da view: regua 14 + clipes 40 + 5x22 + 3 = 167", ReactionLayout.viewH(openXY, 188f), 167f);
        check("conteudo = 5x22", ReactionLayout.contentH(openXY), 110f);
        check("teto menor (tela baixa) limita a view", ReactionLayout.viewH(openXY, 120f), 120f);

        List<ReactionLayout.Row> shut = ReactionLayout.body(all, false, some);
        check("fechada: so resumo (10 dp) das faixas com dados", shut.size() + ":" + shut.get(0).lane + ":" + shut.get(1).lane + ":" + shut.get(0).h + ":" + shut.get(0).summary, "2:1:5:10.0:true");
        check("fechada sem dados: nenhuma linha", ReactionLayout.body(all, false, none).size(), 0);

        boolean[] noSeq = {true, true, true, true, false};
        List<ReactionLayout.Row> f = ReactionLayout.body(noSeq, true, five);
        boolean hasSeq = false;
        for (ReactionLayout.Row r : f) hasSeq |= r.lane == ReactionLayout.L_SEQ;
        check("filtro: faixa desligada some", f.size() + ":" + hasSeq, "4:false");
        boolean[] noSpeedX = {false, true, true, true, true};
        check("filtro desliga o speed x mesmo com dados", ReactionLayout.body(noSpeedX, true, some).size(), 1);

        // rolagem e posicoes
        float vh = ReactionLayout.viewH(openXY, 120f);
        check("rolagem maxima = conteudo - (view - regua - clipes) = 110 - 66", ReactionLayout.maxScroll(openXY, vh), 44f);
        check("rolagem presa em 0..max", ReactionLayout.clampScroll(openXY, vh, -5f) + ":" + ReactionLayout.clampScroll(openXY, vh, 999f), "0.0:44.0");
        ReactionLayout.place(openXY, 0f);
        check("posicoes sem rolagem: 54, 76, 98, 120, 142", openXY.get(0).top + ":" + openXY.get(1).top + ":" + openXY.get(2).top + ":" + openXY.get(3).top + ":" + openXY.get(4).top, "54.0:76.0:98.0:120.0:142.0");
        ReactionLayout.place(openXY, 30f);
        check("rolando 30 dp tudo sobe 30", openXY.get(0).top + ":" + openXY.get(4).top, "24.0:112.0");

        // hit-test = mesmas linhas do desenho
        ReactionLayout.place(openXY, 0f);
        check("regua", ReactionLayout.laneAt(openXY, 5f), -1);
        check("clipes: 14..54", ReactionLayout.laneAt(openXY, 14f) + ":" + ReactionLayout.laneAt(openXY, 53.9f), ReactionLayout.L_CLIP + ":" + ReactionLayout.L_CLIP);
        check("speed x: 54..76 e speed y: 76..98", ReactionLayout.laneAt(openXY, 54f) + ":" + ReactionLayout.laneAt(openXY, 75f) + ":" + ReactionLayout.laneAt(openXY, 80f), ReactionLayout.L_SPEEDX + ":" + ReactionLayout.L_SPEEDX + ":" + ReactionLayout.L_SPEEDY);
        check("voz, efeitos, seq em ordem", ReactionLayout.laneAt(openXY, 102f) + "" + ReactionLayout.laneAt(openXY, 122f) + ReactionLayout.laneAt(openXY, 150f), "345");
        check("abaixo do conteudo", ReactionLayout.laneAt(openXY, 170f), -1);
        ReactionLayout.place(openXY, 40f);
        check("com rolagem 40: voz (58..80) ocupa o y 60", ReactionLayout.laneAt(openXY, 60f), ReactionLayout.L_VOZ);
        check("com rolagem 40, o y 55 (logo abaixo dos clipes) cai no speed y (36..58)", ReactionLayout.laneAt(openXY, 55f), ReactionLayout.L_SPEEDY);

        int[][] segs = {{0, 4, 0}, {4, 7, 1}, {7, 7, 2}};
        check("passo no tick", ReactionLayout.rowAtTick(segs, 0) + ":" + ReactionLayout.rowAtTick(segs, 3) + ":" + ReactionLayout.rowAtTick(segs, 4) + ":" + ReactionLayout.rowAtTick(segs, 7) + ":" + ReactionLayout.rowAtTick(segs, -1), "0:0:1:-1:-1");
        check("filtro tem um nome por faixa de corpo", ReactionLayout.FILTER_NAMES.length, ReactionLayout.L_SEQ);
        check("rotulos por faixa", ReactionLayout.NAMES.length, ReactionLayout.LANES);

        System.out.println("ReactionLayoutTest fails=" + BattleTest.fails);
    }
}
