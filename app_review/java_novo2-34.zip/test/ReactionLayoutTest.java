package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Geometria da timeline de reacoes (mesmas medidas da principal) e o hit-test pelas mesmas linhas do desenho. */
public class ReactionLayoutTest {
    public static void main(String[] args) throws Exception {
        boolean[] all = {true, true, true, true, true};
        boolean[] none = new boolean[ReactionLayout.LANES];
        boolean[] some = new boolean[ReactionLayout.LANES];
        some[ReactionLayout.L_SPEED] = true;
        some[ReactionLayout.L_SEQ] = true;

        List<ReactionLayout.Row> open = ReactionLayout.body(all, true, none);
        check("aberta: 5 linhas (speed, voz, efeitos, seq e curva), mesmo sem dados", open.size(), 5);
        check("aberta: alturas 22,22,22,22 e curva 40", open.get(0).h + ":" + open.get(3).h + ":" + open.get(4).h, "22.0:22.0:40.0");
        check("aberta: conteudo = 4x22 + 40", ReactionLayout.contentH(open), 128f);
        check("altura da view: regua 14 + clipes 40 + conteudo + 3, limitada ao teto 188", ReactionLayout.viewH(open, 188f), 185f);
        check("teto menor (tela baixa) limita a view", ReactionLayout.viewH(open, 120f), 120f);

        List<ReactionLayout.Row> shut = ReactionLayout.body(all, false, some);
        check("fechada: so resumo (10 dp) das faixas com dados", shut.size() + ":" + shut.get(0).lane + ":" + shut.get(1).lane + ":" + shut.get(0).h + ":" + shut.get(0).summary, "2:1:4:10.0:true");
        check("fechada sem dados: nenhuma linha", ReactionLayout.body(all, false, none).size(), 0);
        check("a curva nao tem resumo", ReactionLayout.body(new boolean[]{false, false, false, false, true}, false, some).size(), 0);

        boolean[] noSeq = {true, true, true, false, true};
        List<ReactionLayout.Row> f = ReactionLayout.body(noSeq, true, none);
        boolean hasSeq = false;
        for (ReactionLayout.Row r : f) hasSeq |= r.lane == ReactionLayout.L_SEQ;
        check("filtro: faixa desligada some", f.size() + ":" + hasSeq, "4:false");

        // rolagem e posicoes
        float vh = ReactionLayout.viewH(open, 120f);
        check("rolagem maxima = conteudo - (view - regua - clipes) = 128 - 66", ReactionLayout.maxScroll(open, vh), 62f);
        check("rolagem presa em 0..max", ReactionLayout.clampScroll(open, vh, -5f) + ":" + ReactionLayout.clampScroll(open, vh, 999f), "0.0:62.0");
        ReactionLayout.place(open, 0f);
        check("posicoes sem rolagem: 54, 76, 98, 120, 142", open.get(0).top + ":" + open.get(1).top + ":" + open.get(2).top + ":" + open.get(3).top + ":" + open.get(4).top, "54.0:76.0:98.0:120.0:142.0");
        ReactionLayout.place(open, 30f);
        check("rolando 30 dp tudo sobe 30", open.get(0).top + ":" + open.get(4).top, "24.0:112.0");

        // hit-test = mesmas linhas do desenho
        ReactionLayout.place(open, 0f);
        check("regua", ReactionLayout.laneAt(open, 5f), -1);
        check("clipes: 14..54", ReactionLayout.laneAt(open, 14f) + ":" + ReactionLayout.laneAt(open, 53.9f), ReactionLayout.L_CLIP + ":" + ReactionLayout.L_CLIP);
        check("speed: 54..76", ReactionLayout.laneAt(open, 54f) + ":" + ReactionLayout.laneAt(open, 75f), ReactionLayout.L_SPEED + ":" + ReactionLayout.L_SPEED);
        check("voz, efeitos, seq, curva em ordem", ReactionLayout.laneAt(open, 80f) + "" + ReactionLayout.laneAt(open, 100f) + ReactionLayout.laneAt(open, 130f) + ReactionLayout.laneAt(open, 160f), "2345");
        check("abaixo do conteudo", ReactionLayout.laneAt(open, 190f), -1);
        ReactionLayout.place(open, 40f);
        check("com rolagem 40: a 1a linha sai por cima e a 3a (efeitos, top 58) ocupa o y 60", ReactionLayout.laneAt(open, 60f), ReactionLayout.L_EFEITOS);
        check("com rolagem, y de linha rolada para baixo dos clipes cai na linha seguinte (speed saiu: 14..36 fica atras dos clipes)", ReactionLayout.laneAt(open, 55f), ReactionLayout.L_VOZ);

        int[][] segs = {{0, 4, 0}, {4, 7, 1}, {7, 7, 2}};
        check("passo no tick", ReactionLayout.rowAtTick(segs, 0) + ":" + ReactionLayout.rowAtTick(segs, 3) + ":" + ReactionLayout.rowAtTick(segs, 4) + ":" + ReactionLayout.rowAtTick(segs, 7) + ":" + ReactionLayout.rowAtTick(segs, -1), "0:0:1:-1:-1");
        check("filtro tem um nome por faixa de corpo", ReactionLayout.FILTER_NAMES.length, ReactionLayout.L_CURVA);
        check("rotulos por faixa", ReactionLayout.NAMES.length, ReactionLayout.LANES);

        System.out.println("ReactionLayoutTest fails=" + BattleTest.fails);
    }
}
