package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Ocorrencias (uma passagem por tabela), fatias para a timeline, tabela teorica (sem hit), WallRules e as acoes especiais do COMP. */
public class ReactionOccurrencesTest {
    public static void main(String[] args) throws Exception {
        // reacao 0 do personagem: 2 passos (3 + 255 ate pousar, cai 4 px/tick), ao pousar COMP 3 = reacao 3 do jogo
        byte[][] rs = new byte[1][];
        rs[0] = react(new int[]{3, 3, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, new int[]{255, 255, 6, 0, 0, 0, 0, 0, 40, 0, 0, 3, 0, 0});
        ReactionTrace tr = ReactionTrace.record(LockReactionTest.sim(rs, 60), 30, 300);
        java.util.List<ReactionTrace.Occ> os = tr.occurrences();
        check("duas passagens: a reacao 0 do personagem e a 3 do jogo", os.size() + ":" + os.get(0).charSrc + ":" + os.get(0).type + ":" + os.get(1).charSrc + ":" + os.get(1).type, "2:true:0:false:3");
        check("passos seguidos da mesma tabela (tempo do passo) sao a mesma passagem", tr.segments.size() >= 3 && os.get(0).end == tr.segments.get(1).end, true);
        check("a 2a passagem veio da 1a, por pouso, saindo do passo 2", os.get(1).from + ":" + os.get(1).reason + ":" + os.get(1).fromRow + ":" + os.get(0).from, "0:" + BattleSim.R_LAND + ":1:-1");
        check("as passagens se encaixam sem buraco e cobrem o trace todo", os.get(0).start + ":" + (os.get(0).end == os.get(1).start) + ":" + (os.get(1).end == tr.ticks.size()), "0:true:true");
        check("occIndexAt: antes e depois do salto", tr.occIndexAt(0) + ":" + tr.occIndexAt(os.get(0).end - 1) + ":" + tr.occIndexAt(os.get(1).start) + ":" + tr.occIndexAt(9999), "0:0:1:1");
        ReactionTrace sl = tr.slice(os.get(1));
        check("fatia: so os ticks da passagem, trechos recontados do 0", sl.ticks.size() == os.get(1).length() && sl.segments.get(0).start == 0 && sl.segments.get(0).end == sl.ticks.size() && sl.segments.get(0).type == 3, true);
        ReactionTrace s0 = tr.slice(os.get(0));
        check("fatia da 1a: 2 passos da tabela, comecando na posicao do hit", s0.segments.size() + ":" + s0.startY, "2:-60");
        check("fatia da 2a comeca onde a 1a terminou (posicao)", sl.startY, tr.ticks.get(os.get(0).end - 1).y);

        // sem o golpe acertar: tabela teorica (solo ou ar), 255 mostra 30 ticks
        ReactionTable t = new ReactionTable(react(new int[]{4, 9, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, new int[]{255, 255, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}), 0);
        ReactionTrace g = ReactionTrace.theoretical(t, true, 7, false), a = ReactionTrace.theoretical(t, true, 7, true);
        check("teorica no chao: 4 + 30 ticks, 2 passos, marcada como teorica", g.ticks.size() + ":" + g.segments.size() + ":" + g.theoretical, "34:2:true");
        check("teorica no ar: 9 + 30 ticks", a.ticks.size(), 39);
        check("teorica: uma passagem so, da reacao pedida", g.occurrences().size() + ":" + g.occurrences().get(0).type + ":" + g.occurrences().get(0).charSrc, "1:7:true");
        check("teorica de tabela nula: vazia", ReactionTrace.theoretical(null, true, 0, false).ticks.size(), 0);

        // WALL: so 2 e 3 agem; o resto vale 0
        check("WALL 2 e 3 ativam, 0 / 1 / outros nao", WallRules.triggers(2) + ":" + WallRules.triggers(3) + ":" + WallRules.triggers(0) + ":" + WallRules.triggers(1) + ":" + WallRules.triggers(7) + ":" + WallRules.triggers(255), "true:true:false:false:false:false");
        check("valor efetivo: 7 vale 0, -3 vale 0, 1 vale 1", WallRules.effective(7) + ":" + WallRules.effective(-3) + ":" + WallRules.effective(1), "0:0:1");
        check("o seletor oferece desligado, mapa, tela e camera (nessa ordem)", java.util.Arrays.toString(WallRules.MODES), "[0, 2, 3, 1]");
        check("texto do modo tela muda entre personagem e jogo", WallRules.describe(3, true).equals(WallRules.describe(3, false)), false);
        check("nomes", WallRules.name(0) + "|" + WallRules.name(2) + "|" + WallRules.name(3) + "|" + WallRules.name(1), "Desligado (0)|Borda do mapa (2)|Borda da tela (3)|Câmera segue (1)");

        // COMP: acoes especiais no topo do seletor - N +
        GameData gdc = gd(new byte[][]{null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}), null, null, null, null, null, null, null, null, null, null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0})});
        CharData cd = chr(move(new int[]{0, 4}, new int[]{2, 3}), rs);
        java.util.List<Integer> steps = ReactionSlots.compSteps(gdc, cd);
        check("passos do seletor: 0, 11, 12, 50 no topo, depois jogo (sem 12) e personagem", steps.toString(), "[0, 11, 12, 50, 1, 30]");
        check("especiais", ReactionSlots.COMP_SPECIAL.length + ":" + ReactionSlots.compIsSpecial(11) + ":" + ReactionSlots.compIsSpecial(12) + ":" + ReactionSlots.compIsSpecial(50) + ":" + ReactionSlots.compIsSpecial(70) + ":" + ReactionSlots.compIsSpecial(3), "3:true:true:true:true:false");
        check("titulos das especiais", ReactionSlots.compTitle(11) + "|" + ReactionSlots.compTitle(12) + "|" + ReactionSlots.compTitle(50), "11 · faz pousar|12 · faz quicar|50 · só pousa e termina");
        System.out.println("ReactionOccurrencesTest fails=" + fails);
    }
}
