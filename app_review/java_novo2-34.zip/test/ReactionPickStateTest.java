package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Estado da grade "Escolher reacao": destaque inicial, trocar, so o destacado toca e so grava se mudou. */
public class ReactionPickStateTest {
    public static void main(String[] args) throws Exception {
        ReactionPickState s = new ReactionPickState(103);
        check("grupo e reacao atual (103 = grupo 2, indice 3)", s.group + ":" + s.initial + ":" + s.selected(), "2:3:3");
        check("so a atual toca ao abrir", s.audible(3) + ":" + s.audible(4), "true:false");
        check("sem mudar nao grava", s.changed(), false);
        s.select(7);
        check("trocar: o novo toca e o antigo nao", s.audible(7) + ":" + s.audible(3), "true:false");
        check("mudou e grava no mesmo grupo", s.changed() + ":" + s.result(), "true:107");
        s.select(3);
        check("voltar a atual = sem mudanca", s.changed(), false);
        ReactionPickState neg = new ReactionPickState(-1);
        check("valor invalido cai em grupo 0 reacao 0", neg.group + ":" + neg.initial, "0:0");
        ReactionPickState big = new ReactionPickState(999);
        check("grupo preso a 4", big.group, 4);
        System.out.println("ReactionPickStateTest fails=" + fails);
    }
}
