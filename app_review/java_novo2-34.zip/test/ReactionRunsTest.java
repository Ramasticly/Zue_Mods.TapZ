package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Colunas de velocidade e celulas das faixas SPEED X / SPEED Y: uma por passo, sem unir; speed e accel no mesmo passo em linhas separadas. */
public class ReactionRunsTest {
    static ReactionTable t(int[]... rows) { return new ReactionTable(react(rows), 0); }

    /** passo: dc, da, ano, xs, ys, xa, ya, (ar) xs, ys, xa, ya, comp, wall, voz */
    static int[] r(int xs, int ys, int xa, int ya) { return new int[]{5, 5, 1, xs, ys, xa, ya, xs, ys, xa, ya, 0, 0, 0}; }

    static ReactionSpeedCells.Result cells(ReactionTable tb, boolean air, int axis, int[] eff) {
        int n = tb.rows;
        int[] st = new int[n], en = new int[n];
        for (int i = 0; i < n; i++) { st[i] = i * 5; en[i] = i * 5 + 5; }
        return ReactionSpeedCells.build(tb, air, axis, st, en, eff);
    }

    public static void main(String[] args) throws Exception {
        check("colunas: chao 3/4, ar 7/8 e accel 5/6, 9/10", ReactionRuns.col(false, 0) + ":" + ReactionRuns.col(false, 1) + ":" + ReactionRuns.col(true, 0) + ":" + ReactionRuns.col(true, 1) + ":"
                + ReactionSpeedCells.accelCol(false, 0) + ":" + ReactionSpeedCells.accelCol(false, 1) + ":" + ReactionSpeedCells.accelCol(true, 0) + ":" + ReactionSpeedCells.accelCol(true, 1), "3:4:7:8:5:6:9:10");
        ReactionTable keep = t(r(-1, 5, 0, 0));
        check("keeps por eixo", ReactionRuns.keeps(keep, 0, false, 0) + ":" + ReactionRuns.keeps(keep, 0, false, 1) + ":" + ReactionRuns.keeps(keep, 0, false), "true:false:false");

        // x: p0 10 | p1 = (mantem) | p2 = | p3 20 | p4 =   -> so os passos com speed PROPRIA viram celula; o "mantem" (-1) nao e faixa
        ReactionTable tb = t(r(10, 0, 0, 0), r(-1, 0, 0, 0), r(-1, 0, 0, 0), r(20, 0, 0, 0), r(-1, 0, 0, 0));
        ReactionSpeedCells.Result x = cells(tb, false, ReactionRuns.X, new int[]{10, 10, 10, 20, 20});
        check("x: 2 celulas (passos 0 e 3), 1 linha; os passos que mantem nao geram celula", x.cells.size() + ":" + x.lines + ":" + (x.find(1, 0) == null) + ":" + (x.find(4, 0) == null), "2:1:true:true");
        check("textos: valor proprio", x.find(0, 0).text + "|" + x.find(3, 0).text, "x 10|x 20");
        check("y: nada (0 sem nada andando)", cells(tb, false, ReactionRuns.Y, null).cells.size(), 0);

        // speed e accel no MESMO passo = 2 linhas; em passos diferentes = 1 linha
        ReactionTable same = t(r(10, 0, 2, 0), r(-1, 0, 0, 0));
        ReactionSpeedCells.Result sa = cells(same, false, ReactionRuns.X, new int[]{10, 10});
        check("speed + accel do mesmo passo: 2 linhas (speed na 0, accel na 1)", sa.lines + ":" + sa.find(0, 0).line + ":" + sa.find(0, 1).line + ":" + sa.find(0, 1).text, "2:0:1:ax 2");
        ReactionTable diff = t(r(0, 0, 3, 0), r(0, 0, -1, 0));
        ReactionSpeedCells.Result da = cells(diff, false, ReactionRuns.X, null);
        check("accel no passo 0 e accel mantida (-1) no passo 1: a mantida nao e faixa (1 celula, 1 linha)", da.lines + ":" + da.find(0, 1).line + ":" + (da.find(1, 1) == null), "1:0:true");
        ReactionTable accOnly = t(r(0, 0, 3, 0));
        check("so accel (sem speed): uma celula na linha 0", cells(accOnly, false, ReactionRuns.X, null).lines + ":" + cells(accOnly, false, ReactionRuns.X, null).cells.size(), "1:1");
        ReactionTable stop = t(r(10, 0, 0, 0), r(0, 0, 0, 0));
        check("o 0 que para uma velocidade que andava aparece como 'x 0'", cells(stop, false, ReactionRuns.X, null).find(1, 0).text, "x 0");
        check("o 0 da aceleracao que cancela uma accel aparece como 'ax 0'", sa.find(1, 1) != null && sa.find(1, 1).text.equals("ax 0") && sa.find(1, 1).kind == ReactionSpeedCells.ACCEL, true);

        // metade e valores
        ReactionTable half = t(r(10, 0, 0, 0), r(-2, 0, 0, 0));
        check("-2 (metade) tambem nao e faixa", cells(half, false, ReactionRuns.X, new int[]{10, 5}).cells.size(), 1);
        // ar usa as colunas do ar
        ReactionTable airT = t(new int[]{5, 5, 1, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, 0});
        check("ar: coluna 7 tem speed, chao nao", cells(airT, true, ReactionRuns.X, null).cells.size() + ":" + cells(airT, false, ReactionRuns.X, null).cells.size(), "1:0");
        // passo nao simulado nao tem celula
        ReactionTable two = t(r(10, 0, 0, 0), r(20, 0, 0, 0));
        ReactionSpeedCells.Result ns = ReactionSpeedCells.build(two, false, 0, new int[]{0, -1}, new int[]{5, 0}, null);
        check("passo nao simulado: sem celula", ns.cells.size(), 1);
        // leading '=' sem nada andando nao aparece
        ReactionTable lead = t(r(-1, 0, 0, 0), r(10, 0, 0, 0));
        check("'=' no inicio (nada andando) nao aparece", cells(lead, false, ReactionRuns.X, null).cells.size(), 1);

        // layout: rowAt devolve a linha com a sub
        java.util.List<ReactionLayout.Row> rows = ReactionLayout.body(new boolean[]{true, true, true, true, true}, true, new boolean[]{false, true, false, false, false, false}, new int[]{1, 2, 1, 1, 1, 1});
        ReactionLayout.place(rows, 0);
        ReactionLayout.Row r0 = rows.get(0), r1 = rows.get(1);
        check("faixa com 2 linhas: duas linhas sub 0 e 1", rows.size() + ":" + r0.sub + ":" + r1.sub + ":" + r1.lane, "2:0:1:" + ReactionLayout.L_SPEEDX);
        ReactionLayout.Row at = ReactionLayout.rowAt(rows, r1.top + 1);
        check("rowAt acha a sub-linha tocada", at != null && at.sub == 1, true);
        check("rowAt na regua: null", ReactionLayout.rowAt(rows, 3f) == null, true);
        System.out.println("ReactionRunsTest fails=" + fails);
    }
}
