package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Faixas SPEED X e SPEED Y: corridas independentes por eixo (o jogo trata xs e ys separados; -1 mantem so aquele eixo). */
public class ReactionRunsTest {
    static ReactionTable t(int[]... rows) { return new ReactionTable(react(rows), 0); }

    /** passo: dc, da, ano, xs, ys, xa, ya, (ar) xs, ys, xa, ya, comp, wall, voz */
    static int[] r(int xs, int ys) { return new int[]{5, 5, 1, xs, ys, 0, 0, xs, ys, 0, 0, 0, 0, 0}; }

    public static void main(String[] args) throws Exception {
        // x muda nos passos 0 e 3; y nos passos 0 e 2
        ReactionTable tb = t(r(10, 20), r(-1, -1), r(-1, 30), r(40, -1), r(-1, -1));
        List<int[]> xs = ReactionRuns.runs(tb, false, ReactionRuns.X), ys = ReactionRuns.runs(tb, false, ReactionRuns.Y);
        check("corridas de x: 0-3 e 3-5", xs.size() + ":" + xs.get(0)[0] + "-" + xs.get(0)[1] + ":" + xs.get(1)[0] + "-" + xs.get(1)[1], "2:0-3:3-5");
        check("corridas de y: 0-2 e 2-5", ys.size() + ":" + ys.get(0)[0] + "-" + ys.get(0)[1] + ":" + ys.get(1)[0] + "-" + ys.get(1)[1], "2:0-2:2-5");
        check("o par antigo (x+y) tem uma corrida em cada passo com algum valor proprio (0, 2 e 3)", ReactionRuns.runs(tb, false).size(), 3);
        check("runOf por eixo", ReactionRuns.runOf(tb, false, ReactionRuns.X, 2) + ":" + ReactionRuns.runOf(tb, false, ReactionRuns.Y, 2), "0:1");
        check("keeps por eixo", ReactionRuns.keeps(tb, 2, false, ReactionRuns.X) + ":" + ReactionRuns.keeps(tb, 2, false, ReactionRuns.Y), "true:false");

        // arrastar o fim da corrida de x nao mexe em y
        ReactionTable a = tb.copy();
        boolean moved = ReactionRuns.setRunEnd(a, false, ReactionRuns.X, 0, 2);
        check("x: encurtar a corrida 0 para 2 passos faz o passo 2 receber o x do passo 3 (40)", moved && a.s8(2, 3) == 40 && a.s8(3, 3) == -1, true);
        check("y nao mudou", a.s8(0, 4) == 20 && a.s8(1, 4) == -1 && a.s8(2, 4) == 30 && a.s8(3, 4) == -1, true);

        // remover e criar por eixo
        ReactionTable rm = tb.copy();
        check("remover a corrida 1 de y: so o y do passo 2 volta a manter", ReactionRuns.removeRun(rm, false, ReactionRuns.Y, 1) && rm.s8(2, 4) == -1 && rm.s8(2, 3) == -1 && rm.s8(3, 3) == 40, true);
        ReactionTable st = tb.copy();
        check("criar corrida de x no passo 1 (so mantinha x): x = 0 e y continua mantendo", ReactionRuns.startRun(st, false, ReactionRuns.X, 1) && st.s8(1, 3) == 0 && st.s8(1, 4) == -1, true);
        check("criar onde ja tem valor proprio: nada", ReactionRuns.startRun(tb.copy(), false, ReactionRuns.Y, 2), false);

        // ultima corrida de um eixo encurtada abre uma corrida parada so naquele eixo
        ReactionTable last = tb.copy();
        check("encurtar a ultima corrida de y (2-5) para 2-4: y do passo 4 = 0 e x segue", ReactionRuns.setRunEnd(last, false, ReactionRuns.Y, 1, 4) && last.s8(4, 4) == 0 && last.s8(4, 3) == -1, true);

        // ar usa as colunas 7/8
        ReactionTable air = t(r(10, 20), r(-1, -1), r(-1, 30));
        check("ar: colunas 7 (x) e 8 (y)", ReactionRuns.col(true, ReactionRuns.X) + ":" + ReactionRuns.col(true, ReactionRuns.Y) + ":" + ReactionRuns.runs(air, true, ReactionRuns.Y).size(), "7:8:2");
        System.out.println("ReactionRunsTest fails=" + fails);
    }
}
