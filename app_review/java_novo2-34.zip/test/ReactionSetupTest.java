package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** ReactionSetup: oponente em outro ponto do mapa (paredes) na simulacao do editor de reacoes. */
public class ReactionSetupTest {
    static BattleSim sim(ReactionSetup su, byte[][] charReactions, int dist) throws Exception {
        A[] atk = new A[10];
        for (int i = 0; i < 10; i++) atk[i] = new A().mpt(new M().time(5));
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(3)).mpt(new M().time(3));
        CharData ch = chr(move(new int[]{0, 4}, new int[]{2, 3}), charReactions);
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}) });
        BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], su.fromRight, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, dist, 0, 0);
        s.setReactionSpot(su.placed ? su.x : Integer.MIN_VALUE, su.heightPx);
        return s;
    }

    public static void main(String[] args) throws Exception {
        // ---- objeto puro
        ReactionSetup d = new ReactionSetup();
        check("padrao: nao colocado", d.placed + ":" + d.describe(), "false:padrão");
        check("presets", new ReactionSetup().leftWall().x + ":" + new ReactionSetup().leftWall().fromRight + ":" + new ReactionSetup().rightWall().x + ":" + new ReactionSetup().rightWall().fromRight + ":" + new ReactionSetup().center().x, "-720:true:719:false:0");
        check("arrastar: clampa no mapa e comeca de 120 se nao estava colocado", new ReactionSetup().moveBy(30).x + ":" + new ReactionSetup().moveBy(5000).x + ":" + new ReactionSetup().moveBy(-5000).x, "150:719:-720");
        check("altura entre 0 e 200", new ReactionSetup().setHeight(-5).heightPx + ":" + new ReactionSetup().setHeight(999).heightPx, "0:200");
        check("key muda com cada campo", new ReactionSetup().key().equals(new ReactionSetup().key()) && !new ReactionSetup().key().equals(new ReactionSetup().leftWall().key()) && !new ReactionSetup().key().equals(new ReactionSetup().setHeight(60).key()), true);
        ReactionSetup cp = new ReactionSetup().leftWall().setHeight(60);
        check("copy", cp.copy().key(), cp.key());

        // ---- na simulacao: posicao inicial e altura
        byte[][] rs = new byte[1][];
        rs[0] = react(new int[]{6, 6, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});
        BattleSim def = sim(new ReactionSetup(), rs, 100);
        BattleSim c0 = sim(new ReactionSetup().center(), rs, 100);
        BattleSim lw = sim(new ReactionSetup().leftWall(), rs, 100);
        BattleSim rw = sim(new ReactionSetup().rightWall(), rs, 100);
        check("padrao: oponente a +120 px (atacante a esquerda dele)", def.opponentX() + ":" + (def.attackerX() < def.opponentX()), "120:true");
        check("centro: oponente em x = 0", c0.opponentX(), 0);
        check("parede esquerda: oponente colado na parede (x < -600) e o atacante a direita dele", (lw.opponentX() < -600) + ":" + (lw.attackerX() > lw.opponentX()), "true:true");
        check("parede direita: oponente na ponta direita (x > 600) e o atacante a esquerda", (rw.opponentX() > 600) + ":" + (rw.attackerX() < rw.opponentX()), "true:true");
        check("altura da previa", sim(new ReactionSetup().setHeight(60), rs, 100).opponentY() + ":" + def.opponentY(), "-60:0");

        // ---- parede muda o caminho: WALL 2 com COMP 3 (reacao 3 do jogo) so entra se o oponente chega na parede
        byte[][] wl = new byte[1][];
        wl[0] = react(new int[]{60, 60, 4, -100, 0, 0, 0, -100, 0, 0, 0, 3, 2, 0});    // empurra para tras 10 px/tick; COMP 3, parede 2
        ReactionTrace nearWall = ReactionTrace.record(sim(new ReactionSetup().leftWall(), wl, 100), 30, 300);
        ReactionTrace center = ReactionTrace.record(sim(new ReactionSetup().center(), wl, 100), 30, 300);
        boolean hitWall = false;
        for (ReactionTrace.Seg sg : nearWall.segments) if (sg.reason == BattleSim.R_WALL) hitWall = true;
        boolean centerWall = false;
        for (ReactionTrace.Seg sg : center.segments) if (sg.reason == BattleSim.R_WALL) centerWall = true;
        check("na parede esquerda o golpe vindo da direita empurra o oponente para ela: o trace tem a troca PAREDE -> reacao 3", hitWall, true);
        check("no centro, em 60 ticks nao chega na parede", centerWall, false);
        System.out.println("ReactionSetupTest fails=" + fails);
    }
}
