package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;

/** Slots de reacao do personagem (HDAT 14..33): vazios, copiar/importar, e gravar no 000.bin.txt mesmo sem o bloco $REACAO_DANO_n. */
public class ReactionSlotsTest {
    static byte[] bin(byte[][] reactionsByType) throws Exception {
        byte[][] t = new byte[40][];
        int[] cols = new int[40], rows = new int[40];
        for (int i = 0; i < 40; i++) t[i] = new byte[0];
        byte[] moves = move(new int[]{0, 4}, new int[]{2, 3});
        t[4] = moves; cols[4] = 48; rows[4] = 1;
        for (int i = 0; i < reactionsByType.length; i++) {
            if (reactionsByType[i] == null) continue;
            t[14 + i] = reactionsByType[i]; cols[14 + i] = 14; rows[14 + i] = reactionsByType[i].length / 14;
        }
        return hdat(t, cols, rows);
    }

    static void del(File f) { File[] k = f.listFiles(); if (k != null) for (File c : k) del(c); f.delete(); }

    public static void main(String[] args) throws Exception {
        byte[][] rs = new byte[8][];
        rs[0] = react(new int[]{20, 20, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});
        rs[5] = react(new int[]{6, 6, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}, new int[]{12, 255, -4, -1, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0});
        CharData cd = chr(move(new int[]{0, 4}, new int[]{2, 3}), rs);

        // ---- vazios e resumo
        java.util.List<Integer> empty = ReactionSlots.emptySlots(cd);
        check("slots vazios: 20 - 2 preenchidos", empty.size() + ":" + empty.contains(Integer.valueOf(0)) + ":" + empty.contains(Integer.valueOf(5)) + ":" + empty.contains(Integer.valueOf(19)), "18:false:false:true");
        check("resumo de um passo", ReactionSlots.summary(cd.reaction(0)), "1 passo · ANO 7 · 0.3s no chão");
        check("resumo de dois passos (ANO negativo vira positivo; 255 = ate pousar)", ReactionSlots.summary(cd.reaction(5)), "2 passos · ANOs 3, 4 · 0.3s no chão");
        check("resumo de vazia", ReactionSlots.summary(cd.reaction(3)), "vazia");
        ReactionTable open = new ReactionTable(react(new int[]{255, 255, 2}), 1);
        check("duracao 255 no chao = ate pousar", ReactionSlots.summary(open).endsWith("até pousar"), true);

        // ---- candidatas do COMP (seletor da proxima reacao): jogo 1..29 e personagem 30..49, so com passos
        GameData gdc = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) });
        java.util.List<ReactionSlots.Comp> cj = ReactionSlots.compCandidates(gdc, cd, 0), cp = ReactionSlots.compCandidates(gdc, cd, 1);
        check("COMP: aba do jogo lista so tabelas com passos (a 3 do gamedata de teste, valor 3)", cj.size() == 1 && cj.get(0).value == 3 && !cj.get(0).charSrc && cj.get(0).firstAno == 20, true);
        check("COMP: aba do personagem = valor 30 + tipo (tipos 0 e 5 preenchidos -> 30 e 35)", cp.size() + ":" + cp.get(0).value + ":" + cp.get(1).value + ":" + cp.get(1).charSrc, "2:30:35:true");
        check("COMP: aba do valor", ReactionSlots.compTab(3) + ":" + ReactionSlots.compTab(30) + ":" + ReactionSlots.compTab(49), "0:1:1");
        check("COMP: sem dados nao quebra", ReactionSlots.compCandidates(null, null, 0).size() + ":" + ReactionSlots.compCandidates(null, null, 1).size(), "0:0");

        // ---- em branco e copia
        ReactionTable bl = ReactionTable.blank();
        check("em branco: 1 passo, ANO 0, 6 ticks", bl.rows + ":" + bl.s8(0, 2) + ":" + bl.u8(0, 0) + ":" + bl.u8(0, 1) + ":" + bl.u8(0, 11), "1:0:6:6:0");
        ReactionTable slot = cd.reaction(9);
        slot.restoreFrom(cd.reaction(5).copy());
        check("copiar para o slot vazio: mesmas linhas", slot.rows + ":" + slot.s8(1, 2) + ":" + slot.u8(1, 1), "2:-4:255");
        slot.set(0, 2, 99);
        check("a copia nao muda a origem", cd.reaction(5).s8(0, 2), 3);

        // ---- gravar no 000.bin.txt
        ReactionTable two = cd.reaction(5);
        // a) HDAT em linha unica, ROW 0 e sem o bloco $REACAO_DANO_n
        String a = "BIN_CNV_ {$COUNT: 43,\n   $HDAT_29:{$info:{$COL: 14, $ROW: 1, $SZ: &0000000E},\n      $REACAO_DANO_15:{\n         $FR_0: {$DUR_C: 1, $DUR_A: 1, $ANO: 1, $XSPEED: 0, $YSPEED: 0, $XACCEL: 0, $YACCEL: 0, $XSPEED_A: 0, $YSPEED_A: 0, $XACCEL_A: 0, $YACCEL_A: 0, $COMP: 0, $WALL: 0, $VOZ: 0},\n      },\n   },\n"
                + "   $HDAT_30:{$info:{$COL: 0, $ROW: 0, $SZ: &00000000}},\n"
                + "   $HDAT_31:{$info:{$COL: 14, $ROW: 0, $SZ: &00000000},\n      $REACAO_DANO_17:{\n      },\n   },\n"
                + "   $HDAT_32:{$info:{$COL: 14, $ROW: 0, $SZ: &00000000},\n   },\n}\n";
        boolean[] f = new boolean[1];
        String r1 = Saver.patchReaction(a, two, 16, f);
        check("slot sem bloco: criado dentro do HDAT_30", f[0] && Saver.findBlock(r1, "REACAO_DANO_16") != null, true);
        int[] hb = Saver.findBlock(r1, "HDAT_30");
        String h30 = r1.substring(hb[0], hb[2] + 1);
        check("info do HDAT_30 corrigida (COL 14, ROW 2, SZ 0x1C)", h30.contains("$COL: 14") && h30.contains("$ROW: 2") && h30.contains("$SZ: &0000001C"), true);
        check("virgula depois do $info", h30.replaceAll("\\s", "").contains("&0000001C},$REACAO_DANO_16"), true);
        check("os outros blocos ficam como estavam", Saver.findBlock(r1, "REACAO_DANO_15") != null && r1.contains("$HDAT_31:{$info:{$COL: 14, $ROW: 0"), true);
        String r2 = Saver.patchReaction(r1, two, 17, f);
        int[] hb31 = Saver.findBlock(r2, "HDAT_31");
        check("bloco existente mas vazio: preenchido e ROW 2", f[0] && r2.substring(hb31[0], hb31[2] + 1).contains("$ROW: 2") && r2.substring(hb31[0], hb31[2] + 1).contains("$FR_1"), true);
        String r3 = Saver.patchReaction(r2, two, 18, f);
        check("HDAT_32 com info e chaves em linhas separadas", f[0] && Saver.findBlock(r3, "REACAO_DANO_18") != null, true);
        String r4 = Saver.patchReaction(r3, two, 19, f);
        check("nem o HDAT_33 existe: nao grava e avisa (found = false), texto igual", !f[0] && r4.equals(r3), true);
        check("slots gravaveis = HDAT_14+n que existem", Saver.writableReactionSlots(a).toString(), "[15, 16, 17, 18]");
        String r5 = Saver.patchReaction(a, bl, 15, f);
        check("bloco existente continua sendo trocado (regressao)", f[0] && r5.contains("$DUR_C: 6") && r5.indexOf("$FR_0") == r5.lastIndexOf("$FR_0"), true);

        // ---- ida e volta: o app le de volta o que gravou (applyBinTxt)
        File tmp = new File(System.getProperty("java.io.tmpdir"), "reaction_slots_test");
        del(tmp);
        File dir = new File(tmp, "assets/char07");
        dir.mkdirs();
        java.nio.file.Files.write(new File(dir, "000.bin").toPath(), bin(rs));
        Saver.write(new File(dir, "000.bin.txt"), r3);
        CharData back = ReactionSlots.readChar(dir);
        ReactionTable b16 = back.reaction(16);
        check("importar de outro personagem: o slot que estava vazio no .bin vem do .bin.txt", b16.rows + ":" + b16.s8(1, 2) + ":" + b16.u8(1, 1), "2:-4:255");
        check("os preenchidos do .bin continuam", back.reaction(0).rows == 1 && back.reaction(5).rows == 2, true);
        check("e os vazios sem bloco continuam vazios", ReactionSlots.isEmpty(back.reaction(19)) && ReactionSlots.isEmpty(back.reaction(3)), true);
        del(tmp);

        System.out.println("ReactionSlotsTest fails=" + BattleTest.fails);
    }
}
