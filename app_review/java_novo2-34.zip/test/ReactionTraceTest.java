package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** ReactionTrace: o que a simulacao real faz com uma reacao (passos, duracoes de chao/ar, velocidade, deslocamento) + operacoes de passo da tabela. */
public class ReactionTraceTest {
    static BattleSim sim(byte[][] charReactions, int oppHeight) throws Exception {
        A[] atk = new A[10];
        for (int i = 0; i < 10; i++) atk[i] = new A().mpt(new M().time(5));
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(3)).mpt(new M().time(3));
        CharData ch = chr(move(new int[]{0, 4}, new int[]{2, 3}), charReactions);
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}) });
        int old = BattleSim.oppHeightPx;
        BattleSim.oppHeightPx = oppHeight;
        try {
            BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, 200, 0, 0);
            s.reset();
            return s;
        } finally { BattleSim.oppHeightPx = old; }
    }

    public static void main(String[] args) throws Exception {
        byte[][] rs = new byte[3][];
        // 0: passo 0 = 4 ticks no chao / 9 no ar (ANO 3, vx = 10 -> 1 px/tick), passo 1 = 3 / 5 (ANO 4, velocidade mantem)
        rs[0] = react(new int[]{4, 9, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}, new int[]{3, 5, 4, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0});
        // 1: um passo "ate pousar" (255) com vy = 40 (4 px/tick para baixo no ar)
        rs[1] = react(new int[]{255, 255, 5, 0, 0, 0, 0, 0, 40, 0, 0, 0, 0, 0});

        // ---- chao: cada passo dura DUR_C ticks e a velocidade anda 1 px/tick desde o primeiro tick
        ReactionTrace g = ReactionTrace.record(sim(rs, 0), 30, 300);
        check("chao: 2 passos da tabela 0 do personagem", g.segments.size() + ":" + g.of(true, 0).size(), "2:2");
        check("chao: duracoes = DUR_C (4 e 3)", g.segments.get(0).length() + ":" + g.segments.get(1).length(), "4:3");
        check("chao: passos em sequencia, sem buraco", g.segments.get(0).start + ":" + g.segments.get(0).end + ":" + g.segments.get(1).start, "0:4:4");
        check("chao: a reacao acaba sozinha", g.ended && g.ticks.size() == 7, true);
        boolean keeps = true;
        for (BattleSim.DamageTick t : g.ticks) keeps &= t.xs == 128;
        check("velocidade -1 (mantem) segue com a do passo anterior (10 -> 128 unidades)", keeps, true);
        check("deslocamento total = 1 px/tick x 7 ticks (o defensor esta virado: anda para tras)", Math.abs(g.displacement(g.ticks.size())[0]) + ":" + g.displacement(g.ticks.size())[1], "7:0");
        check("deslocamento parcial (ate o fim do passo 0) = 4 px", Math.abs(g.displacement(g.segments.get(0).end)[0]), 4);
        check("o passo mostra o estado que o tick processou (1o tick: tempo 0, passo 0)", g.ticks.get(0).row + ":" + g.ticks.get(0).time + ":" + g.segments.get(1).flip, "0:0:true");

        // ---- no ar (oponente 60 px acima): vale DUR_A (9 e 5)
        ReactionTrace a = ReactionTrace.record(sim(rs, 60), 30, 300);
        check("ar: duracoes = DUR_A (9 e 5)", a.segments.get(0).length() + ":" + a.segments.get(1).length(), "9:5");
        check("ar: parte de y = -60 e fica no ar (sem velocidade vertical)", a.startY + ":" + a.ticks.get(a.ticks.size() - 1).y, "-60:-60");

        // ---- 255 ate pousar: cai 4 px/tick e a linha continua
        ReactionTrace f = ReactionTrace.record(sim(rs, 60), 31, 300);
        check("255: a linha 0 dura ate o limite de 255 ticks", f.segments.get(0).type + ":" + f.segments.get(0).row + ":" + f.segments.get(0).length(), "1:0:255");
        boolean landed = false;
        for (BattleSim.DamageTick t : f.ticks) if (t.y == 0) landed = true;
        check("255: o defensor pousa (y chega a 0) a 4 px/tick", landed && f.ticks.get(0).y == -56 && f.ticks.get(13).y == -4 && f.ticks.get(14).y == 0, true);
        check("limite de ticks: para onde mandar", ReactionTrace.record(sim(rs, 60), 31, 20).ticks.size() + ":" + ReactionTrace.record(sim(rs, 60), 31, 20).ended, "20:false");

        // ---- candidata num slot vazio (previa antes de gravar): overrideCharReaction
        ReactionTable cand = new ReactionTable(react(new int[]{6, 6, 3, 20, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0}, new int[]{2, 2, 4, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0}), 0);
        BattleSim es = sim(rs, 0);
        ReactionTrace none = ReactionTrace.record(es, 35, 300);
        check("slot 5 vazio: sem tabela nao ha passos", none.segments.size(), 0);
        BattleSim os = sim(rs, 0);
        os.overrideCharReaction(5, cand);
        ReactionTrace ov = ReactionTrace.record(os, 35, 300);
        check("override: a candidata toca no slot 5 (2 passos de 6 e 2 ticks)", ov.segments.size() + ":" + ov.segments.get(0).length() + ":" + ov.segments.get(1).length(), "2:6:2");
        check("override: velocidade 2 px/tick desde o primeiro tick", Math.abs(ov.displacement(ov.ticks.size())[0]), 16);
        BattleSim os2 = sim(rs, 0);
        os2.overrideCharReaction(5, cand);
        ReactionTrace other = ReactionTrace.record(os2, 30, 300);
        check("override num slot nao muda os outros (slot 0 intacto)", other.segments.get(0).length() + ":" + other.segments.size(), "4:2");
        os2.overrideCharReaction(5, null);
        check("override removido volta ao slot vazio", ReactionTrace.record(os2, 35, 300).segments.size(), 0);

        // ---- operacoes de passo da tabela
        ReactionTable t = new ReactionTable(react(new int[]{1, 1, 1}, new int[]{2, 2, 2}, new int[]{3, 3, 3}), 0);
        t.duplicateRow(1);
        check("duplicar o passo 1", t.rows + ":" + t.u8(0, 2) + t.u8(1, 2) + t.u8(2, 2) + t.u8(3, 2), "4:1223");
        t.moveRow(3, 0);
        check("mover o passo 3 para o inicio", "" + t.u8(0, 2) + t.u8(1, 2) + t.u8(2, 2) + t.u8(3, 2), "3122");
        t.moveRow(0, 99);
        check("mover para alem do fim prende no ultimo", "" + t.u8(0, 2) + t.u8(1, 2) + t.u8(2, 2) + t.u8(3, 2), "1223");
        t.moveRow(1, 1);
        t.moveRow(9, 0);
        t.duplicateRow(9);
        check("mover para o mesmo lugar ou de linha inexistente nao muda", t.rows + ":" + t.u8(1, 2), "4:2");
        t.removeRow(0);
        check("remover o passo 0", t.rows + ":" + t.u8(0, 2) + t.u8(1, 2) + t.u8(2, 2), "3:223");

        System.out.println("ReactionTraceTest fails=" + BattleTest.fails);
    }
}
