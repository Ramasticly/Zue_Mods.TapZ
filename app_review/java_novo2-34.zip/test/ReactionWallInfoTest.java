package com.zue.attackeditor;

import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** (i) das thumbs de reacao: como a reacao trata parede (WALL) e pouso (COMP). */
public class ReactionWallInfoTest {
    static ReactionTable tab(int[][] rows) {      // cada linha: {ano, wall, comp}
        ReactionTable t = ReactionTable.blank();
        while (t.rows < rows.length) t.insertRow(t.rows - 1);
        for (int r = 0; r < rows.length; r++) { t.set(r, 2, rows[r][0]); t.set(r, 12, rows[r][1]); t.set(r, 11, rows[r][2]); }
        return t;
    }

    static String text(List<AttackInfo.Line> l) {
        StringBuilder b = new StringBuilder();
        for (AttackInfo.Line x : l) b.append(x.text).append('\n');
        return b.toString();
    }

    static ReactionWallInfo.Lookup lk(final ReactionTable[] game, final ReactionTable[] chr) {
        return new ReactionWallInfo.Lookup() {
            public ReactionTable game(int t) { return t >= 0 && t < game.length ? game[t] : null; }
            public ReactionTable chr(int i) { return i >= 0 && i < chr.length ? chr[i] : null; }
        };
    }

    public static void main(String[] args) throws Exception {
        ReactionTable[] game = new ReactionTable[30];
        for (int i = 0; i < 30; i++) game[i] = tab(new int[][]{{20 + i, 0, 0}});
        game[12] = tab(new int[][]{{44, 0, 0}});
        game[14] = null;                                  // vazia
        ReactionTable[] chr = new ReactionTable[20];
        chr[3] = tab(new int[][]{{77, 0, 0}});
        ReactionWallInfo.Lookup lk = lk(game, chr);

        // WALL 0 e COMP 0 em tudo: nao muda a animacao
        String s0 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 0, 0}, {6, 0, 0}}), false, 3, lk));
        check("WALL 0: 'nao muda a animacao'", s0.startsWith("Parede: não muda a animação"), true);
        check("WALL 0 e COMP 0: nenhuma linha de passo", s0.split("\n").length, 1);

        // WALL 2 + COMP 13 em reacao do jogo: reinicia em Jogo 13 (ANO 33), no chao quica em Jogo 12 (ANO 44)
        String s1 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 0, 0}, {6, 2, 13}}), false, 3, lk));
        check("WALL 2 + COMP 13: resumo 'muda a animacao'", s1.startsWith("Parede: muda a animação"), true);
        check("passo 2 reinicia em Jogo 13 (ANO 33)", s1.contains("Passo 2: na parede reinicia em Jogo 13 (ANO 33)."), true);
        check("no chao quica em Jogo 12 (ANO 44)", s1.contains("No chão, em vez disso, quica em Jogo 12 (ANO 44)."), true);
        check("reacao do jogo: so no limite do cenario e sem subir", s1.contains("limite do cenário e se o oponente não estiver subindo"), true);
        check("passo 1 (WALL 0, COMP 0) nao gera linha", s1.contains("Passo 1"), false);

        // reacao do personagem: WALL 3 vale em qualquer borda; WALL 2 so no limite
        String s2 = text(ReactionWallInfo.lines(tab(new int[][]{{9, 3, 33}}), true, 31, lk));
        check("personagem WALL 3 + COMP 33 reinicia em Personagem 3 (ANO 77)", s2.contains("Passo 1: na parede reinicia em Personagem 3 (ANO 77)."), true);
        check("WALL 3 vale em qualquer borda", s2.contains("WALL 3 vale em qualquer borda da tela"), true);
        String s2b = text(ReactionWallInfo.lines(tab(new int[][]{{9, 2, 33}}), true, 31, lk));
        check("WALL 2 so no limite do cenario", s2b.contains("WALL 2, reação do personagem"), true);

        // WALL 2/3 sem COMP util: a parede nao faz nada
        String s3 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 0}, {5, 3, 60}}), false, 3, lk));
        check("WALL 2 sem COMP: nao faz nada", s3.contains("Passo 1: WALL 2 sem um COMP de 1 a 49 — a parede não faz nada."), true);
        check("WALL 3 com COMP 60: nao faz nada", s3.contains("Passo 2: WALL 3 sem um COMP de 1 a 49"), true);
        check("sem passo com parede ativa: resumo 'nao muda'", s3.startsWith("Parede: não muda a animação"), true);

        // WALL 1: camera
        String s4 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 1, 0}}), false, 3, lk));
        check("WALL 1: camera acompanha", s4.contains("WALL 1 — a animação não muda; se o oponente já bateu na parede, a câmera acompanha."), true);

        // pouso: 11, 12, N, 50+
        String s5 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 0, 11}, {5, 0, 12}, {5, 0, 20}, {5, 0, 255}}), false, 3, lk));
        check("COMP 11 deita", s5.contains("Passo 1: ao pousar fica caído (ANO 24)"), true);
        check("COMP 12 quica e levanta com botao", s5.contains("Passo 2: ao pousar quica em Jogo 12 (ANO 44); se o jogador apertar botão no ar, levanta (ANO 22)."), true);
        check("COMP 20 vai para Jogo 20 (ANO 40)", s5.contains("Passo 3: ao pousar vai para Jogo 20 (ANO 40)."), true);
        check("COMP 255 so pousa", s5.contains("Passo 4: ao pousar só toca o pouso (ANO 13) e termina."), true);

        // agrupamento de passos iguais seguidos
        String s6 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 13}, {6, 2, 13}, {7, 2, 13}, {8, 0, 0}}), false, 3, lk));
        check("passos 1 a 3 iguais viram uma so linha 'Passos 1–3'", s6.contains("Passos 1–3: na parede reinicia em Jogo 13 (ANO 33)."), true);
        check("uma so linha de parede", s6.split("reinicia em Jogo 13").length, 2);

        // avisos
        String w1 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 0, 35}}), false, 3, lk));
        check("COMP 35 em reacao do jogo: tabela inexistente", w1.contains("⚠ Passo 1: COMP 35 em reação do jogo lê uma tabela que não existe."), true);
        String w2 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 14}}), false, 3, lk));
        check("destino vazio", w2.contains("⚠ Passo 1: Jogo 14 está vazia (sem passos)."), true);
        String w3 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 3}}), false, 3, lk));
        check("aponta para si mesma (laco)", w3.contains("é esta mesma reação (reinicia em laço)"), true);
        String w4 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 33}}), true, 33, lk));
        check("personagem 3 apontando para Personagem 3 = laco", w4.contains("Personagem 3 é esta mesma reação"), true);
        String w5 = text(ReactionWallInfo.lines(tab(new int[][]{{5, 0, 31}}), true, 30, lk));
        check("personagem COMP 31 sem tabela (vazia)", w5.contains("Personagem 1 está vazia"), true);

        // tabela vazia / sem lookup
        check("reacao vazia", text(ReactionWallInfo.lines(null, false, 1, lk)).startsWith("Reação vazia"), true);
        check("sem lookup: ANO desconhecida '?'", text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 13}}), false, 3, null)).contains("Jogo 13 (ANO ?)"), true);
        // fontes: dado da tabela = BIN, regra do jogo = CODE
        List<AttackInfo.Line> ls = ReactionWallInfo.lines(tab(new int[][]{{5, 2, 13}}), false, 3, lk);
        check("cores: resumo RED (muda na parede), passo BIN, regra CODE", ls.get(0).src == AttackInfo.RED && ls.get(1).src == AttackInfo.BIN && ls.get(2).src == AttackInfo.CODE, true);
        check("resumo DIM quando a parede nao muda", ReactionWallInfo.lines(tab(new int[][]{{5, 0, 0}}), false, 3, lk).get(0).src, AttackInfo.DIM);
        check("hasWallReaction: WALL 2 + COMP 13", ReactionWallInfo.hasWallReaction(tab(new int[][]{{5, 0, 0}, {6, 2, 13}})), true);
        check("hasWallReaction: WALL 3 + COMP 49", ReactionWallInfo.hasWallReaction(tab(new int[][]{{5, 3, 49}})), true);
        check("hasWallReaction: WALL 2 sem COMP / COMP 50 / WALL 1 / WALL 0", ReactionWallInfo.hasWallReaction(tab(new int[][]{{5, 2, 0}, {5, 2, 50}, {5, 1, 13}, {5, 0, 13}})), false);
        check("hasWallReaction: nulo e vazia", ReactionWallInfo.hasWallReaction(null) + "," + ReactionWallInfo.hasWallReaction(new ReactionTable(new byte[0], 0)), "false,false");

        // traducao: o texto montado (rotulos ja traduzidos na hora de montar) sai coerente em EN e ES
        I18n.set(I18n.EN);
        String en = text(ReactionWallInfo.lines(tab(new int[][]{{5, 2, 13}}), false, 3, lk));
        StringBuilder enT = new StringBuilder();
        for (AttackInfo.Line x : ReactionWallInfo.lines(tab(new int[][]{{5, 2, 13}}), false, 3, lk)) enT.append(I18n.tr(x.text)).append('\n');
        I18n.set(I18n.PT);
        check("EN: passo e destino traduzidos", enT.toString().contains("Step 1: on the wall restarts in Game 13 (ANO 33)."), true);
        check("EN: resumo", enT.toString().startsWith("Wall: changes the animation"), true);
        check("o texto montado em EN usa os rotulos EN", en.contains("Step 1: ") || en.contains("Passo 1: "), true);
    }
}
