package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Botao ↻: escolha do item selecionado depois de recarregar as pastas, e textos do dialogo nos tres idiomas. */
public class ReloadTest {
    public static void main(String[] args) {
        List<String> a = Arrays.asList("char00", "char01", "char02");
        check("pasta continua: mantem o indice", FolderReload.resolve(a, "char01"), 1);
        check("pasta continua: kept", FolderReload.kept(a, "char01"), true);
        List<String> b = Arrays.asList("char00", "char02");
        check("pasta apagada: volta ao primeiro", FolderReload.resolve(b, "char01"), 0);
        check("pasta apagada: kept = false", FolderReload.kept(b, "char01"), false);
        List<String> c = Arrays.asList("char00", "char01", "char02", "char03");
        check("pasta nova no meio muda o indice mas mantem o nome", FolderReload.resolve(Arrays.asList("char00", "char005x", "char01"), "char01"), 2);
        check("pasta nova no fim nao muda nada", FolderReload.resolve(c, "char02"), 2);
        check("sem selecao anterior: primeiro", FolderReload.resolve(a, null), 0);
        check("lista vazia: -1", FolderReload.resolve(new ArrayList<String>(), "char00"), -1);
        check("lista nula: -1", FolderReload.resolve(null, "char00"), -1);
        check("kept sem selecao anterior", FolderReload.kept(a, null), false);
        check("clamp dentro", FolderReload.clamp(3, 10), 3);
        check("clamp acima do tamanho novo", FolderReload.clamp(12, 10), 9);
        check("clamp negativo", FolderReload.clamp(-1, 10), 0);
        check("clamp sem itens", FolderReload.clamp(2, 0), -1);

        int old = I18n.lang();
        check("dialogo EN", I18n.trTo("Recarregar as pastas?", I18n.EN) + "|" + I18n.trTo("RECARREGAR", I18n.EN), "Reload the folders?|RELOAD");
        check("dialogo ES", I18n.trTo("Recarregar as pastas?", I18n.ES) + "|" + I18n.trTo("RECARREGAR", I18n.ES), "¿Recargar las carpetas?|RECARGAR");
        check("toast com numero EN", I18n.trTo("Pastas recarregadas: 5 personagens", I18n.EN), "Folders reloaded: 5 characters");
        check("toast com numero ES", I18n.trTo("Pastas recarregadas: 5 personagens", I18n.ES), "Carpetas recargadas: 5 personajes");
        check("pasta sumiu EN", I18n.trTo("A pasta char01 não existe mais; abrindo char00", I18n.EN), "The folder char01 no longer exists; opening char00");
        check("pasta sumiu ES", I18n.trTo("A pasta char01 não existe mais; abrindo char00", I18n.ES), "La carpeta char01 ya no existe; abriendo char00");
        I18n.set(old);
        System.out.println("ReloadTest fails=" + fails);
    }
}
