package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** REPOSICIONAR: acha distancia e altura do oponente em que a hitbox (atacante parado no fim do frame) cai dentro da hurtbox; so isso muda. */
public class RepositionHitTest {
    /** Golpe 0: ANO 40, frame 1 com hitbox x..x+w a y; oponente com hurtbox -10..10 x -60..0. */
    static BattleSim held(int dist, int oppH, int hx, int hy, int hw, int hh) throws Exception {
        A[] atk = new A[60];
        for (int i = 0; i < atk.length; i++) atk[i] = new A().mpt(new M().time(5).img(1));
        atk[40] = new A().mpt(new M().time(2).img(1)).mpt(new M().time(3).img(1).hit(2, hx, hy, hw, hh).opt1(30)).mpt(new M().time(4).img(1)).mpt(new M().time(30).img(1));
        A[] def = new A[30];
        for (int i = 0; i < 30; i++) def[i] = new A().mpt(new M().time(3).img(1).hit(1, -10, -60, 20, 60)).mpt(new M().time(3).img(1).hit(1, -10, -60, 20, 60));
        byte[][] rs = new byte[1][];
        rs[0] = react(new int[]{6, 6, 3, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0});
        CharData ch = chr(move(new int[]{2, 40}, new int[]{10, 41}), rs);
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}) });
        int old = BattleSim.oppHeightPx;
        BattleSim.oppHeightPx = oppH;
        try {
            BattleSim s = new BattleSim(dac(atk), ch, ch.moves[0], false, dac(def), dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4))), g, dist, 0, 0);
            s.setReactionMode(true, 40, 1);
            for (int i = 0; i < 300 && !s.attackerHeld(); i++) s.step();
            return s.attackerHeld() ? s : null;
        } finally { BattleSim.oppHeightPx = old; }
    }

    public static void main(String[] args) throws Exception {
        BattleSim.defend = false;
        RepositionHit.SimFactory f = new RepositionHit.SimFactory() {
            public BattleSim held(int d, int h) { try { return RepositionHitTest.held(d, h, 20, -40, 250, 20); } catch (Exception e) { throw new RuntimeException(e); } }
        };
        check("longe (600) e no ar (100): nao cruza", RepositionHit.overlaps(f.held(480, 100)), false);
        int[] r = RepositionHit.solve(f, 480, 100, false, 4);
        check("reposicionar acha uma posicao", r != null, true);
        check("a posicao achada cruza (hitbox dentro da hurtbox)", r != null && RepositionHit.overlaps(f.held(r[0], r[1])), true);
        check("a distancia diminuiu (de 480) e fica dentro do alcance da hitbox (<= 270)", r != null && r[0] < 480 && r[0] <= 270, true);
        check("altura volta a ~0 (a hitbox esta rente ao chao)", r != null && r[1] <= 10, true);
        int[] ok = RepositionHit.solve(f, 140, 0, false, 4);
        check("ja cruzando: devolve a mesma posicao", ok != null && ok[0] == 140 && ok[1] == 0, true);
        // hitbox muito alta (y -400): a altura maxima 200 nao alcanca
        RepositionHit.SimFactory high = new RepositionHit.SimFactory() {
            public BattleSim held(int d, int h) { try { return RepositionHitTest.held(d, h, 20, -420, 250, 20); } catch (Exception e) { throw new RuntimeException(e); } }
        };
        check("hitbox fora do alcance de altura: null (nao mexe)", RepositionHit.solve(high, 300, 0, false, 4), null);
        // hitbox 20..270 e a mesma, mas facingLeft usa sinal oposto no passo
        BattleSim s = f.held(480, 0);
        int[] st = RepositionHit.step(s, 480, 0, false);
        check("passo para a direita: a distancia diminui", st != null && st[0] < 480, true);
        // worldRect: mesmo que o jogo
        AttackSim.Obj a = s.attacker().root();
        int[] wr = BattleSim.worldRect(a, a.hits[0]);
        check("worldRect: largura e altura da caixa", (wr[2] - wr[0]) + ":" + (wr[3] - wr[1]), "250:20");
        System.out.println("RepositionHitTest fails=" + fails);
    }
}
