package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import static com.zue.attackeditor.BattleTest.*;

/** REESCALAR com revisao por ANO: passos sprite x ANO, "depois" so nos Frames da sprite naquela ANO, aceitar/pular, padrao intocado. */
public class RescaleReviewTest {
    static Ano.Mpt mpt(int image, int zoom) { return CenterTest.mpt(image, zoom); }

    public static void main(String[] args) throws Exception {
        // ANO 0: Parado (img 0); ANO 1: usa 2 e 3; ANO 2 vazia (ausente); ANO 3: usa 2 (duas vezes) e 4; ANO 4: so 3
        Ano a0 = new Ano(0, true, 0, 0, null, new Ano.Mpt[]{mpt(0, 150), mpt(1, 100)});
        Ano a1 = new Ano(1, true, 0, 0, null, new Ano.Mpt[]{mpt(2, 100), mpt(3, 100), mpt(2, 100)});
        Ano a2 = new Ano(2, false, 0, 0, null, new Ano.Mpt[0]);
        Ano a3 = new Ano(3, true, 0, 0, null, new Ano.Mpt[]{mpt(4, 100), mpt(2, 100), mpt(2, 100)});
        Ano a4 = new Ano(4, true, 0, 0, null, new Ano.Mpt[]{mpt(3, 100)});
        Dac d = CenterTest.dac(a0, a1, a2, a3, a4);
        final int[][] size = {{40, 80}, {30, 60}, {20, 40}, {50, 50}, {10, 10}};
        Centralize.Sizes sz = new Centralize.Sizes() { public int[] logical(int i) { return i >= 0 && i < size.length ? size[i] : null; } };

        // passos
        List<RescaleReview.Step> st = RescaleReview.steps(d, set(3, 2));
        check("passos: sprite 2 (ANOs 1 e 3) e depois a 3 (ANOs 1 e 4), em ordem", st.toString(), "[SPR_2/ANO 1, SPR_2/ANO 3, SPR_3/ANO 1, SPR_3/ANO 4]");
        check("ANO ausente nao entra", RescaleReview.steps(d, set(9)).size(), 0);
        check("sprite sem uso aparece em 'unused'", RescaleReview.unused(d, set(2, 9, 4)).toString(), "[9]");
        check("framesUsing", RescaleReview.framesUsing(a1, 2) + "," + RescaleReview.framesUsing(a3, 2) + "," + RescaleReview.framesUsing(a2, 2) + "," + RescaleReview.framesUsing(null, 2), "2,2,0,0");
        check("sem DAC / sem sprites: nenhum passo", RescaleReview.steps(null, set(2)).size() + "," + RescaleReview.steps(d, null).size(), "0,0");

        // planos
        double refH = Centralize.refHeight(d, sz);                       // 80 x 150% = 120
        Map<Integer, Centralize.Plan> plans = new HashMap<Integer, Centralize.Plan>();
        plans.put(Integer.valueOf(2), Centralize.plan(refH, 20, 40));    // zoom 300, MID (-30,-120)
        plans.put(Integer.valueOf(3), Centralize.plan(refH, 50, 50));    // zoom 240, MID (-60,-120)

        // "depois": so a sprite do passo e so nessa ANO
        RescaleReview.Step s = st.get(0);                                // SPR_2 na ANO 1
        Dac after = RescaleReview.afterDac(d, s, plans.get(Integer.valueOf(2)));
        Ano n1 = after.getAno(1);
        check("depois: os 2 Frames da sprite 2 na ANO 1 reescalados", SpriteDefaults.read(n1.mpts[0]).zx + "," + SpriteDefaults.read(n1.mpts[2]).zx + "," + SpriteDefaults.read(n1.mpts[0]).midY, "300,300,-120");
        check("depois: o Frame da sprite 3 na mesma ANO nao muda", SpriteDefaults.read(n1.mpts[1]).isNeutral(), true);
        check("depois: outras ANOs com a sprite 2 nao mudam", SpriteDefaults.read(after.getAno(3).mpts[1]).isNeutral(), true);
        check("o DAC original nao muda", SpriteDefaults.read(d.getAno(1).mpts[0]).isNeutral(), true);
        check("passo sem Frame da sprite: o mesmo DAC", RescaleReview.afterDac(d, new RescaleReview.Step(2, 4), plans.get(Integer.valueOf(2))) == d, true);
        check("resumo do primeiro Frame", RescaleReview.summary(a1, 2, plans.get(Integer.valueOf(2))), "zoom 100% → 300%  ·  MID (0, 0) → (-30, -120)");

        // aceitar so alguns passos
        List<RescaleReview.Step> accepted = new ArrayList<RescaleReview.Step>();
        accepted.add(st.get(1));                                          // SPR_2/ANO 3
        accepted.add(st.get(3));                                          // SPR_3/ANO 4
        int[] cnt = new int[1];
        TreeSet<Integer> ch = RescaleReview.apply(d, accepted, plans, cnt);
        check("aplicou 2 passos: 3 Frames em 2 ANOs (3 e 4)", cnt[0] + ":" + ch, "3:[3, 4]");
        check("ANO 3: sprites 2 reescaladas, a 4 nao", SpriteDefaults.read(d.getAno(3).mpts[1]).zx + "," + SpriteDefaults.read(d.getAno(3).mpts[2]).zx + "," + SpriteDefaults.read(d.getAno(3).mpts[0]).isNeutral(), "300,300,true");
        check("ANO 4: sprite 3 reescalada (zoom 240)", SpriteDefaults.read(d.getAno(4).mpts[0]).zx + "," + SpriteDefaults.read(d.getAno(4).mpts[0]).midX, "240,-60");
        check("ANO 1 (pulada) nao mudou", SpriteDefaults.read(d.getAno(1).mpts[0]).isNeutral() && SpriteDefaults.read(d.getAno(1).mpts[1]).isNeutral(), true);
        check("o Parado (ANO 0) nao mudou", SpriteDefaults.read(d.getAno(0).mpts[0]).zx, 150);

        // rotacao, alpha e flips ficam
        Ano.Mpt rot = mpt(2, 100);
        rot.flags |= 0x80; rot.rot = 25; rot.alphaRaw = 40; rot.xZoom = 100; rot.yZoom = 100; rot.normalize();
        Ano ar = new Ano(0, true, 0, 0, null, new Ano.Mpt[]{rot});
        SpriteDefaults.Def r = SpriteDefaults.read(RescaleReview.afterAno(ar, 2, plans.get(Integer.valueOf(2))).mpts[0]);
        check("rotacao 25 e alpha 40 continuam", r.rot + "," + r.alpha + "," + r.zx, "25,40,300");

        // nenhum aceito = nada muda
        Dac d2 = CenterTest.dac(a0, a1, a2, a3, a4);
        check("nenhum passo aceito: nada", RescaleReview.apply(d2, new ArrayList<RescaleReview.Step>(), plans, null).size(), 0);
        check("plano ausente: ignora o passo", RescaleReview.apply(d2, st, new HashMap<Integer, Centralize.Plan>(), null).size(), 0);
    }

    static TreeSet<Integer> set(Integer... v) { return new TreeSet<Integer>(java.util.Arrays.asList(v)); }
}
