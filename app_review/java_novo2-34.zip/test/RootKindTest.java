package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** ANO de projetil/efeito aberto sozinho no editor: nao e o personagem (sem pouso 13, queda 89 nem sombra); no chao segue o md 971. */
public class RootKindTest {
    static BattleSim run(int kind, int projChao, int steps) throws Exception {
        A[] a = SpawnDiagTest.anos();
        a[40] = new A().mpt(new M().time(30).speedY(2 << 16));
        a[50] = new A().mpt(new M().time(20));
        CharData ch = chr(move(new int[]{2, 40}, new int[]{40, projChao}), new byte[][] {});
        CharData.Move mv = CharData.genericFrom(40, ch.moves[0]);
        mv.rootKind = kind;
        BattleSim s = SpawnDiagTest.sim(dac(a), ch, mv, 200, 0, 0);
        for (int i = 0; i < steps; i++) s.step();
        return s;
    }

    static boolean hasShadow(BattleSim s) {
        for (BattleSim.Layer l : s.layers()) if (l.owner == BattleSim.OWNER_SHADOW) return true;
        return false;
    }

    public static void main(String[] args) throws Exception {
        // personagem avulso: ao tocar o chao pousa (ANO 13), como sempre
        BattleSim c = run(CharData.Move.ROOT_CHAR, 0, 4);
        check("personagem avulso: pousa no ANO 13", c.attacker().root().ano.index, 13);

        // projetil sem PROJETIL_COLISAO_CHAO: continua no mesmo ANO, y preso ao chao, velocidade intacta
        BattleSim p = run(CharData.Move.ROOT_PROJ, 0, 4);
        check("projetil: continua no ANO 40", p.attacker().root().ano.index, 40);
        check("projetil: y preso ao chao", p.attacker().root().y, 0);
        check("projetil: velocidade Y nao e zerada", p.attacker().root().speedY, 2 << 16);
        check("projetil: sem sombra de lutador", hasShadow(p), false);

        // com PROJETIL_COLISAO_CHAO = 50: troca para esse ANO
        BattleSim q = run(CharData.Move.ROOT_PROJ, 50, 4);
        check("projetil com COLISAO_CHAO: vai para o ANO 50", q.attacker().root().ano.index, 50);
        check("projetil com COLISAO_CHAO: y no chao", q.attacker().root().y <= 0, true);
        BattleSim q2 = run(CharData.Move.ROOT_PROJ, 50, 12);
        check("depois de trocar fica no ANO 50 (nao volta nem pousa no 13)", q2.attacker().root() == null || q2.attacker().root().ano.index == 50, true);

        // efeito: nada de chao
        BattleSim e = run(CharData.Move.ROOT_EFFECT, 50, 6);
        check("efeito: continua no ANO 40", e.attacker().root().ano.index, 40);
        check("efeito: atravessa o chao (sem clamp)", e.attacker().root().y > 0, true);
        check("efeito: sem sombra", hasShadow(e), false);

        // quem e quem quando o ANO e aberto sozinho
        CharData ch = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{40, 31}), new byte[][] {});
        check("ANIM_INICIAL = personagem", ch.rootKindOf(40), CharData.Move.ROOT_CHAR);
        check("PROJETIL_ANIM_NORMAL = projetil", ch.rootKindOf(30), CharData.Move.ROOT_PROJ);
        check("PROJETIL_COLISAO_CHAO = projetil", ch.rootKindOf(31), CharData.Move.ROOT_PROJ);
        check("ANO 201..255 = efeito", ch.rootKindOf(210), CharData.Move.ROOT_EFFECT);
        check("ANO qualquer = personagem", ch.rootKindOf(5), CharData.Move.ROOT_CHAR);
        check("copia mantem o tipo", CharData.genericFrom(30, null).copy().rootKind, CharData.Move.ROOT_CHAR);
        CharData.Move cm = new CharData.Move(); cm.rootKind = CharData.Move.ROOT_EFFECT;
        check("copy() copia rootKind", cm.copy().rootKind, CharData.Move.ROOT_EFFECT);
        System.out.println("RootKindTest fails=" + fails);
    }
}
