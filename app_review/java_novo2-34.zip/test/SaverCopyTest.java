package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;

/** Salvar em pasta separada: copia completa do personagem para Tap Battle/TBRE/Chars e a mesma gravacao do Runtime na copia. */
public class SaverCopyTest {
    static void put(File f, String text) throws Exception { f.getParentFile().mkdirs(); Saver.write(f, text); }

    public static void main(String[] args) throws Exception {
        File tb = new File(System.getProperty("java.io.tmpdir"), "savercopy_test_tapbattle");
        Saver.deleteTree(tb);
        File src = new File(tb, "assets/char03");
        A[] anos = new A[6];
        for (int i = 0; i < 6; i++) anos[i] = new A().mpt(new M().time(5).img(1));
        Dac dac = dac(anos);
        CharData cd = chr(move(new int[]{0, 4}, new int[]{2, 3}), new byte[][] {});
        put(new File(src, "000.dac.txt"), Saver.dacText(dac, null));
        put(new File(src, "000.bin.txt"), "BIN_CNV_ {\n" + DacText.move(cd.moves[0], 0) + "\n}\n");
        put(new File(src, "000.cnv.txt"), "CNV_TXT_ {\n}\n");
        put(new File(src, "000.dac"), "binario");
        put(new File(src, "000.png"), "folha");
        put(new File(src, "sons/001.wav"), "wav1");
        put(new File(src, "salvos/velho.txt"), "arquivo da pasta antiga");
        String dac0 = Saver.readText(new File(src, "000.dac.txt")), bin0 = Saver.readText(new File(src, "000.bin.txt"));

        File dst = Saver.separateDir(src, src.getName());
        check("pasta separada = Tap Battle/TBRE/Chars/char03", dst.getPath().endsWith("savercopy_test_tapbattle/TBRE/Chars/char03"), true);
        final int[] last = new int[2];
        Saver.copyChar(src, dst, false, new Saver.CopyProgress() { public void on(String f, int done, int total) { last[0] = done; last[1] = total; } });
        check("copia completa: txt, binario, folha e subpasta", new File(dst, "000.dac.txt").isFile() && new File(dst, "000.bin.txt").isFile() && new File(dst, "000.dac").isFile()
                && new File(dst, "000.png").isFile() && new File(dst, "sons/001.wav").isFile() && new File(dst, "000.cnv.txt").isFile(), true);
        check("a velha pasta salvos/ nao vai", new File(dst, "salvos").exists(), false);
        check("progresso chegou ao fim (6 arquivos, sem o de salvos/)", last[0] + "/" + last[1], "6/6");
        check("conteudo igual", Saver.readText(new File(dst, "000.png")).equals("folha") && Saver.readText(new File(dst, "sons/001.wav")).equals("wav1"), true);

        // salvar golpe 0 na copia: altera o golpe do HDAT 4 e nao toca no original
        cd.moves[0].animInicial = 4;
        String r = Saver.saveInto(dst, dac, cd, 0, 0, 0);
        String binCopy = Saver.readText(new File(dst, "000.bin.txt"));
        check("a copia recebeu o golpe editado", binCopy.replaceAll("\\s", "").contains("$ANIM_INICIAL:4,"), true);
        check("o original continua igual", Saver.readText(new File(src, "000.bin.txt")).equals(bin0) && Saver.readText(new File(src, "000.dac.txt")).equals(dac0), true);
        check("resumo do salvamento", r.contains("1 golpe(s)"), true);

        // ANO: edita o ANO 2 em memoria e salva so ele
        Ano a2 = dac.getAno(2);
        Ano.Mpt[] m2 = a2.mpts.clone();
        m2[0] = m2[0].copy();
        m2[0].time = 77;
        dac.setAno(2, new Ano(2, true, a2.flags, a2.priority, a2.links, m2));
        String r2 = Saver.saveInto(dst, dac, cd, 1, 0, 2);
        check("salvar ANO 2 na copia", Saver.readText(new File(dst, "000.dac.txt")).contains("$TIME: 77") && !Saver.readText(new File(src, "000.dac.txt")).contains("$TIME: 77") && r2.contains("1 ANO(s)"), true);
        String all = Saver.saveInto(dst, dac, cd, 4, 0, 0);
        check("salvar tudo na copia", all.contains("6 ANO(s)") && all.contains("golpe(s)"), true);

        // unir: nao sobrescreve o que ja esta na copia, so acrescenta o que falta
        put(new File(dst, "000.png"), "folha editada na copia");
        new File(dst, "sons/001.wav").delete();
        Saver.copyChar(src, dst, true, null);
        check("unir: arquivo existente fica como esta", Saver.readText(new File(dst, "000.png")), "folha editada na copia");
        check("unir: arquivo que faltava volta", new File(dst, "sons/001.wav").isFile(), true);
        Saver.copyChar(src, dst, false, null);
        check("sem unir: sobrescreve", Saver.readText(new File(dst, "000.png")), "folha");

        // outro nome e delecao segura
        check("nome livre: char03_2, depois char03_3", Saver.freeName(src, "char03"), "char03_2");
        new File(Saver.separateDir(src, "char03_2"), "x").mkdirs();
        check("nome livre pula o existente", Saver.freeName(src, "char03"), "char03_3");
        check("so pastas dentro de TBRE/Chars podem ser apagadas", Saver.isSeparateCopy(dst) + ":" + Saver.isSeparateCopy(src) + ":" + Saver.isSeparateCopy(new File(tb, "TBRE/Chars")), "true:false:false");
        Saver.deleteTree(dst);
        check("deletar a copia", dst.exists() + ":" + src.exists(), "false:true");

        Saver.deleteTree(tb);
        System.out.println("SaverCopyTest fails=" + BattleTest.fails);
    }
}
