package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

/** $src do CNV = indice da folha na lista dos PNG da pasta (nao o numero do nome). */
public class SheetFilesTest {
    static File dir(String... names) throws Exception {
        File d = Files.createTempDirectory("sheets").toFile();
        for (String n : names) Files.write(new File(d, n).toPath(), new byte[]{1});
        return d;
    }

    static String names(List<File> l) { StringBuilder b = new StringBuilder(); for (File f : l) b.append(f.getName()).append(' '); return b.toString().trim(); }

    public static void main(String[] args) throws Exception {
        File a = dir("000.png", "001.png", "002.png", "000.cnv", "000.cnv.txt", "ano_000.txt", "foto.png", "SPR_1.png", "003.png.tmp", "000.wav");
        check("contiguo: 3 folhas, so NNN.png", names(SheetFiles.list(a)), "000.png 001.png 002.png");
        check("contiguo: indice = numero", SheetFiles.file(a, 2).getName(), "002.png");

        // o caso do relato: 017.png, 018.cnv, 019.png
        String[] n = new String[20];
        int k = 0;
        for (int i = 0; i <= 17; i++) n[k++] = String.format("%03d.png", i);
        n[k++] = "018.cnv";
        n[k++] = "019.png";
        File b = dir(java.util.Arrays.copyOf(n, k));
        check("017/018.cnv/019: 19 folhas PNG", SheetFiles.count(b), 19);
        check("$src:17 = 017.png", SheetFiles.file(b, 17).getName(), "017.png");
        check("$src:18 = 019.png (o 018 e o cnv, nao um PNG)", SheetFiles.file(b, 18).getName(), "019.png");
        check("$src:19 nao existe", SheetFiles.file(b, 19), null);
        check("indice negativo", SheetFiles.file(b, -1), null);

        File c = dir("019.png", "001.png", "017.png");
        check("ordem pelo numero, nao pela criacao", names(SheetFiles.list(c)), "001.png 017.png 019.png");
        File up = dir("017.PNG", "018.png");
        check("maiuscula conta", names(SheetFiles.list(up)), "017.PNG 018.png");
        check("pasta inexistente", SheetFiles.list(new File("/nao/existe/x")).size() + ":" + SheetFiles.file(new File("/nao/existe/x"), 0), "0:null");
        check("pasta nula", SheetFiles.count(null), 0);

        check("nextNumber contiguo", SheetFiles.nextNumber(dir("000.png", "001.png", "002.png", "003.png", "004.png")), 5);
        check("nextNumber com buraco", SheetFiles.nextNumber(dir("000.png", "001.png", "019.png")), 20);
        check("nextNumber vazio", SheetFiles.nextNumber(dir()), 0);
        check("nome de folha", SheetFiles.name(5) + ":" + SheetFiles.name(120), "005.png:120.png");
        check("isSheetName", SheetFiles.isSheetName("017.png") + ":" + SheetFiles.isSheetName("17.png") + ":" + SheetFiles.isSheetName("017.png.tmp") + ":" + SheetFiles.isSheetName("a017.png"), "true:false:false:false");
        check("numberOf", SheetFiles.numberOf("019.png") + ":" + SheetFiles.numberOf("foto.png"), "19:-1");
        System.out.println("SheetFilesTest fails=" + fails);
    }
}
