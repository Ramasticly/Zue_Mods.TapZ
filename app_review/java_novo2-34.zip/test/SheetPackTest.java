package com.zue.attackeditor;

import java.util.List;
import java.util.Random;
import java.util.TreeSet;
import static com.zue.attackeditor.BattleTest.*;

/** Compactar folhas: sprites das folhas do fim vao para vaos das folhas do inicio, sem sobrepor e sem criar folha. */
public class SheetPackTest {
    static SpriteAlloc.Sheets sheets(final int n, final int w, final int h) {
        return new SpriteAlloc.Sheets() {
            public int count() { return n; }
            public int width(int s) { return w; }
            public int height(int s) { return h; }
        };
    }

    static boolean overlap(Cnv.Entry a, Cnv.Entry b) {
        return a.source == b.source && a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height;
    }

    public static void main(String[] args) throws Exception {
        // ---- exemplo do usuario: folha 0 (200x200 logicos, escala 2 = 400 px) com a faixa livre da direita; sprite 30x30 numa folha de tras
        Cnv c = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 200, 150}, {0, 0, 150, 200, 50}, {1, 0, 0, 30, 30}});
        // folha 0: ocupada ate a direita e a base inteira: sem vao. Abre-se um vao de 70x50 ao tirar o pedaco da direita:
        c = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 130, 200}, {0, 130, 0, 70, 150}, {1, 0, 0, 30, 30}});
        // vao: (130,150) 70x50
        List<SheetPack.Move> mv = SheetPack.plan(c, sheets(2, 400, 400), 2, 0, null);
        check("a sprite 30x30 da folha 1 vai para o vao 70x50 da folha 0", mv.size() + ":" + mv.get(0).toSheet + ":" + mv.get(0).fromSheet, "1:0:1");
        check("recorte novo dentro do vao", c.byImage(2).source + "," + (c.byImage(2).x >= 130) + "," + (c.byImage(2).y >= 150), "0,true,true");
        check("a folha 1 ficou sem sprite", SheetPurge.referenced(c, 1), false);
        check("e entra em 'sem referencia'", SheetPurge.unreferenced(c, 2, java.util.Arrays.asList(Integer.valueOf(1))).toString(), "[1]");
        check("idempotente: nada mais a mover", SheetPack.plan(c, sheets(2, 400, 400), 2, 0, null).size(), 0);

        // ---- nao cabe: fica onde esta
        Cnv big = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 130, 200}, {0, 130, 0, 70, 150}, {1, 0, 0, 80, 60}});
        check("sprite maior que o vao nao se mexe", SheetPack.plan(big, sheets(2, 400, 400), 2, 0, null).size() + ":" + big.byImage(2).source, "0:1");

        // ---- a primeira folha que couber vence
        Cnv first = SheetPurgeTest.cnv(new int[][]{
                {0, 0, 0, 200, 150}, {0, 0, 150, 100, 50},        // folha 0: vao (100,150) 100x50
                {1, 0, 0, 200, 150}, {1, 0, 150, 100, 50},        // folha 1: mesmo vao
                {2, 0, 0, 20, 20}});
        SheetPack.plan(first, sheets(3, 400, 400), 2, 0, null);
        check("entre duas folhas com vao, vai para a mais antiga (0)", first.byImage(4).source, 0);

        // ---- maiores primeiro: a maior fica com o vao que so ela enche
        Cnv order = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 200, 150}, {0, 0, 150, 60, 50}, {1, 0, 0, 20, 20}, {1, 30, 0, 60, 50}});
        SheetPack.plan(order, sheets(2, 400, 400), 2, 0, null);
        check("a sprite 60x50 ocupa o vao 140x50 e a 20x20 cabe junto", order.byImage(3).source + ":" + order.byImage(2).source, "0:0");
        for (int i = 0; i < order.size(); i++) for (int j = i + 1; j < order.size(); j++) check("sem sobrepor " + i + "/" + j, overlap(order.byImage(i), order.byImage(j)), false);

        // ---- recortes identicos andam juntos
        Cnv twin = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 200, 150}, {1, 0, 0, 30, 30}, {1, 0, 0, 30, 30}});
        List<SheetPack.Move> tw = SheetPack.plan(twin, sheets(2, 400, 400), 2, 0, null);
        check("as duas sprites com o mesmo recorte viram um movimento so", tw.size() + ":" + tw.get(0).sprites.length, "1:2");
        check("e continuam com o mesmo recorte", twin.byImage(1).source + "," + twin.byImage(1).x + "," + twin.byImage(1).y + "|" + twin.byImage(2).x + "," + twin.byImage(2).y,
                twin.byImage(1).source + "," + twin.byImage(1).x + "," + twin.byImage(1).y + "|" + twin.byImage(1).x + "," + twin.byImage(1).y);

        // ---- sobreposicao parcial: nao mexe; marcada como fixa: nao mexe
        Cnv part = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 200, 150}, {1, 0, 0, 30, 30}, {1, 20, 20, 30, 30}});
        check("recortes que se sobrepoem em parte ficam", SheetPack.plan(part, sheets(2, 400, 400), 2, 0, null).size(), 0);
        Cnv fx = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 200, 150}, {1, 0, 0, 30, 30}});
        check("sprite marcada fixa fica", SheetPack.plan(fx, sheets(2, 400, 400), 2, 0, new boolean[]{false, true}).size(), 0);
        Cnv out = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 200, 150}, {1, 190, 190, 30, 30}});
        check("recorte que sai da folha fica", SheetPack.plan(out, sheets(2, 400, 400), 2, 0, null).size(), 0);

        // ---- nunca cria folha e nunca leva para folha de tras
        Cnv back = SheetPurgeTest.cnv(new int[][]{{0, 0, 0, 20, 20}, {1, 0, 0, 20, 20}});
        SheetPack.plan(back, sheets(2, 400, 400), 2, 0, null);
        check("a sprite da folha 0 nunca vai para tras", back.byImage(0).source, 0);

        // ---- aleatorio: nada sobreposto nem fora da folha, sprites nunca vao para tras, idempotente, area preservada
        Random r = new Random(7);
        for (int round = 0; round < 60; round++) {
            int nSheets = 2 + r.nextInt(5), side = 256 + r.nextInt(3) * 128, scale = 1 + r.nextInt(2);
            int lw = side / scale;
            java.util.ArrayList<int[]> es = new java.util.ArrayList<int[]>();
            for (int s = 0; s < nSheets; s++) {
                int k = 1 + r.nextInt(6);
                for (int t = 0; t < k; t++) {
                    int w = 8 + r.nextInt(lw / 2), h = 8 + r.nextInt(lw / 2), x = r.nextInt(lw - w), y = r.nextInt(lw - h);
                    boolean clash = false;
                    for (int[] o : es) if (o[0] == s && x < o[1] + o[3] && o[1] < x + w && y < o[2] + o[4] && o[2] < y + h) clash = true;
                    if (!clash) es.add(new int[]{s, x, y, w, h});
                }
            }
            Cnv rc = SheetPurgeTest.cnv(es.toArray(new int[0][]));
            int[] src0 = new int[rc.size()];
            long area0 = 0;
            for (int i = 0; i < rc.size(); i++) { src0[i] = rc.byImage(i).source; area0 += (long) rc.byImage(i).width * rc.byImage(i).height; }
            SpriteAlloc.Sheets sh = sheets(nSheets, side, side);
            SheetPack.plan(rc, sh, scale, 1, null);
            boolean bad = false, back2 = false, outside = false, areaOk = true;
            long area1 = 0;
            for (int i = 0; i < rc.size(); i++) {
                Cnv.Entry a = rc.byImage(i);
                area1 += (long) a.width * a.height;
                if (a.source > src0[i]) back2 = true;
                if (a.x < 0 || a.y < 0 || a.x + a.width > lw || a.y + a.height > lw || a.source >= nSheets) outside = true;
                for (int j = i + 1; j < rc.size(); j++) if (overlap(a, rc.byImage(j))) bad = true;
            }
            if (area1 != area0) areaOk = false;
            check("aleatorio " + round + ": sem sobrepor", bad, false);
            check("aleatorio " + round + ": dentro da folha", outside, false);
            check("aleatorio " + round + ": nenhuma vai para folha de tras", back2, false);
            check("aleatorio " + round + ": tamanhos preservados", areaOk, true);
            check("aleatorio " + round + ": idempotente", SheetPack.plan(rc, sh, scale, 1, null).size(), 0);
        }
    }
}
