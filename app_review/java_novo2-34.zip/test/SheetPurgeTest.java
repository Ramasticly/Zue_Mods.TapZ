package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeSet;
import static com.zue.attackeditor.BattleTest.*;

/** Excluir sprite na folha: retangulo apagado, folha sem sprite sai, CNV renumerado e o espaco liberado volta a ser alocavel. */
public class SheetPurgeTest {
    static Cnv cnv(int[][] e) throws Exception {          // {source, x, y, w, h}
        byte[] d = new byte[e.length * Cnv.ENTRY_SIZE];
        for (int i = 0; i < e.length; i++) System.arraycopy(Cnv.encode(e[i][0], e[i][1], e[i][2], e[i][3], e[i][4]), 0, d, i * Cnv.ENTRY_SIZE, Cnv.ENTRY_SIZE);
        return Cnv.read(d, false);
    }

    public static void main(String[] args) throws Exception {
        Cnv c = cnv(new int[][]{{0, 10, 20, 30, 40}, {1, 0, 0, 16, 16}, {2, 100, 100, 50, 50}});
        // ---- retangulo em pixels
        check("retangulo x2: (20,40) 60 x 80", Arrays.toString(SheetPurge.rect(c.byImage(0), 2, 512, 512)), "[20, 40, 60, 80]");
        check("retangulo x1", Arrays.toString(SheetPurge.rect(c.byImage(0), 1, 512, 512)), "[10, 20, 30, 40]");
        check("recorte que passa da folha e cortado", Arrays.toString(SheetPurge.rect(c.byImage(2), 2, 220, 230)), "[200, 200, 20, 30]");
        check("recorte inteiro fora da folha = nada", SheetPurge.rect(c.byImage(2), 2, 150, 150) == null, true);
        check("entrada vazia = nada", SheetPurge.rect(cnv(new int[][]{{0, 0, 0, 0, 0}}).byImage(0), 2, 512, 512) == null, true);

        // ---- folhas sem sprite
        check("a folha 1 so tem a sprite 1", SheetPurge.referenced(c, 1) + ":" + SheetPurge.referenced(c, 3), "true:false");
        Cnv after = cnv(new int[][]{{0, 10, 20, 30, 40}, {1, 0, 0, 16, 16}, {2, 100, 100, 50, 50}});
        after.removeShift(new boolean[]{false, true, false});                 // exclui a sprite 1 (remove a entrada e renumera as sprites)
        TreeSet<Integer> un = SheetPurge.unreferenced(after, 3, Arrays.asList(Integer.valueOf(1)));
        check("tocada e sem referencia -> sai", un.toString(), "[1]");
        check("tocada mas ainda referenciada -> fica", SheetPurge.unreferenced(after, 3, Arrays.asList(Integer.valueOf(0))).isEmpty(), true);
        check("nao tocada nunca sai (mesmo sem sprites)", SheetPurge.unreferenced(after, 5, Arrays.asList(Integer.valueOf(4))).toString(), "[4]");
        // a regra 'so as tocadas' e do chamador: aqui a folha 4 foi tocada de proposito. Folha nao listada nao entra:
        check("folha nao listada nao entra", SheetPurge.unreferenced(after, 5, new ArrayList<Integer>()).isEmpty(), true);
        SheetPurge.renumberSources(after, 1);
        check("$src das seguintes desce 1 (a folha 2 vira 1); as anteriores ficam", after.byImage(0).source + ":" + after.byImage(1).source, "0:1");
        Cnv multi = cnv(new int[][]{{0, 0, 0, 8, 8}, {3, 0, 0, 8, 8}, {4, 0, 0, 8, 8}});       // as folhas 1 e 2 ficaram sem sprites e saem (a maior primeiro)
        SheetPurge.renumberSources(multi, 2);
        SheetPurge.renumberSources(multi, 1);
        check("duas folhas retiradas (2 e depois 1): 0, 3 -> 1, 4 -> 2", multi.byImage(0).source + "," + multi.byImage(1).source + "," + multi.byImage(2).source, "0,1,2");
        Cnv emptyOne = cnv(new int[][]{{3, 0, 0, 0, 0}, {3, 5, 5, 8, 8}});
        SheetPurge.renumberSources(emptyOne, 1);
        check("entrada vazia nao e renumerada", emptyOne.byImage(0).source + ":" + emptyOne.byImage(1).source, "3:2");

        // ---- varredura: tudo fora dos recortes fica transparente
        Cnv two = cnv(new int[][]{{0, 0, 0, 10, 10}, {0, 20, 0, 10, 10}});        // folha 0: duas sprites logicas 10x10 em (0,0) e (20,0)
        java.util.List<int[]> out = SheetPurge.outsideRects(two, 0, 2, 64, 40);       // folha 64x40 px = 32x20 logicos
        long area = 0;
        for (int[] r : out) area += (long) r[2] * r[3];
        check("area fora dos recortes = folha (64x40) - 2 sprites de 20x20 px", area, 64L * 40 - 2 * 20 * 20);
        boolean overlap = false;
        for (int i = 0; i < out.size(); i++) for (int j = i + 1; j < out.size(); j++) {
            int[] p = out.get(i), q = out.get(j);
            if (p[0] < q[0] + q[2] && q[0] < p[0] + p[2] && p[1] < q[1] + q[3] && q[1] < p[1] + p[3]) overlap = true;
        }
        check("os retangulos de fora nao se sobrepoem", overlap, false);
        int[] px = new int[64 * 40];
        java.util.Arrays.fill(px, 0xFFFF0000);                                       // folha toda opaca
        boolean dirty = false;
        for (int[] r : out) dirty |= SheetPurge.hasPixels(px, 64, 40, r);
        check("pixels fora dos recortes sao detectados", dirty, true);
        for (int[] r : out) SheetPurge.clear(px, 64, 40, r);
        boolean inside = (px[5 * 64 + 5] >>> 24) != 0 && (px[5 * 64 + 45] >>> 24) != 0, outsideClear = (px[25 * 64 + 5] >>> 24) == 0 && (px[5 * 64 + 25] >>> 24) == 0 && (px[39 * 64 + 63] >>> 24) == 0;
        check("depois: dentro das sprites segue opaco, fora ficou transparente", inside + ":" + outsideClear, "true:true");
        boolean again = false;
        for (int[] r : out) again |= SheetPurge.hasPixels(px, 64, 40, r);
        check("folha ja limpa nao e marcada de novo", again, false);
        check("sprites que cobrem a folha toda: nada fora", SheetPurge.outsideRects(cnv(new int[][]{{0, 0, 0, 32, 20}}), 0, 2, 64, 40).isEmpty(), true);
        check("folha de largura impar (65 px, escala 2) fica dentro da folha", SheetPurge.outsideRects(cnv(new int[][]{{0, 0, 0, 10, 10}}), 0, 2, 65, 40).get(0)[2] <= 65, true);

        // ---- o espaco liberado volta a ser alocavel (sprite do mesmo tamanho cai no mesmo retangulo)
        final Cnv sheet = cnv(new int[][]{{0, 0, 0, 100, 100}, {0, 100, 0, 100, 100}, {0, 0, 100, 100, 100}, {0, 100, 100, 100, 100}});
        SpriteAlloc.Sheets sh = new SpriteAlloc.Sheets() {
            public int count() { return 1; }
            public int width(int s) { return 400; }
            public int height(int s) { return 400; }
        };
        SpriteAlloc.Spot full = SpriteAlloc.find(sheet, sh, 2, 100, 100, 0);
        check("folha cheia (200x200 logicos de 4 sprites de 100): a sprite nova precisa de folha nova", full.newSheet, true);
        sheet.removeShift(new boolean[]{false, true, false, false});             // exclui a sprite 1, que ocupava (100, 0)
        SpriteAlloc.Spot back = SpriteAlloc.find(sheet, sh, 2, 100, 100, 0);
        check("depois da exclusao a nova cai no espaco liberado (folha 0, x 100, y 0)", !back.newSheet && back.sheet == 0 && back.x == 100 && back.y == 0, true);
        SpriteAlloc.Spot small = SpriteAlloc.find(sheet, sh, 2, 60, 40, 0);
        check("uma sprite menor tambem cabe no espaco liberado", !small.newSheet && small.sheet == 0 && small.x >= 100 && small.y < 100, true);
    }
}
