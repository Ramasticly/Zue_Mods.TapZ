package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Ids do SE (byte sem sinal) x arquivos de som global (se_NN / se_NNN), placeholders e limites. */
public class SoundIdsTest {
    static Set<Integer> set(int... a) { Set<Integer> s = new HashSet<Integer>(); for (int x : a) s.add(Integer.valueOf(x)); return s; }

    public static void main(String[] args) throws Exception {
        check("id 0 nao toca nada", SoundIds.commonOf(0), -1);
        check("id 1 = se_00", SoundIds.commonOf(1), 0);
        check("id 79 = se_78", SoundIds.commonOf(79), 78);
        check("id 80 e do personagem", SoundIds.isCharId(80) && SoundIds.commonOf(80) == -1, true);
        check("id 99 e do personagem (o 20o)", SoundIds.isCharId(99) && SoundIds.commonOf(99) == -1, true);
        check("id 100 = se_99", SoundIds.commonOf(100), 99);
        check("id 101 = se_100", SoundIds.commonOf(101), 100);
        check("id 255 = se_254 (o ultimo)", SoundIds.commonOf(255), 254);
        check("id 256 nao existe", SoundIds.commonOf(256), -1);
        check("id negativo nao existe", SoundIds.commonOf(-1), -1);
        check("idOfCommon", SoundIds.idOfCommon(100), 101);

        check("nome com 2 digitos", SoundIds.fileName(7), "se_07.ogg");
        check("nome de 99", SoundIds.fileName(99), "se_99.ogg");
        check("nome com 3 digitos a partir do 100", SoundIds.fileName(100), "se_100.ogg");
        check("nome 254", SoundIds.fileName(254), "se_254.ogg");
        check("reconhece se_07.ogg", SoundIds.isFileName("se_07.ogg"), true);
        check("reconhece se_100.ogg", SoundIds.isFileName("se_100.ogg"), true);
        check("nao reconhece se_7.ogg", SoundIds.isFileName("se_7.ogg"), false);
        check("nao reconhece se_1000.ogg", SoundIds.isFileName("se_1000.ogg"), false);
        check("nao reconhece bgm_01.ogg", SoundIds.isFileName("bgm_01.ogg"), false);
        check("numero de se_07", SoundIds.numberOf("se_07.ogg"), 7);
        check("numero de se_100", SoundIds.numberOf("se_100.ogg"), 100);
        check("numero de nome invalido", SoundIds.numberOf("x.ogg"), -1);

        check("selecionaveis: 0..78 e 99..254, nao os de preenchimento 79..98", SoundIds.selectable(78) && !SoundIds.selectable(79) && !SoundIds.selectable(98)
                && SoundIds.selectable(99) && SoundIds.selectable(254) && !SoundIds.selectable(255), true);

        check("primeiro som global do app sem nenhum", SoundIds.nextNew(-1), 0);
        check("depois do se_50 vem o se_51", SoundIds.nextNew(50), 51);
        check("depois do se_77 vem o se_78", SoundIds.nextNew(77), 78);
        check("depois do se_78 pula para o se_100", SoundIds.nextNew(78), 100);
        check("com preenchimento ate o 90 tambem vai ao 100", SoundIds.nextNew(90), 100);
        check("com o se_99 vai ao 100", SoundIds.nextNew(99), 100);
        check("depois do se_100 vem o 101", SoundIds.nextNew(100), 101);
        check("depois do se_253 vem o 254", SoundIds.nextNew(253), 254);
        check("depois do se_254 acabou (255 ids)", SoundIds.nextNew(254), -1);

        Set<Integer> orig = new HashSet<Integer>();
        for (int i = 0; i <= 78; i++) orig.add(Integer.valueOf(i));
        check("novo se_100 com os 79 originais: 21 preenchimentos (79..99)", SoundIds.placeholders(orig, 100).size(), 21);
        check("o primeiro e o ultimo preenchimento", SoundIds.placeholders(orig, 100).get(0) + ".." + SoundIds.placeholders(orig, 100).get(20), "79..99");
        orig.addAll(SoundIds.placeholders(orig, 100));
        orig.add(Integer.valueOf(100));
        check("o proximo (se_101) nao precisa de preenchimento", SoundIds.placeholders(orig, 101).size(), 0);
        check("buraco abaixo do novo tambem e preenchido", SoundIds.placeholders(set(0, 1, 3), 4).toString(), "[2]");

        // lista de ids do stepper do frame
        check("sem sons novos: 0..seMax e os audios do personagem", SoundIds.frameIds(5, 2).toString(), "[0, 1, 2, 3, 4, 5, 80, 81]");
        check("com sons novos: 0..79, personagem, 100..seMax", SoundIds.frameIds(102, 1).size(), 80 + 1 + 3);
        check("os audios do personagem param em 20", SoundIds.frameIds(0, 30).size(), 1 + 20);
        check("teto 255", SoundIds.frameIds(400, 0).get(SoundIds.frameIds(400, 0).size() - 1), 255);
        check("FrameTools.stepSound passa de 79 para o primeiro audio do personagem", FrameTools.stepSound(79, 1, 102, 2), 80);
        check("e do ultimo audio do personagem para o 100", FrameTools.stepSound(81, 1, 102, 2), 100);
        check("e volta do 100 para o audio do personagem", FrameTools.stepSound(100, -1, 102, 2), 81);

        // $SE e byte sem sinal: 200 sobrevive ao DAC em texto
        Ano.Mpt m = new Ano.Mpt();
        m.hasTime = true; m.time = 5; m.flags = 0x28; m.se = 200; m.image = 1;
        Ano an = new Ano(40, true, 0, 0, new Ano.Link[0], new Ano.Mpt[]{m});
        String txt = DacText.ano(an, -1);
        check("$SE: 200 sai no texto", txt.contains("$SE: 200"), true);
        Ano back = DacText.parseAno(txt, 40, null);
        check("$SE: 200 volta do texto", back.mpts[0].se, 200);
        boolean bad = false;
        try { DacText.parseAno(txt.replace("$SE: 200", "$SE: 300"), 40, null); } catch (Exception e) { bad = true; }
        check("$SE: 300 e recusado", bad, true);
        bad = false;
        try { DacText.parseAno(txt.replace("$SE: 200", "$SE: -2"), 40, null); } catch (Exception e) { bad = true; }
        check("$SE negativo e recusado", bad, true);
        // o simulador toca o arquivo certo para cada id
        A[] aa = SpawnDiagTest.anos();
        aa[40] = new A().mpt(new M().time(3).se(150)).mpt(new M().time(3).se(85)).mpt(new M().time(3).se(100)).mpt(new M().time(3).se(8)).mpt(new M().time(3).se(255));
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim bs = SpawnDiagTest.sim(dac(aa), ch, ch.moves[0], 200, 0, 0);
        java.util.List<BattleSim.Snd> got = new java.util.ArrayList<BattleSim.Snd>(bs.drainSounds());
        for (int i = 0; i < 20; i++) { bs.step(); got.addAll(bs.drainSounds()); }
        StringBuilder sb = new StringBuilder();
        for (BattleSim.Snd x : got) sb.append(x.common ? "c" : "p").append(x.id).append(' ');
        check("SE 150 -> se_149; 85 -> audio do personagem; 100 -> se_99; 8 -> se_07; 255 -> se_254", sb.toString().trim(), "c149 p5 c99 c7 c254");
        // PCM para o codificador OGG
        short[] one = new short[22050];
        for (int i = 0; i < one.length; i++) one[i] = (short) (i % 100 * 100);
        short[] up = OggPcm.to48k(one, 22050);
        check("1 s a 22050 Hz vira 1 s a 48 kHz", up.length, 48000);
        check("o comeco da onda e preservado", up[0], one[0]);
        check("interpolacao linear entre amostras", Math.abs(up[1] - (one[0] + (one[1] - one[0]) * (22050.0 / 48000))) <= 1, true);
        check("48 kHz entra como esta", OggPcm.to48k(new short[]{1, 2, 3}, 48000).length, 3);
        check("PCM vazio", OggPcm.to48k(new short[0], 22050).length, 0);
        check("silencio de 100 ms a 48 kHz", OggPcm.silence(100).length, 4800);
        check("silencio minimo e 1 quadro de 20 ms", OggPcm.silence(1).length, 960);
        check("padTo20ms arredonda para cima", OggPcm.padTo20ms(new short[961]).length, 1920);
        check("padTo20ms nao mexe no que ja e multiplo", OggPcm.padTo20ms(new short[960]).length, 960);
        // textos da gravacao de som global
        check("aviso de preenchimento EN", I18n.trTo("O novo som global sera o se_100.ogg (id 101 no frame). O jogo carrega os se_ em sequencia, entao o app cria 21 arquivo(s) silencioso(s) (se_79.ogg a se_99.ogg) para nao ficar buraco. Eles nao aparecem na lista. Continuar?", I18n.EN),
                "The new global sound will be se_100.ogg (id 101 in the frame). The game loads the se_ files in sequence, so the app creates 21 silent file(s) (se_79.ogg to se_99.ogg) to leave no gap. They do not show in the list. Continue?");
        check("som adicionado ES", I18n.trTo("Som global adicionado: se_100.ogg (id 101).", I18n.ES), "Sonido global agregado: se_100.ogg (id 101).");
        check("erro de Android antigo EN", I18n.trTo("Nao da para gravar OGG: Precisa do Android 10 ou mais novo (o aparelho tem a API 28).", I18n.EN), "Cannot write OGG: Needs Android 10 or newer (this device has API 28).");
        // id de um som NOVO num frame: nunca 0 ("Som 0" nao toca nada); 80 = a 1a voz do personagem
        java.util.Set<Integer> none = new java.util.HashSet<Integer>(), e80 = new java.util.HashSet<Integer>(java.util.Arrays.asList(Integer.valueOf(80), Integer.valueOf(81)));
        check("defaultId: com audios do personagem = 80", SoundIds.defaultId(3, none, true), 80);
        check("defaultId: sem set de vazios = 80", SoundIds.defaultId(3, null, true), 80);
        check("defaultId: 80 e 81 vazios = 82", SoundIds.defaultId(3, e80, true), 82);
        check("defaultId: todos vazios cai no som comum 1", SoundIds.defaultId(2, e80, true), 1);
        check("defaultId: sem audios cai no comum 1", SoundIds.defaultId(0, none, true), 1);
        check("defaultId: sem nada para tocar = -1", SoundIds.defaultId(0, none, false) + "," + SoundIds.defaultId(2, e80, false), "-1,-1");
        check("defaultId: so conta ate 20 audios", SoundIds.defaultId(99, none, true), 80);
        FrameOps.soundDefault = 82;
        Ano.Mpt dm = new Ano.Mpt();
        FrameOps.defaults(FrameOps.SOM, dm);
        check("FrameOps.defaults(SOM) usa o id padrao, nao 0", dm.se + "," + ((dm.flags & 8) != 0), "82,true");
        FrameOps.soundDefault = SoundIds.CHAR_FIRST;
        Ano.Mpt dm2 = new Ano.Mpt();
        FrameOps.defaults(FrameOps.SOM, dm2);
        check("padrao inicial = 80", dm2.se, 80);
        System.out.println("SoundIdsTest fails=" + fails);
    }
}
