package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/**
 * Projetil que o golpe pede (hit flag 0) e nao nasce: o simulador copia o jogo (StartPlayerAttack escolhe PROJETIL_ANIM_NORMAL /
 * ABAIXO / ACIMA pela altura relativa; zero = nada nasce; BulletNum < 8), entao o aviso diz QUAL campo/limite falhou.
 */
public class SpawnDiagTest {
    static final int N = 60;

    static A[] anos() {
        A[] a = new A[N];
        for (int i = 0; i < N; i++) a[i] = new A().mpt(new M().time(1));
        return a;
    }

    static BattleSim sim(Dac d, CharData ch, CharData.Move mv, int dist, int atkH, int oppH) throws Exception {
        A[] def = new A[25];
        for (int i = 0; i < 25; i++) def[i] = new A().mpt(new M().time(5).hit(1, -10, -60, 20, 60));
        GameData g = gd(new byte[][] { null, null, null, react(new int[]{4, 4, 20, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0}) });
        Dac fx = dac(new A().mpt(new M().time(4)), new A().mpt(new M().time(4)));
        // oppHeightPx e estatico e fresh() (usado por measureLength) o le de novo: fica ligado ate o fim da medicao
        BattleSim.oppHeightPx = oppH;
        return new BattleSim(d, ch, mv, false, dac(def), fx, g, dist, atkH, 0);
    }

    static String problem(Dac d, CharData ch, CharData.Move mv, int dist, int atkH, int oppH) throws Exception {
        try {
            BattleSim s = sim(d, ch, mv, dist, atkH, oppH);
            check("antes da medicao nada a avisar", s.spawnProblem(), "");
            s.measureLength();
            return s.spawnProblem();
        } finally { BattleSim.oppHeightPx = 0; }
    }

    static boolean has(String s, String... parts) {
        for (String p : parts) if (!s.contains(p)) return false;
        return true;
    }

    public static void main(String[] args) throws Exception {
        A[] a = anos();
        a[40] = new A().mpt(new M().time(2).hit(0, 10, -30, 4, 4)).mpt(new M().time(20));
        a[30] = new A().mpt(new M().time(60).speedX(2 << 16).hit(2, 0, -30, 16, 20).opt1(3));
        Dac d = dac(a);

        // tudo certo: PROJETIL_ANIM_NORMAL = 30 e ANO existe
        CharData ok = chr(move(new int[]{2, 40}, new int[]{4, 30}), new byte[][] {});
        check("projetil nasce: sem aviso", problem(d, ok, ok.moves[0], 120, 0, 0), "");

        // campo NORMAL vazio
        CharData noNormal = chr(move(new int[]{2, 40}, new int[]{36, 30}), new byte[][] {});
        String p = problem(d, noNormal, noNormal.moves[0], 120, 0, 0);
        check("NORMAL vazio: aponta o campo", has(p, "PROJETIL_ANIM_NORMAL", "vazio"), true);
        BattleSim s = sim(d, noNormal, noNormal.moves[0], 120, 0, 0);
        s.measureLength();
        check("NORMAL vazio: ajuste nao e a altura", s.spawnProblemByHeight(), false);
        BattleSim.oppHeightPx = 0;

        // oponente 60 px acima do chao e atacante no chao => atacante 60 px ABAIXO => PROJETIL_ANIM_ABAIXO (offset 34) vazio
        CharData onlyNormal = chr(move(new int[]{2, 40}, new int[]{4, 30}), new byte[][] {});
        s = sim(d, onlyNormal, onlyNormal.moves[0], 120, 0, 60);
        s.measureLength();
        BattleSim.oppHeightPx = 0;
        p = s.spawnProblem();
        check("ABAIXO vazio: campo, diferenca e valor do NORMAL", has(p, "PROJETIL_ANIM_ABAIXO", "60 px abaixo", "PROJETIL_ANIM_NORMAL = 30", "POS"), true);
        check("ABAIXO vazio: resolve pela altura (botao POS)", s.spawnProblemByHeight(), true);
        // mesma situacao com o campo preenchido: nasce
        CharData withBelow = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{34, 30}), new byte[][] {});
        check("ABAIXO preenchido: sem aviso", problem(d, withBelow, withBelow.moves[0], 120, 0, 60), "");

        // atacante 40 px no ar, oponente no chao => ACIMA (offset 36)
        p = problem(d, onlyNormal, onlyNormal.moves[0], 120, 40, 0);
        check("ACIMA vazio: campo e diferenca", has(p, "PROJETIL_ANIM_ACIMA", "40 px acima"), true);
        CharData withAbove = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{36, 30}), new byte[][] {});
        check("ACIMA preenchido: sem aviso", problem(d, withAbove, withAbove.moves[0], 120, 40, 0), "");
        // dentro da faixa NORMAL (30 px acima): usa NORMAL e nasce
        check("30 px acima ainda e NORMAL: sem aviso", problem(d, onlyNormal, onlyNormal.moves[0], 120, 30, 0), "");

        // limite de 8 projeteis vivos (BulletNum < 8)
        A[] b = anos();
        A burst = new A();
        for (int i = 0; i < 12; i++) burst.mpt(new M().time(1).hit(0, 10, -30, 4, 4));
        burst.mpt(new M().time(20));
        b[40] = burst;
        b[30] = new A().mpt(new M().time(250).speedX(1 << 15));
        p = problem(dac(b), ok, ok.moves[0], 400, 0, 0);
        check("9o projetil: limite do jogo", has(p, "8 vivos", "BulletNum"), true);
        // com 8 ou menos nao avisa
        A[] c = anos();
        A few = new A();
        for (int i = 0; i < 8; i++) few.mpt(new M().time(1).hit(0, 10, -30, 4, 4));
        few.mpt(new M().time(20));
        c[40] = few;
        c[30] = b[30];
        check("8 projeteis cabem: sem aviso", problem(dac(c), ok, ok.moves[0], 400, 0, 0), "");

        // tiro triplo: ANO+1 e ANO+2 precisam existir (aqui o DAC termina no ANO 45)
        A[] t = new A[46];
        for (int i = 0; i < 46; i++) t[i] = new A().mpt(new M().time(1));
        t[40] = a[40];
        t[45] = a[30];
        CharData triple = chr(move(new int[]{0, 4}, new int[]{2, 40}, new int[]{4, 45}), new byte[][] {});
        p = problem(dac(t), triple, triple.moves[0], 120, 0, 0);
        check("tiro triplo com ANO+1 inexistente", has(p, "ANO 46", "tiro triplo"), true);
        A[] t3 = new A[48];
        for (int i = 0; i < 48; i++) t3[i] = new A().mpt(new M().time(1));
        t3[40] = a[40];
        t3[45] = a[30];
        check("tiro triplo com os 3 ANOs: sem aviso", problem(dac(t3), triple, triple.moves[0], 120, 0, 0), "");

        // projetil que aponta para ANO inexistente
        CharData ghost = chr(move(new int[]{2, 40}, new int[]{4, 58}), new byte[][] {});
        A[] g = new A[50];
        for (int i = 0; i < 50; i++) g[i] = new A().mpt(new M().time(1));
        g[40] = a[40];
        p = problem(dac(g), ghost, ghost.moves[0], 120, 0, 0);
        check("ANO do projetil nao existe", has(p, "ANO 58", "não existe"), true);

        // ANO solto, sem golpe dono: os tres campos zerados
        CharData.Move solto = CharData.genericFrom(40, null);
        p = problem(d, ok, solto, 120, 0, 0);
        check("ANO sem dono: explica", has(p, "não pertence a nenhum golpe"), true);
        // ANO com dono: herda os campos do golpe e o projetil nasce
        CharData.Move dono = CharData.genericFrom(40, ok.ownerOf(40));
        check("ANO com dono: sem aviso", problem(d, ok, dono, 120, 0, 0), "");

        // subprojetil: hit flag 0 dentro do ANO do projetil e SUBPROJETIL_ANIM_ID = 0
        A[] sp = anos();
        sp[40] = a[40];
        sp[30] = new A().mpt(new M().time(3).hit(0, 0, 0, 0, 0)).mpt(new M().time(40).speedX(1 << 16));
        p = problem(dac(sp), ok, ok.moves[0], 120, 0, 0);
        check("subprojetil sem ID", has(p, "SUBPROJETIL_ANIM_ID"), true);
        CharData withSub = chr(move(new int[]{2, 40}, new int[]{4, 30}, new int[]{18, 31}), new byte[][] {});
        sp[31] = new A().mpt(new M().time(40).speedX(1 << 16));
        check("subprojetil com ID: sem aviso", problem(dac(sp), withSub, withSub.moves[0], 120, 0, 0), "");

        // regressao do 33: o hit de projetil no frame 0 do ANO do projetil (time 1) era pulado (o app andava um frame antes do 1o _ActReq do jogo)
        for (int t0 = 1; t0 <= 3; t0++) {
            A[] q = anos();
            q[40] = a[40];
            q[30] = new A().mpt(new M().time(t0).hit(0, 0, 0, 0, 0)).mpt(new M().time(40).speedX(1 << 16));
            q[31] = new A().mpt(new M().time(40).speedX(1 << 16));
            BattleSim sq = sim(dac(q), withSub, withSub.moves[0], 300, 0, 0);
            int most = 0;
            for (int i = 0; i < 12; i++) { sq.step(); most = Math.max(most, sq.projectileCount()); }
            check("subprojetil no frame 0 do projetil (time " + t0 + ") nasce", most, 2);
        }

        // golpe sem hit de projetil nunca avisa, mesmo com os campos vazios
        A[] nh = anos();
        nh[40] = new A().mpt(new M().time(5)).mpt(new M().time(5));
        CharData none = chr(move(new int[]{2, 40}), new byte[][] {});
        check("sem hit de projetil: sem aviso", problem(dac(nh), none, none.moves[0], 120, 0, 0), "");

        System.out.println("SpawnDiagTest fails=" + BattleTest.fails);
    }
}
