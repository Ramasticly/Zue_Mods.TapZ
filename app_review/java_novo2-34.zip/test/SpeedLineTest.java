package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** SPEEDLINE: pontos da trajetoria, posicao por tick (confere com o AttackSim), arrastar so muda speed, remover/zerar e presets. */
public class SpeedLineTest {
    static final int P = 65536;

    static Ano.Mpt f(int time) { Ano.Mpt m = new Ano.Mpt(); m.flags = 0x20; m.hasTime = true; m.time = time; return m; }
    static Ano.Mpt keep(Ano.Mpt m) { m.flags |= 2; m.wActFlag |= 64; return m; }
    static Ano.Mpt mv(Ano.Mpt m, double sx, double sy, double ax, double ay) {
        if (sx != 0) m = FrameTools.setSpeed(m, 0, sx, true);
        if (sy != 0) m = FrameTools.setSpeed(m, 1, sy, true);
        if (ax != 0) m = FrameTools.setAccel(m, 0, ax);
        if (ay != 0) m = FrameTools.setAccel(m, 1, ay);
        return m;
    }

    static String pts(SpeedLine.Chain c) {
        StringBuilder b = new StringBuilder();
        for (SpeedLine.Pt p : c.pts) b.append(p.kind).append('@').append(p.frame).append(':').append(p.tick).append('(').append(FrameTools.px(p.x)).append(',').append(FrameTools.px(p.y)).append(") ");
        return b.toString().trim();
    }

    public static void main(String[] args) throws Exception {
        // um frame so: 2 pontos
        Ano.Mpt[] one = {mv(f(4), 5, 0, 0, 0), f(3)};
        List<SpeedLine.Chain> ch = SpeedLine.chains(one);
        check("1 frame de movimento = 1 cadeia com 2 pontos", ch.size() + ":" + ch.get(0).pts.size() + ":" + pts(ch.get(0)), "1:2:0@0:0(0,0) 3@1:0(20,0)");

        // frame com subida e queda (accel y): 3 pontos
        Ano.Mpt[] arc = {mv(f(6), 2, -3, 0, 1), f(2)};
        SpeedLine.Chain ca = SpeedLine.chains(arc).get(0);
        int apex = 0;
        for (SpeedLine.Pt p : ca.pts) if (p.kind == SpeedLine.APEX) apex++;
        check("altura que muda de sentido ganha 1 ponto (3 no total)", apex + ":" + ca.pts.size(), "1:3");
        check("o ponto final do arco", FrameTools.px(ca.vertex(1).x) + "," + FrameTools.px(ca.vertex(1).y), "12,-3");

        // mantem velocidade: a linha continua conectando os frames
        Ano.Mpt[] run = {mv(f(2), 10, 0, 0, 0), keep(f(2)), keep(f(3)), f(2)};
        SpeedLine.Chain cr = SpeedLine.chains(run).get(0);
        check("3 frames mantendo velocidade: 4 pontos conectados", cr.head + "-" + cr.last + ":" + cr.pts.size() + ":" + pts(cr), "0-2:4:0@0:0(0,0) 1@1:0(20,0) 1@2:0(40,0) 3@3:0(70,0)");
        check("posicao dentro de um frame", FrameTools.px(cr.posAt(run, 2, 1)[0]) + ":" + FrameTools.px(cr.posAt(run, 2, 3)[0]), "50:70");
        double[][] vs = SpeedLine.velocities(run, cr);
        check("velocidade por tick", vs[0].length + ":" + FrameTools.px(vs[0][0]) + ":" + FrameTools.px(vs[0][6]), "7:10:10");

        // dois trechos colados formam uma linha so; separados por frame parado, duas
        Ano.Mpt[] two = {mv(f(2), 4, 0, 0, 0), mv(f(2), 8, 0, 0, 0), f(2), mv(f(2), 1, 0, 0, 0)};
        check("trechos colados = 1 cadeia; depois do frame parado, outra", SpeedLine.chains(two).size() + ":" + SpeedLine.chains(two).get(0).last + ":" + SpeedLine.chains(two).get(1).head, "2:1:3");

        // confere com o AttackSim (a conta do jogo): posicao no inicio de cada frame
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            Dac d = dac(a);
            d.setAno(40, new Ano(40, true, 0, 0, new Ano.Link[0], new Ano.Mpt[] {mv(f(4), 3, -2, 0.5, 0.25), keep(f(3)), mv(keep(f(5)), 0, 0, -1, 0), f(2)}));
            Ano ano = d.getAno(40);
            SpeedLine.Chain c = SpeedLine.chains(ano.mpts).get(0);
            AttackSim sim = new AttackSim(d, 40, false);
            int x0 = sim.root().x, y0 = sim.root().y;
            StringBuilder exp = new StringBuilder(), got = new StringBuilder();
            int tick = 0;
            for (int fr = 0; fr <= 4; fr++) {
                int pat = Math.min(fr, 3);
                while (fr < 4 && sim.root().pat != pat && tick < 40) { sim.step(); tick++; }
                if (fr == 4) while (sim.root().pat == 3 && sim.root().time > 0 && tick < 60) { sim.step(); tick++; }
                SpeedLine.Pt v = c.vertex(fr);
                if (v == null) break;
                exp.append(FrameTools.px(v.x)).append(',').append(FrameTools.px(v.y)).append(' ');
                got.append(FrameTools.px((sim.root().x - x0) / (double) P)).append(',').append(FrameTools.px((sim.root().y - y0) / (double) P)).append(' ');
            }
            check("pontos do modelo = posicao do AttackSim no inicio de cada frame", got.toString().trim(), exp.toString().trim());
        }

        // arrastar: muda so a speed, nunca o TIME
        Ano.Mpt[] dr = {mv(f(4), 5, 0, 0, 0), keep(f(3)), keep(f(2)), f(1)};
        SpeedLine.Chain cd = SpeedLine.chains(dr).get(0);
        Ano.Mpt[] dd = SpeedLine.dragTo(dr, cd, 1, 40, 12);          // fim do 1o frame (4 ticks) em (40,12)
        check("arrastar: speed do frame para chegar la no mesmo tempo", dd[0].speedX / (double) P + ":" + dd[0].speedY / (double) P, "10.0:3.0");
        boolean sameTime = true;
        for (int i = 0; i < dr.length; i++) if (dd[i].time != dr[i].time || dd[i].hasTime != dr[i].hasTime) sameTime = false;
        check("arrastar nunca muda o TIME", sameTime, true);
        SpeedLine.Chain cd2 = SpeedLine.chains(dd).get(0);
        check("depois de arrastar o ponto esta onde foi solto", FrameTools.px(cd2.vertex(1).x) + "," + FrameTools.px(cd2.vertex(1).y), "40,12");
        check("os frames que mantem herdam a nova speed", FrameTools.px(cd2.vertex(2).x), "70");
        check("com aceleracao no frame, a conta desconta", FrameTools.px(SpeedLine.chains(SpeedLine.dragTo(new Ano.Mpt[] {mv(f(4), 1, 0, 1, 0), f(1)}, SpeedLine.chains(new Ano.Mpt[] {mv(f(4), 1, 0, 1, 0), f(1)}).get(0), 1, 30, 0)).get(0).vertex(1).x), "30");
        check("frame sem TIME nao e arrastavel", SpeedLine.dragTo(new Ano.Mpt[] {mv(f(0), 5, 0, 0, 0), f(2)}, SpeedLine.chains(new Ano.Mpt[] {mv(f(0), 5, 0, 0, 0), f(2)}).get(0), 1, 9, 9)[0].speedX, 5 * P);
        check("ponto 0 nao arrasta", SpeedLine.dragTo(dr, cd, 0, 9, 9), dr);

        // remover ponto do meio: o frame continua com a velocidade do anterior
        Ano.Mpt[] rp = {mv(f(2), 6, 0, 0, 0), mv(f(2), 20, 0, 0, 0), keep(f(2)), f(1)};
        SpeedLine.Chain cp = SpeedLine.chains(rp).get(0);
        check("2 pontos de frame no meio, remover o 1: sem confirmacao", SpeedLine.removesAll(cp, 1), false);
        Ano.Mpt[] r1 = SpeedLine.removePoint(rp, cp, 1);
        check("remover: o frame perde a speed propria e mantem a do anterior", FrameOps.isMoveCont(r1[1]) + ":" + FrameTools.px(FrameTools.startSpeed(r1, 1)[0]), "true:6");
        check("remover: o TIME fica", r1[1].time, 2);
        check("remover o primeiro ponto ou cadeia de 1 frame pede confirmacao", SpeedLine.removesAll(cp, 0) + ":" + SpeedLine.removesAll(SpeedLine.chains(one).get(0), 1), "true:true");
        Ano.Mpt[] ra = SpeedLine.removePoint(rp, cp, 0);
        check("remover o primeiro: sem speed nenhuma", SpeedLine.chains(ra).size(), 0);
        Ano.Mpt[] re = SpeedLine.removePoint(dr, cd, cd.frames());
        check("remover o ponto final encurta a cadeia em 1 frame", SpeedLine.chains(re).get(0).last, 1);

        // zerar speed: de verdade (sem manter e sem speed)
        Ano.Mpt[] zs = SpeedLine.zeroSpeed(dr, cd, 1);
        check("zerar: speed propria 0, sem manter", FrameTools.keeps(zs, 1) + ":" + zs[1].speedX + ":" + zs[1].speedY + ":" + FrameOps.isMoveHead(zs[1]), "false:0:0:true");
        check("zerar: os que mantem herdam 0", FrameTools.px(FrameTools.startSpeed(zs, 2)[0]), "0");

        // presets mantem o deslocamento total e a escala diminui o movimento
        Ano.Mpt[] pr = {mv(f(4), 8, -2, 0, 0), keep(f(4)), keep(f(4)), f(1)};
        SpeedLine.Chain cpr = SpeedLine.chains(pr).get(0);
        double totX = cpr.vertex(3).x, totY = cpr.vertex(3).y;
        for (int pset = 0; pset < AccelPresets.NAMES.length; pset++) {
            Ano.Mpt[] ap = AccelPresets.apply(pr, cpr, pset, 100);
            SpeedLine.Chain c2 = SpeedLine.chains(ap).get(0);
            boolean near = Math.abs(c2.vertex(3).x - totX) < 0.05 && Math.abs(c2.vertex(3).y - totY) < 0.05;
            check("preset " + pset + ": deslocamento total igual", near, true);
            boolean time = true;
            for (int i = 0; i < pr.length; i++) if (ap[i].time != pr[i].time) time = false;
            check("preset " + pset + ": TIME intacto", time, true);
        }
        Ano.Mpt[] half = AccelPresets.apply(pr, cpr, AccelPresets.DECEL_STOP, 50);
        SpeedLine.Chain ch2 = SpeedLine.chains(half).get(0);
        check("escala 50%: metade do deslocamento, mesmo padrao", Math.abs(ch2.vertex(3).x - totX / 2) < 0.05, true);
        double[][] dv = SpeedLine.velocities(AccelPresets.apply(pr, cpr, AccelPresets.DECEL_STOP, 100), cpr);
        check("desacelerar ate parar termina perto de 0", dv[0][dv[0].length - 1] < dv[0][0] * 0.2, true);
        Ano.Mpt[] ap2 = AccelPresets.apply(pr, cpr, AccelPresets.ACCEL, 100);
        check("os frames depois do primeiro mantem a velocidade", FrameTools.keeps(ap2, 1) + ":" + FrameTools.keeps(ap2, 2), "true:true");
        System.out.println("SpeedLineTest fails=" + fails);
    }
}
