package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Random;

public class SpriteAllocTest {
    static int total(java.util.List<int[]> l) { int t = 0; for (int[] r : l) t += r[2] * r[3]; return t; }
    static boolean hits(java.util.List<int[]> l, int x, int y, int w, int h) {
        for (int[] r : l) if (r[0] < x + w && x < r[0] + r[2] && r[1] < y + h && y < r[1] + r[3]) return true;
        return false;
    }

    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    public static void main(String[] args) throws Exception {
        // Cnv mutavel: ida e volta
        Cnv c = Cnv.read(new byte[9], true);
        c.set(0, 1, 10, 20, 30, 40);
        c.set(3, 2, -5, 7, 8, 9);
        Cnv r = Cnv.read(c.encode(), true);
        check("cnv cresce e codifica", r.size() == 4 && r.byImage(0).source == 1 && r.byImage(0).x == 10 && r.byImage(3).x == -5 && r.byImage(1).width == 0);
        c.clear(0);
        check("cnv clear", c.byImage(0).width == 0 && c.byImage(0).height == 0);

        // aloca muitas sprites aleatorias: nada pode se sobrepor, tudo dentro da folha
        for (int scale = 1; scale <= 2; scale++) {
            final Cnv cnv = Cnv.read(new byte[9], scale == 2);
            cnv.clear(0);
            final ArrayList<int[]> sheets = new ArrayList<int[]>();   // {w,h} fisicos
            sheets.add(new int[]{512, 512});
            SpriteAlloc.Sheets sh = new SpriteAlloc.Sheets() {
                public int count() { return sheets.size(); }
                public int width(int s) { return sheets.get(s)[0]; }
                public int height(int s) { return sheets.get(s)[1]; }
                
            };
            Random rnd = new Random(7 + scale);
            int n = 0;
            boolean ok = true;
            for (int i = 0; i < 300; i++) {
                int w = 8 + rnd.nextInt(90), h = 8 + rnd.nextInt(90);
                SpriteAlloc.Spot sp = SpriteAlloc.find(cnv, sh, scale, w, h, 1);
                if (sp.newSheet) { sheets.add(new int[]{sp.newSize, sp.newSize}); }
                int sw = sheets.get(sp.sheet)[0] / scale, shh = sheets.get(sp.sheet)[1] / scale;
                if (sp.x < 0 || sp.y < 0 || sp.x + w > sw || sp.y + h > shh) { ok = false; break; }
                for (int k = 0; k < cnv.size(); k++) {
                    Cnv.Entry e = cnv.byImage(k);
                    if (e.source != sp.sheet || e.width <= 0) continue;
                    if (sp.x < e.x + e.width && e.x < sp.x + w && sp.y < e.y + e.height && e.y < sp.y + h) { ok = false; break; }
                }
                if (!ok) break;
                cnv.set(n == 0 ? 0 : cnv.size(), sp.sheet, sp.x, sp.y, w, h);
                n++;
            }
            check("300 sprites sem sobrepor (escala " + scale + "), " + sheets.size() + " folha(s)", ok);
            long used = 0, total = 0;
            for (int[] s : sheets) total += (long) (s[0] / scale) * (s[1] / scale);
            for (int k = 0; k < cnv.size(); k++) used += (long) cnv.byImage(k).width * cnv.byImage(k).height;
            check("aproveitamento > 55% (" + (100 * used / total) + "%)", used * 100 / total > 55);
        }

        // .cnv.txt: ida e volta, personagem em pixels fisicos (x2)
        Cnv tx = Cnv.read(new byte[9], true);
        tx.set(0, 1, 10, 20, 30, 40);
        tx.set(1, 2, -5, 7, 8, 9);
        tx.clear(2);
        String txt = tx.toTxt();
        check("txt de personagem em pixels fisicos", txt.contains("$SPR_0:{$src:1, $x:20, $y:40, $w:60, $h:80},") && txt.contains("$x:-10"));
        Cnv back = Cnv.fromTxt(txt, true);
        check("txt ida e volta igual ao binario", java.util.Arrays.equals(back.encode(), tx.encode()));
        Cnv tf = Cnv.read(new byte[9], false);
        tf.set(0, 3, 1, 2, 3, 4);
        check("txt de effect sem dobrar", tf.toTxt().contains("$x:1, $y:2, $w:3, $h:4") && Cnv.fromTxt(tf.toTxt(), false).byImage(0).width == 3);

        // sprite removida (entrada zerada) libera o espaco no mapa
        final Cnv full = Cnv.read(new byte[9], true);
        full.set(0, 0, 0, 0, 128, 128);          // folha 256x256 logica toda ocupada por uma sprite
        SpriteAlloc.Sheets one = new SpriteAlloc.Sheets() {
            public int count() { return 1; }
            public int width(int s) { return 512; }
            public int height(int s) { return 512; }
        };
        SpriteAlloc.Spot sp = SpriteAlloc.find(full, one, 2, 100, 100, 1);
        check("sobra espaco na folha 128x128 -> cabe sem folha nova", !sp.newSheet);
        full.set(0, 0, 0, 0, 128, 128);
        full.set(1, 0, 0, 0, 0, 0);
        Cnv busy = Cnv.read(new byte[9], true);
        busy.set(0, 0, 0, 0, 128, 128);
        busy.set(1, 0, 128, 0, 128, 128);
        busy.set(2, 0, 0, 128, 128, 128);
        busy.set(3, 0, 128, 128, 128, 128);
        sp = SpriteAlloc.find(busy, one, 2, 20, 20, 1);
        check("folha cheia pelo mapa -> folha nova", sp.newSheet && sp.sheet == 1);
        busy.clear(3);
        sp = SpriteAlloc.find(busy, one, 2, 100, 100, 1);
        check("zerar SPR_3 libera o quadrado dela", !sp.newSheet && sp.x == 128 && sp.y == 128);
        sp = SpriteAlloc.find(busy, one, 2, 700, 100, 1);
        check("sprite grande -> folha maior (potencia de 2)", sp.newSheet && sp.newSize == 2048);

        // ---- uncovered: o que sobra do retangulo antigo depois de tirar as outras sprites
        {
            Cnv u = Cnv.read(new byte[9], false);
            u.set(0, 0, 10, 10, 20, 20);                     // a sprite que sai (ja limpa abaixo)
            u.clear(0);
            check("uncovered: sem outras entradas = o retangulo inteiro", total(SpriteAlloc.uncovered(u, 0, 10, 10, 20, 20)) == 400 && SpriteAlloc.uncovered(u, 0, 10, 10, 20, 20).size() == 1);
            u.set(1, 0, 15, 15, 10, 10);                     // outra sprite no meio
            java.util.List<int[]> mid = SpriteAlloc.uncovered(u, 0, 10, 10, 20, 20);
            check("uncovered: uma entrada no meio deixa 400-100 px, sem tocar nela", total(mid) == 300 && !hits(mid, 15, 15, 10, 10));
            u.set(2, 1, 10, 10, 20, 20);                     // outra folha nao conta
            check("uncovered: entrada de outra folha nao conta", total(SpriteAlloc.uncovered(u, 0, 10, 10, 20, 20)) == 300);
            u.set(3, 0, 0, 0, 100, 100);                     // cobre tudo
            check("uncovered: entrada que cobre tudo = nada a apagar", SpriteAlloc.uncovered(u, 0, 10, 10, 20, 20).isEmpty());
            check("uncovered: retangulo vazio = nada", SpriteAlloc.uncovered(u, 0, 10, 10, 0, 20).isEmpty());
            Cnv v = Cnv.read(new byte[9], false);
            v.clear(0);
            v.set(1, 0, 0, 0, 14, 40);                       // duas sobrepostas, cada uma cobre uma ponta
            v.set(2, 0, 10, 0, 14, 40);
            java.util.List<int[]> two = SpriteAlloc.uncovered(v, 0, 0, 0, 40, 40);
            check("uncovered: duas entradas sobrepostas = 40*40 - 24*40 = 640, sem contar duas vezes", total(two) == 640 && !hits(two, 0, 0, 24, 40));
        }
        // ---- ordem do replace: apagada a antiga, a menor assume o MESMO lugar
        {
            Cnv w2 = Cnv.read(new byte[9], false);
            w2.set(0, 0, 0, 0, 60, 60);
            w2.set(1, 0, 61, 0, 40, 40);
            final java.util.ArrayList<int[]> sh2 = new java.util.ArrayList<int[]>();
            sh2.add(new int[]{128, 128});
            SpriteAlloc.Sheets s2 = new SpriteAlloc.Sheets() {
                public int count() { return sh2.size(); }
                public int width(int s) { return sh2.get(s)[0]; }
                public int height(int s) { return sh2.get(s)[1]; }
            };
            w2.clear(0);                                     // 1) a antiga sai do mapa (e da folha)
            SpriteAlloc.Spot spot2 = SpriteAlloc.find(w2, s2, 1, 30, 30, 1);
            check("replace: a sprite menor cabe no buraco da antiga (mesma folha, canto 0,0)", !spot2.newSheet && spot2.sheet == 0 && spot2.x == 0 && spot2.y == 0);
        }
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }
}
