package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** Sprites repetidas: deteccao (igual, espelhada, girada, escalada), solucao geometrica do frame e aplicacao no DAC. */
public class SpriteDedupTest {
    /** Imagem assimetrica de w x h (quadrantes diferentes e uma marca no canto). */
    static int[] base(int w, int h) {
        int[] p = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = (x < w / 2 ? (y < h / 2 ? 0xFFE04040 : 0xFF40E040) : (y < h / 2 ? 0xFF4040E0 : 0xFFE0E040));
            if (x < w / 4 && y < h / 4) c = 0xFFFFFFFF;
            if (x > w * 3 / 4 && y > h * 3 / 4) c = 0xFF202020;
            if (x > w / 3 && x < w / 2 && y > h / 3 && y < h * 2 / 3) c = 0x00000000;
            p[y * w + x] = c;
        }
        return p;
    }

    /** K tal que R(u, v) = K(g(u, v)), com K de wK x hK (amostra R por vizinho mais proximo). */
    static int[] derive(int[] r, int wR, int hR, int g, int wK, int hK) {
        double[] gg = SpriteXform.G[g];
        int[] k = new int[wK * hK];
        for (int y = 0; y < hK; y++) for (int x = 0; x < wK; x++) {
            double a = (x + 0.5) / wK - gg[4], b = (y + 0.5) / hK - gg[5];
            double u = gg[0] * a + gg[2] * b, v = gg[1] * a + gg[3] * b;          // G^T
            int rx = Math.max(0, Math.min(wR - 1, (int) Math.floor(u * wR))), ry = Math.max(0, Math.min(hR - 1, (int) Math.floor(v * hR)));
            k[y * wK + x] = r[ry * wR + rx];
        }
        return k;
    }

    static SpriteDedup.Sig sig(int idx, int[] px, int w, int h) { return SpriteDedup.sig(idx, px, w, h, w, h); }

    static M mpt(int image) { return new M().time(4).img(image); }

    static double maxErr(SpriteXform.Frame fr, int wR, int hR, SpriteXform.Frame fk, int wK, int hK, int g) {
        double[] gg = SpriteXform.G[g];
        double worst = 0;
        for (int i = 0; i <= 4; i++) for (int j = 0; j <= 4; j++) {
            double u = i / 4.0, v = j / 4.0;
            double[] pr = SpriteXform.place(fr, wR, hR, u, v);
            double[] pk = SpriteXform.place(fk, wK, hK, gg[0] * u + gg[1] * v + gg[4], gg[2] * u + gg[3] * v + gg[5]);
            worst = Math.max(worst, Math.hypot(pr[0] - pk[0], pr[1] - pk[1]));
        }
        return worst;
    }

    public static void main(String[] args) throws Exception {
        int w = 24, h = 16;
        int[] r = base(w, h);
        // ---- deteccao
        int[] mir = derive(r, w, h, 1, w, h);
        int[] vf = derive(r, w, h, 2, w, h);
        int[] rot = derive(r, w, h, 5, h, w);
        int[] big = derive(r, w, h, 0, w * 2, h * 2);
        int[] other = new int[w * h];
        for (int i = 0; i < other.length; i++) other[i] = i % 3 == 0 ? 0xFF8080FF : 0xFF101010;
        SpriteDedup.Sig sr = sig(0, r, w, h);
        check("identica: 100", SpriteDedup.best(sig(1, r.clone(), w, h), sr, 60).score, 100);
        SpriteDedup.Match m1 = SpriteDedup.best(sig(1, mir, w, h), sr, 60);
        check("espelhada acha a relacao 1 (horizontal)", m1 != null ? m1.g : -1, 1);
        // R(u, v) = K(g(u, v)): a espelhada K tem R = K mirror => g de K para R e simetrica a g de R para K
        SpriteDedup.Match m2 = SpriteDedup.best(sr, sig(1, mir, w, h), 60);
        check("R contra a espelhada: g = 1", m2 != null ? m2.g : -1, 1);
        SpriteDedup.Match m3 = SpriteDedup.best(sr, sig(2, vf, w, h), 60);
        check("espelho vertical: g = 2", m3 != null ? m3.g : -1, 2);
        SpriteDedup.Match m4 = SpriteDedup.best(sr, sig(3, rot, h, w), 60);
        check("girada 90 (eixos trocados): g = 5", m4 != null ? m4.g : -1, 5);
        SpriteDedup.Match m5 = SpriteDedup.best(sr, sig(4, big, w * 2, h * 2), 60);
        check("outra escala (2x): g = 0", m5 != null ? m5.g : -1, 0);
        check("outra imagem nao casa", SpriteDedup.best(sr, sig(5, other, w, h), 60) == null, true);
        check("proporcao diferente nao casa", SpriteDedup.best(sr, sig(6, derive(r, w, h, 0, w, h * 2), w, h * 2), 60) == null, true);

        // grupos: a maior (2x) vira representante; as outras apontam para ela
        List<SpriteDedup.Sig> all = new ArrayList<SpriteDedup.Sig>();
        all.add(sr); all.add(sig(1, mir, w, h)); all.add(sig(4, big, w * 2, h * 2)); all.add(sig(5, other, w, h));
        List<SpriteDedup.Group> gs = SpriteDedup.groups(all, 60);
        check("um grupo com 3 sprites, representante a de maior area (4)", gs.size() + ":" + gs.get(0).members.size() + ":" + gs.get(0).rep(), "1:3:4");
        check("a sem relacao fica de fora", gs.get(0).members.get(1).index != 5 && gs.get(0).members.get(2).index != 5, true);

        // ---- geometria exata do frame: para cada g e varios estados de R, o desenho de K cai onde o de R caia
        int[][] states = {{0, 0, 0, 0, 100, 100, 0}, {10, -6, 0, 0, 100, 100, 0}, {5, 8, 30, 0, 200, 100, 0}, {-4, 3, 0, 1, 100, 100, 0}, {7, -2, 45, 1, 150, 150, 1}, {0, 0, 90, 0, 100, 200, 1}};
        int bad = 0, nulls = 0, total = 0;
        for (int g = 0; g < 8; g++) {
            int wK = SpriteXform.swapsAxes(g) ? h * 2 : w * 2, hK = SpriteXform.swapsAxes(g) ? w * 2 : h * 2;
            for (int[] st : states) {
                SpriteXform.Frame fr = new SpriteXform.Frame();
                fr.ox = st[0]; fr.oy = st[1]; fr.rot = st[2]; fr.flipH = st[3] == 1; fr.zx = st[4]; fr.zy = st[5]; fr.flipV = st[6] == 1;
                SpriteXform.Frame fk = SpriteXform.solve(fr, w, h, wK, hK, g, true);
                total++;
                if (fk == null) { nulls++; continue; }
                if (maxErr(fr, w, h, fk, wK, hK, g) > 0.6) bad++;
            }
        }
        check("48 casos (8 relacoes x 6 estados): todos tem solucao", nulls, 0);
        check("e o desenho cai no mesmo lugar (erro < 0,6 px)", bad, 0);

        // casos pedidos pelo usuario
        SpriteXform.Frame plain = new SpriteXform.Frame();
        SpriteXform.Frame fl = SpriteXform.solve(plain, w, h, w, h, 1, true);
        check("espelhada: liga o Flip X e desloca o centro por -largura", fl.flipH + ":" + fl.flipV + ":" + fl.ox + ":" + fl.rot, "true:false:-24:0");
        SpriteXform.Frame sc = SpriteXform.solve(plain, w, h, w * 2, h * 2, 0, true);
        check("outra escala (K 2x): so o zoom cai para 50 %, sem Flip nem posicao", sc.zx + ":" + sc.zy + ":" + sc.ox + ":" + sc.oy + ":" + sc.flipH + ":" + sc.rot, "50:50:0:0:false:0");
        SpriteXform.Frame rt = SpriteXform.solve(plain, w, h, h, w, 5, true);
        check("girada 90: rotacao multipla de 90 e sem Flip", Math.abs(rt.rot) % 90 == 0 && !rt.flipH && !rt.flipV, true);
        check("sem permitir Flip, o espelho nao tem solucao em ANO filha de link", SpriteXform.solve(plain, w, h, w, h, 1, false) == null || !SpriteXform.solve(plain, w, h, w, h, 1, false).flipH, true);

        // ---- aplicar no DAC
        Dac dac = dac(new A().mpt(mpt(0)).mpt(mpt(1)).mpt(mpt(2)), new A().mpt(mpt(1)));
        SpriteDedup.Choice ch = new SpriteDedup.Choice();
        ch.removed = sig(1, mir, w, h); ch.kept = sr; ch.match = SpriteDedup.best(ch.removed, sr, 60);
        List<SpriteDedup.Choice> cl = new ArrayList<SpriteDedup.Choice>();
        cl.add(ch);
        SpriteDedup.Result res = SpriteDedup.apply(dac, cl);
        check("removida a sprite 1; 2 frames reescritos em 2 ANOs", res.removedSprites + ":" + res.framesRewritten + ":" + res.changedAnos, "[1]:2:[0, 1]");
        Ano.Mpt n = dac.getAno(0).mpts[1];
        check("o frame passou a usar a sprite 0 com Flip X", n.image + ":" + ((n.wActFlag & 16) != 0), "0:true");
        check("o frame de outra sprite nao mudou", dac.getAno(0).mpts[2].image, 2);
        System.out.println("SpriteDedupTest fails=" + fails);
    }
}
