package com.zue.attackeditor;

import java.io.File;
import static com.zue.attackeditor.BattleTest.*;

/** Padrao visual por sprite: composicao (soma/multiplica/XOR), Frame <-> padrao, troca relativa de imagem, texto, renumeracao e arquivo em utils. */
public class SpriteDefaultsTest {
    static SpriteDefaults.Def def(int zx, int zy, int rot, int alpha, int mx, int my, boolean fh, boolean fv) {
        SpriteDefaults.Def d = new SpriteDefaults.Def();
        d.zx = zx; d.zy = zy; d.rot = rot; d.alpha = alpha; d.midX = mx; d.midY = my; d.flipH = fh; d.flipV = fv;
        return d;
    }

    static Ano.Mpt mpt(int image) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.flags |= 0x20; m.time = 4; m.normalize();
        return m;
    }

    public static void main(String[] args) throws Exception {
        // ---- composicao
        SpriteDefaults.Def a = def(200, 100, 30, 0, 5, -3, true, false), d = def(150, 100, 5, 10, 2, 2, true, true);
        SpriteDefaults.Def s = SpriteDefaults.add(a, d);
        check("soma: rot soma, zoom multiplica, alpha soma, MID soma, flip XOR", s.toString(), "300x100% rot 35 alpha 10 mid 7,-1 flipV");
        check("diff e o inverso de add", SpriteDefaults.add(a, SpriteDefaults.diff(a, s)).equals(s), true);
        check("o ajuste neutro nao muda nada", SpriteDefaults.add(a, new SpriteDefaults.Def()).equals(a), true);
        check("neutro", new SpriteDefaults.Def().isNeutral() && !a.isNeutral(), true);

        // ---- Frame <-> padrao
        Ano.Mpt m = mpt(7);
        check("frame sem nada = neutro", SpriteDefaults.read(m).isNeutral(), true);
        Ano.Mpt w = SpriteDefaults.write(m, a);
        check("escrever e ler devolve o mesmo", SpriteDefaults.read(w).equals(a), true);
        check("flags 1 (MID), 2 (flip) e 0x80 (RAZ) ligadas", (w.flags & 1) != 0 && (w.flags & 2) != 0 && (w.flags & 0x80) != 0, true);
        Ano.Mpt n = SpriteDefaults.write(w, new SpriteDefaults.Def());
        check("neutro desliga as flags e zera os campos", (n.flags & (1 | 2 | 0x80)) == 0 && n.rot == 0 && n.midX == 0 && n.xZoom == 100 && n.wActFlag == 0, true);
        check("a imagem e o tempo ficam", w.image == 7 && w.time == 4, true);
        Ano.Mpt rot5 = SpriteDefaults.addTo(w, def(100, 100, 5, 0, 0, 0, false, false));
        check("addTo soma +5 de rotacao e mantem zoom/flip/MID do Frame", rot5.rot == 35 && rot5.xZoom == 200 && rot5.midX == 5 && (rot5.wActFlag & ObjModel.FLIP_H) != 0, true);
        Ano.Mpt z = SpriteDefaults.addTo(w, def(110, 100, 0, 0, 0, 0, false, false));
        check("zoom multiplica: 200% x 110% = 220%", z.xZoom == 220 && z.yZoom == 100, true);
        Ano.Mpt modo = write(mptAlpha(300));
        check("alpha em modo especial (>=256) nao soma", SpriteDefaults.addTo(modo, def(100, 100, 0, 5, 0, 0, false, false)).alphaRaw == 300, true);

        // ---- troca relativa de imagem
        SpriteDefaults.Store st = new SpriteDefaults.Store();
        st.set(3, def(100, 100, 10, 0, 0, 0, false, false));
        st.set(4, def(100, 100, 15, 0, 4, 0, false, true));
        Ano.Mpt f3 = SpriteDefaults.write(mpt(3), def(100, 100, 10 + 90, 0, 1, 1, false, false));        // o usuario ajustou +90 e +1,+1 alem do padrao
        Ano.Mpt f4 = SpriteDefaults.changeImage(st, f3, 3, 4);
        check("trocar 3 -> 4: tira o padrao da 3 e poe o da 4 (rot 100 - 10 + 15, MID 1+4, flipV)", f4.image == 4 && f4.rot == 105 && f4.midX == 5 && f4.midY == 1 && (f4.wActFlag & ObjModel.FLIP_V) != 0, true);
        Ano.Mpt back = SpriteDefaults.changeImage(st, f4, 4, 3);
        check("e voltar 4 -> 3 devolve o Frame de antes", SpriteDefaults.read(back).equals(SpriteDefaults.read(f3)) && back.image == 3, true);
        check("sem padrao em nenhuma das duas: so troca a imagem", SpriteDefaults.changeImage(st, mpt(8), 8, 9).image == 9 && SpriteDefaults.read(SpriteDefaults.changeImage(st, mpt(8), 8, 9)).isNeutral(), true);
        check("padrao so na nova: ela entra aplicada", SpriteDefaults.read(SpriteDefaults.changeImage(st, mpt(8), 8, 3)).rot == 10, true);
        check("mesma imagem: nada muda", SpriteDefaults.read(SpriteDefaults.changeImage(st, f3, 3, 3)).equals(SpriteDefaults.read(f3)), true);

        // ---- Igualar: ajuste em relacao a original; padrao da nova = padrao da original + ajuste
        SpriteDefaults.Def adj = def(100, 100, 5, 0, 0, 0, false, false);
        SpriteDefaults.Def newDef = SpriteDefaults.add(st.get(3), adj);
        check("nova = rotacao da antiga (10) + 5", newDef.rot, 15);
        Ano.Mpt aplic = SpriteDefaults.addTo(f3, adj);
        check("Frame que usava a original ganha +5 e mantem o resto", aplic.rot == 105 && aplic.midX == 1, true);

        // ---- texto
        st.set(12, def(80, 120, -20, 30, -1, 2, true, true));
        String txt = st.format();
        SpriteDefaults.Store p = new SpriteDefaults.Store();
        p.parse(txt + "lixo\nSPR_x 1 2\nSPR_5 abc 1 1 1 1 1 0 0\n");
        check("formato e leitura de ida e volta, linhas ruins ignoradas", p.map.size() == 3 && p.get(12).equals(st.get(12)) && p.get(4).equals(st.get(4)), true);
        st.set(12, null);
        check("padrao neutro/nulo remove", st.has(12), false);

        // ---- renumeracao
        SpriteDefaults.Store r = new SpriteDefaults.Store();
        r.set(2, def(100, 100, 2, 0, 0, 0, false, false));
        r.set(5, def(100, 100, 5, 0, 0, 0, false, false));
        r.set(6, def(100, 100, 6, 0, 0, 0, false, false));
        boolean[] rem = new boolean[8];
        rem[2] = true;
        r.remap(SpriteRenumber.map(8, rem));            // exclui a SPR_2: 5 -> 4, 6 -> 5
        check("excluir a SPR_2: o padrao dela some e os outros descem", !r.has(2) && r.get(4).rot == 5 && r.get(5).rot == 6 && r.map.size() == 2, true);
        r.remap(SpriteRenumber.swapMap(4, 5));
        check("trocar slots acompanha", r.get(5).rot == 5 && r.get(4).rot == 6, true);
        check("mapa vazio/sem mudanca nao altera", !r.remap(new int[]{0, 1, 2, 3, 4, 5}), true);

        // ---- arquivo em TBRE/utils/charNN
        File root = new File(System.getProperty("java.io.tmpdir"), "defaults_test_tapbattle");
        Saver.deleteTree(root);
        File ch = new File(root, "assets/char05");
        ch.mkdirs();
        SpriteDefaults.Store fs = SpriteDefaults.Store.load(ch);
        check("sem arquivo: vazio", fs.map.isEmpty(), true);
        fs.set(9, def(120, 120, 7, 0, 3, 3, false, true));
        fs.save(ch);
        File f = new File(root, "TBRE/utils/char05/" + SpriteDefaults.FILE);
        check("grava em TBRE/utils/charNN e nada na pasta do char", f.isFile() && ch.list().length == 0, true);
        SpriteDefaults.Store ld = SpriteDefaults.Store.load(ch);
        check("relê igual", ld.get(9).equals(fs.get(9)) && ld.map.size() == 1, true);
        ld.set(9, null);
        ld.save(ch);
        check("vazio apaga o arquivo", f.exists(), false);
    }

    static Ano.Mpt mptAlpha(int raw) {
        Ano.Mpt m = mpt(1);
        m.flags |= 0x80; m.alphaRaw = raw; m.xZoom = 100; m.yZoom = 100; m.normalize();
        return m;
    }
    static Ano.Mpt write(Ano.Mpt m) { return m; }
}
