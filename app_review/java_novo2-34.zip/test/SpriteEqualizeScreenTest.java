package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Contas da previa de Igualar/Editar Frames: ancora e escala iguais as da previa principal; cantos da sprite com zoom, rotacao, flip e MID. */
public class SpriteEqualizeScreenTest {
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }

    public static void main(String[] args) throws Exception {
        SpriteDefaults.Def d = new SpriteDefaults.Def();
        double[] c = SpriteEqualizeScreen.corners(d, 40, 60);
        check("sem ajuste: canto (0,0), (40,0), (0,60)", near(c[0], 0) && near(c[1], 0) && near(c[2], 40) && near(c[3], 0) && near(c[4], 0) && near(c[5], 60), true);
        d.midX = -20; d.midY = -60;
        c = SpriteEqualizeScreen.corners(d, 40, 60);
        check("MID desloca o quadro (-20,-60)", near(c[0], -20) && near(c[1], -60) && near(c[2], 20), true);
        d = new SpriteDefaults.Def();
        d.zx = 200; d.zy = 50;
        c = SpriteEqualizeScreen.corners(d, 40, 60);
        check("zoom X 200% e Y 50%: 80 x 30", near(c[2], 80) && near(c[5], 30), true);
        d = new SpriteDefaults.Def();
        d.rot = 90;
        c = SpriteEqualizeScreen.corners(d, 40, 60);
        check("rotacao de 90 graus: a borda de cima vira a coluna da direita (0,40)", near(c[2], 0) && near(c[3], 40), true);
        d = new SpriteDefaults.Def();
        d.flipH = true;
        c = SpriteEqualizeScreen.corners(d, 40, 60);
        check("flip horizontal espelha em torno da ancora: (0,0)->(0,0) e (40,0)->(-40,0)", near(c[0], 0) && near(c[2], -40), true);

        // confirmacao do Substituir: aviso de tamanho e escala comum das duas previas
        check("mesmo tamanho: sem aviso", SpriteMass.sizeWarningDims(3, 40, 60, 40, 60), "");
        check("sprite vazia: sem aviso", SpriteMass.sizeWarningDims(3, 0, 0, 40, 60), "");
        check("tamanho diferente: avisa com os dois tamanhos", SpriteMass.sizeWarningDims(3, 40, 60, 50, 60).contains("SPR_3 (40x60)") && SpriteMass.sizeWarningDims(3, 40, 60, 50, 60).contains("(50x60)"), true);
        check("previa 1:1 cabe: escala = densidade", ReplaceConfirm.fitScale(2f, 40, 60, 50, 80, 300f, 400f), 2f);
        check("previa grande: as duas encolhem juntas pela maior", ReplaceConfirm.fitScale(3f, 100, 100, 50, 300, 600f, 300f), 1f);
        check("nunca passa da densidade nem fica 0", ReplaceConfirm.fitScale(2f, 1, 1, 1, 1, 1000f, 1000f) == 2f && ReplaceConfirm.fitScale(2f, 1000, 1000, 1, 1, 10f, 10f) > 0f, true);
    }
}
