package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

/** Importar sprites de outro pac: quais entram (sem vazias nem recortes repetidos), ampliacao para manter o tamanho e nomes de arquivo. */
public class SpriteImportPlanTest {
    static Cnv cnv(int[][] e, boolean character) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (int[] r : e) { byte[] b = Cnv.encode(r[0], r[1], r[2], r[3], r[4]); o.write(b, 0, b.length); }
        return Cnv.read(o.toByteArray(), character);
    }

    public static void main(String[] args) throws Exception {
        Cnv c = cnv(new int[][] {
                {0, 0, 0, 32, 48},      // 0
                {0, 32, 0, 16, 16},     // 1
                {0, 0, 0, 0, 0},        // 2 vazia
                {0, 0, 0, 32, 48},      // 3 = recorte da 0
                {1, 5, 5, 8, 8},        // 4 (outra folha)
                {1, 5, 5, 8, 0},        // 5 sem altura
                {0, 0, 0, 32, 48}},     // 6 = recorte da 0
                false);
        List<SpriteImportPlan.Item> it = SpriteImportPlan.items(c);
        StringBuilder sb = new StringBuilder();
        for (SpriteImportPlan.Item x : it) sb.append(x.index).append(' ');
        check("sprites distintas e com desenho", sb.toString().trim(), "0 1 4");
        check("a 0 repete em 3 e 6", it.get(0).same.toString(), "[3, 6]");
        check("descricao com repetidas", SpriteImportPlan.describe(it.get(0)), "SPR_0  32x48  (= SPR_3, SPR_6)");
        check("descricao simples", SpriteImportPlan.describe(it.get(1)), "SPR_1  16x16");
        check("tamanho logico", it.get(2).width + "x" + it.get(2).height, "8x8");

        check("fator: escala 1 -> 2 dobra", SpriteImportPlan.factor(1, 2), 2);
        check("fator: 2 -> 2 mantem", SpriteImportPlan.factor(2, 2), 1);
        check("fator: 2 -> 1 nao reduz", SpriteImportPlan.factor(2, 1), 1);
        check("fator: escala invalida", SpriteImportPlan.factor(0, 2), 1);
        check("fator: 1 -> 3", SpriteImportPlan.factor(1, 3), 3);

        check(".cnv", SpriteImportPlan.isCnvName("000.cnv"), true);
        check(".cnv.txt", SpriteImportPlan.isCnvName("000.CNV.TXT"), true);
        check("outro", SpriteImportPlan.isCnvName("000.dac.txt"), false);
        check("png nao", SpriteImportPlan.isCnvName("000.png"), false);
        check("cnvOf tira o .txt", SpriteImportPlan.cnvOf(new File("/a/b/000.cnv.txt")).getName(), "000.cnv");
        check("cnvOf mantem o .cnv", SpriteImportPlan.cnvOf(new File("/a/b/000.cnv")).getName(), "000.cnv");
        check("pasta de personagem", SpriteImportPlan.isCharacterDir(new File("/x/assets/char07")), true);
        check("pasta de efeito nao", SpriteImportPlan.isCharacterDir(new File("/x/assets/effect")), false);
        check("pasta de personagem com sufixo, maiuscula ou 1 digito", SpriteImportPlan.isCharacterDir(new File("/x/char07_copia")) + ":" + SpriteImportPlan.isCharacterDir(new File("/x/Char7")) + ":" + SpriteImportPlan.isCharacterDir(new File("/x/char123")), "true:true:true");
        check("chara/charf/char sem numero nao", SpriteImportPlan.isCharacterDir(new File("/x/chara01")) + ":" + SpriteImportPlan.isCharacterDir(new File("/x/char")), "false:false");
        check("charf nao e personagem", SpriteImportPlan.isCharacterDir(new File("/x/assets/charf007")), false);
        File t = new File(System.getProperty("java.io.tmpdir"));
        check("mesma pasta", SpriteImportPlan.sameFolder(t, new File(t, ".")), true);
        check("pastas diferentes", SpriteImportPlan.sameFolder(t, t.getParentFile() == null ? new File("/") : t.getParentFile()), false);
        check("escala do CNV: personagem 2, o resto 1", cnv(new int[][] {{0, 0, 0, 1, 1}}, true).scale() + "/" + cnv(new int[][] {{0, 0, 0, 1, 1}}, false).scale(), "2/1");
        // textos novos da escolha de sprites do pac
        check("titulo EN", I18n.trTo("Sprites de effect/000.cnv", I18n.EN), "Sprites from effect/000.cnv");
        check("dica com ampliacao EN", I18n.trTo("12 sprite(s) distintas  \u00b7  escala 1 \u2192 2: entram ampliadas 2x para manter o tamanho na tela. Toque nas que quer adicionar.", I18n.EN),
                "12 distinct sprite(s)  \u00b7  scale 1 \u2192 2: they come in enlarged 2x to keep the on-screen size. Tap the ones you want to add.");
        check("dica sem ampliacao ES", I18n.trTo("5 sprite(s) distintas  \u00b7  escala 2  \u00b7  entram sem mudar o tamanho. Toque nas que quer adicionar.", I18n.ES),
                "5 sprite(s) distintos  \u00b7  escala 2  \u00b7  entran sin cambiar el tamaño. Toca los que quieras agregar.");
        check("botao ADICIONAR n ES", I18n.trTo("ADICIONAR 3", I18n.ES), "AGREGAR 3");
        check("TODAS/NENHUMA EN", I18n.trTo("TODAS", I18n.EN) + "/" + I18n.trTo("NENHUMA", I18n.EN), "ALL/NONE");
        // ---- .cnv em texto (coordenadas originais, sem x2) x .cnv.txt (coordenadas finais, ja x2) x binario
        File td = java.nio.file.Files.createTempDirectory("cnvtxt").toFile();
        String logical = "CNV_TXT_ {\n   $SPR_0:{$src:5, $x:96, $y:144, $w:73, $h:68},\n   $SPR_1:{$src:6, $x:108, $y:0, $w:72, $h:67},\n}\n";
        String physical = "CNV_TXT_ {\n   $SPR_0:{$src:5, $x:192, $y:288, $w:146, $h:136},\n   $SPR_1:{$src:6, $x:216, $y:0, $w:144, $h:134},\n}\n";
        File f1 = new File(td, "a.cnv");
        java.nio.file.Files.write(f1.toPath(), logical.getBytes("UTF-8"));
        Cnv t1 = CharAssets.readCnv(f1, true);
        Cnv.Entry e0 = t1.byImage(0);
        check(".cnv texto de personagem: coordenadas originais, sem dividir", e0.source + ":" + e0.x + ":" + e0.y + ":" + e0.width + ":" + e0.height, "5:96:144:73:68");
        check(".cnv texto de personagem: escala 2 (o recorte multiplica)", t1.scale() + ":" + t1.size(), "2:2");
        Cnv t1e = CharAssets.readCnv(f1, false);
        check(".cnv texto de effect: mesmos numeros, escala 1", t1e.byImage(1).width + ":" + t1e.scale(), "72:1");
        File f2 = new File(td, "b.cnv");
        java.nio.file.Files.write(f2.toPath(), ("\uFEFF// pac\n" + logical).getBytes("UTF-8"));
        check(".cnv texto com BOM e comentario", CharAssets.readCnv(f2, true).byImage(1).height, 67);
        File f3 = new File(td, "c.cnv");
        java.nio.file.Files.write(f3.toPath(), physical.getBytes("UTF-8"));
        File f3t = new File(td, "c.cnv.txt");
        java.nio.file.Files.write(f3t.toPath(), physical.getBytes("UTF-8"));
        File f3b = new File(td, "d.cnv");
        java.nio.file.Files.write(f3b.toPath(), logical.getBytes("UTF-8"));
        File f3bt = new File(td, "d.cnv.txt");
        java.nio.file.Files.write(f3bt.toPath(), physical.getBytes("UTF-8"));
        Cnv both = CharAssets.readCnv(f3b, true);
        check(".cnv.txt ao lado vence e divide por 2 (coordenadas finais -> originais)", both.byImage(0).width + ":" + both.byImage(0).x + ":" + both.byImage(1).y, "73:96:0");
        check("so .cnv.txt (sem .cnv): o picker usa o .cnv e o .txt e lido", SpriteImportPlan.cnvOf(f3t).getName(), "c.cnv");
        check(".cnv.txt de effect nao divide", CharAssets.readCnv(f3, false).byImage(0).width, 73 * 2);
        File f4 = new File(td, "e.cnv");
        java.nio.file.Files.write(f4.toPath(), cnv(new int[][] {{3, 10, 20, 30, 40}, {4, 1, 2, 3, 4}}, true).encode());
        Cnv bin = CharAssets.readCnv(f4, true);
        check(".cnv binario sem texto continua lido como binario", bin.size() + ":" + bin.byImage(0).source + ":" + bin.byImage(0).width + ":" + bin.byImage(1).height, "2:3:30:4");
        File f5 = new File(td, "f.cnv");
        java.nio.file.Files.write(f5.toPath(), new byte[3]);
        boolean err = false;
        try { CharAssets.readCnv(f5, true); } catch (java.io.IOException ex) { err = true; }
        check(".cnv sem texto e pequeno demais para binario: erro", err, true);
        List<SpriteImportPlan.Item> ti = SpriteImportPlan.items(t1);
        check("sprites do .cnv texto entram no plano", ti.size() + ":" + SpriteImportPlan.describe(ti.get(0)), "2:SPR_0  73x68");
        check("ampliacao de um pac de efeito (escala 1) para o personagem", SpriteImportPlan.factor(t1e.scale(), t1.scale()), 2);
        // ---- deduzir a escala pelo tamanho das folhas (pasta sem nome charNN e sem 000.bin)
        Cnv half = cnv(new int[][] {{0, 0, 0, 240, 160}, {0, 240, 0, 240, 160}, {0, 0, 160, 240, 160}, {0, 240, 160, 240, 160}}, false);   // 4 recortes de 240x160 (coordenadas = metade do pixel)
        check("folha 960x640 com recortes que so cabem dobrados e enchem a folha: escala 2", SpriteImportPlan.guessScale(half, new int[][] {{960, 640}}), 2);
        Cnv full = cnv(new int[][] {{0, 0, 0, 480, 320}, {0, 480, 0, 480, 320}}, false);
        check("recortes que nao cabem dobrados: escala 1 (sem evidencia)", SpriteImportPlan.guessScale(full, new int[][] {{960, 640}}), 0);
        Cnv little = cnv(new int[][] {{0, 0, 0, 100, 100}}, false);
        check("pouco conteudo numa folha grande: sem evidencia", SpriteImportPlan.guessScale(little, new int[][] {{960, 640}}), 0);
        check("folha desconhecida (0x0): sem evidencia", SpriteImportPlan.guessScale(half, new int[][] {{0, 0}}), 0);
        check("sem folhas: sem evidencia", SpriteImportPlan.guessScale(half, null), 0);
        File pacDir = java.nio.file.Files.createTempDirectory("pac").toFile();
        check("pasta qualquer sem 000.bin nao e personagem", SpriteImportPlan.isCharacterPac(pacDir), false);
        java.nio.file.Files.write(new File(pacDir, "000.bin").toPath(), new byte[4]);
        check("pasta com 000.bin e personagem", SpriteImportPlan.isCharacterPac(pacDir), true);
        File fk = new File(td, "k.cnv");
        java.nio.file.Files.write(fk.toPath(), logical.getBytes("UTF-8"));
        CharAssets.readCnv(fk, true);
        check("diagnostico: .cnv em texto", CharAssets.lastCnvKind, CharAssets.KIND_TEXT);
        CharAssets.readCnv(f3b, true);
        check("diagnostico: .cnv.txt ao lado", CharAssets.lastCnvKind, CharAssets.KIND_TXT);
        CharAssets.readCnv(f4, true);
        check("diagnostico: binario", CharAssets.lastCnvKind, CharAssets.KIND_BIN);
        System.out.println("SpriteImportPlanTest fails=" + fails);
    }
}
