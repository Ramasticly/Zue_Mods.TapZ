package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

/** Importar sprites de outro pac: quais entram (sem vazias nem recortes repetidos), ampliacao para manter o tamanho e nomes de arquivo. */
public class SpriteImportPlanTest {
    static Cnv cnv(int[][] e, boolean character) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (int[] r : e) { byte[] b = Cnv.encode(r[0], r[1], r[2], r[3], r[4]); o.write(b, 0, b.length); }
        return Cnv.read(o.toByteArray(), character);
    }

    public static void main(String[] args) throws Exception {
        Cnv c = cnv(new int[][] {
                {0, 0, 0, 32, 48},      // 0
                {0, 32, 0, 16, 16},     // 1
                {0, 0, 0, 0, 0},        // 2 vazia
                {0, 0, 0, 32, 48},      // 3 = recorte da 0
                {1, 5, 5, 8, 8},        // 4 (outra folha)
                {1, 5, 5, 8, 0},        // 5 sem altura
                {0, 0, 0, 32, 48}},     // 6 = recorte da 0
                false);
        List<SpriteImportPlan.Item> it = SpriteImportPlan.items(c);
        StringBuilder sb = new StringBuilder();
        for (SpriteImportPlan.Item x : it) sb.append(x.index).append(' ');
        check("sprites distintas e com desenho", sb.toString().trim(), "0 1 4");
        check("a 0 repete em 3 e 6", it.get(0).same.toString(), "[3, 6]");
        check("descricao com repetidas", SpriteImportPlan.describe(it.get(0)), "SPR_0  32x48  (= SPR_3, SPR_6)");
        check("descricao simples", SpriteImportPlan.describe(it.get(1)), "SPR_1  16x16");
        check("tamanho logico", it.get(2).width + "x" + it.get(2).height, "8x8");

        check("fator: escala 1 -> 2 dobra", SpriteImportPlan.factor(1, 2), 2);
        check("fator: 2 -> 2 mantem", SpriteImportPlan.factor(2, 2), 1);
        check("fator: 2 -> 1 nao reduz", SpriteImportPlan.factor(2, 1), 1);
        check("fator: escala invalida", SpriteImportPlan.factor(0, 2), 1);
        check("fator: 1 -> 3", SpriteImportPlan.factor(1, 3), 3);

        check(".cnv", SpriteImportPlan.isCnvName("000.cnv"), true);
        check(".cnv.txt", SpriteImportPlan.isCnvName("000.CNV.TXT"), true);
        check("outro", SpriteImportPlan.isCnvName("000.dac.txt"), false);
        check("png nao", SpriteImportPlan.isCnvName("000.png"), false);
        check("cnvOf tira o .txt", SpriteImportPlan.cnvOf(new File("/a/b/000.cnv.txt")).getName(), "000.cnv");
        check("cnvOf mantem o .cnv", SpriteImportPlan.cnvOf(new File("/a/b/000.cnv")).getName(), "000.cnv");
        check("pasta de personagem", SpriteImportPlan.isCharacterDir(new File("/x/assets/char07")), true);
        check("pasta de efeito nao", SpriteImportPlan.isCharacterDir(new File("/x/assets/effect")), false);
        check("charf nao e personagem", SpriteImportPlan.isCharacterDir(new File("/x/assets/charf007")), false);
        File t = new File(System.getProperty("java.io.tmpdir"));
        check("mesma pasta", SpriteImportPlan.sameFolder(t, new File(t, ".")), true);
        check("pastas diferentes", SpriteImportPlan.sameFolder(t, t.getParentFile() == null ? new File("/") : t.getParentFile()), false);
        check("escala do CNV: personagem 2, o resto 1", cnv(new int[][] {{0, 0, 0, 1, 1}}, true).scale() + "/" + cnv(new int[][] {{0, 0, 0, 1, 1}}, false).scale(), "2/1");
        // textos novos da escolha de sprites do pac
        check("titulo EN", I18n.trTo("Sprites de effect/000.cnv", I18n.EN), "Sprites from effect/000.cnv");
        check("dica com ampliacao EN", I18n.trTo("12 sprite(s) distintas  \u00b7  escala 1 \u2192 2: entram ampliadas 2x para manter o tamanho na tela. Toque nas que quer adicionar.", I18n.EN),
                "12 distinct sprite(s)  \u00b7  scale 1 \u2192 2: they come in enlarged 2x to keep the on-screen size. Tap the ones you want to add.");
        check("dica sem ampliacao ES", I18n.trTo("5 sprite(s) distintas  \u00b7  escala 2  \u00b7  entram sem mudar o tamanho. Toque nas que quer adicionar.", I18n.ES),
                "5 sprite(s) distintos  \u00b7  escala 2  \u00b7  entran sin cambiar el tamaño. Toca los que quieras agregar.");
        check("botao ADICIONAR n ES", I18n.trTo("ADICIONAR 3", I18n.ES), "AGREGAR 3");
        check("TODAS/NENHUMA EN", I18n.trTo("TODAS", I18n.EN) + "/" + I18n.trTo("NENHUMA", I18n.EN), "ALL/NONE");
        System.out.println("SpriteImportPlanTest fails=" + fails);
    }
}
