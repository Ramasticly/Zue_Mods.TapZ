package com.zue.attackeditor;

import java.util.HashSet;
import java.util.Set;

public class SpriteMassTest {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.println((ok ? "OK   " : "FALHA ") + n); if (!ok) fails++; }

    static Ano.Mpt mpt(int image) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.time = 2; m.flags = 0x20; m.normalize();
        return m;
    }

    static Dac dac(Ano... anos) throws Exception {
        java.lang.reflect.Constructor<Dac> c = Dac.class.getDeclaredConstructor(Ano[].class, java.util.List.class);
        c.setAccessible(true);
        return c.newInstance((Object) anos, new java.util.ArrayList<String>());
    }

    public static void main(String[] a) throws Exception {
        Ano.Mpt hitFrame = mpt(5);
        hitFrame.hits = new Ano.Hit[]{new Ano.Hit()};
        hitFrame.hits[0].flag = 2; hitFrame.flags |= 0x10;
        Ano a0 = new Ano(0, true, 0, 0, null, new Ano.Mpt[]{mpt(1), mpt(5), mpt(2), mpt(5)});
        Ano a1 = new Ano(1, true, 0, 0, null, new Ano.Mpt[]{mpt(5)});
        Ano a2 = new Ano(2, true, 0, 0, null, new Ano.Mpt[]{hitFrame, mpt(3)});
        Dac d = dac(a0, a1, a2);
        Set<Integer> s5 = new HashSet<Integer>();
        s5.add(Integer.valueOf(5));

        SpriteMass.Usage u = SpriteMass.usage(d, null, s5);
        check("uso: 4 frames em 3 ANOs", u.frames == 4 && u.anos.size() == 3);
        check("uso: hitbox detectada", u.hitOrProjectile);
        Set<Integer> s1 = new HashSet<Integer>();
        s1.add(Integer.valueOf(1));
        check("uso sem hitbox", !SpriteMass.usage(d, null, s1).hitOrProjectile);

        // edicao em massa
        SpriteMass.Edit e = new SpriteMass.Edit();
        e.zoom = true; e.zoomX = 50; e.zoomY = 50;
        e.hurt = SpriteMass.SET;
        e.flipH = SpriteMass.SET;
        e.pos = SpriteMass.SET; e.midX = 3; e.midY = -4;
        int n = SpriteMass.apply(d, s5, e);
        check("editou 4 frames", n == 4);
        Ano.Mpt m = d.getAno(0).mpts[1];
        check("zoom 50 + flag raz", m.xZoom == 50 && m.yZoom == 50 && (m.flags & 0x80) != 0);
        check("hurtbox criada", (m.flags & 0x10) != 0 && m.hits.length == 1 && m.hits[0].flag == 1 && m.hits[0].width == 32);
        check("flip H ligado", (m.wActFlag & ObjModel.FLIP_H) != 0 && (m.flags & 2) != 0);
        check("centro proprio", (m.flags & 1) != 0 && m.midX == 3 && m.midY == -4);
        check("outras imagens intactas", d.getAno(0).mpts[0].xZoom == 100 && (d.getAno(0).mpts[0].flags & 0x80) == 0);
        Ano.Mpt hf = d.getAno(2).mpts[0];
        check("hitbox existente mantida e hurtbox somada", hf.hits.length == 2);
        // zoom volta a 100 => tira a flag
        SpriteMass.Edit e2 = new SpriteMass.Edit();
        e2.zoom = true; e2.zoomX = 100; e2.zoomY = 100;
        SpriteMass.apply(d, s5, e2);
        check("zoom 100 limpa raz", (d.getAno(0).mpts[1].flags & 0x80) == 0);
        SpriteMass.Edit e3 = new SpriteMass.Edit();
        e3.hurt = SpriteMass.REMOVE; e3.flipH = SpriteMass.REMOVE; e3.pos = SpriteMass.REMOVE;
        SpriteMass.apply(d, s5, e3);
        Ano.Mpt r = d.getAno(0).mpts[1];
        check("remover hurtbox/flip/centro", (r.flags & 0x10) == 0 && r.wActFlag == 0 && (r.flags & 2) == 0 && (r.flags & 1) == 0);
        SpriteMass.Edit e4 = new SpriteMass.Edit();
        e4.effect = SpriteMass.SET; e4.effectAno = 205; e4.effectX = 7; e4.effectY = 9;
        SpriteMass.apply(d, s1, e4);
        Ano.Hit fx = d.getAno(0).mpts[0].hits[0];
        check("efeito do personagem ANO 205 = flag 75", fx.flag == 75 && fx.x == 7 && fx.y == 9);
        check("edicao vazia nao faz nada", SpriteMass.apply(d, s5, new SpriteMass.Edit()) == 0);

        // ANO 2 com um link para a ANO 1 (vai ficar vazia) e outro para a ANO 0
        Ano a2L = d.getAno(2);
        d.setAno(2, new Ano(2, true, a2L.flags | 2, a2L.priority, new Ano.Link[]{new Ano.Link(0, 0, 1), new Ano.Link(5, 5, 0)}, a2L.mpts));
        // exclusao de frames
        int rem = SpriteMass.deleteFrames(d, s5);
        check("excluiu 4 frames", rem == 4);
        check("ANO 0 ficou com 2 frames em sequencia", d.getAno(0).mpts.length == 2 && d.getAno(0).mpts[0].image == 1 && d.getAno(0).mpts[1].image == 2);
        check("ANO 1 sem frames ficou vazia", !d.getAno(1).present && d.getAno(1).mpts.length == 0);
        check("ANO 2 manteve o frame restante", d.getAno(2).present && d.getAno(2).mpts.length == 1 && d.getAno(2).mpts[0].image == 3);
        check("link para ANO vazia removido, o outro ficou", d.getAno(2).links.length == 1 && d.getAno(2).links[0].getAno() == 0 && SpriteMass.lastLinksRemoved == 1);
        check("texto da ANO vazia", DacText.ano(d.getAno(1), -1).equals("$ANO_1: {\n},"));
        // gravar no .txt e reabrir: o DAC binario (copia nova) tem que reaparecer com as mudancas
        java.io.File tmp = java.io.File.createTempFile("dac", "");
        tmp.deleteOnExit();
        java.io.File txt = new java.io.File(tmp.getPath() + ".txt");
        txt.deleteOnExit();
        Dac orig = dac(a0, a1, a2);
        String full = Saver.dacText(orig, null);
        java.io.FileOutputStream fo = new java.io.FileOutputStream(txt);
        fo.write(full.getBytes("UTF-8")); fo.close();
        String t2 = full;
        boolean[] fnd = new boolean[1];
        t2 = Saver.patchAno(t2, d.getAno(1), fnd);
        t2 = Saver.patchAno(t2, d.getAno(2), fnd);
        fo = new java.io.FileOutputStream(txt);
        fo.write(t2.getBytes("UTF-8")); fo.close();
        Dac reopened = dac(a0, a1, a2);
        TxtOverlay.applyDacTxt(reopened, tmp);
        check("reabrir: ANO 1 continua vazia", !reopened.getAno(1).present);
        check("reabrir: link para ANO vazia sumiu", reopened.getAno(2).links.length == 1 && reopened.getAno(2).links[0].getAno() == 0);
        check("reabrir: ANO 0 intacta", reopened.getAno(0).mpts.length == 4);
        System.out.println(fails == 0 ? "TODOS OS TESTES PASSARAM" : fails + " FALHA(S)");
    }
}
