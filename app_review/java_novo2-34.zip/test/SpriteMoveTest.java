package com.zue.attackeditor;

import java.util.Arrays;
import static com.zue.attackeditor.BattleTest.*;

/** Mover a sprite de slot (arrastar): permutacao, CNV, DAC (animacoes iguais) e grupos de GIF. */
public class SpriteMoveTest {
    static Cnv cnv(int n) throws Exception {
        byte[] d = new byte[n * Cnv.ENTRY_SIZE];
        for (int i = 0; i < n; i++) System.arraycopy(Cnv.encode(0, i * 10, i, 10 + i, 20 + i), 0, d, i * Cnv.ENTRY_SIZE, Cnv.ENTRY_SIZE);
        return Cnv.read(d, false);
    }

    static String imgs(Ano a) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.mpts.length; i++) b.append(i == 0 ? "" : ",").append(a.mpts[i].image);
        return b.toString();
    }

    public static void main(String[] args) throws Exception {
        check("para baixo: 1 -> 4", Arrays.toString(SpriteMove.moveMap(6, 1, 4)), "[0, 4, 1, 2, 3, 5]");
        check("para cima: 4 -> 1", Arrays.toString(SpriteMove.moveMap(6, 4, 1)), "[0, 2, 3, 4, 1, 5]");
        check("igual ou invalido = identidade", Arrays.toString(SpriteMove.moveMap(4, 2, 2)) + Arrays.toString(SpriteMove.moveMap(4, -1, 2)) + Arrays.toString(SpriteMove.moveMap(4, 1, 9)), "[0, 1, 2, 3][0, 1, 2, 3][0, 1, 2, 3]");
        boolean allPerm = true;
        for (int f = 0; f < 7; f++) for (int t = 0; t < 7; t++) allPerm &= SpriteMove.isPermutation(SpriteMove.moveMap(7, f, t));
        check("todo movimento e uma permutacao valida", allPerm, true);
        check("isPermutation recusa repetido e fora da faixa", SpriteMove.isPermutation(new int[]{0, 0, 2}) + ":" + SpriteMove.isPermutation(new int[]{0, 5, 1}), "false:false");

        // ---- CNV: o recorte vai com a sprite
        Cnv c = cnv(6);
        SpriteMove.moveCnv(c, 1, 4);
        check("CNV: SPR_4 e o recorte que era da 1 (x 10, altura 21)", c.byImage(4).x + ":" + c.byImage(4).height, "10:21");
        check("CNV: as do meio descem 1 (SPR_1 era a 2, SPR_3 era a 4)", c.byImage(1).x + ":" + c.byImage(3).x, "20:40");
        check("CNV: as de fora ficam", c.byImage(0).x + ":" + c.byImage(5).x, "0:50");
        check("CNV: mesmo tamanho", c.size(), 6);
        Cnv c2 = cnv(6);
        SpriteMove.moveCnv(c2, 4, 1);
        check("CNV para cima: SPR_1 e o recorte da 4; SPR_2 era a 1", c2.byImage(1).x + ":" + c2.byImage(2).x + ":" + c2.byImage(4).x, "40:10:30");

        // ---- DAC: cada Frame continua apontando para o MESMO recorte (animacoes iguais)
        Cnv before = cnv(6), after = cnv(6);
        SpriteMove.moveCnv(after, 1, 4);
        int[] map = SpriteMove.moveMap(6, 1, 4);
        Dac d = dac(new A().mpt(new M().time(4).img(0)).mpt(new M().time(4).img(1)).mpt(new M().time(4).img(4)).mpt(new M().time(4).img(-1)), new A().mpt(new M().time(4).img(2)).mpt(new M().time(4).img(5)).mpt(new M().time(4).img(9)));
        java.util.TreeSet<Integer> ch = SpriteRenumber.remapDac(d, map);
        check("DAC: imagens reescritas pelo mapa (indice alem do mapa e -1 ficam)", imgs(d.getAno(0)) + "|" + imgs(d.getAno(1)), "0,4,3,-1|1,5,9");
        check("so as ANOs que mudaram", ch.toString(), "[0, 1]");
        boolean same = true;
        int[][] orig = {{0, 1, 4}, {2, 5}};
        for (int a = 0; a < 2; a++) for (int k = 0; k < orig[a].length; k++) {
            Cnv.Entry e0 = before.byImage(orig[a][k]), e1 = after.byImage(d.getAno(a).mpts[k].image);
            same &= e0.x == e1.x && e0.y == e1.y && e0.width == e1.width && e0.height == e1.height;
        }
        check("cada Frame ainda mostra o mesmo recorte de antes", same, true);

        // ---- grupos de GIF
        // GIF em 2..4 (3 quadros, atrasos 100/200/300); mover 6 -> 0 desloca 0..5 para 1..6: o GIF acompanha (2..4 -> 3..5)
        SpriteGroups g = new SpriteGroups();
        g.add(new SpriteGroups.Group("a", 2, 3, new int[]{100, 200, 300}));
        check("GIF inteiro na faixa deslocada acompanha (mover 6 -> 0)", g.remapMove(SpriteMove.moveMap(8, 6, 0)) + ":" + g.list.get(0).first + ":" + Arrays.toString(g.list.get(0).delayMs), "0:3:[100, 200, 300]");
        SpriteGroups g2 = new SpriteGroups();
        g2.add(new SpriteGroups.Group("b", 2, 3, new int[]{100, 200, 300}));
        check("GIF fora da faixa nao muda (mover 0 -> 1)", g2.remapMove(SpriteMove.moveMap(8, 0, 1)) + ":" + g2.list.get(0).first, "0:2");
        SpriteGroups g3 = new SpriteGroups();
        g3.add(new SpriteGroups.Group("c", 2, 3, new int[]{100, 200, 300}));
        check("reordenar quadros dentro do GIF mantem o GIF e o atraso vai com a sprite (2 -> 4)", g3.remapMove(SpriteMove.moveMap(8, 2, 4)) + ":" + g3.list.get(0).first + ":" + Arrays.toString(g3.list.get(0).delayMs), "0:2:[200, 300, 100]");
        SpriteGroups g4 = new SpriteGroups();
        g4.add(new SpriteGroups.Group("d", 2, 3, new int[]{100, 200, 300}));
        check("sprite de fora entrando no meio do GIF desfaz o GIF (0 -> 3)", g4.remapMove(SpriteMove.moveMap(8, 0, 3)) + ":" + g4.list.size(), "1:0");
        SpriteGroups g5 = new SpriteGroups();
        g5.add(new SpriteGroups.Group("e", 2, 3, new int[]{100, 200, 300}));
        check("quadro saindo do GIF desfaz o GIF (3 -> 7)", g5.remapMove(SpriteMove.moveMap(8, 3, 7)) + ":" + g5.list.size(), "1:0");
        SpriteGroups g6 = new SpriteGroups();
        SpriteGroups.Group withSeq = new SpriteGroups.Group("f", 2, 3, new int[]{100, 200, 300, 400});
        withSeq.seq = new int[]{2, 3, 4, 3};
        g6.add(withSeq);
        g6.remapMove(SpriteMove.moveMap(8, 6, 0));
        check("GIF com sequencia reaproveitada: a sequencia acompanha", g6.list.get(0).first + ":" + Arrays.toString(g6.list.get(0).seq), "3:[3, 4, 5, 4]");
        SpriteGroups g7 = new SpriteGroups();
        SpriteGroups.Group inner = new SpriteGroups.Group("g", 2, 3, new int[]{100, 200, 300, 400});
        inner.seq = new int[]{2, 3, 4, 3};
        g7.add(inner);
        g7.remapMove(SpriteMove.moveMap(8, 2, 4));
        check("reordenar dentro do GIF com sequencia: a sequencia segue a sprite e os atrasos ficam por quadro", Arrays.toString(g7.list.get(0).seq) + Arrays.toString(g7.list.get(0).delayMs), "[4, 2, 3, 2][100, 200, 300, 400]");
    }
}
