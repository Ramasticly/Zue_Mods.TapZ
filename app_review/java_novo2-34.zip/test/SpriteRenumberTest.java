package com.zue.attackeditor;

import java.util.HashSet;
import java.util.Set;
import static com.zue.attackeditor.BattleTest.*;

/** Exclusao de sprites com renumeracao: mapa, CNV deslocado, grupos de GIF e os usos no DAC. */
public class SpriteRenumberTest {
    static M mpt(int image) { return new M().time(4).img(image); }

    static String imgs(Ano a) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.mpts.length; i++) b.append(i == 0 ? "" : ",").append(a.mpts[i].image);
        return b.toString();
    }

    static Cnv cnv(int n) throws Exception {
        byte[] d = new byte[n * Cnv.ENTRY_SIZE];
        for (int i = 0; i < n; i++) System.arraycopy(Cnv.encode(0, i * 10, i, 10 + i, 20 + i), 0, d, i * Cnv.ENTRY_SIZE, Cnv.ENTRY_SIZE);
        return Cnv.read(d, false);
    }

    public static void main(String[] args) throws Exception {
        boolean[] rem = new boolean[6];
        rem[0] = true; rem[3] = true;
        int[] map = SpriteRenumber.map(6, rem);
        check("mapa: 0 e 3 saem, o resto desce", java.util.Arrays.toString(map), "[-1, 0, 1, -1, 2, 3]");

        // CNV: as entradas seguintes descem e guardam o proprio recorte
        Cnv c = cnv(6);
        c.removeShift(rem);
        check("CNV com 4 entradas", c.size(), 4);
        check("SPR_0 passou a ser a antiga 1 (x 10, h 21)", c.byImage(0).x + ":" + c.byImage(0).height + ":" + c.byImage(0).index, "10:21:0");
        check("SPR_2 e a antiga 4 (x 40)", c.byImage(2).x + ":" + c.byImage(2).index, "40:2");
        Cnv one = cnv(1);
        one.removeShift(new boolean[]{true});
        check("a tabela nunca fica vazia", one.size(), 1);

        // DAC: imagens reescritas, removidas viram -1, -1 continua -1
        Ano.Mpt[] none = null;
        Dac d = dac(new A().mpt(mpt(0)).mpt(mpt(1)).mpt(mpt(2)).mpt(mpt(-1)), new A().mpt(mpt(3)).mpt(mpt(4)).mpt(mpt(5)), new A().mpt(mpt(9)));
        java.util.TreeSet<Integer> ch = SpriteRenumber.remapDac(d, map);
        check("ANO 0 reescrita", imgs(d.getAno(0)), "-1,0,1,-1");
        check("ANO 1 reescrita", imgs(d.getAno(1)), "-1,2,3");
        check("indice alem do mapa fica como esta", imgs(d.getAno(2)), "9");
        check("so as ANOs que mudaram", ch.toString(), "[0, 1]");

        // grupo de GIF sem reaproveitamento: perde o quadro removido e os atrasos dele
        SpriteGroups g = new SpriteGroups();
        g.add(new SpriteGroups.Group("a", 1, 4, new int[]{100, 200, 300, 400}));        // sprites 1..4; a 3 sai
        check("grupo remapeado", g.remap(map), 1);
        SpriteGroups.Group a = g.list.get(0);
        check("grupo: comeca na nova 0, 3 quadros, atrasos sem o da sprite 3", a.first + ":" + a.count + ":" + java.util.Arrays.toString(a.delayMs), "0:3:[100, 200, 400]");
        // grupo que fica com 1 quadro deixa de ser grupo
        SpriteGroups g2 = new SpriteGroups();
        g2.add(new SpriteGroups.Group("b", 2, 2, new int[]{100, 100}));                  // sprites 2 e 3; a 3 sai
        g2.remap(map);
        check("grupo de 1 quadro some", g2.list.size(), 0);
        // grupo com seq: os quadros da sprite removida saem da ordem
        SpriteGroups g3 = new SpriteGroups();
        SpriteGroups.Group s = new SpriteGroups.Group("c", 1, 4, new int[]{10, 20, 30, 40, 50});
        s.seq = new int[]{1, 2, 3, 4, 1};
        g3.add(s);
        g3.remap(map);
        SpriteGroups.Group r = g3.list.get(0);
        check("seq remapeada sem a removida", java.util.Arrays.toString(r.seq) + ":" + java.util.Arrays.toString(r.delayMs) + ":" + r.first + ":" + r.count, "[0, 1, 2, 0]:[10, 20, 40, 50]:0:3");
        // exclusao dos frames + renumeracao (a ordem do app: frames com os indices antigos, depois o mapa)
        Dac d2 = dac(new A().mpt(mpt(0)).mpt(mpt(1)).mpt(mpt(3)).mpt(mpt(4)));
        Set<Integer> set = new HashSet<Integer>();
        set.add(Integer.valueOf(0)); set.add(Integer.valueOf(3));
        SpriteMass.deleteFrames(d2, set);
        SpriteRenumber.remapDac(d2, map);
        check("frames das excluidas saem e os outros descem", imgs(d2.getAno(0)), "0,2");
        System.out.println("SpriteRenumberTest fails=" + fails);
    }
}
