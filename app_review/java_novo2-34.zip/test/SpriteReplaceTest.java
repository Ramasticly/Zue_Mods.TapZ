package com.zue.attackeditor;

import java.util.HashSet;
import java.util.Set;
import static com.zue.attackeditor.BattleTest.*;

/** Excluir sprites SUBSTITUINDO os Frames por outra sprite (e "Trocar os Usos"): troca o IMG com os indices antigos e depois renumera. */
public class SpriteReplaceTest {
    static M mpt(int image) { return new M().time(4).img(image); }

    static Set<Integer> set(Integer... v) { return new HashSet<Integer>(java.util.Arrays.asList(v)); }

    public static void main(String[] args) throws Exception {
        // ANO 0: 0,1,0,40 | ANO 1: 3,40,-1 | ANO 2: 5
        Dac dac = dac(new A[]{
                new A().mpt(mpt(0)).mpt(mpt(1)).mpt(mpt(0)).mpt(mpt(40)),
                new A().mpt(mpt(3)).mpt(mpt(40)).mpt(mpt(-1)),
                new A().mpt(mpt(5))});
        java.util.TreeSet<Integer> ch = SpriteMass.replaceUses(dac, set(0), 40);
        check("0 -> 40: as ANOs alteradas (so a 0)", ch.toString(), "[0]");
        check("2 Frames trocados", SpriteMass.lastReplaced, 2);
        check("ANO 0 ficou 40,1,40,40; as outras nao mudam", SpriteRenumberTest.imgs(dac.getAno(0)) + "|" + SpriteRenumberTest.imgs(dac.getAno(1)) + "|" + SpriteRenumberTest.imgs(dac.getAno(2)), "40,1,40,40|3,40,-1|5");

        // depois da troca, excluir a 0 e renumerar: o 40 vira 39
        boolean[] rem = new boolean[50];
        rem[0] = true;
        int[] map = SpriteRenumber.map(50, rem);
        java.util.TreeSet<Integer> ch2 = SpriteRenumber.remapDac(dac, map);
        check("depois de renumerar a 0 fora: 40 -> 39, 1 -> 0", SpriteRenumberTest.imgs(dac.getAno(0)) + "|" + SpriteRenumberTest.imgs(dac.getAno(1)) + "|" + SpriteRenumberTest.imgs(dac.getAno(2)), "39,0,39,39|2,39,-1|4");
        check("o remap tambem acusa as ANOs que mudaram", ch2.toString(), "[0, 1, 2]");

        // varias saem com UMA substituta: {0,3} -> 40, depois renumera (40 -> 38)
        Dac d2 = dac(new A[]{new A().mpt(mpt(0)).mpt(mpt(3)).mpt(mpt(40)).mpt(mpt(7))});
        SpriteMass.replaceUses(d2, set(0, 3), 40);
        boolean[] r2 = new boolean[50];
        r2[0] = true; r2[3] = true;
        SpriteRenumber.remapDac(d2, SpriteRenumber.map(50, r2));
        check("{0,3} -> 40, renumerado: 38,38,38 e a 7 vira 5", SpriteRenumberTest.imgs(d2.getAno(0)), "38,38,38,5");

        // regras: substituta no conjunto ou negativa = nada
        Dac d3 = dac(new A[]{new A().mpt(mpt(0)).mpt(mpt(3))});
        check("a substituta nao pode estar entre as que saem", SpriteMass.replaceUses(d3, set(0, 3), 3).isEmpty() && SpriteMass.lastReplaced == 0 && SpriteRenumberTest.imgs(d3.getAno(0)).equals("0,3"), true);
        check("substituta negativa: nada", SpriteMass.replaceUses(d3, set(0), -1).isEmpty() && SpriteRenumberTest.imgs(d3.getAno(0)).equals("0,3"), true);
        check("sem uso nenhum: vazio", SpriteMass.replaceUses(d3, set(9), 4).isEmpty() && SpriteMass.lastReplaced == 0, true);
        check("-1 nunca e trocado", SpriteMass.replaceUses(dac(new A[]{new A().mpt(mpt(-1))}), set(0), 2).isEmpty(), true);

        // "Trocar os Usos": troca sem excluir (a sprite continua; nada de renumerar)
        Dac d4 = dac(new A[]{new A().mpt(mpt(2)).mpt(mpt(2)).mpt(mpt(5))});
        SpriteMass.replaceUses(d4, set(2), 5);
        check("trocar os usos da 2 pela 5: indices de todo o resto ficam", SpriteRenumberTest.imgs(d4.getAno(0)), "5,5,5");

        // aviso de tamanho (CNV: largura 10+i, altura 20+i)
        Cnv cnv = SpriteRenumberTest.cnv(6);
        check("tamanhos diferentes: avisa quais saem", SpriteMass.sizeWarning(cnv, set(0, 2), 4).contains("SPR_0 (10x20)") && SpriteMass.sizeWarning(cnv, set(0, 2), 4).contains("SPR_2 (12x22)"), true);
        check("mesma sprite/mesmo tamanho: sem aviso", SpriteMass.sizeWarning(cnv, set(4), 4), "");
        check("destino sem entrada: sem aviso", SpriteMass.sizeWarning(cnv, set(0), 99), "");

        // grava no .txt e le de volta (o persist usa isto)
        java.io.File dir = new java.io.File(System.getProperty("java.io.tmpdir"), "spritereplace_test");
        File0.del(dir);
        dir.mkdirs();
        Dac src = dac(new A[]{new A().mpt(mpt(0)).mpt(mpt(1))});
        Saver.write(new java.io.File(dir, "000.dac.txt"), Saver.dacText(src, null));
        java.util.TreeSet<Integer> c5 = SpriteMass.replaceUses(src, set(0), 1);
        Saver.saveRuntime(dir, src, null == null ? chr(move(new int[]{0, 4}), new byte[0][]) : null, c5, null, false);
        String txt = Saver.readText(new java.io.File(dir, "000.dac.txt"));
        int[] b0 = Saver.findBlock(txt, "ANO_0");
        Ano back = DacText.parseAno(txt.substring(b0[0], b0[2] + 1), 0, null);
        check("o .txt traz o IMG novo", SpriteRenumberTest.imgs(back), "1,1");
        File0.del(dir);
        System.out.println("SpriteReplaceTest fails=" + fails);
    }

    static final class File0 {
        static void del(java.io.File f) { java.io.File[] k = f.listFiles(); if (k != null) for (java.io.File c : k) del(c); f.delete(); }
    }
}
