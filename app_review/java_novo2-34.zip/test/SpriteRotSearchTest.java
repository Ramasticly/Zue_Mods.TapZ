package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** Copias giradas em qualquer angulo (com escala/achatamento/espelho): deteccao, mapa geometrico e aplicacao no DAC. */
public class SpriteRotSearchTest {
    /** R = Rot(theta) . S . M . K  (modelo do DAC). Devolve {px, w, h}; {@code c} recebe o centro de K e de R. */
    static Object[] rotated(int[] k, int kw, int kh, double thetaDeg, double sx, double sy, boolean mirror) {
        double t = Math.toRadians(thetaDeg), ct = Math.cos(t), st = Math.sin(t);
        double minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
        for (int i = 0; i < 4; i++) {
            double x = ((i & 1) * kw - kw / 2.0) * (mirror ? -1 : 1) * sx, y = ((i >> 1) * kh - kh / 2.0) * sy;
            double rx = x * ct - y * st, ry = x * st + y * ct;
            minx = Math.min(minx, rx); maxx = Math.max(maxx, rx); miny = Math.min(miny, ry); maxy = Math.max(maxy, ry);
        }
        int w = (int) Math.ceil(maxx - minx) + 2, h = (int) Math.ceil(maxy - miny) + 2;
        int[] out = new int[w * h];
        for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
            double rx = i + 0.5 - w / 2.0, ry = j + 0.5 - h / 2.0;
            double qx = rx * ct + ry * st, qy = -rx * st + ry * ct;               // Rot(-theta)
            double kx = qx / sx * (mirror ? -1 : 1) + kw / 2.0, ky = qy / sy + kh / 2.0;
            out[j * w + i] = bil(k, kw, kh, kx, ky);
        }
        return new Object[]{out, Integer.valueOf(w), Integer.valueOf(h)};
    }

    static int bil(int[] px, int w, int h, double x, double y) {
        double fx = x - 0.5, fy = y - 0.5;
        int x0 = (int) Math.floor(fx), y0 = (int) Math.floor(fy);
        double tx = fx - x0, ty = fy - y0;
        double a = 0, r = 0, g = 0, b = 0;
        for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
            int sx = x0 + i, sy = y0 + j;
            if (sx < 0 || sy < 0 || sx >= w || sy >= h) continue;
            double wt = (i == 0 ? 1 - tx : tx) * (j == 0 ? 1 - ty : ty);
            int c = px[sy * w + sx];
            double ca = (c >>> 24) * wt;
            a += ca; r += ca * ((c >> 16) & 255); g += ca * ((c >> 8) & 255); b += ca * (c & 255);
        }
        if (a <= 0) return 0;
        return ((int) Math.min(255, Math.round(a)) << 24) | ((int) Math.min(255, Math.round(r / a)) << 16) | ((int) Math.min(255, Math.round(g / a)) << 8) | (int) Math.min(255, Math.round(b / a));
    }

    static SpriteDedup.Sig sig(int idx, Object[] o) { return SpriteDedup.sig(idx, (int[]) o[0], (Integer) o[1], (Integer) o[2], (Integer) o[1], (Integer) o[2]); }

    static double angleDiff(double a, double b) {
        double d = Math.abs(a - b) % 360;
        return d > 180 ? 360 - d : d;
    }

    public static void main(String[] args) throws Exception {
        int[] k = SpriteScaleTest.art(5, 60, 60, 2);
        SpriteDedup.Sig ks = SpriteDedup.sig(0, k, 60, 60, 60, 60);
        double[] angles = {30, 45, -20, 100, 170, 7, 90, -135};
        int good = 0;
        StringBuilder log = new StringBuilder();
        for (double th : angles) {
            Object[] r = rotated(k, 60, 60, th, 0.6, 0.6, false);
            SpriteDedup.Match m = SpriteRotSearch.find(sig(1, r), ks, SpriteRotSearch.FLOOR);
            boolean ok = m != null && m.score >= 85 && angleDiff(m.rotDeg, th) <= 2 && !m.mirror;
            if (ok) good++; else log.append(" " + th + "=" + (m == null ? "null" : m.score + "@" + m.rotDeg + (m.mirror ? "m" : "")));
            check("angulo " + th + " achado (nota >= 85, erro <= 2 graus)", ok, true);
        }
        System.out.println("angulos ok: " + good + "/" + angles.length + log);

        // espelhada + girada
        Object[] rm = rotated(k, 60, 60, 30, 0.6, 0.6, true);
        SpriteDedup.Match mm = SpriteRotSearch.find(sig(1, rm), ks, SpriteRotSearch.FLOOR);
        check("espelhada e girada 30: achada", mm != null && mm.mirror && angleDiff(mm.rotDeg, 30) <= 2 && mm.score >= 85, true);

        // achatada e depois girada
        Object[] rs = rotated(k, 60, 60, 25, 1.0, 0.5, false);
        SpriteDedup.Match ms = SpriteRotSearch.find(sig(1, rs), ks, SpriteRotSearch.FLOOR);
        check("achatada (100% x 50%) e girada 25: achada", ms != null && angleDiff(ms.rotDeg, 25) <= 2 && ms.score >= 85, true);

        // nao relacionadas nao casam
        int fp = 0, n = 0;
        for (long seed = 200; seed < 206; seed++) {
            int[] other = SpriteScaleTest.art(seed, 60, 60, 2);
            for (double th : new double[]{0, 30, 77}) {
                Object[] r = rotated(other, 60, 60, th, 0.6, 0.6, false);
                n++;
                if (SpriteRotSearch.find(sig(1, r), ks, SpriteRotSearch.FLOOR) != null) fp++;
            }
        }
        check("imagens diferentes (giradas) nao casam: 0 de " + n, fp, 0);

        // o mapa leva um ponto da copia ao ponto certo de K
        Object[] r30 = rotated(k, 60, 60, 30, 0.6, 0.6, false);
        SpriteDedup.Sig rsig = sig(1, r30);
        SpriteDedup.Match m30 = SpriteRotSearch.find(rsig, ks, SpriteRotSearch.FLOOR);
        int wr = (Integer) r30[1], hr = (Integer) r30[2];
        double t = Math.toRadians(30), ct = Math.cos(t), st = Math.sin(t);
        double worst = 0;
        for (double[] kp : new double[][]{{15, 20}, {45, 18}, {30, 48}, {10, 50}}) {
            double qx = (kp[0] - 30) * 0.6, qy = (kp[1] - 30) * 0.6;                 // S . (p - c)
            double rx = qx * ct - qy * st + wr / 2.0, ry = qx * st + qy * ct + hr / 2.0;   // posicao na copia, em px
            double u = rx / wr, v = ry / hr;
            double ku = m30.gen[0] * u + m30.gen[1] * v + m30.gen[4], kv = m30.gen[2] * u + m30.gen[3] * v + m30.gen[5];
            worst = Math.max(worst, Math.hypot(ku * 60 - kp[0], kv * 60 - kp[1]));
        }
        check("mapa gen leva 4 pontos da copia girada aos de K (erro < 3 px)", worst < 3, true);
        System.out.println("erro do mapa (px): " + worst);

        // aplicar no DAC: a copia (sprite 1) passa a usar K (sprite 0) com rotacao/zoom, ponto marcado no mesmo lugar do mundo
        Dac d = dac(new A().mpt(new M().time(4).img(1)));
        SpriteXform.Frame f0 = SpriteXform.read(d.getAno(0).mpts[0]);
        SpriteDedup.Choice c = new SpriteDedup.Choice();
        c.removed = rsig; c.kept = ks; c.match = m30;
        SpriteDedup.Result res = SpriteDedup.apply(d, java.util.Arrays.asList(c));
        check("apply: sprite removida e frame reescrito", res.removedSprites.contains(Integer.valueOf(1)) && res.framesRewritten == 1, true);
        Ano.Mpt nm = d.getAno(0).mpts[0];
        SpriteXform.Frame f1 = SpriteXform.read(nm);
        System.out.println("novo frame: img " + nm.image + " rot " + nm.rot + " zoom " + nm.xZoom + "x" + nm.yZoom + " mid " + nm.midX + "," + nm.midY + " flips " + f1.flipH + f1.flipV);
        double werr = 0;
        for (double[] kp : new double[][]{{15, 20}, {45, 18}, {30, 48}, {10, 50}}) {
            double qx = (kp[0] - 30) * 0.6, qy = (kp[1] - 30) * 0.6;
            double rx = qx * ct - qy * st + wr / 2.0, ry = qx * st + qy * ct + hr / 2.0;
            double[] pr = SpriteXform.place(f0, wr, hr, rx / wr, ry / hr), pk = SpriteXform.place(f1, 60, 60, kp[0] / 60, kp[1] / 60);
            werr = Math.max(werr, Math.hypot(pr[0] - pk[0], pr[1] - pk[1]));
        }
        check("apply: o ponto marcado cai no mesmo lugar do mundo (erro < 3 px)", werr < 3, true);
        System.out.println("erro no mundo (px): " + werr);

        // varredura inteira: grupos usam o mapa de angulos
        List<SpriteDedup.Sig> all = new ArrayList<SpriteDedup.Sig>();
        all.add(ks);
        all.add(rsig);
        all.add(SpriteDedup.sig(2, SpriteScaleTest.art(300, 60, 60, 2), 60, 60, 60, 60));
        all.add(SpriteDedup.sig(3, SpriteScaleTest.art(301, 50, 50, 2), 50, 50, 50, 50));
        SpriteDedup.Matcher mx = SpriteRotSearch.run(all, SpriteRotSearch.FLOOR, 60000, null);
        check("run: completo e achou o par girado", mx.complete && mx.rot.containsKey(Long.valueOf(SpriteDedup.Matcher.key(1, 0))), true);
        List<SpriteDedup.Group> gs = SpriteDedup.groups(all, 85, mx);
        check("groups com o mapa de angulos: 1 grupo {0, 1}", gs.size() == 1 && gs.get(0).rep() == 0 && gs.get(0).members.size() == 2 && gs.get(0).members.get(1).index == 1, true);
        check("groups sem o mapa: nada", SpriteDedup.groups(all, 85).isEmpty(), true);
        SpriteDedup.Matcher cut = SpriteRotSearch.run(all, SpriteRotSearch.FLOOR, -1, null);
        check("orcamento de tempo estourado: parcial e avisa", !cut.complete, true);
        final int[] calls = {0};
        SpriteDedup.Matcher cancelled = SpriteRotSearch.run(all, SpriteRotSearch.FLOOR, 60000, new SpriteRotSearch.Progress() { @Override public boolean on(int d2, int t2) { return ++calls[0] < 2; } });
        check("cancelar: parcial", !cancelled.complete && calls[0] == 2, true);
    }
}
