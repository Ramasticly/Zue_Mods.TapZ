package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static com.zue.attackeditor.BattleTest.*;

/** Sprites repetidas em outra escala, achatadas, com margem diferente e suavizadas (box/bilinear): o que o vizinho mais proximo escondia. */
public class SpriteScaleTest {
    /** "Personagem" sintetico: elipses e retangulos coloridos com detalhes, fundo transparente e margem de {@code m} px. */
    static int[] art(long seed, int w, int h, int m) {
        Random rnd = new Random(seed);
        int[] p = new int[w * h];
        int iw = w - 2 * m, ih = h - 2 * m;
        for (int k = 0; k < 7; k++) {
            double cx = m + rnd.nextDouble() * iw, cy = m + rnd.nextDouble() * ih;
            double rx = iw * (0.12 + rnd.nextDouble() * 0.25), ry = ih * (0.12 + rnd.nextDouble() * 0.25);
            int col = 0xFF000000 | (40 + rnd.nextInt(200)) << 16 | (40 + rnd.nextInt(200)) << 8 | (40 + rnd.nextInt(200));
            boolean rect = k % 3 == 0;
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
                boolean in = rect ? Math.abs(dx) < 1 && Math.abs(dy) < 1 : dx * dx + dy * dy < 1;
                if (in && x >= m && y >= m && x < w - m && y < h - m) p[y * w + x] = col;
            }
        }
        return p;
    }

    /** Reducao/ampliacao com filtro bilinear (amostra no centro, alpha pre-multiplicado). */
    static int[] bilinear(int[] px, int w, int h, int nw, int nh) {
        int[] out = new int[nw * nh];
        for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
            double fx = (x + 0.5) * w / nw - 0.5, fy = (y + 0.5) * h / nh - 0.5;
            int x0 = (int) Math.floor(fx), y0 = (int) Math.floor(fy);
            double tx = fx - x0, ty = fy - y0;
            double a = 0, r = 0, g = 0, b = 0;
            for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
                int sx = Math.max(0, Math.min(w - 1, x0 + i)), sy = Math.max(0, Math.min(h - 1, y0 + j));
                double wt = (i == 0 ? 1 - tx : tx) * (j == 0 ? 1 - ty : ty);
                int c = px[sy * w + sx];
                double ca = (c >>> 24) / 255.0;
                a += wt * ca; r += wt * ca * ((c >> 16) & 255); g += wt * ca * ((c >> 8) & 255); b += wt * ca * (c & 255);
            }
            if (a <= 0) continue;
            out[y * nw + x] = ((int) Math.round(a * 255) << 24) | ((int) Math.min(255, Math.round(r / a)) << 16) | ((int) Math.min(255, Math.round(g / a)) << 8) | (int) Math.min(255, Math.round(b / a));
        }
        return out;
    }

    /** Reducao com media por area (box filter). */
    static int[] boxResize(int[] px, int w, int h, int nw, int nh) { return SpriteDedup.box(px, w, h, 0, 0, w, h, nw, nh); }

    static SpriteDedup.Sig sig(int idx, int[] px, int w, int h) { return SpriteDedup.sig(idx, px, w, h, w, h); }

    static int score(int[] big, int w, int h, int nw, int nh, boolean box) {
        int[] small = box ? boxResize(big, w, h, nw, nh) : bilinear(big, w, h, nw, nh);
        SpriteDedup.Match m = SpriteDedup.best(sig(1, small, nw, nh), sig(0, big, w, h), 0);
        return m == null ? -1 : m.score;
    }

    public static void main(String[] args) throws Exception {
        int ok = 0, tot = 0, min = 100;
        StringBuilder worst = new StringBuilder();
        for (long seed = 1; seed <= 6; seed++) {
            int[] big = art(seed, 64, 64, 4);
            int[][] sizes = {{48, 48}, {32, 32}, {25, 25}, {37, 41}, {64, 32}, {20, 64}, {45, 23}};
            for (int[] sz : sizes) {
                for (int mode = 0; mode < 2; mode++) {
                    int sc = score(big, 64, 64, sz[0], sz[1], mode == 0);
                    tot++;
                    min = Math.min(min, sc);
                    if (sc >= 90) ok++; else worst.append(" seed" + seed + " " + sz[0] + "x" + sz[1] + (mode == 0 ? "box" : "bil") + "=" + sc);
                }
            }
        }
        System.out.println("escalas/achatadas >= 90: " + ok + "/" + tot + worst);
        check("copias reduzidas/achatadas (box e bilinear, ate 39%) passam de 90% (resto fica >= 80)", ok >= tot - 4 && min >= 80, true);

        // objetos pequenos (tamanho logico arredondado)
        int[] small = art(11, 30, 17, 1);
        int[] half = boxResize(small, 30, 17, 15, 8);
        SpriteDedup.Match ms = SpriteDedup.best(sig(1, half, 15, 8), sig(0, small, 30, 17), 80);
        check("30x17 -> 15x8 (proporcao nao bate por arredondamento) acha", ms != null, true);
        int[] half2 = boxResize(small, 30, 17, 15, 9);
        check("30x17 -> 15x9 acha", SpriteDedup.best(sig(1, half2, 15, 9), sig(0, small, 30, 17), 80) != null, true);

        // margens diferentes (recorte justo)
        int[] a = art(21, 48, 48, 0);
        int[] padded = new int[72 * 60];
        for (int y = 0; y < 48; y++) System.arraycopy(a, y * 48, padded, (y + 7) * 72 + 11, 48);
        SpriteDedup.Match mp = SpriteDedup.best(sig(1, padded, 72, 60), sig(0, a, 48, 48), 95);
        check("mesma imagem com margens transparentes diferentes: 100% de celulas", mp != null && mp.score >= 95, true);
        SpriteDedup.Match mp2 = SpriteDedup.best(sig(1, padded, 72, 60), sig(0, a, 48, 48), 95);
        double[] gen = mp2.gen;
        // o ponto da imagem (11/72, 7/60) cai no canto (0, 0) de K
        check("mapa da margem leva o canto do conteudo ao canto de K", Math.abs(gen[4] + gen[0] * 11.0 / 72 + gen[1] * 7.0 / 60) < 0.02 && Math.abs(gen[5] + gen[2] * 11.0 / 72 + gen[3] * 7.0 / 60) < 0.02, true);

        // nao relacionadas
        int fp = 0, pairs = 0;
        List<int[]> imgs = new ArrayList<int[]>();
        for (long s = 100; s < 112; s++) imgs.add(art(s, 40, 40, 3));
        for (int i = 0; i < imgs.size(); i++) for (int j = i + 1; j < imgs.size(); j++) {
            pairs++;
            if (SpriteDedup.best(sig(1, imgs.get(i), 40, 40), sig(0, imgs.get(j), 40, 40), 90) != null) fp++;
        }
        check("imagens diferentes nao casam (" + pairs + " pares)", fp, 0);
        // dois retangulos cheios de cores diferentes
        int[] red = new int[40 * 40], blue = new int[40 * 40];
        java.util.Arrays.fill(red, 0xFFD02020); java.util.Arrays.fill(blue, 0xFF2020D0);
        check("cores diferentes nao casam", SpriteDedup.best(sig(1, red, 40, 40), sig(0, blue, 40, 40), 60) == null, true);
        // um retangulo cheio e uma elipse da mesma cor
        int[] ell = new int[40 * 40];
        for (int y = 0; y < 40; y++) for (int x = 0; x < 40; x++) { double dx = (x - 19.5) / 20, dy = (y - 19.5) / 20; if (dx * dx + dy * dy < 1) ell[y * 40 + x] = 0xFFD02020; }
        check("retangulo e elipse da mesma cor nao passam de 90%", SpriteDedup.best(sig(1, ell, 40, 40), sig(0, red, 40, 40), 90) == null, true);

        // achatamento extremo e sprite vazia
        int[] thin = boxResize(a, 48, 48, 48, 4);
        check("achatamento 12x e recusado em best", SpriteDedup.best(sig(1, thin, 48, 4), sig(0, a, 48, 48), 0) == null, true);
        check("sprite vazia nunca casa", SpriteDedup.best(sig(1, new int[100], 10, 10), sig(0, a, 48, 48), 0) == null, true);

        // aplicar: a copia achatada (zoom Y 50%) vira a grande com zoom 100 x 50
        int[] sq = boxResize(a, 48, 48, 48, 24);
        SpriteDedup.Sig rs = sig(1, sq, 48, 24), ks = sig(0, a, 48, 48);
        SpriteDedup.Choice c = SpriteDedup.choose(rs, java.util.Arrays.asList(ks), 80);
        check("choose acha a grande para a achatada", c != null, true);
        Dac d = dac(new A().mpt(new M().time(4).img(1)));
        SpriteXform.Frame f0 = SpriteXform.read(d.getAno(0).mpts[0]);
        SpriteDedup.apply(d, java.util.Arrays.asList(c));
        Ano.Mpt n = d.getAno(0).mpts[0];
        check("DAC: imagem 0 com zoom 100 x 50", n.image + ":" + n.xZoom + ":" + n.yZoom, "0:100:50");
        SpriteXform.Frame f1 = SpriteXform.read(n);
        double[] pr = SpriteXform.place(f0, 48, 24, 1, 1), pk = SpriteXform.place(f1, 48, 48, 1, 1);
        check("canto inferior direito no mesmo lugar", Math.hypot(pr[0] - pk[0], pr[1] - pk[1]) < 1.5, true);

        // ---- resolver geral
        SpriteXform.Frame id = new SpriteXform.Frame();
        check("solve: zoom que daria 0 (R 3 px, K 1000 px) e recusado", SpriteXform.solve(id, 3, 3, 1000, 1000, 0, true) == null, true);
        check("solve: cisalhamento (eixos nao ortogonais) recusado", SpriteXform.solve(id, 40, 40, 40, 40, new double[]{1, 0.5, 0, 1, 0, 0}, true) == null, true);
        SpriteXform.Frame f8 = SpriteXform.solve(id, 40, 40, 20, 20, 0, true);
        check("solve: K metade do tamanho = zoom 200", f8 != null && f8.zx == 200 && f8.zy == 200, true);
        SpriteXform.Frame fg = SpriteXform.solve(id, 40, 40, 20, 20, SpriteXform.G[0], true);
        check("solve geral com G[0] igual ao int g", fg != null && fg.zx == f8.zx && fg.ox == f8.ox && fg.rot == f8.rot, true);

        // ---- agrupamento em cadeia e escolha de quem fica
        int[] A = art(31, 80, 80, 2);
        int[] B = boxResize(A, 80, 80, 40, 40);
        int[] C = boxResize(A, 80, 80, 20, 20);
        List<SpriteDedup.Sig> trio = new ArrayList<SpriteDedup.Sig>(java.util.Arrays.asList(sig(10, A, 80, 80), sig(11, B, 40, 40), sig(12, C, 20, 20)));
        List<SpriteDedup.Group> gr = SpriteDedup.groups(trio, 80);
        check("A, B (50%) e C (25%) formam um grupo com A de representante", gr.size() == 1 && gr.get(0).rep() == 10 && gr.get(0).members.size() == 3, true);
        SpriteDedup.Choice ch = SpriteDedup.choose(trio.get(0), java.util.Arrays.asList(trio.get(1), trio.get(2)), 0);
        check("choose: a grande tambem se refaz com a pequena (sem portao de proporcao)", ch != null, true);
        SpriteDedup.Choice ch2 = SpriteDedup.choose(trio.get(2), java.util.Arrays.asList(trio.get(0), trio.get(1)), 0);
        check("choose: para a menor, mantem uma maior (zoom <= 105)", ch2 != null && ch2.match.up <= 105, true);
        // com tamanhos iguais em area mas eixos diferentes, nao mistura: 60x20 e 20x60 do mesmo desenho viram 90 graus
        int[] wide = art(41, 60, 20, 1);
        int[] tall = new int[20 * 60];
        for (int y = 0; y < 20; y++) for (int x = 0; x < 60; x++) tall[x * 20 + (19 - y)] = wide[y * 60 + x];     // girada 90 graus
        SpriteDedup.Match m90 = SpriteDedup.best(sig(1, tall, 20, 60), sig(0, wide, 60, 20), 90);
        check("girada 90 sem escala: acha com g de troca de eixos e zoom 100", m90 != null && m90.g >= 4 && Math.abs(m90.up - 100) < 3, true);
    }
}
