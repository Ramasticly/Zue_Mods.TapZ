package com.zue.attackeditor;

import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** Ordens da lista de sprites: bytes, Px, usos e semelhanca (identicas juntas no topo); vazias por ultimo; empate pelo numero. */
public class SpriteSortTest {
    static String s(List<Integer> l) { StringBuilder b = new StringBuilder(); for (Integer i : l) b.append(b.length() == 0 ? "" : ",").append(i); return b.toString(); }

    public static void main(String[] args) throws Exception {
        int[] w = {10, 20, 0, 5, 20}, h = {10, 5, 0, 5, 5};          // px: 100, 100, vazia, 25, 100
        check("numero: ordem natural", s(SpriteSort.order(SpriteSort.NUMBER, 5, w, h, null, null, null)), "0,1,2,3,4");
        check("bytes decrescente: empates pelo numero, vazia por ultimo", s(SpriteSort.order(SpriteSort.BYTES_DESC, 5, w, h, null, null, null)), "0,1,4,3,2");
        check("bytes crescente: menor primeiro, vazia ainda por ultimo", s(SpriteSort.order(SpriteSort.BYTES_ASC, 5, w, h, null, null, null)), "3,0,1,4,2");
        check("px decrescente e crescente", s(SpriteSort.order(SpriteSort.PX_DESC, 5, w, h, null, null, null)) + "|" + s(SpriteSort.order(SpriteSort.PX_ASC, 5, w, h, null, null, null)), "0,1,4,3,2|3,0,1,4,2");
        int[] uses = {3, 0, 9, 3, 1};
        check("mais usos primeiro (vazia por ultimo mesmo com 9 usos)", s(SpriteSort.order(SpriteSort.USES_DESC, 5, w, h, uses, null, null)), "0,3,4,1,2");
        check("menos usos primeiro", s(SpriteSort.order(SpriteSort.USES_ASC, 5, w, h, uses, null, null)), "1,4,0,3,2");

        // parecidas: 0,3,5 identicas entre si (100), 1 e 4 com 95, 2 sem par
        int[] w2 = {8, 8, 8, 8, 8, 8, 8}, h2 = {8, 8, 8, 8, 8, 8, 8};
        int[] best = {100, 95, -1, 100, 95, 100, 40}, partner = {3, 4, -1, 0, 1, 0, 1};
        check("mais parecidas: as 3 identicas (100%) no topo juntas, depois as de 95%, depois 40%, sem par por ultimo",
                s(SpriteSort.order(SpriteSort.SIMILAR, 7, w2, h2, null, best, partner)), "0,3,5,1,4,6,2");
        check("empate de nota: o par fica junto (pelo menor indice do par)", s(SpriteSort.order(SpriteSort.SIMILAR, 4, new int[]{8, 8, 8, 8}, new int[]{8, 8, 8, 8}, null, new int[]{90, 90, 90, 90}, new int[]{2, 3, 0, 1})), "0,2,1,3");

        check("bytes = L x A x 4", SpriteSort.bytes(10, 5), 200L);
        check("separador de milhar", SpriteSort.grouped(1280) + "," + SpriteSort.grouped(12) + "," + SpriteSort.grouped(1234567), "1.280,12,1.234.567");
        check("texto do criterio", SpriteSort.info(SpriteSort.BYTES_DESC, 0, w, h, null, null) + "|" + SpriteSort.info(SpriteSort.PX_ASC, 1, w, h, null, null) + "|" + SpriteSort.info(SpriteSort.USES_DESC, 0, w, h, uses, null) + "|" + SpriteSort.info(SpriteSort.SIMILAR, 0, w, h, null, best),
                "400 B|20×5 px|3 usos|100%");
        check("1 uso no singular e sem par", SpriteSort.info(SpriteSort.USES_ASC, 4, w, h, uses, null) + "," + SpriteSort.info(SpriteSort.SIMILAR, 2, w, h, null, best), "1 uso,sem par");

        // contagem de usos contra o DAC
        Ano.Mpt m1 = new Ano.Mpt(), m2 = new Ano.Mpt(), m3 = new Ano.Mpt();
        m1.image = 0; m2.image = 2; m3.image = 2;
        java.lang.reflect.Constructor<Dac> cc = Dac.class.getDeclaredConstructor(Ano[].class, java.util.List.class);
        cc.setAccessible(true);
        Dac d = cc.newInstance((Object) new Ano[]{new Ano(0, true, 0, 0, null, new Ano.Mpt[]{m1, m2}), new Ano(1, true, 0, 0, null, new Ano.Mpt[]{m3})}, new java.util.ArrayList<String>());
        check("useCounts: SPR_0 1 uso, SPR_2 2 usos", java.util.Arrays.toString(SpriteSort.useCounts(d, 4)), "[1, 0, 2, 0]");
    }
}
