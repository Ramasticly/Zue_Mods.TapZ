package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import static com.zue.attackeditor.BattleTest.*;

/** Conferencia em pixels, criterios configuraveis, tabela de pares e marcas da grade de "Remover Sprites repetidas". */
public class SpriteVerifyTest {
    static SpriteDedup.Sig sig(int idx, int[] px, int w, int h) { return SpriteDedup.sig(idx, px, w, h, w, h); }

    /** Variantes "parecidas, mas diferentes" do desenho {@code seed}: 0 = uma elipse de outra cor, 1 = um quarto deslocado, 2 = uma elipse extra. */
    static int[] variant(long seed, int w, int h, int kind) {
        int[] a = SpriteScaleTest.art(seed, w, h, 4);
        Random r = new Random(seed * 31 + kind);
        if (kind == 0) {
            int col = 0xFF000000 | (r.nextInt(200) + 40) << 16 | (r.nextInt(200) + 40) << 8 | (r.nextInt(200) + 40);
            int cx = w / 2 + r.nextInt(w / 4) - w / 8, cy = h / 2 + r.nextInt(h / 4) - h / 8, rad = Math.max(4, w / 6);
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (a[y * w + x] != 0 && (x - cx) * (x - cx) + (y - cy) * (y - cy) < rad * rad) a[y * w + x] = col;
        } else if (kind == 1) {
            int[] b = new int[a.length];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) { int sy = y; if (x > w / 2) sy = Math.min(h - 1, Math.max(0, y - h / 8)); b[y * w + x] = a[sy * w + x]; }
            a = b;
        } else {
            int col = 0xFF000000 | (r.nextInt(200) + 40) << 16 | (r.nextInt(200) + 40) << 8 | (r.nextInt(200) + 40);
            int cx = r.nextInt(w - 8) + 4, cy = r.nextInt(h - 8) + 4, rad = Math.max(4, w / 7);
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < rad * rad && x >= 4 && y >= 4 && x < w - 4 && y < h - 4) a[y * w + x] = col;
        }
        return a;
    }

    static int groupedWith(List<SpriteDedup.Sig> sigs, DedupOptions o, int minPct) {
        DedupAnalysis an = DedupAnalysis.analyze(sigs, null, 600000);
        List<SpriteDedup.Group> g = an.groups(sigs, minPct, o);
        int n = 0;
        for (SpriteDedup.Group x : g) n += x.members.size() - 1;
        return n;
    }

    /** Mapa afim de uma rotacao de {@code deg} graus em torno do centro (retangulo quadrado). */
    static double[] rotMap(double deg) {
        double t = Math.toRadians(deg), c = Math.cos(t), si = Math.sin(t);
        return new double[]{c, -si, si, c, 0.5 - 0.5 * c + 0.5 * si, 0.5 - 0.5 * si - 0.5 * c};
    }

    static SpriteDedup.Match fake(int score, int g, double sx, double sy, double up) {
        SpriteDedup.Match m = new SpriteDedup.Match(score, g);
        m.sx = sx; m.sy = sy; m.up = up;
        return m;
    }

    public static void main(String[] args) throws Exception {
        // ---- copias reamostradas agrupam com os criterios padrao
        int copiesOk = 0, copiesTot = 0;
        int[][] sizes = {{48, 48}, {32, 32}, {37, 41}, {64, 32}, {20, 64}, {45, 23}};
        for (long seed = 1; seed <= 4; seed++) {
            int[] big = SpriteScaleTest.art(seed, 64, 64, 4);
            for (int[] s : sizes) for (int mode = 0; mode < 2; mode++) {
                int[] sm = mode == 0 ? SpriteScaleTest.boxResize(big, 64, 64, s[0], s[1]) : SpriteScaleTest.bilinear(big, 64, 64, s[0], s[1]);
                List<SpriteDedup.Sig> two = new ArrayList<SpriteDedup.Sig>(Arrays.asList(sig(0, big, 64, 64), sig(1, sm, s[0], s[1])));
                copiesTot++;
                if (groupedWith(two, new DedupOptions(), 90) == 1) copiesOk++;
            }
        }
        check("copias (box/bilinear, escala e achatamento) agrupam com o padrao: " + copiesOk + "/" + copiesTot, copiesOk, copiesTot);

        // ---- parecidas mas diferentes quase nunca agrupam (e a deslocada nunca)
        String[] kn = {"outra cor em uma elipse", "um quarto deslocado", "elipse extra"};
        int[] cap = {4, 0, 5};
        for (int kind = 0; kind < 3; kind++) {
            int grouped = 0, total = 20;
            for (long seed = 1; seed <= total; seed++) {
                int[] v = SpriteScaleTest.boxResize(variant(seed, 64, 64, kind), 64, 64, 48, 48);
                List<SpriteDedup.Sig> two = new ArrayList<SpriteDedup.Sig>(Arrays.asList(sig(0, SpriteScaleTest.art(seed, 64, 64, 4), 64, 64), sig(1, v, 48, 48)));
                if (groupedWith(two, new DedupOptions(), 90) == 1) grouped++;
            }
            check("parecidas mas diferentes (" + kn[kind] + "): agrupam " + grouped + " de " + total + " (limite " + cap[kind] + ")", grouped <= cap[kind], true);
        }

        // ---- criterios ligados/desligados mudam o resultado
        int hit = -1;
        for (long seed = 1; seed <= 40 && hit < 0; seed++) {
            int[] v = SpriteScaleTest.boxResize(variant(seed, 64, 64, 1), 64, 64, 48, 48);
            SpriteDedup.Sig k = sig(0, SpriteScaleTest.art(seed, 64, 64, 4), 64, 64), r = sig(1, v, 48, 48);
            SpriteDedup.Match m = SpriteDedup.best(r, k, 90);
            if (m != null) hit = (int) seed;
        }
        check("existe uma deslocada com nota de celulas >= 90 (o caso que antes agrupava)", hit > 0, true);
        if (hit > 0) {
            int[] v = SpriteScaleTest.boxResize(variant(hit, 64, 64, 1), 64, 64, 48, 48);
            List<SpriteDedup.Sig> two = new ArrayList<SpriteDedup.Sig>(Arrays.asList(sig(0, SpriteScaleTest.art(hit, 64, 64, 4), 64, 64), sig(1, v, 48, 48)));
            check("padrao: nao agrupa (forma/cor/detalhes barram)", groupedWith(two, new DedupOptions(), 90), 0);
            DedupOptions off = new DedupOptions();
            off.shape.on = false; off.color.on = false; off.detail.on = false; off.palette.on = false;
            check("sem os criterios de pixels: agrupa (so as celulas)", groupedWith(two, off, 90), 1);
            DedupOptions loose = new DedupOptions();
            loose.shape.set(50); loose.color.set(50); loose.detail.set(0);
            check("tolerancias baixas tambem deixam agrupar", groupedWith(two, loose, 90), 1);
        }

        // ---- giradas em angulo qualquer agrupam; criterio de angulo desliga
        int[] k60 = SpriteScaleTest.art(5, 60, 60, 2);
        Object[] r30 = SpriteRotSearchTest.rotated(k60, 60, 60, 30, 0.6, 0.6, false);
        List<SpriteDedup.Sig> rotPair = new ArrayList<SpriteDedup.Sig>(Arrays.asList(SpriteDedup.sig(0, k60, 60, 60, 60, 60), SpriteRotSearchTest.sig(1, r30)));
        check("girada 30 agrupa com o padrao", groupedWith(rotPair, new DedupOptions(), 85), 1);
        DedupOptions noAngle = new DedupOptions();
        noAngle.anyAngle.on = false;
        check("sem 'girar em qualquer angulo': nao agrupa", groupedWith(rotPair, noAngle, 85), 0);
        Object[] rm = SpriteRotSearchTest.rotated(k60, 60, 60, 30, 0.6, 0.6, true);
        List<SpriteDedup.Sig> mirPair = new ArrayList<SpriteDedup.Sig>(Arrays.asList(SpriteDedup.sig(0, k60, 60, 60, 60, 60), SpriteRotSearchTest.sig(1, rm)));
        check("espelhada e girada agrupa", groupedWith(mirPair, new DedupOptions(), 85), 1);
        DedupOptions noMirror = new DedupOptions();
        noMirror.mirror.on = false;
        check("sem 'espelhar': nao agrupa", groupedWith(mirPair, noMirror, 85), 0);

        // ---- accepts: achatamento, ampliacao, 90 graus, espelho
        DedupOptions o = new DedupOptions();
        check("achatamento 5x recusado (limite 4x)", o.accepts(fake(95, 0, 1.0, 0.2, 100), 90), false);
        check("achatamento 4x aceito", o.accepts(fake(95, 0, 1.0, 0.25, 100), 90), true);
        o.stretch.set(80);
        check("achatamento 5x aceito com limite 8x", o.accepts(fake(95, 0, 1.0, 0.2, 100), 90), true);
        check("ampliacao desligada por padrao", o.accepts(fake(95, 0, 0.5, 0.5, 200), 90), true);
        o.enlarge.on = true;
        check("ampliacao 200% recusada com limite 125%", o.accepts(fake(95, 0, 0.5, 0.5, 200), 90), false);
        check("nota abaixo da barra recusa", o.accepts(fake(89, 0, 1, 1, 100), 90), false);
        o.turn90.on = false;
        check("sem 'girar 90': g=5 recusado, g=1 (espelho) aceito", o.accepts(fake(95, 5, 1, 1, 100), 90) + ":" + o.accepts(fake(95, 1, 1, 1, 100), 90), "false:true");
        o.mirror.on = false;
        check("sem 'espelhar': g=1 recusado, g=3 (180) recusado por 90", o.accepts(fake(95, 1, 1, 1, 100), 90) + ":" + o.accepts(fake(95, 3, 1, 1, 100), 90), "false:false");
        o.reset();
        check("reset volta ao padrao", o.isDefault(), true);
        o.shape.set(10);
        check("valor fora da faixa e cortado (forma >= 50)", o.shape.value, 50);
        DedupOptions c = o.copy();
        check("copia independente", c.shape.value + ":" + (c != o), "50:true");
        check("padroes: forma 96, cor 95, detalhes 65, paleta 70, achatamento 4x, cadeia desligada", new DedupOptions().shape.value + ":" + new DedupOptions().color.value + ":" + new DedupOptions().detail.value + ":" + new DedupOptions().palette.value + ":" + new DedupOptions().stretch.value + ":" + new DedupOptions().chain.on, "96:95:65:70:40:false");

        // ---- cadeia: A~B e B~C, mas A nao casa com C
        int[] A = SpriteScaleTest.art(7, 80, 80, 2), B = SpriteScaleTest.art(7, 60, 60, 2), C = SpriteScaleTest.art(7, 40, 40, 2);
        List<SpriteDedup.Sig> trio = new ArrayList<SpriteDedup.Sig>(Arrays.asList(sig(10, A, 80, 80), sig(11, B, 60, 60), sig(12, C, 40, 40)));
        DedupAnalysis fab = new DedupAnalysis();
        for (SpriteDedup.Sig s : trio) fab.byIndex.put(Integer.valueOf(s.index), s);
        fab.pairs.put(Long.valueOf(DedupAnalysis.key(11, 10)), fake(95, 0, 1, 1, 100));
        fab.pairs.put(Long.valueOf(DedupAnalysis.key(12, 11)), fake(95, 0, 1, 1, 100));
        List<SpriteDedup.Group> noChain = fab.groups(trio, 90, new DedupOptions());
        check("sem cadeia: so A e B", noChain.size() == 1 && noChain.get(0).members.size() == 2 && noChain.get(0).rep() == 10, true);
        DedupOptions ch = new DedupOptions();
        ch.chain.on = true;
        List<SpriteDedup.Group> withChain = fab.groups(trio, 90, ch);
        check("com cadeia: A, B e C no mesmo grupo (C ligada por B)", withChain.size() == 1 && withChain.get(0).members.size() == 3 && withChain.get(0).members.get(2).via == 11, true);

        // ---- desenhar K no espaco de R reproduz a copia
        int[] big = SpriteScaleTest.art(3, 64, 64, 4);
        int[] small = SpriteScaleTest.boxResize(big, 64, 64, 32, 32);
        SpriteDedup.Sig bs = sig(0, big, 64, 64), ss = sig(1, small, 32, 32);
        SpriteDedup.Match m = SpriteDedup.best(ss, bs, 80);
        int[] shown = SpriteVerify.renderRect(big, 64, 64, m.map(), 32, 32);
        SpriteVerify.Metrics mt = SpriteVerify.measure(small, shown, 32, 32, true);
        check("renderRect: a grande desenhada no espaco da pequena e igual a ela (forma >= 97, cor >= 95)", mt.iou >= 97 && mt.color >= 95, true);
        double[] q = SpriteVerify.quantized(SpriteXform.G[0], 40, 40, 40, 40);
        check("quantized do mapa identidade e a identidade", q != null && Math.abs(q[0] - 1) < 1e-9 && Math.abs(q[3] - 1) < 1e-9 && Math.abs(q[4]) < 1e-9, true);
        check("quantized recusa zoom que daria 0", SpriteVerify.quantized(SpriteXform.G[0], 3, 3, 1000, 1000) == null, true);

        // ---- o refino nao piora e corrige uma escala ligeiramente errada
        SpriteDedup.Match wrong = SpriteDedup.best(ss, bs, 80);
        double before = SpriteVerify.measure(ss.work, SpriteVerify.renderWork(ss, bs, SpriteVerify.perturb(wrong.gen, ss, bs, 0.05, -0.04, 0.02, 0, 0)), ss.ww, ss.wh, false).objective();
        wrong.gen = SpriteVerify.perturb(wrong.gen, ss, bs, 0.05, -0.04, 0.02, 0, 0);
        SpriteVerify.verify(ss, bs, wrong);
        double after = wrong.iou / 100 + wrong.color / 100;
        check("refino: depois >= antes (" + before + " -> " + after + ")", after >= before - 1e-9, true);
        check("refino: forma e cor altas depois de corrigir o mapa errado", wrong.iou >= 96 && wrong.color >= 95, true);

        // ---- marcas
        SpriteDedup.Group g1 = new SpriteDedup.Group();
        for (int idx : new int[]{5, 8, 9, 12}) { SpriteDedup.Member mem = new SpriteDedup.Member(); mem.index = idx; g1.members.add(mem); }
        SpriteDedup.Group g2 = new SpriteDedup.Group();
        for (int idx : new int[]{20, 21}) { SpriteDedup.Member mem = new SpriteDedup.Member(); mem.index = idx; g2.members.add(mem); }
        DedupMarks mk = new DedupMarks(new ArrayList<SpriteDedup.Group>(Arrays.asList(g1, g2)));
        check("marcas: nada marcado por padrao", mk.totalMarked(), 0);
        check("a maior do grupo nao abre comparacao; as outras sim", mk.canCompare(g1, 5) + ":" + mk.canCompare(g1, 8) + ":" + mk.canCompare(g1, 12) + ":" + mk.canCompare(g1, 99), "false:true:true:false");
        check("marcar uma", mk.set(g1, 8, true) && mk.isMarked(8), true);
        check("desmarcar", mk.set(g1, 8, false) && !mk.isMarked(8), true);
        mk.set(g1, 8, true);
        mk.set(g2, 21, true);
        check("grupos com marcas / total", mk.groupsWithMarks() + ":" + mk.totalMarked(), "2:2");
        check("ao menos uma fica: marcar a ultima que ficaria recusa", mk.set(g2, 20, true), false);
        mk.set(g1, 9, true);
        mk.set(g1, 12, true);
        check("a maior pode ser marcada a mao se outra ficar... aqui nao: so ela ficaria", mk.set(g1, 5, true), false);
        mk.set(g1, 12, false);
        check("depois de manter uma, marcar a maior vale", mk.set(g1, 5, true), true);
        check("sprite fora do grupo nao marca", mk.set(g1, 77, true), false);
        // sprites de GIF: fixas, sem comparar, nunca marcadas (so saem pelo Otimizar GIF)
        DedupMarks fx = new DedupMarks(new ArrayList<SpriteDedup.Group>(Arrays.asList(g1)), new java.util.HashSet<Integer>(Arrays.asList(Integer.valueOf(8), Integer.valueOf(5))));
        check("sprite de GIF nao abre comparacao (nem a maior, se for de GIF)", fx.canCompare(g1, 8) + ":" + fx.canCompare(g1, 9) + ":" + fx.canCompare(g1, 5), "false:true:false");
        check("sprite de GIF nao pode ser marcada", fx.set(g1, 8, true) + ":" + fx.isMarked(8) + ":" + fx.set(g1, 9, true), "false:false:true");
        check("selo da sprite de GIF (inclusive a maior) e 'Sprite de Gif, mantida'; as outras seguem a regra", fx.chip(g1, 5) + "|" + fx.chip(g1, 8) + "|" + fx.chip(g1, 9) + "|" + fx.chip(g1, 12), "Sprite de Gif, mantida|Sprite de Gif, mantida|REMOVER|MANTER");
        check("sem GIF nada muda: a maior continua MANTER (FIXA)", mk.chip(g1, 5), "MANTER (FIXA)");
    }
}
