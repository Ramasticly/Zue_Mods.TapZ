package com.zue.attackeditor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static com.zue.attackeditor.BattleTest.*;

/** Exclusao de sprites em etapas: nota de semelhanca sem portao de proporcao, decisoes por sprite (usar outra / Frames / sem imagem) e alinhar MID/RAZ. */
public class SpriteWizardTest {
    static SpriteDedup.Sig sig(int idx, int[] px, int w, int h) { return SpriteDedupTest.sig(idx, px, w, h); }
    static M mpt(int image) { return new M().time(4).img(image); }
    static Set<Integer> set(Integer... v) { return new HashSet<Integer>(java.util.Arrays.asList(v)); }

    public static void main(String[] args) throws Exception {
        int[] base = SpriteDedupTest.base(40, 40);
        SpriteDedup.Sig a = sig(0, base, 40, 40);
        SpriteDedup.Sig same = sig(1, base.clone(), 40, 40);
        check("identica: 100", SpriteDedup.bestAny(a, same).score, 100);
        SpriteDedup.Sig mirror = sig(2, SpriteDedupTest.derive(base, 40, 40, 1, 40, 40), 40, 40);
        SpriteDedup.Match mm = SpriteDedup.bestAny(a, mirror);
        check("espelhada: nota alta e g=1", mm.score >= 90 && mm.g == 1, true);
        SpriteDedup.Sig scaled = sig(3, SpriteDedupTest.derive(base, 40, 40, 0, 80, 80), 80, 80);
        check("escalada 2x: nota alta", SpriteDedup.bestAny(a, scaled).score >= 90, true);
        int[] other = new int[40 * 40];
        for (int i = 0; i < other.length; i++) other[i] = (i % 40 < 20) ? 0xFF101010 : 0x00000000;
        SpriteDedup.Sig unrelated = sig(4, other, 40, 40);
        check("sem relacao: nota baixa", SpriteDedup.bestAny(a, unrelated).score < 60, true);
        SpriteDedup.Sig wide = sig(5, SpriteDedupTest.derive(base, 40, 40, 0, 80, 40), 80, 40);
        check("proporcao diferente: o 'best' antigo recusa, o bestAny da nota", SpriteDedup.best(a, wide, 0) == null && SpriteDedup.bestAny(a, wide).score > 0, true);
        SpriteDedup.Sig empty = sig(6, new int[40 * 40], 40, 40);
        check("sprite vazia: 0", SpriteDedup.bestAny(a, empty).score, 0);
        List<SpriteDedup.Sig> all = new ArrayList<SpriteDedup.Sig>(java.util.Arrays.asList(a, same, mirror, scaled, unrelated, wide, empty));
        java.util.Map<Integer, Integer> sc = SpriteDedup.scores(a, all);
        check("scores: a propria nao entra; 6 notas", sc.size() + ":" + sc.containsKey(Integer.valueOf(0)), "6:false");
        check("scores: a identica e a maior", sc.get(Integer.valueOf(1)).intValue() == 100 && sc.get(Integer.valueOf(4)).intValue() < sc.get(Integer.valueOf(3)).intValue(), true);

        // ---- uso por sprite: hitbox, hurtbox, ANO fixa
        Dac d0 = dac(new A[]{
                new A().mpt(mpt(7)), new A().mpt(mpt(8).hit(1, 0, -50, 20, 50)), new A().mpt(mpt(9).hit(2, 0, 0, 10, 10)),
                new A().mpt(mpt(7)), new A().mpt(mpt(7)).mpt(mpt(8))});
        SpriteMass.Usage u8 = SpriteMass.usage(d0, null, set(8));
        check("sprite 8: so hurtbox (nao hitbox), 2 frames", u8.hurtbox + ":" + u8.hitOrProjectile + ":" + u8.frames, "true:false:2");
        SpriteMass.Usage u9 = SpriteMass.usage(d0, null, set(9));
        check("sprite 9: hitbox, sem hurtbox", u9.hitOrProjectile + ":" + u9.hurtbox, "true:false");
        SpriteMass.Usage u7 = SpriteMass.usage(d0, null, set(7));
        check("sprite 7 aparece na ANO fixa 0 (Parado) e na 4 (Defesa)", u7.fixedAnos.toString().contains("ANO 0") && u7.fixedAnos.toString().contains("ANO 4") && !u7.fixedAnos.toString().contains("ANO 3"), true);

        // ---- decisoes mistas: 0 -> usar a 3 (alinhando, a 3 e o espelho da 0), 1 -> excluir Frames, 2 -> sem imagem
        int[] r0 = SpriteDedupTest.base(40, 40);
        Dac dac = dac(new A[]{
                new A().mpt(mpt(0)).mpt(mpt(1)).mpt(mpt(2)).mpt(mpt(4)),
                new A().mpt(mpt(0)).mpt(mpt(2)),
                new A().mpt(mpt(1))});
        List<SpriteMass.Decision> ds = new ArrayList<SpriteMass.Decision>();
        SpriteMass.Decision d1 = new SpriteMass.Decision();
        d1.sprite = 0; d1.mode = SpriteMass.Decision.REPLACE; d1.replacement = 3; d1.align = true;
        d1.removed = sig(0, r0, 40, 40);
        d1.kept = sig(3, SpriteDedupTest.derive(r0, 40, 40, 1, 40, 40), 40, 40);
        ds.add(d1);
        SpriteMass.Decision d2 = new SpriteMass.Decision();
        d2.sprite = 1; d2.mode = SpriteMass.Decision.FRAMES;
        ds.add(d2);
        SpriteMass.Decision d3 = new SpriteMass.Decision();
        d3.sprite = 2; d3.mode = SpriteMass.Decision.BLANK;
        ds.add(d3);
        SpriteMass.Applied ap = SpriteMass.applyDecisions(dac, ds);
        check("ANO 0: IMG 0 virou 3 (alinhado com Flip), IMG 1 saiu, IMG 2 ficou -1, 4 intacto", SpriteRenumberTest.imgs(dac.getAno(0)), "3,-1,4");
        check("o alinhamento ligou o Flip do Frame (o 3 e o espelho da 0)", (dac.getAno(0).mpts[0].wActFlag & ObjModel.FLIP_H) != 0 || (dac.getAno(0).mpts[0].wActFlag & ObjModel.FLIP_V) != 0, true);
        check("ANO 1: IMG 0 -> 3 e IMG 2 -> -1", SpriteRenumberTest.imgs(dac.getAno(1)), "3,-1");
        check("ANO 2 tinha so a sprite 1: ficou vazia", dac.getAno(2).present, false);
        check("contagens: 2 trocados e alinhados, 2 excluidos... ", ap.replaced + ":" + ap.aligned + ":" + ap.deleted + ":" + ap.blanked, "2:2:2:2");
        check("ANOs alteradas: 0, 1 e 2", ap.changed.toString(), "[0, 1, 2]");
        check("nada falhou no alinhamento", ap.alignFailed.isEmpty(), true);
        // depois renumera tudo: saem 0, 1 e 2 -> a 3 vira 0 e a 4 vira 1
        boolean[] rem = new boolean[5];
        rem[0] = rem[1] = rem[2] = true;
        SpriteRenumber.remapDac(dac, SpriteRenumber.map(5, rem));
        check("renumerado: 3 -> 0 e 4 -> 1", SpriteRenumberTest.imgs(dac.getAno(0)) + "|" + SpriteRenumberTest.imgs(dac.getAno(1)), "0,-1,1|0,-1");

        // ---- alinhar sem solucao: ANO filha de link nao pode trocar Flip -> cai na troca simples
        Dac dl = dac(new A[]{new A().mpt(mpt(0)), new A().mpt(mpt(0))});
        MoveTransplantTest.link(dl, 0, 1);                 // ANO 1 e filha de link
        SpriteMass.Decision dm = new SpriteMass.Decision();
        dm.sprite = 0; dm.mode = SpriteMass.Decision.REPLACE; dm.replacement = 3; dm.align = true;
        dm.removed = sig(0, r0, 40, 40);
        dm.kept = sig(3, SpriteDedupTest.derive(r0, 40, 40, 1, 40, 40), 40, 40);
        List<SpriteMass.Decision> l1 = new ArrayList<SpriteMass.Decision>();
        l1.add(dm);
        SpriteMass.Applied ap2 = SpriteMass.applyDecisions(dl, l1);
        check("sem solucao num Frame: todos trocam so o IMG e a sprite entra no aviso", SpriteRenumberTest.imgs(dl.getAno(0)) + "|" + SpriteRenumberTest.imgs(dl.getAno(1)) + "|" + ap2.alignFailed + "|" + ap2.aligned, "3|3|[0]|0");

        // substituta entre as que saem: ignorada (vira sem imagem), nunca aponta para sprite que vai sumir
        Dac dr = dac(new A[]{new A().mpt(mpt(0)).mpt(mpt(1))});
        SpriteMass.Decision x = new SpriteMass.Decision(), y = new SpriteMass.Decision();
        x.sprite = 0; x.mode = SpriteMass.Decision.REPLACE; x.replacement = 1;
        y.sprite = 1; y.mode = SpriteMass.Decision.BLANK;
        List<SpriteMass.Decision> l2 = new ArrayList<SpriteMass.Decision>();
        l2.add(x); l2.add(y);
        SpriteMass.applyDecisions(dr, l2);
        check("substituta que tambem sai: os Frames ficam sem imagem", SpriteRenumberTest.imgs(dr.getAno(0)), "-1,-1");
        System.out.println("SpriteWizardTest fails=" + fails);
    }
}
