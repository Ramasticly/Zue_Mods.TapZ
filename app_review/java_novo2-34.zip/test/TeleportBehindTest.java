package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/**
 * Teleportar atras do oponente = hit flag 39 (o PERSONAGEM vai ate o oponente) + Flip X + speed X positiva no mesmo frame (a velocidade segue a direcao do personagem; o Flip X so vira o desenho) (formato atual, um frame so);
 * o formato antigo (flag 40 com x negativo, que puxava o oponente) continua reconhecido.
 */
public class TeleportBehindTest {
    static Ano.Mpt[] mpts(int n) {
        Ano.Mpt[] m = new Ano.Mpt[n];
        for (int i = 0; i < n; i++) { m[i] = new Ano.Mpt(); m[i].flags = 0x20; m[i].hasTime = true; m[i].time = 5; }
        return m;
    }

    static boolean flip(Ano.Mpt m) { return ObjModel.spriteBit(m, ObjModel.FLIP_H); }

    static Ano.Mpt[] legacy(int n, int x) {
        Ano.Mpt[] m = ObjModel.add(mpts(n), 1, 2, hit40(x));
        for (int f = 1; f <= 2; f++) m[f] = ObjModel.setSpriteBit(m[f], ObjModel.FLIP_H, true);
        return m;
    }

    public static void main(String[] args) throws Exception {
        Ano.Mpt[] base = mpts(4);
        Ano.Mpt[] ab = ObjModel.addBehind(base, 1, 2);
        check("addBehind: so o frame 1 (hit 39, Flip X e speed X +12 px/tick = 60 px em 5 ticks)", ab[1].hits[0].flag + ":" + flip(ab[1]) + ":" + FrameTools.px(ab[1].speedX / FrameTools.ONE),
                "39:true:12");
        check("addBehind: frames de fora intactos (o ultimo parametro e ignorado)", ab[0] == base[0] && ab[2] == base[2] && ab[3] == base[3], true);
        check("addBehind nao muda o original", base[1].hits.length + ":" + flip(base[1]) + ":" + FrameTools.hasSpeedX(base[1]), "0:false:false");
        check("distancia = 60 px", ObjModel.behindDistance(ab[1]), 60);

        List<ObjModel.Obj> objs = ObjModel.objects(ab);
        check("um objeto so, reconhecido como Teleportar atras no frame 1", objs.size() + ":" + objs.get(0).behind + ":" + objs.get(0).f0 + "-" + objs.get(0).f1 + ":" + objs.get(0).flag, "1:true:1-1:39");
        check("nome e linha proprios", ObjModel.nameOf(objs.get(0)) + ":" + ObjModel.laneFlag(objs.get(0)), "Teleportar atras do oponente:" + ObjModel.ACT_BEHIND);

        // distancia editavel
        Ano.Mpt[] d90 = ObjModel.setBehindDistance(ab, 1, 90);
        check("distancia 90: speed +18 px/tick, 90 px", FrameTools.px(d90[1].speedX / FrameTools.ONE) + ":" + ObjModel.behindDistance(d90[1]), "18:90");

        // apagar leva hit, Flip X e speed
        Ano.Mpt[] gone = ObjModel.remove(ab, objs.get(0));
        check("apagar: some o hit, o Flip X e a speed X", gone[1].hits.length + ":" + flip(gone[1]) + ":" + FrameTools.hasSpeedX(gone[1]), "0:false:false");

        // so a combinacao e Teleportar atras
        Ano.Mpt[] only39 = ObjModel.add(mpts(2), 0, 0, ObjModel.defaultHit(39));
        check("flag 39 sozinha continua Teleportar ate o oponente", ObjModel.objects(only39).get(0).behind + ":" + ObjModel.nameOf(ObjModel.objects(only39).get(0)), "false:Teleportar ate o oponente");
        Ano.Mpt[] noSpeed = only39.clone();
        noSpeed[0] = ObjModel.setSpriteBit(noSpeed[0], ObjModel.FLIP_H, true);
        check("39 + Flip X sem speed negativa nao e Teleportar atras", ObjModel.objects(noSpeed).get(0).behind, false);
        Ano.Mpt[] posSpeed = noSpeed.clone();
        posSpeed[0] = FrameTools.setSpeed(posSpeed[0], 0, -5, true);
        check("39 + Flip X + speed negativa nao e Teleportar atras", ObjModel.objects(posSpeed).get(0).behind, false);

        // Puxar comum fica como Puxar (e continua na lista do +)
        Ano.Mpt[] pull = ObjModel.add(mpts(2), 0, 0, hit40(25));
        check("Puxar oponente comum nao e Teleportar atras", ObjModel.objects(pull).get(0).behind + ":" + ObjModel.nameOf(ObjModel.objects(pull).get(0)), "false:Puxar oponente");
        boolean[] has = new boolean[2];
        for (int f : ObjModel.actionFlagsFor(null, -1, ab[1])) { if (f == 40) has[0] = true; if (f == ObjModel.ACT_BEHIND) has[1] = true; }
        check("frame com Teleportar atras (atual): Puxar continua na lista, Teleportar atras nao", has[0] + ":" + has[1], "true:false");
        has = new boolean[2];
        for (int f : ObjModel.actionFlagsFor(null, -1, base[1])) { if (f == 40) has[0] = true; if (f == ObjModel.ACT_BEHIND) has[1] = true; }
        check("frame comum: Puxar e Teleportar atras na lista", has[0] + ":" + has[1], "true:true");
        int[] full = ObjModel.actionFlagsFor(null, -1, null);
        int i40 = -1, iB = -1;
        for (int i = 0; i < full.length; i++) { if (full[i] == 40) i40 = i; if (full[i] == ObjModel.ACT_BEHIND) iB = i; }
        check("Teleportar atras vem logo depois do Puxar oponente", iB, i40 + 1);

        // esticar nao faz nada (um frame so); mover leva tudo e a distancia
        ObjModel.Obj ob = objs.get(0);
        check("esticar: sem efeito (um frame so)", ObjModel.trim(ab, ob, 1, 3) == ab, true);
        Ano.Mpt[] mv = ObjModel.move(ab, ob, 3);
        check("mover para o frame 3: hit, Flip e speed vao, o frame 1 fica limpo", mv[3].hits.length + ":" + flip(mv[3]) + ":" + ObjModel.behindDistance(mv[3]) + "|" + mv[1].hits.length + ":" + flip(mv[1]) + ":" + FrameTools.hasSpeedX(mv[1]), "1:true:60|0:false:false");
        // frame sem tempo ganha 1 tick
        Ano.Mpt[] nt = mpts(2);
        nt[1] = new Ano.Mpt();
        Ano.Mpt[] abn = ObjModel.addBehind(nt, 1, 1);
        check("frame sem tempo: ganha 1 tick e a speed +60", FrameTools.ticks(abn[1]) + ":" + ObjModel.behindDistance(abn[1]), "1:60");
        // trocar de acao leva o Flip e a speed
        Ano.Mpt[] sf = ObjModel.setFlag(ab, objs.get(0), 26);
        check("trocar de acao: sai o Flip X e a speed X", flip(sf[1]) + ":" + FrameTools.hasSpeedX(sf[1]) + ":" + sf[1].hits[0].flag, "false:false:26");

        // ---- formato antigo (flag 40 negativa + Flip X) continua reconhecido
        Ano.Mpt[] old = legacy(4, -120);
        List<ObjModel.Obj> lo = ObjModel.objects(old);
        check("antigo: um objeto Teleportar atras nos frames 1-2", lo.size() + ":" + lo.get(0).behind + ":" + lo.get(0).f0 + "-" + lo.get(0).f1 + ":" + lo.get(0).flag, "1:true:1-2:40");
        Ano.Mpt[] oldGone = ObjModel.remove(old, lo.get(0));
        check("antigo: apagar leva o hit e o Flip X", oldGone[1].hits.length + ":" + flip(oldGone[1]) + ":" + flip(oldGone[2]), "0:false:false");
        has = new boolean[2];
        for (int f : ObjModel.actionFlagsFor(null, -1, old[1])) { if (f == 40) has[0] = true; if (f == ObjModel.ACT_BEHIND) has[1] = true; }
        check("antigo: nenhum dos dois na lista do frame", has[0] + ":" + has[1], "false:false");

        // ---- fidelidade: o PERSONAGEM vai para tras do oponente. Sem "Personagens se atravessam" (ATK_FLAGS 16) a separacao dos corpos do jogo (md 19) empurra o oponente.
        for (int ghost = 0; ghost <= 1; ghost++) {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(1)).mpt(new M().time(5).hit(39, 0, 0, 0, 0).act(16).speedX(12 * 65536)).mpt(new M().time(30));
            CharData ch = chr(move(new int[]{0, ghost == 1 ? 16 : 0}, new int[]{2, 40}), new byte[][] {});
            BattleSim.edgeMode = 1;
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 200, 0, 0);
            int ox0 = s.opponentX();
            int ax0 = s.attackerX();
            for (int i = 0; i < 12; i++) s.step();
            int dx = s.attackerX() - s.opponentX();
            if (ghost == 1) {
                check("com fantasma: o atacante (estava a esquerda) termina a 60 px a direita do oponente, que nao se mexe", ax0 < ox0 && dx == 60 && s.opponentX() == ox0, true);
            } else {
                check("sem fantasma: atravessa para o outro lado, mas a separacao dos corpos empurra o oponente", ax0 < ox0 && dx > 0 && s.opponentX() != ox0, true);
            }
        }
        System.out.println("TeleportBehindTest fails=" + fails);
    }

    static Ano.Hit hit40(int x) {
        Ano.Hit h = ObjModel.defaultHit(40);
        h.x = x;
        return h;
    }
}
