package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.List;

/** Teleportar atras do oponente = Puxar oponente (flag 40, x < 0) + Flip X no mesmo frame, tratados como um so. */
public class TeleportBehindTest {
    static Ano.Mpt[] mpts(int n) {
        Ano.Mpt[] m = new Ano.Mpt[n];
        for (int i = 0; i < n; i++) { m[i] = new Ano.Mpt(); m[i].flags = 0x20; m[i].hasTime = true; m[i].time = 5; }
        return m;
    }

    static boolean flip(Ano.Mpt m) { return ObjModel.spriteBit(m, ObjModel.FLIP_H); }

    public static void main(String[] args) throws Exception {
        Ano.Mpt[] base = mpts(4);
        Ano.Mpt[] ab = ObjModel.addBehind(base, 1, 2);
        check("addBehind: hit 40 com x -120 e Flip X nos frames 1 e 2", ab[1].hits[0].flag + ":" + ab[1].hits[0].x + ":" + flip(ab[1]) + "|" + ab[2].hits[0].x + ":" + flip(ab[2]), "40:-120:true|-120:true");
        check("addBehind: frames de fora intactos", ab[0] == base[0] && ab[3] == base[3], true);
        check("addBehind nao muda o original", base[1].hits.length + ":" + flip(base[1]), "0:false");

        List<ObjModel.Obj> objs = ObjModel.objects(ab);
        check("um objeto so, reconhecido como Teleportar atras", objs.size() + ":" + objs.get(0).behind + ":" + objs.get(0).f0 + "-" + objs.get(0).f1, "1:true:1-2");
        check("nome e linha proprios", ObjModel.nameOf(objs.get(0)) + ":" + ObjModel.laneFlag(objs.get(0)), "Teleportar atras do oponente:" + ObjModel.ACT_BEHIND);

        // apagar leva o Flip X junto
        Ano.Mpt[] gone = ObjModel.remove(ab, objs.get(0));
        check("apagar: some o hit e o Flip X", ObjModel.hasBehind(gone[1]) + ":" + flip(gone[1]) + ":" + flip(gone[2]) + ":" + gone[1].hits.length, "false:false:false:0");

        // Puxar comum (x >= 0) com Flip X NAO e Teleportar atras; sem limite de x
        Ano.Mpt[] pull = ObjModel.add(mpts(2), 0, 0, hit40(25));
        pull[0] = ObjModel.setSpriteBit(pull[0], ObjModel.FLIP_H, true);
        List<ObjModel.Obj> po = ObjModel.objects(pull);
        check("Puxar com x positivo + Flip continua Puxar comum", po.size() + ":" + po.get(0).behind + ":" + ObjModel.nameOf(po.get(0)), "1:false:Puxar oponente");
        Ano.Mpt[] pull2 = ObjModel.add(mpts(2), 0, 0, hit40(-30));
        List<ObjModel.Obj> po2 = ObjModel.objects(pull2);
        check("Puxar com x negativo sem Flip continua Puxar comum", po2.get(0).behind, false);
        check("apagar um Puxar comum nao mexe no Flip", flip(ObjModel.remove(pull, po.get(0))[0]), true);

        // Puxar comum no mesmo frame do Teleportar atras fica oculto na timeline
        Ano.Mpt[] mix = ObjModel.add(ab, 1, 1, hit40(50));
        List<ObjModel.Obj> mo = ObjModel.objects(mix);
        int behinds = 0, pulls = 0;
        for (ObjModel.Obj o : mo) if (o.flag == 40) { if (o.behind) behinds++; else pulls++; }
        check("Puxar oculto onde ha Teleportar atras", behinds + ":" + pulls, "1:0");

        // lista de adicionar
        boolean[] has = new boolean[2];
        for (int f : ObjModel.actionFlagsFor(null, -1, base[1])) { if (f == 40) has[0] = true; if (f == ObjModel.ACT_BEHIND) has[1] = true; }
        check("frame comum: Puxar e Teleportar atras na lista", has[0] + ":" + has[1], "true:true");
        has = new boolean[2];
        for (int f : ObjModel.actionFlagsFor(null, -1, ab[1])) { if (f == 40) has[0] = true; if (f == ObjModel.ACT_BEHIND) has[1] = true; }
        check("frame com Teleportar atras: nenhum dos dois na lista", has[0] + ":" + has[1], "false:false");
        int[] full = ObjModel.actionFlagsFor(null, -1, null);
        int i40 = -1, iB = -1;
        for (int i = 0; i < full.length; i++) { if (full[i] == 40) i40 = i; if (full[i] == ObjModel.ACT_BEHIND) iB = i; }
        check("Teleportar atras vem logo depois do Puxar oponente", iB, i40 + 1);

        // mover / esticar levam o Flip
        ObjModel.Obj ob = objs.get(0);
        Ano.Mpt[] ext = ObjModel.trim(ab, ob, 1, 3);
        check("esticar: o frame novo recebe o hit e o Flip", ObjModel.hasBehind(ext[3]) + ":" + flip(ext[3]), "true:true");
        Ano.Mpt[] shr = ObjModel.trim(ab, ob, 1, 1);
        check("encolher: o frame que sai perde o hit e o Flip", ObjModel.hasBehind(shr[2]) + ":" + flip(shr[2]), "false:false");
        Ano.Mpt[] mv = ObjModel.move(ab, ob, 0);
        check("mover: Flip acompanha", flip(mv[0]) + ":" + flip(mv[1]) + ":" + flip(mv[2]), "true:true:false");

        // fidelidade: onde o oponente fica na simulacao
        {
            A[] a = new A[45];
            for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
            a[40] = new A().mpt(new M().time(5).hit(40, -120, 0, 0, 0).act(16)).mpt(new M().time(5));
            CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
            BattleSim.edgeMode = 1;
            BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 200, 0, 0);
            int dx = s.opponentX() - (s.attacker().root().x >> 16);
            System.out.println("INFO opponentX - attackerX com flag 40 x=-120 + Flip X = " + dx);
            check("o oponente vai para tras do atacante (que olhava para a direita) e o Flip X faz o atacante olhar para ele", dx < 0, true);
        }
        System.out.println("TeleportBehindTest fails=" + fails);
    }

    static Ano.Hit hit40(int x) {
        Ano.Hit h = ObjModel.defaultHit(40);
        h.x = x;
        return h;
    }
}
