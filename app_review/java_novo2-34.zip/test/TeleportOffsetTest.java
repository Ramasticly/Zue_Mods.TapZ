package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Flag 39 (Teleportar ate o oponente) com deslocamento x/y, como a 40: x espelhado pelo flip, x = y = 0 continua igual a antes. */
public class TeleportOffsetTest {
    static BattleSim run(boolean left, int x, int y, boolean dead) throws Exception {
        A[] a = new A[45];
        for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
        a[40] = new A().mpt(new M().time(1)).mpt(new M().time(5).hit(39, x, y, 0, 0)).mpt(new M().time(30));
        CharData ch = chr(move(new int[]{0, 16}, new int[]{2, 40}), new byte[][] {});
        BattleSim.edgeMode = 1;
        BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], left, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 200, 0, 0);
        for (int i = 0; i < 6; i++) s.step();
        return s;
    }

    public static void main(String[] args) throws Exception {
        BattleSim z = run(false, 0, 0, false);
        check("sem deslocamento: vai exatamente ate o oponente", z.attackerX() == z.opponentX() && z.attackerY() == 0, true);

        BattleSim p = run(false, 30, -20, false);
        check("atacante nao virado: x +30 e y -20 a partir do oponente", p.attackerX() - p.opponentX() + ":" + p.attackerY(), "30:-20");

        BattleSim f = run(true, 30, 0, false);
        check("atacante virado: o x espelha (-30)", f.attackerX() - f.opponentX(), -30);
        System.out.println("TeleportOffsetTest fails=" + fails);
    }
}
