package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Contador do botao +1 tick: congelamentos (trava cinematica, hitstop) travam o numero e a contagem continua sem somar os ticks parados. */
public class TickDisplayTest {
    public static void main(String[] args) throws Exception {
        TickDisplay t = new TickDisplay();
        t.afterStep(1, false);
        check("sem congelamento: tick real", t.shown(1), 1);
        t.afterStep(2, true);
        check("entrou na trava em 2: fica 2", t.shown(2) + ":" + t.stalled(), "2:true");
        for (int r = 3; r < 122; r++) t.afterStep(r, true);
        check("durante a trava o numero nao muda", t.shown(121), 2);
        t.afterStep(122, false);
        check("liberou no tick 122: mostra 3 (nao 122)", t.shown(122), 3);
        t.afterStep(123, false);
        t.afterStep(124, false);
        check("segue 4, 5...", t.shown(123) + ":" + t.shown(124), "4:5");
        // segundo congelamento (hitstop de 10 ticks) depois da trava
        t.afterStep(125, true);
        check("hitstop trava no numero atual", t.shown(125), 6);
        for (int r = 126; r < 135; r++) t.afterStep(r, true);
        t.afterStep(135, false);
        check("liberou o hitstop: proximo numero (7), somando os dois congelamentos", t.shown(135), 7);
        t.afterStep(136, false);
        check("e continua", t.shown(136), 8);
        // congelamentos seguidos (trava e logo hitstop) valem como um so
        TickDisplay u = new TickDisplay();
        u.afterStep(1, true); u.afterStep(2, true); u.afterStep(3, true); u.afterStep(4, false);
        check("congelamentos colados: um so", u.shown(4), 2);
        t.reset();
        check("reset: volta ao tick real", t.shown(50) + ":" + t.stalled(), "50:false");
        System.out.println("TickDisplayTest fails=" + fails);
    }
}
