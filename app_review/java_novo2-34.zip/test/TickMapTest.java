package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Os ticks da timeline sao so os dos frames: o hitstop (ticks so da simulacao) nao ocupa lugar nela. */
public class TickMapTest {
    public static void main(String[] args) throws Exception {
        A[] a = new A[45];
        for (int i = 0; i < 45; i++) a[i] = new A().mpt(new M().time(1));
        // frame 0 acerta (hitstop), frame 1 normal
        a[40] = new A().mpt(new M().time(30).hit(2, -40, -40, 400, 100)).mpt(new M().time(20));
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        BattleSim.edgeMode = 1;
        BattleSim s = new BattleSim(dac(a), ch, ch.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 20, 0, 0);
        int[][] t = s.firstTicksElapsed(40, new int[] {30, 20}, 400);
        check("frame 0 tem 30 pontos e o frame 1 tem 20", t[0].length + ":" + t[1].length, "30:20");
        boolean all = true, inc = true;
        int maxJump = 0;
        for (int p = 0; p < 2; p++) for (int e = 0; e < t[p].length; e++) {
            if (t[p][e] < 0) all = false;
            int prev = e > 0 ? t[p][e - 1] : (p > 0 ? t[p - 1][t[p - 1].length - 1] : -1);
            if (t[p][e] <= prev) inc = false;
            if (prev >= 0) maxJump = Math.max(maxJump, t[p][e] - prev);
        }
        check("todo ponto (frame, tick) ocorre na simulacao", all, true);
        check("a ordem logica e crescente", inc, true);
        check("o hitstop abre um salto de 10 ticks de simulacao entre dois ticks da timeline", maxJump, 11);

        // cada ponto aponta para o tick certo: no tick mapeado o atacante esta nesse frame e nesse tick dele
        boolean exact = true;
        for (int p = 0; p < 2; p++) for (int e = 0; e < t[p].length; e += 3) {
            BattleSim c = s.copyAt(t[p][e]);
            AttackSim.Obj r = c.attacker().root();
            int dur = p == 0 ? 30 : 20;
            if (r.pat != p || dur - r.time != e) exact = false;
        }
        check("copyAt(tick mapeado) cai no frame e no tick pedidos", exact, true);

        // sem acerto: tabela = inicio do frame + tick (nada muda)
        A[] b = new A[45];
        for (int i = 0; i < 45; i++) b[i] = new A().mpt(new M().time(1));
        b[40] = new A().mpt(new M().time(8)).mpt(new M().time(6));
        BattleSim q = new BattleSim(dac(b), ch, ch.moves[0], false, CutsceneTest.defDac(), CutsceneTest.fxDac(), gd(new byte[][] {}), 20, 0, 0);
        int[][] u = q.firstTicksElapsed(40, new int[] {8, 6}, 100);
        int[] first = q.firstTicks(40, 2, 100);
        boolean same = true;
        for (int p = 0; p < 2; p++) for (int e = 0; e < u[p].length; e++) if (u[p][e] != first[p] + e) same = false;
        check("sem hitstop: tabela = inicio do frame + tick", same, true);
        System.out.println("TickMapTest fails=" + fails);
    }
}
