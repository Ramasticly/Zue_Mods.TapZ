package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

/** Edicao na timeline: o loop e do ANO (acompanha o ultimo frame), frame sem TIME, clique dentro do clipe e divisao de velocidade. */
public class TimelineEditTest {
    static Dac with(Dac d, int idx, Ano.Mpt[] mp) {
        d.setAno(idx, new Ano(idx, true, 0, 0, new Ano.Link[0], mp));
        return d;
    }

    static int len(Dac d) throws Exception {
        CharData ch = chr(move(new int[]{2, 40}), new byte[][] {});
        return SpawnDiagTest.sim(d, ch, ch.moves[0], 200, 0, 0).measureLength();
    }

    static boolean loopBit(Ano.Mpt m) { return (m.flags & 2) != 0 && (m.wActFlag & 1) != 0; }

    static int loopCount(Ano.Mpt[] m) { int n = 0; for (Ano.Mpt x : m) if (loopBit(x)) n++; return n; }

    public static void main(String[] args) throws Exception {
        A[] a = SpawnDiagTest.anos();
        a[40] = new A().mpt(new M().time(4)).mpt(new M().time(4)).mpt(new M().time(4).act(1));
        Dac d = dac(a);
        Ano.Mpt[] mp = d.getAno(40).mpts;
        check("ANO com loop no ultimo frame: 12 ticks", len(d), 12);

        // ---- adicionar / duplicar no fim: o loop vai para o novo ultimo frame e a duracao cresce
        Ano.Mpt[] dup = FrameOps.duplicate(mp, 2);
        check("duplicar o ultimo: sem normalizar o loop ficaria no antigo (bug)", loopBit(dup[2]) && !loopBit(dup[3]), true);
        Ano.Mpt[] fixed = FrameOps.normalizeLoop(mp, dup);
        check("duplicar o ultimo: loop so no novo ultimo", loopBit(fixed[3]) && loopCount(fixed) == 1, true);
        check("duplicar o ultimo: duracao 16 ticks", len(with(dac(a), 40, fixed)), 16);
        check("duplicar o ultimo sem normalizar travava em 12", len(with(dac(a), 40, dup)), 12);

        Ano.Mpt[] ins = FrameOps.insertSprites(mp, 2, new int[]{7, 8}, new int[]{3, 3});
        Ano.Mpt[] insFixed = FrameOps.normalizeLoop(mp, ins);
        check("inserir sprites no fim: loop no ultimo", loopBit(insFixed[4]) && loopCount(insFixed) == 1, true);
        check("inserir sprites no fim: duracao 18", len(with(dac(a), 40, insFixed)), 18);

        // ---- apagar o ultimo: o loop passa para o novo ultimo
        Ano.Mpt[] del = FrameOps.delete(mp, 2);
        check("apagar o ultimo perde o loop sem normalizar", loopCount(del), 0);
        Ano.Mpt[] delFixed = FrameOps.normalizeLoop(mp, del);
        check("apagar o ultimo: loop no novo ultimo", loopBit(delFixed[1]) && loopCount(delFixed) == 1, true);
        // dividir o ultimo frame: a metade final continua com o loop
        FrameOps.Split sp = FrameOps.splitAt(mp, 10);
        check("dividir o ultimo: loop na metade final", loopBit(sp.mpts[3]) && !loopBit(sp.mpts[2]), true);

        // ---- so o usuario desliga
        Ano.Mpt[] off = ObjModel.setLoop(mp, false);
        check("setLoop(false) desliga", ObjModel.loops(off), false);
        check("depois de desligado, editar nao liga de novo", ObjModel.loops(FrameOps.normalizeLoop(off, FrameOps.duplicate(off, 2))), false);
        // loop no meio (ANO importado) nao e mexido
        Ano.Mpt[] mid = mp.clone();
        mid[2] = mp[2].copy(); mid[2].wActFlag = 0; mid[2].flags &= ~2;
        mid[1] = mp[1].copy(); mid[1].flags |= 2; mid[1].wActFlag |= 1;
        Ano.Mpt[] midDup = FrameOps.duplicate(mid, 2);
        check("loop no meio fica onde esta", FrameOps.normalizeLoop(mid, midDup) == midDup, true);
        check("sem mudanca: devolve o mesmo array", FrameOps.normalizeLoop(mp, mp) == mp, true);

        // ---- frame sem TIME segura para sempre: ao por um sprite depois dele, ele passa a durar o que a timeline mostra
        A[] b = SpawnDiagTest.anos();
        b[40] = new A().mpt(new M().time(4)).mpt(new M());
        Ano.Mpt[] hold = dac(b).getAno(40).mpts;
        check("frame sem TIME e segurado", hold[1].hasTime, false);
        Ano.Mpt[] dh = FrameOps.duplicate(hold, 1);
        check("duplicar o frame que segura: ele ganha 3 ticks", dh[1].hasTime && dh[1].time == 3, true);
        check("duplicar o frame que segura: o novo ultimo e quem segura", !dh[2].hasTime, true);
        Ano.Mpt[] dm = FrameOps.duplicate(hold, 0);
        check("duplicar no meio: a copia dura o mesmo que o original", dm[1].hasTime && dm[1].time == 4, true);
        Ano.Mpt[] ih = FrameOps.insertSprites(hold, 1, new int[]{9}, new int[]{5});
        check("inserir depois do frame que segura", ih[1].hasTime && ih[1].time == 3 && ih[2].time == 5, true);
        check("a ANO com sprite depois do frame que segura agora chega ao novo frame (total 12 ticks)", FrameOps.total(ih), 4 + 3 + 5);

        // ---- clique num clipe: dentro nao mexe, antes vai ao inicio, depois ao ultimo tick
        check("clipTarget dentro", FrameOps.clipTarget(7, 4, 12), 7);
        check("clipTarget no inicio", FrameOps.clipTarget(4, 4, 12), 4);
        check("clipTarget antes", FrameOps.clipTarget(2, 4, 12), 4);
        check("clipTarget depois", FrameOps.clipTarget(12, 4, 12), 11);
        check("clipTarget bem depois", FrameOps.clipTarget(30, 4, 12), 11);
        check("clipTarget vazio", FrameOps.clipTarget(30, 4, 4), 4);

        // ---- velocidade: eixos e divisao do trecho
        A[] c = SpawnDiagTest.anos();
        c[40] = new A().mpt(new M().time(10).speedX(2 << 16)).mpt(new M().time(10)).mpt(new M().time(10)).mpt(new M().time(10));
        Ano.Mpt[] sp0 = dac(c).getAno(40).mpts;
        Ano.Mpt[] run = FrameOps.setMoveRun(sp0, 0, 2);
        check("eixos: so X", FrameOps.moveAxes(run, 0), 1);
        Ano.Mpt yOnly = FrameTools.setSpeed(sp0[3], 1, 1.5, true);
        check("eixos: so Y", FrameOps.moveAxes(new Ano.Mpt[]{yOnly}, 0), 2);
        Ano.Mpt both = FrameTools.setAccel(FrameTools.setSpeed(sp0[3], 1, 1.0, true), 0, 0.25);
        check("eixos: speed Y + accel X = X e Y", FrameOps.moveAxes(new Ano.Mpt[]{both}, 0), 3);
        check("sem velocidade: nenhum eixo", FrameOps.moveAxes(sp0, 1), 0);
        Ano.Mpt e = sp0[1].copy();
        FrameOps.defaultsMove(e, 1);
        check("celula vazia na faixa Y cria speed Y", e.moveMask, 2);

        double[] before = FrameTools.totalPixels(run, 0, 2);
        check("dividir no meio do 2o frame do trecho", FrameOps.splitMove(run, 15) != null, true);
        FrameOps.Split sm = FrameOps.splitMove(run, 15);
        check("dividir velocidade: um frame a mais e o corte vira cabeca", sm.mpts.length == 5 && FrameOps.isMoveHead(sm.mpts[2]) && sm.index == 2, true);
        check("a cabeca nova mantem a velocidade (2 px/tick) e o bit 64", sm.mpts[2].speedX == (2 << 16) && (sm.mpts[2].wActFlag & 64) != 0, true);
        double[] after = FrameTools.totalPixels(sm.mpts, 0, 3);
        check("dividir velocidade nao muda o deslocamento (" + before[0] + ")", before[0] == after[0] && before[1] == after[1], true);
        check("agora sao dois trechos", FrameOps.moveHeadOf(sm.mpts, 1) == 0 && FrameOps.moveHeadOf(sm.mpts, 3) == 2 && FrameOps.moveHeadOf(sm.mpts, 2) == 2, true);
        check("dividir no inicio da cabeca: nao ha o que dividir", FrameOps.splitMove(run, 0), null);
        check("dividir fora do trecho (frame sem velocidade)", FrameOps.splitMove(run, 35), null);
        check("dividir exatamente no inicio de um frame de continuacao", FrameOps.splitMove(run, 10) != null && FrameOps.splitMove(run, 10).mpts.length == 4, true);

        // com aceleracao: o 2o trecho comeca com a velocidade ja acumulada e a deslocamento total e igual
        Ano.Mpt acc = FrameTools.setAccel(sp0[0], 0, 0.25);
        Ano.Mpt[] ar = FrameOps.setMoveRun(new Ano.Mpt[]{acc, sp0[1], sp0[2], sp0[3]}, 0, 2);
        check("duracao do trecho liga o manter velocidade mas NAO copia a accel para os frames seguintes", (ar[1].wActFlag & 64) != 0 && ar[1].accelX == 0 && (ar[1].moveMask & 4) == 0, true);
        ar[1] = FrameTools.setAccel(ar[1], 0, 0.25);                    // accel posta pelo usuario em cada frame (nao continua sozinha)
        ar[2] = FrameTools.setAccel(ar[2], 0, 0.25);
        double[] ab = FrameTools.totalPixels(ar, 0, 2);
        FrameOps.Split as = FrameOps.splitMove(ar, 13);
        double[] aa = FrameTools.totalPixels(as.mpts, 0, 3);
        check("accel: deslocamento igual depois de dividir", Math.abs(ab[0] - aa[0]) < 1e-9, true);
        check("accel: o 2o trecho comeca em 4.5 + 0.25*3 = 5.25 px/tick", as.mpts[as.index].speedX, (int) Math.round(5.25 * 65536.0));

        // POSE: o ANO 0 do atacante desenhado na mesma ancora do golpe
        AttackSim pose = new AttackSim(dac(SpawnDiagTest.anos()), 0, false, 7 << 16, -(3 << 16));
        check("POSE: o ANO 0 nasce na ancora pedida", (pose.root().x >> 16) + "," + (pose.root().y >> 16), "7,-3");
        check("POSE: espelhada quando o golpe esta espelhado", (new AttackSim(dac(SpawnDiagTest.anos()), 0, true, 0, 0).root().objFlags & 16) != 0, true);

        // ---- DIVIDIR objeto: so na divisa de frames mais proxima do ponteiro
        int[] bst = {0, 4, 8, 20, 24};                       // frames 0..4
        ObjModel.Obj bo = new ObjModel.Obj(); bo.f0 = 1; bo.f1 = 3;   // cobre os frames 1..3
        check("divisa: ponteiro perto do inicio do frame 2", ObjModel.splitBoundary(bst, bo, 9), 2);
        check("divisa: ponteiro perto do inicio do frame 3 (meio de frame grande)", ObjModel.splitBoundary(bst, bo, 17), 3);
        check("divisa: ponteiro no meio de frame grande vai para a mais proxima", ObjModel.splitBoundary(bst, bo, 11), 2);
        check("divisa: ponteiro no inicio do objeto vai para a primeira divisa dentro dele", ObjModel.splitBoundary(bst, bo, 4), 2);
        check("divisa: ponteiro no fim do objeto vai para a ultima divisa dentro dele", ObjModel.splitBoundary(bst, bo, 23), 3);
        check("divisa: empate fica com a anterior", ObjModel.splitBoundary(bst, bo, 14), 2);
        bo.f1 = 1;
        check("divisa: objeto de um frame so nao divide", ObjModel.splitBoundary(bst, bo, 5), -1);

        // ---- 3.9: adicionar no meio do Frame (＋ Som / ＋ Velocidade) vale para o Frame inteiro; so o DIVIDIR divide
        {
            Ano.Mpt[] f3 = new Ano.Mpt[3];
            for (int q = 0; q < 3; q++) { f3[q] = new Ano.Mpt(); f3[q].flags = 0x20; f3[q].time = 10; f3[q].image = q; f3[q].normalize(); }
            FrameOps.Split ak = FrameOps.addKey(f3, FrameOps.SOM, 14);
            check("som no meio do frame 1: continuam 3 frames e o total de ticks", ak.mpts.length + ":" + FrameOps.total(ak.mpts) + ":" + ak.index + ":" + ak.changed, "3:30:1:true");
            check("som no frame 1 inteiro (10 ticks), os outros sem som", FrameOps.has(FrameOps.SOM, ak.mpts[1]) + ":" + ak.mpts[1].time + ":" + FrameOps.has(FrameOps.SOM, ak.mpts[0]) + ":" + FrameOps.has(FrameOps.SOM, ak.mpts[2]), "true:10:false:false");
            check("original intacto", FrameOps.has(FrameOps.SOM, f3[1]), false);
            FrameOps.Split again = FrameOps.addKey(ak.mpts, FrameOps.SOM, 17);
            check("frame que ja tem som: nada muda", again.changed + ":" + (again.mpts == ak.mpts) + ":" + again.index, "false:true:1");
            FrameOps.Split mv = FrameOps.addKey(f3, FrameOps.MOV, 25);
            check("velocidade no meio do frame 2: o frame inteiro, sem dividir", mv.mpts.length + ":" + mv.index + ":" + FrameOps.has(FrameOps.MOV, mv.mpts[2]) + ":" + mv.mpts[2].time, "3:2:true:10");
            check("ponteiro fora da ANO: null", FrameOps.addKey(f3, FrameOps.SOM, 99) == null, true);
            FrameOps.Split cut = FrameOps.splitAt(f3, 14);
            check("DIVIDIR continua dividindo", cut.mpts.length + ":" + cut.mpts[1].time + ":" + cut.mpts[2].time, "4:4:6");
        }
        System.out.println("TimelineEditTest fails=" + fails);
    }
}
