package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Rotulos do comeco e das faixas das timelines (principal e da reacao): todos precisam sair em EN e ES. */
public class TimelineLabelsTest {
    /** Termos que sao iguais nos tres idiomas (nome de campo, sigla ou palavra igual). */
    static final Set<String> NEUTRAL = new HashSet<String>(Arrays.asList(
            "SPRITES", "SPEED", "SEQ", "Links", "Audio", "Hitbox", "Hurtbox", "Hitboxes", "Hurtboxes", "Cutscene", "Link 2", "POUSO", "x", "y", "＋", "↻ LOOP",
            "img 3", "SEQ_PROJ", "QUEDA → 89", "Hitbox", "Voz", "0.5s/30 ticks", "0.02s/1 tick", "250 ticks", "±3.5 px/t", "ANO 5 · 12t", "← SEQ 7·f2", "SEQ → 12", "END ✕", "POUSO 13/89"));

    static List<String> labels() {
        List<String> l = new ArrayList<String>();
        l.addAll(Arrays.asList(ObjModel.KIND_NAMES));
        for (int f : ObjModel.ACTION_FLAGS) l.add(ObjModel.actionName(f));
        for (int f : new int[]{31, 33, 37, 999, ObjModel.VF_SCENE, ObjModel.VF_WALL, ObjModel.VF_DUST + 3}) l.add(ObjModel.actionName(f));
        l.add(ObjModel.windowName());
        l.addAll(Arrays.asList("Tentar agarrão", "Repetir projétil", "Janela 512 (conflito)", "Janela de cancel (512)"));
        l.addAll(Arrays.asList(TimelineView.FILTER_NAMES));
        l.addAll(Arrays.asList(ReactionLayout.NAMES));
        l.addAll(Arrays.asList(ReactionLayout.FILTER_NAMES));
        // fixos da timeline principal
        l.addAll(Arrays.asList("SPRITES", "Audio", "Velocidade", "Links", "Transicoes", "Estilo", "sem ANO", "toque p/ abrir", "toque p/ fechar", "+ som", "+ velocidade", "+ velocidade X", "+ velocidade Y", "Velocidade X", "Velocidade Y", "+ estilo", "↻ LOOP"));
        // dinamicos
        l.addAll(Arrays.asList("Link 2", "Transicoes 2", "Efeito 1.2", "animação ligada: ANO 7", "som 12", "img 3", "vel", "x 1.5 y 2 acel", "acel",
                "0.5s/30 ticks", "0.02s/1 tick", "ANO 5"));
        // fixos e dinamicos da timeline da reacao
        l.addAll(Arrays.asList("PASSOS", "sem reação", "REAÇÃO 31", "JOGO 4", "passo 3", "passo 3 ⇄", "→ pers. 1", "→ jogo 4", "ANO 5 · 12t", "ANO 5 · até pousar 12t",
                "parede 2", "♪ 5", "até o passo 3", "250 ticks", "±3.5 px/t"));
        // marcas de transicao
        l.addAll(Arrays.asList("SEQ → 12", "END ✕", "POUSO 13/89", "← SEQ 7·f2"));
        return l;
    }

    public static void main(String[] args) {
        int old = I18n.lang();
        Set<String> uniq = new java.util.LinkedHashSet<String>(labels());
        StringBuilder bad = new StringBuilder();
        int n = 0;
        for (String pt : uniq) {
            n++;
            String en = I18n.trTo(pt, I18n.EN), es = I18n.trTo(pt, I18n.ES);
            boolean neutral = NEUTRAL.contains(pt) || !I18n.hasLetters(pt.replaceAll("[A-Z_]+|\\d+|[xy]\\b", ""));
            if (!neutral && (en.equals(pt) || es.equals(pt) && !SAME_ES.contains(pt))) bad.append(pt).append(" -> ").append(en).append(" | ").append(es).append('\n');
            if (!digits(pt).equals(digits(en)) || !digits(pt).equals(digits(es))) bad.append("[numeros] ").append(pt).append(" -> ").append(en).append(" | ").append(es).append('\n');
        }
        if (bad.length() > 0) System.out.print(bad);
        check("todos os rotulos das timelines (" + n + ") saem em EN e ES", bad.length() == 0, true);
        // o PT nao muda
        check("PT intacto", I18n.trTo("Velocidade", I18n.PT), "Velocidade");
        I18n.set(old);
        System.out.println("TimelineLabelsTest fails=" + fails);
    }

    /** Iguais em PT e ES (cognatos). */
    static final Set<String> SAME_ES = new HashSet<String>(Arrays.asList("Estilo", "Efeito 1.2", "Estilo (espelhar, transformacao)", "Curar vida", "+ estilo", "vel", "acel", "→ pers. 1", "x 1.5 y 2 acel"));

    static String digits(String s) {
        StringBuilder b = new StringBuilder();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(s);
        while (m.find()) b.append(m.group()).append(',');
        return b.toString();
    }
}
