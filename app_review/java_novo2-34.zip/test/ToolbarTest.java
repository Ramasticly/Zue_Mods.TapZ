package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** ToolbarOrder (ordem dos botoes do menu superior) e HelpText (menu AJUDA). */
public class ToolbarTest {
    static String s(List<String> l) { return ToolbarOrder.save(l); }

    public static void main(String[] args) throws Exception {
        List<String> def = ToolbarOrder.defaults();
        check("padrao: SALVAR fixo no inicio", def.get(0), ToolbarOrder.SAVE);
        check("padrao: SCREEN (TELA) no fim; AJUDA fica na barra de titulo", def.get(def.size() - 1) + ":" + def.contains("help"), "scr:false");
        check("padrao: 15 botoes sem repeticao", def.size() + ":" + new HashSet<String>(def).size(), "15:15");

        // restaurar
        check("sem nada salvo: padrao", s(ToolbarOrder.restore(null, def)), s(def));
        check("texto vazio: padrao", s(ToolbarOrder.restore("", def)), s(def));
        check("ordem salva volta igual", s(ToolbarOrder.restore(s(ToolbarOrder.move(def, 0, 3)), def)), s(ToolbarOrder.move(def, 0, 3)));
        List<String> junk = ToolbarOrder.restore("hide,xyz,hide, char ,save", def);
        check("lixo: desconhecido e repetido saem, o resto vem na ordem de fabrica", s(junk),
                "hide,char,save,spr,snd,links,opt,hit,time,ctr,land,lock,flip,ghost,scr");
        check("lixo: mantem 15 ids", junk.size(), 15);
        check("SONS fica ao lado de SPRITES no padrao", def.indexOf(ToolbarOrder.SOUNDS) + ":" + def.indexOf(ToolbarOrder.SPRITES), "3:2");
        check("ordem salva antiga (sem SONS) ganha SONS logo depois de SPRITES", s(ToolbarOrder.restore("save,links,spr,char,opt,hit,time,ctr,land,lock,flip,hide,ghost,scr", def)),
                "save,links,spr,snd,char,opt,hit,time,ctr,land,lock,flip,hide,ghost,scr");
        check("SONS sem SPRITES salvo vai ao fim", s(ToolbarOrder.restore("save,char", Arrays.asList("save", "char", "spr", "snd"))), "save,char,spr,snd");
        check("SONS salvo em outro lugar continua la", s(ToolbarOrder.restore("snd,save,spr,char,links,opt,hit,time,ctr,land,lock,flip,hide,ghost,scr", def)).startsWith("snd,save,spr,char"), true);
        List<String> older = Arrays.asList(ToolbarOrder.SAVE, ToolbarOrder.CHAR);
        check("botao novo (nao salvo) entra no fim", s(ToolbarOrder.restore("char,save", ToolbarOrder.defaults())).endsWith(",scr"), true);
        check("ordem salva de versao anterior com help: descartado", s(ToolbarOrder.restore("help,char,save", ToolbarOrder.defaults())).contains("help"), false);
        check("botao ausente da build nao entra", s(ToolbarOrder.restore("char,save,scr", older)), "char,save");

        // mover
        check("mover para tras fica antes do alvo", s(ToolbarOrder.move(Arrays.asList("a", "b", "c", "d"), 3, 1)), "a,d,b,c");
        check("mover para frente fica depois do alvo", s(ToolbarOrder.move(Arrays.asList("a", "b", "c", "d"), 0, 2)), "b,c,a,d");
        check("mover para o slot fixo", s(ToolbarOrder.move(Arrays.asList("a", "b", "c", "d"), 2, 0)), "c,a,b,d");
        check("mover para o mesmo lugar nao muda", s(ToolbarOrder.move(Arrays.asList("a", "b", "c"), 1, 1)), "a,b,c");
        check("destino fora da lista prende na ponta", s(ToolbarOrder.move(Arrays.asList("a", "b", "c"), 0, 9)) + "|" + s(ToolbarOrder.move(Arrays.asList("a", "b", "c"), 2, -4)), "b,c,a|c,a,b");
        check("origem invalida nao muda", s(ToolbarOrder.move(Arrays.asList("a", "b"), 5, 0)), "a,b");
        check("lista vazia", ToolbarOrder.move(Arrays.<String>asList(), 0, 0).size(), 0);
        List<String> orig = Arrays.asList("a", "b", "c");
        ToolbarOrder.move(orig, 0, 2);
        check("move devolve copia", s(orig), "a,b,c");
        // salvar + restaurar com varios movimentos (arrastar o botao fixo, depois outro para o fixo)
        List<String> o = ToolbarOrder.move(def, 0, def.size() - 1);
        o = ToolbarOrder.move(o, 5, 0);
        check("viagem de ida e volta", s(ToolbarOrder.restore(s(o), ToolbarOrder.defaults())), s(o));
        check("o primeiro e o que foi solto no slot fixo", o.get(0), def.get(6));

        // ajuda
        Set<String> ids = new HashSet<String>();
        for (HelpText.Section sec : HelpText.toolbar()) {
            check("ajuda " + sec.title + ": tem texto", sec.body.length() > 40 && sec.title.length() > 0, true);
            ids.add(sec.button);
        }
        check("ajuda: um item para cada botao do menu, na ordem de fabrica", HelpText.toolbar().size() + ":" + ids.containsAll(def), "15:true");
        for (String id : def) check("ajuda do botao " + id, HelpText.forButton(id) != null, true);
        check("ajuda de id desconhecido", HelpText.forButton("nao-existe"), null);
        check("ajuda da tela nao tem botao do menu", HelpText.screen().get(0).button, null);
        check("ajuda: tudo = menu + tela", HelpText.all().size(), HelpText.toolbar().size() + HelpText.screen().size());
        check("ajuda: dica de reordenar fala em arrastar e no botao fixo", HelpText.REORDER_TIP.contains("arraste") && HelpText.REORDER_TIP.contains("fixo"), true);

        // faixas visiveis da timeline no modo T: 6 com o menu baixo, 2 no maximo, sempre entre 2 e 6
        check("faixas: menu no minimo = 6", TimelineView.lanesFor(0f), 6);
        check("faixas: menu no maximo = 2", TimelineView.lanesFor(1f), 2);
        check("faixas: meio = 4", TimelineView.lanesFor(0.5f), 4);
        check("faixas: fora de 0..1 prende em 6 e 2", TimelineView.lanesFor(-3f) + ":" + TimelineView.lanesFor(9f), "6:2");
        int prev = 99; boolean mono = true, inRange = true;
        for (int i = 0; i <= 100; i++) { int n = TimelineView.lanesFor(i / 100f); mono &= n <= prev; prev = n; inRange &= n >= 2 && n <= 6; }
        check("faixas: nunca aumenta ao subir e fica em 2..6", mono && inRange, true);

        // faixas de transicao: marcas do mesmo frame em faixas diferentes, frames diferentes reusam a faixa 0
        java.util.List<SeqMark> mk = new java.util.ArrayList<SeqMark>();
        check("transicoes: sem marcas = 0 faixas", TimelineView.laneCount(TimelineView.seqLanes(mk)), 0);
        int[] pats = {0, 2, 5, 2, 2, 0};
        for (int pt : pats) { SeqMark m = new SeqMark(); m.pat = pt; mk.add(m); }
        int[] ln = TimelineView.seqLanes(mk);
        check("transicoes: lane por ordem dentro do frame", java.util.Arrays.toString(ln), "[0, 0, 0, 1, 2, 1]");
        check("transicoes: faixas = maximo simultaneo", TimelineView.laneCount(ln), 3);
        mk.clear();
        for (int pt = 0; pt < 4; pt++) { SeqMark m = new SeqMark(); m.pat = pt; mk.add(m); }
        check("transicoes: frames distintos = 1 faixa", TimelineView.laneCount(TimelineView.seqLanes(mk)), 1);

        HelpText.Section sa = null;
        for (HelpText.Section sec : HelpText.screen()) if (sec.title.startsWith("Speed x Accel")) sa = sec;
        check("ajuda: secao Speed x Accel existe", sa != null, true);
        check("ajuda: Speed x Accel explica constante, soma a cada tick e exemplo", sa != null && sa.body.contains("constante") && sa.body.contains("a cada tick") && sa.body.contains("500 px") && sa.body.contains("250 px"), true);

        // ---- AJUDA em capitulos
        java.util.List<HelpText.Chapter> chs = HelpText.chapters();
        java.util.Set<String> chIds = new HashSet<String>();
        boolean chOk = true;
        for (HelpText.Chapter ch : chs) {
            chIds.add(ch.id);
            chOk &= ch.title.length() > 3 && ch.summary.length() > 20 && !ch.sections.isEmpty();
            for (HelpText.Section sec : ch.sections) chOk &= sec.title.length() > 2 && sec.body.length() > 40;
        }
        check("ajuda: 14 capitulos com id unico, titulo, resumo e secoes com texto", chs.size() + ":" + chIds.size() + ":" + chOk, "14:14:true");
        check("ajuda: capitulos pedidos existem (ramificacao, sequencias, reacoes, speed, menus de edicao)",
                chIds.containsAll(Arrays.asList("inicio", "menu", "timeline", "sprite", "box", "golpe", "projetil", "sequencia", "reacao", "speed", "links", "sons", "salvar", "avisos")), true);
        HelpText.Chapter menuCh = null;
        for (HelpText.Chapter ch : chs) if (ch.id.equals(HelpText.CH_MENU)) menuCh = ch;
        check("ajuda: o capitulo do menu superior tem a dica de ordem e os 14 botoes", menuCh != null && menuCh.sections.size() == 16, true);
        check("ajuda: all() = menu + resto", HelpText.all().size(), HelpText.toolbar().size() + HelpText.screen().size());
        check("ajuda: busca vazia nao acha nada", HelpText.search("  ").size(), 0);
        check("ajuda: busca sem acento acha reacao", HelpText.search("reacao").size() > 3 && HelpText.search("REAÇÃO").size() == HelpText.search("reacao").size(), true);
        boolean spd = false, seq = false, ram = false;
        for (HelpText.Hit h : HelpText.search("bit 64")) spd |= h.chapter.id.equals("speed");
        for (HelpText.Hit h : HelpText.search("SEQ_PROJETIL")) seq |= h.chapter.id.equals("sequencia");
        for (HelpText.Hit h : HelpText.search("ramificacao")) ram |= h.chapter.id.equals("projetil");
        check("ajuda: busca acha speed (bit 64), sequencia (SEQ_PROJETIL) e ramificacao nos capitulos certos", spd && seq && ram, true);
        check("ajuda: varias palavras exigem todas", HelpText.search("speed accel").size() > 0 && HelpText.search("speed palavraqueNaoExiste").size() == 0, true);
        boolean lim = false;
        for (HelpText.Hit h : HelpText.search("limites do jogo")) lim |= h.section.body.contains("10 caixas") && !h.section.body.contains("50 caixas");
        check("ajuda: limite de caixas por frame e 10 (o array guarda 50 numeros)", lim, true);
        boolean tabs = false;
        for (HelpText.Hit h : HelpText.search("editor de reacoes")) tabs |= h.section.body.contains("EFEITOS") && h.section.body.contains("SEQ") && h.section.body.contains("ARRASTE");
        check("ajuda: editor de reacoes descreve as faixas novas e arrastar a duracao", tabs, true);

        System.out.println("ToolbarTest fails=" + BattleTest.fails);
    }
}
