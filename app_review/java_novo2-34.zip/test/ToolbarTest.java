package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** ToolbarOrder (ordem dos botoes do menu superior) e HelpText (menu AJUDA). */
public class ToolbarTest {
    static String s(List<String> l) { return ToolbarOrder.save(l); }

    public static void main(String[] args) throws Exception {
        List<String> def = ToolbarOrder.defaults();
        check("padrao: SALVAR fixo no inicio", def.get(0), ToolbarOrder.SAVE);
        check("padrao: AJUDA no fim", def.get(def.size() - 1), ToolbarOrder.HELP);
        check("padrao: 15 botoes sem repeticao", def.size() + ":" + new HashSet<String>(def).size(), "15:15");

        // restaurar
        check("sem nada salvo: padrao", s(ToolbarOrder.restore(null, def)), s(def));
        check("texto vazio: padrao", s(ToolbarOrder.restore("", def)), s(def));
        check("ordem salva volta igual", s(ToolbarOrder.restore(s(ToolbarOrder.move(def, 0, 3)), def)), s(ToolbarOrder.move(def, 0, 3)));
        List<String> junk = ToolbarOrder.restore("hide,xyz,hide, char ,save", def);
        check("lixo: desconhecido e repetido saem, o resto vem na ordem de fabrica", s(junk),
                "hide,char,save,spr,links,opt,hit,time,ctr,land,lock,flip,ghost,scr,help");
        check("lixo: mantem 15 ids", junk.size(), 15);
        List<String> older = Arrays.asList(ToolbarOrder.SAVE, ToolbarOrder.CHAR);
        check("botao novo (nao salvo) entra no fim", s(ToolbarOrder.restore("char,save", ToolbarOrder.defaults())).endsWith(",help"), true);
        check("botao ausente da build nao entra", s(ToolbarOrder.restore("char,save,help", older)), "char,save");

        // mover
        check("mover para tras fica antes do alvo", s(ToolbarOrder.move(Arrays.asList("a", "b", "c", "d"), 3, 1)), "a,d,b,c");
        check("mover para frente fica depois do alvo", s(ToolbarOrder.move(Arrays.asList("a", "b", "c", "d"), 0, 2)), "b,c,a,d");
        check("mover para o slot fixo", s(ToolbarOrder.move(Arrays.asList("a", "b", "c", "d"), 2, 0)), "c,a,b,d");
        check("mover para o mesmo lugar nao muda", s(ToolbarOrder.move(Arrays.asList("a", "b", "c"), 1, 1)), "a,b,c");
        check("destino fora da lista prende na ponta", s(ToolbarOrder.move(Arrays.asList("a", "b", "c"), 0, 9)) + "|" + s(ToolbarOrder.move(Arrays.asList("a", "b", "c"), 2, -4)), "b,c,a|c,a,b");
        check("origem invalida nao muda", s(ToolbarOrder.move(Arrays.asList("a", "b"), 5, 0)), "a,b");
        check("lista vazia", ToolbarOrder.move(Arrays.<String>asList(), 0, 0).size(), 0);
        List<String> orig = Arrays.asList("a", "b", "c");
        ToolbarOrder.move(orig, 0, 2);
        check("move devolve copia", s(orig), "a,b,c");
        // salvar + restaurar com varios movimentos (arrastar o botao fixo, depois outro para o fixo)
        List<String> o = ToolbarOrder.move(def, 0, def.size() - 1);
        o = ToolbarOrder.move(o, 5, 0);
        check("viagem de ida e volta", s(ToolbarOrder.restore(s(o), ToolbarOrder.defaults())), s(o));
        check("o primeiro e o que foi solto no slot fixo", o.get(0), def.get(6));

        // ajuda
        Set<String> ids = new HashSet<String>();
        for (HelpText.Section sec : HelpText.toolbar()) {
            check("ajuda " + sec.title + ": tem texto", sec.body.length() > 40 && sec.title.length() > 0, true);
            ids.add(sec.button);
        }
        check("ajuda: um item para cada botao do menu, na ordem de fabrica", HelpText.toolbar().size() + ":" + ids.containsAll(def), "15:true");
        for (String id : def) check("ajuda do botao " + id, HelpText.forButton(id) != null, true);
        check("ajuda de id desconhecido", HelpText.forButton("nao-existe"), null);
        check("ajuda da tela nao tem botao do menu", HelpText.screen().get(0).button, null);
        check("ajuda: tudo = menu + tela", HelpText.all().size(), HelpText.toolbar().size() + HelpText.screen().size());
        check("ajuda: dica de reordenar fala em arrastar e no botao fixo", HelpText.REORDER_TIP.contains("arraste") && HelpText.REORDER_TIP.contains("fixo"), true);

        System.out.println("ToolbarTest fails=" + BattleTest.fails);
    }
}
