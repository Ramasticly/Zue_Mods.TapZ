package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.HashMap;
import java.util.Map;

/** Salvar em outro personagem por etapas: sem sprites (IMG -1) e reacoes sem igual nem vaga (USAR ESSA / SUBSTITUIR). */
public class TransplantStepsTest {
    static A[] anos(int n) {
        A[] a = new A[n];
        for (int i = 0; i < n; i++) a[i] = new A().mpt(new M().time(5).img(1));
        return a;
    }

    public static void main(String[] args) throws Exception {
        A[] sa = anos(30);
        sa[10] = new A().mpt(new M().time(5).img(3).hit(2, 10, -30, 20, 20).opt1(32)).mpt(new M().time(5).img(7)).mpt(new M().time(5).img(-1));
        sa[11] = new A().mpt(new M().time(5).img(7).hit(2, 5, -30, 20, 20).opt1(31));
        Dac sd = dac(sa);
        byte[][] sreact = new byte[3][];
        sreact[1] = react(new int[]{10, 11, 12}, new int[]{20, 21, 22});
        sreact[2] = react(new int[]{77, 1, 2});
        CharData src = chr(move(new int[]{0, 4}, new int[]{2, 10}, new int[]{10, 11}), sreact);
        CharData.Move m = src.moves[0];

        // destino com os 20 slots cheios e diferentes dos da origem: nao ha igual nem vaga
        byte[][] full = new byte[20][];
        for (int i = 0; i < 20; i++) full[i] = react(new int[]{1 + i, 2, 3});
        CharData dstFull = chr(move(new int[]{0, 4}, new int[]{2, 3}), full);
        Dac dd = dac(anos(8));

        check("sem igual nem vaga: as reacoes 1 e 2 precisam de decisao", MoveTransplant.needsChoice(sd, src, m, dd, dstFull, null).toString(), "[1, 2]");

        // destino com um slot vazio e uma reacao igual: nada a perguntar
        byte[][] some = new byte[6][];
        some[1] = sreact[1];
        some[5] = react(new int[]{1, 2, 3});
        CharData dstSome = chr(move(new int[]{0, 4}, new int[]{2, 3}), some);
        check("reacao igual (1) e vaga vazia (2): nada a perguntar", MoveTransplant.needsChoice(sd, src, m, dd, dstSome, null).isEmpty(), true);

        // decisoes: 1 = USAR o slot 7 (nao grava), 2 = SUBSTITUIR o slot 9
        Map<Integer, MoveTransplant.Choice> ch = new HashMap<Integer, MoveTransplant.Choice>();
        ch.put(Integer.valueOf(1), new MoveTransplant.Choice(false, 7));
        ch.put(Integer.valueOf(2), new MoveTransplant.Choice(true, 9));
        MoveTransplant.Plan p = MoveTransplant.build(sd, src, m, dd, dstFull, null, null, ch);
        check("USAR ESSA e SUBSTITUIR no mapa de reacoes", p.reactionMap.toString(), "{1=7, 2=9}");
        check("so o SUBSTITUIR grava (no slot 9)", p.reactionWrites.keySet().toString(), "[9]");
        check("OPT 1 da hitbox aponta para o slot escolhido (32 -> 39)", p.anos.get(0).mpts[0].optData[1], 39);

        // sem sprites: IMG -1, nenhuma sprite pedida
        check("sem sprites: nenhuma contada", p.sprites, 0);
        check("sem sprites: todos os frames com IMG -1", p.anos.get(0).mpts[0].image + ":" + p.anos.get(0).mpts[1].image + ":" + p.anos.get(0).mpts[2].image, "-1:-1:-1");

        // sem decisao: continua apontando para o numero original, com aviso
        MoveTransplant.Plan q = MoveTransplant.build(sd, src, m, dd, dstFull, null, null, new HashMap<Integer, MoveTransplant.Choice>());
        boolean warn = false;
        for (String w : q.warnings) if (w.contains("sem decis")) warn = true;
        check("sem decisao: nada mapeado e com aviso", q.reactionMap.isEmpty() && q.reactionWrites.isEmpty() && warn, true);

        // com sprites (comportamento antigo) continua pedindo as imagens
        final java.util.List<Integer> asked = new java.util.ArrayList<Integer>();
        MoveTransplant.Plan r = MoveTransplant.build(sd, src, m, dd, dstSome, new MoveTransplant.Sprites() {
            public int add(int image) { asked.add(Integer.valueOf(image)); return 50 + asked.size(); }
        }, null);
        check("com sprites: pede as imagens 3 e 7", asked.toString() + ":" + r.sprites, "[3, 7]:2");
        System.out.println("TransplantStepsTest fails=" + fails);
    }
}
