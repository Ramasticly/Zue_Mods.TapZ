package com.zue.attackeditor;

import java.io.File;
import static com.zue.attackeditor.BattleTest.*;

/** TXT de qualquer nome: *.dac.txt / *.bin.txt / *.cnv.txt; 000. primeiro; sem TXT = erro claro. */
public class TxtFilesTest {
    static void touch(File d, String n) throws Exception { java.nio.file.Files.write(new File(d, n).toPath(), new byte[]{'x'}); }

    public static void main(String[] args) throws Exception {
        File d = File.createTempFile("txtf", "");
        d.delete();
        d.mkdirs();
        try {
            check("pasta vazia: nenhum", TxtFiles.find(d, "dac") == null && TxtFiles.all(d, "bin").isEmpty(), true);
            boolean thrown = false;
            String msg = "";
            try { TxtFiles.require(d, "dac"); } catch (TxtFiles.Missing e) { thrown = true; msg = e.getMessage(); }
            check("sem TXT: Missing com a extensao e a pasta", thrown && msg.contains("*.dac.txt") && msg.contains(d.getPath()), true);

            touch(d, "char13.dac.txt");
            touch(d, "char13.bin.txt");
            touch(d, "char13.CNV.TXT");
            touch(d, "000.dac");                 // binario: nunca conta
            touch(d, "000.png");
            touch(d, "notas.txt");
            touch(d, ".dac.txt");
            check("nome livre: char13.dac.txt", TxtFiles.find(d, "dac").getName(), "char13.dac.txt");
            check("bin e cnv (caixa mista) tambem", TxtFiles.find(d, "bin").getName() + "," + TxtFiles.find(d, "cnv").getName(), "char13.bin.txt,char13.CNV.TXT");
            check("o binario sozinho nao e achado", TxtFiles.find(d, "dac").getName().endsWith(".txt"), true);
            check("sem aviso com um so", TxtFiles.duplicates(d, "dac"), null);

            touch(d, "aaa.dac.txt");
            touch(d, "000.dac.txt");
            check("com 000.: ele vem primeiro", TxtFiles.find(d, "dac").getName(), "000.dac.txt");
            check("ordem: 000., aaa, char13", TxtFiles.all(d, "dac").toString().replace(d.getPath() + File.separator, ""), "[000.dac.txt, aaa.dac.txt, char13.dac.txt]");
            check("aviso de duplicado cita o usado", TxtFiles.duplicates(d, "dac").contains("3 arquivos *.dac.txt") && TxtFiles.duplicates(d, "dac").contains("000.dac.txt"), true);

            check("isKind", TxtFiles.isKind("A.DAC.TXT", "dac") + "," + TxtFiles.isKind("x.dac", "dac") + "," + TxtFiles.isKind("dac.txt", "dac") + "," + TxtFiles.isKind("x.bin.txt", "dac"), "true,false,false,false");
            check("withoutTxt", TxtFiles.withoutTxt(new File("/a/b/char13.cnv.txt")).getName() + "," + TxtFiles.withoutTxt(new File("/a/b/x.cnv")).getName(), "char13.cnv,x.cnv");
        } finally {
            File[] f = d.listFiles();
            if (f != null) for (File x : f) x.delete();
            d.delete();
        }
    }
}
