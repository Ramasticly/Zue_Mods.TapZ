package com.zue.attackeditor;

import java.io.File;

/**
 * SO PARA TESTES: sobrepoe um .txt avulso (sem formato BIN_CNV_ completo) a um DAC/CharData ja montado. O app em si le tudo dos TXT por {@link Dac#fromTxt} e
 * {@link CharData#fromTxt}; estes dois metodos so deixam os testes antigos checarem trechos de texto sem montar o arquivo inteiro.
 */
final class TxtOverlay {
    private TxtOverlay() { }

    /** Texto sem comentarios, espacos e virgula final: para comparar o bloco do .txt com o que o app geraria. */
    static String norm(String t) {
        StringBuilder sb = new StringBuilder();
        for (String ln : t.split("\n")) {
            int c = ln.indexOf("//");
            if (c >= 0) ln = ln.substring(0, c);
            sb.append(ln.replaceAll("\\s+", ""));
        }
        String r = sb.toString();
        return r.endsWith(",") ? r.substring(0, r.length() - 1) : r;
    }

    /**
     * O app grava as edicoes em 000.dac.txt (o .dac binario nao e reescrito aqui). O .txt manda (o .dac binario e so uma compilacao dele): os blocos $ANO_n
     * que diferem do binario sao lidos de volta, senao uma ANO editada/esvaziada voltaria ao que era ao reabrir o app.
     */
    static void applyDacTxt(Dac dac, File dacFile) {
        File txt = new File(dacFile.getPath() + ".txt");
        if (!txt.isFile()) return;
        String text;
        try { text = new String(GameData.readAll(txt), "UTF-8"); } catch (Exception e) { return; }
        for (int i = 0; i < dac.size(); i++) {
            int[] b = Saver.findBlock(text, "ANO_" + i);
            if (b == null) continue;
            String blk = text.substring(b[0], b[2] + 1);
            Ano old = dac.getAno(i);
            String cur = old == null ? "$ANO_" + i + ":{}" : DacText.ano(old, -1);
            String nb = norm(blk);
            if (nb.equals(norm(cur))) continue;
            try {
                Ano na = DacText.parseAno(blk, i, old);
                if (na.mpts.length == 0 && na.links.length == 0) na = new Ano(i, false, 0, 0, new Ano.Link[0], new Ano.Mpt[0]);
                dac.setAno(i, na);
            } catch (Exception ex) { /* bloco que nao le: fica o binario */ }
        }
        // ANOs que o .txt tem alem do binario (ex.: golpe transplantado de outro personagem): entram no fim da tabela
        int maxIdx = -1;
        java.util.regex.Matcher mm = java.util.regex.Pattern.compile("\\$ANO_(\\d+)\\s*:").matcher(text);
        while (mm.find()) {
            int ls = text.lastIndexOf('\n', mm.start()) + 1;
            if (text.substring(ls, mm.start()).contains("//")) continue;
            try { maxIdx = Math.max(maxIdx, Integer.parseInt(mm.group(1))); } catch (NumberFormatException ignored) { }
        }
        int old0 = dac.size();
        if (maxIdx >= old0 && maxIdx <= 0x0FFF) {
            dac.growTo(maxIdx + 1);
            for (int i = old0; i <= maxIdx; i++) {
                int[] b = Saver.findBlock(text, "ANO_" + i);
                if (b == null) continue;
                try {
                    Ano na = DacText.parseAno(text.substring(b[0], b[2] + 1), i, dac.getAno(i));
                    if (na.mpts.length > 0 || na.links.length > 0) dac.setAno(i, na);
                } catch (Exception ex) { /* bloco que nao le: o ANO fica ausente */ }
            }
        }
    }

    private static final String[] FR_KEYS = {"DUR_C", "DUR_A", "ANO", "XSPEED", "YSPEED", "XACCEL", "YACCEL", "XSPEED_A", "YSPEED_A", "XACCEL_A", "YACCEL_A", "COMP", "WALL", "VOZ"};

    /** O 000.bin.txt manda sobre o 000.bin: golpes ($GOLPE_n) e tabelas de reacao ($REACAO_DANO_n) sao lidos dele. */
    static void applyBinTxt(CharData cd, File binFile) {
        File txt = new File(binFile.getPath() + ".txt");
        if (!txt.isFile()) return;
        String text;
        try { text = new String(GameData.readAll(txt), "UTF-8"); } catch (Exception e) { return; }
        for (int i = 0; i < cd.moves.length; i++) {
            int[] b = Saver.findBlock(text, "GOLPE_" + i);
            if (b == null) continue;
            try { DacText.parseMove(text.substring(b[0], b[2] + 1), cd.moves[i]); } catch (Exception ex) { /* fica o binario */ }
        }
        int[] bb = Saver.findBlock(text, "STATUS_BASE_E_FISICA");
        if (bb != null) {
            String blk = text.substring(bb[0], bb[2] + 1);
            java.util.regex.Matcher mw = java.util.regex.Pattern.compile("\\$LARGURA\\s*:\\s*(\\d+)").matcher(blk);
            java.util.regex.Matcher mh = java.util.regex.Pattern.compile("\\$ALTURA\\s*:\\s*(\\d+)").matcher(blk);
            if (mw.find() && mh.find()) cd.setBody(Integer.parseInt(mw.group(1)) * 2, Integer.parseInt(mh.group(1)));
            java.util.regex.Matcher mp = java.util.regex.Pattern.compile("\\$DISTANCIA_AGARRE\\s*:\\s*(\\d+)").matcher(blk);
            if (mp.find()) cd.setPullDistance(Integer.parseInt(mp.group(1)));
        }
        int[][] evs = CutsceneText.parse(text);                  // $ROTEIRO_CUTSCENE (HDAT 13): o texto manda sobre o binario
        if (evs != null) cd.loadEvents(evs);
        for (int ty = 0; ty < CharData.REACTION_COUNT; ty++) {
            ReactionTable t = cd.reaction(ty);
            int[] b = Saver.findBlock(text, "REACAO_DANO_" + ty);
            if (t == null || b == null) continue;
            StringBuilder sb = new StringBuilder();
            for (String ln : text.substring(b[1], b[2] + 1).split("\n")) {
                int c = ln.indexOf("//");
                sb.append(c >= 0 ? ln.substring(0, c) : ln).append('\n');
            }
            java.util.regex.Matcher fm = java.util.regex.Pattern.compile("\\$FR_(\\d+)\\s*:\\s*\\{([^}]*)\\}").matcher(sb);
            java.util.TreeMap<Integer, int[]> rows = new java.util.TreeMap<Integer, int[]>();
            while (fm.find()) {
                int[] v = new int[FR_KEYS.length];
                java.util.regex.Matcher km = java.util.regex.Pattern.compile("\\$([A-Za-z_]+)\\s*:\\s*(-?\\d+)").matcher(fm.group(2));
                while (km.find()) for (int k = 0; k < FR_KEYS.length; k++) if (FR_KEYS[k].equalsIgnoreCase(km.group(1))) v[k] = Integer.parseInt(km.group(2));
                rows.put(Integer.valueOf(Integer.parseInt(fm.group(1))), v);
            }
            if (rows.isEmpty()) continue;
            ReactionTable nt = new ReactionTable(new byte[rows.size() * ReactionTable.STRIDE], rows.size());
            int r = 0;
            for (int[] v : rows.values()) { for (int k = 0; k < v.length; k++) nt.set(r, k, v[k]); r++; }
            t.restoreFrom(nt);
        }
    }
}
