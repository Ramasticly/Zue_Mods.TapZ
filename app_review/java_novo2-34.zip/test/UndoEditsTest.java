package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.List;

/** Fabricas de edicao do desfazer: ida e volta com DAC, golpe e tabela de reacao reais. */
public class UndoEditsTest {
    static int firstTime(Dac d, int idx) { return d.getAno(idx).mpts[0].time; }

    public static void main(String[] args) throws Exception {
        A[] a = SpawnDiagTest.anos();
        a[40] = new A().mpt(new M().time(4)).mpt(new M().time(5));
        a[41] = new A().mpt(new M().time(7));
        Dac d = dac(a);

        // swapAno
        Ano old = d.getAno(40);
        Ano na = new Ano(40, true, 0, 0, new Ano.Link[0], new Ano.Mpt[] {old.mpts[0].copy()});
        na.mpts[0].time = 9;
        d.setAno(40, na);
        UndoHistory.Edit e = UndoEdits.swapAno(d, 40, old);
        UndoHistory.Edit back = e.revert();
        check("swapAno: desfaz", d.getAno(40) == old, true);
        back.revert();
        check("swapAno: refaz (a ANO nova volta)", d.getAno(40) == na, true);

        // swapAnos (varias ANOs de uma vez)
        Ano o40 = d.getAno(40), o41 = d.getAno(41);
        List<Ano> olds = new ArrayList<Ano>();
        olds.add(o40); olds.add(o41);
        Ano n40 = new Ano(40, true, 0, 0, new Ano.Link[0], o40.mpts), n41 = new Ano(41, true, 0, 0, new Ano.Link[0], o41.mpts);
        d.setAno(40, n40); d.setAno(41, n41);
        UndoHistory.Edit b2 = UndoEdits.swapAnos(d, olds).revert();
        check("swapAnos: desfaz as duas", d.getAno(40) == o40 && d.getAno(41) == o41, true);
        b2.revert();
        check("swapAnos: refaz as duas", d.getAno(40) == n40 && d.getAno(41) == n41, true);

        // swapMpts (troca no proprio array)
        Ano an = new Ano(42, true, 0, 0, new Ano.Link[0], new Ano.Mpt[] {old.mpts[0].copy(), old.mpts[0].copy()});
        Ano.Mpt p0 = an.mpts[0], p1 = an.mpts[1];
        Ano.Mpt q0 = p0.copy(), q1 = p1.copy();
        q0.time = 11; q1.time = 12;
        an.mpts[0] = q0; an.mpts[1] = q1;
        UndoHistory.Edit b3 = UndoEdits.swapMpts(an, new int[] {0, 1}, new Ano.Mpt[] {p0, p1}).revert();
        check("swapMpts: desfaz", an.mpts[0] == p0 && an.mpts[1] == p1, true);
        b3.revert();
        check("swapMpts: refaz", an.mpts[0] == q0 && an.mpts[1] == q1, true);

        // swapMove / swapPull / swapReaction com dados reais
        CharData ch = chr(move(new int[] {2, 40}), new byte[][] {});
        CharData.Move mv = ch.moves[0];
        CharData.Move before = mv.copy();
        int origPull = ch.pullDistance();
        ch.setPullDistance(origPull + 5);
        UndoHistory.Edit pb = UndoEdits.swapPull(ch, origPull).revert();
        check("swapPull: desfaz", ch.pullDistance(), origPull);
        pb.revert();
        check("swapPull: refaz", ch.pullDistance(), origPull + 5);
        final int[] syncs = {0};
        mv.clamp();
        UndoHistory.Edit mb = UndoEdits.swapMove(mv, before, new Runnable() { public void run() { syncs[0]++; } }).revert();
        check("swapMove: desfaz roda o sync", syncs[0], 1);
        mb.revert();
        check("swapMove: refaz roda o sync de novo", syncs[0], 2);
        System.out.println("UndoEditsTest fails=" + fails);
    }
}
