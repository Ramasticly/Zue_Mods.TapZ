package com.zue.attackeditor;

import static com.zue.attackeditor.BattleTest.*;

import java.util.ArrayList;
import java.util.List;

/** Desfazer/refazer por hierarquias: a sessao (menu) e a pilha externa (menus aplicados). */
public class UndoHistoryTest {
    /** Estado de teste: x e hurtbox. */
    static final class St { int x = 30; int hurt = 0; }

    static UndoHistory.Edit swapX(final St s, final int old) {
        return new UndoHistory.Edit() { @Override public UndoHistory.Edit revert() { int cur = s.x; s.x = old; return swapX(s, cur); } };
    }
    static UndoHistory.Edit swapHurt(final St s, final int old) {
        return new UndoHistory.Edit() { @Override public UndoHistory.Edit revert() { int cur = s.hurt; s.hurt = old; return swapHurt(s, cur); } };
    }
    static void setX(UndoHistory h, St s, String key, long t, int v) { UndoHistory.Edit e = swapX(s, s.x); s.x = v; h.push(key, t, e); }
    static void setHurt(UndoHistory h, St s, int v) { UndoHistory.Edit e = swapHurt(s, s.hurt); s.hurt = v; h.push(null, 0, e); }
    static String st(St s) { return s.x + "/" + s.hurt; }

    public static void main(String[] args) throws Exception {
        // ---- fora de sessao: cada acao e uma entrada; refazer apagado por acao nova
        {
            UndoHistory h = new UndoHistory();
            St s = new St();
            setX(h, s, null, 0, 40); setX(h, s, null, 0, 50); setX(h, s, null, 0, 60);
            check("externo: 3 entradas", h.count(), 3);
            h.undo(); h.undo();
            check("externo: desfez 2", st(s) + ":" + h.canRedo(), "40/0:true");
            h.redo();
            check("externo: refez 1", st(s), "50/0");
            setX(h, s, null, 0, 99);
            check("externo: acao nova apaga o refazer", h.canRedo() + ":" + h.redo(), "false:false");
            check("externo: nada para desfazer vazio", new UndoHistory().undo(), false);
        }

        // ---- sessao: x 30 -> 40, aplicar hurtbox a todas; passo a passo ate o original e refaz tudo
        {
            UndoHistory h = new UndoHistory();
            St s = new St();
            h.begin();
            setX(h, s, "x", 1000, 40);
            setHurt(h, s, 7);
            check("sessao: 2 passos", h.count() + ":" + st(s), "2:40/7");
            h.undo();
            check("sessao: desfaz so a hurtbox (campo/botao)", st(s), "40/0");
            h.undo();
            check("sessao: desfaz o x ate o original", st(s) + ":" + h.canUndo(), "30/0:false");
            check("sessao: nada mais para desfazer", h.undo(), false);
            h.redo(); h.redo();
            check("sessao: refaz tudo", st(s) + ":" + h.canRedo(), "40/7:false");
            // desfaz um e muda outra coisa: o refazer some
            h.undo();
            setX(h, s, "x2", 9000, 55);
            check("sessao: mudanca nova apaga o refazer", st(s) + ":" + h.canRedo() + ":" + h.redo(), "55/0:false:false");
            check("sessao: 2 passos vigentes (x40 e x55)", h.count(), 2);
        }

        // ---- fusao por chave (o - + segurado): um passo so; e tambem apaga o refazer
        {
            UndoHistory h = new UndoHistory();
            St s = new St();
            h.begin();
            setX(h, s, "x", 1000, 31); setX(h, s, "x", 2000, 32); setX(h, s, "x", 3000, 33);
            check("fusao: 3 toques em 4 s = 1 passo", h.count() + ":" + st(s), "1:33/0");
            setX(h, s, "x", 9000, 34);
            check("fusao: depois de 4 s e outro passo", h.count(), 2);
            h.undo();
            check("fusao: desfazer volta ao estado antes da primeira", st(s), "33/0");
            h.undo();
            check("fusao: ... e ao original", st(s), "30/0");
            h.redo();
            setX(h, s, "x", 9500, 77);
            check("fusao: mudanca nova (mesmo apos desfazer) apaga o refazer", h.canRedo(), false);
        }

        // ---- commit: a sessao vira UMA entrada externa
        {
            UndoHistory h = new UndoHistory();
            St s = new St();
            setX(h, s, null, 0, 35);                               // acao externa anterior
            h.begin();
            setX(h, s, "x", 1000, 40); setHurt(h, s, 7); setX(h, s, null, 0, 45);
            check("menu aberto: o externo nao aparece (so a sessao)", h.count() + ":" + h.inSession(), "3:true");
            check("commit cria entrada", h.commit(), true);
            check("depois do commit: 2 entradas externas (a acao e o menu)", h.count() + ":" + h.inSession(), "2:false");
            h.undo();
            check("desfazer externo desfaz o menu INTEIRO de uma vez", st(s), "35/0");
            h.undo();
            check("... e a acao anterior", st(s), "30/0");
            h.redo();
            check("refazer repoe a acao", st(s), "35/0");
            h.redo();
            check("refazer repoe o menu inteiro", st(s), "45/7");
            h.undo();
            setHurt(h, s, 3);                                      // acao nova externa
            check("acao nova externa apaga o refazer externo", h.canRedo(), false);
        }

        // ---- sessao vazia nao cria entrada; sessao nao enxerga a externa
        {
            UndoHistory h = new UndoHistory();
            St s = new St();
            setX(h, s, null, 0, 35);
            h.begin();
            check("sessao nova: nada para desfazer apesar do externo", h.canUndo() + ":" + h.undo(), "false:false");
            check("commit vazio nao cria entrada", h.commit() + ":" + h.count(), "false:1");
            h.undo();
            check("a acao externa continua desfazivel", st(s), "30/0");
        }

        // ---- discard: desfaz o que restou (nao o que ja estava desfeito) e some com o refazer
        {
            UndoHistory h = new UndoHistory();
            St s = new St();
            h.begin();
            setX(h, s, null, 0, 40); setHurt(h, s, 7); setX(h, s, null, 0, 50);
            h.undo();                                              // x=40 hurt=7
            check("discard: desfaz so os vigentes e informa quantos", h.discard() + ":" + st(s), "2:30/0");
            check("discard: fecha a sessao e nao deixa refazer", h.inSession() + ":" + h.canRedo() + ":" + h.count(), "false:false:0");
        }

        // ---- grupo: ordem de desfazer (ultimo primeiro) e de refazer (primeiro primeiro)
        {
            final List<String> log = new ArrayList<String>();
            List<UndoHistory.Edit> es = new ArrayList<UndoHistory.Edit>();
            for (int i = 1; i <= 3; i++) es.add(mark(log, "e" + i, "r" + i));
            UndoHistory.Group g = new UndoHistory.Group(es);
            UndoHistory.Edit inv = g.revert();
            check("grupo: desfaz do ultimo para o primeiro", log.toString(), "[e3, e2, e1]");
            log.clear();
            inv.revert();
            check("grupo: refaz do primeiro para o ultimo", log.toString(), "[r1, r2, r3]");
        }
        System.out.println("UndoHistoryTest fails=" + fails);
    }

    /** Edicao cuja reversao registra {@code onRevert} e devolve uma inversa que registra {@code onBack}. */
    static UndoHistory.Edit mark(final List<String> log, final String onRevert, final String onBack) {
        return new UndoHistory.Edit() {
            @Override public UndoHistory.Edit revert() { log.add(onRevert); return mark(log, onBack, onRevert); }
        };
    }
}
