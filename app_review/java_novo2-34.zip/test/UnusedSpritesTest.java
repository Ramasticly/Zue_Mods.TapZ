package com.zue.attackeditor;

import java.util.List;
import static com.zue.attackeditor.BattleTest.*;

/** Remover Sprites nao usadas: so entram as que nenhum Frame de nenhuma ANO presente usa; GIF fica fixo, vazias marcadas. */
public class UnusedSpritesTest {
    static Ano.Mpt mpt(int image) {
        Ano.Mpt m = new Ano.Mpt();
        m.image = image; m.time = 2; m.flags = 0x20; m.normalize();
        return m;
    }

    static Dac dac(Ano... anos) throws Exception {
        java.lang.reflect.Constructor<Dac> c = Dac.class.getDeclaredConstructor(Ano[].class, java.util.List.class);
        c.setAccessible(true);
        return c.newInstance((Object) anos, new java.util.ArrayList<String>());
    }

    static String idx(List<UnusedSprites.Item> l) {
        StringBuilder b = new StringBuilder();
        for (UnusedSprites.Item i : l) b.append(b.length() == 0 ? "" : ",").append(i.index);
        return b.toString();
    }

    public static void main(String[] args) throws Exception {
        boolean[] draw = {true, true, true, true, true, true, false, true};     // 8 sprites; a 6 e vazia
        Ano a0 = new Ano(0, true, 0, 0, null, new Ano.Mpt[]{mpt(0), mpt(2), mpt(-1), mpt(2)});
        Ano a1 = new Ano(1, true, 0, 0, null, new Ano.Mpt[]{mpt(5), mpt(99)});
        Ano ghost = new Ano(2, false, 0, 0, null, new Ano.Mpt[]{mpt(4)});        // ANO que nao existe: nao conta
        Dac d = dac(a0, a1, ghost);
        check("usadas: 0, 2 e 5 (-1 e 99 ignoradas; ANO ausente nao conta)", java.util.Arrays.toString(UnusedSprites.used(d, 8)), "[true, false, true, false, false, true, false, false]");
        check("sem uso em ordem: 1, 3, 4, 6, 7", idx(UnusedSprites.find(d, 8, draw, null)), "1,3,4,6,7");
        List<UnusedSprites.Item> l = UnusedSprites.find(d, 8, draw, null);
        check("a 6 e vazia, as outras tem desenho", l.get(3).empty && !l.get(0).empty && !l.get(4).empty, true);
        check("uma sprite usada em varias ANOs/Frames conta uma vez e nunca entra", !idx(l).contains("2") && !idx(l).contains("0"), true);

        SpriteGroups g = new SpriteGroups();
        g.add(new SpriteGroups.Group("anim", 3, 2, new int[]{100, 100}));        // sprites 3 e 4
        l = UnusedSprites.find(d, 8, draw, g);
        check("sprites de GIF sem uso aparecem como fixas (3 e 4)", l.get(1).inGif && l.get(2).inGif && !l.get(0).inGif && !l.get(3).inGif, true);
        g.add(new SpriteGroups.Group("outro", 0, 2, new int[]{100, 100}));       // 0 e 1: a 0 e usada, a 1 nao
        l = UnusedSprites.find(d, 8, draw, g);
        check("GIF com uma sprite usada: so a sem uso entra, ainda fixa", l.get(0).index == 1 && l.get(0).inGif, true);

        check("sem DAC: todas sem uso", idx(UnusedSprites.find(null, 3, new boolean[]{true, true, true}, null)), "0,1,2");
        check("zero sprites: lista vazia", UnusedSprites.find(d, 0, new boolean[0], null).isEmpty(), true);
        // consistencia com 'Mostrar usos'
        boolean cons = true;
        for (int i = 0; i < 8; i++) {
            boolean listed = idx(UnusedSprites.find(d, 8, draw, null)).matches(".*(^|,)" + i + "(,|$).*");
            if (listed != SpriteUses.find(d, i).isEmpty()) cons = false;
        }
        check("esta na lista <=> 'Mostrar usos' esta vazio", cons, true);
        check("todas usadas: lista vazia", UnusedSprites.find(dac(new Ano(0, true, 0, 0, null, new Ano.Mpt[]{mpt(0), mpt(1)})), 2, new boolean[]{true, true}, null).isEmpty(), true);
    }
}
